# <a id="zep"/>Zephaniah

## Zephaniah 01

### Zephaniah 01:01

#### General Information:

Verses 1:2-18 refer to Yahweh's judgment. Verses 1:2-3 describe Yahweh's final judgment of every sinner in the future.

#### the word of Yahweh that came

This idiom is used to introduce a special message from God. AT: "Yahweh gave a message" or "Yahweh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### son of Gedaliah son of Amariah son of Hezekiah

This is a list of Zephaniah's ancestors. These usages of "son of" are the broader sense of "descendant of." Here "Hezekiah" refers to King Hezekiah. These things can be made explicit. AT: "the grandson of Gedaliah, and the great-grandson of Amariah, whose father was King Hezekiah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will utterly destroy everything from off the surface of the earth ... I will cut off man from the surface of the earth

The words "everything" and "will cut off man" are deliberate exaggerations by Yahweh to express his anger at the people's sin. Yahweh will destroy neither sinners who repent nor all living things nor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### destroy everything from off the surface of the earth

"destroy everything that is on the entire earth"

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### man and beast

"people and animals"

#### the ruins

Possible meanings are 1) the piles of rubble that will remain after the judgment or 2) the idols that Yahweh destroyed.

#### cut off

Destroying is spoken of as if it were cutting something off from what it was a part of. AT: "destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zephaniah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zephaniah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Zephaniah 01:04

#### General Information:

Verses 1:2-18 refer to Yahweh's judgment. Verses 1:4-16 describe Yahweh's judgment on the people of Judah.

#### I will reach out with my hand over Judah

This is an idiom that means God will punish. AT: "I will punish Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I will cut off every remnant ... the names of the idolatrous people among the priests ... the people who on the housetops ... the people who worship and swear

The verb "cut off" applies to each of these phrases, but has been used only once to avoid repetition. AT: "I will cut off every remnant ... I will cut off the names of the idolatrous people among the priests ... I will cut off the people who on the housetops ... I will cut off the people who worship and swear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### cut off

Destroying is spoken of as if it were cutting something off from what it was a part of. See how you translated this in [Zephaniah 1:3](./01.md). AT: "destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### cut off ... the names of the idolatrous people among the priests

Here "cut off ... the names" is an idiom that means to cause people to forget them. AT: "cause everyone ... to forget the priests who are idolatrous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### by their king

See the footnote about the possible rendering of this as "by Milcom."

#### neither seek Yahweh nor ask for his guidance

Seeking Yahweh represents either 1) asking God for help or 2) thinking about God and obeying him. AT: "do not think about Yahweh or ask him to guide them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Zephaniah 01:07

#### General Information:

Verses 1:2-18 refer to Yahweh's judgment. Verses 1:4-16 describe Yahweh's judgment on the people of Judah.

#### General Information:

In verses 1:8-13, Yahweh is speaking. He alternates between using first person and speaking about himself in the third person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Be silent

This is an idiom. Here silence is meant to signal shock and amazement. AT: "Be shocked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh has prepared the sacrifice and set apart his guests

The people of Judah are spoken of as Yahweh's sacrifice, and the enemy nations are spoken of as his guests who would eat the sacrifice. This can be stated explicitly. AT: "Yahweh has prepared the people of Judah as a sacrifice, and invited the enemy nations as his guests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### set apart his guests

Here "set apart" is an idiom that means he has invited them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### It will come about

This phrase is used to mark the point at which Yahweh's judgment of Judah will begin.

#### everyone dressed in foreign clothes

This phrase suggests that the Israelites wore clothes similar to the foreigners to show sympathy to their customs and to the worship of their foreign gods. AT: "everyone who worships foreign gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### On that day

"On the day of Yahweh"

#### all those who leap over the threshold

Possible meanings are 1) this is a reference to people who did not step on thresholds as part of their worship of a god called Dagan or 2) people who leapt up onto platforms to worship pagan idols or 3) royal officials who climbed the steps to the throne.

#### fill their master's house with violence and deceit

The abstract nouns "violence" and "deceit" can be stated as actions. AT: "those who do violent things and tell lies in the temples of their gods"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Zephaniah 01:10

#### General Information:

Verses 1:2-18 refer to Yahweh's judgment. Verses 1:4-16 describe Yahweh's judgment on the people of Judah.

#### General Information:

In verses 1:8-13, Yahweh is speaking. He alternates between using first person and speaking about himself in the third person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### on that day

"on the day of Yahweh." See how you translated this phrase in [Zephaniah 1:9](./07.md).

#### Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "what Yahweh has declared" or "what Yahweh has solemnly said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Fish Gate

The Fish Gate was one of the gates in the Jerusalem city wall.

#### wailing from the Second District

"Mourn loudly from the Second District." The Second District was a newer part of Jerusalem.

#### a great crashing sound

This refers to the sound of buildings collapsing. This can be stated explicitly. AT: "a loud sound of buildings collapsing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from the hills

This refers to the hills surrounding Jerusalem.

#### for all the merchants will be ruined; all those who weigh out silver will be cut off

These two phrases refer to the same people and are used to emphasize that business will be destroyed. AT: "for those who buy and sell goods will be killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### those who weigh out silver

This refers to merchants. Before coins were used, people weighed out silver or gold as payment for things they bought.

#### cut off

Destroying is spoken of as if it were cutting something off from what it was a part of. See how you translated this in [Zephaniah 1:3](./01.md). AT: "destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Zephaniah 01:12

#### General Information:

Verses 1:2-18 refer to Yahweh's judgment. Verses 1:4-16 describe Yahweh's judgment on the people of Judah.

#### General Information:

In verses 1:8-13, Yahweh is speaking. He alternates between using first person and speaking about himself in the third person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### It will come about at that time

This phrase is used to mark the time when Jerusalem has been destroyed by the enemies.

#### I will search Jerusalem with lamps

Yahweh speaks of knowing about all people of Jerusalem as if he had searched for them with lamps. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### settled into their wine

They feel safe from trouble. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### say in their heart, 'Yahweh will not do anything, either good or evil.'

This direct quotation can be stated as an indirect quotation. AT: "say in their heart that Yahweh will not do anything, either good or evil.

#### say in their heart

This idiom means they think to themselves. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh will not do anything, either good or evil

Here "good and evil" is a merism that includes everything in between. AT: "Yahweh will not do anything at all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### an abandoned devastation

"destroyed and abandoned"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]

### Zephaniah 01:14

#### General Information:

Verses 1:2-18 refer to Yahweh's judgment. Verses 1:4-16 describe Yahweh's judgment on the people of Judah.

#### near, near and hurrying quickly

The repetition of the word "near," along with the phrase "hurrying quickly," emphasize that the day when Yahweh judges the people will soon happen. AT: "close and will be here soon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the day of Yahweh

See how you translated this phrase in [Zephaniah 1:7](./07.md).

#### a warrior crying bitterly

Possible meanings are 1) a soldier crying in despair or 2) a soldier's battle cry.

#### That day ... a day

These phrases refer back to the "day of Yahweh" in verse 14.

#### That day will be a day of fury ... battlements

Verses 15-16 have multiple figures of speech that together emphasize the destructive nature of this final judgment by God.

#### a day of distress and anguish

The words "distress" and "anguish" mean about the same thing and emphasize the intensity of the people's distress. AT: "a day when people feel terrible distress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### a day of storm and devastation

Here the word "storm" refers to divine judgment. The word "devastation" describes the effects of that judgment. AT: "a day of devastating storms" or "a day of devastating judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a day of darkness and gloom

The words "darkness" and "gloom" share similar meanings and emphasize the intensity of darkness. Both words refer to a time of disaster or divine judgment. AT: "a day that is full of darkness" or "a day of terrible judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a day of clouds and thick darkness

This phrase means the same thing as, and intensifies, the idea of the previous phrase. Like that phrase, both "clouds" and "thick darkness" refer to divine judgment. AT: "a day full of dark storm clouds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a day of trumpets and alarms

The words "trumpets" and "alarms" mean basically the same thing here. Both are means to call soldiers to prepare for battle. AT: "a day when people sound the alarm for battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### fortified cities and the high battlements

These two phrases both refer to military strongholds. AT: "well fortified cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Zephaniah 01:17

#### General Information:

Verses 1:2-18 refer to Yahweh's judgment. Verses 1:17-18 describe Yahweh's final judgment of every sinner in the future.

#### they will walk about like blind men

The result of Yahweh's judgment is that people will be so confused and dazed when they walk about that people will think they are blind. AT: "they will walk around as confused and dazed as blind men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Their blood will be poured out like dust

Their blood that is shed will be as worthless as dust. This can be stated in active form. AT: "Their enemies will pour out their blood and consider it to be worthless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### their inner parts like dung

The verb "poured out" is understood here. This can be stated in active form. AT: "their enemies will cut open their bodies and leave them to rot like dung" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the fire of his jealousy

Here "fire" refers to the intensity of Yahweh's anger. This can be stated as a simile. AT: "his jealousy is as intense as a fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### all the inhabitants of the earth

It is understood that this refers to the wicked people. This can be stated explicitly. AT: "all the wicked people who live on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]

### Zephaniah 01:intro

#### Zephaniah 01 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 1:2-18.

####### Special concepts in this chapter #######

######## Prophecy ########
In this chapter, it is unclear whether these prophecies concern the fall of Jerusalem, the coming of the Messiah or the day of the Lord. It is possible that the prophecies reference more than one period of time. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]])

##### Links: #####

* __[Zephaniah 01:01 Notes](./01.md)__
* __[Zephaniah intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Zephaniah 02

### Zephaniah 02:01

#### General Information:

In 2:1-3, Yahweh continues to speak to Judah, and tells them to repent.

#### Rally yourselves together and gather

These two phrases mean the same thing. Together they intensify the command for the people to gather together in order to repent of their sins. AT: "Gather yourselves together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### unashamed nation

The nation is not sorry for their sins.

#### before the decree takes effect

This phrase refers to the punishment that will happen as a result of Yahweh's decree. AT: "before Yahweh punishes you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### that day ... the day of the wrath of Yahweh ... the day of Yahweh's wrath

These phrases all refer to the "day of Yahweh." Translate these phrases as you did similar phrases in [Zephaniah 1:7-9](../01/07.md).

#### that day passes like the chaff

The chaff is the insignificant part of the plant that the wind blows away. In a similar way, the day of judgment will pass quickly. AT: "that day passes as quickly as chaff blown by the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### before the fierce anger of Yahweh's wrath comes upon you, before the day of the wrath of Yahweh comes upon you

The prophet repeats the same phrase almost exactly in order to emphasize how terrible Yahweh's judgment will be and the urgency with which the people must repent. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Yahweh's wrath

This stands for God's intent to punish. AT: "Yahweh's punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Seek Yahweh

Seeking Yahweh represents either 1) asking God for help or 2) thinking about God and obeying him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Seek righteousness. Seek humility

The abstract nouns "righteousness" and "humility" can be stated as actions. AT: "Try to do what is right and to be humble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### you will be protected in the day of Yahweh's wrath

This can be stated in active form. AT: "Yahweh will protect you in the day of his wrath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chaff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chaff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Zephaniah 02:04

#### General Information:

In 2:4-15, Yahweh announces his judgment on the nations that surround Judah.

#### Gaza ... Ashkelon ... Ashdod ... Ekron

These were the four major Philistine cities of that day.

#### will be abandoned ... will turn into a devastation

These two phrases mean the same thing and emphasize the complete destruction of these cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### They will drive out Ashdod at noon

Here "They" refers to the enemies of the Philistines. Possible meanings for "at noon" are 1) the enemies will defeat Ashdod before noon or 2) the enemies will attack Ashdod at noon while the people are resting and unaware.

#### they will uproot Ekron

The defeat of Ekron is spoken of as if it was a tree that was pulled from the ground and thrown away. AT: "they will take the people of Ekron away as if uprooting a tree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the inhabitants of the seacoast, the nation of the Kerethites

The first phrase explains where the Kerethites lived.

#### Canaan, land of the Philistines

The Philistines were one of several people groups who lived in Canaan.

#### until no inhabitant remains

"until no one is left." This can be stated in positive form. AT: "until every inhabitant is dead"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cherethites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cherethites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Zephaniah 02:06

#### General Information:

In 2:4-15, Yahweh announces his judgment on the nations that surround Judah.

#### So the seacoast will become pastures for shepherds and for sheep pens

This probably means that the Philistine cities are gone, and only open fields remain. However, the Hebrew meaning is unclear and is sometimes translated differently by modern versions.

#### sheep pens

A sheep pen is a small area surrounded by a fence to keep the sheep together.

#### Their people

"The people of Judah"

#### lie down

"lie down to sleep"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]

### Zephaniah 02:08

#### General Information:

In 2:4-15, Yahweh announces his judgment on the nations that surround Judah.

#### the taunts ... the reviling

"the taunts ... the insults." These two phrases mean the same thing and emphasize that both Moab and Ammon have insulted Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### violated their borders

This refers to crossing over into Judah's territory in order to attack them.

#### as I live

"as surely as I am alive." Yahweh uses this expression to show that what he says next is certainly true. This is a way of making a solemn promise. AT: "I solemnly swear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### this is the declaration of Yahweh of hosts, God of Israel

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "this is what Yahweh of hosts, God of Israel, has declared" or "this is what I, Yahweh of hosts, God of Israel, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### like Sodom ... like Gomorrah

These two cities were so wicked that God completely destroyed them with fire from heaven. These similes therefore refer to complete destruction. This can be stated explicitly. AT: "completely destroyed like Sodom ... like Gomorrah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a place of nettles and a salt pit

"a place with thorns and a salt pit." This describes a barren, useless land.

#### the remnant of my people ... the remainder of my nation

These two phrases mean the same thing and refer to the Israelites that survived Yahweh's punishment. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]

### Zephaniah 02:10

#### General Information:

In 2:4-15, Yahweh announces his judgment on the nations that surround Judah.

#### they taunted and mocked the people of Yahweh of hosts ... he will taunt all the gods of the earth

Yahweh is speaking with irony. He will taunt the worthless gods in the same way that the people who served those gods had taunted Yahweh's people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Zephaniah 02:12

#### General Information:

In 2:4-15, Yahweh announces his judgment on the nations that surround Judah.

#### You Cushites also will be pierced by my sword

Here "pieced by my sword" is a metonym for being killed in battle. AT: "I will kill you people of Cush in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### God's hand

Here "hand" refers to power. AT: "God's power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### an abandoned devastation

The abstract noun "devastation" can be stated as an action. AT: "ruined and deserted" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### as dry as the desert

This means it will be so dry that nothing will grow there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### every animal of the nations

"every kind of animal"

#### the screech owl

This term is uncertain. Some versions translate it as "hedgehog."

#### in the top of her columns

When buildings were destroyed and fell down, the columns used for decoration and support would often remain standing.

#### A call will sing out from the windows

"A call will be heard from the windows"

#### beams

Beams are long and thick pieces of wood that are used to keep a building stable.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cush.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cush.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]

### Zephaniah 02:15

#### General Information:

In 2:4-15, Yahweh announces his judgment on the nations that surround Judah.

#### the exultant city

"the city that is proud of itself." This refers to the city of Nineveh, about whom Yahweh began to speak in [Zephaniah 2:13](./12.md).

#### said in her heart

This idiom means "said to herself" or "she thought." The city is spoken of as if it were a person that could speak. It represents the people who live in that city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I am, and nothing is my equal

It may be necessary to supply an object for "I am." AT: "I am the greatest city, and no other city is equal to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a horror

"a horrible place to see"

#### hiss and shake his fist

A hiss is an angry sound. This phrase indicates extreme anger of the people toward Nineveh.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exult.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exult.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Zephaniah 02:intro

#### Zephaniah 02 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 2:1-9, 12-15.

####### Special concepts in this chapter #######

######## Prophecy ########
In this chapter, because the prophesied destruction is so complete, it is unclear whether these prophecies concern the time near the fall of Jerusalem or the day of the Lord. It is possible that the prophecies reference more than one period of time. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]])

##### Links: #####

* __[Zephaniah 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Zephaniah 03

### Zephaniah 03:01

#### General Information:

In verses 3:1-5, Zephaniah speaks Yahweh's message of judgment to the sinful people of Jerusalem. The city represents the people who live within it. To make this clear, it may be helpful to replace the singular "she" and "her" with the plural "they" and "their." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the rebellious city

The nature of their rebellion can be stated. AT: "the people of the city who have rebelled against God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The violent city is defiled

"The people of the city have committed violence and so I consider them unclean"

#### She has not listened to the voice of God

The voice is a metonym for what the speaker says with the voice, and listening is a metonym for obeying. AT: "She has not obeyed what God has said to her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]

### Zephaniah 03:03

#### General Information:

In verses 3:1-5, Zephaniah speaks Yahweh's message of judgment to the sinful people of Jerusalem. The city represents the people who live within it. To make this clear, it may be helpful to replace the singular "she" and "her" with the plural "they" and "their." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Her princes are roaring lions in her midst

Lions roar to chase other animals away from the prey they have caught. The princes of Jerusalem are spoken of as if they were roaring lions who were keeping the prey for themselves. AT: "Jerusalem's royalty are as greedy as roaring lions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Her judges are evening wolves who leave nothing to be gnawed upon in the morning

Wolves are especially hungry before they hunt at night. The judges are spoken of as if they were hungry wolves. AT: "Her judges are as greedy as hungry wolves that leave nothing for anyone else" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Her prophets are insolent and treasonous men

"Her prophets do not listen to anyone and cannot be trusted"

#### have profaned what is holy

"have treated holy things with disrespect"

#### have done violence to the law

"have broken the law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wolf.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wolf.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Zephaniah 03:05

#### General Information:

In verses 3:1-5, Zephaniah speaks Yahweh's message of judgment to the sinful people of Jerusalem.

#### Yahweh is righteous ... He can do no wrong

These two phrases mean the same thing, and emphasize Yahweh's righteousness even among the wicked people in Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### in her midst

"among them"

#### Morning by morning

This idiom means "Every day" or "Day after day." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he will dispense his justice

Yahweh's just treatment of every person is spoken of as if he was handing out a commodity. AT: "he will treat people justly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It will not be hidden in the light

This uses a negative statement to emphasize the positive truth that Yahweh's justice is always visible. AT: "His justice is clearly shown to all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### know no shame

"are not ashamed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/criminal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/criminal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Zephaniah 03:06

#### General Information:

In verses 3:6-7, Yahweh rebukes the people of Jerusalem because they did not learn from how he judged other sinful cities. It may be helpful to add "Yahweh says this:" to the beginning of verse 6 to make this explicit. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I have made their streets ruins, so that no one passes over them. Their cities are destroyed so that there is no man inhabiting them

These two sentences express the same idea in two different ways in order to emphasize the complete destruction of the cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### no one passes over them

"no one walks on them"

#### there is no man inhabiting them

"no one lives there." This can be stated in positive form. AT: "all the people are dead"

#### I said, 'Surely you will fear me ... I have planned to do to you.'

This can be stated as an indirect quotation. AT: "I thought they would surely fear me and accept correction so that they would not be cut off from their homes by all that I have planned to do to them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### and do not be cut off from your homes

Here "cut off" is an idiom that means to be removed. This can be stated in active form. AT: "so that I will not remove you from your homes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by corrupting all their deeds

"by doing deeds that were corrupt"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]

### Zephaniah 03:08

#### General Information:

In verse 3:8, Yahweh warns that he will judge all nations.

#### wait for me ... until the day

This phrase implies that they are waiting for judgment.

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I rise up to seize the prey

Yahweh's judgment on the nations is spoken of as if he was an hungry animal that attacked a smaller animal. AT: "I will rise up and destroy them as an animal seizes its prey" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to assemble the nations, to gather the kingdoms

These two phrases mean the same thing and emphasize that Yahweh will judge all of the nations. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### my anger—all of my burning wrath

The words "anger" and "burning wrath" mean basically the same thing and emphasize the intensity of Yahweh's anger. AT: "my very fierce wrath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### in the fire of my jealousy all the earth will be consumed

This phrase can be stated in active form. AT: "the fire of my jealousy will devour all the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the fire of my jealousy ... consumed

Yahweh's jealousy is here spoken of as if it were fire that could consume something. This can be stated as a simile. AT: "my jealousy will consume all the earth as a fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Zephaniah 03:09

#### General Information:

In verses 3:9-10, Yahweh says that he will renew the Gentiles after the judgment.

#### General Information:

In verses 3:11-13, Yahweh encourages the remnant of Israel who survive the judgment.

#### I will purify the lips of the peoples

Here "lips" refers to the ability to speak. AT: "I will cause the peoples to speak what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### call upon the name of Yahweh

This is an idiom that means they worship Yahweh. AT: "worship Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### serve him shoulder to shoulder

Here "shoulder to shoulder" is an idiom that means "side by side." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### beyond the river of Cush

This may refer to the area where Sudan is located today.

#### In that day ... at that time

"When that happens ... at that time." These phrases here refer to the time of peace and restoration that immediately follows the day of Yahweh.

#### will not be put to shame for all your deeds

This can be stated in active form. AT: "will no longer be ashamed of all your deeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### those who celebrated your pride

"all the people who are very proud"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Zephaniah 03:12

#### General Information:

In verses 3:11-13, Yahweh encourages the remnant of Israel who survive the judgment.

#### I will leave among you a lowly and poor people ... The remnant of Israel

The first phrase describes the "remnant" in the second phrase.

#### they will find refuge in the name of Yahweh

Yahweh's protection of this remnant is spoke of as if he was a refuge or a fortress. Here "name of Yahweh" refers to his person. AT: "they will come to Yahweh and he will help them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### commit injustice

"do unjust things"

#### no deceitful tongue will be found in their mouth

Here "tongue ... in their mouth" represents the things that the tongue enables the mouth to speak. They can be stated in active form. AT: "none of them will speak deceitful things" or "they will not say deceitful things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they will graze and lie down

Yahweh speaks of his provision for the people of Israel as if they are a flock of sheep that grazes and rests in safety. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lowly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lowly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]

### Zephaniah 03:14

#### General Information:

In verses 3:14-20, Zephaniah tells the remnant of Israel who survived the judgment that they should rejoice.

#### daughter of Zion ... daughter of Jerusalem

Here "daughter" refers to all the people who lived in the city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Be glad and rejoice

These two phrases mean the same thing and emphasize how happy they should be. AT: "Be very happy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### with all your heart

Here "heart" refers to the inner being of a person. AT: "with all your inner being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yahweh has taken away your punishment

Here to "take away" punishment is an idiom that means to stop doing it. AT: "Yahweh has stopped punishing you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### You will never again fear evil

The abstract noun "evil" can be stated as an action. AT: "You will no longer be afraid that people will harm you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### In that day

"At that time" or "When this happens." This phrase here refers to the time of peace and restoration that immediately follows the day of Yahweh.

#### say to Jerusalem ... Zion

The names of these cities here refer to the people who live in them. AT: "say to the people of Jerusalem ... people of Zion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Do not let your hands falter

To feel weak or helpless is spoken of as if their hands became physically weak. Here "hands" represents the whole person. AT: "Do not become weak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Zephaniah 03:17

#### General Information:

In verses 3:14-20, Zephaniah tells the remnant of Israel who survived the judgment that they should rejoice.

#### a mighty one to save you

"he is mighty and will save you." Yahweh is spoken of as a mighty warrior. AT: "he is a mighty warrior and will give you victory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He will celebrate over you with joy ... he will be glad over you with a shout for joy

These two phrases mean the same thing and are repeated to emphasize Yahweh's joy that the remnant is restored to him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### he will be silent over you in his love

Possible meanings are 1) "he will quiet you by his love for you" or 2) "he will renew you because he loves you."

#### no longer bear any shame for it

Here shame is spoken of as if it was a heavy thing that a person had to carry. AT: "no longer be ashamed because of it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]

### Zephaniah 03:19

#### General Information:

In verses 3:19-20, Yahweh speaks directly to the remnant of Israel who survived the judgment and tells them that they should rejoice.

#### Behold

This tells the reader to pay special attention to what follows. AT: "Look" or "Pay attention"

#### I am about to deal with all your oppressors

It is understood that "deal with" means to punish the oppressors. This can be stated explicitly. AT: "I will severely punish all those who oppressed you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will rescue the lame and gather up the outcast

Here the Israelites who suffered in exile are spoken of as if they were lame and outcast sheep. This can be stated as a simile. AT: "I will rescue and bring together the remnant of Israel who are like lame and outcast sheep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the lame

This refers to people or animals that cannot walk.

#### I will make them as praise

The full thought here is, "I will make them to be objects of praise," that is, "I will make them to be praised by others." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### I will change their shame into renown

The abstract nouns "shame" and "renown" can be stated as actions. AT: "I will cause them to no longer be ashamed, but for people to respect them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### At that time I will lead you; at that time I will gather you together

These two lines mean basically the same thing and imply that Yahweh will bring the exiled people back to their homeland. AT: "At that time I will gather you together and lead you home" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Zephaniah 03:intro

#### Zephaniah 03 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 3:1-20.

####### Special concepts in this chapter #######

######## Prophecy ########
In this chapter, because the prophesied destruction is so complete, it is unclear whether these prophecies concern the time near the fall of Jerusalem or the day of the Lord. It is possible that the prophecies reference more than one period of time. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]])

##### Links: #####

* __[Zephaniah 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | __


## Zephaniah front

### Zephaniah front:intro

#### Introduction to Zephaniah ####

##### Part 1: General Introduction #####

####### Outline of the Book of Zephaniah #######

1. Yahweh will judge Judah on "the Day of Yahweh" 
    - Judgment on Baal worshipers (1:2–6)
    - Yahweh will cause the destruction of Judah (1:7–13)
    - Judgment is coming soon (1:14–18)
    - Invitation to "seek Yahweh" and escape the Day of Yahweh (2:1–3)
1. Yahweh's judgment on the nations 
    - Philistia (2:4–7)
    - Moab and Ammon (2:8–11)
    - Egypt (2:12)
    - Assyria (2:13–15)
1. Judgment on Jerusalem, the city of oppressors (3:1–8)
1. The promise that Yahweh will purify, restore, gather, and bless his people (3:9–20)

####### What is the Book of Zephaniah about? #######

This book contains prophecies that warned Judah and other nations that God is about to punish them on the day of Yahweh. There are also prophecies about how God will restore Judah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]])

####### How should the title of this book be translated? #######

Translators may decide to translate this traditional title "The Book of Zephaniah" in a way that is clearer to the readers. They may decide to call it, "The sayings of Zephaniah." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Zephaniah? #######

Zephaniah is the author of this book, but there are four different individuals in the Old Testament named Zephaniah. This Zephaniah was probably the great-grandson of King Hezekiah and a cousin to King Josiah. Zephaniah lived in the city of Jerusalem and began to prophesy about seventy years after the prophets Isaiah and Micah. Zephaniah spoke Yahweh's messages during the reign of King Josiah (about 640–621 B.C.), and just before the prophet Jeremiah began his own work. 

##### Part 2: Important Religious and Cultural Concepts #####

####### Were the people of Judah faithful to Yahweh at the time Zephaniah started his work? #######

Manasseh, the grandfather of Josiah, had been one of the worst kings of Judah. He encouraged the people to worship other gods. After his death, his son Amon ruled for only two years before he was assassinated. Amon's son Josiah became king when he was eight years old and learned to worship and honor Yahweh. It is likely that Zephaniah began his work after Josiah had destroyed most of the idols and shrines of false gods in Judah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

####### What country is coming to invade Judah? #######

Zephaniah often mentioned a foreign nation that would invade the kingdom of Judah. Zephaniah probably meant the Babylon. However, the name of this nation is never mentioned.



---

