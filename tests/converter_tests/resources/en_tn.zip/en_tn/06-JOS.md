# <a id="jos"/>Joshua

## Joshua 01

### Joshua 01:01

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### Nun

Joshua's father (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### cross over this Jordan

To "cross over" means "go to the opposite bank of the river." AT: "travel from this side to the opposite side of the Jordan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you and all this people

The word "you" here refers to Joshua. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### I have given you every place

God giving the land to the Israelites in the future is spoken of as if he gave it to them in the past. This emphasizes that he will certainly give it to them. AT: "I will give to you every place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### I have given you

The word "you" refers to both Joshua and the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### every place where the sole of your foot will walk

This refers to all the places Joshua and the Israelites will travel when they cross the Jordan River. AT: "everywhere you go in this land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Joshua 01:04

#### General Information:

Yahweh continues speaking to Joshua.

#### your land

The word "your" refers to the tribes of Israel and not only Joshua. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### to stand before you

In verse 5 the words "you" and "your" refer to Joshua. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### I will not abandon you or leave you

The words "abandon" and "leave" mean basically the same thing. Yahweh combines them to emphasize that he will not do these things. AT: "I will certainly stay with you always" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]

### Joshua 01:06

#### General Information:

Yahweh gives Joshua a series of commands. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md)]])

#### Be strong and courageous

Yahweh commands Joshua to overcome his fears with courage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md)]])

#### Do not turn from it to the right or to the left

This can be stated as a positive command. AT: "Follow it exactly" or "Follow them exactly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md)]])

#### be successful

"achieve your goal" or "reach your goal"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]

### Joshua 01:08

#### General Information:

Yahweh continues speaking to Joshua.

#### You will always speak

The word "always" is an exaggeration for speaking often. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### prosperous and successful

These two words mean basically the same thing and emphasize great prosperity. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Have I not commanded you?

This refers to Yahweh commanding Joshua. AT: "I have commanded you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Be strong and courageous!

Yahweh is commanding Joshua. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/meditate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/meditate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 01:10

#### Go through the camp and command the people, 'Prepare ... possess.'

Embedded quotes can be expressed as indirect quotes. AT: "Go through the camp and command the people to prepare provisions for themselves. In three days they will cross over this Jordan and go in and possess the land that Yahweh their God is giving them to possess." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md)]])

#### the people

This refers to the people of Israel. AT: "the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### In three days

Here Joshua was counting his present day as day one. AT: "Two days from now" or "On the day after tomorrow"

#### cross over this Jordan

"cross over" refers to going to the opposite side of the river. AT: "travel to the other side of the Jordan River" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joshua 01:12

#### General Information:

The tribes of Reuben, Gad and half of the tribe of Manasseh chose to settle east of the Jordan River. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Reubenites

These were the descendants of Reuben. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Gadites

These were the decendants of Gad. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Joshua 01:14

#### General Information:

Joshua continues speaking to the Reubenites, Gadites, and the half tribe of Manasseh.

#### your little ones

"your little children"

#### beyond the Jordan

This refers to the east side of the Jordan River. Later most of the Israelites would live west of the Jordan, so they called the east side "beyond the Jordan." But at this time they were all still on the east side. AT: "east of the Jordan River" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### given your brothers rest

This refers to Israel defeating all their enemies residing in Canaan that they were to conquer. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you will ... possess it

This refers to living out their life on the land in peace.

#### beyond the Jordan, where the sun rises

This refers to the east side of the Jordan river. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 01:16

#### General Information:

These Isrelites were specifically the Reubenites, Gadites, and the half tribe of Manasseh that replied to Joshua.

#### rebels against your commands and disobeys your words

These two phrases mean basically the same thing and emphasize that any form of disobedience will be punished. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### will be put to death

This can be stated in active form. AT: "we will put to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### be strong and courageous

Israel and God considered both traits important for Joshua to pursue as their leader. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]

### Joshua 01:intro

#### Joshua 01 General Notes ####

#######  Structure and formatting #######

This chapter appears to be a natural continuation of the book of Deuteronomy.

####### Special concepts in this chapter #######

######## Be strong and Courageous ########

Joshua is often told, "Be strong and courageous." This repeated encouragement is on purpose and may indicate Joshua will need help in the future.  

##### Links: #####

* __[Joshua 01:01 Notes](./01.md)__
* __[Joshua intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Joshua 02

### Joshua 02:01

#### Nun

This is Joshua's father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shittim

This is the name of a place on the east side of the Jordan River. It means "Acacia Trees." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### as spies

These men were to visit the land to gain information on how Israel should conquer the land.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 02:04

#### General Information:

Rahab the prostitute protects the two Israelite spies from harm.

#### But the woman had taken the two men and hidden them

This happened before the king's messenger spoke to her.

#### the woman

This refers to Rahab, the prostitute.

#### dusk

This is the time that day begins to change to the darkness of night.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Joshua 02:06

#### But she had taken them ... on the roof

This is background information and explains how she had hidden the men in [Joshua 2:4](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### the roof

The roof was flat and strong, so people could walk around on it.

#### flax

a plant that is grown for its fibers, which is used in making cloth

#### the men pursued them

The men pursued the spies because of what Rahab had told them in [Joshua 2:5](./04.md).

#### fords

places where a river or other body of water is shallow enough for people to get to the other side by walking through it

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Joshua 02:08

#### not yet lain down

This refers to going to sleep for the night. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I know that Yahweh has given you the land

The word "you" refers to the all the Israelite people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### fear of you has come upon us

Becoming afraid is spoken of as if feat came and attacked them. AT: "we have become afraid of you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will melt away before you

This compares the fearful people to ice melting and flowing away. Possible meanings are 1) they will be weak in the Israelites' presence or 2) they will be scattered. AT: "will be so afraid that they will not resist you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Joshua 02:10

#### General Information:

Rahab continues to talk to the Israelite spies.

#### the Sea of Reeds

This is another name for the Red Sea.

#### Sihon ... Og

These are the names of the Amorite kings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### our hearts melted and there was no courage left in anyone

These two phrases share similar meanings, combined for emphasis. The phrase "our hearts melted" compares the hearts of the fearful people of Jericho to ice melting and flowing away. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Joshua 02:12

#### General Information:

Rahab continues to talk to the Israelite spies.

#### please swear to me ... Give me a sure sign

These are similar statements of Rahab seeking assurance from the spies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### I have been kind to you

The word "you" refers to the two spies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### spare the lives ... save us from death

a polite way of saying "do not to kill us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Joshua 02:14

#### General Information:

The Israelite spies make the promise which Rahab asked for in [Joshua 2:12](./12.md)

#### Our life for yours, even to death

This idiom is a way of swearing and asking God to curse them if they do not keep their promise. AT: "If we do not do what we promise, may Yahweh cause us to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Joshua 02:15

#### General Information:

The Israelite spies continue to talk to Rahab.

#### if you do not do this

This expresses a condition for the promise the spies had made to Rahab. The word, "this," refers to "tie this scarlet rope in the window" in [Joshua 2:18](./18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Joshua 02:18

#### Connecting Statement:

The Israelite spies clarify the condition they expressed in [Joshua 2:15](./15.md).

#### General Information:

The Israelite spies continue talking to Rahab.

#### Whoever goes out of the doors of your house

This phrase expresses a condition, creating a hypothetical situation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### blood will be upon their own heads

Here "blood" represents a person's death. To be responsible for their own death is spoken of as if their blood would be on their heads. AT: "their death will be their own fault" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### we will be guiltless

"we will be innocent"

#### if a hand is laid upon any

Here "a hand is laid upon" is a polite way of referring to causing someone injury. AT: "if we cause injury to any" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### Joshua 02:20

#### General Information:

The two Israelite spies continue to speak to Rahab about their promise to her.

#### General Information:

The spies required Rahab to remain silent about their visit or they would be free from their oath to protect her family.

#### if you speak

"You" refers to Rahab. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### May what you say be done

Rahab agreed to their terms of the oath to protect her family.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md)]]

### Joshua 02:22

#### General Information:

The two Israelites spies leave Jericho.

#### their pursuers returned

It may be helpful to say they returned to Jericho. AT: "their pursuers returned to the city of Jericho" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### found nothing

This refers to the men not finding the spies.

### Joshua 02:23

#### The two men returned

The two men returned back to the Israelite's camp. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### returned and crossed over and came back

These are similar expressions referring to returning to where the Israelite's are camped. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### crossed over

"cross over" means to go to the opposite bank of the river. AT: "traveled from this side to the opposite side of the Jordan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Nun

This is a male name; the father of Joshua. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### everything that had happened to them

"all that the men had experienced and seen."

#### us

This word, "us," refers to Israel.

#### inhabitants of the land are melting away

The people of the land toward Israel are like a substance that melts in the presence of heat. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 02:intro

#### Joshua 02 General Notes ####

####### Structure and formatting #######

This chapter begins the story of the conquest of the Promised Land. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

####### Special concepts in this chapter #######

######## Rahab's faith ########

Rahab expressed her faith in Yahweh. The statement "for Yahweh your God, he is God in heaven above and on the earth below" is a recognition of her faith. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]])

####### Important figures of speech in this chapter #######

######## Metaphor ########

The Israelites were to completely destroy the evil Canaanites. They are compared to melting snow: "... melting away because of us."  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

##### Links: #####

* __[Joshua 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Joshua 03

### Joshua 03:01

#### got up

The phrase, "got up," means to "awaken."

#### Shittim

A place in the land of Moab, west of the Jordan River where the Israelites were camped before their entry into the promised land, Canaan.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 03:02

#### officers

These are people holding a position of command or authority.

#### people

This is the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### two thousand cubits

"2,000 cubits." The word "cubit" is a measurement equaling the distance from the elbow to the finger tips. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Joshua 03:05

#### Consecrate yourselves

This refers to a special preparation of being religiously clean before Yahweh.

#### Yahweh will do wonders

Yahweh will be doing miracles for all to see and experience.

#### Take up the ark

This is referring to the levites picking up the ark for the purpose of carrying it from one location to another.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]

### Joshua 03:07

#### General Information:

Yahweh tells Joshua what the priest are to do.

#### I will make you a great man in the eyes of all Israel

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "the people will see what I do and realize that I have made you a great man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### edge of the waters of the Jordan

Joshua is to approach the bank or edge of the Jordan River.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 03:09

#### General Information:

Joshua tells Israel what Yahweh is about to do

#### drive out from before you

Yahweh will force the other people living on the land to leave or be killed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### crosses over

"cross over" means to go to the opposite bank of the river. AT: "will travel from this side to the opposite side" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/girgashites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/girgashites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 03:12

#### General Information:

Joshua continues to tell Israel of the miracle that Yahweh will do.

#### General Information:

Just as Israel's fathers experience crossing the Red Sea, these people will experience crossing the Jordan river on dry land.

#### the soles of the feet

This refers to the bottom of their feet.

#### upstream

This word refers to the direction the Jordan River water is flowing toward Israel.

#### stand in one heap

The water will stay in one spot or place. It will not flow around the priests.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 03:14

#### edge of the water

This can refer to the surface of the water as well as the bank where the water flows to dry land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### now the Jordan overflows all its banks throughout the time of the harvest

This is background information and it emphasizes the scale of what Yahweh is doing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Joshua 03:17

#### General Information:

The miraculous Jordan River crossing continues.

#### the Jordan

This refers to the Jordan River bed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### crossed over

This phrase means to go to the opposite bank of the river. AT: "traveled from this side to the opposite side" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 03:intro

#### Joshua 03 General Notes ####

####### Special concepts in this chapter #######

######## God dries the Jordan River ########

Joshua told the people "Dedicate yourselves to Yahweh tomorrow, for Yahweh will do wonders among you." The conquest of the Promised Land is accomplished through the supernatural power of God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

##### Links: #####

* __[Joshua 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Joshua 04

### Joshua 04:01

#### General Information:

Though Yahweh was speaking directly to Joshua, all occurrences of you include Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### crossed over

The words "crossed over" refer to going to the opposite bank of the river. AT: "went across" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the Jordan

the Jordan River (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Give them this command: ' ... '

The nested quote can be stated as an indirect quote. AT: "Give them this command to take up twelve stones from the middle of the Jordan where the priests are standing on the dry ground, and bring them over with you and lay them down in the place where you will spend the night tonight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Joshua 04:04

#### General Information:

Joshua tells the twelve men what to do.

#### into the middle of the Jordan. Each of you is to take up a stone upon his shoulder

Each of the twelve men were to pick up a large stone from the Jordan River bed and carry them to the other side to build a monument. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joshua 04:06

#### General Information:

Joshua tells Israel what the pile of twelve stones mean.

#### The waters of the Jordan were cut off before the ark of the covenant of Yahweh

This can be stated in active form. AT: "Yahweh cut off the waters of the Jordan in front of the ark of his covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The waters of the Jordan were

"The Jordan River was"

#### were cut off before the ark

The Jordan River was prevented by God from flowing up to the ark that was being carried by the priests.

#### the waters of the Jordan were cut off

The water flowing down the Jordan River stopped before the ark so everyone including the ark traveled on the dry river bed.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Joshua 04:08

#### General Information:

Joshua and Israel continue to do as Yahweh commanded.

#### they picked up twelve stones from the middle of the Jordan

This refers to the twelve men picking up stones from the middle of the Jordan River bed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Then Joshua set up twelve stones in the middle of the Jordan

These were twelve additional stones, not the stones that the twelve men carried from the river bed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The memorial is there to this day

This means the memorial was there to the day that the author was writing this book.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md)]]

### Joshua 04:10

#### the Jordan

This refers to the Jordan River.

#### the people

This refers to the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### crossed over

This means to go to the opposite bank of the river. AT: "traveled from one side to the opposite side" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### before the people

This refers to being in front of the people or in the sight of all the people. Everyone saw the ark being carried by the priests. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Joshua 04:12

#### The tribe of Reuben, the tribe of Gad, and the half tribe of Manasseh passed before the people of Israel formed up as an army

These were the soldiers of the 3 tribes that were fulfilling their obligation to lead the Israelites into battle for settling on the East side of the Jordan River. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### just as they

The word "they" refers to the people of Israel.

#### they honored Moses

This refers to not just honor but submission to his commands and to treat him as the commander of their army as they had followed Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Joshua 04:15

#### General Information:

Yahweh tells Joshua to have the priests exit the Jordan River.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]

### Joshua 04:17

#### General Information:

The Author was making it clear that parting the Jordan River was no different than parting the Red Sea for the previous generation.

#### waters of the Jordan returned to their place and overflowed its banks

The Jordan River was overflowing its banks and flooding the area before and after Israel passed through on dry land.

#### four days

"4 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Joshua 04:19

#### came up out of the Jordan

This refers to when Israel crossed the Jordan River on dry ground.

#### on the tenth day of the first month

This is the first month of the Hebrew calendar. The tenth day is near the end of March on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### The twelve stones that they took out of the Jordan

Each tribe was to take one stone from the Jordan River so Joshua could build a memorial of the crossing event. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Joshua 04:22

#### General Information:

Joshua continues to remind the people the purpose of the pile of stones.

#### Tell your children

It was for Israel to teach their children of God's miracles so that they would honor Yahweh forever.

#### the hand of Yahweh is mighty

This refers to the power of Yahweh being strong. AT: "Yahweh is mighty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Joshua 04:intro

#### Joshua 04 General Notes ####

####### Special concepts in this chapter #######

######## God's war ########
The conquering of the Promised Land was a special war. It was God's war against the people of Canaan and Joshua recognized that they would only be victorious through Yahweh's power. This is why their first act after crossing the Jordan River was to build an altar. This war was a witness to Yahweh's power. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

##### Links: #####

* __[Joshua 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Joshua 05

### Joshua 05:01

#### their hearts melted ... there was no longer any spirit in them

These two phrases mean basically the same thing and emphasize the intensity of their fear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### their hearts melted

Here "hearts" refers to their courage. They were so afraid that it was as if their courage melted away like wax in a fire. AT: "they lost all their courage" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### there was no longer any spirit in them

Here "spirit" refers to their will to fight. AT: "they no longer had any will to fight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Joshua 05:02

#### Joshua made himself flint knives ... he circumcised all the males

There were over 600,000 males, so it is understood that while Joshua was in charge of this task, many other people helped him. If this would confuse your readers, you may want to make this explicit. AT: "Joshua and the Israelites made themselves flint knives ... they circumcised all the males" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Gibeath Haaraloth

This is a place name which commemorates Israel rededicating themselves to Yahweh. It means "the hill of the foreskins." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 05:04

#### General Information:

The reason all the males of Israel had to be circumcised is explained.

#### the men of war

the men who were old enough to be soldiers

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Joshua 05:06

#### obey the voice of Yahweh

Here "voice" refers to the things that Yahweh spoke. AT: "obey the things that Yahweh commanded them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a land flowing with milk and honey

God spoke of the land being good for animals and plants as if the milk and honey from those animals and plants were flowing through the land. AT: "a land that is excellent for raising livestock and growing crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]

### Joshua 05:08

#### This day I have rolled away the disgrace of Egypt from you

Their disgrace is spoken of as if it were a large stone that blocked their path. Here "rolled away" means "removed." AT: "This day I have removed the disgrace of Egypt from you" or "You were disgraced when you were slaves in Egypt. But, today I have caused you to no longer be disgraced" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]

### Joshua 05:10

#### the fourteenth day of the month

This is near the end of March on Western calendars. AT: "the fourteenth day of the first month" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]

### Joshua 05:12

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Joshua 05:13

#### he lifted up his eyes and looked, and behold, a man was standing

Here looking up is spoken of as if Joshua literally lifted his eyes in his hands. AT: "he looked up and saw that a man was standing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### behold

The word "behold" alerts us to pay special attention to new information. Your language may have a way of doing this.

#### he had drawn his sword and it was in his hand

Here the words "he" and "his" refer to the man who was standing in front of Joshua.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Joshua 05:14

#### He said

The word "he" refers to the man Joshua saw.

#### Neither

This is the beginning of the man's answer to Joshua's question, "Are you for us or for our enemies?" This short answer could be clarified. AT: "I am neither for you nor for your enemies"

#### Joshua lay facedown on the ground to worship

This was an act of worship. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### Take off your sandals from your feet

This was an act of reverence. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Joshua 05:intro

#### Joshua 05 General Notes ####

####### Special concepts in this chapter #######

######## Circumcision ########

It would have been very unusual to be circumcised in a time of war. When men are circumcised they are unable to move without pain or to defend themselves in battle for several days. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]])

######## Manna ########

Yahweh stops providing manna in this chapter and will no longer provide them with their daily allotment of food. This does not mean Yahweh's care and provision will stop.

##### Links: #####

* __[Joshua 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Joshua 06

### Joshua 06:01

#### Now

This word is used here to mark a break in the main story line. Here the narrator tells us why the gates of Jericho are closed and locked up.

#### I have delivered Jericho into your hand, its king, and its trained soldiers

Yahweh is telling Joshua that he will certainly do this by saying that he has already done it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### into your hand

This means "into your control" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Joshua 06:03

#### Connecting Statement:

God continues telling Joshua what the people must do.

#### You must do this for six days

"You must do this once each day for six days"

#### Seven priests must carry seven trumpets of rams' horns before the ark

The seven priests are to march in front of other priests who are carrying the ark and marching around the city.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]

### Joshua 06:05

#### Connecting Statement:

God continues telling Joshua what the people must do.

#### they must sound a long blast with the ram's horn ... of the trumpet

The word "they" refers to the seven priests. The "ram's horn" and "trumpet" refer to the trumpets of rams' horns that the priests were blowing in [Joshua 6:4](./03.md).

#### the wall of the city

"the outer wall of the city" or "the wall surrounding the city"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Joshua 06:06

#### Nun

This is Joshua's father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Take up the ark of the covenant

"Pick up the ark of the covenant"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 06:08

#### before Yahweh

Possible meanings are 1) "in obedience to Yahweh" or 2) "in front of Yahweh's ark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they gave a blast on the trumpets

"they sounded the trumpets loudly" or "the priests blew into the ram's horn trumpets"

#### The ark of the covenant of Yahweh followed after them

It can be stated clearly that there were people carrying the ark. AT: "The priests who were carrying the ark of the covenant of Yahweh followed after them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]

### Joshua 06:10

#### No sound must leave your mouths

Sound leaving someone's mouth refers to that person's speaking or shouting. AT: "Do not yell or speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But Joshua commanded the people

Joshua had commanded the people before they started walking around the city. AT: "Joshua had commanded the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]

### Joshua 06:12

#### seven priests ... seven trumpets

"7 priests ... 7 trumpets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### gave blasts on the trumpets

This means that they blew into their trumpets, causing them to make loud noises, multiple times. AT: "continually sounded the trumpets loudly" or "blew into the ram's horn trumpets continually"

#### the second day

the next day (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### They did this

Israel marched around Jericho once every day.

#### six days

"6 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Joshua 06:15

#### the people

This refers to the people of Israel.

#### gave a blast with the trumpets

"sounded the trumpets loudly" or "blew into the ram's horn trumpets"

#### Yahweh has given you

Joshua is saying that Yahweh will definitely give them the city by saying that he has already given it to them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### given you

The word "you" refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 06:17

#### Connecting Statement:

Joshua continues speaking to the people of Israel.

#### The city and all that is in it will be set apart to Yahweh for destruction

This can be stated with an active form. AT: "You must set apart to Yahweh the city and all that is in it for destruction" or "You must set apart to Yahweh the city and all that is in it by destroying it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### be on guard about taking the things

Being careful is spoken of as if they are to guard themselves. "Be careful that you do not take the things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will bring trouble on it

Doing something that makes bad things to happen to the city is spoken of as bringing trouble on it. AT: "you will cause bad things to happen to it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the treasury of Yahweh

a collection of things set apart for the worship of Yahweh

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]

### Joshua 06:20

#### the people gave a great shout

"the people of Israel shouted"

#### gave blasts with the trumpets

"sounded the trumpets loudly" or "blew into the ram's horn trumpets"

#### They completely destroyed all that was in the city by the edge of the sword

The "edge of the sword" represents the swords and other weapons that soldiers used in battle. AT: "They completely destroyed all that was in the city with their swords" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Joshua 06:22

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Joshua 06:23

#### They burned the city

The word "they" refers to the Israelite soldiers. It does not refer only to the two young men who brought Rahab and her family out of the city.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 06:25

#### She lives in Israel

The word "She" refers to Rahab and represents her descendants. AT: "Her descendants live in Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to this day

"now" or "even today." Rahab's descendants are still living in Israel as the original writer writes this story.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Joshua 06:26

#### Cursed is the man in Yahweh's sight who rebuilds

Being cursed in Yahweh's sight represents being cursed by Yahweh. AT: "May Yahweh curse the man who rebuilds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### At the cost of his firstborn son, he will lay the foundation

The consequence of a man laying a new foundation for Jericho is that his firstborn son would die. This is spoken of as if it were a cost that the man would pay. AT: "If he lays the foundation, he will lose his firstborn son" or "If he lays the foundation, his firstborn son will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### at the cost of his youngest son, he will set up its gates

The consequence of a man setting up new gates for Jericho is that his youngest son would die. This is spoken of as if it were a cost that the man would pay. AT: "If he sets up its gates, he will lose his youngest son" or "If he sets up it gates, his youngest son will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his fame spread throughout the land

This refers to Joshua's fame, not Yahweh's. Becoming known among the people throughout the land is spoken of as if his fame spread. AT: "Joshua became famous throughout the land" or "people throughout the land learned about Joshua" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Joshua 06:intro

#### Joshua 06 General Notes ####

####### Special concepts in this chapter #######

######## Yahweh conquers ########

It was God, not the army, who gave them victory. It is said, "Shout! For Yahweh has given you the city." The circumstances of Israel's victory in the battle for Jericho were very unusual. It was never common to march around a city or to shout in order to win a military battle. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Joshua 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Joshua 07

### Joshua 07:01

#### the things that were set apart for destruction

"the things that God had said they must set apart to him by destroying them"

#### Achan ... Karmi ... Zabdi ... Zerah

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Yahweh's anger burned

"anger" and "burned" indicates intensity, not that fire is present. AT: "Yahweh's anger burned like a fire" or "Yahweh was very angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 07:02

#### all the people

This refers to the army of Israel.

#### they are few in number

The word "they" refers to the people of Ai.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]

### Joshua 07:04

#### three thousand men went up from the army

These men were part of the army. AT: "three thousand men belonging to the army went up"

#### three thousand men ... thirty-six men

"3,000 men ... 36 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### The hearts of the people melted and became like water

These phrases "melted" and "became like water" share similar meanings and are combined to emphasize that the people were extremely afraid. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### The hearts of the people melted

Here the people are represented by their "hearts" to emphasize their emotions. AT: "The people were very afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### The hearts of the people

The phrase "the people" refers to the Israelite soldiers.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Joshua 07:06

#### tore his garments ... put dust on their heads and lay facedown on the ground in front of the ark of Yahweh

They did these things to show God how sad and distressed they were. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### To give us into the hands of the Amorites to destroy us?

Joshua was asking if this is the reason God had brought them across the Jordan. AT: "Did you do it in order to give us into the hands of the Amorites to destroy us?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### To give us into the hands of the Amorites to destroy us?

The hands of the Amorites represents their control and power. Giving the Israelites into their hands to destroy them represents allowing the Amorites to have control of the Israelites and destroy them. AT: "To allow the Amorites to destroy us? (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### If only we made a different decision

The words "If only" show that this is a wish for something that had not happened. AT: "I wish we had made a different decision"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]

### Joshua 07:08

#### General Information:

Joshua expresses frustration to God.

#### what can I say, after Israel has turned their backs before their enemies?

Joshua said this to show how upset he was that he did not even know what to say. AT: "I do not know what to say. Israel has turned their backs before their enemies!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Israel has turned their backs before their enemies

Doing this represents running away from their enemies. AT: "Israel has run away from their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They will surround us and make the people of the earth forget our name

Making people forget the name of the Israelites represents making them forget the Israelites. In this case they would do it by killing the Israelites. AT: "They will surround us and kill us, and the people of the earth will forget about us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for your great name

The phrase "your great name" here represents God's reputation and power. AT: "And so what will you do so that people will know that you are great" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### What will you do for your great name?

Joshua uses this question to warn God that if the Israelites are destroyed, then the other people will think that God is not great. AT: "Then there will be nothing you can do for your great name." or "Then people will not know that you are great." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Joshua 07:10

#### General Information:

Yahweh tells Joshua why Israel is cursed.

#### Why are you lying there on your face?

God used this question to rebuke Joshua for lying there on his face. AT: "Stop lying there with your face in the dirt!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the things that were set apart

These are the things "marked for destruction" from [Joshua 6:18-19](../06/17.md). AT: "the cursed things" or "those things which God has cursed"

#### They have stolen and then also hidden their sin

Hiding their sin represents trying to keep others from knowing that they have sinned. AT: "They have stolen those things, and then they tried to keep people from knowing that they sinned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### cannot stand before their enemies

Standing before their enemies represents fighting successfully against their enemies. AT: "cannot fight successfully against their enemies" or "cannot defeat their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They turned their backs from their enemies

Doing this represents running away from their enemies. AT: "They ran away from their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not be with you any more

Being with Israel represents helping Israel. AT: "I will not help you any more" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Joshua 07:13

#### Connecting Statement:

Yahweh continues speaking to Joshua and tells him what to tell the people.

#### the people

This refers to the people of Israel.

#### You cannot stand against your enemies

Standing before their enemies represents fighting successfully against them. AT: "You cannot fight successfully against your enemies" or "You cannot defeat your enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 07:14

#### Connecting Statement:

Yahweh continues telling Joshua what he must tell the people.

#### you must present yourselves by your tribes

There were twelve tribes that made up the people of Israel. The phrase "by your tribes" means "each tribe." AT: "each of your tribes must present themselves to Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The tribe that Yahweh selects will come near by their clans

The tribe was made up of multiple clans. AT: "From the tribe that Yahweh selects, each clan will come near" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The tribe that Yahweh selects

The leaders of Israel would toss lots, and by doing this, they would learn which tribe Yahweh had selected. This can be stated clearly. AT: "The tribe that Yahweh selects by lot" or "The tribe that Yahweh selects when we toss lots"

#### The clan that Yahweh selects must come near by each household

The clan was made up of multiple households. AT: "From the clan that Yahweh selects, each household must come near" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The household that Yahweh selects must come near one by one

The household was made up of multiple people. AT: "From the household that Yahweh selects, each person must come near" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the one who is selected

This can be stated with an active form. AT: "the one whom Yahweh selects" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he has broken the covenant of Yahweh

Breaking the covenant represents disobeying it. AT: "he has disobeyed the covenant of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 07:16

#### General Information:

Joshua follows Yahweh's command to bring Israel before Yahweh.

#### brought Israel near, tribe by tribe

The phrase "tribe by tribe" means each tribe. AT: "brought each tribe of Israel near" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the tribe of Judah was selected

This can be stated in active form. AT: "Yahweh selected the tribe of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He brought near the clan of the Zerahites person by person

The phrase "person by person" is an idiom meaning each person. The persons in this sentence were the leaders of their households. AT: "He brought near each person of the clan of the Zerahites" or "From the clan of the Zerahites, he brought near each man who was the leader of his household" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the clan of the Zerahites

The clan was named after the man named Zerah.

#### Zabdi ... Achan ... Karmi ... Zerah

These are men's names. Translate them as you did in [Joshua 7:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]

### Joshua 07:19

#### give your confession to him

The abstract noun "confession" can be expressed with the verb "confess." AT: "confess to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Do not hide it from me

Hiding information represents trying to keep someone from knowing it. AT: "Do not try to prevent me from knowing what you have done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### two hundred shekels

This is over two kilograms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### fifty shekels

This is over 500 grams. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### They are hidden in the ground

This can be stated in active form. AT: "I hid them in the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]

### Joshua 07:22

#### they looked

"the men Joshua had sent looked"

#### poured them out

Use the word in your language for pouring many small solid things out of a large bag onto the ground.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 07:24

#### the Valley of Achor

The name means "Valley of Trouble," but it is best to translate Achor the way it sounds. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]

### Joshua 07:25

#### Why have you troubled us?

Joshua uses this question to rebuke Achan. AT: "You have troubled us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Then they stoned the rest with stones and burned them with fire.

Possible meanings are 1) the Israelites burned Achan's family to death and then covered them with stones or 2) the Israelites stoned Achan's family to death and then burned the dead bodies or 3) that Achan and his possessions were stoned and then burned.

#### Yahweh turned away his burning anger

Turning away his anger represents stopping being angry. Burning anger represents strong anger. AT: "Yahweh stopped being angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### until this present day

It was still called the valley of Achor at the time the author wrote this. AT: "even today" or "even now"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]

### Joshua 07:intro

#### Joshua 07 General Notes ####

####### Special concepts in this chapter #######

######## Sin brought defeat ########

It was great sin to take what was to be destroyed. Because of their sin, Yahweh withheld victory from the Israelites. Sin resulted in defeat in battle. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Joshua 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Joshua 08

### Joshua 08:01

#### Do not fear; do not be discouraged

These two phrases mean basically the same thing. Yahweh combines them to emphasize that there is no reason to be afraid. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### I have given into your hand the king of Ai ... and his land

Giving them into Israel's hand represents giving Israel victory and control over them. AT: "I have given you victory over the king of Ai and his people, and I have given you control over his city and his land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I have given

God speaks of what he promises to do as though he had already done it, because he will certainly do it. AT: "I will certainly give" or "I am giving" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### her king

The word "her" refers to the city of Ai. Cities were often spoken of as if they were women. AT: "its king" or "their king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Joshua 08:03

#### the men of war

"the army of Israel"

#### thirty thousand men

"30,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Joshua 08:05

#### General Information:

Joshua continues to explain the battle plan to his soldiers.

#### will give it into your hand

Here "hand" symbolizes the control and power the people have over their enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joshua 08:08

#### General Information:

Joshua finishes explaining the battle plan to his soldiers.

#### Joshua sent them out

This phrase refers to Joshua sending the thirty thousand men who had been selected to ambush Ai to where they would set the ambush.

#### the place of ambush

"where they would hide until it was time to attack"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]

### Joshua 08:10

#### five thousand men

"5,000 men." This group seems to be a portion of the "thirty thousand men" ([Joshua 8:9](./08.md)). This smaller group remained in the ambush while the other 25,000 men attacked the city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]

### Joshua 08:13

#### General Information:

The Israelites prepare to fight the people of Ai.

#### the main army

This refers to the largest group of fighting men, those not in the ambush group.

#### rear guard

those who were "set in ambush on the west side of the city" (See: [Joshua 8:12](./10.md))

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 08:15

#### let themselves be defeated before them

"let themselves be defeated before the people of Ai." The phrase "before them" represents what the people of Ai would see and think. AT: "let the people of Ai think that the Israelites were defeated" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### let themselves be defeated before them

The phrase "be defeated" can be stated in active form. AT: "let the people of Ai think that they had defeated the Israelites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### before them ... they went after ... they were drawn away

The words "them" and "they" here refer to the army of Ai.

#### they fled ... go after them

The words "they" and "them" here refer to the army of Isreal.

#### All the people who were in the city were called together

This can be stated in active form. AT: "The city leaders called all the people in the city together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### All the people who were in the city

The writer speaks in a general way about all the people, but "all the people" refers only to those who could fight. AT: "all the people in the city who could help chase the army of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### left it open

"left the city gates open"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]

### Joshua 08:18

#### I will give Ai into your hand

Giving Ai into Israel's hand represents giving Israel victory and control over Ai. AT: "I will give you victory over Ai" or "I will cause you to capture Ai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]

### Joshua 08:20

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 08:22

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]

### Joshua 08:24

#### when Israel had finished killing all the inhabitants ... when all of them ... had fallen by the edge of the sword

The writer uses both of these sentences, which mean almost the same thing, to strongly say that the Israelites had obeyed God's command to kill everyone in Ai. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### had fallen by the edge of the sword

Here "fallen" is a euphemism for dying. Also, "the edge of the sword" represents whole swords, and swords represent either battle or the army of Israel. AT: "had died in battle" or "had died when the army of Israel attacked them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### twelve thousand

"12,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]

### Joshua 08:27

#### an abandoned place

It is a place where people once lived, but now, no one lives there.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Joshua 08:29

#### to this day

"today" or "even now"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hang.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hang.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Joshua 08:30

#### Mount Ebal

a mountain in Canaan (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md)]]

### Joshua 08:33

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Joshua 08:34

#### There was not one word from all that Moses commanded that Joshua did not read

This can be expressed positively. AT: "Joshua read every word of all that Moses commanded" or "Joshua read the entire law of Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### Israel

This refers to the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]

### Joshua 08:intro

#### Joshua 08 General Notes ####

####### Structure and formatting #######

####### Special concepts in this chapter #######

######## Sin brought defeat ########
It was great sin to take what was to be destroyed. Because of their sin, Yahweh withheld victory from the Israelites. Sin resulted in defeat in battle. Because they repented, Yahweh brought victory to Israel in Ai. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]])

######## Built an altar ########
Altars were commonly built in the Ancient Near East to commemorate important events. Several altars were built in the Book of Joshua.

##### Links: #####

* __[Joshua 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Joshua 09

### Joshua 09:01

#### the Jordan

a shortened name for the Jordan River (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### under one command

Here "command" represents the one who commanded them. Being under him represents obeying his commands. AT: "obeying the commands of one leader" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 09:03

#### cunning plan

a crafty scheme intended to trick Joshua and the Israelites

#### dry and moldy

"dry and filled with fungus" or "stale and ruined"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Joshua 09:06

#### men of Israel

This refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the Hivites

This is another name for the Gibeonites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Perhaps you live near us. How can we make a covenant with you?

Joshua is emphasizing that the people of Israel have to follow the command of Yahweh above all else. AT: "If you do live near us, we cannot make a covenant with you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Joshua 09:09

#### the Jordan

This is a shortened name for the Jordan River. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Sihon

This is the name of the defeated Amorite king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Heshbon

This is the name of the royal city of the nation of Moab. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Og

This is the name of the defeated king of Bashan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ashtaroth

This is the name of a city known for worshiping the goddess of the same name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]

### Joshua 09:11

#### in your hand

This phrase means "take with you." Here the word "hand" represents the possession by the Gibeonites of the provisions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### meet them and say to them

The word "them" refers to the people of Israel.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md)]]

### Joshua 09:14

#### Joshua made peace with them and made a covenant with them, to let them live. The leaders of the people also made a vow to them.

These two sentences are saying that the same thing occurred. Joshua, the leader of the nation of Israel, promised not to kill the Gibeonites. The leaders of the nation of Israel, likewise, made the same covenant. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the people

Here this refers to the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]

### Joshua 09:16

#### third day

This refers to number three in order. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Kephirah

This is one of the cities of the Gibeonites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Beeroth

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Kiriath Jearim

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]

### Joshua 09:18

#### the people

Here this phrase refers to the nation of Israel.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joshua 09:20

#### the Gibeonites became cutters of wood and drawers of water

"the Gibeonites became woodcutters and water carriers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 09:22

#### house of my God

Here this phrase refers to the dwelling place of Yahweh, the Tabernacle. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Joshua 09:24

#### Whatever seems good and right

The words "good" and "right" mean basically the same thing. AT: "Whatever seems fair and just" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Joshua 09:26

#### for them

The word "them" here refers to the Gibeonites.

#### to this day

"even up to now." This means that the people had continued to do these things even up to the day that the writer was living.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 09:intro

#### Joshua 09 General Notes ####

####### Special concepts in this chapter #######

######## Israel's mistake ########

Israel was deceived because "they did not consult with Yahweh for guidance." Instead of consulting Yahweh, they attempted to achieve victory under their own power.  This was sinful. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Joshua 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Joshua 10

### Joshua 10:01

#### Now

This word is used here to mark a break in the main story line. Here the writer tells about a new person in the story, Adoni-Zedek.

#### Adoni-Zedek

This is the name of a man who is an important king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]

### Joshua 10:03

#### Jarmuth ... Lachish ... Eglon

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hoham ... Piram ... Japhia ... Debir

These are the names of kings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Come up to me

"Travel to where I am." Jerusalem was higher in elevation than other cities in Canaan.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 10:05

#### five kings

"5 kings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Jarmuth ... Lachish ... Eglon

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They set up their positions against Gibeon

This means they set up their camp around their city. This was a way of weakening those in the city. It prevented people from escaping the city, and it prevented others from bringing food and water to them in the city.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]

### Joshua 10:06

#### They said

The word "They" here refers to Gibeonites.

#### Do not withdraw your hands from your servants

This humble request is stated with two negatives to emphasize the need for a positive action. AT: "Please come and use your strength to protect us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### your hands

The word "hands" here refers to the people of Israel's strength. AT: "your strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]

### Joshua 10:08

#### I have given them into your hand

Here "hand" represents the people of Israel's strength and their ability to defeat their enemy. The word "them" refers to the attacking army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I have given them

Here the word "them" refers to the attacking armies.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]

### Joshua 10:09

#### Joshua came

The entire army of Israel is referred to here by the name of their commander, Joshua. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Yahweh confused the enemy before Israel

Here "Israel" refers to the entire army of Israel.

#### Beth Horon ... Azekah ... Makkedah

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]

### Joshua 10:11

#### Beth Horon ... Azekah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### threw large stones down from heaven

"threw large hailstones from the sky"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Joshua 10:12

#### Sun, be still at Gibeon, and moon, in the Valley of Aijalon

Joshua is praying that Yahweh would make the progression of time stop on this day. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Sun ... moon

Joshua commands the sun and moon as if these were people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Valley of Aijalon

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]

### Joshua 10:13

#### the nation

This refers to the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Is this not written in the Book of Jashar?

The writer uses this question as background information to remind the reader that the incident is well-documented. AT: "This is written in The Book of Jashar." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 10:15

#### Makkedah

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### It was told to Joshua

Messengers came and told Joshua. AT: "Someone told Joshua" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Joshua 10:18

#### into your hand

The phrase "your hand" here means "your control." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 10:20

#### Makkedah

Translate the same way as you did in [Joshua 10:10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### No one dared to say one word against

"No one dared to say anything against" or "No one dared to complain or protest against"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]

### Joshua 10:22

#### Open the mouth of the cave

Here "mouth" is an idiom that means "entrance." AT: "Open the entrance of the cave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Jarmuth ... Lachish ... Eglon

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]

### Joshua 10:24

#### every man of Israel

Here the men of Israel represent only those who were soldiers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 10:26

#### to this very day

"until the author wrote this story"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Joshua 10:28

#### Makkedah

This is the name of a city. See how you translated it in [Joshua 10:10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He completely destroyed everyone in it. He left no survivor in it

The second sentence summarizes the first sentence to emphasize that Joshua left no person or animal alive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Joshua 10:29

#### Libnah

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### gave it into the hand of Israel

Here "hand" means "control of." AT: "gave control of it to Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Joshua 10:31

#### Libnah ... Lachish

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### into the hand of Israel

Here their "hand" represents their control. AT: "Yahweh gave Lachish into the control of the nation of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]

### Joshua 10:33

#### Horam

This is the name of a man who is an important king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Gezer ... Lachish

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]

### Joshua 10:34

#### Lachish ... Eglon

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### struck it with the edge of the sword ... completely destroyed everyone in it

These two phrases have similar meanings. Together they show the completeness of the destruction of Eglon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Joshua 10:36

#### Eglon

This is the name of a city. See how you translated this in [Joshua 10:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They captured it and struck it with the edge of the sword

The sword represents the army of Israel and striking expresses the idea of slaughter and destruction. AT: "They captured and killed and destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]

### Joshua 10:38

#### Debir ... Libnah

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They struck them with the edge of the sword

The sword represents the army of Israel and striking expresses the idea of slaughter and destruction. AT: "They killed and destroyed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]

### Joshua 10:40

#### Of all their kings he left not one survivor. He completely destroyed every living thing

These two phrases share similar meanings and emphasize the complete destruction that the people of Israel accomplished at Yahweh's command. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Joshua struck them with the sword

The sword represents the army of Israel and striking expresses the idea of slaughter and destruction. AT: "Joshua killed and destroyed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]

### Joshua 10:42

#### Joshua captured all these kings and their land

This refers to the kings and lands that were listed beginning in [Joshua 10:28](./28.md).

#### Joshua captured

Here Joshua represents his whole army. AT: "Joshua and his soldiers captured" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### at one time

This does not mean in one day. It means during one military campaign, which may have lasted many days or weeks.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]

### Joshua 10:intro

#### Joshua 10 General Notes ####

####### Structure and formatting #######

The ULB indents the lines in 10:12-13 because they are a poem.

####### Special concepts in this chapter #######

######## "For Yahweh was waging war on behalf of Israel" ########
Israel's conquest of the Promised Land was Yahweh's war on the ungodly Canaanites more than Israel's war. This type of war was different from other wars and God gave Israel special instructions. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md)]])

####### Important figures of speech in this chapter #######

######## Idiom ########
 
The people of Gibeon used an idiom when they called for help from Israel: "Do not withdraw your hands," meaning "do not stop protecting." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

##### Links: #####

* __[Joshua 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Joshua 11

### Joshua 11:01

#### Jabin ... Jobab

These are names of kings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hazor ... Madon ... Shimron ... Akshaph ... Kinnereth ... Naphoth Dor ... Mount Hermon

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]

### Joshua 11:04

#### General Information:

All the Canaanite kings attack Joshua and the nation of Israel.

#### a great number of soldiers, in number like the sand on the seashore

No one can count the grains of sand on the seashore. This exaggeration emphasizes the very large number of soldiers that these kings assembled. AT: "such a great number of soldiers that there appeared to be as many of them as there are grains of sand on the seashore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Merom

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 11:06

#### I am giving them all to Israel as dead men

Yahweh enabling Israel to conquer the enemy army and kill all of the soldiers is spoken of as if Yahweh killed the soldiers and then gave them to Israel. AT: "I will enable Israel to kill all of them in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### hamstring their horses

"cripple their horses by cutting their legs." This is a practice where the tendons in the backs of the legs are cut so that the horses cannot walk.

#### Merom

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]

### Joshua 11:08

#### Yahweh gave the enemy into the hand of Israel

Here the word "hand" represents power. Yahweh enabling the army of Israel to conquer their enemy is spoken of as if Yahweh had put the enemy army into Israel's hand. AT: "Yahweh enabled Israel to conquer the enemy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### struck them ... struck them

"attacked them ... attacked them"

#### Misrephoth Maim

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### hamstrung

This is a practice where the tendons in the backs of the legs are cut so that the horses cannot run. See how you translated this word in [Joshua 11:6](./06.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]

### Joshua 11:10

#### He struck its king with the sword

"Joshua killed the king of Hazor with his sword"

#### Hazor had been head of all these kingdoms

Hazor being the most important city is spoken of as Hazor being the head of the other kingdoms. AT: Hazor had been the most important of all these kingdoms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They struck with the sword every living creature that was there ... so there was not any living creature left alive

These two phrases share similar meanings and emphasize complete destruction. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### he set them apart to be destroyed

The word "he" refers to Joshua and represents himself and his army. Completely destroying every living thing in the city is spoken of as if those living things were dedicated for destruction. AT: "the army completely destroyed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]

### Joshua 11:12

#### struck them with the edge of the sword

"killed them"

#### cities built on mounds

"cities built on small hills"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 11:14

#### for themselves

This phrase refers to the army of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### They killed every human being with the edge of the sword until all were dead. They left alive no creature that breathed.

These two phrases share similar meanings and emphasize complete destruction. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### He left nothing undone of all that Yahweh commanded Moses to do

This negative phrase emphasizes that Joshua did everything that Yahweh commanded. AT: "Joshua did everything that Yahweh commanded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Joshua 11:16

#### Mount Halak ... Baal Gad

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mounthermon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mounthermon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Joshua 11:18

#### it was Yahweh who hardened their hearts

Yahweh causing the people of the cities to be stubborn is spoken of as if Yahweh had hardened their hearts. AT: "it was Yahweh who caused them to act stubbornly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Joshua 11:21

#### Anakim

These are the descendants of Anak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Debir ... Anab

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]

### Joshua 11:23

#### Joshua gave it as an inheritance to Israel

Joshua giving the land to the Israelites is spoken of as if he had given the Israelites an inheritance as a permanent possession. AT: "Joshua gave the land to the Israelites as a permanent possession" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the land had rest from the wars

The people no longer fighting wars is spoken of as if the land were a person who rested from war. AT: "the people no longer fought wars in the land" or "there was peace in the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Joshua 11:intro

#### Joshua 11 General Notes ####

####### Special concepts in this chapter #######

######## Yahweh overcomes the united forces of the northern kingdoms ########

Yahweh said to Joshua, "Do not be afraid in their presence, because tomorrow at this time I am giving them all to Israel as dead men." Even when the kingdoms of Canaan joined forces, they were not able to overcome the power of Yahweh. 

####### Other possible translation difficulties in this chapter #######
######## "Yahweh gave the enemy into the hand of Israel" ########
This phrase may present difficulties in translation. The translator should ensure that Yahweh receives credit for Israel's victory. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

##### Links: #####

* __[Joshua 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Joshua 12

### Joshua 12:01

#### Now

This word is used here to mark a break in the main story line. Here the writer begins to provide background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### these are the kings

This refers to the list of kings that continues through verse 24.

#### Arabah ... Aroer

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Sihon ... Heshbon

See how you translated these words in [Joshua 9:10](../09/09.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mounthermon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mounthermon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]

### Joshua 12:03

#### Sea of Kinnereth

This is a place. See how you translated this in [Joshua 11:2](../11/01.md).

#### Beth Jeshimoth ... Mount Pisgah ... Ashtaroth ... Edrei ... Salekah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Og, king of Bashan

See how you translated this man's name in [Joshua 9:10](../09/09.md).

#### the Rephaim ... Maacathites

These are the names of people groups. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Joshua 12:06

#### Reubenites

These are the descendants of Reuben.

#### Gadites

These are the descendants of Gad.

#### half tribe of Manasseh

They are called a half tribe because the other half of the tribe received an inheritance in the land of Canaan.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Joshua 12:07

#### Baal Gad ... Mount Halak ... Arabah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]

### Joshua 12:09

#### Enaim ... Jarmuth ... Lachish ... Eglon ... Gezer

These are the names of cities. Translate "Jarmuth," "Lachish," and "Eglon" in the same way you did in [Joshua 10:3](../10/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Joshua 12:13

#### Debir ... Geder ... Hormah ... Arad ... Libnah ... Adullam ... Makkedah

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]

### Joshua 12:17

#### Tappuah ... Hepher ... Aphek ... Lasharon ... Madon ... Hazor ... Shimron Meron ... Akshaph

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Joshua 12:21

#### Taanach ... Megiddo ... Kedesh ... Jokneam ... Dor ... Goyim ... Tirzah

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### thirty-one in all

"31 in all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]

### Joshua 12:intro

#### Joshua 12 General Notes ####

####### Structure and formatting #######

The ULB indents the lines in 12:2-5 because they are part of a long list.

##### Links: #####

* __[Joshua 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Joshua 13

### Joshua 13:01

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joshua 13:02

#### This is the land that still remains

You may clarify that this is the land that Israel still needs to capture. AT: "This is the land that still remains for Israel to capture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Shihor

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### which is considered property of the Canaanites

This can be stated in active form. AT: "which the Canaanites now consider their property" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Avvites

This is the name of a people group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md)]]

### Joshua 13:04

#### Arah ... Aphek ... Baal Gad ... Mount Hermon

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Gebalites

This is the name of a people group who lived in Geba. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamath.md)]]

### Joshua 13:06

#### Misrephoth Maim

this is the name of a place (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### land ... as an inheritance

The land that Israel will claim is spoken of as if it were an inheritance that they will receive as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]

### Joshua 13:08

#### Aroer ... Medeba ... Dibon

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### gorge

a place where the river is far below the land on the sides

#### plateau

flat land high above rivers

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 13:10

#### Heshbon ... Salekah ... Ashtaroth ... Edrei

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the region of the Geshurites and Maacathites

"the land where the Geshurites and Maacathites lived"

#### Maacathites ... Rephaim

These are the names of people groups. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Moses struck them

Here "Moses" represents himself and the Israelite army that Moses led. AT: "Moses and the Israelites attacked them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Joshua 13:13

#### the Geshurites or the Maacathites

These are the names of people groups. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Geshur and Maacath live among Israel

"Geshur" and "Maacath" are either the names of the ancestors of "the Geshurites" and "the Maacathites" or are the names of the cities in which they lived. AT: "those people live among Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to this day

This refers to the period of time in which the author wrote this book.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/geshur.md)]]

### Joshua 13:14

#### Moses gave no inheritance

The land that Moses assigned to the tribes of Israel is spoken of as if it were an inheritance that they received as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The offerings of Yahweh ... are their inheritance

The writer speaks of the great honor that the Levites had by serving Yahweh as priests as if the offerings were something that they would inherit. AT: "The offerings of Yahweh ... are what they will have for their provision" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### offerings of Yahweh

"offerings that the people were to bring to Yahweh"

#### made by fire

This can be stated in active form. AT: "that the priests burned with fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 13:15

#### Aroer ... Medeba

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### gorge ... plateau

See how you translated these words in [Joshua 13:9](./08.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 13:17

#### Heshbon ... Dibon ... Bamoth Baal ... Beth Baal Meon ... Jahaz ... Kedemoth ... Mephaath ... Kiriathaim ... Sibmah ... Zereth Shahar

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]

### Joshua 13:20

#### Beth Peor ... Pisgah ... Beth Jeshimoth ... Heshbon

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Sihon ... Evi ... Rekem ... Zur ... Hur ... Reba

These are the names of people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### together with the leaders of Midian

"as he had defeated the leaders of Midian"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Joshua 13:22

#### this is their boundary

The Jordan River was the western border of the land that the tribe of Reuben received.

#### This was the inheritance of the tribe of Reuben

The land that Moses assigned to the tribe of Reuben is spoken of as if it were an inheritance that the tribe of Reuben received as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### given to each of their clans

This can be stated in active form. AT: "that Moses gave to each of their clans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 13:24

#### Jazer ... Aroer ... Heshbon ... Ramath Mizpah ... Betonim ... Mahanaim ... Debir

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rabbah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rabbah.md)]]

### Joshua 13:27

#### Beth Haram ... Beth Nimrah ... Zaphon ... Heshbon

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This is the inheritance of the tribe of Gad

The land that Moses assigned to the tribe of Gad is spoken of as if it were an inheritance that the tribe of Gad received as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Joshua 13:29

#### Moses gave an inheritance to the half tribe of Manasseh

The land that Moses assigned to the half tribe of Manasseh is spoken of as if it were an inheritance that he gave to them as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### half tribe of Manasseh

Only half of the tribe received this land because the other half received land on the other side of the Jordan River.

#### It was assigned

This can be stated in active form. AT: "Moses assigned it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Mahanaim ... Jair ... Ashtaroth ... Edrei

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### These were assigned

This can be stated in active form. AT: "Moses assigned these" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Machir

This is a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]

### Joshua 13:32

#### This is the inheritance that Moses assigned to them

The land that Moses assigned to the tribes of Israel on the east side of the Jordan is spoken of as if it were an inheritance that Moses gave to them as a permanent possession. AT: "This is the land that Moses assigned to them as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh, the God of Israel, is their inheritance

The writer speaks of the great honor that the Levites had by serving Yahweh as priests as if Yahweh were something that they would inherit. AT: "Yahweh, the God of Israel, is what they have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joshua 13:intro

#### Joshua 13 General Notes ####

####### Structure and formatting #######

This chapter begins a section about dividing the land between the tribes of Israel.

####### Special concepts in this chapter #######

######## Division of the land ########

There was still much land to be captured west of the Jordan River, but the tribe of Reuben, Gad and half of the tribe of Mannasah received their land east of the Jordan.  This land had been promised to them in Numbers 32.

######## Driving out the people ########

While Yahweh achieved many great victories through Joshua, Israel was still supposed to drive out the rest of the Canaanites. Israel's success in this would depend on their faith in Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

##### Links: #####

* __[Joshua 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Joshua 14

### Joshua 14:01

#### the areas of land that the people of Israel received as their inheritance

The land that the people of Israel acquired is spoken of as if it were an inheritance that they received as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### tribal leaders

"leaders of the tribes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]

### Joshua 14:02

#### Their inheritance was selected by lot

This can be stated in active form. AT: "Eleazar, Joshua, and the tribal leaders cast lots to determine the inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by the hand of Moses

Here the word "hand" refers to Moses himself and means that Yahweh used Moses as the agent to deliver his command. AT: "through Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Moses had given the inheritance of the two and one-half tribes beyond the Jordan, but to the Levites he gave no inheritance

The land that Moses gave to the tribes is spoken of as if it were an inheritance that they received as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The Levites were given no portion of the inheritance in the land

This can be stated in active form. AT: "And Moses did not give a portion of the inheritance to the Levites in the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### portion

"part"

#### but only certain cities to live in

The verb may be supplied from the previous phrase. AT: "but he gave to them only certain cities to live in" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### pasturelands

fields of grass for the livestock to eat

#### material resources

physical things they needed so they could provide for their families

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]

### Joshua 14:06

#### Jephunneh

This is a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Kenizzite

This is the name of a people group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I brought him a report again as it was in my heart to make

Here the word "heart" represents the thoughts. The phrase is an idiom that refers to a report that is given honestly. AT: "I brought back to him an honest report" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Joshua 14:08

#### made the heart of the people melt with fear

Making the people very afraid is spoken of as if it were making the hearts of the people melt. AT: "made the people very afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I completely followed Yahweh

Being loyal to Yahweh is spoken of as if it were completely following Yahweh. AT: "I remained loyal to Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the land ... will be an inheritance for you and for your children forever

The land that Caleb and his descendants would have is spoken of as if it were an inheritance that they would receive as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the land on which your foot has walked

Here "your foot" represents Caleb. AT: "the land on which you have walked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Joshua 14:10

#### look

This means "listen." This word adds emphasis to what is said next.

#### while Israel walked in the wilderness

"while the people of Israel traveled in the wilderness"

#### My strength is now as my strength was then

"I am still as strong now as I was then"

#### for going and coming

This is an idiom that refers to daily activities. AT: "for the things I do every day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Joshua 14:12

#### hill country

Possible meanings are 1) many large hills or small mountains or 2) one mountain.

#### Anakim

This is the name of a people group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### Joshua 14:13

#### gave Hebron as an inheritance to Caleb

Hebron is spoken of as if it were an inheritance that Caleb received as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to this day

This refers to the period of time in which the author wrote this book.

#### he completely followed Yahweh

Being loyal to Yahweh is spoken of as if it were completely following Yahweh. AT: "he remained loyal to Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Kiriath Arba

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Then the land had rest from war

The people no longer fighting wars is spoken of as if the land were a person who rested from war. See how you translated this phrase in [Joshua 11:23](../11/23.md). AT: "Then the people no longer fought wars in the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joshua 14:intro

#### Joshua 14 General Notes ####

####### Special concepts in this chapter #######

######## Drive them out ########
The Israelites were to completely drive out the Canaanites. If they did not drive them out completely, the Canaanites would cause the Israelites to worship other gods. It was sinful to allow the Canaanites to remain in the land. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Joshua 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## Joshua 15

### Joshua 15:01

#### Zin

This is the name of the wilderness area. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### from the end of the Salt Sea, from the bay that faces to the south

"from the bay that faces south at the end of the Salt Sea." These two phrases refer to the same location. The second phrase clarifies the point at which the southern border begins.

#### from the bay that faces to the south

"from the bay that extends to the south" or "from the southern bay"

#### bay

smaller part of the sea that extends into the land

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md)]]

### Joshua 15:03

#### Their boundary

"The border of the land belonging to the tribe of Judah"

#### Akrabbim ... Zin ... Hezron ... Addar ... Karka ... Azmon

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### brook of Egypt

a small river of water at the southwestern edge of the land, near Egypt (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]

### Joshua 15:05

#### at the mouth of the Jordan

The point at which the river empties into the sea is spoken of as if it were the mouth of the river. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### border ... ran

"border ... was"

#### Beth Hoglah ... Beth Arabah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Stone of Bohan

This was likely a large stone that someone set up as a landmark and named after the man, Bohan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]

### Joshua 15:07

#### Debir ... the Valley of Achor ... the hill of Adummim ... En Shemesh ... En Rogel ... the Valley of Ben Hinnom ... the Valley of Rephaim

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Joshua 15:09

#### Nephtoah ... Mount Ephron ... Baalah ... Kiriath Jearim ... Mount Seir ... Mount Jearim ... Kesalon ... Beth Shemesh ... Timnah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md)]]

### Joshua 15:11

#### Shikkeron ... Mount Baalah ... Jabneel

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 15:13

#### Kiriath Arba ... Debir ... Kiriath Sepher

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Arba ... Anak ... Sheshai ... Ahiman ... Talmai

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the three sons of Anak: Sheshai, Ahiman and Talmai, descendants of Anak

These names represent clans of people who were descendants of Sheshai, Ahiman, and Talmai. The words "sons" and "descendants" in this context mean the same thing. AT: "the three clans, Sheshai, Ahiman, and Talmai, who were descendants of Anak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He went up from there against

"He went up from there to fight against"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Joshua 15:16

#### Kiriath Sepher

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Aksah

This is a woman's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Othniel ... Kenaz

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]

### Joshua 15:18

#### Aksah came to Othniel

This is an idiom that refers to Aksah becoming Othniel's wife. AT: "when Aksah became Othniel's wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### she urged him to ask her father for a field.

This can be translated as direct speech. AT: "she urged him, 'Ask my father to give me a field.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Joshua 15:19

#### the upper springs and lower springs

The words "upper" and "lower" likely refer to the geographical altitude of the water springs.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]

### Joshua 15:20

#### This was the inheritance of the tribe of Judah

The land that the tribe of Judah received is spoken of as if it were an inheritance that they received as a permanent possession. AT: "This was the land that the tribe of Judah received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 15:21

#### Connecting Statement:

The writer lists the southern cities of which Judah took possession. The list continues through [Joshua 15:32](./29.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]

### Joshua 15:25

#### Connecting Statement:

The list of cities continues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md)]]

### Joshua 15:29

#### Connecting Statement:

The list of cities continues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Joshua 15:33

#### General Information:

The writer lists the northern cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Joshua 15:37

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Joshua 15:40

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Joshua 15:42

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Joshua 15:45

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### settlements

"villages"

#### brook of Egypt

a small river of water at the southwestern edge of the land near Egypt (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]

### Joshua 15:48

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md)]]

### Joshua 15:52

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]

### Joshua 15:55

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezreel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezreel.md)]]

### Joshua 15:58

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Joshua 15:60

#### Connecting Statement:

The writer lists cities of which Judah took possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Joshua 15:63

#### to this day

This refers to the period of time in which the author wrote this book.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### Joshua 15:intro

#### Joshua 15 General Notes ####

####### Other possible translation difficulties in this chapter #######

This chapter is about the land given to the tribe of Judah. It will be difficult to fully understand their location without a map. Further research may be needed to understand the location of their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Joshua 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## Joshua 16

### Joshua 16:01

#### the tribe of Joseph

The "tribe of Joseph" consisted of the tribes of Joseph's two sons, Manasseh and Ephraim. Since half of the tribe of Manasseh had settled east of the Jordan, this phrase refers to the tribe of Ephraim and the other half of the tribe of Manasseh. AT: "the tribe of Ephraim and the other half of the tribe of Manasseh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Luz ... Ataroth

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Arkites

This is the name of a people group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]

### Joshua 16:03

#### Japhletites

This is the name of a people group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Lower Beth Horon ... Gezer

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the tribes of Joseph, Manasseh and Ephraim

"the tribes of Manasseh and Ephraim, the sons of Joseph"

#### received their inheritance

The land that the tribes of Manasseh and Ephraim possessed is spoken of as if it were an inheritance that they received as a permanent possession. AT: "received this land as their inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Joshua 16:05

#### The territory of the tribe of Ephraim, clan by clan

This can be stated in active form. AT: "The territory ... that Joshua assigned to their clans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Ataroth Addar ... Upper Beth Horon ... Mikmethath ... Taanath Shiloh ... Janoah ... Naarah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 16:08

#### Tappuah ... Kanah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This was the inheritance of the tribe of Ephraim

The land that Ephraim possessed is spoken of as if it were an inheritance that they received as a permanent possession. AT: "This was the land that the tribe of Ephraim received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### clan by clan

This can be stated in active form. AT: "which Joshua assigned to their clans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the cities that were chosen

This can be stated in active form. AT: "the cities that Joshua had chosen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### within the inheritance of the tribe of Manasseh

The land that the tribe of Manasseh possessed is spoken of as if it were an inheritance that they received as a permanent possession. AT: "within the land that the tribe of Manasseh had received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

### Joshua 16:10

#### to this day

This refers to the period of time in which the author wrote this book.

#### these people were made to do forced labor

This can be stated in active form. AT: "the Israelites forced these people to work as slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Joshua 16:intro

#### Joshua 16 General Notes ####

####### Special concepts in this chapter #######

######## Drive them out ########
The Israelites were to completely drive out the Canaanites. If they did not drive them out completely, the Canaanites would cause the Israelites to worship other gods. It was sinful to allow the Canaanites to remain in the land. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Other possible translation difficulties in this chapter #######

This chapter is about the land given to the tribe of Ephraim, one of Joseph's sons. It will be difficult to fully understand their location without a map. Further research may be needed to understand the location of their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Joshua 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | [>>](../17/intro.md)__


## Joshua 17

### Joshua 17:01

#### firstborn and who himself was

Here "himself" emphasizes that the same person—Makir—was the firstborn of Manasseh and was also the father of Gilead. AT: "firstborn; he was also" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### Makir ... Abiezer, Helek, Asriel, Shechem, Hepher, and Shemida

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Makir's descendants were assigned the land of Gilead and Bashan

This can be stated in active form. AT: "Joshua assigned the land of Gilead and Bashan to Makir's descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Land was assigned ... given to their clans

This can be stated in active form. AT: "Joshua assigned land ... and gave them to their clans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 17:03

#### Zelophehad ... Hepher ... Eleazar

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mahlah, Noah, Hoglah, Milkah, and Tirzah

These are women's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### to give to us an inheritance

The land is spoken of as if it were an inheritance that the people received as a permanent possession. AT: "to give to us some land as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he gave those women an inheritance

Possible meanings are 1) "Joshua gave those women an inheritance" or 2) "Eleazar gave those women an inheritance."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Joshua 17:05

#### Ten parcels of land were assigned

This can be stated in active form. AT: "Joshua assigned ten parcels of land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Ten parcels

"Ten portions"

#### received an inheritance

The land is spoken of as if it were an inheritance that they received as a permanent possession. AT: "received land as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The land of Gilead was assigned

This can be stated in active form. AT: "Joshua assigned the land of Gilead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 17:07

#### southward

"toward the south"

#### Mikmethath ... Tappuah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]

### Joshua 17:09

#### The border

"The border of Manasseh's land"

#### brook

a very small river

#### Kanah

name of a brook (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### On the north side Asher can be reached

Possible meanings are 1) that the border of Manasseh's land on the north side touched the land that belonged to the tribe of Asher or 2) that one can travel north to reach Asher. AT: "Asher was on the north side" or "One can travel north to reach Asher" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to the east, Issachar

The verb may be supplied from the previous phrase. AT: "to the east, one can reach Issachar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]

### Joshua 17:11

#### Beth Shan ... Ibleam ... Dor ... Endor ... Taanach ... Megiddo ... Napheth

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Joshua 17:13

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### Joshua 17:14

#### the descendants of Joseph

This refers to the tribes of Ephraim and Manasseh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Why have you given us only one ... Yahweh has blessed us?

The people of the tribes of Ephraim and Manasseh ask this question to emphasize that Joshua should have assigned to them more land. AT: "You should have given us more than one ... Yahweh has blessed us." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### one assignment of land and one portion for an inheritance

These two phrases mean basically the same thing. In the second, the land is spoken of as if it were an inheritance that the people received as a permanent possession. AT: "one assignment of land as our inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### portion

part

#### people great in number

"many people"

#### If you are a people great in number

"Since you are a people great in number"

#### Rephaim

This is the name of a people group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]

### Joshua 17:16

#### Beth Shan ... Jezreel

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the house of Joseph

Here the word "house" refers to the descendants. AT: "the descendants of Joseph" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you will clear it

"you will clear the forest of trees" or "you will cut down its trees"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### Joshua 17:intro

#### Joshua 17 General Notes ####

####### Special concepts in this chapter #######

######## Manasseh's lack of faith ########
Even though they were one of the largest and most powerful tribes of Israel, the tribe of Manasseh lacked faith in the power of Yahweh. This caused them many problems. It would also cause their descendants many problems. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Other possible translation difficulties in this chapter #######

This chapter is about the land given to the tribe of Manasseh, one of Joseph's sons. It will be difficult to fully understand their locations without a map. Further research may be needed to understand the locations of their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Joshua 17:01 Notes](./01.md)__

__[<<](../16/intro.md) | [>>](../18/intro.md)__


## Joshua 18

### Joshua 18:01

#### and they conquered the land

They had conquered the people who lived in the land before they set up the tent of meeting. AT: "after they had conquered the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])

#### whose inheritance had not been assigned

The land that the tribes would receive is spoken of as if it were an inheritance that they would receive as a permanent possession. This can be stated in active form. AT: "to whom Joshua had not assigned land as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]

### Joshua 18:03

#### How long will you put off ... has given you?

Joshua asks this question in order to encourage the Israelites to take possession of the land. AT: "For long enough, you have put off ... has given you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the land up and down

The words "up and down" mean in every direction. AT: "the land in every direction" or "throughout the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### write out a description of it with a view to their inheritances

This means that they will describe the portions of land that each tribe would like to receive for an inheritance.

#### their inheritances

The land that they are to survey is spoken of as if it were an inheritance that each of the tribes would receive as a permanent possession. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### Joshua 18:05

#### General Information:

Joshua is continuing his speech to the children of Israel.

#### They will divide it

"They will divide the land"

#### Judah will remain

"The tribe of Judah will remain"

#### the house of Joseph

Here the word "house" represents the descendants of Joseph. The phrase refers to the tribes of Ephraim and Manasseh. AT: "the tribes of Ephraim and Manasseh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]

### Joshua 18:07

#### General Information:

Joshua is continuing his speech to the children of Israel.

#### no portion

"no portion of land"

#### for the priesthood of Yahweh is their inheritance

Joshua speaks of the great honor that the Levites have by serving Yahweh as priests as if it were something that they inherited. AT: "for the priesthood of Yahweh is what they have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the half tribe of Manasseh

"half of the tribe of Manasseh"

#### have received their inheritance

The land that the tribes received is spoken of as if it were an inheritance that they received as a permanent possession. AT: "have received land as their inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Joshua 18:08

#### General Information:

Joshua speaks to the twenty-one men who were to go look at the land.

#### up and down in the land

The words "up and down" mean in every direction. See how you translated this in [Joshua 18:4](./03.md). AT: "in every direction in the land" or "throughout the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]

### Joshua 18:10

#### to each was given his portion of the land

This can be stated in active form. AT: "to each tribe Joshua gave their portion in the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]

### Joshua 18:11

#### between the descendants of Judah and the descendants of Joseph

"between the land that belonged to the descendants of Judah and the land that belonged to the descendants of Joseph"

#### the descendants of Joseph

This refers to the tribes of Ephraim and Manasseh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Beth Aven

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Joshua 18:13

#### the border ... The boundary

These refer to the same thing.

#### Luz ... Ataroth Addar ... Beth Horon ... Kiriath Baal ... Kiriath Jearim

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]

### Joshua 18:15

#### Kiriath Jearim ... Ephron ... Nephtoah ... Ben Hinnom ... Rephaim ... Hinnom ... En Rogel

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]

### Joshua 18:17

#### En Shemesh ... Geliloth ... Adummim ... Beth Arabah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Stone of Bohan

This was likely a large stone that someone set up as a landmark and named after the man, Bohan. See how you translated this in [Joshua 15:6](../15/05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the shoulder of Beth Arabah

Land that is in the form of a slope or ridge is spoken of as if it were a shoulder. AT: "the slope of Beth Arabah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabah.md)]]

### Joshua 18:19

#### the north shoulder of Beth Hoglah

Land that is in the form of a slope or ridge is spoken of as if it were a shoulder. AT: "the north slope of Beth Hoglah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Beth Hoglah

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This was the inheritance of the tribe of Benjamin

The land that the tribe of Benjamin received is spoken of as if it were an inheritance that they received as a permanent possession. AT: "This was the land that the tribe of Benjamin received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it was given clan by clan

This can be stated in active form. AT: "Joshua gave it to each of their clans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/saltsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 18:21

#### General Information:

The writer lists the cities that were in the land that the tribe of Benjamin received as an inheritance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### their villages

"the villages around them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]

### Joshua 18:25

#### General Information:

The writer continues to list the cities that were in the land that the tribe of Benjamin received as an inheritance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This was the inheritance of Benjamin

The land and cities that the tribe of Benjamin received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "This was the land and the cities that the tribe of Benjamin received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 18:intro

#### Joshua 18 General Notes ####

####### Other possible translation difficulties in this chapter #######

This chapter is about the land given to the tribes of Israel. It will be difficult to fully understand their locations without a map. Further research may be needed to understand the locations of their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Joshua 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__


## Joshua 19

### Joshua 19:01

#### The second casting of lots fell to Simeon

"The second time Joshua cast lots, the lot indicated the tribe of Simeon"

#### The second

number two in a list (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### clan by clan

"and Joshua assigned the land to each of their clans"

#### Their inheritance was in the middle of the inheritance that belonged to the tribe of Judah

The land is spoken of as if it were an inheritance that the tribes received as a permanent possession. AT: "The land that they received as an inheritance was in the middle of the land that the tribe of Judah received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Joshua 19:02

#### General Information:

The writer lists cities that were in the land that the tribe of Simeon received as an inheritance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They had for their inheritance

The land and cities that the tribe of Simeon received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "They had the following cities for their inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md)]]

### Joshua 19:05

#### General Information:

The writer continues to list the cities that were in the land that the tribe of Simeon received as an inheritance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ziklag

See how you translated the name of this city in [Joshua 15:31](../15/29.md).

### Joshua 19:08

#### This was the inheritance of the tribe of Simeon

The land and cities that the tribe of Simeon received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "This was the land and the cities that the tribe of Simeon received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### clan by clan

This can be stated in active form. AT: "which Joshua gave to their clans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the portion of land assigned to the tribe of Judah

This can be stated in active form. AT: "the portion of land which Joshua assigned to the tribe of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the middle of their portion

"the middle of Judah's portion of land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 19:10

#### The third casting of lots

See how you translated this phrase in [Joshua 19:1](./01.md).

#### The third

number three in a list (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Sarid ... Maralah ... Dabbesheth ... Jokneam

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### opposite Jokneam

"across from Jokneam"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 19:12

#### Sarid ... Kisloth Tabor ... Daberath ... Japhia ... Gath Hepher ... Eth Kazin ... Rimmon ... Neah

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Joshua 19:14

#### Hannathon ... Iphtah El ... Kattath ... Nahalal ... Shimron ... Idalah ... Bethlehem

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bethlehem

This is not the same "Bethlehem" that is south of Jerusalem in Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This was the inheritance of the tribe of Zebulun

The land and cities that the tribe of Zebulun received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "This was the land and the cities that the tribe of Zebulun received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]

### Joshua 19:17

#### The fourth casting of lots

See how you translated this phrase in [Joshua 19:1](./01.md).

#### The fourth

number four in a list (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Chesulloth ... Shunem ... Hapharaim ... Shion ... Anaharath

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezreel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezreel.md)]]

### Joshua 19:20

#### Rabbith ... Kishion ... Ebez ... Remeth ... En Gannim ... En Haddah ... Beth Pazzez ... Shahazumah

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Tabor

This is the name of a mountain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 19:23

#### This was the inheritance of the tribe of Issachar

The land and cities that the tribe of Issachar received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "This was the land and the cities that the tribe of Issachar received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Joshua 19:24

#### The fifth casting of lots

See how you translated this phrase in [Joshua 19:1](./01.md).

#### The fifth

number five in a list (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Helkath, Hali, Beten, Akshaph, Allammelek, Amad, and Mishall ... Shihor Libnath

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md)]]

### Joshua 19:27

#### Beth Dagon ... Valley of Iphtah El ... Beth Emek ... Neiel ... Kabul ... Abdon ... Rehob ... Hammon ... Kanah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]

### Joshua 19:29

#### Hosah ... Akzib ... Ummah ... Aphek ... Rehob

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]

### Joshua 19:31

#### This was the inheritance of the tribe of Asher

The land and cities that the tribe of Asher received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "This was the land and the cities that the tribe of Asher received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 19:32

#### The sixth casting of lots

See how you translated this phrase in [Joshua 19:1](./01.md).

#### The sixth

number six in a list (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Heleph ... Zaanannim ... Adami Nekeb ... Jabneel ... Lakkum ... Aznoth Tabor ... Hukkok

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Joshua 19:35

#### Ziddim ... Zer ... Hammath ... Rakkath ... Kinnereth ... Adamah ... Ramah ... Hazor ... Edrei ... En Hazor

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hammath

This is not the same location as "Hamath," but is located on the west shore of the Sea of Galilee.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]

### Joshua 19:38

#### Yiron ... Migdal El ... Horem ... Beth Anath

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This was the inheritance of the tribe of Naphtali

The land and cities that the tribe of Naphtali received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "This was the land and the cities that the tribe of Naphtali received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 19:40

#### The seventh casting of lots

See how you translated this phrase in [Joshua 19:1](./01.md).

#### The seventh

number seven in a list (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### The territory of its inheritance

The land that the tribe of Dan received is spoken of as if it was an inheritance that they received as a permanent possession. AT: "The territory of land that the tribe of Dan received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Zorah, Eshtaol, Ir Shemesh, Shaalabbin, Aijalon, and Ithlah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Joshua 19:43

#### Elon, Timnah, Ekron, Eltekeh, Gibbethon, Baalath, Jehud, Bene Berak, Gath Rimmon, Me Jarkon, and Rakkon

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### across from Joppa

"opposite Joppa" or "beside Joppa"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joppa.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joppa.md)]]

### Joshua 19:47

#### Leshem

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This was the inheritance of the tribe of Dan

The land and cities that the tribe of Dan received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "This was the land and the cities that the tribe of Dan received as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Joshua 19:49

#### gave an inheritance among themselves to Joshua son of Nun

The city that Joshua received is spoken of as if it were an inheritance that he received as a permanent possession. AT: "gave a city within their own land as an inheritance to Joshua son of Nun" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Timnath Serah

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]

### Joshua 19:51

#### These are the inheritances ... assigned

The land and cities that the various tribes received are spoken of as if they were an inheritance that they received as a permanent possession. AT: "These are the portions of land and the cities ... assigned as inheritances" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]

### Joshua 19:intro

#### Joshua 19 General Notes ####

####### Other possible translation difficulties in this chapter #######

This chapter is about the land given to the tribes of Israel. It will be difficult to fully understand their locations without a map. Further research may be needed to understand the locations of their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Joshua 19:01 Notes](./01.md)__

__[<<](../18/intro.md) | [>>](../20/intro.md)__


## Joshua 20

### Joshua 20:01

#### by the hand of Moses

Here "hand of Moses" refers to the scriptures that Moses wrote down. AT: "through the things that Moses wrote" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### unintentionally kills

This happens when a person accidentally kills another person, without intending to do so.

#### avenge the blood of a person who was killed

Here the shed blood of a person represents their death. This can be stated in active form. AT: "avenge a person's death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### Joshua 20:04

#### He will run

Here the word "he" refers to the person who unintentionally killed someone.

#### explain his case to the elders of that city

"convince the elders of that city that he had not intentionally killed the person.

#### Then they will take him

The word "they" refers to the elders and "him" refers to the person who unintentionally killed someone.

#### live among them

This refers to the city as a whole, not to the elders only.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Joshua 20:05

#### avenge the blood of the person who was killed

Here the shed blood of a person represents their death. This can be stated in active form. See how you translated this in [Joshua 20:3](./01.md). AT: "avenge a person's death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### killed his neighbor unintentionally ... accidentally killed the person

These phrases mean the same thing.

#### stood before the assembly

This is a phrase that describes standing to seek justice from a court of the assembly of his fellow citizens.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]

### Joshua 20:07

#### General Information:

There are a lot of names in this section. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Jordan

This is a short name for the Jordan River.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]

### Joshua 20:09

#### would not die by the hand of the one

Here "by the hand" is an idiom that means to be the specific cause of something. AT: "would not be killed by the one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### avenge the blood that was shed

This can be stated in active form. See how you translated a similar phrase in [Joshua 20:3](./01.md). AT: "avenge a person's death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]

### Joshua 20:intro

#### Joshua 20 General Notes ####

####### Special concepts in this chapter #######

######## Cities of Refuge ########

If a person was killed, it was the duty of his relatives to kill the killer. If the death was an accident, this would be unfair. Therefore, God told the Israelites to make cities of refuge for a person who killed someone accidentally. In the city where he sought refuge, his case would be solved legally: "Do this so that one who unintentionally kills a person can go there. These cities will be a place of refuge from anyone who seeks to avenge the blood of a person who was killed." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]])

##### Links: #####

* __[Joshua 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__


## Joshua 21

### Joshua 21:01

#### Eleazar ... Nun

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They said to them

"The Levites said to them"

#### Yahweh commanded you by the hand of Moses

The phrase "by the hand of" is an idiom that means that Yahweh used Moses to deliver his command. AT: "Yahweh told Moses to command you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Joshua 21:03

#### following cities

This refers to the cities to be listed in the next verses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Joshua 21:04

#### casting of lots

A random method of choosing to remove the choice from the leader's will, often done with the idea that God will decide the outcome. See how you translated this in [Joshua 19:1](../19/01.md).

#### Kohathites

This priests in this group were descendants of Levi's son Kohath. A portion of them were also descendants of Aaron, Kohath's grandson. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### thirteen cities ... ten cities

numbers of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### half tribe

Half the tribe because the other half received their inheritance before crossing the Jordan River.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]

### Joshua 21:06

#### Gershon

Gershon was one of the sons of Levi. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### casting of lots

A random method of choosing to remove the choice from the leader's will, often done with the idea that God will decide the outcome. See how you translated this in [Joshua 19:1](../19/01.md).

#### Merari

Merari was one of the sons of Levi. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]

### Joshua 21:08

#### Yahweh had commanded by the hand of Moses

The phrase "by the hand of" here means that Yahweh used Moses as the agent to deliver his command. AT: "Yahweh had told Moses to command" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### clans of the Kohathites

The priests in this group were descendants of Levi's son Kohath. A portion of them were also descendants of Aaron, Kohath's grandson. See how you translated this in [Joshua 21:2](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### casting of lots

A random method of choosing to remove the choice from the leader's will, often done with the idea that God will decide the outcome. See how you translated this in [Joshua 19:1](../19/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Joshua 21:11

#### Arba had been the father of Anak

This is background information about the name of the man who founded the city of Kiriath Arba. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Anak

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### hill country

An area of land with natural elevations, smaller than mountains.

#### pasturelands

An area covered with grass or plants suitable for the grazing of livestock or cattle.

#### fields of the city

Areas of open land, usually, planted with crops, belonging to and surrounding the city.

#### villages

Small communities, usually smaller than a town.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Joshua 21:13

#### Libnah ... Jattir ... Eshtemoa ... Holon ... Debir ... Ain ... Juttah

These are all names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### nine cities ... two tribes

The number of cities and tribes in the passage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md)]]

### Joshua 21:17

#### From the tribe of Benjamin were given Gibeon

This can be stated in active form. AT: "The tribe of Benjamin gave Gibeon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Geba ... Anathoth ... Almon

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### thirteen cities

"13 cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Joshua 21:20

#### the Kohathite clans

The priests in this group were descendants of Levi's son Kohath. A portion of them were also descendants of Aaron, Kohath's grandson. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### they had cities given to them

This can be stated in active form. AT: "they received cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### casting of lots

A random method of choosing to remove the choice from the leader's will, often done with the idea that God will decide the outcome. See how you translated this in [Joshua 19:1](../19/01.md).

#### Gezer ... Kibzaim ... Beth Horon

names of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### four cities in all

This refers to the list by the total number. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]

### Joshua 21:23

#### From the tribe of Dan, the clan of Kohath was given Eltekeh

This can be stated in active form. AT: "The tribe of Dan gave to the clan of Kohath Eltekeh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the clan of Kohath

The priests in this group were descendants of Levi's son Kohath. A portion of them were also descendants of Aaron, Kohath's grandson. See how you translated a similar phrase in [Joshua 21:20](./20.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eltekeh ... Gibbethon ... Aijalon ... Gath Rimmon

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### four cities

This refers to the number of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]

### Joshua 21:25

#### From the half tribe of Manasseh, the clan of Kohath was given Taanach

This can be stated in active form. AT: "The half tribe of Manasseh gave to the clan of Kohath Taanach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Taanach ... Gath Rimmon

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### two cities ... ten cities in all

numbers of cities listed (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### clan of Kohath ... clans of the Kohathites

The priests in this group were descendants of Levi's son Kohath. A portion of them were also descendants of Aaron, Kohath's grandson. See how you translated this in [Joshua 21:2](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]

### Joshua 21:27

#### From the half tribe of Manasseh, to clans of Gershon, these were other Levite clans, and they gave Golan

This can be stated in active form. AT: "The half tribe of Manasseh, other Levite clans, received from the half tribe of Manasseh Golan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Golan ... Be Eshterah

names of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### killed another unintentionally

This refers to a death resulting from an action not intended to harm a person.

#### two cities

number of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]

### Joshua 21:28

#### To the clans of Gershon they also gave Kishion

This can be stated in active form. AT: "The clans of Gershon also received Kishion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Kishion ... Daberath ... Jarmuth ... En Gannim ... Mishal ... Abdon ... Helkath ... Rehob

names of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### From the tribe of Asher, they gave Mishal

This can be stated in active form. AT: "They received from the tribe of Asher Mishal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### four cities in all

This refers to the number of cities listed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]

### Joshua 21:32

#### From the tribe of Naphtali, they gave the clans of Gershon Kedesh

This can be stated in active form. AT: "The clans of Gershon received from the tribe of Naphtali Kedesh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Gershon

This is the name of a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hammoth Dor ... Kartan

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### thirteen cities in all

"13 cities in total" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]

### Joshua 21:34

#### To the rest of the Levites—the clans of Merari—were given out of the tribe of Zebulun: Jokneam

This can be stated in active form. AT: The rest of the Levites—the clans of Merari—received from the tribe of Zebulun Jokneam" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Merari

name of a person (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jokneam ... Kartah ... Dimnah ... Nahalal

names of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### four cities in all

The cities are referred to in total as a number. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]

### Joshua 21:36

#### To the clans of Merari were given from the tribe of Reuben: Bezer

This can be stated in active form. AT: "The clans of Merari received from the tribe of Reuben Bezer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### four cities

This refers to the total number of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Bezer ... Jahaz ... Kedemoth ... Mephaath ... Ramoth

names of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Out of the tribe of Gad they were given Ramoth

This can be stated in active form. AT: "They received from the tribe of Gad Ramoth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Mahanaim

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Joshua 21:39

#### The clans of Merari were also given Heshbon

This can be stated in active form. AT: "The clans of Merari also received Heshbon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Heshbon ... Jazer

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### twelve cities in all

"12 cities in total" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### twelve cities in all were given to them by the casting of lots

This can be stated in active form. AT: "they received these twelve cities by the casting of lots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### casting of lots

A random method of choosing to remove the choice from the leader's will, often done with the idea that God will decide the outcome. See how you translated this in [Joshua 19:1](../19/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Joshua 21:41

#### The cities of the Levites taken from the middle of the land

This can be stated in active form. AT: "The Levites received their cities from the middle of the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### forty-eight cities

"48 cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 21:43

#### he swore

"he gave an oath"

#### Not one of their enemies could defeat them

This is stated in a negative way to strengthen the statement. AT: "They defeated every one of their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### gave all their enemies into their hand

Here "into their hand" means "into their power." AT: "gave them power to defeat all their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Not one thing among all the good promises that Yahweh had spoken to the house of Israel failed to come true

This is stated in a negative way to strengthen the statement. AT: "Every one of the good promises that Yahweh had spoken to the house of Israel came true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Joshua 21:intro

#### Joshua 21 General Notes ####

####### Other possible translation difficulties in this chapter #######

This chapter is about the land given to the tribe of Levi. Even though they did not receive a large piece of land like the other tribes, they did receive small pieces of land to live on and for their animals. It will be difficult to fully understand their locations without a map. Further research may be needed to understand the locations of their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Joshua 21:01 Notes](./01.md)__

__[<<](../20/intro.md) | [>>](../22/intro.md)__


## Joshua 22

### Joshua 22:01

#### Reubenites

people of the tribe of Reuben (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Gadites

people of the tribe of Gad (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### obeyed my voice

Here "my voice" refers to the things that Joshua had said. AT: "obeyed everything I said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You have not deserted your brothers

This can be stated in a positive way. AT: "You have remained with your brothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### Joshua 22:04

#### to walk in all his ways

A person obeying Yahweh is spoken of as if he were walking on Yahweh's ways or roads. AT: "to obey everything he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### with all your heart and with all your soul

The terms "heart" and "soul" are here used together to refer to the entire person. AT: "with all you think and feel" or "with your entire being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Joshua 22:07

#### the Jordan

This was a short name for the Jordan River.

#### iron

a strong, hard, magnetic metal

#### plunder

The winning army would take everything of value from the people they conquered.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Joshua 22:09

#### the commandment of Yahweh, by the hand of Moses

The phrase "by the hand of" is an idiom that means that Yahweh used Moses to deliver his command. AT: "the commandment that Yahweh told Moses to give to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Joshua 22:10

#### the Jordan

This was a short name for the Jordan River.

#### at the front of the land of Canaan

The Israelite tribes who lived across the Jordan River would enter Canaan at the place where they built the altar. This place is spoken of as if it was the "front" or "entrance" to Canaan where the other tribes lived. AT: "at the entrance to the land of Canaan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Geliloth

name of a city (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 22:12

#### war

a state of armed conflict between two nations or people groups

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]

### Joshua 22:13

#### Eleazar

name of man (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Joshua 22:15

#### The whole assembly of Yahweh says this

All the people of Israel are spoken of together in the singular as if they were one person. AT: "All the other Israelites are asking"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]

### Joshua 22:17

#### Was our sin at Peor not enough for us?

This question emphasizes how serious their previous sin was. This can be written as a statement. AT: "We had already sinned terribly at Peor!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Peor

This is name of a place. Translate the same way as in [Joshua 13:20](../13/20.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### we have not even now cleansed ourselves from it

This can be stated in positive form. AT: "we are still dealing with the guilt of that sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Must you also turn away from following Yahweh at this present day?

This question is used to rebuke the people for their sin. This can be written as a statement. AT: "You must not turn away from following Yahweh today!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 22:19

#### Achan ... Zerah

names of men (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Did not Achan son of Zerah break faith in the matter of those things that had been reserved for God? Did not wrath fall on all the people of Israel?

These questions are used to remind the people of the punishment for past sins. These questions can be written as statements. AT: "Achan son of Zerah sinned by taking things that had been reserved for God. And because of that God punished all the people of Israel!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]

### Joshua 22:21

#### If it was in rebellion ... let Yahweh make us pay for it

The three tribes are making two hypothetical statements that they insist are not true. They did not build the altar to worship another god. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md)]]

### Joshua 22:24

#### General Information:

The tribes of Reuben, Gad and the half tribe of Manasseh now give their answer.

#### your children might say to our children ... God of Israel?

This is a hypothetical accusation that the three tribes think the children of the other tribes may make sometime in the future. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### What have you to do with Yahweh, the God of Israel?

The three tribes use this rhetorical question to emphasize the situation they are trying to avoid. This can be written as a statement. AT: "You have nothing to do with Yahweh, the God of Israel!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Joshua 22:25

#### General Information:

The tribes of Reuben, Gad and the half tribe of Manasseh continue their answer.

#### For Yahweh has made the Jordan ... nothing to do with Yahweh

This is the continuation of the hypothetical accusation that the three tribes think the children of the other tribes may make sometime in the future. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### the Jordan

This is a short name for the Jordan River.

#### So your children might make our children cease to worship Yahweh

The three tribes built the altar to avoid this hypothetical situation from happening in the future. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Joshua 22:26

#### General Information:

The tribes of Reuben, Gad and the half tribe of Manasseh now give their answer.

#### to be a witness between us and you

The altar is spoken of as if it were a witness that could testify to the rights of the three tribes. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so that your children will never say to our children in time to come, "You have no share in Yahweh."

This is the hypothetical situation that the three tribes did not want to happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### no share

"no portion" or "no inheritance"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### Joshua 22:28

#### General Information:

The tribes of Reuben, Gad and the half tribe of Manasseh now finish their answer.

#### If this should be said ... a witness between us and you."

The three tribes are describing their potential answer to an accusation that might or might not be made at a future time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### May it be far from us that we should rebel

The unlikely chance that they would rebel is spoken of as if it is something that is a great distance away from them. AT: "We would certainly not rebel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### turn away from following him

To stop following Yahweh is spoken of as if they were turning away from him. AT: "stop following him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Joshua 22:30

#### heard the words

"heard the message"

#### was good in their eyes

Here "in their eyes" means "in their opinion." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### committed this breach of faith against him

"broken your promise to him"

#### you have rescued the people of Israel out of the hand of Yahweh

Here "the hand of Yahweh" refers to his punishment. Protecting the people is spoken of as rescuing them from his hand. AT: "you have kept Yahweh from punishing us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Joshua 22:32

#### Their report was good in the eyes of the people

Here "good in the eyes" means "accepted." AT: "The people accepted the report of the leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### destroy the land

"destroy everything in the land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Joshua 22:34

#### for they said

This refers to the Reubenites and Gadites.

#### It is a witness between us

The altar is spoken of as if it were a witness that could testify for the three tribes. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joshua 22:intro

#### Joshua 22 General Notes ####

####### Structure and formatting #######

The division of the land is completed in this chapter. Additionally, the soldiers who received land on the east side of the Jordan River were released to go home.

####### Special concepts in this chapter #######

######## The tribes east of the Jordan River build a monument ########

The tribes east of the Jordan River said, "Let us now build an altar, not for burnt offerings nor for any sacrifices, but to be a witness between us and you, and between our generations after us, that we will perform the service of Yahweh before him, with our burnt offerings and with our sacrifices and with our peace offerings, so that your children will never say to our children in time to come, 'You have no share in Yahweh.'" They went home even though the Israelites had not fully conquered the land. 

##### Links: #####

* __[Joshua 22:01 Notes](./01.md)__

__[<<](../21/intro.md) | [>>](../23/intro.md)__


## Joshua 23

### Joshua 23:01

#### very old

lived for many years

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Joshua 23:04

#### the Jordan

This is a short name for the Jordan River.

#### in the west

This indicates the direction of the setting sun.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mediterranean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Joshua 23:06

#### turning aside from it neither to the right hand nor to the left

Disobeying the commands of the law of Moses is spoken of as turning to the right or to the left away from a path. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you may not mix

Possible meanings are 1) having close friendship with them or 2) intermarrying with them.

#### mention

to speak of

#### their gods

This refers to the gods of the remaining nations.

#### cling to Yahweh

"hold tightly to Yahweh." Believing in Yahweh is spoken of as if they were holding tightly onto him. AT: "continue to believe in Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to this day

"until the present time"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Joshua 23:09

#### to stand before you

Here "stand" represents holding ground in a battle. The word "you" refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### single

"one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### thousand

"1,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Joshua 23:12

#### cling to the survivors of these nations

Accepting the beliefs of these nations is spoken of as holding tightly to them. AT: "accept the beliefs of the survivors of these nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a snare and a trap

The words "snare" and "trap" mean basically the same thing. Together they speak of the other nations as if they were a deadly trap that will cause trouble for Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### whips on your backs and thorns in your eyes

These phrases speak of the troubles these nations will cause Israel as if they were as painful as whips and thorns. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Joshua 23:14

#### I am going the way of all the earth

Joshua uses a polite term to refer to his death. AT: "I am going to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### know with all your hearts and souls

Here the words "hearts" and "souls" have similar meanings. Together they emphasize deep personal knowledge. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### not one word has failed to come true

These words emphasize that Yahweh's promises have all occurred. This can be stated in positive form. AT: "every word has come true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Joshua 23:16

#### He will do this

This refers to the punishment threatened in the previous verse.

#### worship other gods and bow down to them

These two phrases mean basically the same thing. The second describes how the people "worship other gods." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the anger of Yahweh will be kindled against you

"Kindled" here is a metaphor for the beginning of Yahweh's anger, like a fire is "kindled" or started with "kindling" or very easy to start burning like dried grass or small twigs. AT: "Yahweh will begin to be angry with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Joshua 23:intro

#### Joshua 23 General Notes ####

####### Special concepts in this chapter #######

######## Joshua's final words to Israel (Joshua 23-24) ########

"Do not marry with the heathen people but drive them out." ##### Drive them out #####
The Israelites were to completely drive out the Canaanites. If they did not drive them out completely, the Canaanites would cause the Israelites to worship other gods. It was sinful to allow the Canaanites to remain in the land because if the Israelites married the Canaanites, the Canaanites would cause them to worship other gods.  (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Joshua 23:01 Notes](./01.md)__

__[<<](../22/intro.md) | [>>](../24/intro.md)__


## Joshua 24

### Joshua 24:01

#### Joshua gathered all the tribes of Israel

Joshua's summons to the tribes is spoken of as if he gathered them together in a basket. AT: "Joshua asked all the tribes of Israel to meet with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### presented themselves before

"came and stood in front of" or "came before"

#### long ago

"many years ago"

#### This is what

Joshua begins to quote what Yahweh had said previously. The quotation continues until the end of verse 13.

#### Terah ... Nahor

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nahor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nahor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Joshua 24:03

#### General Information:

Joshua continues quoting what Yahweh said about his dealings with his people.

#### Seir

name of a place or location (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### went down

Egypt was lower in elevation that the land of Canaan. AT: "traveled"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Joshua 24:05

#### General Information:

Joshua continues quoting what Yahweh said about his dealings with his people.

#### brought you out ... brought your ancestors out

Yahweh continually alternates between these two phrases, which both refer to all the Israelites, past and present. The word "you" is plural throughout this speech and refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]

### Joshua 24:07

#### General Information:

Joshua continues quoting what Yahweh said about his dealings with his people.

#### your ancestors ... you

Yahweh continually alternates between these two phrases, which both refer to all the Israelites, past and present. The word "you" is plural throughout this speech and refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the sea

This refers to the Sea of Reeds.

#### in the wilderness

an uninhabited area, a desert

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Joshua 24:08

#### General Information:

Joshua continues quoting what Yahweh said about his dealings with his people.

#### you

The word "you" is plural throughout this speech and refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the Jordan

This is a short name for the Jordan River.

#### gave them into your hand

Here "hand" refers to power. AT: "enabled you to conquer them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Joshua 24:09

#### General Information:

Joshua continues quoting what Yahweh said about his dealings with his people.

#### Balak ... Zippor

men's names (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### you

The word "you" is plural throughout this speech and refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### rescued you out of his hand

Here "hand" refers to power. AT: "enabled you to overcome him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Joshua 24:11

#### General Information:

Joshua continues quoting what Yahweh said about his dealings with his people.

#### You

The word "you" is plural throughout this speech and refers to the entire nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the Jordan

This is a short name for the Jordan River.

#### the hornet

A small fast flying stinging insect that lives in colonies. Here, many "hornets" are spoken of as only one.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/girgashites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/girgashites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]

### Joshua 24:13

#### General Information:

Joshua finishes quoting what Yahweh said about his dealings with his people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]

### Joshua 24:14

#### If it seems wrong in your eyes

The eyes represent seeing, and seeing represents thoughts or desire. AT: "If you do not want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my house

This represents his family that lives in his house. AT: "my family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Joshua 24:16

#### us and our ancestors ... we

The people speak as if they were present with their ancestors, and interchange the words "us" and "we" with "our ancestors." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### house of slavery

Here "house" is an idiom that refers to the location of their slavery. AT: "place where we were slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### nations through whom we passed

"nations that we passed through"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Joshua 24:19

#### people

This refers to the Israelites.

#### he is a jealous God

God wants his people to worship only him.

#### He will consume you

Yahweh's anger is spoken of as if he was a fire that would destroy them. AT: "He will destroy you as with fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]

### Joshua 24:21

#### people

This refers to the Israelites.

#### turn your heart to Yahweh

Deciding to obey Yahweh only is spoken of as turning their heart towards him. Here "heart" represents the whole person. In this case, "heart" is plural because it refers to all the Israelites as a single group. However, it may be best to translate it in the plural since "your" is plural. AT: "turn yourselves to Yahweh" or "decide to obey Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joshua 24:24

#### people

This refers to the Israelites.

#### We will listen to his voice

Here "listen" means to obey. AT: "We will obey everything he tells us to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He put in place decrees and laws

Establishing laws is spoken of as if Joshua physically set them in place like monuments. AT: "He established decrees and laws" or "He gave them laws and decrees to obey" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the book of the law of God

This appears to be a continuation of the writings of Moses.

#### set it up there

"placed it there"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]

### Joshua 24:27

#### people

This refers to the Israelites.

#### this stone will be a testimony ... It has heard all the words

The stone that Joshua set up is spoken of as if it were a person who heard what was spoken and would be able to testify about what was said. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### should you ever

"if you ever"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Joshua 24:29

#### 110 years old

"one hundred and ten years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Timnath Serah ... Mount Gaash

names of places (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]

### Joshua 24:31

#### all of Joshua's days

This is an idiom that refers to Joshua's entire life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### outlived Joshua

"lived longer than Joshua"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]

### Joshua 24:32

#### The bones of Joseph ... they buried them at Shechem,

It may be helpful to change the order of the beginning of this sentence. AT: "The people of Israel brought the bones of Joseph up out of Egypt and buried them at Shechem"

#### one hundred pieces

"100 pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Eleazar

name of a man (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Gibeah

name of a place (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]

### Joshua 24:intro

#### Joshua 24 General Notes ####

####### Special concepts in this chapter #######

######## Joshua's instructions ########
In this chapter, Joshua gives the leaders and people instructions in preparation for his death. It was common in the Ancient Near East for important leaders to do this. Unfortunately, the people of Israel did not listen to Joshua's instructions. 

##### Links: #####

* __[Joshua 24:01 Notes](./01.md)__

__[<<](../23/intro.md) | __


## Joshua front

### Joshua front:intro

#### Introduction to Joshua ####

##### Part 1: General Introduction #####

####### Outline of the Book of Joshua #######

1. Conquest of the land of Canaan (1–12)
    - Preparation for conquest; spies, and crossing the Jordan River (1:1–5:1)
    - Ceremonies at Gilgal; conquest of Jericho and Ai (5:2–8:29)
    - Covenant affirmation at Shechem (8:30–35)
    - Southern and central campaigns, northern campaigns (9:1–12:24)
1. Settlement in Promised Land; divisions of the land (13:1–22:34)
1. Joshua's final days (23–24)

####### What is the Book of Joshua about? #######

The Book of Joshua is about the Israelites entering the Promised Land and occupying it. Joshua was the leader that replaced Moses. He led the Israelites in battle to fight the people living in the Promised Land. This book also tells how the Israelites divided the land among the twelve tribes. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

####### How should the title of this book be translated? #######

Translators may create a short title such as "The Book about When Joshua Led Israel." Translators should avoid a title that suggests Joshua as the writer of the book.

####### Who wrote the Book of Joshua? #######

The book does not indicate who wrote it. However, there are verses in the book that indicate that Joshua may have written some it. Since ancient times, Jews have thought that Joshua wrote most of the book.

##### Part 2: Important Religious and Cultural Concepts #####

####### How does the Book of Joshua present the cause of historical events? #######

In the Ancient Near East, people assumed that the gods caused world events to happen in a certain way. The Book of Joshua has some similarities with this view, but there are important differences. In Joshua, these events occurred because Yahweh promised the Israelites that he would give them the Promised Land. However, the results of the events were also based on whether the Israelites obeyed or disobeyed Yahweh.

##### Part 3: Important Translation Issues #####

####### What does the phrase "to this day" mean? #######

This phrase was used by the writer to refer to the time when he was writing. The translator should be aware that "to this day" refers to a time which has already passed. He must avoid giving the impression to readers that "to this day" means the present day. The translator might decide to say "to this day, at the time when this was being written," or "to this day, at the time of writing." This Hebrew phrase occurs in Joshua 4:9; 6:25; 7:26; 8:28, 29; 10:27; 13:13; 14:14; 15:63; 16:10.

####### What does the phrase "all Israel" mean? #######

This phrase appears many times in the Book of Joshua, but it does not always mean every Israelite in the nation. At times it means the Israelite army. At other times it means the representatives of the twelve tribes of Israel. In still other passages it probably means many people in the nation of Israel.

####### When should Joshua be translated? #######

The Book of Joshua should probably not be translated before Genesis, Exodus, Leviticus, Numbers, and Deuteronomy. This is because the historical events of Joshua will not be understood without the information provided by these previous books.



---

