# <a id="zec"/>Zechariah

## Zechariah 01

### Zechariah 01:01

#### In the eighth month

This is the eighth month of the Hebrew calendar. It is during the last part of October and the first part of November on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the second year of Darius' reign

"the second year of the reign of Darius the king" or "the second year since Darius became king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the word of Yahweh came

This idiom is used to introduce a special message from God. AT: "Yahweh gave a message" or "Yawheh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### Berechiah ... Iddo

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### exceedingly angry with your fathers

"very angry with your forefathers"

#### Turn to me ... and I will return to you

Yahweh speaks of having a change of attitude toward another person as if it were turning or returning. The people turning to Yahweh means that they will again be devoted to him and worship him, while Yahweh returning to the people means that he will again bless them and help them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Zechariah 01:04

#### Turn from your evil ways and wicked practices

No longer doing certain actions is spoken of as if it were turning away from those actions. The phrases "evil ways" and "wicked practices" mean basically the same thing. AT: "Stop doing all of your wicked actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### But they would not hear and did not pay attention to me

Both of these phrases mean that the people of Israel would not obey the commands of Yahweh. AT: "But they would not listen to my commands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated a similar phrase in [Zechariah 1:3](./01.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Your fathers, where are they? Where are the prophets, are they here forever?

These two rhetorical questions emphasize that both their ancestors and the prophets who proclaimed Yahweh's message to their ancestors have died. The questions can be translated as a statement. AT: "Neither your fathers nor the prophets are here because they have all died." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### But my words and my decrees that I commanded my servants the prophets, have they not overtaken your fathers?

This rhetorical question emphasizes the positive answer that it anticipates. Yahweh speaks of the people's ancestors experiencing the consequences of not obeying Yahweh's commands as if his words and decrees were a person who had chased after and overtaken them. The question can be translated as a statement. AT: "But my words and my decrees that I commanded my servants the prophets have overtaken your fathers." or "But your fathers have suffered the consequences for disobeying my words and my decrees that I commanded my servants the prophets to tell them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my words and my decrees

These phrases are both ways to refer to Yahweh's message that the prophets had declared to their ancestors. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### our ways and actions

The words "ways" and "actions" mean basically the same thing. AT: "our behavior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]

### Zechariah 01:07

#### the twenty-fourth day of the eleventh month, which is the month of Shebat

"Shebat" is the eleventh month of the Hebrew calendar. The twenty-fourth day is near the middle of February on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in the second year of Darius' reign

"in the second year of the reign of Darius the king" or "in the second year since Darius became king." See how you translated this in [Zechariah 1:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the word of Yahweh came

This idiom is used to introduce a special message from God. See how you translated this in [Zechariah 1:1](./01.md). AT: "Yahweh gave a message" or "Yawheh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Berechiah ... Iddo

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### look

The word "look" here shows that Zechariah was surprised by what he saw.

#### myrtle trees

a kind of small tree with colorful flowers (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### I said, "What are these things, Lord?" Then the angel who talked with me

Here Zechariah speaks to an unidentified angel. This is not the same as the "man" who was "riding on a red horse."

#### What are these things, Lord?

"What are these things, sir?" Here the word "Lord" is a form of polite address.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Zechariah 01:10

#### the man who stood among the myrtle trees ... the angel of Yahweh who stood among the myrtle trees

These phrases refer to the man who "was riding on a red horse" in [Zechariah 1:8](./07.md). Possible meanings are 1) the man dismounted his horse and stood or 2) the word "stood" is an idiom that means he was located in that position. AT: "the man who was among the myrtle trees ... the angel of Yahweh who was among the myrtle trees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### These are those ... They answered ... they said

The words "these" and "they" refer to the red, reddish-brown, and white horses that were behind the man who was among the myrtle trees. Possible meanings are 1) it is implicit that there were other men who were riding the horses, and that these phrases refer to the riders or 2) the horses are personified as being able to speak like people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### to roam throughout the earth

It is implicit that Yahweh sent these out to walk about in order to patrol the earth. This does not suggest that they were wandering or lost. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all the earth sits still and is at rest

There being peace and quiet in the world is spoken of as if the earth were a person who is still and resting. Possible meanings are 1) this is a good thing that means that there is peace between nations or 2) this is a bad thing that means that there is no war because nations are helpless to fight against a stronger nation that has subdued them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Zechariah 01:12

#### to Jerusalem and to the cities of Judah

Here the words "Jerusalem" and "cities" refer to the people who live in those cities. AT: "to the people of Jerusalem and to the people of the cities of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with good words, words of comfort

"with good, comforting words"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Zechariah 01:14

#### I have been jealous for Jerusalem

Here the word "jealous" refers to Yahweh's strong desire to protect his people.

#### I am very angry with the nations that are at ease

The phrase "at ease" means that the people thought that they lived in peace and security. AT: "I am very angry with the nations that enjoy peace and security" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I was only a little angry with them

"I was only a little angry with the people of Jerusalem"

#### they made the disaster worse

"the nations that are at ease made the disaster worse." This means that although Yahweh used these nations to punish Jerusalem, they did more harm to Jerusalem than what Yahweh had intended for them to do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Zechariah 01:16

#### I have returned to Jerusalem with mercies

Possible meanings are 1) although Yahweh had left Jerusalem when the people had gone into exile, he will now return to Jerusalem when they have come back from exile or 2) Yahweh speaks of having a change of attitude towards the people of Jerusalem and again blessing them and helping them as if he were returning to the city. AT: "I will once again show mercy towards Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### My house will be built within her

The word "her" refers to Jerusalem, and the word "house" is a metonym for the temple. This can be stated in active form. AT: "The people will build my temple in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:3](./01.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### the measuring line will be stretched out over Jerusalem

This refers to builders using their instruments to rebuild the city. This can be stated in active form. AT: "builders will stretch out their measuring lines over Jerusalem" or "the people will rebuild Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Again call out, saying

The angel who was speaking to Zechariah says these words.

#### My cities will once again overflow with goodness

The phrase "my cities" refers to the cities of Judah and represents the people who live in those cities. Yahweh speaks of the inhabitants of those cities again being prosperous as if goodness were a liquid that overflowed the cities, which are its containers. AT: "My cities will once again be prosperous" or "The people in the cities of Judah will once again be prosperous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh will again comfort Zion

Here the word "Zion" refers to the people who live in the city. AT: "Yahweh will again comfort the people in Zion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]

### Zechariah 01:18

#### I lifted up my eyes

The word "eyes" represents the person who looks. AT: "I looked up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### These are the horns that have scattered Judah, Israel, and Jerusalem

Horns were often used as a symbol for military power. Here they symbolize the powerful nations that had conquered the kingdoms of Israel. The words "Judah, Israel, and Jerusalem" represent the people who lived in those places. AT: "These horns represent the nations that have scattered the people of Judah, Israel, and Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Zechariah 01:20

#### craftsmen

"blacksmiths" or "metalworkers"

#### these people

This refers to the four craftsmen.

#### These are the horns that scattered Judah

The horns symbolize the powerful nations that had conquered the kingdoms of Israel. The word "Judah" represents the people who lived in Judah. See how you translated a similar phrase in [Zechariah 1:19](./18.md). AT: "These horns represent the nations that scattered the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that no man would lift up his head

The nations oppressing the people of Judah severely is spoken of as if no person in Judah was able to raise his head. AT: "and caused them to suffer greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to cast down the horns of the nations that lifted up a horn against the land of Judah

Yahweh speaks of the nations using their military power to conquer Judah as if the nations had lifted up their horns. He speaks of these four craftsmen destroying the military power of these nations as if the craftsmen threw those horns to the ground. AT: "to destroy the power of the nations who used their military might against the land of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to cast down the horns of the nations that lifted up a horn

"to cast down the horns that the nations had lifted up"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Zechariah 01:intro

#### Zechariah 01 General Notes ####

####### Structure and formatting #######

This chapter is written in prose mainly with imagery used throughout to portray Zechariah's vision given by the Lord. 

Some translations prefer to set apart quotations. The ULB and many other English translations indent lines 1:3-6, 14-17, which are extended quotations.

####### Special concepts in this chapter #######

######## Visions ########
This book contains a number of visions given to Zechariah, so the images are not ones Zechariah actually saw but were given to him in a vision or dream. It is important for each of these visions to keep their meanings and not be interpreted to mean any specific thing. 

####### Other possible translation difficulties in this chapter #######

######## Date ########
Zechariah uses two separate dates in this first chapter. When compared to the book of Haggai, Zechariah's prophecy was proclaimed just a few weeks after Haggai. However, they prophesied in two different places: Haggai was in Jerusalem and Zechariah was somewhere outside of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Zechariah 01:01 Notes](./01.md)__
* __[Zechariah intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Zechariah 02

### Zechariah 02:01

#### I lifted up my eyes

The word "eyes" represents the person who looks. AT: "I looked up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### measuring line

a rope with a certain length that a person would use to measure buildings or large sections of land

#### So he said to me

"So the man with the measuring line said to me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Zechariah 02:03

#### another angel went out to meet him

This angel is a new participant who has not appeared before this verse. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### The second angel said to him

"The second angel said to the angel who had talked with me"

#### Jerusalem will sit in the open country ... beasts within her

The phrase "will sit in the open country" translates a word that refers to a city that has no walls. There will be so many inhabitants in the city that it will be too large to have walls around it. AT: "Jerusalem will not have walls around it ... beasts within the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I ... will become for her a wall of fire around her

People built walls around their cities for protection. Here Yahweh speaks of protecting Jerusalem as if he himself were a wall of fire around the city. AT: "I ... will protect the city, like a wall of fire around it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Zechariah 02:06

#### Up! Up!

These two words express urgency and add emphasis to the following command. The words can be translated with an expression that communicates urgency in your language. AT: "Run! Run!" or "Hurry! Hurry!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the land of the north

This refers to Babylon.

#### I have scattered you like the four winds of the skies

The phrase "the four winds of the skies" means "in every direction." Yahweh compares causing the people to live in many different countries with the way that the wind can blow from any direction. AT: "I have scattered you in all directions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### you who live with the daughter of Babylon

The phrase "daughter of Babylon" refers to the city of Babylon. Yahweh speaks of the city as if it were a daughter. AT: "you who live in Babylon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]

### Zechariah 02:08

#### General Information:

Zechariah begins to speak and tells how Yahweh is sending him to judge the nations who have plundered Jerusalem.

#### plundered you

The word "you" refers to Jerusalem.

#### for whoever touches you

The word "touches" refers to a touch meant to harm. AT: "for whoever harms you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the apple of God's eye

The apple of an eye refers to the pupil of the eye, which is one of the most sensitive parts of the body. The idiom "apple of the eye" refers to something that is most valuable. Here it means that God greatly values Jerusalem. AT: "what is most valuable to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I myself will shake my hand over them

Raising one's hand against another person is a gesture of hostility. Here it is a symbolic action that means that God will attack those who harm Jerusalem. AT: "I myself will fight against them" or "I myself will attack them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### they will be plunder for their slaves

The word "plunder" can be translated with a verb. AT: "their slaves will plunder them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Zechariah 02:10

#### Sing for joy, daughter of Zion

"Zion" is the same as "Jerusalem." The prophet speaks of the city as if it is a daughter. Possible meanings are 1) Zechariah personifies the city as a person who can sing. AT: "Sing for joy, Zion" or 2) the phrase "daughter of Zion" is a metonym for the people who live in the city. AT: "Sing for joy, people of Zion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I myself am about to come and encamp among you

"I myself am about to come and live among you." To "encamp" means to set up and use a camp.

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### great nations will join themselves to Yahweh

Zechariah speaks of the people of great nations becoming Yahweh's people and worshiping him as if they were joining themselves to Yahweh. AT: "the people of great nations will become the people of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in that day

"at that time"

#### I will encamp in the midst of you

"I will live among you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### Zechariah 02:12

#### Yahweh will inherit Judah as his rightful possession

Zechariah speaks of Yahweh claiming Judah as his own land as if Judah were something that Yahweh inherits as a permanent possession. AT: "Yahweh will claim Judah as his rightful possession" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### all flesh

Here the word "flesh" represents all humanity. AT: "all people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he has been roused

Zechariah speaks of Yahweh beginning to act as if someone had roused Yahweh from inactivity. It is implied that this action refers to his returning to Jerusalem. AT: "he is coming" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from out of his holy place

Here "his holy place" refers to heaven, and not to the temple in Jerusalem. AT: "from his holy place in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Zechariah 02:intro

#### Zechariah 02 General Notes ####

####### Structure and formatting #######

This chapter is introduced in prose with imagery used in the rest of the chapter to portray Zechariah's third vision about measuring lines given by the Lord. 

Some translations prefer to set apart quotations. The ULB and many other English translations indent the lines of 2:4-13, which are extended quotations.

####### Special concepts in this chapter #######

######## Visions ########

This book contains a number of visions given to Zechariah so the images are not ones Zechariah actually saw but were given to him in a vision or dream. It is important for each of these visions to keep their meanings and not be interpreted to mean any specific thing. Please be careful to translate each of the terms in your language.

####### Important figures of speech in this chapter #######

######## "This is Yahweh's declaration" ########
This phrase is used several times in this chapter. The UDB often translates this as "Yahweh says." 
##### Links: #####

* __[Zechariah 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Zechariah 03

### Zechariah 03:01

#### General Information:

Yahweh shows Zechariah a vision of Joshua the priest.

#### Satan was standing at his right hand to accuse him of sin

"Satan was standing at Joshua's right side, ready to accuse Joshua of sin"

#### Is this not a brand pulled from the fire?

The angel of Yahweh asks this rhetorical question to emphasize the positive answer that it anticipates. This can be translated as a statement. AT: "Joshua is a brand pulled from the fire." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### a brand pulled from the fire

A brand is a burning piece of wood. The angel of Yahweh speaks of Joshua being rescued from captivity in Babylon as if he were a piece of wood that someone pulls from a fire before the wood is completely burned. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Joshua was dressed in filthy garments

In this vision "filthy garments" are symbolic of sinfulness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Zechariah 03:04

#### those who stood before him

The word "him" refers to the angel. The phrase refers to other angels who were present.

#### Look

The word "look" here adds emphasis to what follows.

#### I have caused your iniquity to pass from you

Since Joshua's garments were symbolic of his sinfulness, by removing his garments, the angel removed Joshua's iniquity. Causing iniquity to pass from him is an idiom that means that he had removed Joshua's iniquity. AT: "I have removed your iniquity from you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### dress you in fine clothing

Here fine clothing symbolizes righteousness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### Let them put

Here the word "them" refers to the other angels who were present.

#### turban

a long piece of cloth wrapped around the head

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]

### Zechariah 03:06

#### solemnly commanded Joshua

"commanded Joshua in a very serious manner"

#### If you will walk in my ways, and if you will keep my commandments

These two phrases mean basically the same thing. Yahweh speaks of obeying him as if the person were walking along Yahweh's paths. AT: "If you will obey me and keep my commandments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will govern my house and guard my courts

Here the word "house" is a metonym for the temple, while the word "courts" refers to the courtyards around the temple. Together the phrases mean that Joshua will have authority over the whole temple complex. AT: "you will have authority over my temple and its courtyards" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to go and come among these who stand before me

The phrase "to go and come among" is an idiom that means that Joshua will be a part of this group and have the same privilege as they do of access to Yahweh. AT: "to come before me as these who stand here do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]

### Zechariah 03:08

#### General Information:

The angel of Yahweh continues to speak to Joshua.

#### your companions who live with you

This phrase refers to other priests who would serve in the temple under the leadership of Joshua. AT: "the other priests who live with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### For these men are a sign

Here the word "sign" refers to something that communicates a special meaning to those who see it. Yahweh speaks of the priests serving in the temple as being this sign that shows that Yahweh will bring his servant.

#### my servant the Branch

The word "Branch" refers to a messianic figure that would serve as king over Yahweh's people. Yahweh speaks of this person as if he were a branch that grows out from a tree. Since the word "Branch" is a title, it should be translated with an equivalent word in your language. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the stone that I have set before Joshua

Here the word "stone" likely refers to a precious stone or jewel.

#### There are seven eyes on this single stone

The sides or facets of the stone that reflect light are spoken of as if they are eyes. AT: "There are seven sides on this single stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will engrave an inscription

It is implicit that he will engrave the inscription on the stone. AT: "I will engrave an inscription on the stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### engrave

"carve"

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:3](../01/01.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I will remove the sin from this land in one day

Here the word "land" represents the people who live in the land. AT: "I will remove the sin of the people from this land in one day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Zechariah 03:10

#### In that day

"At that time"

#### each man will invite his neighbor to sit under his vine and under his fig tree

Both the "vine" and the "fig tree" are symbols of prosperity. This phrase describes actions in which people live prosperously and in peace. AT: "because they will be at peace, each person will invite his neighbor to come and sit under his vine and his fig tree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]

### Zechariah 03:intro

#### Zechariah 03 General Notes ####

####### Structure and formatting #######

This chapter is introduced in prose and shares the fourth vision, which is the priest in dirty clothes. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]) 

Some translations prefer to set apart quotations. The ULB and many other English translations indent the lines of 3:7-9, which is an extended quotation.

####### Difficult concepts in this chapter #######

######## Visions ########
It is important for each of these visions to keep their meanings and not be interpreted to mean any specific thing.  

####### Other possible translation difficulties in this chapter #######

######## The high priest ########

This chapter seems to refer to a particular person, Joshua the high priest. However, little is known about him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]])

##### Links: #####

* __[Zechariah 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Zechariah 04

### Zechariah 04:01

#### roused me like a man roused from his sleep

Zechariah compares the way in which the angel interrupted his being in deep thought with the way someone would awaken another person from sleep. AT: "caused me to become more alert like a man awakened from his sleep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### lamp wicks

the parts of a lamp that are lit on fire

#### the left side

The ellipsis in this phrase may be supplied from the previous phrase. AT: "the left side of the bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]

### Zechariah 04:04

#### Do you not know what these things mean?

The angel asks this rhetorical question to emphasize that Zechariah should have known what these things mean. The question can be translated as a statement. AT: "Surely you know what these things mean." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Zechariah 04:06

#### Connecting Statement:

The angel who speaks with Zechariah continues to explain the vision.

#### Not by might nor by power

Since there is no verb in this phrase, it may be necessary in your language to supply one. AT: "You will not succeed by might nor by power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Not by might nor by power

Possible meanings are 1) that the words "might" and "power" mean basically the same thing and emphasize the greatness of Zerubbabel's strength or 2) that the word "might" refers to military strength and the word "power" refers to Zerubbabel's physical ability. AT: "Certainly not by your own strength" or "Not by military strength nor by your own power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### What are you, great mountain? Before Zerubbabel you will become a plain

This is a metaphor in which Yahweh speaks of the obstacles that Zerubbabel will face as if they were a large mountain. He asks this rhetorical question to emphasize that these obstacles pose no threat to Zerubbabel's success. The question can be translated as a statement. AT: "You are nothing, great mountain! Zerubbabel will cause you to become a plain" or "Although obstacles may appear as large as mountains, Zerubbabel will overcome them as easily as one walks upon level ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### he will bring out the top stone

The top stone is the last stone placed when building something. This refers to the top stone of the temple. AT: "he will bring out the top stone of the temple" or "he will complete the construction of the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to shouts of 'Grace! Grace to it!'

Possible meanings are 1) the word "grace" refers to God's grace and the people are requesting that God bless the completed temple. AT: "while people shout, 'May God bless it! May God bless it!'" or 2) the word "grace" refers to beauty and the people are declaring how beautiful the completed temple is. AT: "while people shout, 'Beautiful! It is beautiful!'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md)]]

### Zechariah 04:08

#### Connecting Statement:

The angel who speaks with Zechariah continues to explain the vision.

#### The word of Yahweh came to me, saying, "The hands

This idiom is used to introduce a special message from God. AT: "Yahweh gave a message to me. He said, 'The hands" or "Yahweh spoke this message to me: 'The hands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The hands of Zerubbabel have laid ... his hands will bring it to completion

Here the word "hands" represents Zerubbabel. AT: "Zerubbabel has laid ... he will bring it to completion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the foundation of this house

The word "house" represents the temple. AT: "the foundation of this temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Who has despised the day of small things? These people will rejoice

Zechariah uses this rhetorical question to speak specifically about those who have "despised the day of small things." It can be translated as a statement. AT: "Those who have despised the day of small things will rejoice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the day of small things

"the time of small things." This phrase refers to the time when the people were building the temple and appeared to be making little progress. AT: "the time when progress was slow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### plumb stone

This refers to an instrument made with a heavy object attached to the end of a string that builders used to ensure that the walls of buildings were straight.

#### These seven lamps ... these two olive trees

These phrases refer to the lamps and olive trees that Zechariah saw in [Zechariah 4:2-3](./01.md).

#### These seven lamps are the eyes of Yahweh that roam over the whole earth

The seven lamps symbolize the eyes of Yahweh, but they are not literally the eyes of Yahweh. The angel speaks of Yahweh seeing everything that happens on the earth as if his eyes roamed over the whole earth. AT: "These seven lamps represent the eyes of Yahweh, who sees everything that happens on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]

### Zechariah 04:12

#### What are these two olive branches

Here Zechariah changes his question and asks about branches that are connected to the two olive trees.

#### the two gold pipes

These pipes were not mentioned in the previous description of Zechariah's vision. It is possible that they are connected to the bowl on top of the lampstand and provide the oil with which the lampstand burns.

#### golden oil

Here "golden" refers to the color of the oil and does not mean that the oil was made of gold.

#### Do you not know what these are?

The angel asks this rhetorical question to emphasize that Zechariah should have known what these things mean. This question can be translated as a statement. AT: "Surely you know what these are." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Zechariah 04:14

#### These are the sons of fresh olive oil

The branches symbolize these people, but they are not literally the people. AT: "These two branches represent the sons of fresh olive oil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the sons of fresh olive oil

This idiom means that these men have been anointed with fresh olive oil. A person who is anointed is one whom Yahweh has chosen or appointed for a special duty. AT: "the anointed men" or "the men whom Yahweh has appointed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### who stand before the Lord

The idiom "stand before" means to be in a person's presence and to serve him. AT: "who serve the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Zechariah 04:intro

#### Zechariah 04 General Notes ####

####### Structure and formatting #######

This chapter is written mainly in prose about the fifth vision, which is about the golden lampstand and olive trees. 

####### Special concepts in this chapter #######

######## Visions ########
This chapter shows a conversation between Zechariah and the angel of Yahweh. It is important for each of these visions to keep their meanings and not be interpreted to mean any specific thing. 

##### Links: #####

* __[Zechariah 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Zechariah 05

### Zechariah 05:01

#### Then I turned

The word "I" refers to Zechariah.

#### lifted my eyes

The word "eyes" represents the person who looks. AT: "looked up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### behold

The word "behold" here shows that Zechariah was surprised by what he saw.

#### twenty cubits long and ten cubits wide

A cubit is 46 centimeters. AT: "9.2 meters long and 4.6 meters wide" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Zechariah 05:03

#### General Information:

The angel continues to speak with Zechariah.

#### This is the curse

The word "this" refers to the scroll. The scroll is a metonym for what is written on the scroll. AT: "On this scroll is the curse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### that goes out over the surface of the whole land

The phrase "the surface of the whole land" refers to every place within the land. It is implied that the curse will apply to every person who lives in the land. AT: "that is upon every person within the whole land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### every thief will be cut off ... everyone who swears a false oath will be cut off

Yahweh removing these people from the land is spoken of as if he were cutting them off, like a person would cut a branch from a tree. This can be stated in active form. AT: "Yahweh will cut off every thief ... Yahweh will cut off everyone who swears a false oath" or "Yahweh will remove every thief from the land ... Yahweh will remove from the land everyone who swears a false oath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what it says on the one side ... what it says on the other side

"what the scroll says on one side ... what the scroll says on the other side"

#### I will send it out

"I will send out the curse"

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:3](../01/01.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### consume its timber and stones

The curse destroying the houses of the thief and of the one who swears falsely is spoken of as if the curse would consume the building materials that people had used to build the houses. AT: "destroy its wood and stones" or "completely destroy it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]

### Zechariah 05:05

#### Raise your eyes

The word "eyes" represents the person who looks. AT: "Look up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### This is a basket containing an ephah that is coming

An "ephah" is a unit of measurement for dry materials and is equal to 22 liters. Here the word is a metonym for the container that would hold an ephah of dry material. AT: "This is a measuring basket that is coming" or "This is a large container that is coming" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### This is their iniquity in the whole land

The basket symbolizes the people's iniquity, but it is not literally their iniquity. AT: "This basket represents the iniquity of the people throughout the whole land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### a lead covering was lifted off the basket

This can be stated in active form. AT: someone lifted a lead covering off the basket" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### there was a woman under it sitting in it

"there was a woman under the lead covering sitting in the basket"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]

### Zechariah 05:08

#### This is Wickedness

The woman represents wickedness. AT: "This woman represents wickedness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### He threw her ... he threw the lead cover

"He thrust her ... he forced the lead cover." The word "threw" indicates the force with which the angel did these things. He did not literally throw the woman or the cover.

#### I lifted my eyes

Here the word "eyes" represents the person who sees. AT: "I looked up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### wind was in their wings

This idiom means that they were flying. AT: "they were flying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they had wings like a stork's wings

A stork is a type of large bird that has a wingspan of two to four meters. Zechariah compares the size of the women's wings with the size of the stork's wings.

#### They lifted up the basket between earth and heaven

The words "earth" and "heaven" form a merism that refer to the sky. It is implicit that the two women flew away with the basket. AT: "They lifted the basket up into the sky and flew away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Zechariah 05:10

#### To build a temple in the land of Shinar for it

The ellipsis can be supplied from the previous verse. AT: "They are taking the basket to the land of Shinar to build a temple for it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the basket will be set there

This can be stated in active form. AT: "they will set the basket there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on its prepared base

The words "prepared base" refer to a pedestal or other kind of fixture upon which they will place the basket.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shinar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shinar.md)]]

### Zechariah 05:intro

#### Zechariah 05 General Notes ####

####### Structure and formatting #######

This chapter contains the next two visions. One is about a flying scroll and one is about the basket filled with iniquity. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]])

##### Links: #####

* __[Zechariah 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Zechariah 06

### Zechariah 06:01

#### lifted my eyes

Here the word "eyes" represents the person who sees. AT: "looked up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### between two mountains; and the two mountains were made of bronze

Since the second phrase describes the mountains in the first phrase, the two phrases may be combined. AT: "between two bronze mountains"

#### The first chariot had red horses

It is implicit that the horses were pulling the chariots. AT: "The first chariot had red horses pulling it" or "Red horses were pulling the first chariot" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Zechariah 06:05

#### These are the four winds of heaven

The chariots symbolize the four winds of heaven, but they are not literally the four winds. AT: "These chariots represent the four winds of heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the four winds of heaven

This phrase refers to the four directions from which the wind blows: north, east, south, and west. However, some modern versions interpret this Hebrew expression to mean "four spirits."

#### standing before the Lord of all the earth

The idiom to "stand before" means to be in a person's presence and to serve him. See how you translated this in [Zechariah 4:14](../04/14.md). AT: "serving the Lord of all the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the white horses are going out to the west country

Some modern versions interpret this Hebrew phrase to mean "the white horses are going out after them," that is, following the black horses to the north country.

#### the white horses are ... the spotted gray horses are

Here the horses represent the chariots that they pull. AT: "the chariot with the white horses is ... the chariot with the spotted gray horses is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Zechariah 06:07

#### he called out to me

"the angel called out to me"

#### Look at the ones

"Look at the black horses"

#### they will appease my spirit concerning the north country

The words "my spirit" refer to Yahweh, so many translations change this to read "Yahweh's spirit." Possible meanings are 1) the word "spirit" represents Yahweh's emotions and appeasing his spirit means that the chariots will cause Yahweh no longer to be angry with the north country AT: "they will calm my anger concerning the north country" or 2) the word "spirit" represents Yahweh's presence and the chariots will cause the Jews who live in the north land to experience Yahweh's blessings. AT: "they will cause my spirit to rest in the north country" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Zechariah 06:09

#### the word of Yahweh came to me, saying, "Take

This idiom is used to introduce a special message from God. AT: "Yahweh gave a message to me. He said, 'Take" or "Yahweh spoke this message to me: 'Take" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Heldai, Tobijah, and Jedaiah ... Jehozadak

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### this same day

"today"

#### take the silver and gold, make a crown

"make a crown with the silver and gold"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zephaniah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zephaniah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]

### Zechariah 06:12

#### Speak to him and say

"Speak to Joshua and say"

#### his name is Branch

The word "Branch" refers to a messianic figure that would serve as king over Yahweh's people. Yahweh speaks of this person as if he were a branch that grows out from a tree. Since the word "Branch" is a title, it should be translated with an equivalent word in your language. See how you translated this name in [Zechariah 3:8](../03/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He will grow up where he is

The phrase "grow up" refers to the growth of a plant, and so continues the metaphor of this person as a "Branch." This likely refers to this person appearing or coming into power as the one who would supervise the rebuilding of the temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He will be a priest on his throne

Possible meanings are 1) the "Branch" will be both priest and king or 2) the "Branch" will be king, and another person will be a priest who will share the royal power. AT: "There will be a priest upon his throne"

#### he will bear a counsel of peace between the two

The words "the two" refer to the roles of king and priest. The meaning of this phrase depends upon the meaning of the previous phrase. Possible meanings are 1) the "Branch" will faithfully carry out his duties as both priest and king and not forsake one in order to fulfill the other or 2) the "Branch" who serves as king and the other person who serves as a priest will each carry out their duties faithfully and they will work together in peace.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Zechariah 06:14

#### The crown will given

This can be stated in active form. AT: "You will give the crown" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Heldai, Tobijah, Jedaiah ... Hen

These are the names of men. See how you translated these in [Zechariah 6:10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### for Hen son of Zephaniah as a memorial

Some modern versions interpret this phrase as "as a memorial to the generosity of the son of Zephaniah" or "as a memorial to the one who is gracious, the son of Zephaniah." Also, some modern versions interpret the name "Hen" as meaning the name "Josiah."

#### those who are far off

This refers to the Israelites who remain in Babylon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so you will know

The word "you" is plural and refers to the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### truly listen to the voice of Yahweh your God

Here to "listen" means to obey and the word "voice" represents the words that Yahweh speaks. AT: "truly obey what Yahweh your God says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zephaniah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zephaniah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Zechariah 06:intro

#### Zechariah 06 General Notes ####

####### Structure and formatting #######

This chapter is written mainly in prose and tells the last vision of the four chariots in the first part of the chapter. 

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 6:12-13.

####### Special concepts in this chapter #######

######## Crown ########
The second part of the chapter is about a crown made for the high priest. This is an actual person, but the meaning of the word "branch" should be translated as his name. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]])

####### Other possible translation difficulties in this chapter #######

######## Meaning of the visions ########
The visions are stated and even when the prophet asked for an explanation, their true meaning is often obscure. This uncertainty should remain in your translation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Zechariah 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Zechariah 07

### Zechariah 07:01

#### on the fourth day

"on day 4" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Kislev (which was the ninth month)

"Kislev" is the ninth month of the Hebrew calendar. The fourth day of Kislev is near the end of November on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the word of Yahweh came to Zechariah

This idiom is used to introduce a special message from God. AT: "Yahweh gave a message to Zechariah" or "Yahweh spoke this message to Zechariah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Sharezer and Regem-Melek

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### beg

Here the word "beg" means to plead or ask urgently.

#### before the face of Yahweh

Here "face" is a metonym for Yahweh's presence. AT: "in the presence of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They spoke ... they said

The word "they" refers to Sharezer and Regem Melek.

#### Should I mourn in the fifth month

"Should I mourn in month 5." The assumed knowledge is that the Jewish people fasted during a part of the fifth month of the Hebrew calendar because this is when the Babylonians destroyed the temple in Jerusalem. The fifth month is during the last part of July and the first part of August on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### by means of a fast

"by fasting"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]

### Zechariah 07:04

#### the word of Yahweh of hosts came to me, saying, "Speak

This idiom is used to introduce a special message from God. AT: "Yahweh of hosts gave me a message. He said, 'Speak" or "Yahweh of hosts spoke this message to me: 'Speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### in the fifth and in the seventh month

"in months 5 and 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### in the fifth

The word "month" can be supplied in translation. AT: "in the fifth month" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### in the seventh month

The assumed knowledge is that the Jews mourned during a part of the seventh month of the Hebrew calendar because in this month the remaining Jews in Jerusalem fled to Egypt after the murder of Gedaliah, whom the king of Babylon appointed as governor over Judah. The seventh month is during the last part of September and the first part of October on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### for these seventy years

The assumed knowledge is that the people of Israel had been slaves in Babylon for 70 years. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### were you truly fasting for me?

This question is asked to make the people think about what their real reason for fasting had been. It can be translated as a statement. AT: "you were not really fasting for me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### When you ate and drank

Possible meanings are 1) when they feasted and drank when celebrating religious festivals or 2) when they ate and drank whenever they were not fasting.

#### did you not eat and drink for yourselves?

This question is used to make the people think about whether they were honoring Yahweh when they ate and drank. This can be translated as a statement. AT: "it was for yourselves that you ate and drank." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Were these not the same words ... to the west?

Yahweh uses a question to scold the people. This question can be translated as a statement. AT: "These are the same words ... to the west." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### by the mouth of the former prophets

Here "mouth" is a metonym for the words spoken by the mouth. AT: "by the words of the former prophets" or "through the former prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### inhabited

"lived in"

#### foothills

hills at the base of a mountain or mountain range

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prosper.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prosper.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]

### Zechariah 07:08

#### The word of Yahweh came to Zechariah, saying, "Yahweh

This idiom is used to introduce a special message from God. AT: "Yahweh gave a message to Zechariah. He said, 'Yahweh" or "Yahweh spoke this message to Zechariah: 'Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Judge with true justice, covenant faithfulness, and mercy

The abstract nouns "justice," "faithfulness," and "mercy" can be stated as adjectives. AT: "When you judge, be just, faithful to the covenant, and merciful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Let each man do this

The word "this" refers to how a person should judge.

#### widow

a woman whose husband has died

#### orphan

a child whose parents have died

#### foreigner

someone who travels from his own land to a different land

#### let none of you plot any harm against another in your heart

Here "heart" represents the thoughts of a person. AT: "you must not make plans to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Zechariah 07:11

#### set their shoulders stubbornly

This is an image of an ox refusing to allow its owner to put a yoke on its shoulders. This metaphor represents the people being stubborn. AT: "became stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They stopped up their ears so they would not hear

This is an image of people putting something into their ears so they would not hear the message from Yahweh. This metaphor represents the people not being willing to hear and obey. AT: "They refused to listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They made their hearts as hard as rock so they would not hear the law or the words of Yahweh of hosts

The people refusing to hear and obey Yahweh are compared to their being as unyielding as rock. Here the heart represents the will of a person. AT: "They stubbornly refused to hear the law or the words of Yahweh of hosts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### in earlier times

"in the past"

#### by the mouth of the prophets

Here the "mouth of the prophets" is a metonym for the words that the prophets speak. AT: "through the words of the prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Zechariah 07:13

#### I will scatter them with a whirlwind

Yahweh speaks of how he will scatter the people as if a whirlwind were scattering everything in its path. AT: "I will scatter them as a whirlwind scatters things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### whirlwind

a strong wind that spins very quickly as it moves and can cause damage

#### delightful land

"pleasant land" or "fruitful land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/waste.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/waste.md)]]

### Zechariah 07:intro

#### Zechariah 07 General Notes ####

####### Structure and formatting #######

This chapter starts about two years after the previous chapter and is written in prose. 

Some translations prefer to set apart quotations. The ULB and many other English translations indent the lines of 7:4-14, which is an extended quotation.

####### Special concepts in this chapter #######

######## Fasting ########
This chapter discusses fasting. People were asking the same questions as those from previous generations. The Israelites were asking these same questions before they were exiled from their land. 

##### Links: #####

* __[Zechariah 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Zechariah 08

### Zechariah 08:01

#### The word of Yahweh of hosts came to me, saying, "Yahweh

This idiom is used to introduce a special message from God. See how you translated this in [Zechariah 7:4](../07/04.md). AT: "Yahweh of hosts gave me a message. He said, 'Yahweh" or "Yahweh of hosts spoke this message to me, saying, 'Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### passionate

"jealous." Here the word "passionate" refers to Yahweh's strong desire to protect his people.

#### for Zion

Here "Zion" represents the people of Zion. AT: "for the people of Zion" or "for the people of Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with great anger

The implied information is that this anger is against the enemies of Zion. AT: "with great anger against her enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the mountain of Yahweh of hosts

The implied information is that this refers to Mount Zion, the location upon which the city of Jerusalem was built. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Zechariah 08:04

#### be in the streets of Jerusalem

"be living in Jerusalem"

#### in his hand because he has grown so old

People having the opportunity to grow old implies the city will be peaceful and prosperous for a long time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The streets of the city will be full

The public areas of the city will be full of people in their normal activities.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]

### Zechariah 08:06

#### If something seems impossible in the eyes of

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "If something does not appear to be possible to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the remnant of this people

"the people of Judah who survive"

#### should it also seem impossible in my eyes?

This question expects a negative answer in order to persuade his people to trust in his promises. It can be translated as a statement. AT: "it will surely be possible for me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### in my eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I am about to rescue my people

The implied information is that the people are in exile. "I am about to rescue my people of Judah who went into exile" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from the land of the sunrise and from the land of the setting sun

Possible meanings are 1) this is a poetic way of expressing specific countries to which the people were exiled. AT: "From the land to the east and from the land to the west" or 2) this is a merism that means from all directions. AT: "from all lands in every direction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### I will be their God in truth and in righteousness

This can be rewritten to remove the abstract nouns "truth" and "righteousness." AT: "I will be their God. I will be faithful to them and act toward them in a just manner" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Zechariah 08:09

#### when the foundation of my house was laid

This can be expressed in active form. AT: "when you were building the foundation of my house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Strengthen your hands

This is an idiom that means to be courageous for the work. AT: "Be strong and courageous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### For before those days

Here "those days" refers to the time the people of Judah started to rebuild the temple.

#### no crops were gathered in

"there were no crops to harvest"

#### there was no profit for either man or beast

It was useless for people and their animals to farm the land, because they got no food from it.

#### for anyone going or coming

This merism refers to all of life's activities everywhere that anyone went. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### I had set every person each against his neighbor

"I had turned everyone against each other"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Zechariah 08:11

#### But now it will not be as in former days, I will be with the remnant of this people

"But I will not treat the remnant of this people now as I did in former days"

#### in former days

"in the past." The implied information is that this refers to the time when the people started rebuilding the temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the remnant of this people

The implied information is that this is the remnant of the people who returned from exile. AT: "the people who returned from exile" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### seeds of peace will be sown

This can be expressed in active form. AT: "the people will safely sow seed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:3](../01/01.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### the earth will give its produce; the skies will give their dew

The earth and skies are spoken of as if they were persons giving what is needed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### inherit all these things

"to have all these things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Zechariah 08:13

#### You were an example to the other nations of a curse

The implied information is that the way Yahweh had allowed the temple to be destroyed and his people to be exiled had been used by other nations as an example of what it meant to be cursed by Yahweh. AT: "When I punished you, the other nations learned what happens when I curse a people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### house of Judah and house of Israel

The word "house" is a metonym for the family that lives in the house. In this case it refers to the people in the kingdoms of Judah and Israel. AT: "people of Judah and Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you will be a blessing

Possible meanings are 1) the implied information is that the people of Judah and Israel would be a blessing to the nations around them. AT: "you will be a blessing to the surrounding nations" or 2) the implied information is that the nations around them would see what it meant to be blessed by Yahweh. AT: when I bless you, the other nations will learn what happens when I bless a people" or 3) Yahweh will bless the people of Judah and Israel. AT: "I will give you many good things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### let your hands be strong

This is an idiom that means to be courageous for the work. AT: "be strong and courageous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### do harm to you

"punish you"

#### provoked my anger

"angered me"

#### did not relent

"did not decide to punish them less"

#### Jerusalem

This is a metonym for the people of Jerusalem. AT: "the people of Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### house of Judah and house of Israel

The word "house" is a metonym for the family that lives in the house. In this case it refers to the people in the kingdom of Judah. AT: "people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Zechariah 08:16

#### that you must do

"You" refers to the people of Judah.

#### Speak truth, every person with his neighbor

The abstract noun "truth" can be translated using the adjective "true." AT: "Everyone must say only true things to his neighbor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### his neighbor

Here "neighbor" means any person, not just someone who lives nearby.

#### Judge with truth, justice, and peace in your gates

This can be restated to remove the abstract nouns "truth," "justice," and "peace." AT: "When you are making decisions in your gates, judge in a way that is true and just and causes people to live peacefully with each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### in your gates

The assumed knowledge is that this refers to the places where judgment took place. AT: "in your places of judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### do not love false oaths

The implied information is that this refers to oaths taken in a court of law. AT: "do not approve when people tell lies in court cases" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Zechariah 08:18

#### the word of Yahweh of hosts came to me, saying, "Yahweh

This idiom is used to introduce a special message from God. See how you translated this in [Zechariah 7:4](../07/04.md). AT: "Yahweh of hosts gave me a message. He said, 'Yahweh" or "Yahweh of hosts spoke this message to me, saying, 'Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### came to me

Here "me" refers to Zechariah.

#### The fasts of the fourth month, the fifth month, the seventh month, and the tenth month

"The fasts of months 4, 5, 7, and 10" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### The fasts of the fourth month

The assumed knowledge is that the Jews mourned during a part of the fourth month of the Hebrew calendar because this is when the Babylonians broke through the walls of Jerusalem. The fourth month is during the last part of June and the first part of July on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### the fifth month

The assumed knowledge is that the Jewish people fasted during a part of the fifth month of the Hebrew calendar because this is when the Babylonians destroyed the temple in Jerusalem. The fifth month is during the last part of July and the first part of August on Western calendars. See how you translated this in [Zechariah 7:3](../07/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### the seventh month

The assumed knowledge is that the Jews mourned during a part of the seventh month of the Hebrew calendar because in this month the remaining Jews in Jerusalem fled to Egypt after the murder of Gedaliah, whom the king of Babylon appointed as governor over Judah. The seventh month is during the last part of September and the first part of October on Western calendars. See how you translated this in [Zechariah 7:5](../07/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### the tenth month

The assumed knowledge is that the Jews mourned during a part of the tenth month of the Hebrew calendar because this is when the Babylonians began their siege against Jerusalem. The tenth month is during the last part of December and the first part of January on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### times of joy, gladness, and happy festivals

The abstract nouns "joy" and "gladness" can be translated using adjectives. AT: "joyful and glad times, with happy festivals" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the house of Judah

The word "house" is a metonym for the family that lives in the house. In this case it refers to the people in the kingdom of Judah, which included the descendants of Judah and Benjamin. AT: "the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### love truth and peace

The abstract nouns "truth" and "peace" can be translated using adjectives. AT: "love what is truthful and peaceful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]

### Zechariah 08:20

#### People will come again

The implied information is that Jerusalem is where the people will come. AT: "People will come again to Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### will go to another city

This is a metonym for the people in the other city. AT: "will go to the people of another city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### beg

Here the word "beg" means to plead or ask urgently.

#### before the face of Yahweh

Here "face" is a metonym for Yahweh's presence. See how you translated this in [Zechariah 7:2](../07/01.md). AT: "in the presence of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### seek Yahweh of hosts

Those who want to know Yahweh and please him are spoken of as if they are literally seeking to find Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### mighty nations

This is a metonym for the people in the mighty nations. AT: "people of mighty nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Zechariah 08:23

#### will grasp the hem of your robe

The implied information is that the foreigners will grab their robe to get their attention. AT: "will grasp the hem of your robe to get your attention" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Let us go with you

The implied information is that people of God are going to Jerusalem. AT: "Let us go to Jerusalem with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### God is with you

"God is with you people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]

### Zechariah 08:intro

#### Zechariah 08 General Notes ####

####### Structure and formatting #######

This chapter is a series of sayings from Yahweh of hosts. Each saying is an encouraging note for those returning from the exile to the land of Judah and Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]])

##### Links: #####

* __[Zechariah 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Zechariah 09

### Zechariah 09:01

#### This is a declaration of Yahweh's word concerning

"This is Yahweh's message about"

#### the land of Hadrak and Damascus

Here "Hadrak" and "Damascus" refer to the people who live in those places. AT: "the people of the land of Hadrak and the city Damascus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hadrak

The location of Hadrak is unknown today.

#### its resting place

"the resting place of the people of Hadrak"

#### for the eyes of all humanity and all the tribes of Israel are toward Yahweh

Some versions translate this as "for Yahweh's eye is on all mankind and on the tribes of Israel."

#### the eyes of all humanity and all the tribes of Israel are toward Yahweh

Here "eyes" refers to what they look at. AT: "all humanity and all the tribes of Israel look toward Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Hamath

This refers to the people who live in that land. AT: "the people of the land of Hamath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Tyre and Sidon

This refers to the people who live in those cities. AT: "the people of Tyre and Sidon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for they are very wise

Possible meanings are 1) the people are wise for looking at Yahweh for help or 2) Zechariah did not really mean that the people of Hamath were wise and was using irony. AT: "though they think they are very wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Zechariah 09:03

#### built herself a stronghold

Here the city of Tyre is pictured as a woman. AT: "built a strong fortress" or "built a high wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### heaped up silver like dust and refined gold like mud in the streets

Yahweh exaggerates to emphasize how rich Tyre was. AT: "accumulated silver and gold as much as soil in the streets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Look! The Lord will dispossess her

Here "Look!" tells the reader to pay attention to the important statement that follows. AT: "Pay attention! The Lord will take away Tyre's possessions"

#### destroy her strength on the sea

Tyre's "strength on the sea" refers to the ships that were used for commerce and conquest. AT: "destroy Tyre's ships in which men fight on the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so she will be devoured by fire

This can be stated in active form. AT: "and enemies will burn the city to the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Zechariah 09:05

#### Ashkelon ... Gaza ... Ekron, her hopes

These cities each refer to the people who live in them. AT: "The people of Ashkelon ... the people of Gaza ... the hopes of the people of Ekron" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will see

"will see Tyre be destroyed"

#### Strangers will make their homes in Ashdod

"Foreigners will take over Ashdod and live there"

#### I will cut off the pride of the Philistines

Here "cut off" is an idiom that means to stop their pride. AT: "I will make the Philistines to be proud of themselves no longer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I will remove their blood from their mouths and their abominations from between their teeth

Here "blood" is a metonym for meat with blood in it, and "abominations" is a metonym for meat offered to idols. AT: "I will no longer allow them to eat meat that still has blood in it, and I will forbid them to eat food that they offered to idols" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]

### Zechariah 09:08

#### I will camp around my land

God is speaking about himself as if he were an army that was protecting his land. AT: "I will protect my land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for now

"For at that time"

#### I see with my own eyes

Here "my own eyes" represent Yahweh's personal attention. AT: "I will personally watch over my land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]

### Zechariah 09:09

#### General Information:

Yahweh appears to be the speaker in verses 9-13.

#### Shout with great joy, daughter of Zion! Shout with happiness, daughter of Jerusalem!

These two sentences mean the same thing and intensify the command to rejoice. Yahweh is speaking to the people of Jerusalem as if they were present, but they were not there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### daughter of Zion ... daughter of Jerusalem

"Zion" is the same as "Jerusalem." The prophet speaks of the city as if it is a daughter. See how you translated "daughter of Zion" in [Zechariah 2:10](../02/10.md).

#### Behold!

This alerts the reader to pay special attention to the surprising statement that follows. AT: "Pay attention!" or "Here is a surprising fact!"

#### Your king is coming to you with righteousness and is rescuing you

"Your king is righteous and is coming to rescue you"

#### on a donkey, on the colt of a donkey

These two phrases mean basically the same thing and refer to one animal. The second phrase clarifies that this is a young donkey. AT: "on a young donkey" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### cut off the chariot from Ephraim

Here "cut off" is an idiom that means to destroy. AT: "destroy the chariots in Israel that are used for battle"

#### the horse from Jerusalem

The references to "chariot" and "bow" means that this refers to horses used in battle. This can be made explicit. AT: "the warhorses in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the bow will be cut off from battle

Here the bow represents all weapons used in warfare. AT: "all weapons of war will be destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### for he will speak peace to the nations

Here the action of announcing peace represents the action of making peace. AT: "for your king will bring peace to the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his dominion will be from sea to sea, and from the River to the ends of the earth!

The phrases "sea to sea" and "from the River to the ends of the earth" mean the same thing and can be combined. AT: "his kingdom will be over all the earth!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the River

This probably refers to the Euphrates River.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Zechariah 09:11

#### General Information:

Yahweh appears to be the speaker in verses 9-13.

#### As for you ... Zion

Here "you" is singular, and continues to refer to the city of Jerusalem, also called "Zion."

#### the pit where there is no water

This dry pit represents the exile in Babylon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Return to the stronghold

Jerusalem is spoken of as a place of safety. AT: "Come back to your nation where you will be safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### prisoners of hope

This expression refers to the Israelites in exile who were still trusting in God to rescue them. AT: "prisoners who still hope in Yahweh"

#### return double to you

"return to you twice as much as was taken from you"

#### I have bent Judah as my bow

The people of Judah are referred to as if they were a bow carried by God into battle. Here "Judah" refers to the people of that nation. AT: "I will cause the people of Judah to be like my bow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### filled my quiver with Ephraim

Yahweh speaks of the people of Israel, the northern kingdom, as if they were arrows that he would shoot at his enemies. A quiver is a bag that holds a soldier's arrows. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I have roused your sons, Zion, against your sons, Greece

God is speaking to the people of two different nations at the same time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Zechariah 09:14

#### General Information:

In verses 14-16, Zechariah describes how Yahweh will rescue Israel from their enemies.

#### will appear to them

The word "them" refers to God's people. AT: "will be seen in the sky by his people" or "will come to his people"

#### his arrows will shoot out like lightning!

The Israelites sometimes thought of lightning bolts as arrows that God shot. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### blow the trumpet

The trumpets were rams' horns. People blew into them to give signals in battle and on other occasions. Here the trumpet is blown as a military signal.

#### will advance with the storms from Teman

Team was located to the south of Judah. The Israelites sometimes thought of God as traveling on violent storms coming from the south. AT: "will march from Teman with the storm winds"

#### they will devour them

"the people of Judah will devour their enemies"

#### will devour

To completely defeat enemies is spoken of as devouring them as a wild animal eats its prey. AT: "will completely defeat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### defeat the stones of the slings

Slings to throw stones were a common weapon in the days of Zechariah. Here the "stones of the slings" represent the soldiers who were using them to attack Israel. AT: "defeat the enemies who attack them with slings and stones" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Then they will drink and shout like men drunk on wine

The people of Judah will shout and celebrate their victory over their enemies as if they were noisy drunks. AT: "Then they will shout and celebrate their victory as loudly as if they were drunk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they will be filled with wine like bowls

This probably refers to the bowls that the priests used to carry animal's blood to the altar. AT: "they will be as full of wine as the basins with which priests carry blood to the altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### like the corners of the altar

Altars had projecting corners that were drenched in animal blood. AT: "they will be drenched as the corners of the altar are covered in blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Zechariah 09:16

#### General Information:

In verses 14-16, Zechariah describes how Yahweh will rescue Israel from their enemies.

#### God will rescue them ... as the flock of his people

The people of Israel are spoken of as if they are God's sheep that he cares for and protects. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### They are the jewels of a crown

The people of Israel are spoken of as if they were the expensive jewels in the crown of a king that show how glorious he is. AT: "They will be like beautiful stones in a crown" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### How good and how beautiful they will be!

This is an exclamation, and not a question. AT: "They will be very good and beautiful!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### The young men will flourish on grain and the virgins on sweet wine!

This sentence uses a parallel structure to express that everyone will have plenty to eat and drink. If your readers might think that only the men ate and only the women drank, you may want to adjust the wording. AT: "All of the people, both men and women, will have plenty of grain to eat and sweet wine to drink!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### The young men ... the virgins

These two phrases are parallel and together represent the entire population of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### grain ... sweet wine

These two phrases are parallel and together represent all of the different kinds of the food and drink. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Zechariah 09:intro

#### Zechariah 09 General Notes ####

####### Structure and formatting #######

This chapter is written mainly in prose about the cities and peoples around where Israel stood as a country until the exile. 

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 9:9-10.

####### Special concepts in this chapter #######

######## Prophecies against other nations ########
The first two verses show that the prophecy concerns neighboring countries. Hamath, Damscus, Tyre and Sidon are cities in areas that were near Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Zechariah 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Zechariah 10

### Zechariah 10:01

#### General Information:

Zechariah continues speaking to the people of Israel.

#### makes thunderstorms

"makes the clouds from which the rain falls in storms"

#### vegetation in the field

"causes plants to grow in the field"

#### household idols speak falsely

"household idols give false messages." Zechariah is not suggesting that idols actually speak. He is referring to the messages people say they hear from idols. The UDB makes this explicit.

#### diviners envision a lie

"diviners see false visions"

#### they tell deceitful dreams

It is implied that they know these dreams are false. This can be made explicit. AT: "diviners lie about their dreams in order to deceive people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### empty comfort

This refers to words that sooth temporarily, but do not provide any longterm help.

#### they wander like sheep

The people who do not have true prophets who tell the truth are spoken of as sheep who do not have a shepherd to tell them where to go. AT: "the people who listen to the false prophets are like sheep who do not know which way to go" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they ... suffer because there is no shepherd

The people who do not have true prophets are spoken of as sheep who suffer because they do not have a shepherd to tell them where to go. AT: "the people who listen to the false prophets ... are suffering like sheep who do not have a shepherd to guide them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Zechariah 10:03

#### General Information:

It is unclear whether Yahweh is speaking, or if Zechariah is speaking for Yahweh in verses 3-5.

#### My wrath burns against the shepherds

Here "the shepherds" represent the leaders of God's people. The intensity of Yahweh's anger is spoken of as if it was a blazing fire. AT: "My anger toward the shepherds of my people is as intense as a fire" or "I am very angry with the leaders of my people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it is the male goats—the leaders—that I will punish

Male goats are typically more dominant than female goats. Here "male goats" represents the oppressive leaders of God's people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh of hosts will also attend to his flock, the house of Judah

Here Yahweh's care for his people is spoken of as a shepherd cares for his sheep. AT: "Yahweh of hosts will take care of the house of Judah as a shepherd cares for his sheep"

#### the house of Judah

The word "house" is a metonym for the family that lives in the house. In this case it refers to the people of Judah, which included the descendants of Judah and Benjamin. AT: "Judah" or "the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### make them like his warhorse in battle

Yahweh changes the metaphor for his people from defenseless sheep to a mighty war horse. He speaks of his people as if they were a strong horse in battle. AT: "will cause them to be strong like war horses in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Zechariah 10:04

#### General Information:

It is unclear whether Yahweh is speaking, or if Zechariah is speaking for Yahweh in verses 3-5.

#### From Judah will come the cornerstone

"The cornerstone will come from Judah." The most important ruler is spoken of as if he where the main foundation stone of a building. AT: "One of the descendants of Judah will become the most important ruler" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the cornerstone ... the tent peg ... the war bow

Possible meanings for these three things are 1) they may be symbolic language that refers to the Messiah who will come from the tribe of Judah or 2) they may refer to different leaders who will come from Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### from him will come the tent peg

"the tent peg will come from him." The tent pegs held the ropes that supported tents in which people lived. Here the most important ruler is spoken of as if he where the main peg that holds a tent in place. AT: "the leader who will hold the nation together will come from Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from him will come the war bow

"the war bow will come from him." Here the most important ruler is spoken of as if he where the a war bow that was used in battle. AT: "the military leader will come from Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from him will come every ruler together

"every ruler will come from Judah"

#### They will be like warriors ... streets in battle

The rulers from Judah are spoken of as if they were victorious warriors. AT: "They will be mighty in battle, trampling their enemies into the mud of the streets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### who trample their enemies into the mud of the streets in battle

To trample them into the mud is an idiom that means to completely defeat them. AT: "who defeat their enemies completely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh is with them

Here "with them" is an idiom that means he is present to help them. AT: "Yahweh will help them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they will shame those who ride warhorses

Here shame accompanies and represents defeat. AT: "they will defeat their enemies who ride warhorses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cornerstone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cornerstone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Zechariah 10:06

#### General Information:

In verses 6-12, Yahweh is speaking to the people of Israel.

#### the house of Judah

The word "house" is a metonym for the family that lives in the house. In this case it refers to the kingdom of Judah, which included the descendants of Judah and Benjamin. AT: "Judah" or "the kingdom of Judah" or "the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the house of Joseph

The word "house" is a metonym for the family that lives in the house. In this case it refers to the kingdom of Israel. AT: "Israel" or "the kingdom of Israel" or "the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I had not cast them off

This speaks of the people as a torn or dirty garment that Yahweh took off and threw away. This symbolizes rejection. AT: "I had not rejected them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### Ephraim will be like a warrior

"Ephraim" refers here to the northern kingdom of Israel. Warriors are strong. AT: "Ephraim will be very strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### their hearts will rejoice as with wine

Here "hearts" refers to the whole person. They will have the same joy as a person who is enjoying drinking wine. AT: "and they will be very happy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### their children will see and rejoice. Their hearts will rejoice in me!

"their children will see what has taken place and will be happy because of what Yahweh has done for them!"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Zechariah 10:08

#### General Information:

In verses 6-12, Yahweh is speaking to the people of Israel.

#### I will whistle

To whistle is to produce a high, shrill sound with air through narrowed lips. It is often done to give a signal to other people, as here.

#### I sowed them among the peoples

The exile of the people is spoken of as if they were seed that Yahweh had planted in a distant land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### until there is no more room for them

The people will continue to go back to Judah and it will become crowded with no room for any more people to live there. This can be stated in positive form. AT: "and they will completely fill the land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]

### Zechariah 10:11

#### General Information:

In verses 6-12, Yahweh is speaking to the people of Israel.

#### I will pass through the sea of their affliction

Scripture often refers to the sea as an image of many troubles and hardships. Here Yahweh speaks of himself accompanying the people to help them go through these afflictions. AT: "I will go with them and help them as they go through their many afflictions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will strike the waves of that sea

Here to "strike" the waves is an idiom that means he will stop the waves from forming. Stopping the afflictions of his people is spoken of as calming the waves of that sea. AT: "I will cause the waves of that sea of affliction to stop" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will dry up all the depths of the Nile

"I will cause the Nile River to lose all its water"

#### The majesty of Assyria will be brought down

Here "the majesty of Assyria" probably refers to the Assyrian army. AT: "I will destroy Assyria's proud army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the scepter of Egypt will go away from the Egyptians

Here "the scepter of Egypt" refers to the political power of Egypt. AT: "the power of Egypt to rule other nations will end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will strengthen them in myself

"I will cause them to be strong and to believe in me"

#### they will walk in my name

Here "in my name" is an idiom that means they will do what Yahweh wants them to do. AT: "they will honor and obey me as I want them to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]

### Zechariah 10:intro

#### Zechariah 10 General Notes ####

####### Structure and formatting #######

This chapter is written mainly in prose but still uses figurative language as the writer shares a message of redemption and hope for the exiles. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]])

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 10:1-2.

####### Special concepts in this chapter #######

######## Redemption ########
This book, and especially this chapter, uses the concepts of redemption and remnant to share the relationship that the people of Judah have with their God. So many of the people of Israel perished as their kingdom went into exile. Now they are returning to the land, but the land is no longer theirs. They are living under foreign rule. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]])
##### Links: #####

* __[Zechariah 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Zechariah 11

### Zechariah 11:01

#### Open your doors, Lebanon, that fire may devour

Not resisting what is about to happen is spoken of as if Lebanon were opening its doors. Here "Lebanon" is a metonym that represents the people of Lebanon. AT: "People of Lebanon, get ready, because fire will devour" or "People of Lebanon, do not try to stop the fire that will devour" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### fire may devour your cedars

Fire completely burning up the cedars is spoken of as if the fire would devour the cedars. AT: "fire may completely destroy your cedars" or "fire may completely burn up your cedars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Lament, cypress trees, for the cedar trees have fallen

Cypress trees are spoken of as if they could grieve like a human. AT: "If the trees were people, they would cry out in sorrow. The cypress trees stand alone because the cedars have burned and fallen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### What was majestic has been devastated

This can be stated in active form. AT: "The majestic cedar trees are no more" or "The cedar trees were once majestic, but now they are ruined" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Lament, you oaks of Bashan, for the strong forest has gone down.

The oaks of Bash are spoken of as if they could grieve like a human. AT: "If the oak trees in Bashan were people, they would wail, for their thick forests are gone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The shepherds howl

"The shepherds cry out loudly"

#### for their glory has been destroyed

Here "their glory" probably represents the rich pastures that the shepherds led their sheep to. AT: "for their rich pastures are ruined" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for the pride of the Jordan River has been devastated

Here "the pride" probably represents the forests that grew near the Jordan River. AT: "because the trees and shrubbery where they lived by the Jordan River are ruined" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cypress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cypress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Zechariah 11:04

#### General Information:

In 11:4-17 is a story about two shepherds. Possible meanings are 1) Zechariah actually became a shepherd over a flock as a symbolic act showing how Yahweh will treat his people or 2) Zechariah tells a parable that teaches how Yahweh will treat his people. Since it is uncertain which of these meanings is correct, it would be best not to specify either option in the translation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### watch over the flock set aside for slaughter

"take care of a flock of sheep that the owners plan to slaughter"

#### are not punished

This can be stated in active form. AT: "no one punishes them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the inhabitants of the land

"the people of the land"

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### See!

"Listen!" or "Pay attention!"

#### I myself

The word "myself" is used to emphasize that it is Yahweh who will do these things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### turn over every person into the hand of his neighbor and into the hand of his king

Here "hand" represents power or control. AT: "allow the people to harm each other and the king will oppress them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### none of them will I deliver them from their hand

Here "hand" represents power or control. AT: "I will not save them from those who are harming them" or "I will not rescue them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]

### Zechariah 11:07

#### for those who dealt in sheep

"for those who bought and sold sheep"

#### Favor

Other versions of the Bible translate this word as "grace," "beauty," or "pleasant."

#### I ran out of patience with them

Possible meanings are 1) "them" refers to the three shepherds or 2) "them" refers to the sheep owners.

#### the sheep that are being destroyed—let them be destroyed

This can be stated in active form. AT: "the sheep that are perishing—let them perish" or "the sheep that are to wander and get lost—let them get lost" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Zechariah 11:10

#### the covenant was broken

This can be stated in active form. AT: "the covenant ended" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### knew that Yahweh had spoken

It is implied that those watching knew Yahweh was giving them a message through the breaking of the staff. AT: "knew that Yahweh had given them a message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### thirty pieces of silver

It is implied that this was very little pay for the shepherd. AT: "only thirty pieces of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### thirty pieces

"30 pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Zechariah 11:13

#### General Information:

The parable about shepherds and sheep continues.

#### treasury

This is the place in the temple of Yahweh where the priests kept the money. Many versions of the Bible translate this as "potter." This is the person who would melt metal to make vessels out of it. Here Yahweh would mean that the payment is so small that the shepherd should have the silver melted to show how insulted he was.

#### the excellent price

Yahweh uses irony to say that this price was very small for a shepherd doing Yahweh's work. AT: "the ridiculously small amount of money" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### between Judah and Israel

Here "Judah" represents the people of the southern kingdom and "Israel" represents the people of the northern kingdom. AT: "between the people of Judah and the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Zechariah 11:15

#### General Information:

This continues the story about two shepherds that began in [Zechariah 11:4](./04.md). Possible meanings are 1) Zechariah actually became a shepherd over a flock as a symbolic act showing how Yahweh will treat his people or 2) Zechariah tells a parable that teaches how Yahweh will treat his people. Since it is uncertain which of these meanings is correct, it would be best not to specify either option in the translation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### I am about to set in place a shepherd in the land

Here "set in place" is an idiom. AT: "I am about to appoint a shepherd in the land" or "I am about to put a shepherd in charge in the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the fattened sheep

"the fattest sheep" or "the best sheep"

#### will tear off their hooves

This was probably done as an act of cruelty.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hooves.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hooves.md)]]

### Zechariah 11:17

#### May the sword

Here "sword" represents enemies who will attack the shepherd. AT: "May enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### come against his arm and his right eye

Here "come against" is an idiom. AT: "strike and wound his right arm and pierce his right eye" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### his arm

Here "arm" represents the power to fight. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his right eye

A soldier would use his right eye to look around the shield that he held with his left hand. If his right eye was wounded, he would not be able to see to fight in war. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### his arm wither away

"his arm waste away" or "his arm become completely useless"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Zechariah 11:intro

#### Zechariah 11 General Notes ####

####### Structure and formatting #######

This chapter unlike the previous one is a warning against the leaders amongst the exiles.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 11:1-3, 17.

####### Important figures of speech in this chapter #######

######## Metaphor ########
This chapter uses an extended metaphor of sheep and shepherds to convey Yahweh's dismay at the leaders during the exiles. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## Symbolism ########
The writer uses symbolism. Zechariah is told to become a shepherd. He uses two staffs and names them "Unity" and "Favor." He does this very purposefully. In order to preserve this symbolism, it is important to pay attention to the specific words used. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]])

##### Links: #####

* __[Zechariah 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Zechariah 12

### Zechariah 12:01

#### General Information:

These verses begin a section that tells about the coming attack against Jerusalem and how God will rescue the city.

#### This is a declaration of Yahweh's word concerning Israel

"This is the message that Yahweh declares concerning Israel"

#### who stretched out the skies

This is a metaphor that speaks of the sky as if it were like a scroll that is rolled up and needs to be stretched out. AT: "the one who created the sky" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### laid the foundation of the earth

This is a metaphor that speaks of the earth as if it were a building with a foundation. AT: "put all the earth into place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fashions the spirit of mankind within man

This is a metaphor that speaks of the spirit as if it were like clay that a potter shapes. AT: "creates the human spirit"

#### I am about to make Jerusalem into a cup ... to stagger about

Yahweh using Jerusalem to punish the surrounding peoples is spoken of as if Yahweh would make Jerusalem a cup full of an alcoholic drink that will cause the surrounding peoples to get drunk and stagger. AT: "Soon it will be like I make Jerusalem into a cup ... to stagger about" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### into a cup

Here "cup" represents the cup and the contents within the cup. AT: "into a cup full of wine" or "into a cup full of an alcoholic drink" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### surrounding her

Here "her" refers to the city of Jerusalem. It was common in Hebrew to speak of a city or country as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### I will make Jerusalem a heavy stone for all the peoples

Yahweh using Jerusalem to punish the surrounding peoples is spoken of as if he would make Jerusalem a heavy stone. AT: "It will be like I will make Jerusalem a heavy stone for all the peoples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Zechariah 12:04

#### General Information:

These verses continue telling about the coming attack against Jerusalem and how God will rescue the city.

#### On that day

"At the time when the armies attack Jerusalem"

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I will look with favor on the house of Judah

The phrase "look with favor on" is an idiom. AT: "I will show favor to the house of Judah" or "I will protect the house of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the house of Judah

Here "house" represents people. AT: "the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### say in their hearts

Here "hearts" represents a person's mind. AT: "think to themselves" or "say to themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### are our strength

The abstract noun "strength" can be stated as "strong" or "encourage." AT: "make us strong" or "encourage us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Yahweh of hosts, their God

"Yahweh of hosts, the God they worship"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Zechariah 12:06

#### General Information:

This verse continues telling about the coming attack against Jerusalem and how God will rescue the city.

#### like firepots among wood ... standing grain

This simile means Yahweh will enable the leaders of Judah to be strong and able to lead the people to defeat their enemies. AT: "like firepots among stacked firewood ... unharvested stalks of grain standing in a field" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### firepots

clay pots in which ancient people often carried burning coals

#### flaming torch

a wooden stick that is burning at one end which gives light as one travels or carries fire somewhere

#### will consume all the surrounding peoples

Completely destroying the peoples is spoken of as if the people of Judah will "devour" them. AT: "will destroy the surrounding peoples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### on their right and on their left

Here "right" and "left" represent every direction. AT: "in every direction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### Jerusalem will again live in her own place

Here "Jerusalem" represents the people who live there. AT: "The people of Jerusalem will again live in their own city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Zechariah 12:07

#### General Information:

These verses continue telling about the coming attack against Jerusalem and how God will rescue the city.

#### the tents of Judah

Here "tents" represents homes, and homes represent the people who live in them. AT: "the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the house of David

Possible meanings are 1) the descendants of David or 2) the ruling class of people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### those who are weak among them will be like David

This simile means those who are weak will be strong. AT: "those who are weak will be strong like David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the angel of Yahweh

This is an angel sent by Yahweh to protect the people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/houseofdavid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/houseofdavid.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Zechariah 12:10

#### I will pour out a spirit of compassion and pleading on the house of David and the inhabitants of Jerusalem

Causing the people to be compassionate and to plead is spoken of as if the spirit were a liquid that Yahweh would pour on them. AT: "I will cause the house of David and inhabitants of Jerusalem to have mercy on others and to pray to me for mercy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a spirit of compassion and pleading

Here this means to have a characteristic of compassion and pleading.

#### the house of David

Here "house" represents descendants. AT: "the descendants of David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the one they have pierced

"the one whom they stabbed to death"

#### for an only son

It is understood that the "son" has died. AT: "for an only son who has died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the laments in Jerusalem will be like the laments at Hadad Rimmon

Hadad Rimmon may have been the place where the good King Josiah died of battle wounds after the Battle of Megiddo. It appears that the custom arose to hold periodic mourning there for his death. Some people, however, think that Hadad Rimmon was the name of a false god who was believed to die every year, an event for which his worshipers would go into mourning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Megiddo

This is the name of a plain in Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/houseofdavid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/houseofdavid.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]

### Zechariah 12:12

#### The land will mourn

This represents all the people living in the land of Judah. AT: "All the people in the land of Judah will mourn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The clan of the house of David ... The clan of the house of Nathan ... The clan of the house of Levi

Here "house" represents descendants. AT: "The descendants of David ... The descendants of Nathan ... The descendants of Levi" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nathan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nathan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shimei.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shimei.md)]]

### Zechariah 12:intro

#### Zechariah 12 General Notes ####

####### Structure and formatting #######

Similar to chapter 11, this chapter is written mainly in prose and is talking about Jerusalem.

####### Special concepts in this chapter #######

######## Prophecy ########
Verses 10-11 are quoted in the New Testament and apply to Jesus' death on the cross. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]])
##### Links: #####

* __[Zechariah 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Zechariah 13

### Zechariah 13:01

#### a spring will be opened ... for their sin and impurity

Forgiving the people's sins is spoken of as if a spring of water will wash away their sins. This can be stated in active form. AT: "it will be like a spring opens ... to cleanse their sin and impurity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a spring

a place where water flows naturally out of the ground

#### the house of David

Here "house" represents descendants. AT: "the descendants of David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:3](../01/01.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I will cut off the names of the idols from the land

Causing the people to no longer mention the names of idols is spoken of as if Yahweh would "cut off the names of the idols from the land." AT: "I will cause the people to no longer mention the names of the idols" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will no longer be remembered

This can be stated in active form. AT: "so that they no longer think about the idols" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I will remove the prophets and the spirit of impurity from the land

The prophets may refer to "false prophets." The spirit of impurity is spoken of as if it were physically unclean. AT: "I will also remove from the land the false prophets and their evil spirits" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/houseofdavid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/houseofdavid.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Zechariah 13:03

#### to prophesy

It is implied that these are false prophecies. AT: "to prophesy falsely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### his father and mother who bore him

The phrase "who bore him" describes "his father and mother" in order to express surprise that someone's own parents would treat him in this way. AT: "his own father and mother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]])

#### You will not live

This can be stated in positive form. AT: "You must die"

#### you speak lies in the name of Yahweh

Speaking in the name of someone means speaking with his power and authority, or as his representative. AT: "you claim to speak for Yahweh but you speak lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will pierce

"will stab and kill him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Zechariah 13:04

#### each prophet

This implies false prophets. AT: "every false prophet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no longer wear a hairy cloak

Prophets often wore heavy outer garments made of animal hair. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I am a man who works the soil

"I am a farmer"

#### the land became my work while I was still a young man

"I became a farmer when I was young." Some versions of the Bible translate this as "a man sold me as a slave when I was young."

#### What are these wounds between your arms?

"How did you get those cuts on your chest?" This refers to the apparent custom of false prophets wounding themselves in their ceremonies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he will answer

It is implied that his answer is a lie. AT: "he will lie to him saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Zechariah 13:07

#### General Information:

Zechariah often wrote prophecy in the form of poetry. Hebrew poetry uses different kinds of parallelism. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### General Information:

Here Yahweh begins speaking.

#### Sword! Rouse yourself against my shepherd

"You, sword! Go and attack my shepherd." Here Yahweh speaks to a sword as if it were a person. Here it represents enemies. AT: "You, enemies! Go and attack my shepherd" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### my shepherd

This speaks of a servant of Yahweh as if he were a shepherd. AT: "my servant who is like a shepherd" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the man who stands close to me

This is an idiom. AT: "the man who is my close companion" or "the man who is my friend" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:3](../01/01.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### the flock will scatter

The people of God are spoken of as if they were sheep. AT: "my people will run away like sheep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will turn my hand against the lowly ones

The idiom "turn my hand against" means to act hostile towards someone. AT: "I will attack the lowly ones" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the lowly ones

This probably refers to all the Israelites who are weak and defenseless.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lowly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lowly.md)]]

### Zechariah 13:08

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Zechariah 1:4](../01/04.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### that two-thirds of it will be cut off! Those people will perish; only one-third will remain there

People being killed is spoken of as if they are cut off like cloth is cut from a garment or a branch is cut from a plant. AT: "that two out of every three people will die! Only one person out of three will remain in the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### I will bring that third through the fire

Metal is passed through fire in order to purify or harden it. This expression serves here as a metaphor for exposing the people to suffering in order that they may become more faithful to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### refine them as silver is refined; I will test them as gold is tested

Refining refers to making precious metals such as silver more pure. Metals such as silver and gold are tested in order to discover how pure or strong they are. Both refining and testing are here metaphors for making the people more faithful to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They will call on my name

Here "name" represents Yahweh. AT: "They will call out to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Zechariah 13:intro

#### Zechariah 13 General Notes ####

####### Structure and formatting #######

This chapter is written partly in prose and partly in poetry. 

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic song in 13:7-9.

####### Special concepts in this chapter #######

Zechariah often speaks of the last days by using the phrase "that day" or "in that day." When referencing a future "day," the translator should be aware that it is possible that the author is speaking about the last days. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]])

##### Links: #####

* __[Zechariah 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Zechariah 14

### Zechariah 14:01

#### General Information:

This chapter describes the final war for the city of Jerusalem and how God will save it.

#### A day for Yahweh is coming when your plunder will be divided in your midst

A future time is spoken of as if "a day is coming." The phrase "will be divided" can be stated in active form. AT: "Soon Yahweh will judge you, and he will allow your enemies to take all of your possessions and divide if for themselves while you watch" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I will gather every nation against Jerusalem for battle

Here "every nation" is a generalization that means "many nations." AT: "I will cause many nations to attack Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the city will be captured

This can be stated in active form. AT: "your enemies will capture the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The houses will be plundered and the women raped

This can be stated in active form. AT: "Enemies will plunder the houses and rape the women" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the remainder of the people will not be cut off from the city

Not removing people from the city is spoken of as if the people will not be "cut off." This can be stated in active form. AT: "your enemies will allow the remaining people to stay in the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Zechariah 14:03

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save it. In this prophecy, Yahweh is described as a warrior who will come and fight in battle.

#### as when he wages war on the day of battle

"just as he fought battles in the past"

#### On that day

"At that time"

#### his feet will stand on the Mount of Olives

Here "feet" represents Yahweh. AT: "he will stand on the Mount of Olives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### The Mount of Olives will be split ... by a very great valley

This can be stated in active form. AT: "The presences of Yahweh will split the Mount of Olives ... causing there to be a very great valley" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Zechariah 14:05

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### you will flee

Here "you" is plural and refers to the people of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### between Yahweh's mountains

This refers to the mountains created after the Mount of Olives split in half.

#### Azel

This is the name of a town or village east of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### You will flee just as you fled

Here "You will" refers to the people of Jerusalem. But, "you fled" refers to their ancestors since this describes an event that happened many years earlier. AT: "You will flee just as your ancestors fled" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in the days of Uzziah, king of Judah

Here "in the days" is an idiom that refers to the time when Uzziah was king. AT: "when Uzziah was king of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the holy ones

This probably refers to God's angels.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uzziah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uzziah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Zechariah 14:06

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### On that day

"At that time"

#### there will be no light

It is implied that there will be no light from the sun. AT: "there will be no light from the sun" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a day known only to Yahweh

This can be stated in active form. AT: "only Yahweh knows when that day will begin" or "only Yahweh knows when that time will begin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### living waters

This normally means running or flowing water, rather than still or stagnant water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the eastern sea

This refers to the Dead Sea, which is east of Jerusalem.

#### the western sea

This refers to the Mediterranean Sea.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Zechariah 14:09

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### there will be Yahweh, the one God, and his name alone

Here "name" represents Yahweh's reputation or character. AT: "people will know that Yahweh is the only true God" or "people will only worship Yahweh, the one true God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### All the land

It is implied that this is the land of Judah. AT: "All the land of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Arabah

This is the name of a plain in the Jordan River Valley. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Geba

This is the name of a town on the northern border of Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Rimmon

This is the name of a town south of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jerusalem will continue to be raised up

This contrasts Jerusalem, which will remain at a higher elevation, to the surrounding area, which is lower in elevation. The contrast can be indicated by adding the word "but." This can also be stated in active form. AT: "But, Jerusalem will remain high up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Benjamin Gate ... the first gate ... the Corner Gate

These are names of gates in the northeast part of city wall of Jerusalem. Possible meanings are 1) "the first gate" and "the Corner Gate" refer to the same gate or 2) "the first gate" and "the Corner gate" are separate gates. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Tower of Hananel

This refers to a strong point in the city defenses on the northern wall. It was probably built by a man named Hananel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the king's winepresses

This probably refers to the place where wine was made for the royal family. It was located in the southwest part of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Jerusalem will live in safety

Here "Jerusalem" represents the people. AT: "The people will live safely in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]

### Zechariah 14:12

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### even as they are standing on their feet

"while they are still standing up." This emphasizes how quickly their flesh will rot away. They will not even have time to lie down.

#### that great fear from Yahweh will come among them

The abstract noun "fear" can be stated as "terrified." AT: "Yahweh will cause the people to be very terrified" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Each one will seize the hand of another, and the hand of one will be raised up against the hand of another

These are idioms that refer to being hostile towards another person. AT: "Each person will grab someone, and they will fight each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Zechariah 14:14

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### Judah will also fight against Jerusalem

Here "Judah" and "Jerusalem" represent the people that live there. AT: "Even the other people in Judah will fight against the people of Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Judah will also fight against Jerusalem

Some versions of the Bible read, "Judah will also fight at Jerusalem."

#### They will gather the wealth

"They will capture all the valuable possessions"

#### in great abundance

"in great quantities"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]

### Zechariah 14:16

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### that came against Jerusalem

Here "came against" is an idiom. AT: "that attacked Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will instead go up from year to year

"will instead go to Jerusalem every year"

#### the Festival of Shelters

"the Festival of Tabernacles" or "the Festival of Booths" or "the Festival of Tents"

#### A plague from Yahweh will attack the nations

Causing people to suffer from a plague is spoken of as if the plague would attack the people like an army. AT: "Yahweh will cause a plague among the people of the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]

### Zechariah 14:19

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]

### Zechariah 14:20

#### General Information:

These verses continue the description of the final war for the city of Jerusalem and of how God will save her.

#### the bells of the horses will say

"the inscription on the bells of the horses will say"

#### the basins in Yahweh's house

These basins were used for boiling meat in the courtyard of the temple. AT: "the cooking pots in the courtyard of the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### will be like the bowls before the altar

It is implied that the basins will be sacred like the bowls used for catching the blood of the sacrifices. AT: "will be as sacred as the bowls used at the altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### every pot in Jerusalem and Judah will be set apart to Yahweh of hosts

Various types of pots and utensils were made especially to be used in the temple for the worship of Yahweh and for the sacrifices. These were considered special, not to be used for anything else.

#### traders will no longer be in the house of Yahweh

It was the custom for traders to sell the people things they needed in order to make proper sacrifices to Yahweh in the temple. AT: "people will no longer buy or sell things in the courtyard of the temple of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### traders

Some versions of the Bible translate "traders" as "Canaanites."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Zechariah 14:intro

#### Zechariah 14 General Notes ####

####### Structure and formatting #######

This chapter is written in prose about Jerusalem during the last days. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]])

####### Special concepts in this chapter #######

######## Last days ########

Zechariah often speaks of the last days by using the phrase "that day" or "in that day." When referencing a future "day," the translator should be aware that it is possible that the author is speaking about the last days. 

##### Links: #####

* __[Zechariah 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | __


## Zechariah front

### Zechariah front:intro

#### Introduction to Zechariah ####

##### Part 1: General Introduction #####

####### Outline of the Book of Zechariah #######

1. The prophet's call and the appeal for the returning nation of Israel to repent and return to Yahweh (1:1–6)
1. The eight night visions 
    - First vision: Yahweh sends his messengers throughout the whole earth (1:7–17)
    - Second vision: four horns and four craftsmen (1:18–21)
    - Third vision: the measuring line (2:1–13)
    - Fourth vision: the priest in filthy clothes (3:1–10)
    - Fifth vision: the golden lampstand and olive trees (4:1–14)
    - Sixth vision: the flying scroll (5:1–4)
    - Seventh vision: the basket filled with iniquity (5:5–11)
    - Eighth vision: four chariots (6:1–8)
1. Crown for the high priest (6:9–15)
1. Questions about fasting (7:1–8:23)
1. The oracle about Hadrach (of Damascus) and Hamath (of Tyre and Sidon) (9:1–11:17)
1. The oracle about Israel 
    - The final defeat of Israel's enemies (12:1-9)
    - Israel's mourning for having killed God's servant (12:10-14)
    - Israel's purification from sin and the end of false prophets (13:1-6)
    - Final removal of idols from returning Israel (14:1–2)
    - Future vision of Messianic Kingdom (14:3–21)

####### What is the Book of Zechariah about? #######

Zechariah wrote to the people of Judah who returned from exile in Babylon. The people of Judah continued to sin as their ancestors had before they went into exile. Zechariah called the people to repent and to obey Yahweh. And he called them to renew the covenant with Yahweh. Zechariah also prophesied about the Messiah (6:12) and Israel's final victory over their enemies.  (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

####### How should the title of this book be translated? #######

Translators may decide to translate the traditional title “The Book of Zechariah” in a way that is clearer to the readers. They may decide to call it the "The Book About Zechariah" or "The Sayings of Zechariah." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Zechariah? #######

The prophet Zechariah wrote this book between 520 B.C. to 480 B.C.

##### Part 2: Important Religious and Cultural Concepts #####

####### Did Zechariah prophesy before Ezra, Nehemiah, and Haggai? #######

Zechariah prophesied before the time of Ezra and Nehemiah. He prophesied at the same time as Haggai and continued after Haggai.

##### Part 3: Important Translation Issues #####

####### What is the meaning of the term "Israel"? #######

The name "Israel" is used in many different ways in the Bible. There was a man named Jacob. God changed his name to Israel. The descendants of Jacob became a nation also called Israel. Eventually, the nation of Israel split into two kingdoms. The northern kingdom was named Israel. The southern kingdom was named Judah. Zechariah uses the term "Israel" to refer to both the nation of Israel and the northern kingdom of Israel.

####### What imagery does Zechariah use in reference to the Messiah? #######

Zechariah presented the Messiah as both a king and a shepherd. Zechariah said that the Messiah would come and deliver his people. However, he would also be pierced (12:10) and struck with the sword (13:7). (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]]])

####### What does the phrase "that day" mean? #######

Zechariah often spoke of the last days by using the phrase "that day" or "in that day." When referencing a future "day," the translator should be aware that it is possible that the author is speaking about the last days. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]])



---

