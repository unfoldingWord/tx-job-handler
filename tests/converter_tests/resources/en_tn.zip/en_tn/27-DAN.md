# <a id="dan"/>Daniel

## Daniel 01

### Daniel 01:01

#### Nebuchadnezzar king of Babylonia ... gave Nebuchadnezzar

This refers to Nebuchadnezzar and his soldiers, not only to Nebuchadnezzar. AT: "Nebuchadnezzar's soldiers ... them" or "Nebuchadnezzar king of Babylonia and his soldiers ... them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### to cut off all supplies to it

"to stop the people from receiving any supplies"

#### Jehoiakim king of Judah

This refers to Jehoiakim and his soldiers, not only to Jehoiakim. AT: "the army of Jehoiakim king of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he gave him

Jehoiakim gave Nebuchadnezzar

#### He brought ... he placed

Although Nebuchadnezzar did not do these things alone, it may easier for the reader to retain the singular pronouns. AT: "They brought ... they placed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### He brought them

Here "them" probably refers to Jehoiakim and other prisoners, as well as the sacred objects.

#### in his god's treasury

This was an act of devotion to his god.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoiakim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoiakim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Daniel 01:03

#### The king spoke

This refers to Nebuchadnezzar.

#### Ashpenaz

This is the chief official. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### nobility

This is the highest social class.

#### without blemish

These two negative words together emphasize a positive idea. AT: "with perfect appearance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### filled with knowledge and understanding

This is an idiom. This means they knew much and could organize and use that information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### king's palace

This is the large house or building where the king lives.

#### He was to teach them

"Ashpenaz was to teach them"

#### The king counted out for them

The king's officials did this task for him. AT: "The king's officials counted out for them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his delicacies

the special, rare, good foods that the king ate

#### These young men were to be trained

This can be stated in active form. AT: "Ashpenaz was to train these young men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### trained

"taught skills"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/qualify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/qualify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Daniel 01:06

#### Among these

"Among the young men from Israel"

#### The chief official

This refers to Ashpenaz who was King Nebuchadnezzar's highest official.

#### Belteshazzar ... Shadrach ... Meshach ... Abednego

These are all men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hananiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hananiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mishael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mishael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/azariah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/azariah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Daniel 01:08

#### Daniel intended in his mind

Here "mind" refers to Daniel himself. AT: "Daniel decided to himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### pollute himself

To "pollute" something is to make is unclean. Some of the food and drink of the Babylonians would make Daniel ceremonially unclean according to God's law. This can be made explicit. AT: "make himself unclean according to God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### delicacies

This refers to the special, rare, good foods that the king ate. See how you translated this in [Daniel 1:3](./01.md).

#### Why should he see you looking worse than the other young men of your own age?

The official uses this question to explain what he thought would happen. It can be a statement. AT: "He does not want to see you looking worse than the other young men of your own age." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The king might have my head

This is an idiom. AT: "The king might cut off my head" or "The king might kill me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 01:11

#### compare our appearance with the appearance

Daniel asked the steward to see if he and his friends looked worse than the other young men. AT: "compare our appearance to see if it is worse than the appearance"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/manager.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/manager.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Daniel 01:14

#### tested them ... their appearance ... they were ... their delicacies ... their wine

All of these pronouns refer to Daniel, Hananiah, Mishael, and Azariah.

#### nourished

This means to have been made healthy from what you have eaten.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/manager.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/manager.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Daniel 01:17

#### God gave them knowledge and insight

This can be reworded so that the abstract nouns "knowledge" and "insight" can be expressed as the verbs "learn" and "understand." AT: "God gave them the ability to learn and understand clearly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### in all literature and wisdom

Here "all" is a generalization to show that they had a very good education and understanding. AT: "in many things that the Babylonians had written and studied" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]

### Daniel 01:19

#### The king spoke with them

The king spoke with the "four young men" ([Daniel 1:17](./17.md)).

#### among the whole group there were none to compare with Daniel, Hananiah, Mishael, and Azariah

This can be stated in positive form. AT: "Daniel, Hananiah, Mishael, and Azariah pleased him much more than anyone else in the whole group" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Daniel, Hananiah, Mishael, and Azariah

These are the names of men. See how you translated these names in [Daniel 1:6-7](./06.md).

#### ten times better

Here "ten times" is an exaggeration representing great quality. AT: "much better" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the first year of King Cyrus

"the first year that King Cyrus ruled Babylon"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/azariah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/azariah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]

### Daniel 01:intro

#### Daniel 01 General Notes ####

####### Structure and formatting #######

######## Training for government jobs ########

Daniel, Shadrach, Meshach, and Abednego were chosen to be trained for service in the Babylonian kingdom. It was not unusual for foreigners to be given positions in the Babylonian government as advisors or cultural ambassadors. 

####### Special concepts in this chapter #######

######## Food laws ########

The food from the king included things the Jews were not allowed to eat according to the law of Moses. Daniel requested permission not to eat the king's food. He proved to the king that this food was not necessary for good health. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])  

##### Links: #####

* __[Daniel 01:01 Notes](./01.md)__
* __[Daniel intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Daniel 02

### Daniel 02:01

#### In the second year

"In year two" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### he had dreams

"Nebuchadnezzar had dreams"

#### His mind was troubled

Here "mind" refers to his thoughts. AT: "His thoughts disturbed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### and he could not sleep

His troubled thoughts prevented him from sleeping. AT: "so that he could not sleep"

#### Then the king summoned the magicians

"Then the king called the magicians"

#### the dead

"people who had died"

#### they came in

"they came into the palace"

#### stood before

"stood in front of"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wisemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wisemen.md)]]

### Daniel 02:03

#### my mind is anxious

Here "mind" refers to the king himself. AT: "I am anxious" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### anxious

"troubled"

#### Aramaic

This is the language that people in Babylon spoke. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### King, live forever!

The men probably said this to show the king that they were loyal to him. AT: "King, we hope you will live forever!"

#### us, your servants

The men called themselves the king's servants to show him respect.

#### we will reveal

Here the word "we" refers to the men that the king is speaking to and does not include the king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wisemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wisemen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]

### Daniel 02:05

#### This matter has been settled

This can be stated in active form. AT: "I have already decided what to do about this matter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### your bodies will be torn apart and your houses made into rubbish heaps

This can be stated in active form. AT: "I will command my soldiers to tear your bodies apart and to make your houses into rubbish heaps" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you will receive gifts from me

This can be stated in active form. AT: "I will give you gifts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Daniel 02:07

#### Let the king tell us

The wise men addressed the king in the third person as a sign of respect. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### you see how firm my decision is about this

A decision that will not be changed is spoken of as something firm. AT: "you see that I will not change my decision about this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### there is only one sentence for you

"there is only one punishment for you"

#### false and deceptive words

These two words mean approximately the same thing and emphasize that these are "lies intended to deceive." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Daniel 02:10

#### great and powerful

These two words mean basically the same thing and emphasize the greatness of the king's power. AT: "most powerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### there is no one who can tell it to the king except the gods

This is stated in negative form for emphasis. It can be stated in positive form. AT: "only the gods can tell this to the king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wisemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wisemen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Daniel 02:12

#### angry and very furious

These words mean basically the same thing and emphasize the intensity of his anger. AT: "incredibly angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### all those in Babylon

"all the men in Babylon"

#### So the decree went out

The decree is spoken of as if it was alive and able to go out by itself. AT: "So the king issued a command" or "So the king gave a command" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### all those who were known for their wisdom were to be put to death

This can be stated in active form. AT: "the soldiers were to kill all of the men who were known for their wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### so they could be put to death

This can be stated in active form. AT: "in order to kill them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]

### Daniel 02:14

#### prudence and discretion

These two words mean basically the same thing and emphasize the greatness of his prudence. AT: "caution and careful judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Arioch

This is the name of the king's commander. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### bodyguard

This is a group of men whose job is to protect the king.

#### who had come to kill

"who the king had sent out to kill"

#### Daniel went in

Daniel probably went to the palace. AT: "Daniel went to the palace" or "Daniel went to talk with the king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### requested an appointment with the king

"asked for a set time to meet with the king"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]

### Daniel 02:17

#### his house

This is referring to Daniel's house.

#### what had happened

"about the king's decree"

#### He urged them to seek mercy

"He begged them to pray for mercy"

#### so that he and they might not be killed

This can be stated in active form. AT: "so that the king would not kill them" or "so that the king's bodyguard would not kill them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hananiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hananiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mishael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mishael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/azariah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/azariah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Daniel 02:19

#### That night the mystery was revealed

This can be stated in active form. AT: "That night God revealed the mystery" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the mystery

This is referring to the king's dream and its meaning.

#### Praise the name of God

Here "name" refers to God himself. AT: "Praise God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Daniel 02:21

#### General Information:

These verses are also part of Daniel's prayer.

#### he removes kings

"he takes away kings' authority to rule"

#### places kings on their thrones

Here being on the "throne" refers to ruling over a kingdom. AT: "makes new kings rule over their kingdoms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the light lives with him

"the light comes from where God is"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]

### Daniel 02:23

#### General Information:

This verse is also part of Daniel's prayer. He stops addressing God in the third person and switches to the more personal second person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### made known to me what we asked of you

"told me what my friends and I asked you to tell us"

#### made known to us the matter that concerns the king

"told us what the king wants to know"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 02:24

#### Arioch

This is the name of the king's commander. See how you translated this name in [Daniel 2:14](./14.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### everyone who was wise

"the wise men"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]

### Daniel 02:25

#### Belteshazzar

This was the name the Babylonians gave to Daniel. See how you translated this name in [Daniel 1:7](../01/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]

### Daniel 02:27

#### The mystery that the king has asked about ... not by astrologers

This can be stated in active form. AT: "Those who have wisdom, those who claim to speak with the dead, magicians, and astrologers cannot reveal the mystery about which the king has asked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The mystery that the king has asked about

This phrase refers to the king's dream.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Daniel 02:29

#### General Information:

Daniel continues talking to the king.

#### the one who reveals mysteries

This phrase refers to God. AT: "God, who reveals mysteries" or "God, who makes mysteries known" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### this mystery was not revealed to me

This can be stated in active form. AT: "God did not reveal this mystery to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### This mystery was revealed to me so that you

This can be stated in active form. AT: "He revealed the mystery to me so that you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### know the thoughts deep within you

This phrase is using the word "you" referring to the person's mind. AT: "know the thoughts deep inside your mind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Daniel 02:31

#### General Information:

Daniel continues talking to the king.

#### was made of fine gold

"was of fine gold" or "was fine gold"

#### were made partly of iron and partly of clay

"were partly of iron and partly of clay" or "were partly iron and partly clay"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Daniel 02:34

#### General Information:

Daniel continues talking to the king.

#### a stone was cut out, although not by human hands, and it

This can be stated in active form if it is divided into two sentences. AT: "someone cut a stone from a mountain, but it was not a human who cut it. The stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### like the chaff of the threshing floors in the summer

This phrase is comparing the pieces of the statue to small and light things which could be blown away by the wind. AT: "like dry pieces of grass blowing away in the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### there was no trace of them left

This can be stated in positive form. AT: "they were completely gone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### filled the whole earth

"spread over the whole earth"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chaff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chaff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Daniel 02:36

#### General Information:

Daniel continues talking to the king.

#### Now we will tell the king

Here "we" refers only to Daniel. He may have used to plural form in humility to avoid taking credit for knowing the meaning of the dream that God had revealed to him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### king of the kings

"the most important king" or "a king who rules over other kings"

#### the power, the strength

These words mean basically the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### He has given into your hand the place

Here "hand" refers to control. AT: "He has given you control over the place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the place where the human beings live

The place is used to represent the people who live there. AT: "the people of the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He has given over the animals ... into your hand

Here "hand" refers to control. AT: "He has given you control over the animals of the fields and the birds of the heavens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### birds of the heavens

Here "heavens" is used in the sense of "skies."

#### You are the statue's head of gold

In the king's dream the statue's head represents the king. AT: "The golden head symbolizes you" or "The golden head is a symbol of you and your power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Daniel 02:39

#### General Information:

Daniel continues talking to the king.

#### another kingdom will arise

In the king's dream his kingdom is gold so an inferior kingdom would be silver. AT: "another kingdom, which is of silver, will arise" or "another kingdom, which is represented by the silver parts of the statue, will arise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### yet a third kingdom of bronze

This is symbolic language where the bronze of parts of the statue represent a future kingdom. AT: "then still another kingdom, which is represented by the bronze parts of the statue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a third kingdom

"kingdom number three" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Daniel 02:40

#### General Information:

Daniel continues talking to the king.

#### There will be a fourth kingdom

"There will be a kingdom number four" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### strong as iron

The fourth kingdom is spoken of as being as strong as iron. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### It will shatter all these things and crush them

This symbolic language means the fourth kingdom will defeat and replace the other kingdoms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### all these things

"the previous kingdoms"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 02:41

#### General Information:

Daniel continues talking to the king.

#### Just as you saw

Nebuchadnezzar saw that the feet consisted of clay and iron. He did not see the process of making the feet.

#### were partly made of baked clay and partly made of iron

This can be stated in active form. AT: "were a mixture of baked clay and iron" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they will not stay together

"they will not remain united"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Daniel 02:44

#### General Information:

Daniel continues talking to the king.

#### In the days of those kings

Here "those kings" refers to the rulers of the kingdoms symbolized by the different parts of the statue.

#### that will never be destroyed, nor will it be conquered by another people

This can be stated in active form. AT: "that no one will ever destroy, and that another people never conquer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a stone was cut out of the mountain, but not by human hands

This can be stated in active form. AT: "someone cut a stone from the mountain, but it was not a human who cut it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### reliable

trustworthy and correct

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]

### Daniel 02:46

#### fell on his face

This symbolic act showed that the king was honoring Daniel. AT: "lay down with his face on the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### an offering be made and that incense be offered up to him

This can be stated in active form. AT: "his servants make an offering and offer up incense to Daniel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Truly your God

"It is true that your God"

#### the God of gods, the Lord of kings

"greater than all the other gods, and King over all other kings"

#### the one who reveals mysteries

Translate "the one who reveals mysteries" as in [Daniel 2:29](./29.md).

#### to reveal this mystery

"to reveal the mystery of my dream"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]

### Daniel 02:48

#### He made him ruler

"The king made Daniel the ruler"

#### Shadrach ... Meshach ... Abednego

These were the Babylonian names of the three Jewish men who were brought to Babylon with Daniel. See how you translated these names in [Daniel 1:7](../01/06.md)

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md)]]

### Daniel 02:intro

#### Daniel 02 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in Daniel's prayer in 2:20-23.

####### Special concepts in this chapter #######

######## The king's dream ########

Daniel told  the king's dream and what the dream meant. In the ancient Near East, it was believed that only people in touch with the gods could interpret dreams. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

######## How Daniel knew the dream ########

Daniel gave Yahweh the honor for having told him the dream and its meaning in answer to the prayers of the four men.

##### Links: #####

* __[Daniel 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Daniel 03

### Daniel 03:01

#### Nebuchadnezzar made a gold statue ... He set it up

Nebuchadnezzar commanded his men to do this work, he did not do the work himself. AT: "Nebuchadnezzar commanded his men to make a gold statue ... They set it up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### sixty cubits tall and six cubits wide

A cubit is 46 centimeters. AT: "about 27 meters tall and almost 3 meters wide" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### Plain of Dura

This is a location within the kingdom of Babylon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### provincial governors ... regional governors ... local governors

These are officials who have authority over different sizes of territory.

#### treasurers

These officials are in charge of money.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magistrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magistrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md)]]

### Daniel 03:03

#### the provincial governors, regional governors, ... officials of the provinces

See how you translated this list in [Daniel 3:2](./01.md).

#### the statue that Nebuchadnezzar had set up

Nebuchadnezzar commanded his men to do this work, he did not do the work himself. AT: "the statue that Nebuchadnezzar's men had set up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### herald

This person is an official messenger for the king.

#### You are commanded

This can be stated in active form. "The king commands you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### peoples, nations, and languages

Here "nations" and "languages" represent people from different nations who speak different languages. AT: "people from different nations and who speak different languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### zithers

These are musical instruments similar to harps. They are shaped like triangles and have four strings.

#### fall down

Here "fall down" means "quickly lie down"

#### prostrate yourselves to

"stretch yourselves out on the ground face down in worship of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magistrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magistrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 03:06

#### Whoever does not fall down and worship, at that very moment, will be thrown into a blazing furnace

This can be stated in active form. AT: "The soldiers will throw into a blazing furnace anyone who does not fall down and worship the statue at the very moment they hear the music" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### fall down

Here "fall down" means "quickly lie down"

#### blazing furnace

This is a large room filled with a hot fire.

#### all the peoples, nations, and languages

Here "all" that means all the people who were present.

#### peoples, nations, and languages

Here "nations" and "languages" represent people from different nations who speak different languages. See how you translated this in [Daniel 3:4](./03.md). AT: "people from different nations and who spoke different languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the horns, flutes ... and pipes

These are musical instruments. See how you translated these words in [Daniel 3:5](./03.md).

#### fell down

Here "fell down" means "quickly lay down"

#### prostrated themselves to

They did this to worship the statue. AT: "stretched themselves out on the ground face down in worship of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the golden statue that Nebuchadnezzar the king had set up

Nebuchadnezzar commanded his men to do this work, he did not do the work himself. AT: "the golden statue that King Nebuchadnezzar's men had set up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 03:08

#### Now

This word is used to mark a break in the main story line. Here the writer tells about some new people in the story.

#### King, live forever

This was a common greeting to the king.

#### the horns, flutes ... and pipes

These are musical instruments. See how you translated these words in [Daniel 3:5](./03.md).

#### fall down

Here "fall down" means "quickly lie down"

#### prostrate himself to

The people would do this to worship the statue. AT: "stretch himself out on the ground face down in worship of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/chaldeans.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/chaldeans.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Daniel 03:11

#### Whoever does not fall down and worship must be thrown into a blazing furnace

This can be stated in active form. AT: "Soldiers must throw into a blazing furnace anyone who does not lie down on the ground and worship" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### fall down

Here "fall down" means "quickly lie down"

#### blazing furnace

This is a large room filled with a hot fire. See how you translated this in [Daniel 3:6](./06.md).

#### affairs

"matters" or "business"

#### Shadrach ... Meshach ... Abednego

These are the Babylonian names of the three Jewish friends of Daniel. See how you translated these names in [Daniel 1:7](../01/06.md).

#### pay no attention to you

"do not pay attention to you"

#### prostrate themselves

They would do this to worship the statue. AT: "stretch themselves out on the ground face down in worship" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the golden statue you have set up

Nebuchadnezzar commanded his men to do this work, he did not do the work himself. AT: "the golden statue your men have set up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Daniel 03:13

#### filled with anger and rage

Nebuchadnezzar's anger and rage were so intense that they are spoken of as if they had filled him up. Here "anger" and "rage" mean about the same thing and are used to emphasize how upset the king was. AT: "extremely angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Shadrach, Meshach, and Abednego

These are the Babylonian names of the three Jewish friends of Daniel. See how you translated these names in [Daniel 1:7](../01/06.md).

#### Have you made your minds up

Here "mind" refers to deciding. To "make up your mind" is an idiom that means to firmly decide. AT: "Have you firmly decided" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### prostrate yourselves to

The three men would not do this to worship the statue. AT: "stretch yourselves out on the ground face down in worship of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the golden statue that I have set up

Nebuchadnezzar commanded his men to do this work, he did not do the work himself. AT: "the golden statue that my men have set up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Daniel 03:15

#### the horns, flutes ... and pipes

These are musical instruments. See how you translated this list in [Daniel 3:5](./03.md).

#### fall down

Here "fall down" means "quickly lie down"

#### prostrate yourselves to

stretch yourselves out on the ground face down in worship of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### all will be well

"there will no longer be a problem" or "you will be free to go"

#### the statue that I have made

Nebuchadnezzar commanded his men to do this work, he did not do the work himself. AT: "the statue that my men have made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you will immediately be thrown into a blazing furnace

This can be stated in active form. AT: "my soldiers will immediately throw you into a blazing furnace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### blazing furnace

This is a large room filled with a hot fire. See how you translated this in [Daniel 3:6](./06.md).

#### Who is the god ... my hands?

The king does not expect an answer. He is threatening the three men. AT: "No god is able to rescue you from my power!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### out of my hands

Here "hands" refers to power to punish. AT: "from my punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Daniel 03:16

#### blazing furnace

This is a large room filled with a hot fire. See how you translated this in [Daniel 3:6](./06.md).

#### out of your hand

Here "hand" refers to power to punish. AT: "from your punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But if not, let it be known to you, king, that

"But king, we must let you know that even if our God does not rescue us"

#### prostrate ourselves to

People would do this to worship their gods. AT: "stretch ourselves out on the ground face down in worship of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the golden statue you set up

Nebuchadnezzar commanded his men to do this work, he did not do the work himself. AT: "the golden statue your men set up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Daniel 03:19

#### Nebuchadnezzar was filled with rage

The king was so angry that rage is spoken of as if it were filling him up. AT: "Nebuchadnezzar became extremely angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He commanded that the furnace should be heated seven times hotter than it was normally heated

Here "seven times hotter" is an idiom that means to make it very much hotter. This can be stated in active form. AT: "He commanded his men to make the furnace very much hotter than they normally make it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Daniel 03:21

#### turbans

A turban is a head covering made of wrapped cloth.

#### blazing furnace

This is a large room filled with a hot fire. See how you translated this in [Daniel 3:6](./06.md).

#### Because the king's command was strictly followed

This can be stated in active form. AT: "Because the men did exactly what the king commanded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tunic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tunic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Daniel 03:24

#### Did we not throw three men tied up into the fire

"We threw three men tied up into the fire, right"

#### The brilliance of the fourth is like a son of the gods

The gods were believed to shine brightly with light. AT: "Man four is shining brightly with light as a son of the gods would shine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Daniel 03:26

#### The provincial governors, regional governors, other governors

These are officials who have authority over different sizes of territory. See how you translated these in [Daniel 3:2](./01.md).

#### the hair on their heads was not singed

This can be stated in active form. AT: "the fire had not singed the hair on their heads" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### singed

"lightly burned"

#### their robes were not harmed

This can be stated in active form. AT: "the fire did not harm their robes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### there was no smell of fire on them

"they did not smell like fire"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]

### Daniel 03:28

#### they set aside my command

Not obeying the king's command is spoken of as if they had physically moved it away from them. AT: "they ignored my command" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they gave up their bodies

This phrase refers to the three men's willingness to die for what they believed. AT: "they were willing to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### prostrate themselves to

People would do this to worship their gods. AT: "stretch themselves out on the ground face down in honor of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### any god except their God

"any other god except their God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Daniel 03:29

#### any people, nation, or language ... must be torn apart, and that their houses must be made into rubbish heaps

This can be stated in active form. AT: "my servants will tear apart any people, nation, or language ... and make their houses into piles of garbage" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### any people, nation, or language that speaks

Here "nations" and "language" represent people from different nations who speak different languages. See how you translated a similar phrase in [Daniel 3:4](./03.md). AT: "any people from any nation, or those who speak any language that says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### speaks anything against the God

"speaks words that do not respect the God"

#### must be torn apart

"must have their bodies torn apart"

#### there is no other god who is able to save like this

This can be stated in positive form. AT: "only their God is able to save like this"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]

### Daniel 03:intro

#### Daniel 03 General Notes ####

####### Special concepts in this chapter #######

######## The king's new idol ########

Shadrach, Meshach, and Abednego refused to worship the new idol. In the ancient Near East, refusing to worship the king was a sign of rebellion against the king. It was often considered the crime of treason. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]])

######## The furnace ########

There was a fourth person with them in the furnace, and because of this they were not hurt. Most scholars believe this to be Jesus before he was born. 

##### Links: #####

* __[Daniel 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Daniel 04

### Daniel 04:01

#### General Information:

In this chapter, Nebuchadnezzar tells what God did to him. In verses 1-18, Nebuchadnezzar describes in the first person his vision from God. Verses 19-33 switch to the third person to describe the punishment of Nebuchadnezzar. Verses 34-37 change back to first person as Nebuchadnezzar describes his response to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### King Nebuchadnezzar sent

This phrase is referring to the king's messenger as the king himself. AT: "Nebuchadnezzar sent his messengers with" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### peoples, nations, and languages

Here "nations" and "languages" represent people from different nations who speak different languages. See how you translated this in [Daniel 3:4](../03/03.md). AT: "people from different nations and who speak different languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### who lived on the earth

Kings would often exaggerate how wide their kingdom was. Nebuchadnezzar did rule over most of the known world at the time this book was written. AT: "who lived in the kingdom of Babylon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### May your peace increase

This is a common greeting.

#### signs and wonders

These words share similar meanings and refer to the amazing things that God had done. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### How great are his signs, and how mighty are his wonders!

Both of these phrases have the same meaning and are used to emphasize how great God's signs and wonders are. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### His kingdom is ... generation to generation

Both of these phrases have the same meaning and are repeated to emphasize how God's reign is forever. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Daniel 04:04

#### General Information:

In verses 1-18, Nebuchadnezzar describes in the first person his vision from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### was living happily ... was enjoying prosperity

These two phrases are parallel and mean the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### my house ... my palace

These two phrases mean basically the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### a dream ... the images ... the visions

These phrases mean basically the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### made me afraid ... troubled me

These phrases are parallel and they mean the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### all the men of Babylon who had wisdom

"all the wise men of Babylon"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prosper.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prosper.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]

### Daniel 04:07

#### General Information:

In verses 1-18, Nebuchadnezzar describes in the first person his vision from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### who is named Belteshazzar

This can be stated in active form. AT: "who I named Belteshazzar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Belteshazzar

This was the name the Babylonians gave to Daniel. See how you translated this name in [Daniel 1:7](../01/06.md).

#### the spirit of the holy gods

Nebuchadnezzar believed that Daniel's power came from the false gods that Nebuchadnezzar worshiped.

#### no mystery is too difficult for you

The can be stated in positive form. AT: "you understand the meaning of every mystery"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]

### Daniel 04:10

#### General Information:

In verses 1-18, Nebuchadnezzar describes in the first person his vision from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### sights

things that you see

#### its height was very great

"it was very tall"

#### Its top reached to the heavens ... it could be seen to the ends of the whole earth

This is symbolic language that exaggerates how tall and how well-known the tree was. AT: "It seemed that its top reached up to the sky and that everyone in the world could see it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### its fruit was abundant

"there was a lot of fruit on the tree"

#### was food for all

"was food for all people and animals"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]

### Daniel 04:13

#### General Information:

In verses 1-18, Nebuchadnezzar describes in the first person his vision from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I saw in my mind

This refers to seeing a dream or vision. AT: "I saw in my dream"

#### He shouted and said

It can be made clear that the holy messenger was speaking to more than one person. AT: "He shouted to some people and said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Let the animals flee ... from its branches

"The animals will flee from under it and the bird will fly away from its branches"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Daniel 04:15

#### General Information:

In verses 1-18, Nebuchadnezzar describes in the first person his vision from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### General Information:

The holy messenger in the vision continues shouting to some people.

#### stump of its roots

This is the part of the tree that is left above the ground after a tree is cut down.

#### dew

the moisture on the ground that is found in the mornings

#### Let his mind be changed ... seven years pass by

Since the tree represents Nebuchadnezzar, the masculine pronouns "his" and "him" in verse 16 refer to the same tree as the neuter pronoun "it" in verse 15. AT: "The man's mind will change from a man's mind to an animal's mind for a period of seven years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Daniel 04:17

#### General Information:

In verses 1-18, Nebuchadnezzar describes in the first person his vision from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### It is a decision made by the holy ones

This can be stated in active form. AT: "The holy ones have made this decision" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the holy ones

This phrase probably refers to angels. AT: "the holy angels" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### those who are alive

"every living person" or "everyone"

#### gives them

"gives the kingdoms"

#### Belteshazzar

This was the name the Babylonians gave to Daniel. See how you translated this name in [Daniel 1:7](../01/06.md).

#### you are able to do so

"you are able to interpret it"

#### the spirit of the holy gods

Nebuchadnezzar believed that Daniel's power came from the false gods that Nebuchadnezzar worshiped. These are not the same as "the holy ones" in verse 17. See how you translated this phrase in [Daniel 4:8](./07.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Daniel 04:19

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### who was also named Belteshazzar

This can be stated in active form. AT: "who I also named Belteshazzar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### was greatly upset for a while, and his thoughts alarmed him

Daniel's understanding of the meaning of the vision is what alarmed him. This can be explicitly stated. AT: "did not say anything for some time because he was very worried about the meaning of the dream" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### may the dream be for those who hate you; may its interpretation be for your enemies

Daniel is expressing his wish that the dream was not about Nebuchadnezzar, even though he knew that it really was about the king.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Daniel 04:20

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### General Information:

Many terms in these verses are almost the same as [Daniel 4:10-12](./10.md). See how you translated those verses.

#### abundant

"very plentiful"

#### this tree is you, king

"this tree represents you, king"

#### Your greatness has grown ... your authority reaches

These two phrases mean similar things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Your greatness has grown

This phrase is using the word "grown" as a way of saying the king's greatness has increased. AT: "Your greatness has increased" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### to the heavens ... to the ends of the earth

These phrases are exaggerations to emphasize that everyone everywhere knew how great Nebuchadnezzar was. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Daniel 04:23

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### General Information:

This verse is almost the same as [Daniel 4:13-14](./13.md) and [Daniel 4:15-16](./15.md). See how you translated those verses.

#### the stump of its roots

This is the part of the tree that is left above ground after a tree is cut down.

#### in the middle of the tender grass of the field

"surrounded by the tender grass of the field"

#### dew

the moisture that settles on the ground in the mornings

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Daniel 04:24

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### General Information:

Many terms in these verses are almost the same as [Daniel 4:15-16](./15.md). See how you translated those verses.

#### that has reached you

"that you have heard"

#### You will be driven from among men

This can be stated in active form. AT: "Men will drive you away from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You will be made to eat grass

This can be stated in active form. AT: "You will eat grass" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 04:26

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### heaven rules

Here "heaven" refers to God who lives in heaven. AT: "God in heaven is the ruler of all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### let my advice be acceptable to you

This can be stated in active form. AT: "please accept my advice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Turn away from your iniquities

Here rejecting iniquity is spoken of as turning away from it. AT: "Reject your iniquities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the oppressed

This nominal adjective refers to people who are oppressed. AT: "people who are oppressed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### it may be that your prosperity will be extended

This can be stated in active form. AT: "God may extend your prosperity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]

### Daniel 04:28

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### All these things ... in Babylon

The information in [Daniel 4:28-29](./28.md) has been rearranged so its meaning can be more easily understood. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md)]])

#### Twelve months

"12 months" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Is this not the great Babylon ... for the glory of my majesty?

Nebuchadnezzar asks this question to emphasize his own glory. This can be translated as a statement. AT: "This is the great Babylon ... for the glory of my majesty!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### for the glory of my majesty

"to show people my honor and my greatness"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimemonth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimemonth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]

### Daniel 04:31

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### While the words were still on the lips of the king

This idiom means the king was still in the act of speaking. AT: "While the king was still speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a voice came from heaven

"he heard a voice from heaven"

#### King Nebuchadnezzar ... has been taken away from you

This can be stated in active form. AT: "King Nebuchadnezzar, a decree went out against you that this kingdom no longer belongs to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You will be driven away from people

This can be stated in active form. AT: "People will chase you away from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### anyone he wishes

"whoever he chooses"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Daniel 04:33

#### General Information:

Verses 19-33 use the third person to describe the punishment of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### This decree against Nebuchadnezzar was carried out immediately

This can be stated in active form. AT: "This decree against Nebuchadnezzar happened immediately" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He was driven away from people

This can be stated in active form. AT: "People chased him away from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his nails became like birds' claws

"his fingernails looked like birds' claws"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]

### Daniel 04:34

#### General Information:

In verses 34-37 Nebuchadnezzar speaks in the first person to describe his response to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### At the end of the days

This refers back to the seven years in [Daniel 4:32](./31.md).

#### my sanity was given back to me

This can be stated in active form. AT: "my sanity came back to me" or "I became sane again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I praised ... and I honored

The two phrases refer to the same action. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### For his reign is an everlasting reign ... his kingdom endures from all generations to all generations

These two phrases mean basically the same thing and are used to emphasize how God's reign never ends. AT: "He rules forever and his kingdom will never end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Daniel 04:35

#### General Information:

In verses 34-37 Nebuchadnezzar speaks in the first person to describe his response to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### All the earth's inhabitants are considered by him to be as nothing

This can be stated in active form. AT: "He considers all the earth's inhabitants as nothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### All the earth's inhabitants

"All the people on the earth"

#### the army of heaven

"the angel armies in heaven"

#### whatever suits his will

"whatever satisfies his purpose" or "anything he wants to do"

#### No one can stop him

It may be helpful to add additional detail. AT: "When he decides to do something, no one can stop him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### No one can say to him, 'Why have you done this?'

This can be stated as an indirect quotation. AT: "No one can question what he does." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Daniel 04:36

#### General Information:

In verses 34-37 Nebuchadnezzar speaks in the first person to describe his response to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### my sanity returned to me

Here his sanity is spoken of as if it was able to return by its own power. AT: "I became sane again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### my majesty and splendor returned to me

Here his majesty and splendor are spoken of as if they were able to return by their own power. AT: "I regained my majesty and my splendor again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### majesty and splendor

These words mean basically the same thing and emphasize the greatness of his glory. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### my noblemen sought my favor

"my noblemen requested my help again"

#### I was brought ... greatness was given to me

Here "throne" refers to his authority to rule. This can be stated in active form. AT: "I returned to rule my kingdom again, and I received even more greatness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### praise, extol, and honor

All three of these words have basically the same meaning and emphasize how greatly he praised God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### who walk in their own pride

This phrase uses "walk" to refer to the person who acts proud. AT: "who are proud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]

### Daniel 04:intro

#### Daniel 04 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 4:3 and 4:34-35.

####### Special concepts in this chapter #######

######## The king becomes insane ########

The king became insane until he realized that Yahweh was the ruler over everyone, including him. 

##### Links: #####

* __[Daniel 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Daniel 05

### Daniel 05:01

#### Belshazzar

This is the son of Nebuchadnezzar who became king after his father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### for a thousand

"for 1,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### he drank wine in front of

"he drank wine in the presence of"

#### the containers made of gold or silver

This can be stated in active form. AT: "the gold or silver containers that the Israelites had made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### containers

These were cups and other items that were small enough for a person to hold and to drink from them.

#### Nebuchadnezzar his father had taken

Here "Nebuchadnezzar" refers to Nebuchadnezzar's army. AT: "his father Nebuchadnezzar's army" or "the army of Nebuchadnezzar his father had taken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]

### Daniel 05:03

#### the gold containers that had been taken out of the temple

This can be stated in active form. AT: "the gold containers that the army of Nebuchadnezzar had taken out of the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### out of the temple, the house of God

"out of God's temple." The phrase "the house of God" tells us something more about the temple.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Daniel 05:05

#### At that moment

"As soon as they did that" or "Suddenly"

#### plaster

cement or mud that is spread on walls or ceilings to give them a smooth hard surface when it dries

#### the king's face changed

"his face became pale." This was caused by his fear.

#### his limbs

"his legs"

#### his knees were knocking together

This was the result of his extreme fear.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]

### Daniel 05:07

#### those known for their wisdom in Babylon

This refers back to those who claimed to speak with the dead, the wise men, and the astrologers.

#### Whoever explains this writing and its meaning will be clothed with purple and will have a gold chain around his neck

This can be stated in active form. AT: "I will give purple clothes and a gold neck chain to whoever explains this writing and its meaning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### clothed with purple

Purple cloth was rare and reserved for royal officials. AT: "dressed in royal clothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the third highest ruler

"the number three ruler" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 05:08

#### Belshazzar

This is the son of Nebuchadnezzar who became king after his father. See how you wrote this name in [Daniel 5:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the look on his face changed

"his face became even more pale." The face of the king grew even more pale than in [Daniel 5:6](./05.md).

#### perplexed

"confused"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]

### Daniel 05:10

#### the queen

Some modern versions understand this to be a reference to the queen mother, that is, to the king's mother. The queen mother received much honor in ancient Babylon.

#### King, live forever!

This was a normal way to greet the king.

#### Do not let the look on your face change

"There is no need for your face to look so pale"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/banquet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/banquet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Daniel 05:11

#### the spirit of the holy gods

The queen believed that Daniel's power came from the false gods that Nebuchadnezzar worshiped. See how you translated this phrase in [Daniel 4:8](../04/07.md).

#### In the days of your father

"When your father was ruling"

#### light and understanding and wisdom like the wisdom of the gods was found in him

This can be stated in active form. AT: "he had light and understanding and wisdom like the wisdom of the gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### King Nebuchadnezzar, your father the king

"Your father, King Nebuchadnezzar"

#### these qualities were found in this man Daniel, whom the king named Belteshazzar

This can be stated in active form. AT: "this same Daniel, whom the king named Belteshazzar, had all of these qualities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what has been written

"what has been written on the wall." This can be stated in active form. AT: "what the hand wrote on the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/learnedmen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]

### Daniel 05:13

#### Then Daniel was brought before the king

This can be stated in active form. AT: "Then they brought Daniel before the king" or "Then the soldiers brought Daniel before the king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### whom my father the king brought out of Judah

In this phrase "father" is being used to represent all of the soldiers. AT: "whom my father's soldiers brought out of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the spirit of the gods

Belshazzar believed that Daniel's power came from the false gods that Belshazzar worshiped. See how you translated a similar phrase in [Daniel 4:8](../04/07.md).

#### light and understanding and excellent wisdom are found in you

This can be stated in active form. AT: "you have light and understanding and excellent wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Daniel 05:15

#### Now the men known ... have been brought in before me

This can be stated in active form. AT: "Now the men known ... have come in before me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### make known to me

"tell me"

#### you will be clothed with purple and have a gold chain placed around your neck

This can be stated in active form. AT: "I will give you purple clothes and a gold neck chain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### clothed with purple

Purple cloth was rare and reserved for royal officials. AT: "dressed in royal clothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the third highest ruler

"the number three ruler" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 05:17

#### Let your gifts be for yourself, and

"I do not want your gifts, so"

#### all peoples, nations, and languages

This phrase uses the word "all" as a generalization that represents a large number. AT: "a great number of people, of different nations and languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### peoples, nations, and languages

Here "nations" and "languages" represent people from different nations who speak different languages. See how you translated this in [Daniel 3:4](../03/03.md). AT: "people from different nations and who speak different languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### trembled and feared him

These words mean basically the same thing and emphasize the intensity of the fear. AT: "were very afraid of him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### He put to death those he wanted to die

This phrase does not mean King Nebuchadnezzar put people to death himself, but rather those he commanded. AT: "Nebuchadnezzar commanded his soldiers to kill those he wanted to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He raised up those he wanted

"He raised up those he wanted to raise up"

#### wanted ... wished

These words here mean the same thing.

#### he humbled those he wished

"he humbled those he wished to humble"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]

### Daniel 05:20

#### his heart was arrogant

Here "heart" refers to the king himself. AT: "the king was arrogant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### his spirit was hardened

Here "spirit" refers to the king himself. His stubbornness is spoken of as if he were hardened. AT: "the king became stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### presumptuously

rudely and overly confident

#### he was brought down from his kingly throne

Here "throne" refers to his authority to rule. This can be stated in active form. AT: "the people took away his kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He was driven away from humanity

This can be stated in active form. AT: "The people chased him away from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he had the mind of an animal

Here "mind" represents his thoughts. AT: "he thought as an animal thinks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### dew

the moisture on the ground that is found in the mornings

#### anyone he wishes

"whomever he chooses"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 05:22

#### Belshazzar

This is the son of Nebuchadnezzar who became king after his father. See how you wrote this name in [Daniel 5:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### have not humbled your heart

Here "heart" refers to Belshazzar himself. AT: "have not humbled yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### You have lifted yourself up against the Lord

To rebel against God is spoken of as raising oneself up against him. AT: "You have rebelled against the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### From his house

What and where "his house" is can be stated clearly. AT: "From his temple in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### God who holds your breath in his hand

Here "breath" refers to life and "hand" refers to power or control. AT: "God who gives you breath" or "God who has control over your entire life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### all your ways

"everything you do"

#### this writing was done

This can be stated in active form. AT: "it wrote this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Daniel 05:25

#### This is the writing that was done

This can be stated in active form. AT: "This is the message that the hand wrote" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Mene, Mene, Tekel, and Pharsin

These are the Aramaic words that were written on the wall. Spell these words with the sounds that fit your language. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### 'Mene,' 'God has numbered

"'Mene' means 'God has numbered"

#### 'Tekel,' 'you are weighed

"'Tekel' means 'you are weighed"

#### 'Peres,' 'your kingdom

"'Peres' means 'your kingdom."

#### Peres

This is the singular form of "Pharsin" in 5:25.

#### you are weighed in the scales and are found lacking

Judging the worthiness of the king to rule is spoken of as weighing him. This means that the king is not worthy to rule. This can be stated in active form. AT: "God has examined your worthiness to rule, and he has found that you are not worthy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### your kingdom is divided and is given to the Medes and Persians

This can be stated in active form. AT: "God has divided your kingdom and given it to the Medes and Persians" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]

### Daniel 05:29

#### Belshazzar

This is the son of Nebuchadnezzar who became king after his father. See how you wrote this name in [Daniel 5:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### A chain of gold was put around his neck

This can be stated in active form. AT: "They put a chain of gold around his neck" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the third highest ruler

"the number three ruler" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### received the kingdom

"became the ruler of the kingdom"

#### when he was about sixty-two years old

"when he was about 62 years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]

### Daniel 05:intro

#### Daniel 05 General Notes ####

####### Special concepts in this chapter #######

######## The writing on the wall ########

God told the new king that he had failed and God was replacing him, showing that God is the real ruler over everything, even kingdoms that do not worship him. 

####### Other possible translation difficulties in this chapter #######
######## Mene, Mene, Tekel, Upharsin ########
These are words in Aramaic. Daniel "transliterates" these words by writing them with Hebrew letters, and then he explains their meanings. In the ULB and UDB they are written with English letters. Translators are encouraged to write them using the letters of the target language alphabet.

##### Links: #####

* __[Daniel 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Daniel 06

### Daniel 06:01

#### Connecting Statement:

The events in this chapter take place after the Persians conquered the Babylonians and Darius the Mede began to rule in Babylon.

#### It pleased Darius

"King Darius decided"

#### 120 provincial governors

"one hundred and twenty provincial governors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Over them

The word "them" refers to the 120 provincial governors.

#### so that the king should suffer no loss

"so that nothing should be stolen from the king" or "so that no one would steal anything from the king"

#### was distinguished above

"excelled above" or "was more capable than"

#### he had an extraordinary spirit

Here "spirit" refers to Daniel. It means he had was unusually capable. AT: "he was and exceptional person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### extraordinary

"impressive" or "excellent"

#### to put him over

"to give him authority over" or "to put him in charge of"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Daniel 06:04

#### Then the other chief administrators and the provincial governors ... for the kingdom

The other administrators were jealous of Daniel. This can be made explicit. AT: "Then the other chief administrators and the provincial governors became jealous. So they looked for mistakes in the work Daniel did for the kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### No mistakes or negligence was found in him

This can be stated in active form. AT: "They could find no mistakes or negligence in his work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### negligence

overly looking your responsibilities

#### to complain against this Daniel

"to complain about Daniel"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Daniel 06:06

#### brought a plan before the king

"presented a plan to the king"

#### may you live forever!

This was a normal way to greet a king.

#### for thirty days

"for 30 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### whoever makes a petition

"whoever makes a request"

#### that person must be thrown into the den of lions

This can be stated in active form. AT: "your soldiers must throw that person into the den of lions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### den of lions

This may refer to a room or pit where lions were kept.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]

### Daniel 06:08

#### Connecting Statement:

In verse 8, the administrators continue to speak to the king.

#### as directed by the laws

"according to the laws"

#### cannot be repealed

"cannot be canceled"

#### making the decree into a law

"making the order into a law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]

### Daniel 06:10

#### When Daniel learned that the document had been signed into law

It is important to the story to state clearly that Daniel knew about the new law before he prayed to God.

#### now his windows were open in his upper room toward Jerusalem

This is background information that explains how Daniel's enemies knew he was praying to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### gave thanks before his God

"gave thanks to his God"

#### plot

a plan with evil intent

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Daniel 06:12

#### Did you not make a decree ... lions?

They asked this question to make the king confirm that he had made the decree.

#### who makes a petition

"who makes a request"

#### den of lions

This may refer to a room or pit where lions were kept. See how you translated this in [Daniel 6:7](./06.md).

#### as directed by the law

"according to the law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]

### Daniel 06:13

#### That person Daniel

This is not a respectful way of referring to Daniel. They intentionally used this phrase to avoid giving Daniel the respect he was due as a chief administrator.

#### who is one of the people of the exile from Judah

"who is an immagrant from Judah"

#### pays no attention to you

This idiom means he ignores the king. AT: "does not obey you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he applied his mind

Here "mind" refers to his thinking. AT: "he thought very hard about how" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He labored

This refers to mental labor, rather than to physical labor.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Daniel 06:15

#### no decree ... can be changed

The men were implying that since no decree or statute of the king can be changed, Daniel must be thrown into the pit of lions. This can be stated clearly if needed. AT: "no decree ... can be changed. They must throw Daniel into the pit of lions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md)]]

### Daniel 06:16

#### they brought in Daniel

"his soldiers went and got Daniel"

#### lions' den

This may refer to a room or pit where lions were kept. See how you translated this in [Daniel 6:7](./06.md).

#### May your God ... rescue you

The king is expressing his desire for God to save Daniel.

#### rescue you

"save you from the lions"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Daniel 06:17

#### den

This may refer to a room or pit where lions were kept. See how you translated this in [Daniel 6:7](./06.md).

#### the king sealed it with his own signet ring and with the signet rings of his nobles ... concerning Daniel

The function of the signet ring can be stated clearly. The king and the noblemen pressed their rings into a seal made of wax. AT: "the king pressed his signet ring into a wax seal, the nobles did this too. No one was allowed to break the seal and help Daniel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### nothing might be changed concerning Daniel

"no one could help Daniel"

#### he went through the night fasting

This symbolic act showed that the king was worried about Daniel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### No entertainment was brought before him

This can be stated in active form. AT: "He did not have anyone entertain him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sleep fled from him

Sleep is spoken of as if it could run away from the king. AT: "he did not sleep at all that night" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]

### Daniel 06:19

#### lions' den

This may refer to a room or pit where lions were kept. See how you translated this in [Daniel 6:7](./06.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Daniel 06:21

#### For I was found blameless

This can be stated in active form. AT: "He knows that I have done nothing wrong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I have done you no harm

"I have not harmed you at all"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]

### Daniel 06:23

#### den

This may refer to a room or pit where lions were kept. See how you translated this in [Daniel 6:7](./06.md).

#### No harm was found on him

This can be stated in active form. AT: "They did not find any wounds on Daniel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]

### Daniel 06:24

#### den of lions

This may refer to a room or pit where lions were kept. See how you translated this in [Daniel 6:7](./06.md).

#### Before they reached the floor

"Before they reached the floor of the lions' den"

#### broke all their bones to pieces

"crushed their bones"

#### peoples, nations, and languages

Here "nations" and "languages" represent people from different nations who speak different languages. See how you translated this in [Daniel 3:4](../03/03.md). AT: "people from different nations and who spoke different languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in all the earth

King Darius wrote his message to his entire kingdom which was huge. Here it says "all the earth" as a generalization to emphasis how large his kingdom was, though it did not include everyone on the earth. AT: "in his kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### May peace increase for you

This is a form of greeting that is used to wish someone well in all areas of life.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Daniel 06:26

#### Connecting Statement:

This continues to state the message that Darius sent to everyone in his kingdom.

#### tremble and fear

These two words are similar and can be combined. AT: "shake with fear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the God of Daniel

"the God that Daniel worships"

#### he is the living God and lives forever

The two phrases "the living God" and "lives forever" express the same concept, that God lives forever. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### his kingdom shall ... his dominion shall

These two phrases are parallel, emphasizing how God's kingdom will never end. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### his kingdom shall not be destroyed

This can be stated in active form. AT: "no one will destroy his kingdom" or "his kingdom will last forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his dominion shall be to the end

"he will rule forever"

#### he has kept Daniel safe from the strength of the lions

"he has not allowed the strong lions to hurt Daniel"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Daniel 06:28

#### during the reign of Darius and during the reign of Cyrus the Persian

Cyrus the Persian was the king who ruled after Darius.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]

### Daniel 06:intro

#### Daniel 06 General Notes ####

####### Structure and formatting #######

Some translations indent the content of letters. The ULB does this with the letter in 6:25-27.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in the letter in 6:26-27.

####### Special concepts in this chapter #######
######## Daniel and the lions ########

Daniel was thrown into the lions' den for praying to Yahweh, but Yahweh protected him and the lions did not hurt him at all. 

##### Links: #####

* __[Daniel 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Daniel 07

### Daniel 07:01

#### General Information:

Chapters 7 and 8 are not in chronological order. They happened while Belshazzar was still the king, before the rule of Darius and Cyrus that was discussed in chapter 6.

#### General Information:

In Daniel's vision, he saw animals that were symbols of other things. Later in the vision someone explains the meaning of those symbols. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### Belshazzar

This was the name of Nebuchadnezzar's son, who became king after him. See how you wrote this name in [Daniel 5:1](../05/01.md).

#### a dream and visions

The words "dream" and "visions" both refer to the same dream that is described in this chapter. AT: "visions while he was dreaming" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the four winds of heaven

"winds from everywhere" or "strong winds from all four directions"

#### stirring up

"whipped up" or "agitated" or "caused high waves in"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]

### Daniel 07:04

#### The first was like a lion but had eagle's wings

This was a symbolic creature, and not an animal that exists. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### its wings were torn off and it was lifted from the ground and made to stand on two feet, like a man

This can be stated in active form. AT: "someone tore off its wings and lifted it up from the ground and made it stand on two feet like a human being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The mind of a man was given to it

Here "mind" refers to thinking. This can be stated in active form. AT: "Someone gave it the ability to think like a human being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a second animal, like a bear

This was not an actual bear, but a symbolic animal that was similar to a bear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### ribs

large curved bones of the chest that connect to the spine

#### It was told

This can be stated in active form. AT: "Someone told it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]

### Daniel 07:06

#### another animal, one that looked like a leopard

This was not an actual leopard, but a symbolic animal that was similar to a leopard. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### four wings ... four heads

The four wings and four heads are symbols, but their meaning is unclear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### it had four heads

"the animal had four heads"

#### It was given authority to rule

This can be stated in active form. AT: "Someone gave it authority to rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a fourth animal ... it had ten horns

This is also not an actual animal. It is a symbolic creature. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### trampled underfoot

"walked on and crushed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leopard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leopard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Daniel 07:08

#### General Information:

Daniel continues to describe his vision of the fourth animal that the saw in [Daniel 7:7](./06.md).

#### the horns

Translators may write a footnote like this: "Horns are a symbol of power and represent powerful leaders." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Three of the first horns were wrenched out by the roots

This can be stated in active form. AT: "The little horn tore out three of the first horns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a mouth that was boasting about great things

Here the horn was boasting, using its mouth to do so. AT: "the horn had a mouth and boasted about doing great things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]

### Daniel 07:09

#### General Information:

Most of the text of verses 9-14 is symbolic language with parallel lines that have similar meaning. For this reason, the ULB and UDB present them in poetic form. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### thrones were set in place

This can be stated in active form. AT: "someone set thrones in their places" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Ancient of Days

This is a title for God that means he is eternal. AT: "the One Who Has Lived Forever" or "the One Who Has Always Lived"

#### took his seat ... His clothing ... the hair of his head

This passage describes God as sitting down, with clothing and hair like a person. This does not mean that God really is like this, but it is how Daniel saw God in a vision.

#### took his seat

This is an idiom that means he sat down. AT: "sat down on his throne" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### His clothing was as white as snow

His clothing is compared to snow to show that it was very white. AT: "His clothing was very white"

#### the hair of his head was like pure wool

Something about God's hair looked like pure wool. Possible meanings are that 1) it was very white or 2) it was thick and curly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### pure wool

"clean wool" or "wool that is washed"

#### His throne was flames ... its wheels were burning fire

This describes the throne of God and its wheels as if they were made of fire. The words "flames" and "burning fire" mean basically the same thing and can be translated the same way.

#### its wheels

It is unclear why God's throne is described as having wheels. Thrones normally do not have wheels, but the text clearly states that this throne has some kind of wheels. Use a general term for "wheels" if possible.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Daniel 07:10

#### General Information:

Daniel continues to describe his vision of the court in heaven and the response to the fourth animal that he saw in [Daniel 7:7](./06.md).

#### General Information:

Most of the text of verses 9-14 is symbolic language with parallel lines that have similar meaning. For this reason, the ULB and UDB present them in poetic form. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### A river of fire flowed out from before him

The quick way in which fire came from the presence of God is spoken of as if it was water flowing in a river. AT: "Fire poured out in front of him like water in a river" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### before him

The word "him" refers to God, the Ancient of Days from [Daniel 7:9](./09.md).

#### millions

This probably refers to a large group rather than to a precise number. AT: "thousands of thousands" or "great numbers of people"

#### one hundred million

This probably refers to a large group rather than to a precise number. AT: "tens of thousands times tens of thousands" or "uncountable numbers of people"

#### The court was in session

This means that God, the judge, was ready to investigate the evidence and make his judgment. AT: "The judge was ready to judge" or "The judge was seated"

#### the books were opened

These are the books that contain the evidence to be used in court. AT: "the books of evidence were opened"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Daniel 07:11

#### General Information:

Daniel continues to describe his vision of the court in heaven and the response to the fourth animal that he saw in [Daniel 7:7](./06.md).

#### the animal was killed ... to be burned up

This can be stated in active form. AT: "they killed the fourth animal, destroyed its body, and gave it to someone to burn it up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the animal was killed

The animal was killed because the judge determined that it was guilty. AT: "they executed the animal" or "the judge commanded and they killed the animal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the animal

This refers to the fourth animal that had the ten horns and the horn that spoke boastfully. AT: "the most frightening animal" or "the animal that had the boastful horn"

#### the rest of the four animals

It may be clearer to say, "the other three animals."

#### their authority to rule was taken away

This can be stated in active form. AT: "the judge took away their authority to rule" or "their authority to rule ended" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### their lives were prolonged for a period of time

This can be stated in active form. AT: "they continued to live for a period of time" or "the judge let them live a little longer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Daniel 07:13

#### General Information:

Most of the text of verses 9-14 is symbolic language with parallel lines that have similar meaning. For this reason, the ULB presents them in poetic form. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### I saw one coming ... like a son of man

The person that Daniel saw was not a normal man, but had a human figure like a man. "I also saw that night someone coming who resembled a son of man, that is, he had a human figure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### with the clouds of heaven

"with the clouds of the sky"

#### the Ancient of Days

This refers to God who is eternal. See how you translated this title in [Daniel 7:9](./09.md)

#### was presented before him

This can be stated in active form. AT: "they presented this son of man to the Ancient of Days" or "he stood before him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Authority to rule and glory and royal power were given to him

This can be stated in active form. AT: "The one who looked like a son of man received authority to rule, glory, and royal power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### royal power

This, here, refers to "authority."

#### peoples, nations, and languages

Here "nations" and "languages" represent people from different nations who speak different languages. See how you translated this in [Daniel 3:4](../03/03.md). AT: "people from different nations and who speak different languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will not pass away ... will never be destroyed

These two phrases mean the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### that will never be destroyed

This can be stated in active form. AT: "that no one will ever destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 07:15

#### my spirit was grieved inside of me ... the visions I saw in my mind troubled me

These two phrases describe how Daniel was feeling. The second one gives more information about the first one, explaining about his grieved spirit. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### my spirit was grieved inside of me

Here "my spirit" refers to Daniel himself. AT: "I was very sad inside" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### one of them standing there

This is one of the heavenly beings who were standing before God's throne. Possible meanings 1) these are angels, spirits who serve God 2) these are people who have died and are now in heaven.

#### to show me

"to tell me" or "to explain to me"

#### these things

"the things I had seen"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Daniel 07:17

#### These large animals, four in number,

"These four large animals"

#### are four kings

"represent four kings"

#### four kings that will arise from the earth

Here "from the earth" means they are real people. AT: "four kings who will come to power on the earth" or "four men who will rise up from among the people of the earth and become kings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they will possess it

"they will rule over it"

#### forever and ever

This repetition of ideas emphasizes that this kingdom will never come to an end. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Daniel 07:19

#### very horrifying

"very frightening"

#### trampled

"walked on and crushed"

#### the ten horns on its head

"the ten horns on the head of the fourth animal"

#### grew up, and before which the three horns fell down

"grew up, and about the three horns that fell down in front of it" or "grew up, and about the three horns that fell down because of it"

#### before which the three horns fell down

Here "fell down" is a euphemism that means they were destroyed." AT: "which destroyed the three horns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### the mouth that boasted

"its mouth that boasted" or "the mouth of the new horn, that boasted"

#### that seemed greater than its companions

the horn with the eyes and a mouth seemed to be greater than the other horns

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Daniel 07:21

#### this horn

"this fourth horn." This refers to the horn that is described in [Daniel 7:20](./19.md).

#### until the Ancient of Days came, and justice was given

This can be stated in active form. AT: "until the Ancient of Days came and brought justice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Ancient of Days

This is a title for God that emphasizes that he is eternal. See how you translated this title in [Daniel 7:9](./09.md).

#### the holy people received the kingdom

This can be stated in active form. AT: "God gave his kingdom to his holy people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 07:23

#### General Information:

Most of the text of verses 23-27 is symbolic language. For this reason, the ULB presents them in poetic form. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### This is what that person said

This is the person that Daniel approached in [Daniel 7:16](./15.md).

#### that person said

"that person answered"

#### As for the fourth animal ... As for the ten horns

"Concerning the fourth animal ... Concerning the ten horns" or "Now, about the fourth animal ... Now, about the ten horns"

#### It will devour ... it into pieces

This does not mean the fourth kingdom will destroy the planet, but that it will brutally attack, conquer, and destroy all other kingdoms on earth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### out of this kingdom ten kings will arise

They will rule one after the other. This can be stated explicitly. AT: "ten kings will rule over this fourth kingdom, one after another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### another will arise after them

This other king is not one of the ten. It may be helpful to refer to him as "the eleventh king." AT: "after that an eleventh king will become powerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He will be different from the previous ones

"He will be different from the other ten kings"

#### he will conquer the three kings

He will defeat three of the original ten kings. It may be helpful to state that those three kings are represented by the three horns that were pulled out. AT: "he will defeat the three kings that were represented by the three horns that were pulled out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 07:25

#### General Information:

The man in Daniel's vision continues talking to Daniel.

#### General Information:

Most of the text of verses 23-27 is symbolic language. For this reason, the ULB presents them in poetic form. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### He will speak words against the Most High

This means that the newest king will openly disagree with and say bad things about the Most High. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### He will try ... into his hand

The words "He" and "his" refer to the newest king, not the Most High.

#### the holy people

"God's holy people"

#### change the festivals and the law

Both terms refer to the law of Moses. The festivals were an important part of the religion of Israel in the Old Testament.

#### These things will be given into his hand

Here "his hand" refers to his control. This can be stated in active form. AT: "The newest king will control the religous festivals and laws" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### one year, two years, and half a year

This means "three and half years." This is not the normal way the Israelites counted. Try to translate it in a way that preserves this way of counting. AT: "one year plus two years plus six months"

#### the court will be in session

This means that the judge will be ready to investigate evidence and make his judgment. AT: "the judge will judge" or "The judge will sit down"

#### they will take his royal power away

"the members of the court will take the royal power away from the newest king"

#### royal power

This, here, refers to "authority." See how you translated this in [Daniel 7:14](./13.md).

#### to be consumed and destroyed at the end

This can be stated in active form. AT: "and consume and destroy it in the end" or "and completely destroy his royal power in the end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]

### Daniel 07:27

#### General Information:

The man in Daniel's vision continues talking to Daniel.

#### General Information:

Most of the text of verses 23-27 is symbolic language. For this reason, the ULB presents them in poetic form. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### The kingdom and the dominion ... will be given to the people

This can be stated in active form. AT: "God will give the kingdom and the dominion ... to the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The kingdom and the dominion

These two terms mean basically the same thing and emphasize that this will concern all forms of official authority. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the greatness of the kingdoms

The abstract noun "greatness" can be translated with the adjective "great." AT: "everything that is great about the kingdoms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### of the kingdoms under the whole heaven

The idiom "under the whole heaven" refers to the kingdoms on earth. AT: "of all the kingdoms on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### His kingdom

"The kingdom of the Most High"

#### an everlasting kingdom

"a kingdom that will exist forever" or "a kingdom that will never end"

#### Here is the end of the matter

This means that Daniel has finished describing the vision. AT: "That is what I saw in my vision" or "This is the end of the description of what I saw in my vision"

#### my face changed in appearance

"my face became pale"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]

### Daniel 07:intro

#### Daniel 07 General Notes ####

####### Structure and formatting #######
Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 7:9-10, 13-14, and 23-27.

####### Special concepts in this chapter #######
######## The four beasts ########

There will be four successive kingdoms before Yahweh sets up his eternal kingdom. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]])

######## The Son of Man ########

God will give the Son of Man an eternal kingdom and he will judge people from the books. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]])

##### Links: #####

* __[Daniel 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Daniel 08

### Daniel 08:01

#### General Information:

Chapters 7 and 8 are not in chronological order. They happened while Belshazzar was still the king, before the rule of Darius and Cyrus that was discussed in chapter 6.

#### General Information:

In Daniel's vision, he saw animals that were symbols of other things. Later in the vision someone explains the meaning of those symbols. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### In the third year

"In year three" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Belshazzar

This is the son of Nebuchadnezzar who became king after his father. See how you translated this name in [Daniel 5:1](../05/01.md).

#### had a vision appear to me (after the one ... first)

This is background information to remind the reader that this is Daniel's second vision. AT: "had a second vision appear to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### fortress

a walled city that was guarded and protected

#### Susa ... Elam ... Ulai Canal

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Canal

A canal is a narrow man-made waterway.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md)]]

### Daniel 08:03

#### a ram with two horns

It is normal for rams to have two horns. These horns, however, have symbolic meaning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### but the longer ... passed up in length by it

"but the longer one grew more slowly than the shorter one, and the shorter one grew to be even longer than it"

#### I saw the ram charging

"I saw the ram rushing" or "I saw the ram running very quickly"

#### to rescue anyone out of his hand

Rams do not have hands. Here "hand" refers to the ram's power. AT: "to rescue anyone from him" or "to rescue anyone from his power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Daniel 08:05

#### across the surface of the whole earth

The phrase "the whole earth" is an exaggeration that means he came from far away. AT: "from far away across the surface of the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### The goat had a large horn between his eyes

Goats have two horns on the sides of their heads. This image should be explained. AT: "The goat had a single large horn in the center of his head" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I had seen the ram standing on the bank of the canal

This phrase is inserted as background information to explain where the ram was located. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### in a powerful rage

"and it was very angry"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md)]]

### Daniel 08:07

#### trampled

to crush something by stepping on it

#### the ram from his power

"the ram from the goat because of his power"

#### the goat became very large

"the goat became very large and strong"

#### the large horn was broken

This can be stated in active form. AT: "something broke off the large horn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### toward the four winds of the heavens

Here "the four winds of heaven" is an idiom that refers to the four main directions (north, east, south, west) from which the winds blow. AT: "in four different directions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Daniel 08:09

#### but which became very large

"but it became very large"

#### in the south, in the east, and in the land of beauty

This probably means it pointed in those directions. This can be stated. AT: "and pointed toward the south and then toward the east and then toward the beautiful land of Israel"

#### the land of beauty

This is a reference to the land of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### It became so large as to engage in war

Here the horn is given qualities of a person and is engaging in war. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Some of that army ... thrown down to the earth

This can be stated in active form. AT: The horn threw some of that army and some of the stars down to the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it trampled on them

Here the horn is given qualities of a person that tramples on the stars and on the army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Daniel 08:11

#### Connecting Statement:

Daniel continues describing his vision of the horn. (See: [Daniel 8:9](./09.md))

#### General Information:

The horn is given qualities of a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the commander of the army

This refers to God himself, who is the leader of the angel army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It took away from him the regular burnt offering

Here "took away" means the horn stopped the offering. Here "him" refers to God, the commander of the army. AT: "It stopped the people from making their regular burnt offering to him"

#### the place of his sanctuary was polluted

This can be stated in active form. AT: "it defiled his sanctuary" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The horn will throw truth down to the ground

The horn ignoring truth and godliness is spoken of as if it will throw truth to the ground. AT: "The horn will reject the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/divine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/divine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Daniel 08:13

#### holy one

"angel"

#### the handing over of the sanctuary

"the surrender of the sanctuary"

#### heaven's army being trampled on

This can be stated in active form. AT: "the horn trampling on heaven's army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### 2,300 evenings and mornings

"Two thousand three hundred evenings and mornings." Here "evenings and mornings" is a merism that refers to everything in between, which means full days. AT: "2,300 sunsets and sunrises" or "2,300 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the sanctuary will be put right

"the temple will be purified and set in order again"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Daniel 08:15

#### a man's voice calling between the banks of the Ulai Canal

Here a man is being referred to by his voice. AT: "a man calling from the Ulai Canal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Ulai Canal

A canal is a narrow man-made waterway. See how you translated this name in [Daniel 8:2](./01.md).

#### prostrated myself on the ground

This is an act of worship in which someone lies flat on the ground. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the time of the end

"the final days" or "the end of the world." This does not refer to the final moment in time, but rather to the events that will happen immediately before the end.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gabriel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gabriel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]

### Daniel 08:18

#### a deep sleep

This is a type of sleep when someone is sleeping heavily and does not wake up easily.

#### the time of wrath

This refers to the time when God will judge. This can be made explicit. AT: "the time when God judges in anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the appointed time for the end

"the time when the world will end"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]

### Daniel 08:20

#### General Information:

In these verses, the angel explains to Daniel the symbolic meaning of the things he saw in his vision. The animals and horns actually represent human rulers and kingdoms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### two horns—they are

"two horns—they represent"

#### the kings of Media and Persia

Possible meanings are 1) this refers to the kings of Media and Persia or 2) this is a metonym in which the kings represents the kingdoms of Media and Persia. AT: "the kingdoms of Media and Persia" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the king of Greece

Possible meanings are 1) this refers to the king of Greece or 2) this is a metonym in which the king represents the kingdom of Greece. AT: "the kingdom of Greece" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The large horn between his eyes is

"The large horn between his eyes represents"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md)]]

### Daniel 08:22

#### General Information:

In these verses, the angel explains to Daniel the symbolic meaning of the things he saw in his vision. The animals and horns actually represented human rulers or kingdoms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### As for the horn that was broken ... four others arose

"Where the large horn was broken off, four others arose"

#### four kingdoms will arise from his nation

The four horns represent the four new kingdoms. This can be made explicit. AT: "they represent the four kingdoms into which the kingdom of the first king will be divided" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but not with his great power

"but they will not have as much power as the king represented by the large horn"

#### At the latter time of those kingdoms

"As those kingdoms approach their end"

#### shall have reached their limit

"have reached their full" or "have run their course"

#### grim-faced

This means someone who looks defiant, or like he will refuse to obey.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 08:24

#### General Information:

In these verses, the angel explains to Daniel the symbolic meaning of the things he saw in his vision. The animals and horns actually represented human rulers or kingdoms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### but not by his own power

"but someone else will give him his power"

#### he will make deceit prosper

Here "deceit" is spoken of as if it is a person who will prosper. AT: "the amount of deception will increase" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### under his hand

Here "hand" refers to his rule. AT: "under his rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### King of kings

This refers to God.

#### he will be broken

Here "he" refers to his power. AT: "his rule will end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### not by any human hand

Here "hand" refers to power. This can be also stated in positive form. AT: "not by any human power" or "by divine power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 08:26

#### General Information:

The angel continues to instruct Daniel about the visions that Daniel saw.

#### seal up the vision

The angel speaks about the vision as if it were a scroll that could be closed with a wax seal. This prevented anyone from seeing the contents until the seal was broken. AT: "close and seal up what you have written about the vision" or "do not tell anyone about the vision now" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]

### Daniel 08:27

#### was overcome and lay weak for several days

"was exhausted and lay in bed sick for several days"

#### went about the king's business

"did the work that the king had assigned to me"

#### I was appalled by the vision

"I was dismayed by the vision" or "I was very confused by the vision"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 08:intro

#### Daniel 08 General Notes ####

####### Special concepts in this chapter #######

######## The vision of the ram and the male goat  ########

Although specific interpretation of this vision is not given, most scholars believe Daniel saw Greece overthrowing Media-Persia before breaking up into four kingdoms. One of these kingdoms stopped the temple worship for a while and then it was restored. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]])

##### Links: #####

* __[Daniel 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Daniel 09

### Daniel 09:01

#### General Information:

Chapters 7 and 8 were not in chronological order. They happened while Belshazzar was still the king. Chapter 9 now returns to the events of the reign of Darius who became king in chapter 6.

#### It was Ahasuerus who had been made king over the realm of the Babylonians

This is background information about who Ahasuerus was. The UDB places this in parentheses to make that clear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### who had been made king over the realm of the Babylonians

This can be stated in active form. AT: "who became king over the realm of the Babylonians" or "who conquered the Babylonians" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### over the realm

"over the country" or "over the kingdom"

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### there would be seventy years until Jerusalem's abandonment would end

"from the time Jerusalem was destroyed, it would remain in ruins for 70 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### abandonment

this means no one would help or rebuild Jerusalem during that time

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeremiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeremiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Daniel 09:03

#### I turned my face to the Lord God

Here "face" represents Daniel's attention. AT: "I focused my attention on the Lord God" or "I directed my thoughts toward the Lord God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to seek him

Those who want to know Yahweh and please him are spoken of as if they are literally seeking to find Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fasting, wearing sackcloth, and sitting in ashes

These are symbolic acts of repentance and sorrow. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### I made confession of our sins

"I confessed our sins"

#### you are the one who keeps the covenant and is faithful to love those

"you do what what you said you would do in your covenant, and you faithfully love those"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Daniel 09:05

#### General Information:

Daniel continues praying to the Lord about the people of Israel.

#### We have sinned and have done what is wrong

These two phrases express one idea in two different ways for emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### We have acted wickedly and we have rebelled

These two phrases express one idea in two different ways for emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### your commands and decrees

The words "commands" and "decrees" share similar meanings and refer to the whole law. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### We have not listened to your servants

Here "not listened" means they did not obey their message. AT: "We have not obeyed the message of your prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### spoke in your name

Here "name" refers to God's authority. AT: "spoke with your authority" or "spoke as your representative" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the people of the land

Here "land" refers to Israel. AT: "the Israelite people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 09:07

#### General Information:

Daniel continues praying to the Lord about the people of Israel.

#### To you, Lord, belongs righteousness

Being righteous is spoken of as if "righteousness" were an object that belongs to Yahweh. The abstract noun "righteousness" can be stated as "righteous." AT: "Lord, you are righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### To us today, however, belongs shame on our faces—for the people

Being ashamed is spoken of as if "shame" were an object that belongs to people. The abstract noun "shame" can be stated as "ashamed." AT: "But as for us, we are ashamed of what we have done—the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### To us today

The word "us" includes Daniel and the Israelites, but it does not include God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### belongs shame on our faces

This idiom means their shame is visible to all. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### because of the great treachery that we committed against you

"because we greatly betrayed you" or "because we were very unfaithful to you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Daniel 09:09

#### General Information:

Daniel continues praying to the Lord about the people of Israel.

#### To the Lord our God belong compassion and forgiveness

Having these traits is spoken of as if they belonged to the Lord. AT: "The Lord our God is compassionate and forgives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We have not obeyed the voice of Yahweh our God

Here "voice" refers to the commands that Yahweh spoke. AT: "We have not obeyed what Yahweh told us to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### turned aside

The words "turned aside" mean that Israel stopped obeying God's laws. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### that are written in the law of Moses

This can be stated in active form. AT: "that Moses wrote about in the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### have been poured out on us

The abundance of the curse and the oath are spoken of as if they were poured out like water. This can be stated in active form. AT: "you have brought upon us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Daniel 09:12

#### General Information:

Daniel continues praying to the Lord about the people of Israel.

#### For under the whole of heaven

This is an idiom. AT: "For in the whole world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### there has not been done anything

"nothing has been done." This can be stated in active form. AT: "nothing has happened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what has been done to Jerusalem

This can be stated in active form. AT: "what you have done to Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### As it is written in the law of Moses

This can be stated in active form. AT: "As Moses wrote in the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### turning away from our iniquities

Here stopping evil activity is spoken of as turning away from them. AT: "stopping our evil actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh has kept the disaster ready

"Yahweh has prepared this disaster"

#### we have not obeyed his voice

Here "voice" refers to the things that Yahweh commanded. AT: "we have not done what he told us to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Daniel 09:15

#### with a mighty hand

Here "mighty hand" is a metonym for strength. AT: "with great strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you have made a famous name for yourself, as in this present day

"you caused people to know how great you are, as you still do today"

#### still we sinned; we have done wicked things

These two clauses mean basically the same thing and are used together to emphasize how bad sin is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### we sinned; we have done wicked things

Daniel and Israel sinned and did wicked things, but "we" does not include God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### your anger and your wrath

The words "anger" and "wrath" mean basically the same thing and emphasize how terrible God's anger is when he acts on it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### your holy mountain

This mountain may be holy because God's temple is there. AT: "the mountain where your holy temple is"

#### our sins ... our ancestors

Here "our" refers to Daniel and Israel, but not to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### an object of scorn

"a target of disrespect"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]

### Daniel 09:17

#### Now

This does not mean "at this moment", but it is a way to show that the next phase in Daniel's prayer is about to start.

#### your servant ... his pleas for mercy

The words "your servant" and "his" here refer to Daniel. He speaks about himself in the third person as a sign of respect for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### pleas for mercy

"requests for mercy"

#### make your face shine on

The writer speaks of Yahweh acting favorably as if Yahweh's face shone a light. AT: "act kindly toward" or "act with favor toward" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your sanctuary

This refers to the temple in Jerusalem.

#### open your ears and listen

To "open the ears" is an idiom that means to listen. These two phrases means the same thing and emphasize Daniel's desire for God to listen to his prayer. AT: "please listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### open your eyes and see

To "open the eyes" is an idiom that means to see. These two phrases means the same thing and emphasize Daniel's desire for God to pay attention to his prayer. AT: "notice us" or "pay attention" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### is called by your name

Here "name" represents ownership. AT: "is your city" or "belongs to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### do not delay

This can be stated in positive form. AT: "act quickly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Daniel 09:20

#### my people Israel

"the people of Israel to whom I belong"

#### God's holy mountain

The mountain may be holy because of the temple. AT: "the mountain where God's holy temple is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the man Gabriel

This is the same angel Gabriel who appeared in the form of a man in [Daniel 8:16](../08/15.md). AT: "Gabriel, who appeared as a man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in the vision at the first

This may refer to the first vision that Daniel had while he was awake. AT: "in the previous vision" or "in the vision I saw before" or "in a vision before"

#### flew down to me in rapid flight

"flew down to me quickly"

#### at the time of the evening sacrifice

The Jewish people sacrificed to God each evening just before the sun went down.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gabriel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gabriel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Daniel 09:22

#### insight and understanding

The words "insight" and "understanding" mean the same thing and emphasize that Gabriel will help Daniel to understand the message completely. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the order was given

This can be stated in active form. AT: "God gave the order" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### consider this word

"think about this message"

#### the revelation

This refers back to the prophesy of Jeremiah in [Daniel 9:2](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]

### Daniel 09:24

#### Seventy sevens ... seven sevens ... and sixty-two sevens

This is not the normal way the Israelites counted. If possible, try to translate in a way that preserves this use of the number seven. AT: "Seventy times seven years ... seven times seven years ... and sixty-two times seven years"

#### Seventy sevens are decreed for your people and your holy city to

God decreed that he would do the things in this verse for the people and the holy city.

#### your people and your holy city

The word "your" here refers to Daniel. The people are the Israelites and the holy city is Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### to end the guilt and put an end to sin

The idea is repeated to emphasize how certain it is that this will happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### to carry out the vision

Here "carry out" is an idiom that means to accomplish. AT: "to accomplish the vision" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the vision and the prophecy

These words in this context mean the same thing. They ensure Daniel that Jeremiah's vision was indeed a prophecy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Know and understand

These words are used together to make the importance clear. AT: "You must clearly understand" or "You must know for sure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the anointed one

Anointing is a symbolic act to show that someone is chosen. AT: "the person that God anoints" or "the person that God chooses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### seven sevens ... and sixty-two sevens

These added together are 69 of the 70 sevens spoken of in verse 24.

#### Jerusalem will be rebuilt

This can be stated in active form. AT: "People will rebuild Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### moat

a deep ditch around a city or building, usually with water in it

#### the times of distress

"a time of great trouble"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]

### Daniel 09:26

#### sixty-two sevens

This is not the normal way the Israelites counted. If possible, try to translate in a way that preserves this use of the number seven. See how you translated this number in [Daniel 9:25](./24.md). AT: "sixty-two times seven"

#### the anointed one will be destroyed and will have nothing

This can be stated in active form. AT: "people will destroy the anointed one and he will have nothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the anointed one

Anointing is a symbolic act to show that someone is chosen. See how you translated this title in [Daniel 9:25](./24.md). AT: "the person that God anoints" or "the person that God chooses"

#### a coming ruler

This is a foreign ruler, not "the anointed one." AT: "a foreign ruler who will come" or "a powerful ruler who will come"

#### Its end will come with a flood

The army will destroy the city and the holy place just as a flood destroys things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Desolations have been decreed

This can be stated in active form. AT: "God has decreed ruin for the city and sanctuary" or "God has declared that the enemy army will destroy everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Daniel 09:27

#### He will ... he will

This refers to the coming ruler who will destroy the anointed one.

#### one seven ... In the middle of the seven

Here "seven" is used to refer to a period of seven years. AT: "seven years ... Halfway through the seven years"

#### put an end to

"stop" or "halt"

#### the sacrifice and the offering

These words basically mean the same thing. The repetition is to show that the ruler will prevent all types of sacrifices. AT: "all forms of sacrificing" or "every type of offering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the wing of abominations

This may refer to the defensive structures on top of the walls of the temple, which are called "abominations" because they are full of idols. AT: "the walls of the temple that are full of abominations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### someone who makes desolate

"a person who completely destroys"

#### A full end and destruction are decreed to be poured out

This can be stated in active form. AT: "God has decreed that he will pour out a full end and destruction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### A full end and destruction

These two words or expressions are basically the same. They emphasize how serious and complete the destruction will be. AT: "Complete destruction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the one who has made the desolation

"the person who caused the destruction"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Daniel 09:intro

#### Daniel 09 General Notes ####

####### Special concepts in this chapter #######

######## Daniel told the future ########
Gabriel told Daniel a prophecy that Jerusalem would be rebuilt. Then later an anointed person would be killed and the worship at the temple stopped. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

######## The unusual expression of numbers in 9:24-26 ########

This passage uses the expressions "seventy sevens of years," "seven sevens and sixty-two sevens," and "sixty-two sevens of years" to denote ""490 years," "49 years and then 434 years," and "434 years," respectively. The original language uses the idea of a "week" to express the idea of a group of sevens, but these numbers are clearly meant to denote years, not weeks. Most translators should use the ways normal in their languages to express these numbers.

##### Links: #####

* __[Daniel 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Daniel 10

### Daniel 10:01

#### the third year of Cyrus king of Persia

"year 3 of the rule of Cyrus the king of Persia" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### a message was revealed to Daniel

This can also be expressed in active form. AT: "God revealed a message to Daniel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### insight

"understanding"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]

### Daniel 10:02

#### delicacies

These are expensive or rare kinds of food. AT: "fancy foods"

#### until the completion of three entire weeks

"until the end of three entire weeks"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]

### Daniel 10:04

#### On the twenty-fourth day of the first month

This is the first month of the Hebrew calendar. The twenty-fourth day is near the middle of April on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### with a belt around his waist

"and he was wearing a belt"

#### Uphaz

Uphaz is a place. Its location is not known (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### His body was like topaz

His body gleamed with blue or yellow light as if it were made of topaz. AT: "his body gleamed like topaz" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### topaz

a blue or yellow gemstone, also known as beryl, peridot, or chrysolite

#### his face was like lightning

His face shone brightly as a bolt of lightning shines. AT: "his face shone with light as bright as the flash of lightning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### His eyes were like flaming torches

His eyes were bright with light as if they were flaming torches. AT: "his eyes were so bright that it seemed they had torches burning inside them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### his arms and his feet were like polished bronze

His arms and feet were as shiny as if they were made of polished bronze. AT: "his arms and feet shone like polished bronze that reflects the light around it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### The sound of his words was like the sound of a great crowd

His voice was so loud that it was as if a crowd of people were all talking loudly. AT: "his voice was as loud as a huge crowd all calling out together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Daniel 10:07

#### So I was left alone and saw

This can be stated in active form. "No one was with me, and I saw" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my bright appearance was turned into a ruined look

This can be stated in active form. "my bright appearance turned into looking ruined" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my bright appearance

This describes the face of someone who is healthy. AT: "my healthy-looking face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a ruined look

Someone's unhealthy, pale face is spoken of as if it were a ruined building. AT: "pale" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I heard his words

This implies that someone was speaking in the vision. This can be made explicit. AT: "I heard the words of someone who was speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I fell on my face in deep sleep

Possible meanings are: 1) Daniel was so scared by what he saw that he deliberately laid on the ground, where he then fainted or 2) Daniel fainted and then fell forward onto the ground. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]

### Daniel 10:10

#### A hand touched me

Here a person's hand represents that person, probably the man whom Daniel saw in [Daniel 10:5-6](./04.md). AT: "Someone touched me with his hand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Daniel, man greatly treasured

This can also be stated in active form. AT: "Daniel, you whom God greatly treasures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### greatly treasured

much valued and loved

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Daniel 10:12

#### you set your mind to understand

"you determined to understand the vision"

#### your words were heard

This can be expressed in active form. AT: "God heard your words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### prince

Here this refers to a spirit who has authority over a human nation. AT: "spirit prince"

#### the kings of Persia

This probably refers to the various kings who ruled over nations in the Persian Empire, and who had to obey the king of Persia.

#### Michael, one of the chief princes

"Michael, on of the chief angels" or "Michael, one of the archangels"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Daniel 10:14

#### General Information:

The angel continues speaking to Daniel.

#### I turned my face toward the ground

"I looked at the ground." Daniel may have done this to show humble reverence, or because he was afraid.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]

### Daniel 10:16

#### One who was like the sons of man

This may refer to the one who had just spoken to Daniel. However, some versions interpret it as referring to a different person. AT: "This one, who looked like a human"

#### like the sons of man

Here this expression refers to human beings in general. AT: "like a human being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### agony

severe emotional suffering

#### I am your servant. How can I talk with my master?

Daniel asks this question meaning that he cannot speak to the angel because he is not the angel's equal. These sentences can be combined. AT: "I am not able to answer you because I am only your servant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### there is no breath left in me

This idiom refers to breathing. AT: "I cannot breathe" or "it's very hard to breathe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]

### Daniel 10:18

#### the one with an appearance of a man

"the one who looked like a human"

#### Be strong now, be strong

The words "be strong" are repeated for emphasis.

#### man greatly treasured

This can also be stated in active form. AT: "you whom God greatly treasures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I was strengthened

This can also be stated in active form. AT: "I became strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Daniel 10:20

#### the prince of Persia

Here "prince" refers to a spirit who rules and guards a human nation. See how you translated a similar phrase in [Daniel 10:13](./12.md). AT: "the spirit prince of Persia"

#### But I will tell you

This implies that the angel will tell Daniel about this immediately, before he goes away. AT: "But first I will tell you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### what is written in the Book of Truth

This can be stated in active form. AT: "what the Book of Truth says" or "what someone wrote in the Book of Truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who shows himself to be strong

"who proves himself to be strong"

#### There is no one who shows himself to be strong with me against them, except Michael your prince

"Michael your prince is the only one to show himself strong with me against them" or "Michael your prince is the only one who helps me against them"

#### Michael your prince

The word "your" is plural. It refers to Daniel and the rest of the people of Israel. AT: "Michael, the prince of your people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Michael your prince

"Michael your guardian angel." Translate "prince" when it refers to Michael as you did [Daniel 10:13](./12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md)]]

### Daniel 10:intro

#### Daniel 10 General Notes ####

####### Structure and formatting #######

This chapter begins a section where Daniel is given a prophecy about the future from an angel. This section continues for the remainder of the book. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Daniel 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Daniel 11

### Daniel 11:01

#### General Information:

In Daniel 11:1 through 12:4, the one who was speaking to Daniel in chapter 10 tells him what is written in the book of truth. This is as he said he would do in [Daniel 10:21](../10/20.md).

#### In the first year of Darius

Darius was the King of the Medes. "The first year" refers to the first year that he was king. AT: "In the first year of the reign of Darius" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Three kings will arise in Persia

"Three kings will rule over Persia"

#### a fourth will be far richer than all the others

"after them a fourth king will come into power who will have more money than the three before him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### power

Possible meanings are 1) authority or 2) military power.

#### he will stir up everyone

"he will cause everyone to want to fight"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greece.md)]]

### Daniel 11:03

#### General Information:

The angel continues speaking to Daniel.

#### A mighty king will rise up

The idea of rising up or standing is often used for someone who becomes powerful. AT: "A mighty king will begin to reign" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who will rule a very great kingdom

Possible meanings are 1) that the size of this kingdom would be very great, or 2) that the king would rule his kingdom with very great power.

#### his kingdom will be broken and divided

This can be stated in active form. AT: "his kingdom will break apart and divide" or "his kingdom will break apart into pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the four winds of heaven

See how you translated this in [Daniel 7:2](../07/01.md).

#### but not to his own descendants

The idea of not being divided and shared out is implied here. AT: "but it will not be divided for his own descendants" or "but it will not be shared by his own descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### his kingdom will be uprooted for others besides his descendants

The kingdom is spoken of as if it were a plant that someone destroyed by uprooting it. This idea can be expressed in active form. AT: "another power will uproot and destroy his kingdom and others who are not his descendants will rule over it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Daniel 11:05

#### General Information:

The angel continues speaking to Daniel.

#### one of his commanders will become even stronger than he and will rule his kingdom with great power

A commander of the king of the South will become the king of the North.

#### they will make an alliance

The king of the South will make an alliance with the king of the North. This alliance would be a formal agreement that both nations are required to follow. AT: "the king of the South and the king of the North will promise to work together"

#### The daughter of the king of the South will come ... to confirm the agreement

The king of the South will give his daughter in marriage to the king of the North. The marriage will confirm the agreement between the two kings.

#### her arm's strength ... his arm

Here "arm" stands for power. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She will be abandoned

This appears to refer to a plot to kill her and those who made the alliance. This phrase may be expressed in active form. AT: "They will abandon her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Daniel 11:07

#### General Information:

The angel continues speaking to Daniel.

#### a branch from her roots

This family is spoken of as if it were a tree. The roots represent ancestors, and the branch represents a descendant. AT: "a descendant of her ancestors" or "one of her descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### her roots

The word "her" refers to the daughter of the king of the South in [Daniel 11:6](./05.md).

#### He will attack the army

The word "he" refers to her descendant, and here it also refers to his army. AT: "He and his army will attack the army of the king of the North" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### He will fight them

Here "them" represents the soldiers of the enemy army. AT: "He will fight the enemy soldiers"

#### but he will withdraw

The word "he" refers to the king of the North.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Daniel 11:10

#### General Information:

The angel continues speaking to Daniel.

#### His sons

"The sons of the king of the North"

#### assemble a great army

"gather together many men who can fight in battles"

#### will flood everything

The way the large army covers the land will be like a flood of water. AT: "will be so great in number that they will cover all the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]

### Daniel 11:11

#### General Information:

The angel continues speaking to Daniel.

#### will raise up a great army

"will assemble a great army"

#### the army will be given into his hand

Here "hand" represents the control of the king of the South. AT: "the king will surrender the army to the king of the South" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The army will be carried off

This may be expressed in active form. AT: "The king of the South will capture the army of the North" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will be lifted up

Being lifted up represents the idea of becoming very proud. AT: "will become very proud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will make tens of thousands to fall

Here falling represents dying in battle. AT: "will have his army kill many thousands of his enemies" or "will kill many thousands of his enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### tens of thousands

"many thousands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Daniel 11:13

#### General Information:

The angel continues speaking to Daniel.

#### a great army supplied with much equipment

This can also be stated in active form. AT: "a great army that has much equipment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Daniel 11:14

#### General Information:

The angel continues speaking to Daniel.

#### many will rise against the king

Here the idea of rising up represents rebelling. AT: "many people will rebel against the king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Sons of the violent

This expression stands for violent people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will stumble

Here stumbling represents failing. AT: "they will not succeed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]

### Daniel 11:15

#### General Information:

The angel continues speaking to Daniel.

#### The king of the North will come

Here "king of the North" includes his army also. AT: "The army of the king of the North will come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### pour out earth for siege mounds

This refers to the piling up of earth in order for soldiers to reach the height of city walls in order to attack them. Soldiers and slaves would put loose earth in baskets, carry them to the right place, and pour it out in order to raise the mounds.

#### fortifications

walls and other things built to defend a city or fort from enemy soldiers

#### will not be able to stand

Here standing represents the ability to fight. AT: "will not be able to keep fighting against them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the one who comes will act according to his desires against him

"the invading king will do whatever he wants against the other king"

#### He will stand in

Here standing represents ruling. AT: "The king will begin to rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the land of beauty

This refers to the land of Israel. See how you translated this in [Daniel 08:09](../08/09.md).

#### destruction will be in his hand

Here "destruction" represents the power to destroy. Also, the power to destroy is spoken of as if it were something that someone could hold in his hand. AT: "he will have power to destroy anything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Daniel 11:17

#### General Information:

The angel continues speaking to Daniel.

#### set his face

This is an idiom for a person deciding to do something and not being willing to change his mind. AT: "decide" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### come with the strength of his entire kingdom

This probably refers to military power. AT: "come with the force of all his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a daughter of women

This is an elegant way of saying "a woman." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will end his arrogance

"will make the king of the North stop being arrogant"

#### will cause his arrogance to turn back upon him

"will cause the king of the North to suffer because he was arrogant toward others"

#### he will pay attention

"the king of the North will pay attention"

#### he will not be found

This is a way of saying that he will die. This idea can be stated in active form. AT: "he will disappear" or "he will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]

### Daniel 11:20

#### General Information:

The angel continues speaking to Daniel.

#### someone will rise up in his place

Rising up in a king's place represents becoming king in place of the previous king. AT: "another man will become king of the North instead of that king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will make a tax collector pass through

The tax collector will go through the land forcing people to pay taxes. AT: "will send someone to make the people pay taxes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he will be broken

Here "he" refers to the new king. Being broken represents dying. AT: "the new king will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but not in anger

Possible meanings are 1) no one was angry at the king, or 2) that the occasion and cause of the king's death were kept secret. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a despised person to whom the people will not have given the honor of royal power

The people will refuse to acknowledge him as king because he is not a descendant of kings. AT: "a person whom the people will despise and will not honor as king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### An army will be swept away like a flood from before him

Being swept away represents being destroyed. This can be stated in active form. AT: "His army will completely destroy a great army as a flood destroys everything in its path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Both that army and the leader of the covenant will be destroyed

This can be stated in active form. AT: "He will destroy that army and the leader of the covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the leader of the covenant

"the leader of the priests." This phrase refers to the person who filled the most important religious position that God required in his covenant, that of the high priest.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]

### Daniel 11:23

#### General Information:

The angel continues speaking to Daniel.

#### From the time an alliance is made with him

This can also be stated in active form. AT: "When other rulers make a peace treaty with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will spread among his followers

"will distribute to his followers"

#### the booty, the plunder, and the wealth

"the valuable things that he and his army take from the people they defeat"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]

### Daniel 11:25

#### General Information:

The angel continues speaking to Daniel.

#### He will wake up his power and his heart

Power and heart (that is, courage) are spoken of as if they were people whom someone could wake up in order to make them act. AT: "He will make himself powerful and will become courageous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### heart

Here this represents courage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### with a great army

"with a great army that he will assemble"

#### will wage war

"will fight against him"

#### he will not stand

Not standing represents being defeated. AT: "the king of the South will be defeated" or "his army will be defeated" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### those who eat his fine food

This refers to the king's advisers. It was usual for a king's most trusted advisers to eat meals with him. AT: "the king's best advisers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### His army will be swept away like a flood

Here the severe defeat of an army is spoken of as a flood of water that completely sweeps it away. AT: "The enemy will completely defeat his army" or "His enemy will completely destroy his army as a flood destroys everything in its path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### many of them will fall killed

Here "fall" is an idiom that refers to dying in battle, so "fall" and "killed" mean basically the same thing. AT: "many of his soldiers will die in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### with their hearts set on evil against each other

Here "heart" represents a person's desires. Desires are spoken of here as if they were an object that someone could set or place in a certain position. AT: "each determined to do evil to the other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will sit at the same table

Sitting at the same table represents the act of talking to each other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but it will be of no use

"but their talking will not help them"

#### For the end will come at the time that has been fixed

This tells why their meetings will not be successful. AT: "The result of their actions will only come at the time that God has fixed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Daniel 11:28

#### riches, with his heart set against the holy covenant

Here "heart" represents the mind or thoughts of a person. The idiom "his heart set against" means to be determined to oppose something. This can be stated as a new sentence. AT: "riches. He will be determined to oppose the holy covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### with his heart set against the holy covenant

The king's desire to act against the holy covenant represents his desire to stop the Israelites from obeying that covenant. AT: "determined to stop the Israelites from obeying the holy covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the holy covenant

Here "holy" describes God's covenant with Israel. It implies that the covenant should be honored and obeyed because it comes from God himself. AT: "God's covenant, which all the Israelites should obey"

#### He will act

This implies that the king will do certain actions in Israel. AT: "He will do what he wants to in Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]

### Daniel 11:29

#### ships of Kittim will come against him

The ships represent the army coming in those ships. AT: "an army will come from Kittim in ships in order to fight his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Kittim

This may refer to a settlement on the island of Cyprus in the Mediterranean Sea. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He will be furious against the holy covenant

"He will hate the holy covenant"

#### will show favor to those

"will act in favor for those" or "will help those"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]

### Daniel 11:31

#### His forces will rise up

"His army will appear" or "His army will come." The word "His" refers to the king of the North. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the fortress sanctuary

"the sanctuary that the people use as a fortress"

#### They will take away the regular burnt offering

Taking away the offering represents preventing people from offering it. AT: "They will stop the priests from presenting the regular burnt offering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the abomination that causes desolation

This refers to an idol that will make the temple desolate, that is, that will cause God to leave his temple. AT: "the disgusting idol that will cause God to abandon the temple" or "the disgusting thing that will make the temple unclean" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### acted wickedly against the covenant

"wickedly disobeyed the covenant"

#### corrupt them

"persuade them to do evil"

#### who know their God

Here "know" means "be faithful." AT: "who are faithful to their God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will be strong and will take action

"will be firm and resist them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Daniel 11:33

#### they will stumble by the sword and by flame

Here "stumble" is a metaphor that represents experiencing a disaster of one kind or another, including death itself. Here "sword" represents battles and warfare, and "flame" represents fire. AT: "they will die in battle and by burning to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they

This refers to the wise persons among the Israelites.

#### they will stumble into captivity and into being robbed for days

Here "stumble" is a metaphor that represents experiencing a disaster of one kind or another, including death itself. The phrase "being robbed" can be stated in active form. AT: "they will become slaves and their enemies will rob them of their possessions for days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they will be helped with a little help

This may be put into active form. AT: "others will give them a little help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### In hypocrisy many will join themselves with them

This refers to other people who will pretend to help the wise persons, but not because they truly wish to help them.

#### will join themselves

Here "join themselves" represents "come to help." AT: "will come to help them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Some of the wise will stumble ... until the time of the end

This suffering will continue until the time when God has decided that it will end.

#### Some of the wise will stumble

Here "stumble" represents experiencing a disaster of one kind or another, including death itself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so that refining will happen to them

Here "so that" means "with the result that." AT: "with the result that refining will happen to them"

#### refining will happen to them, and cleansing, and purifying

These three activities are expressed here as if they were things. However, they may be expressed as actions, either in passive form or in active form. AT: "they will be refined, cleansed, and purified" or "their suffering will refine, cleanse, and purify them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### refining

This refers to the purifying of metal by melting it in a fire. When God makes his people more faithful to himself, this is spoken of as if they were metal that a worker was making more pure by putting it into fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### cleansing

This refers to making people, places, or objects suitable for God's use by separating them from sin and other forms of evil. It speaks of evil as if it were physical dirtiness that could be removed by washing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### purifying

This idea is very similar to refining, discussed earlier. Metal that is refined can also be said to be purified. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### time of the end

"the final days" or "the end of the world." See how you translated this in [Daniel 8:17](../08/15.md).

#### the appointed time is still to come

Here "appointed time" implies that God has set the time. This can be put into active form. AT: "Yahweh has set the time in the future"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]

### Daniel 11:36

#### The king will act according to his desires

"The king will do whatever he wants"

#### The king

This refers to the king of the North.

#### lift himself up and make himself great

The phrases "lift himself up" and "make himself great" mean the same thing and indicate that the king will become very proud. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### lift himself up

Here this represents becoming very proud. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### make himself great

Here this represents pretending to be very important and powerful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the God of gods

This refers to the one true God. AT: "the supreme God" or "the only true God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### astonishing things

"terrible things" or "shocking things"

#### until the wrath is completed

This phrase pictures God as storing up his wrath until his storeroom is completely full of it and he is ready to act according to it. AT: "until God is completely angry with him" or "until God is angry enough to take action against him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the god desirable to women

This seems to refer to the pagan god named Tammuz.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]

### Daniel 11:38

#### the god of fortresses

The king probably believed that this false god would help him to attack other people's fortresses and keep his own. AT: "the god that controls fortresses"

#### instead of these

The word "these" refers to the gods mentioned in [Daniel 11:37](./36.md).

#### he will divide up the land as a reward

Possible meanings are 1) "he will give the land to his followers as a reward" or 2) "he will sell land to his followers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Daniel 11:40

#### the time of the end

"the final days" or "the end of the world." See how you translated this in [Daniel 8:17](../08/15.md).

#### the king of the South ... The king of the North

These phrases stand for the kings and their armies. AT: "the king of the South and his army ... The king of the North and his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### will storm against him

Violently attacking with an army is spoken of as if a storm happened. AT: "will attack him like a violent storm" or "will violently attack him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### flood them

When an army overruns a country, it is spoken of as if a flood occurred. See how you translated this in [Daniel 11:10](./10.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### pass through

Nothing will stop the army. AT: "will pass through the lands with no one to stop him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the land of beauty

This refers to the land of Israel. See how you translated this in [Daniel 08:09](../08/09.md) and [Daniel 11:16](./15.md).

#### will fall

Here falling represents the action of dying. AT: "will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But these will escape from his hand

Here "hand" represents power. AT: "But these will escape from his power" or "But he will not be able to destroy these nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sweep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sweep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]

### Daniel 11:42

#### General Information:

This is still about the king of the North.

#### He will extend his hand into lands

Here "hand" represents power and control. AT: "He will extend his control over various lands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### into lands

Here the idea is many lands or various lands. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the land of Egypt will not be rescued

This can be put into active form. AT: "the land of Egypt will not escape" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Libyans and the Cushites will be in his footsteps

Here "footsteps" represent submission. AT: "the Libyans and the Cushites will have to serve him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the Libyans and the Cushites

"the people of Libya and Cush." Libya is a country west of Egypt, and Cush is a country south of Egypt. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md)]]

### Daniel 11:44

#### General Information:

This is still about the king of the North.

#### he will go out with great rage

The abstract noun "rage" can be expressed with the word "angry." It can be stated clearly that he would go out with his army. AT: "he will be very angry and will go out" or "he will become very angry and will go out with his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### go out

To "go out" represents the action of attacking the enemy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to set many apart for destruction

"to destroy many people"

#### the tent of his royal residence

This refers to the king's luxurious tents that he lived in when he was with his army in time of war.

#### between the seas and the mountain of the beauty of holiness

This probably refers to the region between the Mediterranean Sea and Temple Mount in Jerusalem.

#### the mountain of the beauty of holiness

This refers to the hill in Jerusalem where God's temple was. See how you translated somewhat similar phrases in [Daniel 9:16](../09/15.md) and [Daniel 9:20](../09/20.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/alarm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/alarm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Daniel 11:intro

#### Daniel 11 General Notes ####

####### Structure and formatting #######

The final prophecy continues in this chapter. The kings of the North and of the South will fight many wars against each other. The king of the South is probably a reference to Egypt. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Daniel 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Daniel 12

### Daniel 12:01

#### General Information:

The angel who appeared to Daniel in [Daniel 10:5](../10/04.md) continues speaking.

#### Michael, the great prince

Michael is an archangel. Here he is also given the title "great prince."

#### Michael ... will rise up

Here "rise up" is an idiom that means to appear. AT: "Michael ... will appear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### your people will be saved

This can be stated in active form. You can also make it clear that God will save the people. AT: "God will save your people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### whose name is found written in the book

This can be stated in active form. You can also make it clear that God writes names in the book. AT: "whose name God has written in the book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### those who sleep in the dust of the earth will rise up

The phrase "sleep in the dust of the earth" is another way of referring to those who have died. Here "rise up" is an idiom that means to come back to life. AT: "those who have died will come back to life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md)]]

### Daniel 12:03

#### Those who are wise will shine like the brightness of the sky above

This refers to God's people who will share their wisdom with those around them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### those who turn many to righteousness

This refers to those who help others understand that they are separated from God, as if they were changing the direction in which they were going. AT: "those who teach others to live righteously" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### those who turn ... are like the stars forever and ever

These people are compared to the stars that shine. AT: "those who turn ... will shine brightly like the stars forever and ever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### close up these words; keep the book sealed

Here "words" represents the book. AT: "close this book and keep it sealed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### time of the end

"the final days" or "the end of the world." See how you translated this in [Daniel 8:17](../08/15.md).

#### Many will run here and there, and knowledge will increase

This seems to happen before "the time of the end" during which time the book is sealed. This can be made explicit. AT: "Before that happens, many people will travel here and there, learning more and more about many things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Daniel 12:05

#### General Information:

Daniel goes on to tell what he saw next in this vision that began in [Daniel 10:1](../10/01.md).

#### there were two others standing

"there were two other angels standing"

#### the man clothed in linen

This refers to the angel who appeared to Daniel in [Daniel 10:5](../10/04.md), not to one of the angels who is standing beside the river. This can be stated in active form. AT: "the man who was wearing linen clothes" or "the angel who was wearing linen clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### upstream along the river

Possible meanings are 1) the angel clothed in linen was above the river or 2) the angel was further upstream along the river.

#### How long will it be to the end of these amazing events?

"How long will these amazing events last?" This refers to the time from the beginning to the end of the events.

#### these amazing events

At the time when the angel spoke to Daniel, none of the events in this vision had happened. This definitely refers to the events in [Daniel 12:1-4](./01.md), and may possibly also include the events in the vision from chapter 11.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Daniel 12:07

#### the man clothed in linen

This can be stated in active form. AT: "the man who was wearing linen clothes" or "the angel who was wearing linen clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### upstream along the river

Possible meanings are 1) the man clothed in linen was above the river or 2) the man was further upstream along the river.

#### the one who lives forever

"God, who lives forever"

#### it would be for a time, times, and half a time

It is best to leave it ambiguous as to when this begins. If you must choose a starting point, the three and a half years probably start with the events of [Daniel 12:1-4](./01.md).

#### a time, times, and half a time

"three and a half years." These "times" are generally understood to refer to years. One and two and a half equal three and a half.

#### all these things will be completed

This can be stated in active form. AT: "all these things will have happened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### all these things

At the time when the man clothed in linen spoke to Daniel, none of the events in this vision had happened. This refers to the events in [Daniel 12:1-4](./01.md), and may include the events in the vision from chapter 11.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Daniel 12:08

#### My master

Daniel refers to the angel clothed in linen as "My master" to show respect to the angel.

#### of all these things

At the time when the angel clothed in linen spoke to Daniel, none of the events in this vision had happened. This definitely refers to the events in [Daniel 12:1-4](./01.md), and may possibly also include the events in the vision from chapter 11.

#### for the words are shut up and sealed

The vision that was given to Daniel was not to be explained. The book was sealed and no one could access it. AT: "for you are to close up and seal the words you have written" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the time of the end

"the final days" or "the end of the world." See how you translated this in [Daniel 8:17](../08/15.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/daniel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]

### Daniel 12:10

#### General Information:

The angel clothed in linen continues speaking to Daniel.

#### Many will be purified, cleansed, and refined

Yahweh does the purifying. These three terms mean basically the same thing. AT: "Yahweh will purify, cleanse, and refine many people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### refined

purified by removing anything that does not belong in them

#### but the wicked will act wickedly

The evil people will do evil or sinful things.

#### None of the wicked will understand

The evil people can not understand spiritual knowledge.

#### but those who are wise will understand

"but those who obey Yahweh are wise and will understand"

#### the regular burnt offering is ... is set up

The king of the north is the one who stops the temple sacrifices. AT: "the king of the North takes away the regular burnt offering and sets up the abomination that causes complete desolation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the abomination that causes complete desolation

This refers to an idol that will make the temple desolate, that is, that will cause God to leave his temple. See how you translated this in [Daniel 11:31](../11/31.md). AT: "the disgusting idol that will cause God to abandon the temple" or "the disgusting thing that will make the temple unclean" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### 1,290 days

"one thousand two and hundred ninety days" or "twelve hundred and ninety days." Here "days" refers to a period of time. Most commonly rendered as days, but can also imply years. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]

### Daniel 12:12

#### General Information:

The angel clothed in linen continues speaking to Daniel.

#### Blessed is the one who waits

"Blessed is the person who waits" or "Blessed is anyone who waits"

#### waits

"endures" or "remains faithful"

#### the 1,335 days

"one thousand three hundred and thirty-five days" or "thirteen hundred and thirty-five days." Here "days" is referring to a period of time most commonly rendered as days. However, it can also imply years. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### You must go

"Daniel, you must go" This refers to Daniel continuing to live and serve the kings until the appointed time of his death.

#### you will rest

This is a gentle way of saying "you will die." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### You will rise

This is referring to the first resurrection of the dead when the righteous people will be raised up.

#### the place assigned to you

"the place God has assigned to you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]

### Daniel 12:intro

#### Daniel 12 General Notes ####

####### Structure and formatting #######

The final prophecy concludes in this chapter. It tells about the future resurrection of the dead and the final judgment. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judgmentday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judgmentday.md)]])

##### Links: #####

* __[Daniel 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | __


## Daniel front

### Daniel front:intro

#### Introduction to Daniel ####

##### Part 1: General Introduction #####

####### Outline of Daniel #######

1. The time and place of the Book of Daniel; the first trials and tests of the exiles (1:1–21)
1. The dream of Nebuchadnezzar and its interpretation (2:1–49)
1. The golden image, the fiery furnace, and deliverance (3:1–30)
1. Deciphering Nebuchadnezzar's dream; his fall from power (4:1–37)
1. Belshazzar's feast and the writing on the wall; Daniel in the lions' den (5:1–6:28)
1. The vision of the four beasts (7:1–28)
1. The vision of the ram and the goat (8:1–27)
1. Daniel's prayer and Gabriel's answer (9:1–23)
1. The vision of the seventy weeks (9:24–27)
1. Daniel's vision of a man (10:1–11:1)
1. The kings of the South and the North (11:2–20)
1. A contemptible person rises up, until the desolation is completed (11:21–12:4)
1. The time of the end (12:5–13)

####### What is the Book of Daniel about? #######

The Book of Daniel is about several Jewish young men, Daniel and his friends, who were taken to Babylon as prisoners from Jerusalem. The first section of the book (Chapters 1–6) is a narrative about Daniel and his friends. This section shows how they were faithful to Yahweh even though they were living in a pagan land and serving a pagan king. And it shows how God rewarded them because they were faithful. 

Following this is a section of prophetic visions (Chapters 7–12). Chapters 7 and 8 deal with images representing the kingdoms and kings of the major nations. Chapters 9–11 are prophecies and visions about wars and the appearance of a type of the great enemy of God. Chapter 12 is a final vision that describes the end times.

####### How should the title of this book be translated? #######

"The Book of Daniel" may also be called "The Book About Daniel" or "The Book About the Deeds and Visions of Daniel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Daniel? #######

Daniel was a Jew who became an official in the Babylonian government during the exile. He may have written the book himself. Or he may have written the parts of the book and someone put them together at a later time in the form that we have now.

##### Part 2: Important Religious and Cultural Concepts #####

####### Why is there a missing week in Daniel's prophecy? #######

There is much speculation regarding Daniel's "missing week" in 9:24-27. It is best for translators to allow this mystery to remain in the text. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

####### When do the seventy weeks begin? #######

An exact date for the beginning of the prophecy of the seventy weeks is unknown. The timeline begins when a decree is issued to rebuild the city of Jerusalem, but there were several decrees that allowed this to happen.

####### Who was Darius the Mede? #######

Darius the Mede was a king of Babylon who sent Daniel into the lion's den. Unfortunately, his name is not known in history outside of The Book of Daniel. Many explanations about who Darius was have been suggested, but they are not certain.

##### Part 3: Important Translation Issues #####

####### How does Daniel use the word "king"? #######

There are many kings in the Book of Daniel, but not all of the kings were rulers over all of Babylon or Persia. Some of the kings may have been kings of regions or cities.

####### How many chapters does Daniel have? #######

Daniel has twelve chapters. Some Bible versions include the stories called "Bel and the Dragon" and "The Prayer of Azariah." However, not many people think that these stories are equal in authority with the rest of scripture. Therefore, there is no need to translate them.



---

