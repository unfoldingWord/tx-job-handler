# <a id="amo"/>Amos

## Amos 01

### Amos 01:01

#### General Information:

God speaks through Amos using poetic language. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### These are the things concerning Israel that Amos, one of the shepherds in Tekoa, received in revelation

This can be stated in active form. AT: "These are the things concerning Israel that God revealed to Amos, one of the shepherds in Tekoa" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### These are the things

"This is the message"

#### in Tekoa

"Tekoa" is the name of a town or village. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He received these things

This can be stated in active form. AT: "God gave him these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the days of Uzziah king of Judah, and also in the days of Jeroboam son of Joash king of Israel

The words "in the days of" is an idiom and refers to the time when each king reigned. AT: "when Uzziah was king of Judah, and also when Jeroboam son of Joash was king of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### two years before the earthquake

The assumed knowledge is that the original hearers would be aware of when a large earthquake had affected the area. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Yahweh will roar from Zion; he will raise his voice from Jerusalem

These two phrases share similar meanings. Together they emphasize that Yahweh shouts loudly as he prepares to judge the nation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Yahweh will roar

The author speaks of the voice of Yahweh as if it sounded like the roar of a lion or the roar of thunder. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amos.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amos.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uzziah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uzziah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeroboam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeroboam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md)]]

### Amos 01:03

#### For three sins of ... even for four

This is a poetic device. It does not mean that a specific number of sins had been committed, but it indicates that many sins had led to God's judgment.

#### Damascus

Here "Damascus" represents the people of the city of Damascus. AT: "the people of Damascus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he would punish them. AT: "I will certainly punish those people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### they threshed Gilead with instruments of iron

Yahweh speaks of how Damascus treated Gilead as if they had threshed grain with iron tools or weapons. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Gilead

Here "Gilead" represents the people of the region of Gilead. AT: "the people of Gilead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will send a fire into the house of Hazael

Here Yahweh speaks of his judgment against the house of Hazael as if it were a consuming fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the house of Hazael

The word "house" is a metonym for the family that lives in the house. In this case it refers to Hazael's descendants, who were rulers of the country where Damascus was located. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### it will devour the fortresses of Ben Hadad

Here Yahweh's judgment is spoken of as if it were a fire that was consuming the fortresses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Hazael ... Ben Hadad

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]

### Amos 01:05

#### Connecting Statement:

Yahweh continues his message of judgment on Damascus.

#### cut off the man

Here to "cut off" means either to destroy or to drive away, as one would cut a piece of cloth or cut a branch from a tree. AT: "destroy the man" or "drive away the man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Valley of Aven

This is the name of a place that means "valley of wickedness." Possible meanings are 1) this is the name of an actual place in that region or 2) this is a metonym for Damascus or the surrounding region. AT: "the valley of wickedness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the man who holds the scepter in

This is a metonym for the ruler of that city or region. AT: "the ruler of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Beth Eden

This is the name of a place that means "house of pleasure." Possible meanings are 1) this is the name of an actual place in that region or 2) this is another metonym for Damascus or the surrounding region. AT: "the house of pleasure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Kir

This is the name of a region from which the people of Aram originally came. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Amos 01:06

#### For three sins of ... even for four

This is a poetic device. It does not mean that a specific number of sins had been committed, but it indicates that many sins had led to God's judgment. See how you translated these words in [Amos 1:3](./03.md).

#### Gaza

Here "Gaza" represents the people of the region of Gaza. AT: "the people of Gaza" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he would punish them. See how you translated these words in [Amos 1:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### hand them over to

"deliver them up to" or "sell them to"

#### Edom

Here "Edom" represents the people of the country of Edom. AT: "the people of Edom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### it will devour her fortresses

Here Yahweh's judgment is spoken of as if it were a fire that was consuming the fortresses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]

### Amos 01:08

#### Connecting Statement:

Yahweh continues his message of judgment on Gaza.

#### cut off the man

Here to "cut off" means either to destroy or to drive away, as one would cut a piece of cloth or cut a branch from a tree. AT: "destroy the man" or "drive away the man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the man who holds the scepter

This is a metonym for the ruler of that city or region. AT: "the ruler" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will turn my hand against Ekron

Here "hand" represents Yahweh's power that he would use against Ekron. AT: "I will strike Ekron" or "I will destroy Ekron" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Ekron

Here "Ekron" represents the people of the city of Ekron. AT: "the people of Ekron" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]

### Amos 01:09

#### For three sins of ... even for four

This is a poetic device. It does not mean that a specific number of sins had been committed, but indicates that many sins had led to God's judgment. See how you translated these words in [Amos 1:3](./03.md).

#### Tyre

Here "Tyre" represents the people of the city of Tyre. AT: "the people of Tyre" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he would punish them. See how you translated these words in [Amos 1:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### their covenant of brotherhood

"the agreement they made to treat you as brothers"

#### it will devour her fortresses

Here Yahweh's judgment is spoken of as if it were a fire that was consuming the fortresses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]

### Amos 01:11

#### For three sins of ... even for four

This is a poetic device. It does not mean that a specific number of sins had been committed, but indicates that many sins had led to God's judgment. See how you translated these words in [Amos 1:3](./03.md).

#### Edom

Here "Edom" represents the people of the country of Edom. AT: "the people of Edom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he would punish them. See how you translated these words in [Amos 1:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### he pursued his brother

The assumed knowledge is that Esau, from whom the people of Edom were descended, was the brother of Jacob, from whom the people of Israel were descended. Here "his brother" represents the people of Israel. AT: "he pursued the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### cast off all pity

"showed them no mercy"

#### His anger raged continually, and his wrath lasted forever

These two phrases mean the same thing and are repeated to emphasize his continued anger. The abstract nouns "anger" and "wrath" can be translated using the adjectives "angry" and "furious." AT: "He was continually angry and always furious" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### his wrath lasted forever

This is an exaggeration that is meant to express the ongoing nature of his wrath. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Teman ... Bozrah

These are names of places. See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]]

#### it will devour the palaces of Bozrah

Here Yahweh's judgment is spoken of as if it were a fire that was consuming the palaces. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]

### Amos 01:13

#### For three sins of ... even for four

This is a poetic device. It does not mean that a specific number of sins had been committed, but indicates that many sins had led to God's judgment. See how you translated these words in [Amos 1:3](./03.md).

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he would punish them. See how you translated these words in [Amos 1:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### enlarge their borders

"extend their boundaries" or "expand their territory"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Amos 01:14

#### Connecting Statement:

Yahweh continues his message of judgment on the people of Ammon.

#### it will devour the palaces

Here Yahweh's judgment is spoken of as if it were a fire that was consuming the palaces. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### with a tempest in the day of the whirlwind

The fighting against the people of Ammon is spoken of as if it were a violent storm. AT: "and the fighting will be like a great storm" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### tempest ... whirlwind

These are two kinds of violent storms.

#### whirlwind

a strong wind that spins very quickly as it moves and can cause damage

#### Their king will go into captivity

The abstract noun "captivity" can be translated as the verb "capture." This can be translated in active form. AT: "Their enemies will capture their king and take him away as a prisoner" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rabbah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rabbah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]

### Amos 01:intro

#### Amos 01 General Notes ####

####### Structure and formatting #######

This book is written in a poetic form. Because it was written by a farmer, it includes many references to agricultural concepts. 

######## "For three sins of Judah, even for four" ########
The phrase "For three sins of Judah, even for four," is used to begin each oracle. This is not intended to be a literal count but is an idiom indicating a large number of sins. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]) 

##### Links: #####

* __[Amos 01:01 Notes](./01.md)__
* __[Amos intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Amos 02

### Amos 02:01

#### For three sins of ... even for four

This is a poetic device. It does not mean that a specific number of sins had been committed, but indicates that many sins had led to God's judgment. See how you translated these words in [Amos 1:3](../01/03.md).

#### Moab

This represents the Moabite people. AT: "the people of Moab" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he would punish them. See how you translated these words in [Amos 1:3](../01/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### he burned the bones

The word "he" refers to Moab. AT: "the people of Moab burned the bones"

#### to lime

"to ashes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]

### Amos 02:02

#### Connecting Statement:

Yahweh continues his message of judgment on the people of Moab.

#### Kerioth

This is the name of a city or town. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Moab will die

Here "Moab" represents the people of Moab. AT: "The people of Moab will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in an uproar

An uproar is a very loud noise.

#### the judge in her

"the ruler of Moab"

#### all the princes

"all the officials" or "all the leaders"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Amos 02:04

#### For three sins of ... even for four

This is a poetic device. It does not mean that a specific number of sins had been committed, but indicates that many sins had led to God's judgment. See how you translated these words in [Amos 1:3](../01/03.md).

#### Judah

This represents the people of Judah. AT: "the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he will punish them. See how you translated these words in [Amos 1:3](../01/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Their lies

This expression here probably refers to worshiping false gods or idols. AT: "Their worship of idols" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### go astray ... walked

Worshiping false gods is spoken of as if people were walking behind them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it will devour the fortresses of Jerusalem

Here Yahweh's judgment is spoken of as if it were a fire that was consuming the fortresses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Amos 02:06

#### For three sins of ... even for four

This is a poetic device. It does not meaan that a specific number of sins had been committed, but indicates that many of sins had led to God's judgment. See how you translated these words in [Amos 1:3](../01/03.md).

#### Israel

This represents the Israelite people. AT: "the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will not turn away punishment

Yahweh uses two negatives here to emphasize that he would punish them. See how you translated these words in [Amos 1:3](../01/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### the innocent

This refers to innocent people in general. AT: "innocent people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the needy

This refers to needy people in general. AT: "needy people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Amos 02:07

#### Connecting Statement:

Yahweh continues his message of judgment on the people of Israel.

#### General Information:

The word "they" in these verses refers to the people of Israel.

#### They trample on the heads of the poor as people trample on dust on the ground

How the people of Israel treated the poor is compared to how people step heavily on the ground (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### trample

repeatedly step heavily or roughly

#### the poor

This refers to poor people in general. AT: "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### they push the oppressed away

This idiom means they refused to listen when the oppressed people said they were being treated unfairly (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the oppressed

This refers to oppressed people in general. AT: "oppressed people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### those who were fined

This can be stated in active form. AT: "those who they made to pay a penalty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Amos 02:09

#### Connecting Statement:

Yahweh continues his message of judgment on the people of Israel.

#### General Information:

The words "them" and "you" in these verses both refer to the people of Israel.

#### whose height was like the height of cedars; he was strong as the oaks

This is an exaggeration. It describes how tall and strong the Amorite people were and compares them to the tallest and strongest trees in that region. AT: "who were tall and strong like great trees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### cedars

"cedar trees"

#### the oaks

"the oak trees"

#### Yet I destroyed his fruit above and his roots below

How Yahweh completely destroyed the Amorites is pictured as a tree being destroyed from top to bottom. AT: "Yet I destroyed them completely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Amos 02:11

#### Connecting Statement:

Yahweh continues his message of judgment on the people of Israel.

#### General Information:

The words "your" and "you" in these verses refer to the people of Israel.

#### raised up

"appointed"

#### Is it not so, people of Israel?

Yahweh asks this question to emphasize what he has said. This can be stated in active form. AT: "You people of Israel certainly know that what I have said is true!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Amos 02:13

#### Connecting Statement:

Yahweh continues his message of judgment on the people of Israel.

#### General Information:

The word "you" in these verses refers to the people of Israel.

#### Look

This alerts the reader to pay attention to what follows. AT: "Listen" or "Pay attention to what I am about to tell you"

#### I will crush you as a cart that is full of grain can crush someone

Yahweh compares his judgment on the people of Israel to crushing them with something very heavy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### The swift ... the strong ... the mighty

These adjectives refer to people in general. AT: "Swift people ... strong people ... mighty people" or "The strong person ... the strong person ... the mighty person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Amos 02:15

#### Connecting Statement:

Yahweh continues his message of judgment on the people of Israel.

#### The archer will not stand

Here "stand" means to keep one's place in battle.

#### the fast runner will not escape

The implied information is that the fast runner will not escape from his enemies. AT: "the fast runner will be captured" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### flee naked

Possible meanings are 1) this is a metonym for "run away without his weapons" or 2) this is meant literally as "run away wearing no clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in that day

"at that time"

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 2:11](./11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/archer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/archer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]

### Amos 02:intro

#### Amos 02 General Notes ####

####### Structure and formatting #######

This chapter consists of oracles against Moab and Judah by using poetic language and imagery. But the UDB translates it using prose. If possible, translate this chapter as poetry, but you may translate as narrative. 

####### Important figures of speech in this chapter #######

######## Idiom ########
You will notice that the phrase "For three sins of Judah, even for four," is used to begin each of these oracles. This is not intended to be a literal count but is an idiom indicating a large number of sins. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]) 

##### Links: #####

* __[Amos 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Amos 03

### Amos 03:01

#### Hear this word

"Hear this message" or "Listen to this message"

#### that Yahweh has spoken against you ... against the whole family

"this word that Yahweh has spoken about you ... about the whole family" or "Yahweh's message about you ... about the whole family"

#### you, people of Israel ... the whole family that I brought up out of the land of Egypt

These two phrases refer to the same group of people. The people God is speaking to are the descendants of those he had taken out of Egypt.

#### the whole family

Here "the whole family" represents to the whole nation. The people of Israel were all descendants of Jacob. AT: "the whole nation" or "the whole clan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I have chosen only you from all the families of the earth

This implies that they should have obeyed him. This can be stated clearly. AT: "I have chosen only you from all the families of the earth, so you should have obeyed me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all the families of the earth

Here "families" represents nations or people groups. AT: "all the nations of the earth" or "all the clans on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Therefore I will punish you for all your sins

It can be stated clearly that they did not obey God. AT: "But you did not obey me. Therefore I will punish you for all your sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Amos 03:03

#### General Information:

Amos uses the questions in verses 3-6 to present examples of things that people already know about what causes things to happen and what are the results of things that happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will two walk together unless they have agreed?

Amos uses this question to remind people of what they already know about what must happen in order for two people to walk together. It can be translated as a statement. AT: "Two people will walk together only if they have first agreed to walk together." or "You know that two people will walk together only if they have agreed to do that." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will a lion roar in the forest when he has no victim?

Amos uses this question to remind people of what they already know about what causes a lion to roar. The question can be translated as a statement. AT: "A lion will roar in the forest only when he has a victim." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will a young lion growl from his den if he has caught nothing?

Amos uses this question to remind people of what they already know about what causes a lion to growl. It can be translated as a statement. AT: "A young lion will growl from his den only if he has caught something." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]

### Amos 03:05

#### General Information:

Amos uses the questions in verses 3-6 to present examples of things that people already know about what causes things to happen and what are the results of things that happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Can a bird fall in a trap on the ground when no bait is set for him?

Amos uses this question to remind people of what they already know about what causes a bird to fall into a trap. This can be translated as a statement. AT: "A bird can fall into a trap on the ground only when bait has been set for him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will a trap spring up from the ground when it has not caught anything?

Amos uses this question to remind people of what they already know about what causes a trap to spring up. This question can be translated as a statement. AT: "A trap will spring up from the ground only when it has caught something." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will a trap spring up from the ground

This refers to a trap closing. When an animal steps on a trap, the trap closes and the animal cannot get out of it. AT: "Will a trap close"

#### If a trumpet sounds in a city, will the people not tremble?

Amos uses this question to remind people of what they already know about what happens when a trumpet sounds. This question can be translated as a statement. AT: "When the trumpet sounds in the city, the people will tremble." or "When the trumpet sounds in the city, we expect that people will tremble." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### If a trumpet sounds in a city

The purpose of sounding the trumpet is to warn people that enemies are about to attack the city. AT: "If someone blows the trumpet in the city to warn the people about an enemy attack" or "If the warning trumpet is blown in the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### tremble

The reason for trembling can be stated clearly. AT: "tremble because they are afraid" or "be afraid of the enemy and tremble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If disaster overtakes a city, has Yahweh not sent it?

Amos uses this question to remind the people of what they should already know about what causes a disaster. This question can be translated as a statement. AT: "If disaster overtakes a city, Yahweh has sent it." or "If disaster overtakes a city, we know that Yahweh has sent it." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### If disaster overtakes a city,

Something terrible happening to a city is spoken of as if disaster overtakes it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Amos 03:07

#### Surely the Lord Yahweh will do nothing unless ... the prophets

The relationship between this sentence and the rhetorical questions in [Amos 3:3](./03.md) to [Amos 3:6](./05.md) can be shown with the words "So also." AT: "So also, the Lord Yahweh will do nothing unless ... the prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Surely the Lord Yahweh will do nothing unless he reveals ... prophets

This can be stated positively. AT: "Surely the Lord Yahweh will reveal ... prophets before he does anything" or "So also, the Lord will punish people only if he has revealed his plan to his servants the prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### The lion has roared; who will not fear?

Amos uses this question to remind people of what people do when a lion roars. This can be translated as a statement. AT: "The lion has roared; so we know that everyone will be afraid." or "The lion has roared; so of course everyone will be afraid." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The Lord Yahweh has spoken; who will not prophesy?

Amos uses this question to emphasize what people should already know about what prophets do when God speaks. This question can be translated as a statement. AT: "The Lord Yahweh has spoken; so we know that the prophets will prophesy." or "The Lord Yahweh has spoken; so of course the prophets will prophesy." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### Amos 03:09

#### Assemble yourselves

This command is to Israel's enemies in Ashdod and Egypt.

#### this is Yahweh's declaration

"this is what Yahweh has declared" or "this is what Yahweh has solemnly said." This phrase expresses the certainty of everything else in the message.

#### see what great confusion is in her

The word "her" refers to the city of Samaria. Cities were often spoken of as if they were women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### what great confusion is in her

Here "great confusion is in her" refers to people's fear because of the fighting and rioting there. The word "confusion" can be translated with a verbal phrase to make this meaning explicit. AT: "how the people in Samaria riot" or "how the people in Samaria fight against one another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### what oppression is in her

Here "oppression is in her" refers to leaders in Samaria oppressing the people. The abstract noun "oppress" can be stated as "oppress" or "cause to suffer." AT: "how the leaders oppress people" or "and how they cause people to suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### For they do not know how to do right

The word "they" refers to the people of Samaria.

#### They store up violence and destruction

Here "violence and destruction" represent things they have taken by being violent and destructive. AT: "They store up things that they have violently stolen from others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]

### Amos 03:11

#### Therefore, this is what the Lord Yahweh says

It can be stated clearly who God was saying this to. AT: "Therefore, this is what the Lord Yahweh says to the people of Israel living in Samaria" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### An enemy will surround the land

"An enemy army will surround the land"

#### plunder your fortresses

"steal all the things in your fortresses"

#### As the shepherd rescues ... so will the people of Israel ... be rescued

The Lord compares the people of Israel being rescued with an unsuccessful attempt to rescue an animal from a lion. They will not be completely rescued. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### As the shepherd rescues out of the mouth of the lion two legs only, or a piece of an ear

It can be stated clearly that the shepherd tries to rescue the whole animal. AT: "As the shepherd tries to rescue an animal from the lion's mouth, but is able to save only two legs or a piece of an ear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### As the shepherd ... the lion

Here the phrases "the shepherd" and "the lion" refer to any shepherd or lion. AT: "As a shepherd ... a lion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### they will be left with only the corner of a couch or a piece of a bed

This phrase shows that they will not be completely rescued. Almost all of their possessions will be stolen. This passage in Hebrew is difficult to understand, and some modern versions interpret it differently.

#### couch

This is a soft chair big enough to lie down on.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]

### Amos 03:13

#### the house of Jacob

The word "house" is a metonym for the family that lives in the house. In this case it refers to Jacob's descendants. They were the people of Israel. AT: "the descendants of Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### this is the declaration of the Lord Yahweh, the God of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated the similar phrase "this is Yahweh's declaration" in [Amos 2:11](../02/11.md). AT: "this is what the Lord Yahweh, the God of hosts, has declared" or "this is what I, the Lord Yahweh, the God of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### in the day that I punish the sins of Israel

"when I punish the sins of Israel"

#### I will also punish the altars of Bethel

People sinned against God by worshiping false gods at their altars. Here "punish the altars" represents punishing the people by destroying their altars. AT: "I will also destroy the altars at Bethel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The horns of the altar will be cut off and fall to the ground

This can be stated in active form. AT: "Your enemies will cut off the horns of the altars, and the horns will fall to the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### horns of the altar

People worshiped false gods at their altars. At the top corners of the altars there were pieces of metal shaped like bull horns. These horns were a symbol of the strength of their gods.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Amos 03:15

#### the winter house with the summer house

Some of the wealthy people had two houses: one that they lived in during the winter and one that they lived in during the summer. This refers to any winter and summer houses. AT: "the houses they live in during the winter and the houses they live in during the summer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### The houses of ivory will perish

God speaks of the houses being destroyed as if they were alive and would die. AT: "The houses of ivory will be destroyed" or "The houses of ivory will collapse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The houses of ivory

"the houses that are decorated with ivory." This refers to houses that had decorations made of ivory on the walls and furniture. Ivory was very expensive, so only the wealthy people had things decorated with ivory.

#### ivory

the teeth and horns of large animals

#### the large houses will vanish

"the large houses will exist no more." Here "vanish" represents being destroyed. AT: "the large houses will be destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Amos 03:intro

#### Amos 03 General Notes ####

####### Structure and formatting #######

Amos continues to use poetic form in this chapter to prophesy the disaster coming to the kingdoms of Israel and Judah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
This chapter begins with a number of rhetorical questions. The last question provides the reader with some answers: "Yahweh has certainly spoken through his prophets. So listen to them."  The answer to these rhetorical questions have the expected response of "no" because they are things that are not expected to happen. The writer is helping the reader to conclude that God uses the prophets to speak his message. 

##### Links: #####

* __[Amos 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Amos 04

### Amos 04:01

#### you cows of Bashan, you who are in the mountain of Samaria

Amos speaks to the women of Israel who live in Samaria as if they were well-fed cows. AT: "you wealthy women who live in the mountains of Samaria, you who are like the well-fed cows of Bashan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you who oppress the poor

The phrase "the poor" refers to poor people. AT: "you who oppress poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### you who crush the needy

Hear "crush" is a metaphor that represents treating people badly. The phrase "the needy" refers to people who need help. AT: "you who treat needy people badly" or "you who hurt needy people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### The Lord Yahweh has sworn by his holiness

This means that Yahweh promised that he would do something, and he assured people that he would do what he promised because he is holy.

#### the days will come on you

The word "you" refers to the wealthy women of Israel who lived in Samaria, but also includes men.

#### the days will come on you when they will take you away with hooks

A time in the future when bad things will happen to the people is spoken of as if those days will attack the people. The word "they" refers to their enemies. AT: "There will be a time when your enemies will take you away with hooks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will take you away with hooks, the last of you with fishhooks

These two phrases mean basically the same thing and emphasize that the enemy will capture the people like people catch fish. AT: "they will capture you as people capture animals, and they take you away" or "they will defeat you and cruelly force you to go away with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Amos 04:03

#### Connecting Statement:

God continues to speak to the people of Israel.

#### breaks in the city wall

places where the enemy had broken down the city wall to enter

#### you will be thrown out toward Harmon

This can be stated in active form. AT: "they will throw you out toward Harmon" or "your enemies will force you to leave the city and go toward Harmon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Harmon

This is either the name of a place that we do not know, or it refers to Mount Hermon. Some modern versions interpret it in that way. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated these words in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]

### Amos 04:04

#### Connecting Statement:

God continues to speak to the people of Israel.

#### General Information:

God gives several commands in verse 4, but he does so to show that he is angry

#### Go to Bethel and sin, to Gilgal and multiply sin

People would go to Bethel and Gilgal to make sacrifices to God, but they kept sinning anyway. God makes these commands to show that he is angry with them for doing these things. These commands can be expressed as statements. AT: "You go to Bethel to worship, but you sin. You go to Gilgal to worship, but you sin even more" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### bring your sacrifices ... every three days. Offer a thanksgiving sacrifice ... proclaim freewill offerings; announce them

God makes these commands in order to show the people that he is angry that even though they do these things, they continue to sin against him in other ways. These commands can be expressed as statements. AT: "You bring your sacrifices ... every three days. You offer a thanksgiving sacrifice ... you proclaim freewill offerings. And you announce them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### every three days

Possible meanings are 1) on the third day or 3) every third day. Some versions have "every three years," because the Israelites were supposed to bring their tithes to God once every three years.

#### announce them

"boast about them"

#### for this pleases you, you people of Israel

Yahweh rebukes them for being proud about their offerings and sacrifices. They think that God should be pleased with them, but he is not. AT: "for this pleases you, you people of Israel. But it does not please me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### this is the declaration of the Lord Yahweh

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated the similar phrase "this is Yahweh's declaration" in [Amos 2:11](../02/11.md). AT: "this is what the Lord Yahweh declares" or "this is what I, the Lord Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Amos 04:06

#### Connecting Statement:

God continues to speak to the people of Israel.

#### I gave you cleanness of teeth

Here having clean teeth represents having no food in the mouth to make the teeth dirty. AT: "I caused you to starve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### lack of bread

Giving them "lack of bread" represents causing them to lack bread, and "bread" represents food in general. AT: "I caused you not to have enough food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you have not returned to me

Returning to God represents submitting again to him. AT: "you have not submitted again to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated these words in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I also withheld rain from you

"I prevented the rain from falling on your crops"

#### when there were still three months to the harvest

It can be stated clearly that the people needed the rain. AT: "when there were still three months to the harvest and your crops needed the rain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### One piece of land was rained on

This can be stated in active form. The phrase "One piece of land" represents any piece of land." AT: "It rained on one piece of land" or "It rained on some pieces of land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the piece of land where it did not rain

This refers to any piece of land where it did not rain. AT: "the pieces of land where it did not rain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Amos 04:08

#### Two or three cities staggered

Here "cities" represents the people of those cities. AT: "The people of two or three cities staggered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I afflicted you with blight and mildew

Here "afflicted you" represents afflicting their crops. AT: "I afflicted your crops with blight and mildew" or "I destroyed your crops with blight and mildew" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### blight

This is a disease that dries and kills plants. It is caused by the hot wind from the desert.

#### mildew

This is another disease that kills plants.

#### you have not returned to me

Returning to God represents submitting again to him. See how you translated this in [Amos 4:6](./06.md). AT: "you have not submitted again to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated these words in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md)]]

### Amos 04:10

#### I sent a plague on you as on Egypt

"I sent a plague on you as I did on Egypt" or "I sent a plague on you as I sent plagues on Egypt"

#### I sent a plague on you

"I caused terrible things to happen to you"

#### I killed your young men with the sword

Here "the sword" represents battle. God killed them by sending enemies to fight against them. AT: "I made your enemies kill your men in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### carried away your horses

God speaks of causing the enemies to steal their horses as if he carried the horses away. AT: "I made your enemies take away your horses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### made the stench of your camp come up to your nostrils

A stench is a bad smell. The stench coming up to their nostrils represents them smelling something terrible. It can be stated clearly that the smell was from the dead bodies of those who were killed. AT: "I made you smell the terrible odor of the dead bodies in your camp" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You were like a burning stick snatched out of the fire

God speaks of those who survived the plague and war as if they were a burning stick that someone pulled out of a fire. AT: "Some of you survived, like a burning stick that someone pulls out of a fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you have not returned to me

Returning to God represents submitting again to him. See how you translated this in [Amos 4:6](./06.md). AT: "you have not submitted again to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated these words in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md)]]

### Amos 04:12

#### Connecting Statement:

God continues to speak to the people of Israel.

#### prepare to meet your God

God says this to warn the people of Israel that he will judge them. AT: "prepare to meet me, your God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he who forms the mountains ... reveals his thoughts ... is his name

It is not clear whether Amos is speaking about God, or God is speaking about himself. If God is speaking about himself, it can be translated with the words "I" and "me." AT: "I who form the mountains ... reveal my thoughts ... is my name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### makes the morning darkness

Possible meanings are 1) God causes the day to be very dark with thick clouds. AT: "makes the morning dark" or 2) God causes time to pass, so every day becomes night. AT: "makes morning and evening"

#### treads on the high places of the earth

God ruling over all the earth is spoken of as if he walks on the highest places of the earth. AT: "rules over all the earth" or "rules over even the highest places of the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh, God of hosts, is his name

By declaring his full name, Yahweh is declaring his power and authority to do these things. Your language may have a way for people to do this.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md)]]

### Amos 04:intro

#### Amos 04 General Notes ####

####### Structure and formatting #######

This chapter is written in poetic form  and is about the people's refusal to listen to Yahweh even as he tries to point them back to himself. 

####### Special concepts in this chapter #######

######## Repetition ########
This chapter contains a repeated sentence: "Yet you have not returned to me —this is Yahweh's declaration." Please make sure this sentence is translated the same way each time to show the repetition. This repetition produces a list of sins Yahweh is mounting against his people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]])

##### Links: #####

* __[Amos 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Amos 05

### Amos 05:01

#### house of Israel

The word "house" is a metonym for the family that lives in the house. In this case it refers to Israel's descendants. AT: "you people of Israel" or "you Israelite people group" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The virgin Israel has fallen ... no one to raise her up

The phrase "The virgin Israel" represents the nation of Israel. The nation of Israel being destroyed and having no other nation to help them become strong again is spoken of as if it were a young woman who has fallen and has no one to raise her up. AT: "The nation of Israel is like a woman who has fallen ... no one to help her get up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### she is forsaken on her land

This can be stated in active form. AT: "People have forsaken her" or "they have abandoned her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Amos 05:03

#### The city that went out with a thousand ... the one that went out with a hundred

These phrases refer to any cities that sent out large numbers of soldiers. AT: "Cities that went out with a thousand ... cities that went out with a hundred" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### The city that went out with a thousand will have a hundred left

The phrases "a thousand" and "a hundred" refer to a thousand soldiers and a hundred soldiers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The city that went out with a thousand

"The city that went out" represents the soldiers of that city going out. It can be stated clearly why they went out. AT: "The city out of which a thousand soldiers went to fight" or "The city that sent out a thousand soldiers to fight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### will have a hundred left

"will have a hundred soldiers who have not been killed" or "will have only a hundred soldiers still alive." Here being "left" refers to not being killed by the enemy.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Amos 05:04

#### Seek me

Here "Seek me" represents asking God for help. AT: "Ask me for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do not seek Bethel

Here "seek Bethel" represents going to Bethel to ask for help. AT: "Do not go to Bethel to ask for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### nor enter Gilgal

"and do not enter Gilgal"

#### For Gilgal will surely go into captivity

Here "Gilgal" represents the people of Gilgal, and going into captivity refers to being captured and taken away. AT: "For the people of Gilgal will surely be captured and taken away" or "For your enemies will surely capture the people of Gilgal and take them away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Bethel will become nothing

Here "become nothing" represents being destroyed. AT: "Bethel will be completely destroyed" or "enemies will completely destroy Bethel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]

### Amos 05:06

#### Seek Yahweh

Here "Seek Yahweh" represents asking him for help. AT: "Ask Yahweh for help" or "Ask me, Yahweh, for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will break out like fire

Here "break out like a fire" represents destroying things as fire destroys things. AT: "he will become like a fire that breaks out suddenly and destroys everything" or "he will destroy everything like a fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the house of Joseph

This phrase is a metonym for the descendants of Joseph. Here it represents the northern kingdom of Israel, whose two largest tribes were the descendants of Joseph. AT: "the descendants of Joseph" or "Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### It will devour

The word "it" refers to the fire, and "devour" represents destroying everything. God destroying everything is spoken of as if a fire were to destroy everything. AT: "It will destroy everything" or "He will destroy everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### there will be no one to quench it

"there will no one to stop it" or "there will be no one to stop him from destroying everything"

#### turn justice into a bitter thing

Here "a bitter thing" represents actions that harm people, and "turn justice into a bitter thing" represents harming people rather than doing for them what is just. AT: "say that they are doing what is just, but instead they harm people" or "refuse to do what is just and harm people instead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### throw righteousness down to the ground

This represents treating righteousness as if it were worthless. AT: "treat righteousness as though it were as unimportant as dirt" or "you despise what is righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/quench.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/quench.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Amos 05:08

#### the Pleiades and Orion

People saw patterns in the stars in the sky and gave names to them. These are two of those patterns. AT: "the stars" or "the groups of stars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### he turns darkness into the morning ... day dark with night

"he makes the night become morning, and he makes the day become night." This refers to causing the times of the day.

#### calls for the waters ... on the surface of the earth

This represents God causing the sea water to fall on the earth as rain. AT: "he takes the waters of the sea and makes them rain down on the surface of the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh is his name!

By declaring his name, Yahweh is declaring his power and authority to do these things.

#### He brings sudden destruction on the strong

The abstract noun "destruction" can be translated with the verb "destroy." The phrase "the strong" refers to strong people, specifically soldiers. AT: "He suddenly destroys the strong people" or "He suddenly destroys the soldiers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### so that destruction comes on the fortresses

The abstract noun "destruction" can be translated with the verb "destroy." AT: "so that the fortresses are destroyed" or "and he destroys the fortresses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

### Amos 05:10

#### They hate anyone

"The people of Israel hate anyone"

#### you trample down the poor and take portions of wheat from him

The word "you" refers to the people of Israel. Here "trample down the poor" represents treating poor people badly. AT: "you greatly oppress poor people and take portions of wheat from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### take portions of wheat from him

"make him give you part of his grain"

#### worked stone

"cut stones" or "stones that people have cut"

#### you will not drink their wine

The word "their" refers to the vineyards. This may imply that no one will make the wine, or even that there will not be enough good grapes to make wine. AT: "you will not drink the wine that is made from the grapes in your vineyards" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Amos 05:12

#### afflict the just, take bribes, and turn aside the needy in the city gate

This is a list of some of their sins.

#### the just

The word "just" is a nominal adjective that refers to just people. AT: "just people" or "righteous people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### take bribes

"let people pay you to do bad things" or "let people pay you to lie about people"

#### turn aside the needy in the city gate

Here "turn aside the needy" represents telling the needy people to leave. It can be made clear why the needy were at the city gate. AT: "do not allow poor people to bring their cases to the judges in the city gate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the needy

The word "needy" is a nominal adjective that refers to people who are in need. AT: "people in need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### any prudent person is silent

Those who do not want the evil people to harm them will not speak out against the evil deeds. AT: "wise people do not speak about the evil things people are doing"

#### for it is an evil time

Here "an evil time" represents a time when people are evil and do evil deeds. AT: "for it is a time when people are evil" or "for people do evil things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Amos 05:14

#### Seek good and not evil

Here "Seek good" represents choosing to do what good. "Good" and "evil" represent good actions and evil actions. AT: "Choose to do what is good and not what is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Hate evil, love good

"Hate evil actions, and love good actions." Here "good" and "evil" represent good actions and evil actions.

#### establish justice in the city gate

Here "establish justice" represents making sure that justice is done. AT: "make sure that justice is done in the city gates" or "make sure that the judges make just decisions in the city gates" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### in the city gate

City gates were where business transactions occurred and judgments were made, because city walls were thick enough to have gateways that produced cool shade from the hot sun AT: "in your courts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the remnant of Joseph

Here "remnant" refers to people who are still living in Israel after the others are killed or taken away as captives. Here "Joseph" represents the northern kingdom of Israel, whose two largest tribes were the descendants of Joseph. See how you translated "house of Joseph" in [Amos 5:6](./06.md). AT: "the descendants of Joseph who are still alive" or "those of Israel who survive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]

### Amos 05:16

#### this is what Yahweh says, the God of hosts, the Lord

"this is what Yahweh, the God of hosts, the Lord says"

#### Wailing will be in all the squares

"People will wail in all the town squares"

#### Wailing

long, loud, sad cries

#### the squares

broad open places in the town where people gather

#### the mourners to wail

The phrase "they will call" is understood from the beginning of the sentence. AT: "they will call the mourners to wail" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### I will pass through your midst

God speaks of punishing the people as if he were to come and punish them while walking through the group of them. AT: "I will come and punish you" or "I will punish you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]

### Amos 05:18

#### Why do you long for the day of Yahweh?

God uses this question to rebuke the people for saying that they want the day of Yahweh to be soon. This can be translated as a statement. AT: "You long for the day of Yahweh." or "You should not long for the day of Yahweh!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### It will be darkness and not light

Here "darkness" represents a time when disasters happen, and "light" represents a time when good things happen. AT: "It will be a time of darkness and disaster, not of light and blessing" or "On that day there will be disasters, not blessings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Will not the day of Yahweh be darkness and not light?

This question emphasizes that bad things will happen then. It can be expressed as a statement. AT: "The day of Yahweh will certainly be darkness and not light!" or "Bad things, not good things, will certainly happen on the day of Yahweh!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Gloom and no brightness?

The words "Will not the day of Yahweh be" is understood from the previous sentence. Like the previous question, it emphasizes that terrible things, not good things, will happen on the day of Yahweh. It can be expressed as a statement. AT: "It will be a time of when terrible things, not good things, will happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]

### Amos 05:21

#### I hate, I despise your festivals

The word "despise" is a strong word for "hate." Together the two words emphasize the intensity of Yahweh's hatred for their religious festivals. AT: "I hate your festivals very much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### I take no delight in your solemn assemblies

"Your solemn assemblies do not please me at all"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md)]]

### Amos 05:23

#### Remove from me the noise of your songs

This speaks of the noise of songs as if it could be put somewhere else. It represents stopping singing. AT: "Stop singing your noisy songs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### noise

unpleasant sounds

#### let justice flow like water, and righteousness like a constantly flowing stream

This represents causing there to be much justice and righteous. AT: "let there be so much justice that it is like flowing water, and let there be so much righteousness that it is like a constantly flowing stream" or "let justice abound like a flood, and let righteousness abound like a stream that never stops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Amos 05:25

#### Did you bring me sacrifices ... Israel?

Possible meanings are 1) God uses this question to rebuke them because they did not offer sacrifices. AT: "You did not bring me sacrifices ... Israel." or 2) God uses this question to remind them that the sacrifices were not the most important part about their relationship. AT: "You did not have to bring me sacrifices ... Israel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Did you bring

God speaks as though the Israelites he is speaking to were part of the group that wandered in the wilderness. AT: "Did your ancestors bring" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### house of Israel

The word "house" is a metonym for the family that lives in the house. In this case it refers to Israel's descendants. See how you translated it in [Amos 5:1](./01.md). AT: "you people of Israel" or "you Israelite people group" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You have lifted up the images of Sikkuth ... and Kaiwan

Here "lifted up the images" represents worshiping them. AT: "You have worshiped the images of Sikkuth ... and Kaiwan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Sikkuth ... Kaiwan

These are the names of two false gods. The people had made images to represent them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Kaiwan

Some versions write this as "Kiyyun."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Amos 05:27

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Amos 05:intro

#### Amos 05 General Notes ####

####### Structure and formatting #######

This chapter continues to be written in a poetic format and foretells the destruction of the kingdom of Israel.

####### Special concepts in this chapter #######

######## Place Names ########
This chapter refers to various places in land of Israel (i.e. Gilgal, Bethel, Beersheba). Normally these places have good connotations, but here they are referred to negatively. This is most likely because these cities became known for their idol worship. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]]) 

######## City gate ########
The "city gate" is mentioned several times. This was a place where people would go with legal and financial issues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]]) 

##### Links: #####

* __[Amos 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Amos 06

### Amos 06:01

#### who are at ease

"who feel safe." The people are comfortable and not concerned that God will judge them.

#### the notable men of the best of the nations

"the most important men of this great nation." Yahweh may be using irony to describe how these men think of themselves. AT: "the men who think they are the most important people in the best nation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### the house of Israel comes

The word "house" is a metonym for the family that lives in the house. In this case it refers to Israel's descendants. AT: "the Israelites come" or "the Israelite people group comes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### comes for help

Here "comes" can be stated as "goes." AT: "goes for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md)]])

#### Kalneh

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Are they better than your two kingdoms?

The notable men use this question to emphasize that the kingdoms of Israel and Judah are better than those other kingdoms. AT: "Your two kingdoms are better than they are." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is their border larger than your border?

The notable men use this question to emphasize that their kingdoms are larger than those other kingdoms. AT: "Their border is smaller than yours." or "Those countries are smaller than Judah and Samaria." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Amos 06:03

#### to those who put off the day of disaster

Refusing to believe that Yahweh will cause disaster is spoken of as if the "day of disaster" were an object the people could put far from themselves. AT: "to those who refuse to believe that I will cause them to experience disaster" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### and make the throne of violence come near

Here "throne" is a metonym that represents reign or rule. The people doing evil things, which causes Yahweh to bring disaster on them, is spoken of as if they were causing "violence" to rule them. AT: "but who are actually causing me to send violent people to destroy you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lie ... lounge

Israelites at that time usually ate while sitting on a floor cloth or a simple seat.

#### beds of ivory

"beds decorated with ivory" or "costly beds"

#### ivory

a white substance made from the teeth and horns of large animals (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### lounge

"lie around like lazy people"

#### couches

soft seats large enough to lie down on

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]

### Amos 06:05

#### they improvise on instruments

Possible meanings: 1) they invent new songs and ways of playing the instruments or 2) they invent new instruments.

#### drink wine from bowls

This implies that they drink a lot of wine because they drink it from a large bowl rather than a regular wine cup. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they do not grieve over the ruin of Joseph

Here "Joseph" represents his descendants. AT: "they do not grieve about the descendants of Joseph whom enemies will soon destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]

### Amos 06:07

#### they will now go into exile with the first exiles

"they will be among the first ones to go into exile" or "I will send them into exile first"

#### the feasts of those who lounge about will pass away

"there will be no more feasts for people to lie around at ease"

#### this is the declaration of the Lord Yahweh, the God of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 3:13](../03/13.md). AT: "this is what the Lord Yahweh, the God of hosts, has declared" or "this is what I, the Lord Yahweh, the God of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I detest the pride of Jacob

Here "Jacob" represents his descendants. AT: "I hate the descendants of Jacob because they have become arrogant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I hate his fortresses

It is implied that Yahweh hates the fortresses because the people believed the fortresses would keep them safe. AT: "I hate the people of Israel because they trust in their fortresses, not in me, to protect them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Amos 06:09

#### General Information:

In 6:9-10 Amos describes a hypothetical situation of what it will be like when Yahweh hands the people of Israel over to their enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### if there are ten men left in one house, they will all die

This seems to imply that something terrible is happening, and these ten men go into the house to hide. AT: "if ten men are hiding inside of a house, they will all still die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a man's relative comes to take their bodies up—the one who is to cremate them after bringing the corpses out of the house—if he says to the person in the house, "Is ... you?"

The meaning of these words is not clear. Possible meanings are 1) the "man's relative" is the one who will "take their bodies up" and "cremate ... the corpses," and he speaks to a person who hid in the house after the ten family members died or 2) the "man's relative" who "comes to take their bodies up" is a different person from "the one who is to cremate ... the corpses," and they talk to each other in the house. AT: "a man's relative comes to take their bodies up, and the one who will burn the corpses after they have been brought out of the house is with him—if while they are in the house the relative says to the burner of the corpses, 'Is ... you?'"

#### cremate

to burn a dead body

#### bringing the corpses

"bringing the dead bodies"

#### Then he will say, "Be quiet, for we must not mention Yahweh's name."

The meaning of this is not clear. It seems to imply that the one who asked the question is afraid the one answering will mention Yahweh's name carelessly. If he does this, it may draw Yahweh's attention to them, and he may kill them too. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Amos 06:11

#### look

"listen" or "pay attention"

#### the big house will be smashed to pieces, and the little house to bits

These two phrases share similar meanings. The contrast between "the big house" and "the little house" means that this refers to all houses. AT: "all the houses will be smashed into small pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the big house will be smashed to pieces

This can be stated in active form. AT: "the enemy will smash the big house to pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to pieces ... to bits

You can use the same word for both of these phrases.

#### the little house to bits

This can be stated with the understood information included. AT: "enemies will smash the little house to bits" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Amos 06:12

#### General Information:

Amos uses two rhetorical questions to draw attention to the rebuke that follows.

#### Do horses run on the rocky cliffs?

It is impossible for a horse to run on rocky cliffs without getting hurt. Amos uses this rhetorical question to rebuke them for their actions. AT: "Horses do not run on rocky cliffs." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Does one plow there with oxen?

One does not plow on rocky ground. Amos uses this rhetorical question to rebuke them for their actions. AT: "A person does not plow with oxen on rocky ground." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Yet you have turned justice into poison

Distorting what is just is spoken of as if the leaders "turned justice into poison." AT: "Yet you distort what is just" or "But you make laws that hurt innocent people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the fruit of righteousness into bitterness

This means basically the same thing as the first part of the sentence. Distorting what is right is spoken of as if righteousness were a sweet fruit that the people made bitter tasting. AT: "you distort what is right" or "you punish those who do what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Lo Debar ... Karnaim

These are names of towns. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Have we not taken Karnaim by our own strength?

The people use a question to emphasize that they believe they captured a city because of their own power. AT: "We captured Karnaim by our own power!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Amos 06:14

#### look

"listen" or "pay attention"

#### house of Israel

Here "house" represents people. AT: "people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### this is the declaration of the Lord Yahweh, the God of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 3:13](../03/13.md). AT: "this is what the Lord Yahweh, the God of hosts, has declared" or "this is what I, the Lord Yahweh, the God of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### from Lebo Hamath to the brook of the Arabah

Here "Lebo Hamath" represents the northern border of Israel, and "brook of the Arabah" represents the southern border. AT: "from the northern border of your nation to the southern border" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### brook

a small river that flows only during the wet season

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabah.md)]]

### Amos 06:intro

#### Amos 06 General Notes ####

####### Structure and formatting #######

This chapter continues to be written in poetic style except for verses 9-10, which are in prose. These two verses contain many interested features. 

####### Other possible translation difficulties in this chapter #######

Verses 9-10 will probably be difficult to translate because the situation is vague and details don't appear to align easily. It is appropriate to translate these verses with some ambiguity remaining. It may be helpful to read many different versions prior to translating these verses.  

##### Links: #####

* __[Amos 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Amos 07

### Amos 07:01

#### Look ... look

The writer is telling the reader that he is about to say something surprising. Your language may have a way of doing this.

#### locust

See how you translated this in [Amos 4:9](../04/08.md).

#### after the king's harvest

"after the king takes his share from the harvest"

#### please forgive

The words "your people" or "us" are understood. AT: "please forgive your people" or "please forgive us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### how will Jacob survive? For he is so small.

Here "Jacob" represents his descendants the Israelites. AT: "how will we Israelites survive? We are so small and weak!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]

### Amos 07:04

#### Look

The writer is telling the reader that something surprising is about to happen. Your language may have a way of doing this.

#### the Lord Yahweh called on fire to judge

"the Lord Yahweh used burning fire to punish the people"

#### how will Jacob survive? For he is so small.

Here "Jacob" represents his descendants the Israelites. See how you translated this in [Amos 7:2](./01.md). AT: "how will the Israelites survive? We are so small and weak!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]

### Amos 07:07

#### plumb line

thin rope with a weight at one end used in building to make sure walls stand straight up and down

#### what do you see?

Yahweh uses a question to teach Amos. AT: "tell me what you see." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I will put a plumb line among my people Israel

Judging the people and determining they are wicked is spoken of as if the Israelites were a wall, and Yahweh determines the wall is not straight by using a plumb line. AT: "my people Israel are wicked. They are like a wall that is not straight up and down" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Amos 07:09

#### The high places of Isaac will be destroyed, the sanctuaries of Israel will be ruined, and I will rise against the house of Jeroboam with the sword

Here "sword" represents an army. This can be stated in active form. AT: "I will send an army to attack the house of Jeroboam, and the army will destroy the high places of Isaac and the sanctuaries of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Isaac ... Israel

Both of these represent the people of Israel. AT: "the descendants of Isaac ... the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the house of Jeroboam

Here "house" represents "family." Translate "Jeroboam" as you did in [Amos 1:1](../01/01.md). AT: "Jeroboam and his family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeroboam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeroboam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Amos 07:10

#### Amaziah, the priest of Bethel

Possible meanings: 1) Amaziah was the only priest at Bethel or 2) Amaziah was the leader of the priests at Bethel.

#### Amaziah

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Amos has conspired against you in the middle of the house of Israel

Here "house" represents "people." AT: "Amos is right here among the Israelites, and he is planning to do bad things to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The land cannot bear all his words

Here "land" represents "people." Disrupting the peace is spoken of as if Amos's words were a heavy object that the land could not carry. AT: "What his is saying disturb the peace among the people" or "His message will cause trouble among the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Jeroboam will die by the sword

Here "sword" represents the enemies. AT: "Enemies will kill Jeroboam" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeroboam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeroboam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amos.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amos.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]

### Amos 07:12

#### there eat bread and prophesy

Here "eat bread" is an idiom that means to earn money or make a living for doing something. AT: "see if you can get the people there to pay you for prophesying" or "prophesy there and let them provide you with food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### for it is the king's sanctuary and a royal house

Here "king's sanctuary" and "royal house" refer to the same place. AT: "this is where the national temple is, the place where the king worships" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]

### Amos 07:14

#### herdsman

This here probably means "one who takes care of sheep" since he is called a "shepherd" in [Amos 1:1](../01/01.md).

#### sycamore fig trees

Sycamores are broad trees that grow up to 15 meters tall. AT: "fig trees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Amos 07:16

#### Now

Here the word "now" is used to draw attention to the important point that follows.

#### do not speak against the house of Isaac

Here "house" represents the family or descendants of Isaac. AT: "do not speak against the descendants of Isaac" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your sons and your daughters will fall by the sword

Here "sword" represents enemies. AT: "enemies will kill your sons and daughters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your land will be measured and divided up

This can be stated in active form. AT: "other people will take your land and divide it up among themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### an unclean land

A land full of people that are unacceptable to God is spoken of as if the land were physically unclean. Here it means a land other than Israel. AT: "a foreign land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]

### Amos 07:intro

#### Amos 07 General Notes ####

####### Structure and formatting #######

This chapter is mainly written as a narrative about the prophet Amos interacting with Yahweh. Yahweh presents three different scenarios of judgment before Amos who pleads with God and he does not carry out His judgment. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]])

####### Special concepts in this chapter #######

######## Reported speech ########
In the latter part of the chapter, it is important to follow the conversation carefully to understand who is speaking. There are some instances of "reported speech." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

##### Links: #####

* __[Amos 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Amos 08

### Amos 08:01

#### Look, a basket of summer fruit!

The word "look" here shows that Amos saw something interesting. AT: "I saw a basket of summer fruit!"

#### summer fruit

"ripe fruit"

#### What do you see, Amos?

Yahweh uses a question to teach Amos. AT: "Tell me what you see, Amos." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### in that day

"at that time"

#### this is the declaration of the Lord Yahweh

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 4:5](../04/04.md). AT: "this is what the Lord Yahweh declares" or "this is what I, the Lord Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Silence!

Possible meanings are 1) Yahweh is to telling the people to be silent as they hear about the severity of his punishment or 2) the people will be silent because of their grief after Yahweh's punishment.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Amos 08:04

#### Listen to this

Amos is speaking to the wealthy merchants who harm those who are poor.

#### you who trample the needy and remove the poor of the land

This can be restated to remove the nominal adjectives "the needy" and "the poor." AT: "you who trample those who are in need and remove those in the land that are poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### you who trample

Harming people is spoken of as if it were stomping on people. AT: "you who harm" or "you who oppress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They say, "When will the new moon be over, so we can sell grain again? When will the Sabbath day be over, so that we can sell wheat?

The merchants use theses question to emphasize that want to start selling their items again. This can be stated as an indirect quotation. AT: "They are always asking when the new moon will be over or when the Sabbath will be over so that can sell their grain and wheat again." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### We will make the measure small and increase the price, as we cheat with false scales

The merchants would use false scales that showed that the amount of grain they were giving was greater than it really was and that the weight of the payment was less than it really was.

#### the needy for a pair of sandals

The words "and buy" are understood. AT: "buy the needy for a pair of sandals" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/newmoon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/newmoon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md)]]

### Amos 08:07

#### Yahweh has sworn by the pride of Jacob

Here "pride of Jacob" is a title for Yahweh. Also "Jacob" represents his descendants, the Israelites. AT: "Yahweh has sworn by himself, saying" or "Yahweh, of whom the Israelites are so proud, has sworn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Will not the land quake for this, and every one who lives in it mourn?

Amos uses a question to emphasize that these things will certainly happen. AT: "Yahweh will cause the land to shake, and every one who lives in it will mourn." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### All of it will rise up like the Nile River ... like the river of Egypt

Amos compares the rising and sinking of the waters of the Nile River to how Yahweh will cause the land to shake when he judges the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### river of Egypt

This is another name for the Nile River.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Amos 08:09

#### It will come in that day

"It will happen at that time"

#### this is the declaration of the Lord Yahweh

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 4:5](../04/04.md). AT: "this is what the Lord Yahweh declares" or "this is what I, the Lord Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### have baldness on every head

A person shaves his head to show that he is grieving. AT: "cause you all to shave your heads" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### like mourning for an only son

It is understood that the only son has died. AT: "like mourning for an only son who has died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### a bitter day to its end

Terrible and sad things happening during a day is spoken of as if the day had a bitter taste. AT: "everything that happens at that time will cause you great sorrow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]

### Amos 08:11

#### the days are coming

This speaks of a future time as if "days are coming." AT: "there will be a time" or "in the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this is the declaration of the Lord Yahweh

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 4:5](../04/04.md). AT: "this is what the Lord Yahweh declares" or "this is what I, the Lord Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### when I will send a famine in the land ... but for hearing the words of Yahweh

Yahweh refusing to give messages when the people want to hear from him is spoken of as if there would be a famine of his words. AT: "when I will cause something like a famine in the land ... but for hearing the words of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the words of Yahweh

This can be stated in first person. AT: "words from me, Yahweh" or "my messages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### They will stagger from sea to sea; they will run from the north to the east to seek the word of Yahweh

Here "sea to sea" and "the north to the east" represent all of the land of Israel. AT: "They will wander here and there and search all over for the word of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### from sea to sea

This implies the Dead Sea in the south and the Mediterranean Sea in the west. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]

### Amos 08:13

#### In that day

"At that time"

#### faint

to lose all strength

#### by the sin of Samaria

Here "sin" represents the false god the people worship in Samaria. AT: "by the false god of Samaria" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### As your god lives, Dan

This is a way of making a solemn oath. The people declare that they believe the god of Dan is certainly alive to emphasize that they will certainly do what they promise to do.

#### As the way to Beersheba exists

This is probably a reference to the roads that pilgrims would take to Beersheba in order to worship idols there. Again, this is a way of making a solemn oath. They state that the way to Beersheba certainly exists in order to emphasize that they will certainly do what they promise to do.

#### they will fall

This is an idiom. AT: "they will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md)]]

### Amos 08:intro

#### Amos 08 General Notes ####

####### Structure and formatting #######

This chapter is written in poetic form and it shows the way Yahweh's people are sinning and
how he is going to respond. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Important figures of speech in this chapter #######

######## "This is the declaration of Yahweh" ########

This phrase is used to introduce prophecy. It highlights what God is proclaiming. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Amos 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Amos 09

### Amos 09:01

#### General Information:

Yahweh shows Amos another vision.

#### Strike the tops ... Break them

It is uncertain to whom Yahweh is speaking these commands.

#### Strike the tops of the pillars so that the foundations will shake

It is implied that Yahweh is speaking about the pillars and foundations of a temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so that the foundations will shake

Here "foundations" represents the whole temple. AT: "so that the whole temple will shake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Break them in pieces on all of their heads

Here "heads" represents the whole person. AT: "Break the pillars so that the temple falls on all of the people and kills them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### I will kill the last of them with the sword

Here "sword" represents an army attacking with their weapons. AT: "I will send an enemy army to kill the rest of them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Though they dig into Sheol, there my hand will take them. Though they climb up to heaven, there I will bring them down

Yahweh uses an exaggerated image of people fleeing to Sheol or heaven to try to escape being killed. Here "Sheol" and "heaven" are a merism that represents all places. AT: "Even if they were to flee to Sheol or to heaven, they would not be able to escape me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### there my hand will take them

Here "hand" represents Yahweh's power. AT: "I will pull them up from there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Amos 09:03

#### Though they hide on the top of Carmel ... Though they are hidden from my sight in the bottom of the sea

Yahweh gives an exaggerated image of the people fleeing to the top of mount Carmel or to the bottom of the sea to escape being killed. Here "top of Carmel" and "bottom of the sea" are a merism that represents all places. AT: "Even if they were to hide on the top of Carmel ... Even if they tried to go the bottom sea, thinking that I could not see them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### serpent

an unknown fierce sea animal, not the snake in the garden of Eden and not a common snake

#### Though they go into captivity, driven by their enemies before them

This can be stated in active form. AT: "Though enemies capture them and force them to go to a foreign land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### there will I give orders to the sword, and it will kill them

Here "sword" represents their enemies. AT: "there I will cause their enemies to kill them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will keep my eyes on them for harm and not for good

Here "eyes" represents seeing. The phrase "keep my eyes on them" is an idiom that means to watch closely. AT: "I will watch closely and make sure only bad things happen to them and not good things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]

### Amos 09:05

#### all of it will rise up like the River, and sink again like the river of Egypt

Here "the River" and "river of Egypt" both refer to the Nile river. Yahweh causing the land to shake violently is compared to the waters of the Nile river rising and sinking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### he who builds his steps in the heavens

These are probably the steps that ancient people imagined led up to God's palace in the heavens. However, some modern versions wish to read a different Hebrew word meaning "palace" or "rooms." Here "his steps" probably is a metonym for God's palace. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has established his vault over the earth

Here "vault" refers to the sky which biblical writers described as being a dome over the earth. AT: "he sets the sky over the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He calls for the waters of the sea ... on the surface of the earth

This represents God causing the sea water to fall on the earth as rain. See how you translated this in [Amos 5:8](../05/08.md). AT: "He takes the waters of the sea and makes them rain down on the surface of the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh is his name

By declaring his name, Yahweh is declaring his power and authority to do these things. See how you translated this in [Amos 5:8](../05/08.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Amos 09:07

#### Are you not like the people of Cush to me, people of Israel?

Yahweh uses a question to emphasize that the people of Israel are no more special to him than the people of Cush. AT: "You people of Israel, you are certainly now no more important to me than the people of Cush." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated these words in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Did I not bring up Israel out of the land of Egypt, the Philistines from Crete, and the Arameans from Kir?

Yahweh uses a question to emphasize that the people of Israel are no more special than the Philistines or the Arameans. AT: "Yes, I brought the people of Israel from the land of Egypt, but I also brought the Philistines from Crete and the Arameans from Kir." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Kir

See how you translated the name of this place in [Amos 1:5](../01/05.md).

#### the eyes of the Lord Yahweh are on the sinful kingdom

Here "eyes" represents seeing. Also, Yahweh speaks of himself in third person. AT: "I, the Lord Yahweh, see that the people of this kingdom are very sinful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I will destroy it from the face of the earth

The idiom "from the face of the earth" means "completely." AT: "I will completely destroy this kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the house of Jacob

Here "house" represents a family. And, "Jacob" represents his descendants. AT: "the descendants of Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/crete.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/crete.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]

### Amos 09:09

#### the house of Israel

Here "house" represents the people. AT: "the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will shake the house of Israel ... as one shakes grain in a sieve, so that not the smallest stone will fall to the ground

The picture here is of grain falling through the sieve and stones being kept out. The idea is that Yahweh will remove all of the sinful people from Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### sieve

a surface with many small holes that allow small things to pass through and keep larger things from passing through

#### All the sinners of my people will die by the sword

Here "sword" represents their enemies. AT: "Enemies will kill all the sinners of my people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Disaster will not overtake or meet us

Experiencing disaster is spoken of as disaster could overtake or meet someone. AT: "We will not experience disaster" or "Bad things will not happen to us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Amos 09:11

#### In that day

"At that time"

#### I will raise up the tent of David that has fallen

Causing the people of Israel to be great again is spoken of as if David's kingdom were a tent that fell down and Yahweh will set it back up. AT: "David's kingdom will be like tent that has fallen down, but I will raise it back up again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### close up its breaches

"I will repair its walls"

#### I will raise up its ruins, and rebuild it as in the days of old

"I will rebuild its ruins and make it strong like it was long ago"

#### breaches

parts of a wall that have fallen down

#### the remnant of Edom

"the remaining part of Edom's territory"

#### all the nations that are called by my name

Here "name" represents Yahweh. The idiom "called by my name" means they once belonged to Yahweh. This means that in the past the people had conquered and taken control of these territories. AT: "all the nations that once belonged to me" or "all the nations that I caused the people of Israel to conquer in the past" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Amos 09:13

#### Look

The writer is telling the reader that he is going to say something surprising. Your language may have a way of doing this.

#### the days will come ... when the plowman

A future time is spoken of as if "days will come." AT: "there will be a time ... when the plowman" or "in the future ... the plowman" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### when the plowman ... him who plants seed

These are two images of Yahweh restoring prosperity in Israel. This means grain will grow faster than the people can harvest it, and there will be so many grapes, those crushing the grapes will still be working when farmers start planting more vineyards.

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Amos 2:11](../02/11.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### The mountains will drip sweet wine, and all the hills will flow with it

These two lines mean basically the same thing. The huge amount of grapes and wine in Israel is spoken of as if wine flows down the hills and mountains. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Amos 09:14

#### I will plant them upon their land, and they will never again be uprooted from the land

Bringing the people back to their land and keeping them safe from enemies is spoken of as if Israel were a plant that Yahweh would put in the ground and not let anyone pull the plant up from the ground. AT: "I will cause them to live in the land forever like a plant that is never uprooted" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will never again be uprooted from the land

This can be stated in active form. AT: "no one will ever again uproot them from the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### uprooted

for a plant and its roots to be pulled out of the ground

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Amos 09:intro

#### Amos 09 General Notes ####

####### Structure and formatting #######

This chapter is written in poetic form and continues to show the awesome and terrible judgment of Yahweh on his people. In verse 11, the writer writes about the forgiveness and mercy of God on the kingdom of Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]])

####### Special concepts in this chapter #######

######## "The declaration of Yahweh" ########
This phrase is used to introduce prophecy. It highlights what God is proclaiming. Try to remain consistent in translating this phrase throughout the book. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Amos 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | __


## Amos front

### Amos front:intro

#### Introduction to Amos ####

##### Part 1: General Introduction #####

####### Outline of the Book of Amos #######

1. The author, Amos, and his background and calling (1:1)
1. The oracles of judgment
    - Judgment on the nations surrounding Yahweh's people (1:2–2:3)
    - Judgment on the southern kingdom (2:4–5)
    - Judgment on the northern kingdom (2:6–16)
    - Various judgments on Israel (3:1–6:14)
1. The visions of judgment
    - Final judgment (7:1–17)
    - The basket of ripe fruit as a picture of judgment (8:1–14)
1. Yahweh stands beside his altar and proclaims the final message
    - Summary of all the visions (9:1–10)
    - Vision of the restoration of Israel and descendants of David as kings (9:11–15)

####### What is the Book of Amos about? #######

Amos began to prophesy about 760 BC. He spoke Yahweh's messages against the wicked behavior of God's people. He spoke messages to the southern kingdom of Judah and to the northern kingdom of Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

Yahweh gave Amos the "judgment prophecies" found in the first six chapters of the book to proclaim to the people. Each of them begins with the phrase "This is what Yahweh says" (ULB). 

The last part of the book of Amos contains three visions of the coming judgment from God. The final vision promises both destruction and rescue (9:11-15). The "tent of David" would be raised up again, that is, David's descendants would once again be king over Israel. 

####### How should the title of this book be translated? #######
 
The Book of Amos may also be called the "The Book of the Sayings of Amos." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Amos? #######

It is likely that Amos wrote this book. He lived in the southern kingdom of Judah. Amos came from a poor family. They grew sycamore trees (See: 7:14, 15) and were shepherds (See: [Amos 1:1](../01/01.md)). Though Amos was not trained as a prophet, he demonstrated a very thorough knowledge and understanding of the law of Moses. Also, Amos was very skilled at communicating with expressive and meaningful words.

##### Part 2: Important Religious and Cultural Concepts #####

####### What is social justice? #######

Amos was very concerned with justice. A godly society or community was to be just. Amos said that if the people wanted to be just they must obey Yahweh and treat poor people, orphans, and widows in a fair way. Amos explained that Yahweh would prefer that the people act justly rather than sacrifice to him. True obedience to the law of Moses meant being just to other people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### What is a lawsuit? #######

Many cultures have a process for resolving disputes through the use of courts. These legal disputes are called lawsuits. There are various legal terms in Amos, and part of the book presents events in a courtroom. The people are introduced, the problem is explained, the people are examined, witnesses speak, and a verdict is given.

##### Part 3: Important Translation Issues #####

####### What is the meaning of the term "Israel"? #######

The name "Israel" is used in many different ways in the Bible. There was a man named Jacob. God changed his name to Israel. The descendants of Jacob became a nation also called Israel. Eventually, the nation of Israel split into two kingdoms. The northern kingdom was named Israel. The southern kingdom was named Judah. In Amos, "Israel" almost always refers to the northern kingdom of Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]])

####### Where do the various narratives begin and end? #######

The structure of the Book of Amos may make it difficult to understand where Amos ends one thought and begins another. It may be helpful to solve these issues with carefully divided lines or paragraphs.



---

