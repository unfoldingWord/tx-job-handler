# <a id="pro"/>Proverbs

## Proverbs 01

### Proverbs 01:01

#### General Information:

Verses 2-33 are poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]])

#### to teach wisdom and instruction

This can be reworded so that the abstract nouns "wisdom" and "instruction" can be stated as adjectives or verbs. AT: "to teach you how to be wise and to instruct you about how to live moral lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### to teach words of insight

"to help you understand wise teachings"

#### that you may receive

Here "you" refers to the readers. If it is more natural in your language you can state it as an inclusive "we." AT: "that we may receive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### may receive instruction in order to live

This can be reworded so that the abstract noun "instruction" is stated as a verb. AT: "may be instructed how to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]

### Proverbs 01:04

#### are also to give wisdom to the naive

This can be reworded so that the abstract noun "wisdom" can be stated as the adjective "wise." This can also be stated in active form. AT: "also teach to those who are naive how to be wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### naive

inexperienced or immature

#### to give knowledge and discretion to young people

The abstract nouns "knowledge" and "discretion" can be stated as verbs. AT: "and to teach to young people what they need to know and how to discern the right thing to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### discretion

knowing what should be done in a particular situation

#### Let wise people listen and increase their learning

"Let those who are wise pay attention and learn even more"

#### let discerning people get guidance

"let people who have understanding learn from these proverbs how to make good decisions"

#### riddles

sayings that one can understand only after thinking about them

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]

### Proverbs 01:07

#### General Information:

A father teaches his child.

#### The fear of Yahweh is the beginning of knowledge

The abstract nouns "fear," "beginning," and "knowledge" can be stated as verbs. AT: "You must first fear Yahweh in order to begin to know what is wise" or "You must first honor and respect Yahweh in order to learn what is wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### fools despise wisdom and instruction

"those who do not value what is wise and instructive are fools"

#### do not lay aside

This is an idiom that means "do not ignore" or "do not reject" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they will be a graceful wreath for your head and pendants hanging from your neck

The rules and instructions that parents teach their children are so valuable and important that they are spoken of as if they were a beautiful wreath or pendant that a person wears. AT: "they will make you wise just as wearing a wreath on your head or a pendant around your neck makes you beautiful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wreath

an woven circle made of leaves or flowers

#### pendants

jewelry that is worn around the neck

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Proverbs 01:10

#### try to entice you into their sin

"try to persuade you to sin as they do"

#### refuse to follow them

"refuse them" or "do not listen to them"

#### If they say

Here the speaker gives an example of what sinners may try to entice someone to do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### lie in wait

"hide and wait for the right time"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]

### Proverbs 01:12

#### General Information:

Verses 12-14 end the imagined statement of the sinners who are trying to entice others to sin.

#### Let us swallow them up alive, like Sheol takes away those who are healthy

The sinners speak of murdering innocent people as if they were Sheol and they would take a living and healthy person down to the place where dead people go. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let us swallow ... like Sheol takes away

This speaks of the grave as if it were a person that swallows humans and takes them down to the place of the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### like Sheol takes away those who are healthy

The wicked expect to destroy their victims in the same way Sheol, the place of the dead, takes away even healthy people.

#### make them like those who fall into the pit

Possible meanings are 1) this refers to travelers who fall into a deep hole where no one will ever find them or 2) here "pit" is another word that means Sheol or the place where dead people go.

#### Throw in your lot with us

This is an idiom. AT: "Join us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### we will all have one purse together

Here "purse" represents everything that they steal. AT: "we will equally share everything that we steal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### purse

a bag for carrying money

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Proverbs 01:15

#### do not walk down that road with them; do not let your foot touch where they walk

To avoid behaving the same way as the sinners do is spoken of as if the son were to avoid walking on or even touching the roads that sinners walk on. AT: "do not go with the sinners or do what they do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their feet run to evil

The sinners having an eager interest in doing evil things is spoken of as if they were running to evil. AT: "they are eager to do wicked things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their feet run

Here "feet" represents the whole person. AT: "they run" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### to shed blood

Here "blood" represents a person's life. To "shed blood" means to murder someone. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### For it is useless to spread ... is watching

This begins a comparison that ends in 1:18. It compares the wisdom of birds who avoid traps that they see to the foolishness of sinners who get caught in traps they make for themselves.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### Proverbs 01:18

#### These men lie in wait to kill themselves—they set a trap for themselves

This finishes the comparison started in [Proverbs 1:17](./15.md). The men destroying themselves by doing sinful things is spoken of as if they set a trap and kill themselves. AT: "But these men are more foolish than the birds. They kill themselves with their own traps" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### So are the ways of everyone

A person's fate or destiny is spoken of as if it were a road a person walks on. AT: "This is what happens to everyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### unjust gain takes away the lives of those who hold on to it

A person destroying themselves by trying to gain wealth through violence, theft, and deceit is spoken of as if the unjust gains will kill those who take it. AT: "it is like the unjust gains will destroy those who hold on to it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 01:20

#### General Information:

In 1:20-1:33 Wisdom is spoken of as if it were a woman speaking to the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Wisdom cries aloud

If your language does not allow you to treat wisdom as a woman shouting to the people in the city, you might try something like "Grandmother Wisdom cries aloud" or "Honored Miss Wisdom cries aloud" or "Wisdom is like a woman who cries aloud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### raises her voice

This is an idiom. AT: "speaks with a loud voice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### in the open places

This means places where there would be a lot of people. AT: "in the markets" or "in the town squares" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### at the head of the noisy streets

Possible meanings are 1) "head" refers to the place where busy streets intersect or 2) "head" refers to the top of a wall where people on noisy streets could see and hear wisdom speaking.

#### How long, you naive people, will you love being naive?

Wisdom uses this question to rebuke those who are not wise. AT: "You who are naive must stop loving being naive." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### naive

inexperienced or immature

#### How long, you mockers, will you delight in mockery, and how long, you fools, will you hate knowledge?

Wisdom uses this question to rebuke the mockers and the fools. AT: "You who mock must stop delighting in mockery, and you fools must stop hating knowledge." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 01:23

#### General Information:

Wisdom continues to speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Pay attention

"Listen carefully"

#### I will pour out my thoughts to you

Wisdom telling the people everything she thinks about them is spoken of as if her thoughts were a liquid that she would pour out. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will make my words known to you

"I will tell you what I think"

#### I reached out with my hand

This phrase is an idiom that means to beckon someone or to invite a person to come. AT: "I invited you to come to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]

### Proverbs 01:26

#### General Information:

Wisdom continues to speak, describing what happens to those who ignore her.

#### I will laugh

This can be stated with the word "therefore" to show that the woman wisdom laughs at them because they ignored her. AT: "Therefore I will laugh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]])

#### at your calamity

"when bad things happen to you"

#### when the terror comes

The abstract noun "terror" can be stated as an adjective. AT: "when you are terrified" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### when your fearful dread comes like a storm ... like a whirlwind ... come upon you

Terrible things happening to the people is compared to a storm hitting them and causing fear and suffering. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### whirlwind

a very strong wind storm that causes damage

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]

### Proverbs 01:28

#### Connecting Statement:

Wisdom continues speaking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Then they will call upon me

"Then those who ignored me will cry out to me for help"

#### Because they hate knowledge

The abstract noun "knowledge" can be stated as the verb "learn." AT: "Because they refused to learn to be wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### did not choose the fear of Yahweh

The abstract noun "fear" can be stated as a verb. AT: "did not fear Yahweh" or "did not honor and respect Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### would not follow my instruction

"would not accept my instruction" or "rejected my advice"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]

### Proverbs 01:31

#### General Information:

Verse 33 ends wisdom's statement that began in [Proverbs 1:22](./20.md).

#### eat the fruit of their ways

Here a person's behavior is spoken of as if it were a way or road. Also, a person receiving the results of their behavior is spoken as if the person were eating the fruit of their behavior. AT: "experience the consequences of their actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### with the fruit of their schemes they will be filled

"they will eat the fruit of their schemes until they are full." A person receiving the results of their own evil plans is spoken of as eating the fruit of their schemes. AT: "they will suffer the consequences of their own evil plans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### naive

inexperienced or immature

#### are killed when they turn away

A person rejecting wisdom is spoken of as if the person physically turns away from wisdom. This can be stated in active form. AT: "die because they refuse to learn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the indifference of fools will destroy them

The abstract noun "indifference" can be stated as a verb. AT: "fools will die because they do not care about what should be done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### indifference

a lack of interest about something

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 01:intro

#### Proverbs 01 General Notes ####

####### Structure and formatting #######

The first chapter of proverbs begins with a type of introduction in verses 1-7. It mentions Solomon, son of David. Verse 7 contains a foundational verse for the whole book. It defines wisdom. 

####### Special concepts in this chapter #######

######## Parallelism ########

Proverbs are often written without any surrounding context and in two lines of text. Each line will have a certain relationship to the other line. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

##### Links: #####

* __[Proverbs 01:01 Notes](./01.md)__
* __[Proverbs intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Proverbs 02

### Proverbs 02:01

#### General Information:

A father teaches his child using poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### if you receive my words

"if you listen to what I am teaching you"

#### treasure up my commandments with you

Valuing what is commanded is spoken of as if the commandments were a treasure and the person were a safe place to store the treasure. AT: "consider my commands to be as valuable as a treasure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### make your ears pay attention

This is an idiom. AT: "force yourself to listen carefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### to wisdom

This abstract noun can be stated as an adjective. AT: "to the wise things I am teaching you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### incline your heart to understanding

Here "heart" represents a person's mind. The phrase "incline your heart" is an idiom that means to commit or fully dedicate one's mind to a task. AT: "try hard to understand what is wise" or "fully dedicate yourself to understanding wise teachings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 02:03

#### If you cry out for understanding and raise your voice for it

Both of these phrases have the same meaning. It is implied that the person is strongly asking Yahweh for understanding. AT: "If you urgently ask God and plead for understanding" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### raise your voice

This is an idiom that means to speak loudly or to shout. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### if you seek it like you would seek silver and search for understanding as you would seek hidden treasures

Both phrases have the same meaning. These similes emphasize the great effort a person should make to understand what is wise. AT: "if you seek understanding with as much effort as you search for a valuable object" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### you seek it ... search for understanding

Trying very hard to understand what is wise is spoken of as if understanding were an object for which a person must search. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will find the knowledge of God

To succeed in knowing God is spoken of as if the knowledge of God were an object that a person finds after searching. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Proverbs 02:06

#### from his mouth comes knowledge and understanding

Here "mouth" represents Yahweh himself or what he says. AT: "from Yahweh comes knowledge and understanding" or "Yahweh tells us what we need to know and understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### He stores up sound wisdom for those who please him

Yahweh teaching wisdom to people is spoken of as if wisdom were an item that Yahweh stores and gives to people. AT: "He teaches what is truly wise to those who please him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sound

"dependable"

#### he is a shield for those

Yahweh being able to protect his people is spoken of as if he were a shield. AT: "God protects those" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who walk in integrity

A person behaving with integrity is spoken of as if they were walking in integrity. AT: "who behave with integrity" or "who live their lives as they should" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he guards the paths of justice

Possible meanings are 1) justice itself is spoken of as if it were a path. AT: "God makes sure that people act justly" or 2) a person's life is spoken of as if it were a path. AT: "God protects those who act justly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### preserve the way of those

A person's life is spoken of as if it were a way or road. AT: "protect those" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Proverbs 02:09

#### equity

"fairness"

#### every good path

A behavior that is wise and pleases Yahweh is spoken of as if it were a good path. AT: "ways to live that are pleasing to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wisdom will come into your heart

Here "heart" represents a person's inner being. A person becoming wise is spoken of as if wisdom would enter into a person's heart. AT: "you will gain much wisdom" or "you will learn how to be truly wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### pleasant to your soul

Here "soul" represents the whole person. AT: "pleasing to you" or "enjoyable to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]

### Proverbs 02:11

#### Discretion will watch over you, understanding will guard you

This speaks of "discretion" and "understanding" as if they were persons who could watch over someone else. Both statements mean basically the same thing. AT: "Because you think carefully and understand what is right and wrong you will be safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Discretion

the quality of being careful in actions and speech

#### watch over

to guard, protect or take care of someone or something

#### They will rescue you from the way of evil

"They" refers to discretion and understanding, which are spoken of as if they were persons who could rescue someone else. AT: "You will know to stay away from what is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### from the way of evil

Evil behaviors are spoken of as if evil were a way or path on which a person walks. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who abandon the right paths and walk in the ways of darkness

A person no longer doing what is right but deciding to do what is evil is spoken of as if the person stops walking on the correct path and chooses to walk down a dark path. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who abandon

The word "who" refers to the people who speak perverse things.

#### abandon

to leave and never return to someone or something

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]

### Proverbs 02:14

#### They rejoice

"They" refers to the same people as in [Proverbs 2:12](./11.md).

#### delight in the perversities of evil

This means basically the same thing as the first part of the sentence. AT: "delight in doing what they know is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### They follow crooked paths

People who lie to others are spoken of as if they walk on crooked or twisted paths. AT: "They deceive other people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### using deception they hide their tracks

People lying so that others will not find out what they did is spoken of as if they covered the tracks on a path so that no one could follow them. AT: "they lie so that no one will know what they have done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Proverbs 02:16

#### General Information:

The father continues to teach his child how wisdom will protect him.

#### Wisdom and discretion will save you

The writer speaks of wisdom and discretion as if they were people who save the one who possesses them. AT: "If you have wisdom and discretion, you will save yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the companion of her youth

This refers to her husband, whom she married when she was young.

#### the covenant of her God

This likely refers to the marriage covenant that she made with her husband in the presence of God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Proverbs 02:18

#### her house leads down to death

Possible meanings are 1) "going to her house leads to death" or 2) "the road to her house is the road to death."

#### her tracks will lead you

Possible meanings are 1) "the paths to her house will lead you." This refers to the tracks or path that lead to her house, or 2) this is a metaphor that speaks of her way of life as if it were a path on which she walks. AT: "her way of life will lead you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to those in the grave

This refers to the spirits of dead people and is a metonym for the place of the dead. AT: "to the grave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### go in to her

This means to go into her house to sleep with her, as one would with a prostitute. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### they will not find the paths of life

Possible meanings are 1) "they will not return to the land of the living" or 2) "they will never live a happy life again."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 02:20

#### So

The writer tells the result of getting understanding and discretion.

#### you will walk in the way ... follow the paths

A person's conduct is spoken of as if it were walking on a path. AT: "you will live in the way ... follow the example" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the wicked will be cut off from the land

The writer speaks of Yahweh removing people from the land as if he were cutting the people off, like a person might cut a branch from a tree. This can be stated in active form. AT: "Yahweh will remove the wicked from the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the wicked ... the faithless

These are nominal adjectives that can be stated as adjectives. AT: "those who are wicked ... those who are faithless" or "wicked people ... faithless people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the faithless will be cut off from it

The writer speaks of Yahweh removing people from the land as if he were cutting the people off, like a person might cut a branch from a tree. This can be stated in active form. AT: "he will remove the faithless from it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md)]]

### Proverbs 02:intro

#### Proverbs 02 General Notes ####

####### Structure and formatting #######

Chapter 2 continues a collection of proverbs that ends in chapter nine. 

####### Special concepts in this chapter #######

######## My Son ########
Occasionally, the author addresses a proverb to "my son." This is not intended to restrict the words of that proverb to only males. Instead, it is simply a form used to pass on advice as a father does to his son. 

##### Links: #####

* __[Proverbs 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Proverbs 03

### Proverbs 03:01

#### General Information:

The writer speaks as a father teaching his child using poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### do not forget my commands

The word "commands" can be translated as a verb. AT: "do not forget what I command you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### keep my teachings in your heart

This phrase says in positive terms what the previous phrase says in negative terms. Here the word "heart" represents the mind. The word "teachings" can be translated as a verb. AT: "always remember what I teach you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### length of days and years of life

These two phrases share similar meanings and refer to living a long life. AT: "a long life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Proverbs 03:03

#### Do not let covenant faithfulness and trustworthiness ever leave you

The writer speaks of "covenant faithfulness" and "trustworthiness" as if they were people who could leave someone. The abstract nouns "faithfulness" and "trustworthiness" can be stated as "faithful" and "trustworthy." And, the negative command can be stated positively. AT: "Always be trustworthy and be faithful to the covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### tie them together about your neck

The writer speaks of faithfulness and trustworthiness as if they were objects that a person could tie around the neck like a necklace. The image suggests that these are valuable things that the person displays outwardly. AT: "display them proudly like one would wear a necklace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### write them on the tablet of your heart

Here the heart represents a person's mind. The mind is spoken of as if it were a tablet upon which someone can write messages and commands. AT: "always remember them, as if you had written them permanently on a tablet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the sight of God and man

Here sight represents judgment or evaluation. AT: "in the judgment of God and man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Proverbs 03:05

#### all your heart

Here the word "heart" represents the inner person. AT: "your whole being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### do not lean on your own understanding

The writer speaks of relying on one's own understanding as if "understanding" were an object on which a person can lean. AT: "do not rely on your own understanding" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in all your ways

The writer speaks of a person's actions as if they were paths on which the person walks. AT: "in everything you do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will make your paths straight

The writer speaks of Yahweh making a person's actions prosperous as if that person's actions were paths on which he walks and which Yahweh makes free of obstacles. AT: "he will give you success" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]

### Proverbs 03:07

#### Do not be wise in your own eyes

The writer speaks of a person's opinion as if that person were seeing something with his eyes. AT: "Do not be wise in your own opinion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### turn away from evil

The writer speaks of not committing evil actions as if it were turning away from evil. AT: "do not commit evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It will be healing to your flesh

The word "it" refers to the instructions that the writer gives in the previous verse. The full meaning of this can be made clear. The word "flesh" represents the whole body. AT: "If you do this, it will be healing for your body" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Proverbs 03:09

#### produce

"harvest"

#### your storehouses will be filled up

This can be stated in active form. AT: "your storehouses will be full" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### storehouses

buildings or rooms where food is stored

#### your vats will be bursting

your storage containers will be extremely full, as if ready to break open.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Proverbs 03:11

#### General Information:

The writer writes as a father teaching his son.

#### a son who pleases him

"a son in whom he delights." This refers to the father's affection for the son, and not to the father's approval of the son's behavior. AT: "a son whom he loves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Proverbs 03:13

#### The one who finds wisdom

The writer speaks of "wisdom" as if it were an object that one finds. AT: "The one who attains wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### what silver will give in return

This refers to the profit that one can make from trading or investing silver.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Proverbs 03:15

#### General Information:

The author speaks of wisdom as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### precious

"valuable" or "costly"

#### She has length of days in her right hand; in her left hand are riches and honor

The writer speak of the benefits that one gains from having wisdom as if wisdom were a woman who held these qualities in her hands and offered them to people. AT: "Wisdom gives a person length of days and riches and honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### length of days

This idiom refers to a long life. AT: "long life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 03:17

#### Her ways are ways of kindness and all her paths are peace

The writer speaks of wisdom as if it were a woman and of the benefits that wisdom gives a person as if wisdom were leading that person along a path. AT: "Wisdom will always treat you kindly and give you peace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She is a tree of life to those who take hold of it

The writer speaks of wisdom as if it were a tree that bears life-giving fruit and of a person who benefits from wisdom as if that person ate of the fruit. AT: "Wisdom is like a tree that sustains the life of those who eat of its fruit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a tree of life

"a tree that gives life" or "a tree whose fruit sustains life"

#### those who hold on to it

"those who hold on to its fruit"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 03:19

#### Yahweh founded the earth ... established the heavens

The writer speaks of Yahweh creating the earth and the heavens as if he were laying the foundation of a building. AT: "Yahweh created the earth ... made the heavens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the depths broke open

In ancient thought, water existed under the earth. This phrase refers to Yahweh causing that water to come out of the earth and make the oceans and rivers exist. AT: "he caused the rivers to flow" or "he caused the oceans to exist" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### dew

water that forms on the ground at night

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 03:21

#### do not lose sight of them

The writer speaks of not forgetting something as if it were always being able to see it. AT: "do not forget them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They will be life to your soul

Here the word "soul" represents the person. AT: "They will be life for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### an adornment of favor to wear around your neck

The writer speaks of "sound judgment" and "discernment" as if they were objects that a person could tie around the neck like a necklace. The image suggests that these are valuable things that the person displays outwardly. AT: "a display of favor like one would adorn themselves with a necklace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### adornment of favor

Possible meanings are 1) "a favorable adornment" or 2) "an adornment that displays Yahweh's favor."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]

### Proverbs 03:23

#### you will walk on your way in safety

The writer speaks of living one's life as if the person were walking along a path. AT: "you will live your life in safety" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your foot will not stumble

The word "foot" represents the whole person. The writer speaks of doing wrong as if a person stumbled over an object in his path. AT: "you will not do things that are wrong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### when you lie down

It is implied that a person lies down in order to sleep. The meaning of this can be made clear. AT: "when you lie down to sleep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### your sleep will be sweet

The writer speaks of sleep that is peaceful and refreshing as if it tasted sweet to the person sleeping. The word "sleep" can be translated as a verb. AT: "your sleep will be pleasant" or "you will sleep peacefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Proverbs 03:25

#### devastation caused by the wicked, when it comes

This can be stated in active form. AT: "when the wicked cause devastation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Yahweh will be on your side

"Yahweh will be by your side." A person standing by another person's side is an idiom that means that the one person will help and support the other. AT: "Yahweh will support and defend you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will keep your foot from being caught in a trap

The writer speaks of a person experiencing harm from "terror" and "devastation" as if the person were caught in a trap. The word "foot" represents the whole person. AT: "will protect you from those who want to harm you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devastated.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 03:27

#### Do not withhold good

"Do not withhold good things" or "Do not withhold good actions"

#### when it is in your power to act

"when you are able to help"

#### when you have the money with you

"when you have the money with you now." The meaning here is that the person has the money to help today, but tells his neighbor to come back tomorrow.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Proverbs 03:29

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]

### Proverbs 03:31

#### Do not ... choose any of his ways

It is implied that he is not to choose to imitate the actions of the violent person. AT: "Do not ... choose to imitate any of his ways" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the devious person is detestable to Yahweh

"Yahweh detests the devious person"

#### the devious person

the person who is dishonest or deceitful

#### he brings the upright person into his confidence

Yahweh shares his thoughts with the those who do right as with a close, trusted friend. AT: "Yahweh is a close friend to the upright" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Proverbs 03:33

#### The curse of Yahweh is on the house of the wicked person

The writer speaks of Yahweh's curse as if it were an object that he placed on top of the wicked person's house. The word "house" is a metonym for family. AT: "Yahweh has cursed the family of the wicked person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he blesses the home of righteous people

The word "home" represents the family. AT: "he blesses the families of righteous people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he gives his favor to humble people

The writer speaks of Yahweh's favor as if it were an object that he gives to people. AT: "he shows his favor to humble people" or "he is gracious to humble people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]

### Proverbs 03:35

#### Wise people inherit honor

The writer speaks of wise people obtaining a reputation of honor as if they inherited honor as a permanent possession. AT: "Wise people will obtain honor" or "Wise people will gain an honorable reputation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fools will be lifted up in their shame

The writer speaks of Yahweh making the shame of fools evident to everyone as if Yahweh were lifting fools up for everyone to see them. This can be stated in active form. AT: "Yahweh will cause everyone to see the shame of fools" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Proverbs 03:intro

#### Proverbs 03 General Notes ####

####### Structure and formatting #######

Chapter 3 continues a collection of proverbs that ends in chapter nine. 

####### Special concepts in this chapter #######

######## My Son ########
Occasionally, the author addresses a proverb to "my son." This is not intended to restrict the words of that proverb to only males. Instead, it is simply a form used to pass on advice as a father does to his son.

######## Wisdom is feminine ########

You may notice that wisdom is referenced using a feminine pronoun. This is a feature that is carried in from the Hebrew language. This may apply well in your language but if it does not, follow the conventions of your language. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]])

##### Links: #####

* __[Proverbs 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Proverbs 04

### Proverbs 04:01

#### General Information:

The writer speaks as a father teaching his children.

#### pay attention

"listen carefully"

#### you will know what understanding is

"you will know how to understand" or "you will gain understanding"

#### I am giving you good instructions

"What I am teaching you is good"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]

### Proverbs 04:03

#### When I was a son of my father

This refers to the time when the writer was a child still living under his father's care. AT: "When I was still a boy learning from my father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the tender and only child

Here the word "tender" refers to a young age at which the child is still weak. It forms a hendiadys with the word "only." AT: "the tender only child" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md)]])

#### Let your heart hold fast to my words

Here the word "heart" represents the person's mind. The writer speaks of remembering words as if the heart were holding on tightly to them. AT: "Always remember what I am teaching you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 04:05

#### General Information:

The father continues to teach his children what his father taught him.

#### Acquire wisdom

"Work hard to gain for yourself wisdom" or "Get wisdom"

#### do not forget

"remember"

#### do not reject

"accept"

#### the words of my mouth

Here the word "mouth" represents the person who speaks. AT: "what I am saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### do not abandon wisdom and she will watch over you; love her and she will keep you safe

The writer speaks of wisdom as if it were a woman who protects the person who is faithful to her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### do not abandon wisdom

This can be stated in positive form. AT: "hold tightly to wisdom" or "be faithful to wisdom"

#### love her

"love wisdom"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Proverbs 04:07

#### General Information:

The father finishes teaching his children what his father taught him.

#### spend all you own so you can get understanding

"value understanding more than all you own"

#### Cherish wisdom and she will exalt you

The writer speaks of wisdom as if it were a woman and of wisdom giving great honor to a person as if wisdom lifted that person to a high position. AT: "If you cherish wisdom, she will give you great honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Cherish

to feel or show great love for someone or something

#### she will honor you when you embrace her

The writer speaks of wisdom as if it were a woman and of a person valuing wisdom as if the person placed his arms around her. AT: "if you love wisdom greatly, wisdom will cause people to honor you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She will put a wreath of honor on your head

The writer speaks of the honor that a person will have from gaining wisdom as if wisdom placed a wreath upon that person's head. AT: "Wisdom will be like a wreath on your head that shows your great honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wreath

a woven circle made of leaves or flowers

#### she will give you a beautiful crown

The writer speaks of the honor that a person will have from gaining wisdom as if wisdom placed a crown upon that person's head. AT: "wisdom will be like a beautiful crown on your head" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]

### Proverbs 04:10

#### pay attention to my words

"listen carefully to what I teach you"

#### you will have many years in your life

"you will live many years"

#### I direct you in the way of wisdom; I lead you down straight paths

The writer speaks of teaching his son to live wisely as if he were leading his son along the paths where one may find wisdom. AT: "I am teaching you how to live wisely; I am explaining the right way to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### When you walk, no one will stand in your way and if you run, you will not stumble

These two lines share similar meanings. The writer speaks of the decisions and actions that a person makes as if that person were walking or running along a path and of the person being successful as if the path were free of obstacles that might make the person stumble. AT: "When you plan something, you will succeed in doing it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]

### Proverbs 04:13

#### Hold on to instruction, do not let it go

The writer speaks of a person remembering what he has learned as if "instruction" were an object that the person can hold tightly. AT: "Continue to obey what I have taught you and never forget it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for it is your life

The writer speaks of discipline preserving a person's life as if it were that person's life. AT: "for it will preserve your life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Do not follow the path of the wicked and do not go along the way of those who do evil

The writer speaks of a person's actions as if that person were walking along a path. AT: "Do not do what wicked people do and do not join in the actions of people who do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Avoid it

"Avoid the path of the wicked"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]

### Proverbs 04:16

#### they cannot sleep until they do evil

They probably could literally sleep, but the writer uses an exaggeration to express how intensely they desire to commit evil actions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### they are robbed of sleep

The writer speaks of people being unable to sleep as if sleep were an object that someone stole from them. They probably could literally sleep, but the writer uses an exaggeration to express how intensely they desire to commit evil actions. AT: "they are unable to sleep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### until they cause someone to stumble

The writer speaks of causing harm to another person as if it were causing that person to stumble. AT: "until they harm someone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they eat the bread of wickedness and drink the wine of violence

Possible meanings are 1) this is a metaphor in which the writer speaks of these people constantly committing wickedness and violence as if they ate and drank them like one would drink bread and wine. AT: "wickedness is like the bread that they eat and violence is like the wine that they drink" or 2) these people get their food and drink by committing wickedness and violence. AT: "they eat bread that they obtain by doing wicked things and drink wine that they obtain through violence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Proverbs 04:18

#### the path of righteous people ... The way of the wicked

The writer speaks of the actions and lifestyles of righteous people and wicked people as if they were a "path" or "way" upon which they walk. AT: "the lifestyle of righteous people ... The lifestyle of the wicked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the path of righteous people is like the first light that grows brighter

The writer compares the path of righteous people to the sunrise, meaning that they are safe because they have light to see where they are walking. AT: "righteous people walk along their path safely because the morning sun shines on it and grows brighter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the first light

This refers to the dawn or sunrise.

#### until the fullness of the day comes

This refers to the time of day at which the sun shines the brightest. AT: "until the sun shines most brightly" or "until full daylight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The way of the wicked is like darkness

The writer compares the way of wicked people to darkness, meaning that they are always in danger because they have no light to see where they are walking. AT: "Wicked people walk dangerously along their path because they have no light to be able to see" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they do not know what it is they stumble over

The writer speaks of experiencing harm as if it were stumbling over an object in the path along which the person walks. AT: "they do not know why they experience harm and misfortune" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]

### Proverbs 04:20

#### pay attention

"listen carefully"

#### incline your ear to my sayings

Here the word "ear" represents the person who is listening. The writer speaks of listening attentively to someone as if it were leaning forward so that the ear is closer to the one speaking. The word "sayings" can be translated as a verb. AT: "listen attentively to the things that I am saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Do not let them turn away from your eyes

The writer speaks of always thinking about something as if it were keeping it where one can see it. AT: "Do not stop thinking about them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### keep them in your heart

The writer speaks of remembering something as if it were keeping it within one's heart. AT: "always remember them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 04:22

#### my words are life

The writer speaks of his words preserving a person's life as if they were that person's life. AT: "my words give life" or "the things I say give life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to those who find them

The writer speaks of fully understanding his words as if the person searches for them and finds them. AT: "to those who understand and practice them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### health to their whole body

The word "their" refers to "those who find them." The subject for this phrase can be supplied from the previous phrase. AT: "my words will give health to the whole body of those who find them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Keep your heart safe and guard it

Here the word "heart" represents a person's mind and thoughts. AT: "Keep your mind safe and guard your thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with all diligence

with constant and earnest effort

#### from it flow the springs of life

The word "it" refers to the heart, which is a metonym for the mind and thoughts. The writer speaks of a person's life as if it were a flowing spring that originates from the heart. AT: "from your thoughts comes everything you say and do" or "your thoughts determine your course of life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]

### Proverbs 04:24

#### Put crooked speech away from you and put corrupt talk far from you

The writer speaks of lying or deceitful speech as if it were crooked and of a person not using this kind of language as if it were removing it far away from oneself. AT: "Do not lie and do not speak deceitfully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let your eyes look straight ahead and fix your gaze straight before you

Here the word "eyes" represents the person who is looking. The writer speaks of a person being committed to doing the right thing as if that person were constantly looking forward without turning his head to look in another direction. AT: "Always look straight ahead and fix your gaze straight before you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]

### Proverbs 04:26

#### Make a level path for your foot

Here the word "foot" represents the person who is walking. The writer speaks of a person's actions as if he were walking along a path, and of planning those actions carefully as if it were making that path level. AT: "Make a level path to walk on" or "Prepare well what you want to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a level path

"a smooth path" or "an even path"

#### then all your ways will be secure

The writer speaks of a person's actions as if the person were walking along a path and of those actions being successful as if the path were safe and secure. AT: "then everything that you do will be right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do not turn aside to the right or to the left

The directions "right" and "left" form a merism, meaning that the person is not to leave the level path in any direction. AT: "Walk straight ahead and do not leave the level path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### turn your foot away from evil

Here the word "foot" represents the person who walks. The writer speaks of not committing evil actions as if the person were walking away from evil. AT: "turn away from evil" or "stay away from evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 04:intro

#### Proverbs 04 General Notes ####

####### Structure and formatting #######

Chapter 4 continues a collection of proverbs that ends in chapter nine. 

####### Special concepts in this chapter #######

######## My Son ########
Occasionally, the author addresses a proverb to "my son." This is not intended to restrict the words of that proverb to only males. Instead, it is simply a form used to pass on advice as a father does to his son.

######## Wisdom is feminine ########

You may notice that wisdom is referenced using a feminine pronoun. This is a feature that is carried in from the Hebrew language. This may apply well in your language but if it does not, follow the conventions of your language. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]])
##### Links: #####

* __[Proverbs 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Proverbs 05

### Proverbs 05:01

#### General Information:

The writer speaks as a father teaching his children.

#### incline your ears

Here the word "ears" represents the person who is listening. The writer speaks of listening attentively to someone as if it were leaning forward so that the ears are closer to the one speaking. See how you translated this in [Proverbs 4:20](../04/20.md). AT: "listen attentively" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### discretion

Discretion is the quality of being careful with regard to one's actions and speech. See how you translated this in [Proverbs 1:4](../01/04.md).

#### your lips may protect knowledge

Here the word "lips" represents the person who speaks. The writer speaks of a person being careful only to say what is true as if the person's lips were protecting knowledge. AT: "you will speak only what is true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 05:03

#### the lips of an adulteress drip with honey

Possible meanings are 1) the word "lips" represents the words of the adulteress and the writer speaks of the attractiveness of her words as if her lips dripped with honey. AT: "the words of an adulteress are sweet, as if dripping with honey" or 2) the writer speaks of the allure of kissing the adulteress as if her lips dripped with honey. AT: "the kisses of an adulteress are sweet, as if her lips dripped with honey" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### her mouth is smoother than oil

Possible meanings are 1) the word "mouth" represents the speech of the adulteress and the writer speaks of the persuasiveness of her speech as if her mouth were smoother than olive oil. AT: "her speech is persuasive and smoother than olive oil" or 2) the writer speaks of the pleasure of kissing the adulteress as if her mouth were smoother than oil. AT: "her kisses are smoother than olive oil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but in the end she is as bitter as wormwood

The writer speaks of the harm that comes from having a relationship with an adulteress as if she tasted as bitter as wormwood. AT: "but in the end, she is like bitter-tasting wormwood and will cause you harm" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wormwood

a plant that tastes bitter

#### cutting like a sharp sword

The writer speaks of the pain that the adulteress will cause to the one who has a relationship with her as if she were a sharp weapon that cuts the person. AT: "she wounds a person, as if she were a sharp sword" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Proverbs 05:05

#### Her feet go down to death

Here "her feet" represent the adulteress as she walks. The writer speaks of her conduct as if she were walking along a path. AT: "She is walking along a path that leads to death" or "Her lifestyle leads to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### her steps go all the way to Sheol

The writer speaks of her conduct as if she were walking along a path. AT: "she walks all the way to Sheol" or "her conduct takes her all the way to Sheol" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She gives no thought to the path of life

The writer speaks of behavior that gives a person long life as if it were a path that leads to life. AT: "She does not think about walking along the path that leads to life" or "She is not concerned about conduct that leads to life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Her footsteps wander

Possible meanings are 1) "She wanders about as if she were lost" or 2) "She walks along the wrong path."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 05:07

#### Now

Here the teacher shifts from warning about the adulteress to giving advice.

#### listen to me ... do not turn away from listening

These two phrases express the same idea to make the student pay attention. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### do not turn away from listening

The writer speaks of stopping an action as if the person physically turned away from it. AT: "do not stop listening" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the words of my mouth

Here the word "mouth" represents the person who is speaking. AT: "my words" or "what I am saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Keep your path far away from her

Here the word "path" represents the person's daily conduct and circumstances. AT: "Keep yourself far away from her" or "Stay away from her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### do not come near the door of her house

Here "the door of her house" represents the house itself. It may be more appropriate to use the word "go" instead of "come" since the latter might imply that the speaker is at the door of her house. AT: "do not go near the door of her house" or "do not even go near her house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Proverbs 05:09

#### In that way

"If you do this." This phrase refers to what he has just said in previous verses.

#### you will not give away your honor to others

Possible meanings for the word "honor" are 1) it refers to one's reputation. AT: "You will not lose your good reputation among other people" or 2) it refers to one's wealth and possessions. AT: "You will not give away your wealth to other people" or 3) it refers to strength and represents the prime years of one's life. AT: "You will not give away the best times of your life to other people"

#### or years of your life to a cruel person

The writer speaks of a person dying prematurely, possibly by murder, as if the years of his life were items that he gives away to another person. The verb may be supplied from the previous phrase. AT: "or give years of your life to a cruel person" or "or cause a cruel person to kill you while you are still young" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a cruel person

This may refer to the husband of the adulteress, who will deal cruelly with the person who sleeps with her.

#### strangers will not feast on your wealth

The writer speaks of people taking and enjoying another person's wealth as if they were feasting on the wealth. AT: "strangers will not take all of your wealth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### what you have worked for will not go into the house of strangers

Here the word "house" represents the person's family. AT: "the things that you have obtained will not end up belonging to the families of strangers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Proverbs 05:11

#### your flesh and your body waste away

The words "flesh" and "body" mean basically the same thing and represent the whole person. AT: "your body wastes away" or "you waste away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### waste away

"physically wear down" or "become weak and unhealthy"

#### I hated instruction ... my heart despised correction

These two phrases express the same idea and emphasize how much this person disliked what the teacher had said. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### How I hated instruction

The word "How" is an exclamation that emphasizes the strength of his hatred. The word "instruction" can be translated with a verbal phrase. AT: "I hated it so much when someone would instruct me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### my heart despised correction

Here the word "heart" represents the person and his emotions. The word "correction" can be translated with a verbal phrase. AT: "I despised people when they corrected me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 05:13

#### incline my ear to my instructors

Here the word "ear" represents the person who is listening. The writer speaks of listening attentively to someone as if it were leaning forward so that the ear is closer to the one speaking. See how you translated a similar phrase in [Proverbs 4:20](../04/20.md). AT: "listen to those who instructed me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the midst of the assembly, among the gathering of the people

These two phrases mean basically the same thing and refer to the person's community that has gathered together either 1) to worship God or 2) to judge him for his offense. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Proverbs 05:15

#### water from your own cistern ... running water from your own well

These two phrases mean basically the same thing. The writer speaks of a man sleeping only with his wife as if he drank water only from his own cistern or well. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### running water

The writer speaks of fresh or flowing water as if the water were running. AT: "fresh water" or "flowing water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Should your springs ... your streams of water flow in the public squares?

The writer asks this rhetorical question to emphasize that his son should not do these things. AT: "Your springs should not ... your streams of water should not flow in the public squares." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Should your springs ... your streams of water flow in the public squares?

Here the words "springs" and "streams of water" are likely euphemisms for male reproductive fluids. Possible meanings for these metaphorical phrases are 1) sleeping with women other than one's wife is spoken of as if it were allowing one's water to flow in the public streets or 2) having children with women other than one's wife is spoken of as if it were allowing one's water to flow in the public streets. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### public squares

Open areas in a city or town where two or more streets meet. A common place for people to meet each other and talk.

#### Let them be

The word "them" refers to the "springs" and "streams of water" and what they stand for.

#### not for strangers with you

"do not share them with strangers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]

### Proverbs 05:18

#### May your fountain be blessed

The writer speaks of the son's wife as if she were a fountain. Here the word "blessed" refers to the sense of joy that the man has in his wife. AT: "May you always find joy with your wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the wife of your youth

Possible meanings are 1) "the wife whom you married when you were young" or 2) "your young wife."

#### she is a loving deer and a graceful doe

The writer speaks of the son's wife as if she were "a loving deer and a graceful doe." Here "deer" and "doe" mean a female deer. They were symbols of beauty both in their appearance and in their movements. AT: "she is as beautiful and graceful as a deer or a doe" or "she is as beautiful and graceful as a female deer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### graceful

This word does not mean "full of grace," but "beautiful while moving."

#### Let her breasts satisfy you

Possible meanings are 1) the wife's breasts excite the husband's sexual desire and possibly represent the wife's entire body. AT: "Let her breasts satisfy your desires" or "Let her body satisfy your desires" or 2) this is a metaphor in which the writer speaks of the wife's breasts satisfying the husband's desires as they would satisfy the thirst of a hungry baby. AT: "Let her breasts fill you with delight as a mother's breasts fill her child with food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### may you be continually intoxicated by her love

Intense excitement and joy from the romantic love of one's wife is spoken of as if he was drunk from that love. This can be stated in active form. AT: "let her love control you as alcohol controls someone who is drunk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by her love

Possible meanings are 1) "by your love for her" or 2) "by her love for you."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Proverbs 05:20

#### For why should you, my son, be captivated by an adulteress; why should you embrace the breasts of an immoral woman?

The writer asks these rhetorical questions to emphasize that his son must not do these things. AT: "My son, do not be captivated by an adulteress! Do not embrace the breasts of an immoral woman!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### be captivated by an adulteress

Intense excitement that arises from the desire for a woman is spoken of as if he were being held captive by that woman. This can be stated in active form. AT: "allow an adulteress to captivate you" or "allow an adulteress to fascinate you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### why should you embrace the breasts of an immoral woman

Here the word "breasts" represents the immoral woman and her sexual attractiveness. AT: "why should you embrace an immoral woman" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### an immoral woman

Possible meanings are 1) "a woman who is not your wife" or 2) "a woman who is another man's wife."

#### sees everything ... watches all the paths

These two phrases mean the same thing and emphasize that God knows everything that everyone does. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### all the paths he takes

The writer speaks of a person's actions or lifestyle as if it were a path on which the person walks. AT: "everywhere he goes" or "everything he does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 05:22

#### A wicked person will be seized by his own iniquities

The writer speaks of a wicked person being unable to avoid the consequences of his iniquities as if those iniquities were people who capture the wicked person. This can be stated in active form. AT: "A wicked person's own iniquities will seize him" or "A wicked person will be unable to avoid the consequences of his iniquities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the cords of his sin will hold him tight

The writer speaks of a wicked person being unable to avoid the consequences of his sin as if that sin were a trap made of cords in which the person is caught. AT: "because of his sin, he will be like an animal caught in a trap" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he is led astray by his great foolishness

This can be stated in active form. AT: "his great foolishness leads him astray" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by his great foolishness

"because he is very foolish"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 05:intro

#### Proverbs 05 General Notes ####

####### Structure and formatting #######

Chapter 5 continues a collection of proverbs that ends in chapter nine. 

####### Special concepts in this chapter #######

######## My Son ########
Occasionally, the author addresses a proverb to "my son." This is not intended to restrict the words of that proverb to only males. Instead, it is simply a form used to pass on advice as a father does to his son.

######## Adulteress ########

This chapter is unusual because it holds a theme about the adulteress and warns the young man to avoid her. An adulteress is a woman who commits adultery. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]])

##### Links: #####

* __[Proverbs 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Proverbs 06

### Proverbs 06:01

#### set aside your money

Implied here is that your promise and the circumstances forced you to save up your money. AT: "had to save up some of your money" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a guarantee for your neighbor's loan

Possible meanings are 1) your neighbor may come to you to ask for a loan or 2) your neighbor wants to take out a loan from someone else, but you promise to pay the lender back if your neighbor cannot.

#### neighbor

This same Hebrew word can also mean "friend."

#### you have laid a trap for yourself

This is a figure of speech saying that you are going to trap yourself. AT: "you have made a trap in which you yourself are caught" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the words of your mouth

"what you said" or "what you promised to do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Proverbs 06:03

#### save yourself

"protect yourself" or "help yourself out of these problems"

#### you have fallen into the hand of your neighbor

This is a figure of speech using the term "hand" to mean "harm." AT: "your neighbor can bring harm to you if he wants to" or "your neighbor has power over you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### neighbor

"friend"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]

### Proverbs 06:04

#### Give your eyes no sleep and your eyelids no slumber

"Do not let your eyes sleep; do not let your eyelids slumber." These two phrases mean the same thing and are repeated to emphasize how important it is not to be lazy. It is also stated negatively for even more emphasis. AT: "Stay awake, and do what you can" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### your eyes ... your eyelids

This is a figure of speech using parts of your face to mean your whole body. AT: "yourself ... yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Save yourself like a gazelle from the hand of the hunter

"Escape from your neighbor like a gazelle that flees from a hunter"

#### gazelle

This is a big, lean animal that eats grass and that people often hunt for meat. It is famous for running away quickly.

#### from the hand of the hunter

The hand of the hunter refers to the hunter's control. AT: "from the control of the hunter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### like a bird from the hand of the fowler

"and escape like a bird that flies away from a bird-hunter"

### Proverbs 06:06

#### Look at ... consider

"Study ... think about" or "carefully observe ... ponder"

#### ant

An ant is a small insect that lives underground or in a self-built hill. They usually live in groups of thousands, and they can lift things that are much bigger than they are.

#### consider her ways

This is a figure of speech using the "ways" of an ant to refer to the behavior of the ant. AT: "consider how the ant behaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### commander, officer, or ruler

These three words mean basically the same thing and are used to emphasized that no one has formal authority over an individual ant. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### it prepares its food in the summer ... during the harvest it stores up what it will eat

These two phrases mean basically the same thing and are repeated to show how responsible the ant is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### summer

Summer is the time of the year when some trees bear their fruit.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Proverbs 06:09

#### How long will you sleep ... When will you rise from your sleep?

The teacher uses these questions to scold the lazy person for sleeping too much. AT: "Wake up, you lazy person! Get out of your bed!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### A little sleep ... of the hands to rest

These are the kinds of things that lazy people say.

#### A little sleep, a little slumber

Both of these statements mean the same thing. They can be stated as complete sentences. AT: "I will just sleep a little longer. Let me sleep lightly a little longer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### folding of the hands to rest

People often fold their hands while reclining in order to rest more comfortably. AT: "I will just cross my arms comfortably and rest a little" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### and your poverty will come

This can be stated as a new sentence to make clear that this is a result of being lazy. AT: "If you continue to be lazy, your poverty will come" or "While you sleep, poverty will come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### your poverty will come like a robber

The sudden way a lazy person becomes poor is like the sudden way a robber comes and steals things. AT: "you will suddenly become poor, just as if a robber came and stole everything you have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### and your needs like an armed soldier

The sudden way a lazy person becomes in need of things is like the sudden way an armed soldier takes things from a person. This can be stated as a complete sentence. AT: "and your needs will come to you like an armed soldier" or "and you will become needy just as if an armed soldier stole all your things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### an armed soldier

"a soldier who is holding a weapon" or "a man with a weapon"

### Proverbs 06:12

#### A worthless person—a wicked man

These two words have the same meaning and emphasize how bad this person is. AT: "A person with no value—an evil man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### lives by the crookedness of his speech

Here lies are spoken of as speech that is crooked. AT: "constantly tells lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### winking his eyes, making signals with his feet and pointing with his fingers

All three of these phrases describe a way in which the evil person communicates secretly to deceive other people.

#### winking his eyes

If someone winks, he closes one eye very briefly as a secret signal to another person. This might be a sign of trust, of approval, or of something else.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 06:14

#### He plots evil

"He plans evil" or "He prepares to do evil deeds"

#### he always stirs up discord

"he always causes discord" or "he is constantly looking for conflict and escalating it"

#### Therefore

"For that reason"

#### his disaster will overtake him

This implies that the disaster is chasing him like a person or an animal, and that it will catch him soon. AT: "his disaster will catch him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### his disaster

This refers to the disaster that will happen to him, but also the disaster that he himself caused.

#### in an instant; in a moment

Both mean the same thing, and one or both of them can be replaced by "suddenly" or "very quickly."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 06:16

#### six things that Yahweh hates, seven that

This whole verse is a parallelism that emphasizes that God hates several things and not just one. AT: "six things that Yahwah hates; seven things that" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### that are disgusting to him

"that make him feel disgust" or "that make you disgusting according to him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 06:17

#### Connecting Statement:

This is the list of things that Yahweh hates that was introduced in [Proverbs 6:16](./16.md).

#### eyes ... tongue ... hands ... heart ... feet

All of these body parts refer to a whole person. You can translate each of these with "people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### shed the blood of

"kill" or "murder"

#### wicked schemes

"evil plans"

#### breathes out lies

This figure of speech uses "breathes" to refer to lying constantly. AT: "constantly lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### discord

See how you translated this in [Proverbs 6:14](./14.md).

#### one who sows discord

This figure of speech is using "sows" to refer to causing or bringing about discord. AT: "a person who causes discord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]

### Proverbs 06:20

#### obey the command of your father ... do not forsake the teaching of your mother

These two phrases on the one hand mean the same thing. On the other hand, the repeated emphasis on both "father" and "mother" explicitly includes women in the whole teaching-learning process. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### do not forsake the teaching of your mother

This figure of speech is using the negative "forsake" to mean the positive "obey." AT: "obey the teaching of your mother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### bind them on your heart; tie them about your neck

These two phrases mean basically the same thing. They describe the commands and instructions as if they are written down so that you can put it in or on your body to remind yourself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bind them on your heart

"love them" or "think about them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 06:22

#### When you walk ... when you sleep ... when you wake up

These three phrases are used together to emphasize that the lessons are valuable all the time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### they will guide you ... they will watch over you ... they will teach you

The repetition of these phrases is to show that the lessons are valuable for all sorts of things. It also speaks of those lessons as if they were people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the commands ... the teaching ... the corrections that come by instruction

These three phrases mean basically the same thing, and together they show the various types of lessons a father and a mother teach. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### a lamp ... a light ... the way of life

All three of these mean basically the same thing and are repeated to emphasize the fact that the lessons make life better and easier. AT: "as useful as a lamp ... as helpful as light in the darkness ... as necessary to follow as the way of life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the way of life

"the way that leads to life" or "the way of living that God approves of"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 06:24

#### It keeps you from

Here the word "it" refers to the lessons taught by the father and mother in [Proverbs 6:20](./20.md). AT: "It saves you from" or "It protects you from" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### the immoral woman ... an immoral woman

These two words mean basically the same thing. See how you translated the word "adulteress" in [Proverbs 5:3](../05/03.md).

#### immoral

"morally evil"

#### in your heart

Here "heart" represents the mind. AT: "in your thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### her beauty

"what is beautiful about her." This can also be a metonym for the woman. AT: "her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### capture

"gain control over"

#### her eyelashes

The "eyelashes" stand for the beautiful things about her body that she uses to catch a man's attention. AT: "her beautiful eyes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 06:26

#### the price of a loaf of bread

This is talking about the material cost, not the spiritual cost or the moral cost. AT: "a little bit"

#### may cost you your very life

Possible meanings are 1) the wife of another man will destroy your life because she always wants more or 2) the husband of the other woman will hunt you down and kill you.

#### Can a man carry a fire against his chest without burning his clothes?

This action would be very dangerous and would cause harm. The implied answer to the question is "no." AT: "Every man who carries a fire in his chest will burn his clothes." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### without burning

"without destroying" or "and not destroy"

#### his clothes

His clothes stand for him as a whole person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 06:28

#### Can a man walk on hot coals without scorching his feet?

Walking on hot coals will scorch a person's feet, so the implied answer is "no." AT: "Every man who walks on hot coals will have scorched feet." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### walk on hot coals

This stands for committing adultery. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### walk

That is to slowly walk a long distance, without using tricks or magic.

#### scorching

"burning"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Proverbs 06:30

#### despise a thief

"do not regard a thief with contempt" or "do not think a thief is evil"

#### if he is caught

This can be stated in active form. AT: "if someone catches him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in his house

This figure of speech is saying that everything in his house is all that he owns. AT: "that he owns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md)]]

### Proverbs 06:32

#### The one

"The person" or "The man"

#### what he deserves

"the appropriate punishment for what he has done"

#### his disgrace

This figure of speech is using the term "disgrace" to refer to the feeling of him acting shamefully. AT: "the memory of his shameful act" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will not be wiped away

This figure of speech is using the negative "will not be wiped away" to refer to it always being there. AT: "will always remain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Proverbs 06:34

#### furious

"very angry"

#### he will show no mercy

The "he" is the neighbor whose wife has committed adultery with another man. AT: "he will not limit the pain he will cause you" or "he will hurt you as much as he can" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### when he takes his revenge

"in the moment of his revenge" or "when the moment arrives when he can take his revenge"

#### takes his revenge

If a person takes revenge, it is to cause hurt to the person who hurt him first.

#### compensation

"payment"

#### he cannot be bought off

This can be stated in active form. AT: "you cannot pay him enough money to change his mind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### off, though

"off. This will be true even if"

#### offer

"give" or "promise"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]

### Proverbs 06:intro

#### Proverbs 06 General Notes ####

####### Structure and formatting #######

Chapter 6 continues a collection of proverbs that ends in chapter nine. 

####### Special concepts in this chapter #######

######## My Son ########

Occasionally, the author addresses a proverb to "my son." This is not intended to restrict the words of that proverb to only males. Instead, it is simply a form used to pass on advice as a father does to his son. 

######## Adulteress ########

The latter part of this chapter comes back to the theme about the adulteress and warns the young man to avoid her. An adulteress is a woman who commits adultery. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]])

######## Numbers ########

Occasionally, the author will mention a list of six things, or seven things, that Yahweh hates. These numbers are used to draw attention to the list of things. It is not important whether there are six or seven things in the list. 

####### Important figures of speech in this chapter #######

######## Rhetorical questions ########

The author will use rhetorical questions to draw the reader's attention to important points. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

####### Other possible translation difficulties in this chapter #######

######## Animals used as types ########

The gazelle and the ant have certain characteristics which the author uses to give wisdom. If your language does not recognize these characteristics in those animals, you could add a footnote to explain or possibly substitute another animal from your culture that would help explain the same concept. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]])

##### Links: #####

* __[Proverbs 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Proverbs 07

### Proverbs 07:01

#### keep my words

Here keeping represents obeying. AT: "obey my words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### store up my commands within yourself

Here God's commands are spoken of as if they were objects that someone could put into a storeroom. AT: "memorize my commands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### keep my instruction

Here keeping represents obeying. AT: "obey my instructions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### as the apple of your eye

The apple of the eye is the pupil inside the eye, which people normally instinctively protect when an object flies at their face. Here "the apple of the eye" represents whatever a person values and protects the most. AT: "as your most valuable possession" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Tie them on your fingers

Possible meanings are 1) that the writer wanted his son to engrave certain commands from God on a ring and wear it, or 2) that the writer wanted his son to always remember God's commands, as if he always wore a certain ring. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### write them on the tablet of your heart

Here the heart represents a person's mind, and remembering something well is spoken of as if the person were writing it on a stone tablet. See how you translated this in [Proverbs 3:3](../03/03.md). AT: "remember my commands well as if you were writing them in stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 07:04

#### Say to wisdom, "You are my sister

Here wisdom is spoken of as if it were a person. AT: "Value wisdom as you would love your sister" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### call understanding your kinsman

Here the quality of understanding is spoken of as if it were a kinsman or relative. AT: "treat understanding as you would treat your kinsman" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### kinsman

"relative" or "family member"

#### the adulterous woman

This refers to any woman to whom a man is not married. AT: "the woman whom you should have nothing to do with"

#### the immoral woman

This refers to any woman who is not known to a man.

#### with her smooth words

Words intended to deceive are spoken of as if they were smooth objects. AT: "who says pleasant things, but wants to deceive you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Proverbs 07:06

#### lattice

a covering over a window made of thin strips of wood that cross one another in a slanted pattern that forms square-shaped openings in the pattern

#### naive

inexperienced or immature

### Proverbs 07:08

#### her corner

Here "her" refers to any female stranger, as referred to in [Proverbs 07:05](./04.md). She was standing at a certain corner, waiting for a suitable man to pass by. AT: "the corner where a female stranger was standing"

#### corner

This refers to where two roads meet.

#### twilight

the time of day when it is getting darker and about to become night

### Proverbs 07:10

#### with a false heart

Here "heart" represents intentions or plans. AT: "she planned to deceive someone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She was loud and wayward

"She talked loudly and acted in the ways she wished to"

#### her feet did not stay at home

The phrase "her feet" represent the woman. AT: "she did not stay at home" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### she waited in ambush

Here the woman is spoken of as if she were preparing to physically trap a person or an animal. Also, the idea of trapping someone here represents persuading someone to commit sin. AT: "she waited to trap someone" or "she waited to find someone she could persuade to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]

### Proverbs 07:13

#### she

"She" refers to the woman that was introduced in [Proverbs 7:10](./10.md).

#### grabbed him

"took hold of him firmly"

#### with a strong face

Here "strong" represents "stubborn." A "strong face" means a stubborn expression on a person's face. This implies that the woman is acting in a stubborn way, that she is deliberately doing what she knows is wrong. AT: "with a shameless expression on her face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I paid my vows

Here "vows" represents what the person promised to sacrifice to God. AT: "I made the sacrifices I promised to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### seek your face

Here "face" represents the person and especially the person's presence. AT: "look for you" or "find out where you are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]

### Proverbs 07:16

#### sprinkled my bed with

"scattered on my bed"

#### aloes

A type of wood from a tree that smells good.

#### cinnamon

This is a spice made from the bark of a tree that smells and tastes good.

#### let us drink our fill of love

Here the pleasures of romantic love are spoken of as if they were something good to drink. AT: "let us make love to each other as much as we want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]

### Proverbs 07:19

#### is not at his house

"is not at home"

#### full moon

The moon is said to be full when it is a perfectly round disk, shining at its brightest.

#### she turned him

To persuade someone to act in a certain way is spoken of as if it were changing the direction that person was walking. AT: "she persuaded him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### her ... she ... him

The female is the married woman who wants to sleep with "him," the young man.

#### smooth lips

Here "lips" represents what a person says. When a person flatters someone else by saying things that are not sincere, these words are spoken of as if they were a smooth object. AT: "flattering, deceiving words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### she misled him

"she persuaded him to do something evil" AT: "she convinced him to sin with her"

### Proverbs 07:22

#### He went after her suddenly

This seems to imply that the young man took very little time to think about what he should do. AT: "He quickly decided to go after her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### like an ox going ... into a snare

The naive and unsuspecting way the young man follows the adulteress is compared to the way three animals are unaware of the danger they are in. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### slaughter

This refers to killing an animal in order to eat its meat.

#### deer

See how you translated this word in [Proverbs 5:19](../05/18.md).

#### until an arrow pierces through its liver

This passage implies that a hunter has trapped the deer in order to shoot it with arrows. AT: "until a hunter shoots it in its most important part" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### liver

Here this organ represents a very important part of the deer's body.

#### it would cost his life

This is a way of saying that this person will die as a result. AT: "it would kill him" or "he would die soon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 07:24

#### Now

This is to focus the attention of the speaker's sons on the conclusion of this lesson.

#### May your heart not turn aside onto her paths

Here "ways" means the paths that a person chooses to walk on. It represents the person's behavior, the things that he decides to do in life. AT: "Make your heart stay far away from the ways of the adulterous woman" or "Do not let your heart want to do the things that the adulterous woman does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your heart

Here "heart" represents a person, emphasizing his desires. AT: "you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### do not be led astray onto her paths

This means the same as the sentence before it. It strengthens the first warning. AT: "do not leave the right path in order to go on her paths" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]

### Proverbs 07:26

#### She has caused many people to fall down pierced

Being pierced by spears or arrows represents being killed. AT: "She has caused many people to fall dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Her house is on the paths to Sheol ... they go down

Here "paths" represents the kinds of behavior that foolish people participate in. Sheol was the name for the world of the dead.

#### on the paths to Sheol ... down to the dark bedrooms of death

These two phrases basically mean the same thing and are repeated to emphasize that the woman's victims will be destroyed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the dark bedrooms of death

This expression pictures the dead as sleeping in many different rooms in Sheol. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 07:intro

#### Proverbs 07 General Notes ####

####### Structure and formatting #######

Chapter 7 continues a collection of proverbs that ends in chapter nine. 

####### Special concepts in this chapter #######

######## Parallelism ########

Proverbs are often written without any surrounding context and in two lines of text. Each line will have a certain relationship to the other line. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

Many of the proverbs are stated as promises or commands, but they are intended to be advice. 

######## My Son ########

Occasionally the author addresses a proverb to "my son." This is not intended to restrict the words of that proverb to only males, but is still given in the context of a father warning his son. 

######## Adulteress ########

This chapter continues the theme about the adulteress and warns the young man to avoid her.
##### Links: #####

* __[Proverbs 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Proverbs 08

### Proverbs 08:01

#### General Information:

In chapter 8 wisdom is spoken of as a woman who teaches people how to be wise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### General Information:

Many verses in chapter 8 have parallelisms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Does not Wisdom call out?

This question is used to remind the readers of something they should already know. AT: "Wisdom calls out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Does not Wisdom call out?

Here wisdom is imagined as a woman. If a language does not allow this kind of metaphor, other possible translations are: 1) "Is not wisdom like a woman who calls out?" 2) "Does not a woman named Wisdom call out?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Does not Understanding raise her voice?

Here "Understanding" means the same as "Wisdom." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the gates at the entrance into the city

In ancient times, cities usually had outer walls with gates in them.

#### she calls out

This continues to refer to Wisdom, personified as a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Proverbs 08:04

#### General Information:

Wisdom speaks to the people in verses 4-36.

#### my voice is for the sons of mankind

Here "voice" represents the words that are spoken. AT: "my words are for the sons of mankind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the sons of mankind

This is metonymy representing all human beings. AT: "all people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### naive

inexperienced or immature

#### learn wisdom

The abstract word "wisdom' refers to what a wise person believes and to the way in which he acts. AT: "learn how a wise person acts" or "learn what it means to be wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### you must get an understanding mind

"you must begin to understand things with your mind"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 08:06

#### when my lips open

Here "lips" represents a person's mouth, with which he speaks. AT: "when I open my mouth to speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### upright

"proper" or "just"

#### my mouth speaks

Here "mouth" represents a person who speaks. AT: "I speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### what is trustworthy

"what people should believe"

#### wickedness is disgusting to my lips

Here "lips" represents a person who is speaking. AT: "wickedness is disgusting to me" or "saying wicked things would be disgusting to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### wickedness

Here the abstract noun "wickedness" represents wicked speech. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 08:08

#### the words of my mouth

The "mouth" stands for the person who is speaking. AT: "The things I teach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### twisted

"false"

#### straight

"honest and clear"

#### my words are upright for those who find knowledge

This probably means that those who find knowledge will easily understand that the speaker's words are upright. Here "words" represent a message or teaching. AT: "those who know what is right and what is wrong consider what I teach to be right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### upright

"honest"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]

### Proverbs 08:10

#### Acquire my instruction rather than silver

"You should try much harder to understand my instructions than to get silver"

#### For Wisdom is better than jewels; no treasure is equal to her

Here Wisdom, personified as a woman, is not speaking. However, it is possible to make Wisdom the speaker here as well. AT: "For I, Wisdom, am better than jewels; no treasure is equal to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 08:12

#### I, Wisdom, live with Prudence

Prudence is also represented here as a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Prudence

caution or good judgment

#### I possess knowledge and discretion

The abstract ideas "knowledge" and "discrete" can be expressed in other ways. AT: "I am knowledgeable and discreet" or "I know many things, and I am careful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### discretion

being careful about what we say and do; being cautious not to cause hurt or harm to others

#### perverted speech

"wicked talk"

#### perverted

turned from what is right

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md)]]

### Proverbs 08:14

#### good advice

"wise suggestions"

#### advice

counsel that is given to help someone

#### sound

good, reliable

#### I am insight

Here Wisdom is spoken of as if she were insight. AT: "I have insight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### nobles

noblemen, leading members of important families in the nation

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Proverbs 08:17

#### love

This refers to brotherly love or love for a friend or family member. This is natural human love between friends or relatives.

#### diligently

with careful and continued effort

#### With me are riches and honor

"I have riches and honor"

#### lasting wealth and righteousness

This explains what is meant by "riches and honor." This can be made clear with the connecting statement "therefore." AT: "therefore, I will give lasting wealth and righteousness to those who find me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]])

#### righteousness

"the ability to live in a right way"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Proverbs 08:19

#### My fruit

what wisdom produces or causes

#### my produce

the benefit or gain that wisdom causes

#### I walk in the path of righteousness

Living the right way is spoken of as walking on the right road. AT: "I live right" or "I do what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the midst of the paths of justice

This tells more of what is meant by "the path of righteousness." AT: "I do what is perfectly just" or "I only do what is just" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### treasuries

storehouses for valuable things. Wisdom is spoken of as a woman who fills the storehouses of her followers with valuable things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Proverbs 08:22

#### the first of his deeds then

"I was the first of the things he created then"

#### In ages long ago

"Very long ago"

#### ages

The word "age" refers to a general, extended period of time.

#### I was made

This can be put into active form. AT: "God made me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from the beginnings of the earth

The idea of beginnings can be translated in a less abstract way. AT: "from when God created the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Proverbs 08:24

#### General Information:

Wisdom continues to speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Before the mountains were settled

"Before the bases of the mountains were put into place." This can also be put into active form. AT: "Before God made the foundations of the mountains and put them into their proper places" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Proverbs 08:26

#### I was born ... I was there

This is wisdom speaking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### was born

"I was alive"

#### established

To establish something is to bring into being on a stable basis. AT: "created" or "made"

#### when he drew a circle on the surface of the deep

This refers to setting a limit to how far someone in a ship at sea can see all around himself. AT: "when he marked on the ocean's surface how far a person at sea can see in every direction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the deep

"the ocean"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Proverbs 08:28

#### General Information:

Wisdom continues to speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### established

brought into permanent being

#### when the springs in the deep became fixed

This can be put into active form. AT: "when God fixed the springs in the deep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the springs in the deep

The ancient Hebrews thought that the ocean got its water from springs at the bottom of the sea.

#### when he made his limit for the sea

"when he created the shorelines for the oceans. The "limit for the sea" divided the oceans from the dry land.

#### when there was set the limit for the foundations of the dry land

The Hebrew word for "earth" also often means "land."

#### when there was set the limit for the foundations of the dry land

This can be put into active form. AT: "when God set the limit for the foundations of the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Proverbs 08:30

#### I was beside him

This is still wisdom speaking. Wisdom now says she was right next to Yahweh, implying that she was his assistant in creating the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### skilled craftsman

This is a person who has trained for years to make useful things very well, like furniture or houses.

#### delight

"source of joy" or "reason to be glad"

#### day after day

This is a way to express the idea of a habitual action or of a continuous condition. AT: "continually" or "the whole time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### his whole world

"the whole world he created" or "everything he created"

#### the sons of mankind

This refers to human beings in general. AT: "the people he brought into existence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/delight.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/delight.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Proverbs 08:32

#### Now

This is to focus the attention of the children to the conclusion of this lesson.

#### listen to me

This is still wisdom talking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### those who keep my ways

Here "my ways" represents wisdom's behavior. AT: "those who do what I teach" or "the people who follow my example" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### do not neglect

"do not disregard" AT: "be sure to pay attention to" or "be sure to follow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### watching every day at my doors, waiting beside the posts of my doors

These two phrases basically mean the same thing. Wisdom is described as having a home; possible meanings of "watching" are 1) a wise person waits outside wisdom's home in the morning in order to serve her, or 2) a wise person waits outside wisdom's house for her to come and teach him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 08:35

#### finds me ... hate me

This is still wisdom talking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### he who fails

The complete thought is, "he who fails to find me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### his own life

Here "life" represents the person's self. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 08:intro

#### Proverbs 08 General Notes ####

####### Structure and formatting #######

Chapter 8 continues a collection of proverbs that ends in chapter nine. These chapters operate more as a unit then many of the following chapters in this book. 

####### Special concepts in this chapter #######

######## Wisdom calls out ########

The addressee of this chapter is broader than "my son," but is personal like the previous chapters' use of "my son." In this case, Wisdom is calling out for all to come and learn of her, in contrast to the adulteress mentioned in chapters 5-7. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]])

##### Links: #####

* __[Proverbs 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Proverbs 09

### Proverbs 09:01

#### General Information:

These verses begin a parable in which wisdom is imagined to be a woman who is giving good advice to people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Wisdom has built

The writer speaks about wisdom as if it were a woman who has built her own house. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### She has slaughtered her animals

This refers to animals whose meat will be eaten in the dinner that Wisdom will give. AT: "She has killed the animals for meat at dinner" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### mixed her wine

In ancient Israel, people often mixed wine with water. AT: "prepared her wine by mixing it with water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### she has set her table

"she has prepared her table"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Proverbs 09:03

#### General Information:

These verses begin to give the message of Wisdom, who is personified as a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### She has sent out her maids

These maids went out and invited people to come to the feast that Wisdom had prepared.

#### her maids

Young women or girls who are in the service of a respectable, adult woman, such as Wisdom.

#### she calls out

"she proclaims" or "she summons" AT: "she loudly recites her invitation"

#### the highest points of the city

The invitation is shouted from the highest points so that it will be best heard by all the people.

#### Who is naive? Let ... the one lacking good sense

These two phrases describe the same group of people, those who need more wisdom in their lives. Here the question is addressed to all such people. AT: "Anyone who is naive, let ... anyone lacking good sense"

#### is naive

"is inexperienced or immature"

#### turn aside here

"leave his path and come into my house"

### Proverbs 09:05

#### General Information:

These verses continue the message of Wisdom.

#### Come ... eat ... drink ... Leave ... live ... walk

All of these commands are plural; Wisdom is addressing many people at the same time.

#### the wine I have mixed

In ancient Israel, people often mixed wine with water. AT: "prepared her wine by mixing it with water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Leave your naive actions

Here naive actions are spoken of as if they were a place that a person could leave. AT: "Stop your naive behavior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### naive actions

"inexperienced, immature actions"

#### the path of understanding

Here the process of understanding wisdom is spoken of as if it were a path that a person could follow. AT: "the manner of living that a wise person has" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 09:07

#### General Information:

These verses continue the message of Wisdom.

#### Whoever disciplines ... whoever rebukes

These two phrases basically say the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### a mocker

Someone who habitually mocks people. AT: "someone who says insulting things about other people" or "someone who likes to make other people look bad"

#### receives abuse

"receives harsh treatment"

#### whoever rebukes

"whoever corrects"

#### Do not reprove

"Do not correct"

#### Give to a wise person, and he ... teach a righteous person, and he

These two commands actually represent conditional statements. AT: "If you give to a wise person, he ... if you teach a righteous person, he"

#### Give to a wise person ... teach a righteous person

These two phrases basically say the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Give to a wise person

This refers to giving instruction to a wise person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Proverbs 09:10

#### General Information:

These verses finish the message of Wisdom.

#### The fear of Yahweh

See how you translated this phrase in [Proverbs 1:7](../01/07.md).

#### through me your days will be multiplied

This may be put into active form. AT: "I will multiply your days" or "I will cause you to live many more days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### through me

Wisdom, personified as a woman, continues to speak here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### your days will be multiplied, and years of life will be added to you

These two phrases basically mean the same thing and are used to emphasize the great benefits wisdom has. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### years of life will be added to you

Wisdom speaks of years of life as if they were physical objects. This can be stated in active form. AT: "I will add years of life to you" or "I will add years to your life" or "I will enable you to live longer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### If you are wise ... and if you mock

These two statements seem to mean that wise people gain advantages for themselves because of their wisdom, and mockers suffer because of their behavior.

#### you will carry it

This speaks of the consequence of one's bad behavior as if it were a heavy load that one had to carry on his back. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]

### Proverbs 09:13

#### General Information:

These verses begin to describe foolishness, which is also personified as a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The woman of foolishness

It is possible to translate "foolishness" as a description such as "A foolish woman." However, if a language allows wisdom to be personified, as in the previous part of this chapter, it may also allow foolishness to be personified. AT: "The woman Foolishness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### she is untaught and knows nothing

These two expressions basically mean the same thing, which is repeated to show how useless the foolish woman is. AT: "she does not know anything at all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### she is untaught

"she has not learned from experience" or "she is young and naive"

#### walking straight on their way

This seems to be an idiom for "thinking only of their own affairs" or "minding their own business." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 09:16

#### is naive

"is inexperienced or immature"

#### turn aside here

"leave his path and come here"

#### she says

This is the foolish woman who was introduced in [Proverbs 9:13](./13.md).

#### those who have no sense

"those who do not have wisdom" or "those who are not wise"

#### Stolen waters are sweet, and bread of secrecy is delicious

The foolish woman speaks of the pleasure of stolen waters and bread of secrecy to tell men that if they sleep with her, they will have pleasure. This can be stated clearly in a simile: "You can enjoy me just as you enjoy water that you have stolen or bread that is secret" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that the dead are there

"that the men who have gone to her are now dead"

#### in the depths of Sheol

"Sheol" refers to the world of the dead.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]

### Proverbs 09:intro

#### Proverbs 09 General Notes ####

####### Structure and formatting #######

Chapter 9 concludes a collection of proverbs that operate as a unit about wisdom. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]])

####### Special concepts in this chapter #######

######## Wisdom calls out ########

The addressee of chapters 8 and 9 is broader than "my son," but is personal like the previous chapters' use of "my son."  In this case, Wisdom is calling out for all to come and learn of her. 

##### Links: #####

* __[Proverbs 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Proverbs 10

### Proverbs 10:01

#### General Information:

Many verses in Chapter 10 are contrasting parallelisms (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### The proverbs of Solomon

After the introduction of Chapters 1-9, Chapter 10 begins the collection of the proverbs; short sayings that teach wisdom.

#### accumulated

acquired over time

#### Yahweh does not let the soul of the righteous person go hungry

Here "soul" refers to the person. This can be stated in positive form. AT: "Yahweh makes sure those who do what is right have food to eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 10:04

#### A lazy hand

"Hand" represents the strength and ability of a person. AT: "A person unwilling to work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hand of the diligent

"Hand" represents the strength and ability of a person. AT: "person who works hard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Proverbs 10:06

#### are upon the head

The "head" represents the whole person. AT: "are given to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### mouth of the wicked

The "mouth" represents what a person says. AT: "words the wicked speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### covers up

hides the truth

#### name

The word "name" represents a person's reputation. AT: "memory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Proverbs 10:08

#### come to ruin

"be destroyed" or "be made useless"

#### crooked

not straight; deformed; dishonest; deceitful

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]

### Proverbs 10:10

#### He who winks the eye

"Winking the eye" represents a secretive sign for being cruel to someone else. AT: "He who makes a signal with a gesture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### will be thrown down

A person who is ruined is spoken of as if he were thrown down. AT: "others will ruin him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The mouth of the righteous

Here "mouth" represents what a persons says. AT: "The speech of a righteous person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the righteous

This refers to righteous people in general. AT: "righteous people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### is a water spring of life

This person's speech is spoken of as if it preserved living animals or people, as a water spring would do in a dry land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the mouth of the wicked covers up violence

That is, the wicked person appears to say harmless things, but plans to violent things against other people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the mouth of the wicked

Here "mouth" represents what a persons says. AT: "the speech of a wicked person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the wicked

This refers to wicked people in general. AT: "wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 10:12

#### love covers over

Love acts like a person who quiets trouble between people instead of stirring it up. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### on the lips of a discerning person

"Lips" represents what a person says. AT: "in what a sensible person says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a rod is for the back

"Rod" represents strong, physical punishment and "the back" represents the person who receives the punishment. AT: "a person who has no sense needs forceful punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]

### Proverbs 10:14

#### the mouth of a fool

"Mouth" represents what a person says. AT: "the words from a foolish person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his fortified city

This represents wealth as a safe place. AT: "his safety" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 10:16

#### The wage ... the profit

These terms normally refer to the money a worker earns. Here they represents the results of either doing what is right or doing what is wrong. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### There is a path to life for the one who follows discipline

"The person who obeys wise instruction will have a long and happy life"

#### but the one who rejects correction is led astray

This can be stated in active form. AT: "but the one who does not obey wise instruction will not have a good life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]

### Proverbs 10:18

#### has lying lips

"Lips" represent what a person says. AT: "tells lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### transgression is not lacking

This phrase uses a negative to emphasize a positive idea. AT: "there is much sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 10:20

#### The tongue of the righteous person

"Tongue" represents what a person says. AT: "Whatever a righteous person says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### is pure silver

"Silver" represents valuable sayings. AT: "is extremely valuable" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The lips of the righteous

"Lips" represents what a person says. AT: "The sayings of a righteous man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### nourish

cause them to develop or grow stronger

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 10:22

#### Wickedness is a game a fool plays

A game is an activity people do for pleasure. AT: "Fools find pleasure in wickedness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 10:24

#### overtake

overcome someone

#### The wicked are like the storm

Just as storm comes and sweeps everything away so wicked people will disappear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### is a foundation that lasts forever

"Foundation" represents the base or a beginning of something that people build over. AT: "is a start for something that lasts forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Proverbs 10:26

#### Like vinegar on the teeth and smoke in the eyes, so is the sluggard to those who send him

"Vinegar" and "smoke" represent things that hurt a person's teeth and eyes. AT: "Sending a lazy person to accomplish a task is irritating and unpleasant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### vinegar

a sour liquid used to flavor or preserve foods

#### the years of the wicked

"Years" represent the time a person lives. AT: "the lifetime of the evil person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 10:28

#### the years of wicked people

Here "years" represent the time a person lives. AT: "the lifetime of the evil person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will never be overthrown

This can be stated as active and positive: AT: "will be secure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]

### Proverbs 10:31

#### Out of the mouth of the righteous person

"Mouth" represents what a person says. AT: "From the righteous man's words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the perverse tongue will be cut out

"Tongue" represents what a person says. AT: "God will shut the mouths of people who say what is false" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### lips of the righteous person know what is acceptable

"Lips" represent what a person says. AT: "righteous person knows how to speak acceptably" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### mouth of the wicked

"Mouth" represents what a person says. AT: "the words of the wicked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 10:intro

#### Proverbs 10 General Notes ####

####### Structure and formatting #######

Chapter 10 starts a new section of the book, which is attributed to Solomon and is filled mainly with short,  individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often using contrasting elements: wise/foolish, money, lazy/diligent, truth telling, and wicked/righteous. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Proverbs 11

### Proverbs 11:01

#### General Information:

Many verses in Chapter 11 are contrasting parallelisms (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Yahweh hates scales that are not accurate

"Scales" represent measuring accurately in negotiating. AT: "God hates deceiving scales" or "God hates it when people are deceitful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but he delights in a precise weight

"Precise weight" represents accuracy in negotiating. AT: "but he delights in honest ways" or "but he is happy when people are honest"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 11:03

#### the treacherous

This nominal adjective can be stated as an adjective. AT: "treacherous people" or "those who are treacherous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### Wealth is worthless on the day of wrath

The "day of wrath" represents a specific event, such as the "day of Yahweh" or "judgment day" or "last days." AT: "A person's wealth will do him no good when God comes to judge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 11:05

#### makes his way straight

"has clear direction"

#### the wicked ... the treacherous

These nominal adjectives can be stated as adjectives. AT: "those who are wicked ... those who are treacherous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the treacherous are trapped by their cravings

"those who do evil are captured by their passions"

#### treacherous

ready to betray trust; traitorous; deceptive

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Proverbs 11:07

#### the hope that was in his strength

"the confidence he has in his own power"

#### comes to nothing

"disappears"

#### The righteous person is kept away from trouble

This can be stated in active form. AT: "God keeps away from trouble the person who does what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it comes

"trouble comes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]

### Proverbs 11:09

#### With his mouth the godless

"Mouth" represents what a person says. AT: "The words of the godless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the city becomes great

"City" represents the community or people group. AT: "the people group prospers" or "the community becomes prosperous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### by the mouth of the wicked

"Mouth" represents what a person says. AT: "the words of evil people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Proverbs 11:12

#### keeps a matter covered

"Covered" represents keeping things concealed as much as possible. AT: "does not tell" or "does not speak about the matter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Proverbs 11:14

#### advisors

those who give recommendations as a guide to action; counselors

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]

### Proverbs 11:15

#### one who hates giving

"one who refuses to give"

#### ruthless people

people without pity or compassion; cruel people

#### grasp for wealth

"are greedy for wealth"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 11:17

#### one who

"a person who"

#### sows what is right

To "sow" represents spreading out to gain more. AT: "spreads out what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### reaps the wages of truth

To "reap" represents acquiring or gathering in" AT: "will surely be rewarded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Proverbs 11:19

#### the one who

"the person who"

#### pursues evil

"chases after evil" or "seeks to do evil"

#### whose hearts are perverse

"Heart" represents the feelings, attitudes and motivations of a person. AT: "who have wicked thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]

### Proverbs 11:21

#### will not go unpunished

This phrase uses a negative to emphasize a positive idea. AT: "will certainly be punished" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Like a gold ring ... without discretion

A beautiful woman without discretion is compared to a useless and unsuitable golden ring in a pig's nose. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### without discretion

"without common sense" or "who is foolish"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md)]]

### Proverbs 11:23

#### one who sows seed

"Sowing seed" represents preparing for the future. AT: "a person who prepares for the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will accumulate even more

"will gain even more"

#### does not sow

"Sow" represents preparing for a result. AT: "does not prepare" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]

### Proverbs 11:25

#### will prosper

"will gain more"

#### the one who

"the generous person who" or "anyone who"

#### the man who refuses to sell

This describes the person who hoards his wealth instead of helping those in need.

#### good gifts crown the head of him who sells it

"Crown" represents the reward or award for the person who is willing to sell grain. AT: "good gifts are given as a crown of honor to him who sells it" or "the person who sells it is honored with many blessings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]

### Proverbs 11:27

#### The one who diligently seeks

the one who seeks with careful and continued effort

#### will fall

This is an idiom. Here "fall" represents destruction or failure. AT: "will be destroyed" or "awaits a bad future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### like the leaf, righteous people will flourish

"Leaf" represents growth and prosperity. AT: "righteous people will prosper in the same way a healthy green leaf grows" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### righteous people will flourish

This means that righteous people will thrive or prosper.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]

### Proverbs 11:29

#### inherit the wind

The "wind" is a metaphor for something that cannot be grasped or has no value. AT: "inherit nothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 11:30

#### The righteous person will be like a tree of life

A person who does what is right is compared to a tree that produces life as its fruit. AT: "Those who do right will bring life to themselves and others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### tree of life

See how you translated this in [Proverbs 3:18](../03/17.md).

#### how much more

"even more so"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Proverbs 11:intro

#### Proverbs 11 General Notes ####

####### Structure and formatting #######

Chapter 11 continues the section of the book which is attributed to Solomon and is filled mainly with individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often using contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and  [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Proverbs 12

### Proverbs 12:01

#### General Information:

The author uses [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] throughout this chapter.

#### General Information:

Verses 1-15 contrast wisdom and foolishness.

#### Whoever

"Any person who"

#### the one who hates correction

"the person who does not want to be told what to do"

#### is stupid

"is foolish" or "is unwise"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 12:03

#### A person cannot be established by wickedness

This can be stated in active form. AT: "No one can become safe and secure by doing what is wicked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### cannot be uprooted

"Uprooted" represents being pulled out of the ground like a plant or a tree. This cannot happen to those who do right. AT: "are as stable as a tree with deep roots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### A worthy wife is her husband's crown

A crown represents the greatest honor a person can receive. AT: "A good wife is a sign of great honor for her husband" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### she who brings shame is like a disease that rots his bones

A disease that rots the bones represents the spoiling of a person's life. AT: "a wife's shameful acts destroy her husband's influence and happiness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Proverbs 12:05

#### The words of wicked people are an ambush waiting for a chance to kill

The deceitful things that wicked people say in order to harm other people are spoken of as if their words are waiting to kill someone by surprise. AT: "The deceitful things wicked people say are like a person who waits to kill someone by surprise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the words of the upright keep them safe

"the advice from an upright person keeps people safe"

#### the upright

"the righteous person" or "the honest person" or "the just person"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Proverbs 12:07

#### Wicked people are overthrown

This can be stated in active form. AT: "People will overthrow the wicked people" or "People will remove the wicked people from power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### house

The term "house" is often used figuratively in the Bible to refer to a person's ancestors, descendants or other relatives. AT: "family" or "descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### A person is praised by how much wisdom he has

This can be stated in active form. AT: "People will praise those who have wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the one who makes perverse choices is despised

This can be stated in active form. AT: "people will hate the one who always thinks evil thoughts" or "people will hate the one who takes good things and twists them into bad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 12:09

#### Better to have an unimportant position

"It is better to be an ordinary person"

#### is cruel

"causes suffering"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 12:11

#### projects

"plans" or "tasks"

#### fruit

This refers to a person's actions and thoughts. Just as fruit on a tree shows what kind of tree it is, in the same way a person's words and actions reveal what his character is like.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Proverbs 12:13

#### An evil person is trapped by his wicked talk

"Trapped" represents being caught in a snare or being tricked. This can be stated in active form. AT: "The wicked things an evil person says will trap him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### just as the work of his hands rewards him

The phrase, "the work of his hands" represents work done by physical labor. AT: "just as the good work he does rewards him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]

### Proverbs 12:15

#### in his own eyes

This phrase represents the idea he has from his own observation, imagination or memory. AT: "in his own opinion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### advice

wise suggestions

#### is prudent

"is wise" or "has good sense."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Proverbs 12:17

#### The words of one who speaks rashly are like the thrusts of a sword

The phrase, "thrusts of a sword" represents cruel words that hurt another. AT: "What a person says without thinking can hurt as much as if he stabbed with a sword" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the tongue of the wise

"Tongue" represents what a person says. AT: "what wise people say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### brings healing

"comforts and heals"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 12:19

#### Truthful lips last forever

"Lips" represents what a person says. AT: "A truthful person endures forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a lying tongue is only for a moment

"Tongue" represents what a person says. AT: "the one who lies lasts only for a moment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### advisors

those who give recommendations as a guide to action; counselors

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Proverbs 12:21

#### No ill comes

The negative, "No" cancels out the idea of "ill" (bad things that happen). AT: "Good things come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Yahweh hates lying lips

"Lips" represents what a person says. AT: "Yahweh detests those who tell lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Proverbs 12:23

#### conceals his knowledge

"does not tell everything he knows"

#### The hand of the diligent

"Hand" represents what a person does -- his works. AT: "Diligent people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will be put to forced labor

"Forced labor" describes what a person must do who is not free to do what he wants. AT: "will become a slave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prudent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prudent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Proverbs 12:25

#### Anxiety

uneasy feeling of fear or dread, worry

#### weighs him down

"Weighing down" represents the idea of putting a very heavy load on a person so he cannot move freely. This phrase means to make a person sad or depressed. AT: "causes him to become sad or depressed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but a good word makes him glad

The abstract noun "word" can be stated as the verb "speak." AT: "but when others speak kindly to him, he is cheerful again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 12:27

#### would not roast their own game

"Game" means animals caught and killed while hunting. And "roast" is a way of cooking food.

#### precious wealth

"valuable treasure"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 12:intro

#### Proverbs 12 General Notes ####

####### Structure and formatting #######

Chapter 12 continues the section of the book (Chapter 10-22) which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often using contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility and  integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Proverbs 13

### Proverbs 13:01

#### A wise son hears

Here "hears" represents listening in order to do it. AT: "A wise son obeys" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will not listen to rebuke

Here "listen" represents paying attention in order to do it. AT: "will not learn from rebuke" or "will not obey, despite rebuke" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### From the fruit of his mouth

Here "fruit" represents what a person says. AT: "From the words of his mouth" or "From what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the appetite

the desire or liking for something

#### the treacherous

This nominal adjective can be translated as an adjective. AT: "the treacherous person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Proverbs 13:03

#### his mouth

Here "mouth" represents what a person says. AT: "what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### opens wide his lips

Opening the lips represents speaking, and opening them wide represents speaking too often or too much. AT: "speaks a lot" or "talks too much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The appetite ... the appetite

See how you translated this in [Proverbs 13:2](./01.md).

#### craves but gets nothing

"strongly desires but gets nothing"

#### the appetite of diligent people will be richly satisfied

Here "appetite" represents desire. AT: "diligent people will have a richly satisfied life" or "being diligent will make people richly satisfied" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### diligent people

people who work with careful and continued effort

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]

### Proverbs 13:05

#### repugnant

causing a strong feeling of disgust

#### Righteousness protects those

"Righteousness" represents a way of life approved by Yahweh. This quality acts like a person who protects. AT: "A way of life approved by Yahweh protects" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### who are faultless in their path

Here "path" represents how a person directs his life. AT: "who are faultless in their way of living" or "who live lives of integrity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### wickedness turns away those who commit sin

Here "wickedness" represents an evil conduct of life. This quality acts like a person who turns away those who commit sin. AT: "wickedness turns sinners away from a successful path" or "wickedness ruins sinners' lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Proverbs 13:07

#### who enriches himself

"who makes himself rich"

#### does not hear a threat

Possible meanings are 1) no one will threaten to steal from him because he has nothing anyone would want to steal or 2) he will not listen when people correct him because he has nothing to lose if they punish him. AT: "does not listen to rebuke"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Proverbs 13:09

#### The light of righteous people rejoices

Here the light represents the righteous person's life or good behavior, and rejoicing represents causing people to rejoice. AT: "The life of a righteous person is like a light that causes people to rejoice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the lamp of wicked people will be put out

Here the lamp represents the life or behavior of wicked people, and "be put out" is an idiom that means that a fire is stopped. The lamp being put out represents either the person dying or the person's life not giving any joy. AT: "the lives of wicked people are like a lamp whose fire will be stopped" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Pride only breeds conflict

"Pride always causes conflict"

#### listen to

"heed" or "follow"

#### good advice

suggestions that are helpful and profitable

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 13:11

#### Wealth dwindles away

"Wealth decreases" or "Wealth slowly disappears"

#### working with his hand

The phrase "working with his hand" refers to physical work instead of only mental or other types of work. Many people give physical work a low value. AT: "working with physical strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### make his money grow

Money is compared to a tree that grows. AT: "make his money increase" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### When hope is postponed

Here "hope" represents the thing a person hopes for. This can be stated in active form. AT: "When a person hopes for something but does not receive it for a very long time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it breaks the heart

Breaking a person's heart represents overwhelming that person with sadness. AT: "it causes intense sadness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a longing fulfilled is a tree of life

Someone receiving what they hoped for and becoming very happy is spoken of as if the fulfillment of their hope were a tree that gives life. AT: "a longing fulfilled is like a tree of life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### tree of life

"a tree that gives life" or "a tree whose fruit sustains life." See how you translated this in [Proverbs 3:18](../03/17.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 13:13

#### the one who honors the command will be rewarded

This can be stated in active form. AT: "they will reward the one who honors the command" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### fountain of life

A fountain is a good source of water and here represents a source of life. AT: "a bountiful source of life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### snares of death

Here "snares" represent dangers that will kill. AT: "traps that lead to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 13:15

#### but the way of the treacherous is never-ending

Here a person's behavior or conduct is spoken of as if it were a way or path that a person walks. A person being ruined by their own treachery is spoken of as if they are on a way or path that never ends. AT: "but the behavior of the treacherous will cause their own destruction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the treacherous

This nominal adjective can be stated as an adjective. AT: "the treacherous person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### a fool parades his folly

To "parade" means to display in front of everyone. AT: "a fool displays his foolishness to everyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 13:17

#### falls into trouble

"is unreliable" or "does something evil"

#### envoy

"messenger" or "diplomat"

#### learns from correction

The abstract noun "correction" can be stated as an action. AT: "learns when someone corrects him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 13:19

#### is sweet

"is a delight" or "brings joy"

#### the appetite

the desire or liking for something

#### will suffer harm

"will experience harm" or "will be ruined"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Proverbs 13:21

#### Disaster runs after sinners

"Disaster" is given human characteristics like the ability to run. AT: "Sinners have trouble wherever they go" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### righteous people are rewarded with good

This can be stated in active form. AT: "God rewards righteous people with good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his grandchildren

"the sons of his sons" or "the children of his children" or "his descendants"

#### a sinner's wealth is stored up for the righteous person

This can be stated in active form. AT: "the one who does right will receive the wealth that a sinner has stored up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Proverbs 13:23

#### An unplowed field

"A field that is not prepared for food production" or "An empty field not ready for planting"

#### but it is swept away by injustice

"Swept away" represents completely removing something. This can be stated in active from. AT: "but injustice takes away that food" or "but unjust people take the food away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### is careful to instruct him

"makes sure to instruct him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Proverbs 13:25

#### he satisfies his appetite

"he has satisfied himself" or "he fulfills his desires"

#### the stomach of the wicked is always hungry

Here "stomach" represents the desires of a person. AT: "the wicked person is always hungry for more" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 13:intro

#### Proverbs 13 General Notes ####

####### Structure and formatting #######

Chapter 13 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Proverbs 14

### Proverbs 14:01

#### builds her house

"builds up her house" or "makes her house better"

#### house

Possible meanings are 1) this may refer to her actual house, that is the building she lives in or 2) this may refer to her family.

#### with her own hands

The woman is represented by her "hands." AT: "by herself" or "by the way she behaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### The one who ... the one who

"The person who ... the person who"

#### walks uprightly

"Walks" represents the conduct of life. AT: "conducts his life in a just and honest way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### despises

"grossly disrespects" or "indicates he hates"

#### in his ways despises him

The word "his" refers to the dishonest man and "him" refers to Yahweh.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 14:03

#### the mouth of ... the lips of

The mouth and the lips both refer to what a person says. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### an offshoot of his pride

An offshoot is something that grows out of something else. AT: "what his pride produces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the wise

This word is actually a plural. "the wise men" or "wise people"

#### will preserve them

"will keep them from harm" or "will keep them safe"

#### the feeding trough

A "trough" is a container in which you put the food for animals.

#### an abundant crop

"a good harvest"

#### by the strength of an ox

"Strength" represents the strong work an ox can do. AT: "because of the work an ox does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]

### Proverbs 14:05

#### breathes out lies

This figure of speech uses "breathes" to refer to lying constantly. AT: "constantly lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]]) See how you translated this phrase in [Proverbs 6:19](../06/17.md).

#### and there is none

"and wisdom is not there" or "but he will not find wisdom"

#### comes easy to

"is easily found by" or "acquires without difficulty"

#### the one who is discerning

"the one who is wise" or "a person who has understanding"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 14:07

#### on his lips

The word "lips" represents what a person says. AT: "from his speech" or "with his comments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the prudent

a person who has good judgment or sense

#### his own way

The word "way" represents the conduct of life of a person. AT: "his conduct" or "how he lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the folly of fools is deception

The foolishness of fools is that they think they are wise, when they are not.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Proverbs 14:09

#### when the guilt offering is sacrificed

"at guilt" or "at the guilt offering" The meaning behind this phrase is that fools do not apologize to God or men for the things they do wrong.

#### but among the upright favor is shared

This can be stated in active form. AT: "but the upright enjoy favor together" or "but God's favor is experienced together among the upright" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### bitterness

"sorrow" or "sadness"

#### no stranger

"those who do not know him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/guiltoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/guiltoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Proverbs 14:11

#### the tent

The word "tent" represents everything that happens within it. AT: "the household" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### flourish

The word "flourish" means vigorous blooming of flowers and so represents anything that grows strongly. AT: "to do well and last long" or "to be healthy" or "to be very successful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### There is a way that seems right to a man

The word "way" represents the conduct of life a person follows. AT: "People think that the way they are living is the right way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 14:13

#### A heart can laugh

The word "heart" represents a person's feelings, attitudes and motivations. AT: "A person's feelings can show laughter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### be in pain

"experience pain" or "hurt"

#### The one who

"The person who"

#### what his ways deserve

The word "ways" represents a person's conduct of life. AT: "what he deserves, based on how he lived" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### what is his

"what belongs to him" or "what he has a right to"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Proverbs 14:15

#### naive

inexperienced or immature

#### his steps

Here the idea of footsteps represents a person's behavior. AT: "his actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### turns away from evil

Here evil is spoken of as if it were a place. AT: "avoids doing evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### confidently dismisses

"boldly ignores"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 14:17

#### is quick to become angry

"becomes angry quickly"

#### naive

inexperienced or immature

#### inherit foolishness

Here "inherit" represents having permanent possession of something. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### foolishness

The word "foolishness" is an abstract noun that represents foolish thinking and foolish actions.

#### prudent people

"wise people"

#### are crowned with knowledge

Here knowledge is spoken of as if it were a beautiful ornament worn on one's head, such as a turban with jewels. AT: "wear knowledge as a turban" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 14:19

#### bow down

This means to bend over to humbly express respect and submission toward someone. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### at the gates of the righteous

The word "gates" represents an entrance to meet with another. This means the wicked will have to wait for the righteous person and beg to enter his presence. AT: "to meet with the righteous person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The poor person is hated even by his own companions

This can be stated in active form. AT: "Everyone hates the poor person even his own neighbors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Proverbs 14:21

#### The one ... the one

"The person ... the person"

#### the poor

"poor people"

#### Do not those who plot evil go astray?

The assumed answer to this question is "yes." AT: "Those who plot evil will go astray." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### who plot evil

"who make evil plans" or "who make plans to do evil things"

#### those who plan to do good will receive covenant faithfulness and trustworthiness

The abstract nouns "faithfulness" and "trustworthiness" can be stated as "faithful" and "trustworthy." AT: "God will show himself to be trustworthy and faithful to his covenant to those who plan to do what is good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]

### Proverbs 14:23

#### but when there is only talk

"but if you only talk" or "but when all a person does is talking"

#### The crown of wise people

The word "crown" represents the highest achievement possible and visible to all. AT: "The reward of wise people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the folly of fools

See how you translated this phrase in [Proverbs 14:8](./07.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 14:25

#### breathes out lies

This figure of speech uses "breathes" to refer to lying constantly. See how you translated this phrase in [Proverbs 6:19](../06/17.md). AT: "constantly lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]

### Proverbs 14:26

#### fountain of life

A "fountain" is a bountiful source of water and represents here the source of life. AT: "source of life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from the snares of death

A "snare" is a sort of trap used to hunt animals and represents something tricky and dangerous that will kill. AT: "from the trap that will kill" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 14:28

#### the great number of his people

"how many people he rules"

#### the prince is ruined

"the prince has nothing and his kingdom will fall"

#### the quick-tempered

a person who is quick to become angry

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]

### Proverbs 14:30

#### A tranquil heart

"A peaceful mindset" or "An attitude that is at peace"

#### rots the bones

The word "rots" represents the decay of a person and "bones" represents the whole person. AT: "causes a person to be unhealthy in body and spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The one who ... the one who

"The person who ... the person who"

#### curses

This means to express a desire that bad things will happen to someone.

#### the poor ... the needy

"a poor person ... a needy person"

#### shows favor to

"is kind to" or "helps"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 14:32

#### is brought down by his evil actions

This can be stated in active form. AT: "evil actions push over" or "evil actions destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Wisdom rests in the heart

The word "heart" represents the feelings, attitudes and motivations of a person. AT: "Wisdom is in the attitude" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the discerning

"a discerning person"

#### she lets herself be known

This can be stated in active form. AT: "she makes sure people know her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### she

The word "she" refers to wisdom. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 14:34

#### disgrace

"bring shame upon"

#### prudently

"wisely"

#### the one who

"the servant who"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Proverbs 14:intro

#### Proverbs 14 General Notes ####

####### Structure and formatting #######

Chapter 14 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## Proverbs 15

### Proverbs 15:01

#### A gentle answer turns away wrath

Causing a person to stop being angry is spoken of as if it were turning that person's wrath away. AT: "Answering a person gently will calm that person's wrath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but a harsh word stirs up anger

Causing a person to become more angry is spoken of as if it were stirring up or awakening anger. AT: "but speaking harshly causes that person to become more angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The tongue of wise people compliments knowledge

Here the word "tongue" refers to the person who speaks. AT: "Wise people compliment knowledge when they speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### compliments knowledge

"makes knowledge attractive" or "uses knowledge correctly"

#### the mouth of fools pours out folly

The writer speaks of fools' mouths as if they were containers and of folly as if it were the liquid that filled them. When fools speak, their mouths pour out the liquid. The word "mouth" represents those who speak. AT: "fools are always speaking folly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 15:03

#### The eyes of Yahweh are everywhere

Here the word "eyes" represents Yahweh and emphasizes his ability to see everything. AT: "Yahweh sees everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the evil and the good

The words "evil" and "good" refer to people. AT: "evil people and good people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### A healing tongue is a tree of life

The word "tongue" refers to speech. The writer speaks of the words of a person who says things that help and encourage others as if they were a tree that provides life-giving nourishment. AT: "Kind words are like a tree that gives life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a deceitful tongue crushes the spirit

The phrase "a deceitful tongue" refers to speech that is deceitful or hurtful. The writer speaks of a person being hurt or in despair as if that person's spirit were an object that words have crushed. AT: "deceitful speech causes a person to despair" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Proverbs 15:05

#### he who learns from correction

The word "correction" can be translated as a verb. AT: "he who learns when someone corrects him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### prudent

"wise"

#### the earnings of the wicked person give

The word "earnings" can be translated as a verbal phrase. AT: "the wealth that a wicked person earns gives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Proverbs 15:07

#### The lips of wise people scatter knowledge about

The word "lips" represents what wise people say. The writer speaks of knowledge as if it were seeds that wise people scatter around when they speak. AT: "The speech of wise people spreads knowledge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### not so the hearts of fools

Possible meanings are 1) the word "hearts" is synecdoche for the fools themselves and means that they do not scatter knowledge like wise people do. AT: "fools do not scatter knowledge about" or 2) fools do not have knowledge in their hearts, with "hearts" being a metonym for the thoughts. AT: "fools do not understand knowledge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### upright people

"people who live rightly"

#### is his delight

"pleases him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Proverbs 15:09

#### Yahweh hates the way of wicked people

The lifestyles of wicked people are spoken of as if they are paths on which those people walk. AT: "Yahweh hates the way that wicked people live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the one who pursues what is right

Being diligent to live rightly is spoken of as if it were chasing after right things. AT: "the person who strives to live rightly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### anyone who forsakes the way

Here "the way" refers to the way of righteousness. A person who stops doing what is right is spoken of as if he has stopped walking on the correct path. AT: "anyone who stops living rightly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he who hates correction

The word "correction" can be translated as a verb. AT: "the person who hates it when others correct him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 15:11

#### Sheol and destruction are open before Yahweh

The words "Sheol and destruction" both refer to the place of the dead. Yahweh knowing everything about the place of the dead is spoken of as if it were open before Yahweh. AT: "Yahweh knows everything about the place where dead people are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### how much more the hearts of the sons of mankind?

This rhetorical question emphasizes that since Yahweh knows everything about the place of the dead, it is more obvious that he knows everything about the hearts of men. AT: "so he certainly knows the hearts of the sons of mankind!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the hearts of the sons of mankind

Here the word "hearts" represents the thoughts and motivations. The phrase "the sons of mankind" is an idiom for humanity. AT: "the thoughts of humans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The mocker resents correction

The word "correction" can be translated with a verbal form. AT: "The mocker hates when others correct him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### he will not go to the wise

It is implied that he will not go to the wise to seek their counsel or advice. AT: "he will not go to the wise to seek their counsel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 15:13

#### A joyful heart makes the face cheerful

Here the word "heart" represents the person. AT: "When a person is joyful, his face is cheerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### crushes the spirit

The writer speaks of a person being discouraged as if that person's spirit were an object that is crushed. See how you translated this in [Proverbs 15:4](./03.md). AT: "makes a person discouraged" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The heart of the discerning

Here the word "heart" represents the mind and thoughts. AT: "The mind of the discerning person" or "The discerning person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the mouth of fools feeds on folly

Here the word "mouth" represents the person. The writer speaks of fools desiring foolish things as if they ate foolish things. AT: "foolish people desire folly as if it were the food that they eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 15:15

#### All the days of oppressed people are miserable

"Oppressed people are miserable all of their days"

#### a cheerful heart has an unending feast

Here the word "heart" represents the person. The writer speaks of a cheerful person enjoying life as if that person were celebrating a feast that does not end. AT: "the cheerful person enjoys life, as if he were celebrating an unending feast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an unending feast

"a feast that never ends"

#### confusion

"anxiety"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 15:17

#### a meal with vegetables

The vegetables represent a small meal with very little food. AT: "a small meal" or "very little food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### where there is love

The word "love" can be translated with a verbal phrase. AT: "where people love one another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### a fatted calf served with hatred

This can be translated in active form. AT: "a fatted calf that someone serves with hatred" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a fatted calf

This refers to a calf that has been fed a lot of food so that it will become fat. Here it represents a delicious meal or a feast. AT: "a luxurious meal" or "a feast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with hatred

The word "hatred" can be translated with a verbal phrase. AT: "where people hate one another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### stirs up arguments

Causing people to argue more is spoken of as if it were stirring up or awakening arguments. The abstract noun "arguments" can be stated as "argue." AT: "causes people to argue more" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Proverbs 15:19

#### The path of the sluggard ... the path of the upright

The writer speaks of a person's life as if it were a path on which the person walks. AT: "The life of the sluggard ... the life of the upright" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The path of the sluggard is like a place with a hedge of thorns

The writer compares the lifestyle of the sluggard with trying to walk through a hedge of thorns. Both cause the person to suffer pain. AT: "The life of the sluggard is like a person trying to walk through a hedge of thorns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the path of the upright is a built-up highway

The writer speaks of the blessings that upright people experience in life as if they were walking on a smooth road. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### built-up highway

This is a road that is wide, flat, and without obstacles or potholes.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 15:21

#### the one who has understanding walks a straight path

The writer speaks of a person doing the right thing as if he were walking straight ahead on a path. AT: "the person who has understanding does what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Plans go wrong

"Plans fail"

#### where there is no advice

"when there is no one to give advice"

#### advisors

people who give recommendations as a guide to action

#### they succeed

"plans succeed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]

### Proverbs 15:23

#### a pertinent reply

"a fitting reply" or "an appropriate answer"

#### how good is a timely word

This exclamation emphasizes that a word spoken at the right time is very good. AT: "a word that a person speaks at the right time is very good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### The path of life leads upward ... from Sheol beneath

The writer speaks of a lifestyle that results in life as if it were a path that goes upward towards life and of a lifestyle that results in death as if it were a path that leads down to the place of the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]

### Proverbs 15:25

#### legacy

"house." This refers to household, property, and wealth.

#### the words of kindness are pure

"kind words are pure" or "pleasant words are pure"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Proverbs 15:27

#### The heart of the righteous person ponders before it answers

Here the word "heart" is a metonym for the mind and thoughts. This represents the person who thinks. AT: "The person who does right ponders what to say before he answers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the mouth of wicked people pours out all its evil

The writer speaks of wicked people's mouths as if they were containers and speaks of evil as if it were the liquid that filled them. When wicked people speak, their mouths pour out the liquid. The word "mouths" represents those who speak. AT: "wicked people are always saying evil things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the mouth of wicked people pours out all its evil

It may be more natural in you language to translate all these words as either singular or plural. AT: "the mouth of the wicked person pours out all its evil" or "the mouths of wicked people pour out all their evil"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 15:29

#### Yahweh is far away from wicked people

The writer speaks of Yahweh not listening to wicked people as if he were physically far away from them. AT: "Yahweh does not listen to wicked people" or "Yahweh does not answer wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The light of the eyes

The writer speaks of an expression of joy on one's face as if the person's eyes emitted light. AT: "A cheerful expression" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### brings joy to the heart

The word "heart" represents the person. Possible meanings are 1) the person who has a cheerful expression becomes joyful or 2) other people become joyful when they see someone with a cheerful expression. AT: "causes a person to be joyful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### good news is health to the body

Here the word "body" represents the person. AT: "receiving good news makes a person feel good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]

### Proverbs 15:31

#### you will remain among wise people

Possible meanings are 1) people will continue to consider you to be a wise person or 2) you will continue to enjoy the company of wise people.

#### listens to correction

The word "correction" can be translated with a verbal phrase. AT: "listens when others correct him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]

### Proverbs 15:33

#### The fear of Yahweh teaches wisdom

The words "fear" and "wisdom" can be translated with verbal phrases. AT: "When one fears Yahweh, he will learn to be wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### The fear of Yahweh

See how you translated this phrase in [Proverbs 1:7](../01/07.md).

#### humility comes before honor

This means that a person must first learn humility before Yahweh will honor him.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 15:intro

#### Proverbs 15 General Notes ####

####### Structure and formatting #######

Chapter 15 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## Proverbs 16

### Proverbs 16:01

#### The plans of the heart belong to a person

Here the word "heart" represents the person's mind and thoughts. AT: "A person makes plans in his mind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from Yahweh comes the answer from his tongue

Possible meanings are 1) Yahweh speaks his answer to a person's plans, which is a metaphor meaning that Yahweh determines the outcome of that person's plans or 2) Yahweh enables a person to speak words about the plans that he has made. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the answer from his tongue

The person is represented by his "tongue" to emphasize his speech. AT: "the answer that he speaks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### All of a person's ways are pure in his own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. The writer speaks of what a person does as if that person were walking down a path. AT: "A person thinks that everything he does is pure" or "A person judges everything he does as pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh weighs the spirits

Here the word "spirits" represents people's desires and motives. The writer speaks of Yahweh discerning and judging a person's desires and motives as if he were weighing that person's spirit. AT: "Yahweh judges the person's motives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Proverbs 16:03

#### even the wicked for the day of trouble

The verbal phrase may be supplied from the previous phrase. AT: "he has made even the wicked for the day of trouble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Proverbs 16:05

#### everyone who has an arrogant heart

Here the word "heart" represents the person. AT: "everyone who is arrogant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they will not go unpunished

The two negatives in this phrase strongly emphasize the positive. This can be stated in active form. AT: "Yahweh will certainly punish them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### By covenant faithfulness and trustworthiness iniquity is atoned for

The abstract nouns "faithfulness" and "trustworthiness" can be stated as "faithful" and "trustworthy." This can be stated in active form. Possible meanings are 1) AT: "Because Yahweh is faithful to his covenant and trustworthy he forgives people's sins" or 2) AT: "Yahweh will forgive the sins of those who are faithful to the covenant and trustworthy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### people turn away from evil

The writer speaks of people no longer doing evil things as if they were turning away from evil. AT: "people stop doing evil things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 16:07

#### he makes

"Yahweh makes"

#### a large income

"earning a lot of money"

#### injustice

"wrongdoing"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Proverbs 16:09

#### In his heart a person plans out his way

Here the word "heart" represents the mind and thoughts. The writer speaks of a person's actions as if the person were walking on a path. AT: "A person plans in his mind what he will do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh directs his steps

The writer speaks of Yahweh determining the outcome of a person's plans as if Yahweh were telling that person where to walk. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Insightful decisions are on the lips of a king

Here the word "lips" is a metonym for what the king says. AT: "What a king says are insightful decisions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his mouth should not betray justice

The word "mouth" represents the king himself. AT: "he should not speak deceitfully when he judges" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Proverbs 16:11

#### Honest scales come from Yahweh

Yahweh requires justice and fairness when doing business. Dishonest people used heavier or lighter weights in their scales in order to gain more when buying or selling. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all the weights in the bag are his work

Merchants carried their weights in bags. Possible meanings are 1) Yahweh has determined how much every weight must weigh or 2) Yahweh is concerned with every weight that a merchant uses.

#### that is something to be despised

This can be stated in active form. AT: "that is something that people despise" or "that is something that Yahweh despises" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for a throne is established by doing what is right

Here the word "throne" represents the king's rule. This can be stated in active form. AT: "for the king establishes his reign by doing what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]

### Proverbs 16:13

#### lips that say what is right

Here the word "lips" represents the person who speaks. AT: "a person who speaks the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### A king's wrath is a messenger of death

The writer speaks of an angry king causing someone to die as if the king's wrath were a messenger that he sends out to kill someone. AT: "An angry king can put people to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Proverbs 16:15

#### General Information:

Verse 15 contrasts with verse 14.

#### In the light of a king's face is life

The writer speaks of an expression of joy on the king's face as if his face emitted light. AT: "When the king is cheerful, people live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his favor is like a cloud that brings a spring rain

The writer compares the king showing favor towards someone with a cloud that brings rain to make crops grow. Both promise blessing to those who receive them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### How much better it is to get wisdom than gold

This exclamation emphasizes that having wisdom is much better than having gold. AT: "It is much better to get wisdom than to get gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### To get understanding should be chosen more than silver

This can be stated in active form. AT: "A person should choose to get understanding more than to get silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Proverbs 16:17

#### The highway of upright people

The writer speaks of the lifestyle of upright people as if it were a well-built road, free of obstacles. AT: "The righteous way that upright people live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### turns away from evil

The writer speaks of avoiding or no longer doing evil things as if it were turning away from evil. AT: "keeps them from doing evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a haughty spirit

Here the word "spirit" represents the person's attitude and temperament. AT: "an arrogant attitude" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a downfall

"ruin" or "failure"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Proverbs 16:19

#### spoil

goods taken in battle

#### what they are taught

This can be stated in active form. AT: "what someone has taught them" or "what they have learned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 16:21

#### The one who is wise in heart is called discerning

This person will have a reputation of being a discerning person. This can be stated in active form. AT: "People will call the one who is wise in heart discerning" or "The one who is wise in heart will have a reputation of being a discerning person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The one who is wise in heart

Here the heart represents the mind and thoughts. AT: "The one who is wise" or "The one who is wise in his thinking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### sweetness of speech

The writer speaks of kind or pleasant speech as if it were something that tastes sweet. AT: "kind speech" or "pleasant speech" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Understanding is a fountain of life

The writer speaks of "Understanding" as if it were a fountain that continuously flows with water and which sustains the life of those who drink from it. AT: "Understanding is like a fountain flowing with life-giving water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 16:23

#### The heart of a wise person gives

Here the word "heart" represents the mind and thoughts. AT: "The thoughts of a wise person gives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### gives insight to his mouth

Here the word "mouth" is a metonym for speech. AT: "makes his speech wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to his lips

Here the word "lips" is a metonym for speech. AT: "to what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Pleasant words are a honeycomb

The writer speaks of pleasant words being able to bring delight to the hearers as if the words were a honeycomb dripping with fresh honey. AT: "Pleasant words are like a honeycomb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sweet to the soul

Possible meanings for the word "soul" are 1) it represents a person's inward desires and pleasures. AT: "sweet enough to make a person happy" or 2) it can mean "throat" and is a metonym for a person's tongue and ability to taste. AT: "sweet to a person's taste" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### healing to the bones

Here the word "bones" represent a person's body. AT: "healing to the body" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Proverbs 16:25

#### There is a way that seems right to a man

The writer speaks of a person's conduct or behavior as if it were a road on which the person is traveling. AT: "A person thinks that the way he is living is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but its end is the way to death

The word "its" refers to "way" in the previous line. This "way" is the road that leads to death.

#### The laborer's appetite works for him

The writer speaks of the appetite as if it were a person who works on behalf of the laborer. This means that the person who labors is motivated by his desire to eat. AT: "The laborer works to satisfy his appetite" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### his hunger urges him on

The writer speaks of "hunger" as if it were a person who urges the laborer to continue working. AT: "he keeps on working because he is hungry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Proverbs 16:27

#### A worthless person digs up mischief

The writer speaks of a person trying to find ways to harm other people as if that person were digging in the ground to find something buried. AT: "A worthless person looks for mischief as if he were digging for something in the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### worthless

"useless" or "wicked"

#### mischief

"evil" or "trouble"

#### his speech is like a scorching fire

The writer compares the way this person's words hurt others with the way that fire burns things. AT: "he hurts people with his words, like a fire scorches the things it touches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a gossip

a person who gossips or spreads rumors

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md)]]

### Proverbs 16:29

#### A man of violence lies to his neighbor

It is implied that this man lies to his neighbor in order to get his neighbor to join him in violent actions. AT: "A man of violence entices his neighbor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### A man of violence

"A violent man" or "A man who practices violence"

#### leads him down a path that is not good

The writer speaks of a person's actions as if they were a road on which the person walks. AT: "gets him to do things that are not good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a path that is not good

The writer uses an understatement to emphasize how bad this path is. AT: "a very bad path" or "a terrible path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The one who winks the eye ... those who purse the lips

Both of these are facial gestures which people might use to signal their plans to others. See how you translated "winks the eye" in [Proverbs 10:10](../10/10.md).

#### will bring evil to pass

"will do evil things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 16:31

#### Gray hair is a crown of glory

The writer speaks of gray hair as if it were a crown. "Gray hair" is a metonym for old age. AT: "A person who has lived long enough to have gray hair is like one who wears a glorious crown on his head" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### it is gained

This can be stated in active form. AT: "a person gains it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### one who rules his spirit

The writer speaks of a person being able to control his own temper and emotions as if he ruled over his spirit like a king rules his people. AT: "one who controls his temper" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Proverbs 16:33

#### The lots are cast into the lap

This can be stated in active form. AT: "A person throws the lots into his lap" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the decision is from Yahweh

Possible meanings are 1) Yahweh decides how the lots will land or 2) it is not the lots, but Yahweh who determines what will happen.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 16:intro

#### Proverbs 16 General Notes ####

####### Structure and formatting #######

Chapter 16 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## King and royalty ########

Some of these proverbs mention a king. As in other cases, this is intended to apply to all rulers. 

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | [>>](../17/intro.md)__


## Proverbs 17

### Proverbs 17:01

#### to have quiet

Here "quiet" refers to "peace." AT: "to have peace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### than a house full of feasting with strife

The words "to have" are understood from the previous phrase. They can be repeated. AT: "than to have a house full of feasting with strife" or "than to be in a house full of feasting where there is strife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Proverbs 17:03

#### The crucible is for silver and the furnace is for gold

This refers to how gold and silver are refined. A metal is refined by heating it to a high temperature so that it melts and the impurities may be removed. AT: "The crucible is used to refine silver and the furnace is used to refine gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### crucible

a pot in which metals are melted at a very high temperature

#### Yahweh refines hearts

This speaks of Yahweh testing people to help them stop being evil and foolish as if their hearts were a metal that Yahweh was refining to remove everything that is impure. AT: "Yahweh tests peoples' hearts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### hearts

"Hearts" represent a person's thoughts and desires. AT: "people's thoughts and desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### wicked lips

The word "lips" can be translated as either 1) a synecdoche for the person or 2) a metonym for the words that come out from those lips. AT: "a wicked person" or "wicked talk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### gives ear

This idiom means "listens." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### destructive tongue

The word "tongue" can be translated as either 1) a synecdoche for the person or 2) a metonym for the words that the tongue produces. AT: "a destructive person" or "destructive talk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/furnace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/furnace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 17:05

#### the poor

This refers to poor people. AT: "those who are poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### his Maker

This is a name that refers to Yahweh. This is also an abstract noun that can be written as a verb. AT: "the one who made him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### at misfortune

This refers to the misfortune of others. AT: "at others' misfortune" or "at other peoples' troubles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### are the crown of

This speaks of older peoples' grandchildren being a sign of honor for them as if their grandchildren were a crown. AT: "bring honor and respect to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the aged

This refers to older people. AT: "those who are older" or "older people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 17:07

#### Eloquent speech

"Fine speech" or "Excellent speech"

#### much less are lying lips suitable for royalty

This describes people lying as if it were actually their "lips" that were lying. AT: "even more it is not suitable for royalty to lie" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### A bribe is like a magic stone to the one who gives it

This speaks of a person's bribe working by comparing it to a magical stone or amulet. AT: "A bribe works like a magical stone for the one who gives it" or "A bribe works like magic for the one who is giving the bribe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### wherever he turns

Here "turning" refers to the various things the person does. Specifically, this refers to the different things the person does by bribery. AT: "in whatever he does" or "in everything he tries to do by giving bribes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]

### Proverbs 17:09

#### offense

something that hurts or angers a person

#### who repeats a matter

This refers to bringing up a past situation in which a friend was hurt or offended. AT: "who repeats a past offense" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### alienates

"separates"

#### A rebuke goes deeper into a person ... than a hundred blows go into a fool

This compares how a rebuke effects a man of understanding to how a beating effects a fool. This speaks of the effect on these people as if it could be measured by the depth that it goes into them. AT: "A rebuke has more effect on a person ... than a hundred blows have on a fool" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a person who has understanding

"a person who has good judgment." The word "understand" can be expressed as a verb. AT: "a person who understands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### a hundred blows go

"a beating of a hundred blows goes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 17:11

#### seeks rebellion

The word "rebellion" can be expressed as a verb. AT: "seeks to rebel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### a cruel messenger will be sent against him

This can be stated in active form. AT: "a cruel messenger will come against him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will be sent against him

To be "sent against" someone means to be sent to harm them. AT: "will be sent to harm him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a bear robbed of her cubs

This can be stated in active form. AT: "a bear who has just lost her cubs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in his foolishness

The word "foolishness" can be expressed as an adjective. AT: "who is acting foolish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 17:13

#### evil will never leave his house

Here "evil" is spoken of as if it were a person who would not leave the man's house. Here the word "house" may be taken literally, but it is also a metonym for his family. AT: "bad things will continue to happen to him and his family" or "bad things will never stop happening to him and his family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The beginning of conflict is like one who releases water everywhere

This compares how easily a conflict spreads to how spilled water flows everywhere. AT: "Starting a conflict is like pumping water and letting it run everywhere" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### has broken out

"starts"or "begins"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Proverbs 17:15

#### The person who acquits the wicked person and the person who condemns the righteous person

"The one who acquits wicked people and the one who condemns the righteous"

#### acquits

justifies, declares someone not guilty

#### Why should a fool pay money to learn about wisdom, when he has no ability to learn it?

This rhetorical question emphasizes that the fool should not do this. This question may be written as a statement. AT: "A fool should not pay money to learn about wisdom because he does not have the ability to learn it." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 17:17

#### a brother is born for times of trouble

One of the purposes of a brother is to be there to help his brother or sister in times of trouble. AT: "a brother is there for times of trouble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no sense

"no good judgement"

#### binding promises

This refers to promises that must be kept and are often a burden on the person who made them.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Proverbs 17:19

#### causes bones to be broken

This means that someone will trip on the threshold and break bones, probably in their foot. AT: "is sure to cause someone trip and break their the bones in their foot" or "is sure to cause someone to trip and injure himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who has a crooked heart

The "heart" represents a person's feelings, attitudes and motivations. AT: "who is deceptive" or "who is dishonest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has a perverse tongue

The "tongue" represents a person's speech. AT: "speaks perversely" or "speaks wickedly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### falls into calamity

"falls into trouble" To "fall into" something means to get into that situation. AT: "will have calamity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/threshold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/threshold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]

### Proverbs 17:21

#### A cheerful heart is good medicine

This speaks of a cheerful heart as being good medicine because it makes you feel better. AT: "A cheerful heart is like medicine that makes you feel better" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### A cheerful heart

The "heart" represents a person's feelings, attitudes and motivations. AT: "Being cheerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a broken spirit

Here the "spirit" represents a person's feelings and emotional state. A broken spirit refers to a poor emotional state. AT: "depression" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### dries up the bones

A person's bones represent their physical health and strength. If a person's bones dry up it means that they are very sick and unhealthy. AT: "makes a person unhealthy and weak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Proverbs 17:23

#### to pervert the ways of justice

"to prevent justice from being rendered" or "to pervert justice"

#### sets his face toward wisdom

This speaks of a person's focus on acting wisely as if he were looking at wisdom. AT: "focuses on acting wisely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the eyes of a fool are

This refers to a fool by his eyes to emphasize what he is focusing on. AT: "the fool is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the ends of the earth

This speaks of a fool's impossible dreams as if they were the ends of the earth to emphasize that they are unrealistic. AT: "strive for things that are as far from him as the ends of the earth" or "focus on impossible things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Proverbs 17:25

#### A foolish son is a grief to his father

This speaks of a son causing his father grief as if the son himself were "grief." AT: "A foolish son brings grief to his father"

#### A foolish son ... and bitterness to the woman

This speaks of a son causing his mother bitterness as if the son himself were "bitterness." AT: "A foolish son ... and brings bitterness to the woman"

#### who bore him

"who gave birth to him"

#### bitterness

emotional pain, sorrow

#### it is never good ... neither is it good

These statements can be written in positive form. AT: "it is always wrong ... and it is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### the righteous person

Another possible meaning is "the innocent person," anyone whom others have accused of a crime that he did not commit.

#### flog

whip severely

#### who have integrity

The word "integrity" can be expressed with the adjective "honest." AT: "who are honest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]

### Proverbs 17:27

#### uses few words

This refers to the way he speaks. AT: "speaks with few words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Even a fool is thought to be wise

This can be written in active form. AT: "People even think a fool is wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### keeps his mouth shut

This means that he does not speak. AT: "does not speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he is considered to be intelligent

This can be written in active form. AT: "people consider him to be intelligent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 17:intro

#### Proverbs 17 General Notes ####

####### Structure and formatting #######

Chapter 17 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########
There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 17:01 Notes](./01.md)__

__[<<](../16/intro.md) | [>>](../18/intro.md)__


## Proverbs 18

### Proverbs 18:01

#### isolates himself

"keeps away from other people"

#### quarrels with all sound judgment

This speaks of a person disagreeing with sound judgment as if "sound judgment" were a person he fought with. AT: "he disagrees with all sound judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### sound judgment

"good judgment" or "wise choices"

#### A fool finds no pleasure in understanding, but only

"A fool does not care about understanding, but only about" This means the fool considers "understanding" the opposite of pleasure. AT: "A fool detests understanding and only finds pleasure in" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### but only in revealing what is in his own heart

This means that the fool only finds pleasure in telling other people what he feels and desires in his heart. AT: "but only in telling others what is in his own heart" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### what is in his own heart

The contents of a person's heart refers to the person's thoughts and feelings. AT: "what he thinks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 18:03

#### contempt comes with him—along with shame and reproach

Here "contempt," "shame," and "reproach" are spoken of as if they are people who accompany a wicked man. Possible meanings are 1) people show contempt towards the wicked man and cause him to feel shame and reproach. AT: "people feel contempt for him along with shame and reproach" or 2) the wicked man shows contempt for others and causes them to feel shame and reproach. AT: "he shows his contempt for other people and causes them to feel shame and reproach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### shame and reproach

These two words have similar meaning and are used together to emphasize the "shame" felt by either the wicked man or other people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### The words of a man's mouth are deep waters; ... the fountain of wisdom is a flowing stream

These two lines are parallel and it is implied that the man in the first line is a wise man. AT: "The words of a wise man's mouth are deep waters; ... the fountain of wisdom is a flowing stream" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The words of a man's mouth are deep waters

This speaks of a wise man's words being profound as if they were profound and as deep as deep waters. AT: "The words of a man's mouth are as profound as deep waters" or "The words of a man's mouth are deep and profound" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a man's mouth

Here the man is referred to by his mouth to emphasize what he says. AT: "of a man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the fountain of wisdom is a flowing stream

This speaks of the source of wisdom being plentiful as if it were a gushing spring. The gushing of the spring is spoken of as if it were a flowing stream. AT: "the source of wisdom is as plentiful as the water of a gushing spring" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/contempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reproach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reproach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 18:05

#### It is not good to ... to the righteous person

These phrases can be written in positive form. AT: "It is good to treat the wicked person as he deserves, and to be just to the righteous person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### A fool's lips bring

Here the fool is referred to by his "lips" to emphasize what he says. AT: "what a fool says brings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### bring

"cause"

#### his mouth invites a beating

This speaks of the fool saying things that cause people to want to beat him as if he were inviting them to beat him. AT: "his mouth makes people want to beat him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his mouth

Here what the fool says is referred to as his "mouth." AT: "what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 18:07

#### A fool's mouth ... with his lips

Both of these phrases refer to what a fool says. AT: "What a fool says ... by what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### is his ruin

"will ruin him"

#### he ensnares himself

This speaks of the man causing problems and trouble for himself as if he were trapping himself like a man traps an animal. AT: "he will cause problems for himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The words of a gossip are like delicious morsels

This speaks of the words of a gossip being desirable to listen to as if they were delicious food to eat. AT: "The words of a gossip are desirable to listen to" or (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### The words of a gossip

This refers to what a gossiping person says. AT: "The words that a gossiping person speaks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md)]])

#### morsels

small bites of food

#### they go down into the inner parts of the body

This speaks of the words of a gossip going into a person's mind and affecting his thoughts as if they were food that was going into his stomach. AT: "and they enter a person's mind and affect his thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md)]]

### Proverbs 18:09

#### one who is slack in his work is a brother to the one who destroys

This speaks of the one who is slack being similar to the one who destroys as if they were actually related. AT: "is closely related to" or "is very similar to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### is slack

"is lazy" or "is not interested"

#### the one who destroys the most

"the one who destroys everything" or "the one who is always destructive"

#### The name of Yahweh is a strong tower

This speaks of Yahweh protecting his people as if he were a strong tower in which they could take refuge. AT: "Yahweh protects like a strong tower" or "Yahweh protects his people like a strong tower" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The name of Yahweh

Here Yahweh is referred to by his name. AT: "Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the righteous

This refers to righteous people. AT: "those who are righteous" or "righteous people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### runs into it and is safe

This speaks of people seeking safety from Yahweh and Yahweh protecting them as if he were a strong tower that they ran into for safety. AT: "run to him and they are safe" or "seek him and they are safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Proverbs 18:11

#### The wealth of the rich is his fortified city

This speaks of a rich person depending on his wealth as if his wealth were a fortified wall that protects him. AT: "The wealthy person depends on his wealth as a city depends on its fortified wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the rich

This refers to people who are rich. AT: "the rich person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### fortified city

a city with strong defenses like walls and towers

#### in his imagination it is like a high wall

This speaks of the rich person believing his wealth will keep him safe like a high wall keeps those inside a city safe. AT: "he thinks it protects him as well as a high wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Before his downfall a person's heart is proud

"First a person's heart is proud, but then comes his downfall"

#### downfall

This refers to a significant decline in a person's reputation or health.

#### a person's heart

Here a person is referred to by his heart to emphasize his thoughts and feelings. AT: "a person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### humility comes before honor

The word "humility" may be expressed as an adjective and the word "honor" may be expressed as a verb. AT: "a person must be humble before he can be honored" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 18:13

#### it is his folly and shame

The abstract nouns "folly" and "shame" may be expressed as adjectives. AT: "it is foolish of him, and he should be ashamed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### A person's spirit will survive sickness

Here a person is referred to by his spirit to emphasize his attitude. AT: "A person who is hopeful will survive sickness" or "If a person is full of hope in his inner being, he will survive being sick" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### but a broken spirit who can bear it?

This is a rhetorical question, expecting the answer that few can bear it. This can be written as a statement. AT: "but it is very hard to bear a broken spirit." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### a broken spirit

This refers to being depressed. AT: "being depressed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Proverbs 18:15

#### The heart of the intelligent acquires

Here the intelligent person is referred to by his heart to emphasize his desires. AT: "The intelligent desire to acquire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the intelligent

This refers to people who are intelligent. AT: "those who are intelligent" or "intelligent people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### acquires

"gains" or "obtains"

#### the hearing of the wise seeks it out

Here the wise person is referred to by his hearing to emphasize what he desires to listen to. AT: "the wise seeks to learn about it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the wise

This refers to people who are wise. AT: "those who are wise" or "wise people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### seeks it out

Here the word "it" refers to "knowledge"

#### may open the way

Here to "open the way" means to create an opportunity. AT: "may create an opportunity for him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### bring him before

This means to be allowed to see someone. AT: "let him meet" or "let him be introduced to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]

### Proverbs 18:17

#### The first to plead his case

This refers to the person who pleads his case before his opponent pleads his case. AT: "The first person to plead his case" or "The person who pleads his case first" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### Casting the lot

"Casting lots"

#### separates strong opponents

This refers to people who are fighting harshly over a dispute. When they are separated, they are no longer fighting over their dispute. AT: "causes opponents to stop fighting over their dispute" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]

### Proverbs 18:19

#### An offended brother is harder to be won than a strong city

This speaks of the difficulty of making peace with a brother you have offended by comparing it to the difficulty of winning a war against a strong city. AT: "If you offend your brother, finding a way to have peace with him again may be harder than waging a battle to win a city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### quarreling is like the bars of a castle

This speaks of the difficulty of resolving quarreling by comparing it to the difficulty of breaking down the bars of a castle. AT: "resolving quarreling is as difficult as breaking down the bars of a castle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### castle

a fortified palace

#### From the fruit of his mouth one's stomach is filled; with the harvest of his lips he is satisfied

These two lines have the same meaning and are used together to emphasize what is said. They can be combined. AT: "A person is satisfied by the results of the good things that he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the fruit of his mouth

This speaks of the good things that a person says as if they were fruit that came from his mouth. AT: "his wise speech" or "his good words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### one's stomach is filled

This speaks of a person being satisfied or content by the result of what they have said as if they had eaten and become satisfied" AT: "a person is satisfied" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the harvest of his lips

This speaks of the good things that a person says as if they were fruit that is harvested. AT: "his wise speech" or "his good words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he is satisfied

"he is pleased"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Proverbs 18:21

#### Death and life are controlled by the tongue

This can be written in active form. AT: "The tongue can lead to life of death" or "What people say can lead to life or death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by the tongue ... love the tongue

Here the "tongue" refers to speech. AT: "by what people say ... love speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will eat its fruit

This speaks of a person receiving the consequence for what he says as if the consequences were fruit that he receives. AT: "will receive its consequences" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 18:23

#### many friends is brought to ruin by them

This can be stated in active form. AT: "many friends--they will bring him to ruin" or "many friends--his friends will destroy him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### comes closer than

"is more faithful than" or "stays more loyal than"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]

### Proverbs 18:intro

#### Proverbs 18 General Notes ####

####### Structure and formatting #######

Chapter 18 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__


## Proverbs 19

### Proverbs 19:01

#### Better is a poor person

"It is better to be a poor person"

#### who walks in his integrity

This is an idiom. Here walking refers to living. AT: "who lives in his integrity" or "who lives an honest life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### is perverse in speech

The word "speech" may be expressed as a verb. AT: "speaks perversely" or "speaks in an evil way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### to have desire without knowledge

This refers to people trying to do something without the knowledge for how to correctly do it. AT: "to work hard without knowing what you are doing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the one who runs too fast misses the path

This speaks of a person doing something too quickly and making mistakes as if running too quickly and missing the path. AT: "the one who acts too quickly makes mistakes" or "the one who acts too quickly makes poor choices" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 19:03

#### his heart rages

Here a person is referred to by his "heart" to emphasize his emotions. AT: "he rages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Wealth adds many friends

This means that a person who is wealthy will have many friends because wealth attracts people. The full meaning of this can be made clear. AT: "Those who are wealthy easily find many friends" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a poor person is separated from his friends

A poor person is separated from many of his friends because of his poverty. The meaning of this can be made explicit. AT: "poverty causes a person to lose his friends" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 19:05

#### A false witness will not go unpunished

This can be written in positive and active form. AT: "They will certainly punish a false witness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he who breathes out lies will not escape

This means that he will be captured. AT: "they will capture the one who breathes out lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### breathes out lies

This is an idiom. Here "breathes" refers to lying constantly. See how you translated this phrase in [Proverbs 6:19](../06/17.md). AT: "constantly lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a generous person

someone who often gives away things

#### everyone is a friend

The word "everyone" is an exaggeration. AT: "it seems that everyone is a friend" or "almost everyone is a friend" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]

### Proverbs 19:07

#### how much more do his friends who go far away from him!

This phrase is an exclamation to show that this is more likely than the previous phrase. AT: "therefore his friends will certainly hate him and go far away from him!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### loves his own life

Here the person is referred to by his "life" to emphasize himself being alive. AT: "loves himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### keeps understanding

"has understanding"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Proverbs 19:09

#### A false witness will not go unpunished

This can be written in positive and active form. See how you translated this phrase in [Proverbs 19:5](./05.md). AT: "They will certainly punish a false witness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### breathes out lies

This figure of speech uses "breathes" to refer to lying constantly. See how you translated this phrase in [Proverbs 6:19](../06/17.md). AT: "constantly lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### It is not fitting

"It is not right"

#### luxury

condition of wealth and pleasure

#### much less for a slave

The words "it is" and "fitting" are understood from the previous phrase. They can be repeated. AT: "it is much less fitting for a slave" or "it is even worse for a slave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Proverbs 19:11

#### Discretion makes a person slow to anger

"A person who has discretion is slow to become angry"

#### Discretion

This means to know what should be done in a particular situation. See how you translated this word in [Proverbs 1:4](../01/04.md).

#### it is his glory to overlook

"it will bring him glory to overlook" or "others will consider it honorable if he overlooks"

#### to overlook

to forget on purpose

#### The wrath of the king is like the roaring of a young lion

Here the lion's roaring refers to attacking. The wrath of a king is compared to the unpredictable and dangerous attack of a young lion. AT: "The wrath of the king is as dangerous as the attack of a young lion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but his favor is like dew on the grass

The favor of the king is compared to the refreshing water that appears on grass in the morning. AT: "but his favor is refreshing like dew on grass" or "but his favor is refreshing like the dew on the ground in the morning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]

### Proverbs 19:13

#### is ruin to his father

"will ruin a father"

#### a quarreling wife is a constant dripping of water

This speaks of an annoying wife as if she were the constant dripping of water. AT: "a quarreling wife is as annoying and distracting as a constant dripping of water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a quarreling wife

"an arguing wife" or "a disagreeing wife"

#### A house and wealth are inherited from parents

This can be stated in active form. AT: "Children inherit a house and wealth from their parents" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### prudent

See how you translated this word in [Proverbs 12:23](../12/23.md).

#### a prudent wife is from Yahweh

This can be stated in active form. AT: "Yahweh gives a prudent wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 19:15

#### Laziness throws a person into a deep sleep

This speaks of how laziness causes a person to sleep a lot as if laziness forcefully throws the person into sleep. AT: "Laziness makes a person sleep a lot" or "A lazy person sleeps a lot" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### go hungry

This is an idiom which means to not eat. AT: "not eat" or "be hungry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the command

"the command that he was taught"

#### guards his life

"protects his life"

#### his ways

This is an idiom which refers to how he lives. AT: "the way that he lives" or "how he lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 19:17

#### Whoever is kind to the poor lends to Yahweh

Yahweh considers kindness shown to the poor to be kindness shown to him. One of the ways people are kind to the poor is by giving. AT: "The person who gives to the poor is giving to Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the poor

This refers to poor people. AT: "those who are poor" or "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### while there is hope

This refers to while the child is young and will still accept discipline and instruction. The full meaning of this can be made clear. AT: "while he is young" or "while he can still be taught" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### and do not set your desire on putting him to death

Possible meanings are 1) this phrase describes punishing your child. AT: "but do not punish him so severely that he might die" or 2) this phrase describes what it is like if you do not punish your child. AT: "for if you do not punish him you are helping him destroy himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### set your desire on putting him

This idiom means to be determined to cause something to happen. AT: "be determined to put him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 19:19

#### A hot-tempered person

This idiom refers to a person who is easily angered. AT: "A person who does not control his temper" or "A person who becomes angry quickly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### must pay the penalty

This refers to the person bearing the consequences for what happens when he gets angry. The full meaning of this statement can be made clear. AT: "must bear the consequences of his anger" or "must bear the consequences of what he does in his anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### if you rescue him

"if you save him." This refers to rescuing him when he has acted out of his anger. The meaning of this can be made explicit. AT: "if you rescue him after he has had an outburst" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a second time

"another time" or "again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Listen to advice and accept instruction

These two phrases mean basically the same and are repeated to emphasize how important it is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Listen to advice

This is an idiom. Here "listening" does not mean to merely listen, but to learn from the advice you are given and to follow it. AT: "Pay attention to advice" or "Follow advice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 19:21

#### in a person's heart

Here the "heart" is used to refer to the "mind" to emphasize a person's desire. AT: "in a person's mind" or "that a person desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the purpose of Yahweh

"Yahweh's purpose" or "Yahweh's plans"

#### that will stand

This idiom means to "happen." AT: "that will happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 19:23

#### Honor for Yahweh leads people to life; anyone who has it will be satisfied

This means that they will live a long time if they honor Yahweh. The full meaning of this statement can be made clear. AT: "Those who honor Yahweh will live a long time; anyone who honors Yahweh will be satisfied" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### anyone who has it

Here the word "it" refers to "honor for Yahweh."

#### satisfied and not afflicted by harm

This can be stated in active form. AT: "satisfied; nothing will harm him" or "satisfied; he will be safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sluggard

See how you translated this word in [Proverbs 10:26](../10/26.md).

#### buries his hand in the dish

"dips his hand in the dish" or "puts his hand in his plate." In the Biblical culture people usually ate with their hands as people do in many cultures today.

#### he will not even bring it back up to his mouth

He does not bring his hand back to his mouth because he is too lazy. AT: "but he is too lazy to bring his hand up to his mouth to feed himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]

### Proverbs 19:25

#### Strike a mocker, and the naive person

"If you strike a mocker, the naive person"

#### Strike a mocker

"Punish a mocker"

#### naive person

"inexperienced person" or "immature person"

#### prudent

See how you translated this word in [Proverbs 12:23](../12/23.md).

#### discipline one who is discerning, and

"if you discipline one who is discerning,"

#### he will gain knowledge

The abstract noun "knowledge" can be stated as "know." AT: "he will know more" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 19:26

#### brings shame and reproach

Possible meanings are 1) he brings it to himself. AT: "brings shame and reproach to himself" or 2) he brings it to his family. AT: "brings shame and reproach to his family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If you cease to hear instruction

Here "listening and obeying" is spoken of as if it were "hearing." AT: "If you stop paying attention to instruction" or "If you stop obeying instruction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you will stray from

"you will abandon" or "you will turn your back on"

#### the words of knowledge

"knowledge"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reproach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reproach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 19:28

#### the mouth of the wicked swallows iniquity

This speaks of how wicked people enjoy doing evil by saying that they swallow iniquity as easily as they swallow food. AT: "the wicked enjoy doing evil as much as they enjoy eating food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the mouth of the wicked swallows

The phrase "the mouth of the wicked" represents wicked people. AT: "wicked people swallow" or "the wicked swallow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the wicked

This refers to wicked people. AT: "the wicked person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### Condemnation is ready for mockers and flogging for

The words "condemnation" and "flogging" may be expressed as verbs. AT: "Yahweh is ready to condemn mockers and to flog" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### flogging for the backs of fools

The words "is ready" are understood from the previous phrase and may be repeated. AT: "flogging is ready for the backs of fools" or "he is ready to flog the backs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### flogging

beating with a whip or stick

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 19:intro

#### Proverbs 19 General Notes ####

####### Structure and formatting #######

Chapter 19 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 19:01 Notes](./01.md)__

__[<<](../18/intro.md) | [>>](../20/intro.md)__


## Proverbs 20

### Proverbs 20:01

#### Wine is a mocker and strong drink is a brawler

These two phrases mean basically the same thing and are combined to emphasize the danger of too much alcohol. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Wine is a mocker

Here "wine" refers to the person who is drunk with wine. AT: "A person who is drunk with wine mocks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### strong drink is a brawler

Here "strong drink" refers to a person who is drunk with strong drink. AT: "a person who is drunk with strong drink starts fights" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a brawler

a person who fights noisily, usually in a public place

#### whoever is led astray by drink is not wise

This can be stated in active form. AT: "whoever drinks until they can no longer think clearly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by drink

Here "drink" refers to alcoholic drinks

#### is not wise

This means the opposite of "wise" which is "foolish." AT: "is foolish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### The fear of a king is like the fear of a young lion that is roaring

This compares how people fear a king's wrath to how they fear a young roaring lion. AT: "The king's wrath makes people as afraid as if they were facing a young lion roaring at them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### makes him angry

"makes the king angry"

#### forfeits his life

This refers to being killed. "Life" here refers to physical life. AT: "will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 20:03

#### It is an honor

"It is honorable." This means that a person will be honored.

#### every fool jumps into an argument

This speaks of entering an argument quickly as if the argument were something the fool physically jumped into. AT: "every fool quickly gets into an argument" or "every fool is quick to join an argument" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### plow

to prepare land for planting

#### autumn

"the planting season"

#### but will have nothing

This means that there will be nothing growing in his field for him to harvest. AT: "but will have nothing to harvest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Proverbs 20:05

#### The purpose in a human heart is like deep water

This speaks of how difficult it is to understand the reasons for a person's actions by comparing it to the difficulty of reaching the water in a deep well. AT: "It is as difficult to understand the purpose in the human heart as it is to reach the water in a deep well" or "The purpose of in the human heart is very difficult to understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### someone with understanding

"a person who has understanding"

#### will draw it out

This speaks of figuring out the purpose of the human heart as if it was water being drawn from a deep well. AT: "will cause the purpose to be known" or "will figure it out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### loyal

"faithful" or "trustworthy"

#### but who can find one who is faithful?

The implicit answer is "few can find someone like that." This rhetorical question can be written as a statement. AT: "but few men can find a person who is faithful!" or "but it is hard to find a person who really is faithful!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Proverbs 20:07

#### walks in his integrity

Here walking refers to living. See how you translated this phrase in [Proverbs 19:1](../19/01.md). AT: "lives by his integrity" or "lives an honest life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### his sons who follow after him

This simply means that they "follow after him" since they are younger than he and his children. If this phrase is awkward in your language it may be left to be implied. AT: "his sons after him" or "his sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### is winnowing with his eyes all the evil that is before him

This speaks of the king judging between various types of evil as if he were separating them as a person winnows grain. AT: "sees and sorts the different kinds of evils that are brought before him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winnow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winnow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 20:09

#### Who can say, "I have kept my heart pure; I am clean from my sin"?

The implicit answer to this question is, "No one can say that." This rhetorical question can be written as a statement. AT: "No one can say that his heart is clean and that he is free from sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my heart

Here a person's "heart" refers to his thoughts and desires. AT: "my thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### clean

A person who God considers spiritually acceptable is spoken of as if the person where physically clean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I am clean from my sin

"I am without sin" or "I have not sinned"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 20:11

#### Even a youth is known by his actions

This can be stated in active form. AT: "People know a young man by his actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### whether his conduct is pure and upright

"whether his conduct is pure and upright or not"

#### his conduct

"his deeds" or "what he does"

#### pure and upright

These two words basically mean the same thing and emphasize how good this young person is. They can be combined into one word if necessary. AT: "pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Ears that hear and eyes that see

The same thought is repeated to emphasize that Yahweh made all our senses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 20:13

#### come to poverty

The phrase "come to" here means to transition into a new situation; to become. AT: "become poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### open your eyes

Here "opening one's eyes" is spoken of as "being awake." AT: "stay awake" or "be alert" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### "Bad! Bad!" says the buyer, but when he goes away he boasts

Here a buyer is criticizing what someone is selling to get a low price from him. After he buys he boasts about the good price that he pursuaded the seller to give him. The full meaning of this can be made clear. AT: "'Bad! Bad!' says the buyer criticizing the seller's wares, but after he buys he goes away he boasting about the low price that he paid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]

### Proverbs 20:15

#### lips of knowledge are a precious jewel

This speaks of the value of lips of knowledge by comparing them to a precious jewel. AT: "lips of knowledge are as valuable as an expensive jewel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lips of knowledge

Here "words" are referred to as "lips." AT: "wise words" or "words of knowledge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Take a garment of one who has put up security for a stranger

When lending money, the lender would take something from the borrower, such as a garment, as a guarantee of repayment. He would return it after the money was repaid. If the borrower was too poor, someone else could give something to the lender as a guarantee for him. The full meaning of this statement can be made clear. AT: "Take a garment as security from the one who guarantees that what a stranger has borrowed will be paid back" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### puts up security

This is an idiom. It means that someone gives something to a lender as a guarantee that what was borrowed will be paid. AT: "guarantees that what has been borrowed will be paid back" or "promises to pay a loan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### hold it in pledge

This is an idiom. To "hold something in pledge" means to hold on to something that someone has given as a pledge, or promise, that he will pay a debt. AT: "hold onto his coat as a guarantee of repayment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]

### Proverbs 20:17

#### Bread gained by deceit

This can be stated in active form. AT: "Bread that someone gained by deceit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by deceit

The word "deceit" can be expressed as a verb. AT: "by deceiving others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Bread

Here "bread" refers to food in general. AT: "Food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### tastes sweet

"tastes good"

#### but afterward his mouth will be full of gravel

This speaks of the food tasting unpleasant as if his mouth were actually full of gravel instead of food. AT: "but afterwards it tastes like gravel in his mouth" or "but soon it tastes like sand in his mouth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### gravel

small pieces of rock

#### Plans are established by advice

This can be stated in active form. AT: "People establish plans based on advice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 20:19

#### A gossip

This means someone who gossips a lot.

#### you should not associate with

"you should not be friends with"

#### If a person curses

This means if a someone express a desire that bad things will happen to someone else.

#### his lamp will be snuffed out in the middle of darkness

This speaks of a person dying suddenly and unexpectedly as if his life were a lamp snuffed out in the dark. AT: "his life will end as suddenly as the light of a lamp that is snuffed out in the dark" or "he will die suddenly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his lamp will be snuffed out

This can be stated in active form. AT: "his lamp will go out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his lamp

This refers to a lamp with a burning flame. Here the lamp's flame is referred to as the lamp itself. AT: "the flame of his lamp" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### snuffed out

to cause a flame to go out

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]

### Proverbs 20:21

#### at the beginning

This refers to a person receiving his inheritance before he is supposed to receive it. The full meaning of this statement can be made clear. AT: "before the right time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will pay you back

This means to do wrong to someone because they have done wrong to you. AT: "I will punish you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Wait for Yahweh

This means to have faith that Yahweh will deal with the situation. AT: "Have faith in Yahweh" or "Hope in Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 20:23

#### Yahweh hates unequal weights and dishonest scales are not good

These two phrases basically mean the same thing and are combined to emphasize how bad this is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### A person's steps are directed by Yahweh

This can be stated in active form. AT: "Yahweh directs a person's steps" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### A person's steps

This refers to the various things a person does. AT: "A person's actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### how then can he understand his way?

The implicit answer is that he cannot understand it. This rhetorical question may be written as a statement. AT: "therefore, a person cannot understand his way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### understand his way

This is an idiom. The phrase "his way" refers to the person's life. AT: "understand why some things happen in his life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Proverbs 20:25

#### It is a snare

This speaks of something being dangerous as if it were a trap or a snare. AT: "It is dangerous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to say rashly

to say something quickly and without careful consideration of what it might mean

#### making his vow

The person has made a vow declaring that something is holy and dedicated to Yahweh. AT: "dedicating it to Yahweh" or "declaring it holy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### winnows the wicked

This speaks of the king separating the wicked people as if they were grain that he was winnowing. AT: "separates the wicked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the wicked

This refers to wicked people. AT: "those who are wicked" or "the wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### he turns a threshing wheel over them

This speaks of the king punishing the wicked as if he were driving a threshing wheel over them. AT: "he severely punishes them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### threshing wheel

"threshing cart." This is a tool used to crush grain and help separate it from the chaff.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winnow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winnow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]

### Proverbs 20:27

#### The spirit of a person is the lamp of Yahweh, searching all his inmost parts

This speaks of a person's spirit as if it were a lamp. A person's spirit helps him to understand his inner self. AT: "Yahweh has given us a spirit to understand our deepest selves, just as a lamp makes you see in the dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Covenant faithfulness and trustworthiness preserve the king

The abstract nouns "faithfulness" and "trustworthiness" can be stated as "faithful" and "trustworthy." This can also be stated in active form. AT: "The king preserves himself by being trustworthy and faithful to the covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### preserve the king

keep the king safe from harm

#### his throne is made secure by love

Here "throne" represents the king's power to rule. The abstract noun "love" can be stated as a verb. Also, this can be stated in active form. AT: "a king ensures that he will rule for a long time by loving others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Proverbs 20:29

#### Blows that make a wound cleanse away evil and beatings make the innermost parts clean

Both statements mean the same thing and are repeated for emphasis. Using physical punishment to correct a person is spoken of as if the evil were dirt and the beatings cleansed him. AT: "Beating a person who has done wrong will correct him and cause him to be a better person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 20:intro

#### Proverbs 20 General Notes ####

####### Structure and formatting #######

Chapter 20 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__


## Proverbs 21

### Proverbs 21:01

#### The king's heart is a stream of water in the hand of Yahweh

The writer speaks of the king's heart as if it were an irrigation ditch in a dry area through which people direct water to plants that need it. AT: "Yahweh controls the king's heart as a man directs water for irrigation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The king's heart

The heart is a metaphor for what a person thinks and what he wants to do. AT: "The king's thoughts and actions" or "What the king thinks and what he wants to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Every person's way is right in his own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. The writer speaks of what a person does as if it that person were walking down a path. AT: "Every person thinks that what he does is good" or "Every person judges what he does as good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who weighs the hearts

The writer speaks of Yahweh deciding whether a person desires to do what is right as if Yahweh were looking at a physical object and deciding whether it is of good quality. AT: "who will judge the motives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 21:03

#### To do what is right

"To do what Yahweh thinks is right"

#### To do what is ... just

"To treat people the way Yahweh wants people to treat other people"

#### just is more acceptable to Yahweh

"just—Yahweh wants this more"

#### Haughty eyes and a proud heart

The words "eyes" and "heart" are synecdoches for a person who considers himself better than other people and wants other people to know it. AT: "People who want others to think that they are better than other people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Haughty eyes

This is a synecdoche for a person who wants others to know that he thinks he is better than they are. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### proud heart

This is a synecdoche for a person who thinks he is better than others. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the lamp of the wicked

The things that help the wicked are spoken of as a lamp. AT: "the things that help a wicked person like a lamp helps to see in the dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Proverbs 21:05

#### the diligent

This nominal adjective can be translated as a noun phrase. AT: "a diligent man" or "a man who works hard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### comes only to poverty

The abstract noun "poverty" can be translated as an adjective. AT: "only becomes poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Acquiring riches

"Gaining wealth"

#### a lying tongue

The tongue is a metonym for the words a person uses the tongue to speak. AT: "speaking lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a fleeting vapor

The writer likens the riches a person gains by lying to a mist that quickly goes away in the morning. AT: "a disappearing mist" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a snare that kills

The writer speaks of the riches that a person gains by lying as if it were the bait in a hunter's trap; the word "snare" is a metonym for the bait that attracts the animal into the snare. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]

### Proverbs 21:07

#### The violence of the wicked will drag them away

The writer speaks as though violence were a person who could drag other people away. God will punish wicked people who harm their innocent neighbors. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### violence of the wicked

The abstract noun "violence" refers to violent deeds or things people do to harm their innocent neighbors. The word "wicked" is a nominal adjective that refers to wicked people. AT: "The violent actions of wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### drag them away

This phrase refers to dragging a net through water to catch fish. The wicked being destroyed by their own actions is spoken of as if their actions trapped them in a net like one would catch fish. AT "drag them away like fish" or "destroy them as easily as one catches fish in a net" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The way of a guilty person is crooked

This compares the way one lives to a crooked road one may travel. This is also an idiom. AT: "The way a guilty person lives is crooked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### crooked

Here "crooked" means bent or not straight. This is a metaphor for morally wrong. AT: "wrong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]

### Proverbs 21:09

#### a corner of the roof

Houses in those days had flat roofs. Ancient Israelites spent much time on their roofs, where it was often cooler than inside the house, and sometimes people would build a shelter large enough for a person to sleep in on one corner of the roof. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### quarrelsome

a person who often argues or complains

#### The appetite of the wicked craves evil

The writer speaks of a person's appetite, the physical desire for food and drink, as if it were a person who could desire something. The word "wicked" is a nominal adjective that refers to evil people, and the word "evil" is a nominal adjective that refers to evil deeds. AT: "Evil people desire to do evil deeds just as they desire to eat and drink" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### craves

"strongly desires"

#### his neighbor finds no favor in his eyes

The idiom to "find favor" means to have someone approve of and act kindly towards the one who finds favor. Also, the eyes represent seeing, and seeing represents a person's thoughts and attitude towards another person. AT: "his neighbor does not receive favor from him" or "he does not act kindly towards his neighbor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Proverbs 21:11

#### When the mocker is punished

This can be translated in active form. AT: "When someone punishes the mocker" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### naive

inexperienced or immature

#### the mocker

"the person who mocks others"

#### when the wise person is instructed

This can be translated in active form. AT: "when someone instructs the wise person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### lays hold of knowledge

Here knowledge is spoken of as if it were an object that someone could grasp and keep for himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The righteous

Possible meanings are 1) any righteous person or 2) "Yahweh the one who is righteous."

#### watches

"pays careful attention to"

#### he brings wicked people to disaster

Here disaster is spoken of as if it were a place that someone could be brought to. AT: "he destroys them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]

### Proverbs 21:13

#### The one who shuts his ears to the cry of the poor

This is an idiom. AT: "The one who will not listen when poor people ask for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he will not be answered

The word "answered" is a metonym for a person hearing another person ask for help and acting to help. This can be translated in active form. AT: "no one will do anything to help him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### appeases anger

"makes an angry person feel better so he is no longer angry"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Proverbs 21:15

#### When justice is done

The abstract noun "justice" can be translated as a noun phrase. These words can be translated in active form. AT: "When rulers do what is just" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### wanders from the way of understanding

This is an idiom. AT: "no longer lives wisely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he will rest in the assembly of the dead

"he will remain in the assembly of dead spirits"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Proverbs 21:17

#### is ransom for

The word "ransom" is a metaphor for one person who takes the place of another person. Here the person who does what is wrong is punished instead of the person who does what is right. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the treacherous

a person who harms those who trust him by lying and otherwise dealing falsely

#### upright people

"righteous people" or "honest people" or "just people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md)]]

### Proverbs 21:19

#### wise

This nominal adjective can be translated as a noun phrase. AT: "wise person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### wastes them

"uses them all"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 21:21

#### scales the city

"climbs up and over the wall that surrounds the city"

#### the city of the mighty ones

"a city in which mighty men are living" or "a city of mighty warriors"

#### he brings down

This is an idiom. AT: "he destroys" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the stronghold in which they trusted

"the walls and towers around the city that they did not think anyone would be able to get past into the city, so they felt safe"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]

### Proverbs 21:23

#### Whoever guards his mouth and tongue

Both "mouth" and "tongue" refer to what a person says. AT: "Whoever is careful in what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The proud and haughty person ... acts with arrogant pride

"You can expect a proud and haughty people to act with arrogant pride"

#### proud and haughty

These two words mean basically the same thing and emphasize how prideful the person is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### "Mocker" is his name

The word "name" is a metonym for what people would call him. AT: "a mocker is what you should call him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md)]]

### Proverbs 21:25

#### The desire of the lazy kills him

The writer speaks of what a person wants as if it were a person who could kill a lazy person. Here the lazy person wants to be idle and not work. AT: "A lazy person only wants to be idle, and because of that he will die" or "A lazy person will die because he does not want to work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### his hands refuse

The hand is a synecdoche for the person. AT: "he refuses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### craves

"wants greatly" or "desires strongly"

#### gives and does not hold back

The phrase "does not hold back" can be stated positively, and what he gives can be made explicit. AT: "gives everything he should" or "gives generously" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Proverbs 21:27

#### The sacrifice of the wicked is detestable

The writer does not mention Yahweh here, as in [Proverbs 15:8](../15/07.md), but the reader should understand that it is Yahweh who detests the sacrifice of the wicked.

#### the wicked

The nominal adjective "wicked" can be translated as a noun phrase. AT: "the wicked person" or "wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### it is even more detestable

"Yahweh detests the sacrifice even more"

#### will speak for all time

This is because people will never forget what he said.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/detestable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/detestable.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Proverbs 21:29

#### makes his face hard

Possible meanings are 1) "pretends to be courageous" or 2) "will not listen to correction." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### is certain about his ways

A person's actions are spoken of as if they were a path upon which the person walks. AT: "is certain about what he does" or "is confident about what he does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 21:30

#### There is no wisdom, there is no understanding, and there is no advice that

The words "there is" are repeated to emphasize the abstract nouns "wisdom," "understanding," and "advice." Yahweh is greater than anything that anyone can know or think or say. Your language may require that you not repeat "there is no." The abstract nouns can be translated as adjectives or verbs. AT: "There is no wise person, there is no one who understands anything, and there is no one who tells others what to do who" or "There is no wisdom, understanding, or advice that" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### stand against Yahweh

"defeat Yahweh" or "work against what Yahweh wants to do" or "show that he is right and Yahweh is wrong"

#### The horse is prepared for the day of battle

These words can be translated in active form. AT: "Soldiers prepare horses for the day of battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the day of battle

The word "day" refers to time that may be longer or shorter than a day. AT: "when there is a battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Proverbs 21:intro

#### Proverbs 21 General Notes ####

####### Structure and formatting #######

Chapter 21 continues the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 21:01 Notes](./01.md)__

__[<<](../20/intro.md) | [>>](../22/intro.md)__


## Proverbs 22

### Proverbs 22:01

#### A good name is to be chosen over great riches

These words can be translated in active form. AT: "A person should choose a good name rather than great riches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### A good name

"To have others think that one is a good person"

#### have this in common

"are alike in one way" or "are the same in this way"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 22:03

#### A prudent man

"A man who is wise" or "A man who has good sense." See how you translated "prudent" in [Proverbs 12:16](../12/15.md).

#### the naive

"the inexperienced and immature"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 22:05

#### Thorns and snares lie in the path of the perverse

The writer speaks of the way perverse people live as if it were a path on which the perverse will have trouble because of the natural "thorns" and man-made "snares." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### snares

traps to catch animals

#### the perverse

This nominal adjective can be translated as a noun phrase. AT: "perverse people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### whoever guards his life

A person doing what he needs to do so he can live a long time is spoken of as if that person were keeping thieves away from a physical object. AT: "people who want to live a long time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the way he should go

How a person lives is spoken of as if it were a path on which he walks. AT: "how he should live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perverse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]

### Proverbs 22:07

#### borrows ... lends

You may need to make explicit what it is that is borrowed or lent. AT: "borrows money ... lends money" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He who sows injustice will reap trouble

The writer speaks of a ruler or other powerful person treating those less powerful unjustly as if he were planting seeds that will give birth to plants that bring trouble. AT: "If a person treats those less powerful than he is unjustly, they will cause him trouble later on" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the rod of his fury will fade away

The word "rod" is a metonym for power over other people. Possible meanings are 1) the unjust ruler will lose the power that he had that allowed him to treat other people unjustly or 2) when the people respond to the injustice he had done by harming him, he will have no power to stop them. AT: "he will no longer have the power that he had used to harm people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### rod of his fury

The word "rod" is a metonym for power over other people. The unjust man was harming innocent people as if he were very angry with them. AT: "the rod he had used as if he were punishing people" or "the power he used to harm others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will fade away

The word translated "fade away" is also used of plants drying up.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Proverbs 22:09

#### The one who has a generous eye will be blessed

These words can be translated in active form. AT: "God will bless the one who has a generous eye" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### one who has a generous eye

The eye is a metonym for seeing what other people need, and the "generous eye" not only sees but gives what the other people need. The eye is also a synecdoche for the whole person. AT: "generous person" or "person who is willing to give things to other people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### bread

Since bread was the main food for many people in biblical times, it is often used to refer to food in general. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### disputes and insults will cease

The abstract nouns "disputes" and "insults" can be translated as verbs. AT: "people will no longer argue with each other or say things to hurt each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]

### Proverbs 22:11

#### loves a pure heart

It is his own heart that the person wants to be pure. The heart is a synecdoche for the person. AT: "loves having a pure heart" or "wants to be pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### gracious

"kind"

#### The eyes of Yahweh keep watch over

The eyes are a synecdoche for the person. The writer speaks as if Yahweh had physical eyes like a person. AT: "Yahweh keeps watch over" or "Yahweh guards knowledge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### keep watch over knowledge

Keeping watch is s metonym for protecting. AT: "protect knowledge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### overthrows

"destroys"

#### the treacherous

The nominal adjective treacherous can be translated as a noun phrase. Translate "treacherous" as in [Proverbs 11:3](../11/03.md). AT: "a treacherous person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Proverbs 22:13

#### The lazy person says

The quote that follows is a lie and an excuse for not working. If your language introduces false statements in a special way, you can use that here.

#### The mouth of an adulteress is a deep pit

The word "mouth" is a metonym for the words that come out of the mouth. The writer speaks of a person being unable to escape having people punish him for evil deeds as if that person had fallen into a hole someone had dug in the ground from which he could not escape. AT: "The words spoken by an adulteress will draw you in, and it will be as if you have fallen into a deep and dangerous pit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an adulteress

See how you translated this in [Proverbs 5:3](../05/03.md).

#### Yahweh's anger is stirred up

Here "stirred up" means that his anger increased. AT: "Yahweh is angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### falls into it

Adultery is spoken of as if it is something that a person can fall into. AT: "sins because of the adulteress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Proverbs 22:15

#### Foolishness is bound up in the heart of a child

"The heart of a child is full of foolish things"

#### the rod of discipline

The writer speaks of a parent using any form of discipline as if that parent were hitting the child with a wooden rod. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### drives it far away

The writer speaks as if foolishness were a person that another person could use a physical rod to drive away. AT: "will make a child wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to increase his wealth

"to become richer" or "to gain more money"

#### gives to rich people

"gives money to rich people"

#### will come to poverty

This is an idiom. AT: "will become poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]

### Proverbs 22:17

#### General Information:

Verse 17 begins the introduction to a new section of the Book of Proverbs.

#### Incline your ear and listen

Here the word "ear" represents the person who is listening. The writer speaks of listening attentively to someone as if it were leaning forward so that the ear is closer to the one speaking. See how you translated "incline your ear" in [Proverbs 4:20](../04/20.md). AT: "Pay attention and listen" or "Listen attentively" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the words of the wise

"what wise people say"

#### apply your heart to

This is an idiom. AT: "do your best to understand and remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my knowledge

The person speaking is probably the same as the father from [Proverbs 1:8](../01/07.md). He may be speaking of "the words of the wise" as "my knowledge." The abstract noun "knowledge" can be stated as "know." AT: "the knowledge I have, which I am sharing with you" or "what I know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### all of them are ready on your lips

The person being ready to speak is spoken of as if it were the words that were ready. AT: "you are able to speak of them at any time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### today—even to you

"today. Yes, I am teaching you," The speaker is emphasizing that it is the hearer, not someone else whom he is teaching, and he is teaching the hearer because the hearer needs to learn. If it is awkward in your language to emphasize in this way, you can emphasize in another way or the words "even to you" can be left untranslated.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 22:20

#### General Information:

These verses continue and end the introduction that began in [Proverbs 22:17](./17.md).

#### Have I not written for you ... you?

This rhetorical question can be translated as a statement. AT: "You need to know that I have written for you ... you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### thirty sayings

Some translations read, "excellent sayings." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])

#### to those who sent you

This implies that the hearer is or will be one whom others send to gain and bring back information.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Proverbs 22:22

#### General Information:

These verses begin the "thirty sayings" ([Proverbs 22:20](./20.md)).

#### Do not rob ... or crush

If your language has a way of showing that this is the way one person would speak strongly to another, different from a general rule that people are supposed to obey, you should use it here.

#### the poor

This nominal adjective can be translated as a noun phrase. AT: "any poor person" or "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### crush

grind into powder. This is a metaphor for "treat unjustly." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the needy

This nominal adjective can be translated as a noun phrase. AT: "any needy person" or "any person who does not have what he needs to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### at the gate

The place where people bought and sold items and settled legal arguments is used as a metonym for business and legal activity. AT: "in court" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yahweh will plead their case

The metaphor is of a lawyer defending the needy in front of a judge. AT: "Yahweh will defend the needy from those who oppress them" or "Yahweh will see that the needy receive justice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will rob of life those who robbed them

Yahweh is not a thief, but like a thief he will take life from those who do not choose to give it. AT: "he will destroy those who oppress poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 22:24

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](./20.md)).

#### someone who is ruled by anger

someone who is unable to control his anger (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### rages

shows violent anger

#### you will take bait for your soul

A person who wants to be like an angry person is like an animal taking the bait in a trap. AT: "you will be like an animal that eats the bait that closes a trap and is unable to escape" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bait for your soul

The soul is a metonym for the person's life. AT: "bait that someone has put out so he can kill you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Proverbs 22:26

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](./20.md)).

#### strikes hands

A person would strike his hand against another person's hand to bind himself to do what he had agreed to do. Here the speaker warns the hearer not to strike hands as a way to promise to pay off someone's debts.

#### in making a pledge

"and agree to pay what someone owes to another person"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md)]]

### Proverbs 22:28

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](./20.md)).

#### ancient

very old

#### boundary stone

a large stone that shows where one person's land ends and another person's land begins

#### fathers

ancestors

#### Do you see a man skilled at his work?

This rhetorical question is actually a command. AT: "Think of someone you know who is skilled at his work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### stand before

This represents becoming a servant of the important person. Kings and other important people will think so highly of him that they will use his services. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Proverbs 22:intro

#### Proverbs 22 General Notes ####

####### Structure and formatting #######

Chapter 22 ends the section of the book which is attributed to Solomon and is filled mainly with short, individual proverbs. 

The second half of this chapter and the first half of the next chapter are attributed to the "Wise Men." The exact identity of the men is unknown.

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

####### Important figures of speech in this chapter #######
######## Rhetorical questions ########

With this new section of proverbs, the author begins to use many rhetorical questions. The obvious answers should convince the reader. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])
##### Links: #####

* __[Proverbs 22:01 Notes](./01.md)__

__[<<](../21/intro.md) | [>>](../23/intro.md)__


## Proverbs 23

### Proverbs 23:01

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### put a knife to your throat

Possible meanings of this exaggeration are 1) "be very careful not to eat too much" or 2) "do not eat anything at all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Do not crave

"Do not strongly desire." See how you translated "craves" in [Proverbs 21:9](../21/09.md).

#### delicacies

"special and expensive food"

#### it is the food of lies

This is an idiom. "he is giving it to you so he can deceive you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Proverbs 23:04

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Do not work too hard

"Do not work so much that you are always tired"

#### light upon it

land like a bird upon the wealth (verse 4). This is a metaphor for looking at the wealth for a short time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it will surely take up wings like an eagle and fly off

A person losing his wealth is spoken of as if the wealth were a bird. AT: "the wealth will disappear as quickly as an eagle can fly away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wings like an eagle

wings like an eagle's wings

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]

### Proverbs 23:06

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### one with an evil eye

Possible meanings are 1) a stingy person, one who does not like to give things to other people, or 2) an evil person.

#### do not crave

"do not strongly desire." See how you translated "craves" in [Proverbs 21:9](../21/09.md).

#### delicacies

"special and expensive food." See how you translated this in [Proverbs 23:3](./01.md).

#### his heart is not with you

This is an idiom. AT: "he really does not want you to enjoy the meal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### You will vomit up the little you have eaten

This is an exaggeration for wishing one had not eaten anything. AT: "You will wish that you had not eaten anything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### you will have wasted your compliments

Compliments are spoken of as if they were valuable objects. The abstract noun "compliments" can be translated as a verb. AT: "he will not be happy even if you say good things about him and the food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 23:09

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### in the hearing of a fool

The abstract noun "hearing" can be translated as a verb. AT: "where a fool can hear you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### ancient

very old. See how you translated this in [Proverbs 22:28](../22/28.md).

#### boundary stone

This is a large stone to show where one person's land ends and another person's land begins. See how you translated this in [Proverbs 22:28](../22/28.md).

#### encroach

This means to slowly take or begin to use land (or some thing) that belongs to someone else.

#### orphans

children whose parents are dead

#### their Redeemer

Yahweh

#### he will plead their case against you

The metaphor is of a lawyer defending the needy in front of a judge. AT: "he will defend the orphans against you" or "he will see that the orphans receive justice and punish you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]

### Proverbs 23:12

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Apply your heart to

This is an idiom. See how you translated this in [Proverbs 22:17](../22/17.md). AT: "Do your best to understand and remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### instruction

Possible meanings are 1) "what people who know what is right and what is wrong tell you" or 2) "what people say and do when they correct you."

#### your ears

The ellipsis can be filled in. AT: "apply your ears" or "listen carefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### to words of knowledge

"to me when I tell you what I know"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 23:13

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Do not withhold instruction from a child

The abstract noun "instruction" can be translated as a verb. AT: "Do not neglect to instruct a child" or "Do not refuse to instruct a child" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### withhold

refuse to give something that one knows another person needs

#### rod

piece of wood

#### It is you who must beat him ... and save his soul

"You are the one who must beat him ... and save his soul." No one else will do it. The hearer is responsible to save the child's soul from Sheol, and the way to save him is to beat him.

#### save his soul from Sheol

If the hearer beats his children with the rod, they will not die young because they have done foolish or evil things. The word "soul" is a metonym for the person. Sheol is the world of the dead; going to the world of the dead is a euphemism for dying. AT: "you will keep him from the world of the dead" or "you will keep him from dying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]

### Proverbs 23:15

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### when your lips speak

"Your lips" means the whole person. AT: "when you speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Proverbs 23:17

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Do not let your heart envy sinners

The word "heart" is a synecdoche for the whole person. AT: "Do not allow yourself to envy sinners" or "Make sure you do not envy sinners" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### your hope will not be cut off

This can be translated in active form. AT: "God will not allow anyone to cut off your hope" or "God will keep the promises he made to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Proverbs 23:19

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Hear—you!—my son

"Listen carefully, my son." The speaker speaks an extra word to make sure the hearer is paying attention.

#### direct your heart in the way

Deciding to do what is right is spoken of as if one person were showing another person the correct path to follow. AT: "make sure you do what is wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### gluttonous eaters of meat

Possible meanings are 1) "people who eat more meat than they need to" or 2) "meat" represents food in general. AT: "people who eat more food than they need to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### slumber will clothe them with rags

The word "slumber" is an exaggeration for a person spending so much time enjoying food and drink that he does not do necessary work. This activity is spoken of as if it were a parent putting clothes on a child. AT: "because they spend so much time eating and drinking, they will do no work and so will become poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]

### Proverbs 23:22

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### do not despise

This can be stated positively. AT: "show respect for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Buy the truth, but do not sell it; buy wisdom, instruction, and understanding

Another possible meaning is "Buy the truth, and do not sell wisdom, instruction, or understanding." The words "truth," "wisdom," "instruction," and "understanding" are abstract nouns that are spoken of as if they were physical items that a person can buy and sell in a market. They can be translated as verbs. AT: "Do what you need to do so you can know what is true, so you can be wise, so you can learn how to act, and so you can tell good from bad; never think of anything else as more important than these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 23:24

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### The father of the righteous person will greatly rejoice, and he who begets a wise child will be glad in him

Another possible meaning is that the words "he that begets a wise child" explain who "the father of the righteous person" is. AT: "The father of the righteous person, he who begets a wise child, will greatly rejoice and will be glad in him"

#### will be glad in him

"will be glad because of him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Proverbs 23:26

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### give me your heart

The word "heart" is a metonym for what a person thinks and decides to do. Possible meanings are 1) "pay careful attention" or 2) "trust me completely." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### let your eyes observe

The eyes are a synecdoche for the whole person. AT: "observe" or "look carefully at" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### prostitute ... immoral woman

There are two types of sexually immoral women. The "prostitute" is unmarried, "another man's wife" is married. Together they form a merism for any kind of sexually immoral woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### a prostitute is a deep pit

The word "pit" is a metaphor for what happens to men who sleep with prostitutes. AT: "sleeping with a prostitute is like falling into a deep pit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### prostitute

Here the word refers to any unmarried woman who engages in sexual activity, not only those who do so for money.

#### deep pit ... narrow well

These are two places easy to fall into and hard to get out of, the "pit" because it is "deep" and the "well" because it is "narrow."

#### an immoral woman is a narrow well

Doing evil for which one will be punished is spoken of as falling into a narrow place from which one cannot escape. AT: "Sleeping with another man's wife is like falling into a narrow well" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### well

a hole in the ground that people have dug to get to water

#### lies in wait

stays hidden, ready to attack when a victim approaches

#### the treacherous

This nominal adjective can be translated as an adjective or verb. AT: "treacherous people" or "those who harm others by deceiving them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]

### Proverbs 23:29

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Who has woe? Who has sorrow? Who has fights? Who has complaining? Who has wounds for no reason? Who has bloodshot eyes?

The writer uses these questions to prepare the reader for the point he is about to make about a particular type of person. He does not expect an answer to each question. Your language may have a different way of introducing a lesson. AT: "Listen to me while I tell you what kind of person has woe, sorrow, fights, complaining, wounds for no reason, and bloodshot eyes." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### bloodshot eyes

"eyes red, like the color of blood"

#### Those who linger over wine, those who try the mixed wine

These words answer the questions in verse 29 and describe people who drink too much wine.

#### linger over wine

spend much time drinking wine and so drink much wine (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### the mixed wine

Possible meanings are 1) different wines mixed together or 2) other drinks that are stronger than wine.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Proverbs 23:31

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### In the last

"After you drink it"

#### it bites like a serpent ... it stings like an adder

The word "it" refers to "the wine when it is red." "Bites" and "stings" are metaphors for the way too much wine makes people feel. AT: "it makes you feel as bad as if a serpent had bitten you or an adder had stung you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### adder

a type of poisonous snake

#### your heart will utter perverse things

The "heart" represents the person and emphasize what he thinks and decides to do. AT: "you will think about and decide to do perverse things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### perverse things

things that God says are morally wrong and bad; things that are wicked

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 23:34

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)). It is the continuation of the description of a drunk person.

#### lies on the top of a mast

The place on the mast where the person lies can be made explicit. AT: "lies in the basket near the top of a mast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### mast

the long wooden pole to which are attached the sails of a sailing ship

#### They hit me, ... but I was not hurt. They beat me, but I did not feel it.

Because the drunk person is not thinking clearly, he is imagining that people are hitting and beating him, yet he feels no pain and cannot remember anything.

#### When will I wake up?

The drunk person is wondering when he will be sober again; when the effect of the wine will stop.

### Proverbs 23:intro

#### Proverbs 23 General Notes ####

####### Structure and formatting #######

Chapter 23 continues the section beginning in the previous chapter of the book and is filled mainly with short, individual proverbs. 

The second half of this chapter and the first half of the next chapter are attributed to general sayings. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]) 

##### Links: #####

* __[Proverbs 23:01 Notes](./01.md)__

__[<<](../22/intro.md) | [>>](../24/intro.md)__


## Proverbs 24

### Proverbs 24:01

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### their hearts

The words "their hearts" refer to the whole person. AT: "they" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### their lips

The words "their lips" refer to the whole person. AT: "they" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### talk about trouble

"talk about causing harm" or "talk about creating problems"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Proverbs 24:03

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Through wisdom a house is built

The abstract noun "wisdom" can be translated as an adjective. These words can be translated in active form. AT: "People need to be wise if they are to build a good house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by understanding it is established

The abstract noun "understanding" can be translated as a verb. These words can be translated in active form. AT: "People need to understand what is morally good and what is morally bad if they are to establish a house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### it is established

The word "established" means made stable and strong. The word "house" is a metonym for the family that lives in the house, and the house being physically stable and strong is a metaphor for a family that lives in peace. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### By knowledge the rooms are filled

The abstract noun "knowledge" can be translated as a verb. These words can be translated in active form. AT: "People need to know what is precious and pleasant if they are to fill their rooms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 24:05

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### warrior of wisdom

The abstract noun "wisdom" can be translated as "wise." AT: "wise warrior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### a man of knowledge increases his strength

The abstract nouns "knowledge" and "strength" can be translated as the verb "know" and the adjective "strong." AT: "a man who knows many things is stronger because he knows these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### by wise direction

The abstract noun "direction" can be translated as a verb. AT: "if you have wise people telling you what to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### wage

"fight"

#### advisors

those who tell government officials what those officials should do

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 24:07

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### too high for a fool

This is an idiom. "too difficult for a fool to understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### open his mouth

The mouth is a metonym for the words that come from the mouth. AT: "speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Proverbs 24:08

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### a master of schemes

one who is skillful at making evil plans. AT: "a mischievous person" or "a troublemaker"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]

### Proverbs 24:10

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### your strength is small

This is an idiom. AT: "you have very little strength" or "you are certainly weak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Proverbs 24:11

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### those who are being taken away

These words can be translated in active form by using the term "they" which could be anyone, but are probably government officials. AT: "those whom they are taking away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### taken away

Another possible meaning is "dragged away."

#### staggering

walking unsteadily and almost falling. This word would also describe the way a person walks when he is being dragged away.

#### the slaughter

The abstract noun "slaughter" can be translated as a verb. The writer speaks as if those who take them away think of them as no better than animals. If your language has a word for killing animals that would fit here, you might want to use it. AT: "where people will kill them as they would kill animals" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### If you say, "Behold, ... this," does

The writer is answering something that the reader may wrongly be thinking. AT: "You may say, 'Behold, ... this,' but does"

#### Behold, we

"Listen to us! We" or "But we" or "We have done nothing wrong, because we"

#### does not the one who weighs the heart understand what you are saying?

The writer assumes the readers know the answer and asks this for emphasis. AT: "the one who weighs the heart understands what you are saying." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the one who

The writer expects the reader to know that "the one" is Yahweh. AT: "Yahweh, who" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### weighs the heart

The word "heart" is a metonym for what a person thinks and desires. The writer speaks as if what a person thinks and desires were a physical object that a person could weigh, and weighing an object is a metaphor for looking closely at something to see how good it is. AT: "knows how good what people really think and desire is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The one who guards your life, does he not know it?

The writer assumes the readers know the answer and asks this for emphasis. AT: "The one who guards your life knows it." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will God not give to each one what he deserves?

The writer assumes the readers know the answer and asks this for emphasis. AT: "God will give to each one what he deserves." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Proverbs 24:13

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### your hope will not be cut off

Possible meanings are 1) this is a simple passive that can be translated as in active form. AT: "no one will take your hope away" or 2) this is litotes that can be translated in positive form. AT: "your hope will surely continue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Proverbs 24:15

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Do not lie in wait

The words "lie in wait" are an idiom. Translate "lie in wait" as in [Proverbs 1:11](../01/10.md). AT: "Do not hide and wait for the right time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### his home

the home of the righteous person

#### rises

"gets back on his feet" or "stands up"

#### wicked people are brought down by calamity

The writer speaks as if "calamity" were a person who could do bad things to other people. These words can be translated in active form. AT: "God will use calamity to bring down the wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### are brought down

This is a metaphor of a person who was standing but someone has brought him down to the ground or made him fall. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### calamity

times when bad things happen to people and their property

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Proverbs 24:17

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### your enemy falls

"something bad happens to your enemy"

#### let not your heart be glad

This is a strong command. The word "heart" represents the person. AT: "do not allow yourself to be glad" or "stop yourself from being glad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### turn away his wrath from him

The words "turn away his wrath" are an idiom for no longer being angry. What Yahweh would do instead can be made explicit. AT: "stop being angry with him and be angry with you instead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Proverbs 24:19

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### the lamp of wicked people will go out

The lamp is used as a metaphor for life. The life of wicked people will end just as a lamp goes out. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]

### Proverbs 24:21

#### General Information:

These verses continue the "thirty sayings" ([Proverbs 22:20](../22/20.md)).

#### Fear

a deep respect and awe for a person in authority

#### who knows the extent of the destruction that will come from both of them?

The writer asks this question to emphasize the disaster. AT: "no one knows the extent of the destruction that will come from both of them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### both of them

these words refer to Yahweh and the king

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Proverbs 24:23

#### These also are sayings of the wise

This sentence starts a new collection of proverbs.

#### a case at law

a situation that is brought before a judge in which someone is accused of breaking the law

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]

### Proverbs 24:24

#### Whoever says to the wicked person, ... will be cursed by peoples and hated by nations

The word "nations" is a metonym for the people who live in the nations. These words can be translated in active form. AT: "People will curse whoever says to the wicked person, ... , and the people of other nations will hate him"

#### the wicked person ... a righteous person

Possible meanings are 1) people should never call any wicked person a righteous person or 2) no one should say of a person guilty of a crime that he is innocent. AT: "a person guilty of a crime ... innocent"

#### will have delight

"will be very happy"

#### gifts of goodness will come to them

Gifts are spoken of as if they were people who could move by themselves. The abstract noun "goodness" can be translated as an adjective. AT: "people will give them good gifts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and[[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### gifts of goodness

"good things" or "blessings"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 24:26

#### gives a kiss on the lips

A kiss was a sign of respect and devotion in that culture. AT: "shows true friendship" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Proverbs 24:28

#### with your lips

The lips are a metonym for the words a person speaks. AT: "by what you say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### pay him back

This is an idiom. "take revenge against him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Proverbs 24:30

#### Thorns

useless plants with sharp spines

#### nettles

plants that are covered with stinging leaves and hairs

#### was broken down

"had fallen down"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]

### Proverbs 24:32

#### received instruction

"learned a lesson"

#### A little sleep ... to rest—and poverty comes

You may need to fill in the omitted words. AT: "You may say to yourself, 'A little sleep ... to rest'—but then poverty will come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### poverty comes marching upon you

Some translations read, "poverty comes upon you like a robber." Poverty is spoken of as if it were a person or animal that can attack a lazy person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### your needs like an armed soldier

Needs are spoken of as if they were a person who could attack the lazy person. AT: "your needs will come to you like an armed soldier" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

### Proverbs 24:intro

#### Proverbs 24 General Notes ####

####### Structure and formatting #######

Chapter 24 continues the section beginning in the previous chapter and is mainly filled with short,  individual proverbs. 

The second half of this chapter finishes the section. 

####### Special concepts in this chapter #######

######## Lazy man story ########

Unlike much of Proverbs, verses 30-34 tell a short story about a lazy man, which ends in a very memorable proverb.

######## Themes ########
There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 24:01 Notes](./01.md)__

__[<<](../23/intro.md) | [>>](../25/intro.md)__


## Proverbs 25

### Proverbs 25:01

#### to conceal a matter

"to keep some things secret"

#### but the glory

The ellipsis can be filled in. AT: "but it is the glory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### search it out

"search that matter out" or "search for those things that God has concealed"

#### Like the heavens are for height and the earth is for depth, so the heart of kings is unsearchable

The hearts of kings are compared to the size of the heavens and the earth. AT: "Just as no one can measure the height of the heavens or the depth of the earth, even so no one can understand the heart of kings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### heavens

This refers to everything we see above the earth, including the sun, moon, and stars.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 25:04

#### dross

the material in a metal that people do not want and they remove by heating the metal

#### his throne will be established by doing

The throne is a metonym for the power to rule. These words can be translated in active form. AT: "the king will establish his throne by doing" or "he will have the power to rule because he does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]

### Proverbs 25:06

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Proverbs 25:07

#### It is better for him to say to you, "Come up here," than

Here "up" means to move to a place at the table that is closer to the king. It is a great honor for a person to sit closer to the king. AT: "It is better for someone to invite you to sit closer to the king than" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### before a nobleman

"in front of a nobleman"

#### For what will you do in the end when your neighbor puts you to shame?

This question is asked to make the reader consider the possibility that he may have misunderstood the situation. The way in which the neighbor might put the reader to shame can be stated plainly. AT: "For you will not know what to do in the end when your neighbor puts you to shame." or "For if your neighbor has an explanation, he will put you to shame, and you will have nothing to say to defend yourself." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/humiliate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/humiliate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trial.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Proverbs 25:09

#### your case

"your disagreement"

#### do not disclose another's secret

"do not share your neighbor's secret with other people"

#### an evil report about you that cannot be silenced

Here "evil report" refers to harmful things that the person will tell others. The phrase "cannot be silenced" can be stated in active form. AT: "you will not be able to stop him from telling other people harmful things about you" or "he will tell people evil things about you and you will never have a good reputation again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 25:11

#### Apples of gold in settings of silver is a word spoken in the right situation

The goodness of "a word spoken at the right time" is spoken of as if it were the physical beauty of "apples of gold in settings of silver." Most translations translate this metaphor as a simile and change the order of the phrases. AT: "A word spoken at the right time is beautiful like apples of gold in settings of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Apples of gold in settings of silver

The ancient Israelites did not know the apples that most people know today. Possible meanings are 1) "apples" should be translated as "design." AT: "a golden design carved into a silver bowl" or 2) "apples" refers to another type of fruit with a golden color that someone has placed on a silver plate or bowl. AT: "Golden colored fruit placed in a silver bowl"

#### is a word spoken

This can be stated in active form. AT: "is a message that someone speaks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### A gold ring or jewelry made of fine gold is a wise rebuke to a listening ear

The value and importance of "a wise rebuke" is spoken of as if it had the beauty and value of gold. Most translations translate this metaphor as a simile and change the order of the phrases. AT: "A wise rebuke to a listening ear is beautiful and valuable like a golden ring or golden jewelry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### listening ear

The ear is a synecdoche for the whole person. AT: "person who is willing to listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]

### Proverbs 25:13

#### Like the cold of snow at harvest time is a faithful messenger

Here a faithful messenger is being compared to the cold of snow, because both are pleasant. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the cold of snow

Snow only fell on the tops of mountains, and the harvest took place in hot weather, so this is probably a metaphor for cool, fresh water from a clean stream. If your language has no word for snow, consider "cool, fresh, clean water." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### snow

white flakes of ice that fall from the sky like rain

#### brings back the life of his masters

This means he makes his masters, who are weak and tired, to be strong and rested again.

#### Clouds and wind without rain is the one who boasts ... not give

Most translations translate this metaphor as a simile and change the order of the phrases. Rain was important to the Israelites because only small amounts of it fell, so a cloud without rain was useless and brought disappointment to the Israelites. AT: "The one who boasts ... not give is like clouds and wind without rain" or "The one who boasts ... not give is useless and a disappointment, like clouds and wind without rain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]

### Proverbs 25:15

#### With patience a ruler can be persuaded

These words can be translated in active form. AT: "Someone who is patient can persuade a ruler" or "Someone who is patient can speak to a ruler and change his mind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a soft tongue can break a bone

The word "tongue" is a metonym for the words the person speaks using the tongue. The word "bone" is a metaphor for strong opposition. AT: "gentle speech can overcome strong opposition" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]

### Proverbs 25:16

#### General Information:

Verse 16 states a general principle, and verse 17 gives one specific example. The idea of eating too much honey and then vomiting it up is a metaphor for taking too much of any good thing and regretting it later. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Proverbs 25:18

#### A man who bears false witness against his neighbor is like a club used in war, or a sword, or a sharp arrow

A false witness is compared to three weapons that can hurt or kill people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### An unfaithful man in whom you trust in a time of trouble is like a bad tooth or a foot that slips

A foolish man is compared to a part of the body that causes trouble for a person. AT: "Trusting in an unfaithful man in time of trouble will bring you pain like a bad tooth or a foot that slips" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Proverbs 25:20

#### carbonate of soda

This is a kind of mineral that hisses and bubbles violently when it comes into contact with acids like vinegar. Many translations translate this phrase as "a wound."

#### sings songs

You may need to make explicit what kind of songs the singer sings. AT: "sings happy songs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a heavy heart

The heart is a synecdoche for the whole person. AT: "a sad person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 25:21

#### shovel coals of fire on his head

This is an idiom. AT: "cause him to have a guilty conscience and be ashamed of what he has done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Proverbs 25:23

#### the north wind

In Israel, wind from the north often brought rain. Translators are free to substitute different kinds of wind for the same effect, for example, "a cold wind."

#### a tongue that tells secrets

Some versions read "someone who tells secrets."

#### result in angry faces

The face is a synecdoche for the person. AT: "makes other people so angry you can see it in their faces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### a corner of the roof

Houses in those days had flat roofs. Ancient Israelites spent much time on their roofs, where it was often cooler than inside the house, and sometimes people would build a shelter large enough for a person to sleep in on one corner of the roof. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a quarreling wife

a wife who often argues or complains

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 25:25

#### Like cold waters to one who is thirsty, so is good news from a far country

Cold water is compared to good news that is both refreshing and delightful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Like a fouled spring or a ruined fountain is a righteous person tottering before wicked people

One expects a spring or fountain to have clear water, just as one expects a righteous man to stand for what he believes. A polluted spring or fountain is compared to a righteous man who falls. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### tottering before wicked people

Tottering is a metaphor for either 1) refusing to fight wicked people or 2) joining in their wickedness. AT: "who allows wicked people to do wickedness" or "who starts to do what wicked people do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### tottering

This is a metaphor for being unable to continue to do good. AT: "unable to stand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### before wicked people

Possible meanings are 1) "when wicked people attack him" or 2) "when wicked people urge him to do evil." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 25:27

#### It is not good to eat too much honey; that is like searching for honor after honor.

Both wanting others to honor you and eating honey are good, but you can eat too much honey, and you can try too hard to have people honor you. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### It is not good

This can be stated positively. AT: "It is a bad thing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### that is like searching for honor after honor

"that is like always thinking about how others should honor you." The meaning of the original language is uncertain. Some versions of the Bible translate this as "that is like speaking too many compliments to people."

#### A person without self-control is like a city breached and without walls.

Both a person without self-control and a city without walls are weak and vulnerable. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### breached and without walls

"whose walls an army has knocked down and destroyed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/selfcontrol.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/selfcontrol.md)]]

### Proverbs 25:intro

#### Proverbs 25 General Notes ####

####### Structure and formatting #######

Chapter 25 begins the second section of the book (Chapter 25-29) which is attributed to Solomon. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 25:01 Notes](./01.md)__

__[<<](../24/intro.md) | [>>](../26/intro.md)__


## Proverbs 26

### Proverbs 26:01

#### Like snow in summer or rain in harvest

Normally snow does not fall during the summer and rain does not fall during the harvest. This can be stated clearly. AT: "Just as it would be very strange to have snow in summer or rain during the harvest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so an undeserved curse does not alight

A curse that does not harm a person is spoken of as if it were a bird that does not land. AT: "so an undeserved curse does not land on its mark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### an undeserved curse

This can be stated with an active form. AT: "a curse on a person who does not deserve it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### alight

land on someone or something

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Proverbs 26:03

#### A whip is for the horse, a bridle is for the donkey and a rod is for the back of fools

A whip, a bridle, and a rod are things that people use to make the horse, donkey, and fool do what they want.

#### a bridle is for the donkey

A bridle is made of straps. People put it on a donkey's head and hold one of the straps to make the donkey go the way they want it to go.

#### a rod is for the back of fools

In the Bible, people would hit their children or their slaves with a wooden rod in order to discipline them.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 26:05

#### Answer a fool and join in on his folly

Joining in on a fool's folly when answering him represents answering him in a foolish way. AT: "Answer a fool according to his folly" or "Answer a fool foolishly"

#### so he will not become wise in his own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "so that he will not become wise according to his judgement" or "so that he does not consider himself to be wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Whoever sends a message by the hand of a fool

Here the hand represents the fool's responsibility to deliver the message. AT: "Whoever sends a fool to deliver a message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### cuts off his own feet

Cutting off one's own feet is an exaggeration for harming one's self. AT: "harms himself like a person who cuts off his own feet and drinks violence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### drinks violence

Violence is spoken of as if it were a poisonous liquid that someone might drink. AT: "harms himself by being violent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 26:07

#### Like the legs ... is a proverb in the mouth of fools

The phrases can be reordered. AT: "A proverb in the mouth of fools is like the legs of a paralytic which hang down" or "A proverb in the mouth of fools is as useless as the legs of a paralytic which hang down" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a paralytic

a person who is unable to move or feel all or part of his body

#### in the mouth of fools

Here "mouth" is a metonym for speaking. AT: "in the speech of fools" or "that fools say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### tying a stone in a sling

In order to throw a stone very far, people put it into a sling and swing the sling so that the stone will fly from it very quickly. The result of tying a stone in a sling can be stated clearly. AT: "tying a stone in a sling so that it cannot be thrown" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### giving honor to a fool

"honoring a fool"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 26:09

#### Like a thorn ... is a proverb in the mouth of fools

How the two are alike can be stated clearly. AT: "A proverb in the mouth of fools is as dangerous as a thorn that goes into the hand of a drunkard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a thorn that goes into the hand of a drunkard

Possible meanings are 1) if a drunk person holds a thornbush, a thorn will prick his hand, or 2) if a drunk person is angry, he will pick up a thornbush and swing it at people. For the second meaning, the word "thorn" represents a thornbush. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### in the mouth of fools

Here "mouth" is a metonym for speaking. AT: "in the speech of fools" or "that fools say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hires a fool

"gives a job to a fool"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/archer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/archer.md)]]

### Proverbs 26:11

#### As a dog returns to his own vomit

"As a dog eats its own vomit"

#### Do you see someone who is wise in his own eyes?

This question is used to lead the reader to think about someone who is wise in his own eyes. The phrase "is wise in his own eyes" means "thinks he is wise," and here it implies that the person is not truly wise. AT: "Consider the person who thinks he is wise but is not." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### There is more hope for a fool than for him

"A fool can become wise more easily than he can"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]

### Proverbs 26:13

#### The lazy person says, "There is a lion ... between the open places!"

The lazy person lies and says that he cannot go outside and work because there is a lion on the road or between the open places.

#### There is a lion on the road

See how you translated this in [Proverbs 22:13](../22/13.md).

#### the open places

This refers to the places in town where there is a lot of room for people to walk around or where people gather. AT: "the town plazas" or "the streets"

#### hinges

metal pieces that attach a door to something and allow it to open and close

#### As the door turns on its hinges, so is the lazy person upon his bed

Both the door and the lazy person move, but they do not go anywhere. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]

### Proverbs 26:15

#### puts his hand into the dish

"puts his hand into the dish to get food" or "reaches for food"

#### he has no strength to lift it up to his mouth

This is an exaggeration for doing necessary work that would clearly do him good. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### The lazy person is wiser in his own eyes than seven men with discernment

The phrase "his own eyes" represents his thoughts. AT: "The lazy person thinks he is wiser than seven men who can respond sensibly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/discernment.md)]]

### Proverbs 26:17

#### Like one who takes hold of the ears of a dog, is a passerby who becomes angry at a dispute that is not his own

This can be reordered. AT: "A passerby who becomes angry at some other people's dispute is like a person who grabs hold of a dog's ears" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Like one who takes hold of the ears of a dog

The implied information is that the dog will get angry and bite the person. AT: "Like a person who angers a dog by grabbing its ears" or "Like a person who grabs a dog's ears and is bitten by the dog" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### is a passerby who becomes angry at a dispute that is not his own

The implied information is that the passerby will start arguing, and the people who were fighting will get angry with him and hurt him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Proverbs 26:18

#### Like a madman ... is the one who deceives ... telling a joke?"

Both the madman and the deceiver hurt people but do not take responsibility for it.

#### Was I not telling a joke?

The deceiver uses this question to imply that since he his joke was only for fun, he should not be blamed for any harm he has caused. AT: "I was only telling a joke." or "Do not blame me. I was only telling a joke." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Proverbs 26:20

#### gossiper

a person who gossips a lot

#### As charcoal is to burning coals and wood is to fire

What charcoal does to coals and what wood does to fire can be stated clearly. AT: "As charcoal helps coals burn and as wood helps fire burn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### kindling strife

To kindle something means to set it on fire. Setting strife on fire is a metaphor for causing people to fight or argue. AT: "causing people to fight" or "causing people to argue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]

### Proverbs 26:22

#### The words of a gossip are like delicious morsels

This speaks of gossip being desirable to listen to as if it were delicious food to eat. AT: "The words of a gossip are desirable to listen to" or (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they go down into the inner parts of the body

This speaks of the words that a gossip says going into a person's mind and affecting his thoughts as if they were food that was going into his stomach. This sentence is equivalent to [Proverbs 18:8](../18/07.md). AT: "and they enter a person's mind and affect his thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Like the glaze overlaying an earthen vessel so are burning lips and an evil heart

This simile means that a person who says things to hide the evil in their heart are like a earthen vessel covered in glaze to make it look good. These phrases can be reordered. AT: "People who have burning lips and an evil heart are like an earthen vessel covered with glaze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the glaze overlaying an earthen vessel

"the shiny glaze that covers a clay pot." A clay pot is cheap and common. So people covered it was a glaze to make it shiny and appear more expensive.

#### so are burning lips and an evil heart

This represents a person who has burning lips and an evil heart. AT: "so is a person who has burning lips and an evil heart" or "so is a person who says nice things but whose heart is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### burning lips

The word "burning" is a metaphor for "strongly emotional" and the word "lips" is a metonym for "speech." AT: "emotional speech" or "saying nice things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### an evil heart

The heart represents a person's thoughts, attitudes, desires, or feelings. AT: "evil thoughts" or "evil desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Proverbs 26:24

#### disguises his feelings with his lips

Disguising his feelings represents keeping people from knowing what his feelings are. The phrase "his lips" is a metonym for what he says. AT: "hides his feelings with what he says" or "speaks in such a way that people cannot know his true feelings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he lays up deceit within himself

Being deceitful is spoken of as if he were storing deceit within himself. Possible meanings are that "deceit" refers to lies. AT: "he likes his many lies" or 2) deceit refers secret plans to harm people. AT: "he secretly plans to harm people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but do not believe him

"but do not believe what he says"

#### for there are seven abominations in his heart

The number seven represents completeness. Possible meanings are 1) "abominations" refers to attitudes that God hates. AT: "for his heart is completely filled with hateful things" or 2) "abominations" refers to his hatred for people. AT: "for his heart is completely filled with hatred" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Though his hatred is covered with deception

This can be stated actively. AT: "Though deception covers his hatred" or "Though he covers his hatred with deception" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Though his hatred is covered with deception

Keeping people from knowing that he hates them is spoken of as covering his hatred. AT: "Though he lies to keep people from knowing that he hates them" or "Though he lies so that people will not know that he hates them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his wickedness will be exposed in the assembly

Being exposed represents being discovered or becoming known. AT: "his wickedness will become known in the assembly" or "the assembly will discover his wickedness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the assembly

"the community of Israel"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Proverbs 26:27

#### Whoever digs a pit will fall into it

It is implied that the person digs the pit as a trap so that someone will fall into it. AT: "Whoever digs a pit to trap someone will fall into it" or "If someone digs a pit in order to trap someone, the one who dug it will fall into it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the stone will roll back on the one who pushed it

It is implied that the person pushed a large stone so that it would roll downhill and crush someone there. AT: "if someone pushed a stone so that it would roll downhill and crush someone, the stone will roll back on him instead" or "if someone maked a stone roll so that it would hurt someone, the stone will crush him instead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### A lying tongue hates the people it crushes

The phrase "a lying tongue" represents a person who tells lies. Crushing people represents causing them trouble. AT: "A liar hates those he hurts by his lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a flattering mouth brings about ruin

The phrase "a flattering mouth" represents a person who flatters people. Possible meanings are 1) a person who flatters others causes trouble or 2) a person who flatters others ruins them (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### flattering

praising someone in a manner that is not sincere, or praising someone about things that are not true

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]

### Proverbs 26:intro

#### Proverbs 26 General Notes ####

####### Structure and formatting #######

Chapter 26 continues the second section of the book (Chapter 25-29) which is attributed to Solomon. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. Wisdom and folly are particularly prominent in this chapter.(See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]) 

##### Links: #####

* __[Proverbs 26:01 Notes](./01.md)__

__[<<](../25/intro.md) | [>>](../27/intro.md)__


## Proverbs 27

### Proverbs 27:01

#### Do not boast about tomorrow

This is a warning not to brag about what you expect to happen tomorrow. This can be stated clearly. AT: "Do not speak proudly about your plans for tomorrow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### what a day may bring

Something happening on a certain day is spoken of as if the day were to bring that event. AT: "what will happen on a day" or "what will happen tomorrow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### and not your own mouth ... and not your own lips

The words "let praise you" are understood from the first phrase. They can be repeated. Here a person is represented by his "mouth" and "lips" because those are the parts of the body used to speak. AT: "and do not let your own mouth praise you ... and do not let your own lips praise you" or "and do not praise yourself ... and do not praise yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### a stranger

The words "let praise you" are understood from the first phrase. The words can be repeated here. AT: "let a stranger praise you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Proverbs 27:03

#### the provocation of a fool is heavier than both

The difficulty of being patient with a fool who provokes you is spoken of as if that difficulty were heavy. AT: "the provocation of a fool is harder to tolerate than either of them" or "It is harder to be patient when a fool provokes you than it is to be patient while carrying them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the provocation of a fool

"the trouble caused by a fool." "Provocation" means actions or words that cause anger or irritation.

#### There is the cruelty of rage and the flood of anger, but who is able to stand before jealousy?

The abstract nouns "rage", "anger" and "jealousy" can be translated as adjectives. AT: "A raging person is cruel and an angry person is overwhelming, but who can stand before a jealous person?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### cruelty

"harshness"

#### the flood of anger

"the destructiveness of anger." Anger is spoken of here as if it were a powerful flood. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but who is able to stand before jealousy?

This question implies that no one can stand before jealousy. It can be reworded as a statement. AT: "but no one is able to stand before jealousy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to stand before jealousy

Here standing represents being strong and resisting being harmed by a jealous person who attacks. AT: "to resist a jealous person" or "to remain strong when a jealous person attacks him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]

### Proverbs 27:05

#### Better is an open rebuke

The abstract noun "rebuke" can be expressed with the verb "rebuke." AT: "It is better to be openly rebuked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### than hidden love

"than love that is not openly shown." The abstract noun "love" can be translated as a verbal phrase. AT: "than to be loved secretly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Faithful are the wounds caused by a friend

"The wounds that a friend causes are trustworthy." The word "wounds" here represents the pain and sadness that a person feels when a friend rebukes or corrects him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Faithful are the wounds caused by a friend

The trustworthiness of a friend's rebuke is spoken of as if the sadness that his rebuke causes is trustworthy. AT: "Though it causes sadness, a friend's rebuke is trustworthy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but an enemy may kiss you profusely

It can be stated clearly that the enemy's kisses are not trustworthy. AT: "but the enemy's many kisses are not trustworthy" or "but an enemy may try to deceive you by kissing you profusely" or (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### profusely

"abundantly" or "too much"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]

### Proverbs 27:07

#### A person who has eaten to the full

"A person who is satisfied" or "A person who has eaten enough to be full"

#### rejects even a honeycomb

A honeycomb would normally be desirable, but not to the person who has already eaten enough to be satisfied.

#### every bitter thing is sweet

"everything that is bitter tastes sweet"

#### Like a bird that wanders from its nest is a man who strays from where he lives

The words "wanders" and "strays" mean the same thing in this verse. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 27:09

#### Perfume

The word "perfume" here means a desirable oil or ointment.

#### make the heart rejoice

Here "the heart" represents the feelings or emotions of a person. AT: "make a person feel joyful" or "make a person glad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the sweetness of a friend comes from his sincere counsel

Possible meanings are 1) "sweetness" represents kindness. AT: "we recognize our friend's kindness by his counsel" or 2) "sweetness" represents what we appreciate about a person. AT: "what we appreciate about a friend is his advice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your brother's house

Here the word "brother" is a general reference to relatives, such as members of the same tribe, clan, or people group.

#### calamity

extreme troubles and misfortune

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Proverbs 27:11

#### make my heart rejoice

Here the "heart" represents the person's feelings or emotions. AT: "make me feel joyful" or "make me glad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### then I will give back an answer to the one who mocks me

Here "answer" does not mean to answer a question. It means to respond or to reply to someone who is mocking. How this relates to the clause before it can be made clear. AT "then I will reply to the one who mocks me by telling him about you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### mocks

makes fun of someone, especially in a cruel way

#### A prudent man sees trouble and hides himself, but the naive people go on and suffer because of it

See how you translated a similar phrase in [Proverbs 22:3](../22/03.md).

#### A prudent man

"A man who is wise" or "A man who has good sense"

#### the naive people

"the inexperienced and immature people"

#### suffer

experience something very unpleasant, such as illness, pain, or other hardships

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prudent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prudent.md)]]

### Proverbs 27:13

#### Take a garment of one who has put up security for a stranger

When lending money, a lender would take something from the borrower, such as a garment, as a guarantee of repayment. He would return it after the money was repaid. If the borrower was too poor, someone else could give something to the lender as a guarantee for him. See how you translated this in [Proverbs 20:16](../20/15.md). AT: "Take a garment as security from the one who guarantees that what a stranger has borrowed will be paid back" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who has put up security

This means for someone to give something to a lender as a guarantee that what was borrowed will be paid. See how you translated this in [Proverbs 20:16](../20/15.md). AT: "who has guaranteed that what has been borrowed will be paid back" or "who has promised to pay a loan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### hold it in pledge

To "hold something in pledge" means to hold on to something that someone has given as a pledge, or promise, that he will pay a debt. See how you translated this in [Proverbs 20:16](../20/15.md). AT: "hold onto his coat as a guarantee of repayment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Whoever gives his neighbor a blessing

"If anyone gives his neighbor a blessing"

#### that blessing will be considered to be a curse

This can be stated in active form. AT: "the neighbor will consider that blessing to be a curse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Proverbs 27:15

#### quarreling

This means making people angry with each other or causing strong disagreements between people.

#### the constant dripping

The implied information is that it is rain that is constantly dripping. AT: "the constant dripping of rain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a rainy day

"a day of continual rain"

#### restraining her is like restraining the wind, or trying to catch oil in your right hand

The implied information is that it is as difficult or useless to try and restrain her as it is to try to restrain the wind or catch oil in your hand (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### restraining her

"holding her back" or "keeping her under control." The implied information is that it is trying to stop her from quarreling. AT: "restraining her from quarreling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### restraining the wind

"holding back the wind" or "keeping the wind under control"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]

### Proverbs 27:17

#### Iron sharpens iron; in the same way, a man sharpens his friend.

These two phrases are comparing how iron and a man can be improved. AT: "As iron can sharpen another piece of iron, so a man's character is improved by contact with his friend" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### tends

"takes care of"

#### the one who protects his master will be honored

This can be stated in active form. AT: "a master will honor the one who protects him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 27:19

#### a person's heart

Here this means a person's thoughts. AT: "what a person thinks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Abaddon

This is a name that means "destroyer." AT: "the Destroyer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### satisfied

"filled up"

#### a man's eyes

Here the "eyes" represent a man's desires. AT: "a man's desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]

### Proverbs 27:21

#### A crucible is for silver and a furnace is for gold

This refers to how gold and silver are refined. A metal is refined by heating it to a high temperature so that it melts and the impurities may be removed. See how you translated the very similar phrase in [Proverbs 17:3](../17/03.md). AT: "A crucible is used to refine silver and a furnace is used to refine gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### crucible

a container used for heating substances to very high temperatures (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### furnace

an oven that can be made extremely hot (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### a person is tested when he is praised

This can be stated in active form. AT: "when one praises a person, they are also testing that person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Even if you crush a fool ... yet his foolishness will not leave him

This means that even if a fool is made to suffer hardship or pain (being crushed is often a metaphor for suffering in Hebrew), he will remain foolish. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### pestle

a hard tool with a rounded end, used for crushing things in a bowl (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/furnace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/furnace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 27:23

#### Be sure you know the condition of your flocks and be concerned about your herds

These two phrases have basically the same meaning and are used together for emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### flocks

"flocks of sheep"

#### herds

"herds of goats"

#### Does a crown endure for all generations?

This question expects a negative answer to make the point that the reign of earthly rulers does not last forever. This can be expressed as a statement. AT: "A crown does not endure for all generations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### a crown

Here "crown" is a metonym for a king's rule over his kingdom. AT: "a king's rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the new growth appears

"the new sprouts appear" or "the new grass starts to grow"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Proverbs 27:26

#### Connecting Statement:

Verses 26 and 27 go together with verses 23 to 25 as one proverb.

#### Those lambs will provide your clothing

The implied information is that the wool (hair) from the lambs can be used to make clothing. AT: "The lambs' wool will provide you with clothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the goats will provide the price of the field

The implied information is that the money received by selling the goats will be enough to buy a field. AT: "selling your goats will provide the price of the field" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for your household

"for your whole family"

#### nourishment for your servant girls

The implied information is that there will also be enough goats' milk to feed the servant girls. AT: "there will be goat's milk to nourish your servant girls" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### nourishment

"food"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Proverbs 27:intro

#### Proverbs 27 General Notes ####

####### Structure and formatting #######

Chapter 27 continues the second section of the book (Chapter 25-29) which is attributed to Solomon. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 27:01 Notes](./01.md)__

__[<<](../26/intro.md) | [>>](../28/intro.md)__


## Proverbs 28

### Proverbs 28:01

#### Because of the transgression of a land

The abstract noun "transgression" can be translated as a verb. AT: "Because of how a land transgresses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the transgression of a land

This is a metonym for the sins of the people living in a land. AT: "the transgression of the people of a land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with a man of understanding and knowledge

The implied information is that this man is a ruler or leader. The abstract nouns "understanding" and "knowledge" can be translated as verbs. AT: "with a man who understands and knows how to rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Proverbs 28:03

#### oppresses

"severely mistreats"

#### like a beating rain that leaves no food

The poor man who oppresses other poor people is compared to a rain that falls so hard that it leaves no crop to harvest. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### beating rain

This is a metaphor for a rain coming down hard enough to cause crops to be driven down. AT: "damaging rain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### forsake the law

"forsake God's law"

#### those who keep the law

To "keep the law" means to do what God's law requires. AT: "those who obey God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fight against them

"struggle against them." This means to strongly oppose or resist them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 28:05

#### Evil men

Here "men" means people in general. AT: "People who do evil things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### do not understand justice

The abstract noun "justice" can be expressed as an adjective. AT: "do not understand what is just" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### those who seek Yahweh

Those who want to know Yahweh and please him are spoken of as if they are literally seeking to find Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### understand everything

The implied information is that those who seek Yahweh understand all about justice. AT: "completely understand what is just" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It is better for a poor person ... than for a rich person

"It is better to be a poor person ... than it is to be a rich person"

#### walks in his integrity

This represents a person living a life of integrity. The abstract noun "integrity" can be expressed as an adverb. AT: "walks honestly" or "lives honestly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### who is crooked in his ways

Rich people who are dishonest are spoken of as if they walk on crooked or twisted paths. AT: "who is not honest in what he does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]

### Proverbs 28:07

#### He who keeps the law

To "keep the law" means to do what God's law requires. AT: "He who obeys God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a son who has understanding

The abstract noun "understanding" can be expressed as a verb. AT: "a son who understands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### gluttons

"people who eat too much." A "glutton" is a person who often eats and drinks excessively.

#### shames his father

"puts his father to shame" or "dishonors his father"

#### makes his fortune

"increases his wealth"

#### charging too much interest

"charging extra money to borrow"

#### interest

money paid by a borrower for the use of someone else's money

#### gathers his wealth

"brings his wealth together"

#### for another

"for another person"

#### pity

a strong feeling of sadness or sympathy for someone

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Proverbs 28:09

#### If one

"If a person"

#### turns away his ear from hearing the law

This represents the whole person turning away from and rejecting God's law. AT: "turns away from hearing and obeying the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### even his prayer is detestable

"even his prayer is offensive to God." This can be written in active form. AT: "God detests even his prayer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### detestable

See how you translated this in [Proverbs 3:32](../03/31.md).

#### Whoever misleads the upright into an evil way

This is a metaphor for leading upright people in an evil direction. AT: "Whoever causes the upright to go in an evil direction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Whoever misleads ... evil way will fall

"If anyone misleads ... evil way, he will fall"

#### the upright

This refers to upright persons in general. AT: "upright persons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### will fall into his own pit

"will fall into the trap that he has dug." This is a metaphor for ending up in the same bad place as others had been led toward. AT: "will end up in the same evil place toward which he guided other people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the blameless

This refers to blameless persons in general. AT: "blameless persons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### will have a good inheritance

"will inherit what is good"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Proverbs 28:11

#### be wise in his own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "be wise in his own thoughts" or "think he is wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who has understanding

The abstract noun "understanding" can be expressed as a verb. AT: "who understands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### will find him out

This is an idiom that means the poor person will be able to determine whether or not the rich person is really wise. AT: "will see his true nature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### When the righteous triumph

"When righteous people succeed"

#### when the wicked arise

This is an idiom that means when the wicked gain power or start to rule. AT: "when the wicked rise to power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the wicked

This refers to wicked people in general. AT: "wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### people are sought out

You may need to make explicit that those who "are sought out" have hidden themselves to escape from the wicked. This can be stated in active form. AT: "they seek people out" or "they seek out the people who hide from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 28:13

#### hides his sins

"covers his sins." This is the opposite of confessing and forsaking sins, and is spoken of as covering sins rather than bringing them into the open (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will not prosper

"will not succeed" or "will not advance"

#### the one who confesses them and forsakes them will be shown mercy

This can be stated in active form. AT: "God will show mercy to the one who confesses and forsakes them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The one who always lives with reverence is blessed

This can be expressed in active form. AT: "God will bless the one who always lives with reverence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### lives with reverence

The abstract noun "reverence" can be expressed as an adjective. AT: "lives a reverent life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### reverence

This refers to deeply respecting Yahweh and showing that respect by obeying him.

#### whoever hardens his heart

"the one who hardens his heart"

#### hardens his heart

This is an idiom that means to be stubborn or unwilling to obey God. AT: "refuses to obey God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will fall into trouble

This represents ending up in misery and distress. AT: "will end up in trouble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reverence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reverence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Proverbs 28:15

#### Like a roaring lion or a charging bear is a wicked ruler over poor people

Poor people who are helpless against an evil ruler are compared to people who have a lion roaring at them or a bear attacking them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a charging bear

A bear is a large, furry, dangerous animal that walks on four legs and has sharp claws and teeth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### The ruler who lacks understanding

The abstract noun "understanding" can be translated as a verb. AT: "The ruler who does not understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### oppressor

a person who treats people harshly and makes their lives very difficult

#### the one who hates dishonesty

The abstract noun "dishonesty" can be translated as a verb. AT: "the one who hates being dishonest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### prolong his days

Possible meanings are 1) this is an idiom that means his living for more time. AT: "live longer" or 2) this is an idiom that means extending the length of his reign. AT: "rule for a longer time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Proverbs 28:17

#### he has shed someone's blood

Here "blood" represents a person's life. To "shed blood" means to murder someone. AT: "he has killed someone" or "he has murdered someone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### fugitive

a person who is running away to avoid being captured

#### until death

"until he dies." This means for the rest of his life. AT: "all of his life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Whoever walks with integrity will be kept safe

This can be expressed in active form. AT: "God will keep safe anyone who walks with integrity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Whoever

"Anyone who"

#### walks with integrity

This represents a person living a life of integrity. The abstract noun "integrity" can be expressed as an adverb. AT: "walks honestly" or "lives honestly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the one whose way is crooked

A dishonest person is spoken of as if he walks on crooked or twisted paths. AT: "the one who does not live honestly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will suddenly fall

What will happen to a dishonest person is spoken of as if he suddenly fell down. AT: "will suddenly be ruined" or "will suddenly perish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]

### Proverbs 28:19

#### works his land

This means to till, sow, and care for his crops.

#### whoever follows

"anyone who follows"

#### follows worthless pursuits

"chases after worthless projects." The person who is busy doing things that do not produce anything is spoken of as chasing after useless things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will have plenty of poverty

The person following worthless pursuits is spoken of as getting the opposite of plenty of food. The abstract noun "poverty" can be translated as an adjective. AT: "will be very poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the one who gets rich quickly will not go unpunished

The double negative "will not go unpunished" is used for emphasis. This can be stated in active form. AT: "God will certainly punish the one who gets rich quickly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the one who gets rich quickly

The implied information is that this person gains wealth by unfaithful or dishonest means. AT: "the one who tries to get rich quickly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Proverbs 28:21

#### for a piece of bread a man will do wrong

"A piece of bread" here is an exaggeration for a very small bribe or reward. AT: "a man will sin for very little gain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### do wrong

"sin"

#### A stingy man

"A selfish man." This is a person who does not like to share his possessions or spend money.

#### hurries after riches

The stingy man is spoken of as if he was chasing after wealth. AT: "is greedy for riches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### poverty will come upon him

The result of being stingy is spoken of as if poverty was overtaking the stingy person. The abstract noun "poverty" can be translated as an adjective. AT: "he will suddenly become poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Proverbs 28:23

#### Whoever disciplines someone, afterward will find more favor from him than from the one who flatters him with his tongue

This can be stated in active form, with the abstract noun "favor" being expressed as a verb. AT: "A person will favor the one who disciplines him more than he favors the person who flatters him with his tongue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Whoever disciplines

"If a person disciplines"

#### disciplines

trains people to obey a set of guidelines for moral behavior

#### flatters him with his tongue

The tongue here represents speaking. AT: "flatters him with words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### flatters

praises someone in a manner that is not sincere, or praises someone about things that are not true

#### Whoever robs

"The one who robs"

#### says, "That is no sin," he

This can be expressed as an indirect quotation. AT: "says that it is not a sin, he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### the companion of

Possible meanings are: 1) "the friend of" or 2) an idiom that means having the same character as. AT: "the same kind of person as" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Proverbs 28:25

#### A greedy man

a person who selfishly wants more things, money or food than what he needs

#### stirs up conflict

The action of the greedy man is spoken of as if he were stirring up or awakening conflict. AT: "causes conflict" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### One who trusts in his own heart

Depending on one's self is spoken of as trusting in one's own heart. AT: "The person who relies on himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### whoever walks

"any person who walks"

#### walks in wisdom

Possible meanings are 1) this is an idiom that means to live wisely. AT: "lives wisely" or 2) this is an idiom that means to follow the teachings of wise people. AT: "follows wise teachings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Proverbs 28:27

#### The one

"The person"

#### the poor

This refers to poor people in general. AT: "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### lack nothing

This double negative is used for emphasis. AT: "have everything they need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### whoever closes his eyes to them will receive many curses

This can be stated in active form. Possible meanings are 1) they will receive many curses from the poor. AT: "the poor will give many curses to whoever closes his eyes to them" or 2) they will receive many curses from people in general. AT: "people will give many curses to whoever closes his eyes to the poor" or 3) they will receive many curses from God. AT: "God will give many curses to whoever closes his eyes to the poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### whoever closes

"anyone who closes"

#### closes his eyes to

Closing the eyes represents not responding to the needs of the poor. AT: "ignores" or "chooses not to help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### When the wicked arise

This is an idiom that means when wicked people gain power or start to rule. AT: "When wicked people rise to power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### people hide themselves

This is an exaggeration for doing everything they can to avoid having wicked people harm them. AT: "people go into hiding" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### perish

Possible meanings are 1) "go away" or 2) "fall from power" or 3) "are destroyed."

#### increase

Possible meanings are 1) "multiply" or 2) "rise to power."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Proverbs 28:intro

#### Proverbs 28 General Notes ####

####### Structure and formatting #######

Chapter 28 continues the second section of the book (Chapter 25-29) which is attributed to Solomon. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 28:01 Notes](./01.md)__

__[<<](../27/intro.md) | [>>](../29/intro.md)__


## Proverbs 29

### Proverbs 29:01

#### who stiffens his neck

A person becoming stubborn is spoken of as if he stiffens his neck. AT: "who becomes stubborn" or "who refuses to listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will be broken in a moment

This can be stated in active form. AT: "God will suddenly break him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### beyond healing

"and no one will be able to heal him." Sickness is a metaphor for any kind of bad situation. AT: "and no one will be able to help him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the people sigh

The people let out long, loud breaths that show that they are weary and sad. AT: "the people will be weary and sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Proverbs 29:03

#### by justice

The abstract noun "justice" can be translated as a noun phrase. AT: "by doing what is just" or "by making just laws" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]

### Proverbs 29:05

#### flatters his neighbor

knowingly tells his neighbor things that are not true so that the neighbor will do what the speaker wants him to do

#### spreading a net for his feet

The writer compares the flattery of a person to setting that person up to being caught in a trap. AT: "setting a trap to catch that person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### In the sin of an evil person is a trap

When an evil person sins, it is as if he is stepping into a trap. He desires to do evil to other people, but God will use what he does to punish him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Proverbs 29:07

#### set a city on fire

Here the word "city" represents the people who live in the city. Mockers causing the people to experience turmoil and possibly to become violent is spoken of as if they set the city on fire. AT: "create turmoil for the people of a city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### turn away wrath

This idiom means to cause angry people no longer to be angry. AT: "calm the wrath of angry people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Proverbs 29:09

#### has an argument with

Another possible meaning is "goes to court against."

#### he rages and laughs

The fool becomes very angry and tries to keep the wise person from speaking or the court judge from judging.

#### rages

This means to be loud and excited and to move with powerful movements like a strong storm. This is a negative word.

#### there will be no rest

"they will not be able to settle the problem"

#### seek the life of

This idiom means to "want to kill." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]

### Proverbs 29:11

#### pays attention

"listens." See how you translated this in [Proverbs 17:4](../17/03.md).

#### all his officials will be wicked

The actions of the ruler are spoken of by stating the result they will cause. AT: "it is as if he is teaching his officials to be wicked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 29:13

#### oppressor

a person who treats people harshly and makes their lives very difficult

#### Yahweh gives light to the eyes of them both

This idiom means "Yahweh makes both of them alive." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### his throne

The throne is a metonym for the kingdom he rules from his throne. AT: "his kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Proverbs 29:15

#### The rod and reproof give wisdom

The writer speaks as if a rod and reproof were people who could give wisdom as a physical gift. AT: "If a parent uses the rod on his child and reproves him, the child will become wise" or "If parents discipline their child and tell him when he has done wrong, the child will learn to live wisely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The rod

Parents in Israel used wooden rods as instruments to discipline children by striking them. AT: "discipline" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### reproof

When a person gives reproof to another person, or reproves that person, he tells that person that he does not approve of what that other person is doing.

#### transgression increases

The abstract noun "transgression" can be translated as a verb. AT: "more people will transgress and their sins will become worse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the downfall of those wicked people

The abstract noun "downfall" can be translated with the verb "fall," which is a metaphor for losing the power to rule. AT: "those wicked people fall" or "those wicked people lose their power to rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]

### Proverbs 29:17

#### the one who keeps the law is blessed

This can be translated in active form. AT: "God will bless the one who keeps the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]

### Proverbs 29:19

#### A slave will not be corrected by words

This can be translated in active form."You will not be able to correct a slave simply by talking to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### See a man who is hasty in his words?

The writer is using a question to get the reader's attention. AT: "You should notice what happens to a man who is hasty in his words." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 29:21

#### who pampers his slave

"who allows his slave to avoid work and who treats his slave better than he treats other slaves"

#### at the end of it

"at the end of the slave's youth" or "when the slave is grown"

#### there will be trouble

These words translate a Hebrew word whose meaning no one knows for sure. Some understand it to mean that the slave will be weak, others that the slave will rule the household.

#### stirs up strife

Causing people to argue more is spoken of as if it were stirring up or awakening arguments. The abstract noun "strife" can be stated as "argue." See how you translated similar words in [Proverbs 15:18](../15/17.md). AT: "causes people to argue more" or "causes people to argue and fight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### a master of rage

This idiom means "a person who becomes angry easily." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Proverbs 29:23

#### one who has a humble spirit will be given honor

This can be translated in active form. AT: "men will give honor to a person who has a humble spirit" or "a person who has a humble spirit will receive honor from men" or "Yahweh will cause men to honor a person who has a humble spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### hates his own life

"becomes his own enemy"

#### he hears the curse and says nothing

Possible meanings are 1) people have put the "one who shares with a thief" under oath to tell the truth about what he knows about what the thief stole, and he knows he will be punished if he tells the truth. AT: "he does not dare to testify under oath" or 2) people do not know who the thief is but they call on God to curse the thief, and the "one who shares" is afraid to confess and so come out from under the curse because he is afraid of the thief. AT: "he says nothing even after people have cursed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Proverbs 29:25

#### The fear of man makes a snare

Being afraid of what other people might do is spoken of as stepping into a trap. AT: "Anyone who is afraid of what other people might do to him is like a person who has become snared in a trap" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a snare

a trap that catches animals with ropes

#### the one who trusts in Yahweh will be protected

This can be translated in active form. AT: "Yahweh will protect the one who trusts in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Many are those who seek the face of the ruler

The word "face" is a metonym for the ruler listening to people telling him what they want him to do and then doing it. AT: "Many people want their ruler to pay attention to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from Yahweh is justice for a person

It is Yahweh, not human rulers, who will see that people treat a person justly. The abstract noun "justice" can be stated as "just." AT: "it is Yahweh who is truly just towards a person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]

### Proverbs 29:27

#### detestable

a person who should be hated. See how you translated this in [Proverbs 3:32](../03/31.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Proverbs 29:intro

#### Proverbs 29 General Notes ####

####### Structure and formatting #######

Chapter 29 concludes the second section of the book (Chapter 25-29) which is attributed to Solomon. 

####### Special concepts in this chapter #######

######## Themes ########

There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 29:01 Notes](./01.md)__

__[<<](../28/intro.md) | [>>](../30/intro.md)__


## Proverbs 30

### Proverbs 30:01

#### Agur ... Jakeh ... Ithiel ... Ucal

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Agur son of Jakeh

This is the literal son of Jakeh, not a grandchild.

#### the utterance

"the message"

#### to Ithiel, to Ithiel and Ucal

"to Ithiel—that is, to Ithiel and Ucal"

#### Surely

"Certainly" or "There is no doubt that"

#### I do not have the understanding of a human being

The abstract noun "understanding" can be translated as a verb. AT: "I do not understand anything the way human beings are supposed to understand them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### nor do I have knowledge of the Holy One

The abstract noun "knowledge" can be translated as a verb. AT: "nor do I really know anything about the Holy One" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md)]]

### Proverbs 30:04

#### Who has ... down? Who has ... hands? Who has ... cloak? Who has ... earth?

The writer asks these questions to get the reader thinking about how much greater Yahweh is than people. AT: "No person has ever ... down. No person has ever ... hands. No person has ever ... cloak. No person has ever ... earth." or "Who has ... down? Who has ... hands? Who has ... cloak? Who has ... earth? No one has ever done any of these things." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### heaven

where God lives

#### gathered up the wind in the hollow of his hands

The writer speaks of the wind as if it were something that a person could catch and hold in his hand. AT: "has caught the wind in his hands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the hollow of his hands

the way his hands are shaped when he is scooping up, for example, water or sand. "his cupped hands"

#### gathered up

brought small scattered objects into a pile so they can be lifted

#### has established all the ends of the earth

"has set up the limits for where the earth ends" or "has marked the boundaries for the ends of the earth"

#### What is his name, and what is the name of his son?

The writer uses these questions to command the reader to give an answer. AT: "Tell me his name and the name of his son, if you know them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Surely you know!

The writer uses irony to show that neither he nor the reader know any person who can do what the "who" in the earlier questions can do. AT: "I do not think you really know anyone who can do those things." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Proverbs 30:05

#### is tested

Words are spoken of as if they were metals that need someone to clean the bad parts out of them. AT: "is like a precious metal from which someone has removed all the useless material" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he is a shield to those who take refuge in him

The word "shield" is a metaphor for something that protects a person. AT: "he protects those who come and ask him to protect them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### add to his words

say more than he has said

#### you will be proved to be

This can be translated in active form. AT: "he will prove that you are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]

### Proverbs 30:07

#### Put vanity and lies far away from me

Possible meanings are 1) "Do not allow people to speak vanity and lies to me" or 2) "Do not allow me to speak vanity and lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### vanity

false, useless words

#### Give me neither poverty nor riches

The writer speaks as if "poverty" and "riches" were physical objects that someone could give to another. They are also abstract nouns that can be stated as "poor" and "rich." AT: "Do not allow me to be either very poor or very rich" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### if I have too much, I might deny you and say

This describes a hypothetical situation that has not happened but is possible if the writer becomes rich. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### if I become poor, I might steal and profane

This describes a hypothetical situation that has not happened but is possible if the writer becomes poor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### I might steal and profane the name of my God

"I might make people who know that I have stolen things think that there is no God" or "I might harm God's reputation by stealing"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Proverbs 30:10

#### slander

speak falsely about another person with the desire to harm him

#### he will curse

"the servant will curse"

#### you will be held guilty

This can be translated in active form. AT: "people will hold you guilty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]

### Proverbs 30:11

#### a generation that curses ... and does not bless ... a generation that is

"a generation of people who curse ... and do not bless ... a generation of people that are"

#### generation

type or class or group

#### is pure in their own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "considers themselves pure" or "believes they are pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they are not washed of their filth

The words "washed" and "filth" speak of God forgiving people who sin as if he were washing physical filth off of the people. This can be translated in active form. AT: "God has not forgiven them of their sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### filth

This should be translated with a polite term that includes human or animal vomit and waste.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]

### Proverbs 30:13

#### eyes are raised up ... their eyelids lifted up

This describes people who think that they are better than other people. Their eyes show that they are proud, and the way they look at others shows that they think they are better than those other people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### There is a generation whose teeth are swords, and their jawbones are like knives, so they may devour the poor ... and the needy

The people of the generation who speak very harmful things is spoken of as if they were wild animals with teeth and jawbones made of swords and knives, and they eat the poor and needy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### jawbones

the bones of the face where teeth grow

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/haughty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Proverbs 30:15

#### The leech has two daughters

This is an example of something that always wants more. AT: "Greed has two daughters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### leech

a type of worm that attaches itself to the skin and sucks blood

#### "Give and give" they cry

Another possible meaning is "and they are both named Give Me."

#### There are three things that are never satisfied, four that never say, "Enough"

This use of the numbers "three" and "four" together here is likely a poetic device. AT: "There are four things that are never satisfied, who never say, 'Enough'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]])

#### are never satisfied

This can be stated positively. AT: "always want more" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### land that is never satisfied with water

Land that is no longer producing food because there has been no rain is spoken of as if it were a person who does not have enough water to drink. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### scorns obedience to a mother

The word "obedience" is a metonym for the mother herself. It is also an abstract noun that can be stated as "obey." AT: "considers his mother worthless and will not obey her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his eyes ... the vultures

The writer says that the person will die by giving two pictures of what happens to people who die away from where people live.

#### his eyes will be pecked out by the ravens of the valley

This can be translated in active form. AT: "the ravens of the valley will peck out his eyes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### ravens

large, shiny, black birds that eat plants and dead animals

#### he will be eaten by the vultures

This can be translated in active form. AT: "the vultures will eat him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### vultures

any one of several large birds that eat dead animals and have small, featherless heads

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### Proverbs 30:18

#### There are three things that are ... four that I do not understand:

The use of the numbers "three" and "four" here is likely a poetic device. AT: "There are some things that are too wonderful for me that I do not understand—four of them are:"

#### in the heart of the sea

The "heart" refers to the middle. AT: "in the middle of the sea" or "on the open sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Proverbs 30:20

#### she eats and she wipes her mouth

This seems to be both a euphemism and a metaphor for committing adultery and then taking a bath. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]

### Proverbs 30:21

#### Under three things the earth trembles, and under four it cannot bear up

The use of the numbers "three" and "four" here is likely a poetic device. "There are some things that make the earth tremble, that it cannot endure. Four of these are:"

#### a fool when he is filled with food

This can be translated in active form. AT: "a fool who has had enough to eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a hated woman when she marries

That is, people rightly hated her before she married; once she marries, she will be worse than she was before she married. This can be translated in active form. AT: "a woman whom good people have hated when she marries" or "an outcast woman when she marries" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### takes the place of her mistress

rules the household

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Proverbs 30:24

#### rock badgers

an animal with small, rounded ears, short legs, and no tail

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]

### Proverbs 30:27

#### lizard

a small reptile that has four legs, a long, slender body, and a tail

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]

### Proverbs 30:29

#### There are three things that are ... four that are stately in how they walk

The use of the numbers "three" and "four" here is likely a poetic device. AT: "There are some things that walk stately. Four of these are"

#### stately

majestic or dignified, like a king

#### strutting rooster

an adult male chicken that walks proudly

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Proverbs 30:32

#### churning

strongly stirring

#### butter

Animal milk that someone has stirred and made thick.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Proverbs 30:intro

#### Proverbs 30 General Notes ####

####### Structure and formatting #######

Chapter 30 is a chapter in Proverbs attributed to Agur, who is a person otherwise unknown. 

####### Special concepts in this chapter #######
######## Agur ########

His full title is Agur, Son of Jakeh. Agur comes from a Hebrew word that means "gatherer" and so some scholars believe this is not a real name, but possibly a way of referring to Solomon as a gatherer of proverbs. However, it is still prudent to simply use this as a name. 

######## Three things and four ########

From verses 15 through 32, the author uses a specific technique to explain some things. He says there are three things and even four and lists items that exemplify a feature like "small and yet wise." The numbering is not meant to be so literal, but as a memory device that introduces the items. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]])

######## Themes ########
There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 30:01 Notes](./01.md)__

__[<<](../29/intro.md) | [>>](../31/intro.md)__


## Proverbs 31

### Proverbs 31:01

#### King Lemuel

This is the name of a king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### What, my son? What is it, son of my womb? What do you want, son of my vows?

Possible meanings of the rhetorical question "What" are 1) "What are you doing?" or "You should not be doing what you are doing" or 2) "What shall I tell you?" or "Listen to what I am telling you" or 3) "Do not do the things I am about to warn you against." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my son ... son of my womb ... son of my vows

The speaker wants the hearer to notice carefully and to respect the one who is talking to him.

#### son of my womb

The womb is a synecdoche for the person. It is best to use a polite term for the body part in which babies grow before they are born.

#### son of my vows

The "vows" could be 1) the mother's marriage vows or 2) a vow after she married that if God allowed her to have a child she would dedicate him to God.

#### Do not give your strength to women

"Do not work hard trying to have sex with women," either outside of marriage or with concubines.

#### or your ways to those who destroy kings

"or allow those who destroy kings to advise you"

#### your ways

Possible meanings are 1) "the way you live your life" or 2) "the work you do"

#### those who destroy kings

probably the immoral "women" to whom he is not to give his strength

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]

### Proverbs 31:04

#### Lemuel

This is the name of a man. See how you translated this in [Proverbs 31:1](./01.md).

#### what has been decreed

This can be translated in active form. Possible meanings are 1) "what God has decreed" or 2) "what the kings themselves have decreed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### pervert

"change" or "twist" or "deny"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]

### Proverbs 31:06

#### and wine

The ellipsis can be filled in. AT: "and give wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### in bitter distress

"who's souls are bitter" or "who are in misery"

#### his poverty

The abstract noun "poverty" can be translated as an adjective. AT: "how poor he is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### his trouble

The abstract noun "trouble" can be translated as a clause. AT: "the bad things that are happening to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Proverbs 31:08

#### Speak for those who cannot speak

Speaking is a metonym for using words to defend innocent people. AT: "Defend those who cannot defend themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### for the causes of all who are perishing

The cause represents the person whose cause it is. AT: "so that people will treat all who are perishing justly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for the causes

The ellipsis can be filled in. AT: "speak for the causes" or "speak out for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### poor and needy people

These two words have basically the same meaning and are used together for emphasis. AT: "people who are poor and cannot get the things that they need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]

### Proverbs 31:10

#### Who can find a capable wife?

The writer asks a question to show that he is beginning a new section. AT: "Not many men can find a capable wife." or "Not many men can find a wife who is able to do many things well." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Her value is far more than jewels

"She is more precious than jewels"

#### he will never be poor

This litotes can be stated positively. AT: "he will always have what he needs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Proverbs 31:13

#### wool

sheep's hair that is used to make cloth

#### flax

a plant whose fiber is used to make linen

#### with the delight of her hands

Possible meanings are that the word "delight" describes 1) how she feels as she works, "gladly with her hands," or 2) how she feels about the wool and flax, "with her hands on things that she enjoys working with"

#### merchant

someone who buys and sells

#### distributes the work for her female servants

"tells her female servants what work each of them is to do that day"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Proverbs 31:16

#### the fruit of her hands

The money she has earned from the work she did with wool and flax ([Proverbs 31:13](./13.md)) is spoken of as if it were fruit growing off a tree. The hands are a synecdoche for the person. AT: "the money she has earned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### She dresses herself with strength

Putting on clothes is a metonym for preparing for work. AT: "She prepares herself for hard physical work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### makes her arms strong

"she strengthens her arms by doing her work"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]

### Proverbs 31:18

#### perceives

sees by looking carefully

#### all night long her lamp is not extinguished

This is probably an exaggeration: she works late into the night, but not from dusk to dawn. AT: "She burns a lamp through the night as she works" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### spindle

a thin rod or stick with pointed ends that is used in making thread

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]

### Proverbs 31:20

#### reaches out with her hand to poor

The hand is a metonym for the help the woman uses her hand to give. AT: "helps poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### reaches out with her hands to

These words translate the same words translated "puts her hands on" in [Proverbs 31:19](./18.md).

#### are clothed in scarlet

Here "scarlet" does not refer to the color of the cloth, but that the clothing is expensive and warm. AT: "have expensive, warm clothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### scarlet

The color red, but with a hint of orange.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]

### Proverbs 31:22

#### linen

cloth made of flax yarn

#### Her husband is known

This can be translated in active form. The verb "know" is a metonym for respect. AT: "People respect her husband" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### when he sits with the elders of the land

to make laws and settle arguments

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Proverbs 31:24

#### linen

cloth made from flax yarn

#### sashes

long pieces of cloth worn around the waist or over one shoulder

#### She is clothed with strength and honor

Having strength and honor is spoken of as if the woman were wearing them. This can be translated in active form. The abstract nouns "strength" and "honor" can be translated by an adjective and a verb, respectively. AT: "Everyone can see that she is strong, and so they honor her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### laughs at the time to come

This is probably an exaggeration to show that she is not afraid. AT: "is not afraid of what will happen in the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Proverbs 31:26

#### opens her mouth with wisdom

The act of opening her mouth is a metonym for speaking. The abstract noun "wisdom" can be translated as an adverb or an adjective. AT: "she speaks wisely" or "she speaks wise words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the law of kindness is on her tongue

The phrase "on her tongue" refers to her speaking, as the tongue is part of the mouth. The phrase "the law of kindness" refers to her teaching people to be kind. AT: "she teaches people to be kind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### watches over the ways of her household

The word "ways" refers to the way people live. AT: "makes sure her whole family lives in a way that pleases God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### does not eat the bread of idleness

To "eat the bread of" something means to do something. AT: "she is not idle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### idleness

doing nothing and being lazy

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]

### Proverbs 31:28

#### rise up and

Possible meanings are 1) literally "stand up and" or 2) as a metonym, "actively." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### call her blessed

saying that good things have happened to her because she has done good things. This can be translated as a direct quote. AT: "congratulate her" or "say, 'Yay, Mom!'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### surpassed

"have done better than"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Proverbs 31:30

#### Elegance is deceptive

The abstract noun "elegance" can be translated as an adjective. AT: "A gracious woman can deceive people" or "A woman with good manners could really be evil" See how you translated this in [Proverbs 11:16](../11/15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### beauty is vain

The abstract noun "beauty" can be translated as an adjective. AT: "a woman who is beautiful now will not always be beautiful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### she will be praised

This can be translated in active form. AT: "people will praise her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the fruit of her hands

The money she has earned from the work she did with wool and flax ([Proverbs 31:13](./13.md)) is spoken of as if it were fruit growing off a tree. The hands are a synecdoche for the person. See how you translated this in [Proverbs 31:16](./16.md). AT: "the money she has earned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### let her works praise her in the gates

She will be praised for her works, not by her works. Those "in the gates" are the important people of the city who conduct business and legal affairs near the gates of the city. AT: "may the important people of the city praise her because of the works she has done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Proverbs 31:intro

#### Proverbs 31 General Notes ####

####### Structure and formatting #######

Chapter 31 begins with 9 verses from King Lemuel. The last portion of this chapter is a poem about a godly wife. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]])

######## King Lemuel ########

This person is unknown in Scripture, other than here. It is important to recognize that the words in this chapter are words of his mother addressed to him. They are formed like advice of a mother to her son. 

####### Special concepts in this chapter #######

######## An acrostic poem ########

Verse 10 through 31 is tightly formed as a poem in the original language. There are 22 lines in the Hebrew language that each begin with a successive letter of the alphabet. However, each language will have a different set of letters. Therefore, it is important to realize this was a single composition with a single theme of a noble or godly wife. 

######## Themes ########
There are individual proverbs that run along common themes, often including contrasting elements: wise/foolish, money, lazy/diligent, truth telling, wicked/righteous, sluggard, pride/humility, integrity/crookedness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Proverbs 31:01 Notes](./01.md)__

__[<<](../30/intro.md) | __


## Proverbs front

### Proverbs front:intro

#### Introduction to Proverbs ####

##### Part 1: General Introduction #####

####### Outline of Proverbs #######

   - Introduction and Solomon's place (1:1–7)
1. Collection of sayings (1:8–9:18)
1. First collection of Solomon (10:1–22:16)
1. First "Sayings of the Wise Men" (22:17–23:14)
1. Other sayings (23:15–24:22)
1. Second "Sayings of the Wise Men" (24:23–34)
1. Second collection of Solomon (25:1–29:27)
1. The Words of Agur (30:1–33)
1. The Words of Lemuel (31:1–9)
1. The Virtuous Woman (31:10–31)

####### What is the book of Proverbs about? #######

Proverbs are usually short sentences well-known for their meanings and understood by everyone who speaks that language. Most societies have their own proverbs. The book of Proverbs is a collection of this kind of statements. It also includes general teachings about how to live wisely. Scholars refer to Proverbs, Psalms, Job, Ecclesiastes, and the Song of Songs as Wisdom Literature. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-proverbs.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-proverbs.md)]])

####### How should the title of this book be translated? #######

The title of this book is often translated as "Proverbs." A more general translation would be "Words for Wise People," "Words that Give Wisdom," or something similar.

####### Who wrote the book of Proverbs? #######

Proverbs begins with the words, "The Proverbs of Solomon, son of David and King of Israel." But we understand that not all the proverbs were written by Solomon. Unnamed "wise men" seem to have written some of them. One author is identified as Agur the son of Jakeh (30:1). Another author is identified as King Lemuel (31:1).

##### Part 2: Important Religious and Cultural Concepts #####

####### What is meant by "wisdom" and "foolishness" in the book of Proverbs? #######

Here "wisdom" means the humility necessary to live in a way that honors Yahweh. Anyone living in this way will also learn to live well with other people and to make good practical decisions in life. The book of Proverbs also acknowledges that it is important to maintain one's honor or reputation in the opinion of other people. Those who fail to live in this way are called "foolish." For this reason, it is possible for a person to be very intelligent and still be foolish. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]])

##### Part 3: Important Translation Issues #####

####### What form do the individual proverbs have? #######

In general, the proverbs have two parts or two lines, "parallel" to each other. The second part may strengthen the first, may elaborate on the first, or may even contradict the first. But it is also true that these sayings are a part of a larger group of proverbs. So the translator should take this fact into account as well. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]]) 

####### How should personification be represented in translation? #######

In Proverbs, certain qualities such as wisdom and understanding are often represented as if they were wise women, as in [Proverbs 03:15-18](../03/15.md), [Proverbs 04:6-9](../04/05.md), and elsewhere. In languages where it is possible for a woman figure to represent these qualities, the translator should translate in this way. However, in many languages this kind of direct translation is not possible. In such a case, the translator may be able to translate these personifications as similes instead. This means they would present wisdom or understanding as being like a wise woman whom people should obey. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])



---

