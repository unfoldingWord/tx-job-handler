# <a id="lam"/>Lamentations

## Lamentations 01

### Lamentations 01:01

#### General Information:

Various poetic forms are used throughout this book. (See [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### is now sitting all alone

This speaks of the city of Jerusalem being empty, as if it were a woman who was sitting alone. AT: "is now empty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She

The writer of Lamentations writes about the city of Jerusalem as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### like a widow

This speaks of Jerusalem as being without protection, as if it were a vulnerable widow. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### She was a princess among the nations

This speaks of Jerusalem being honored as if it were a princess. AT: "She was like a princess among the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### forced into slavery

"forced to become a slave." This can be stated in active form. AT: "but she is now a slave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### She weeps and wails ... and her tears cover her cheeks

The author describes Jerusalem as having emotions like a human being. The city also stands for her inhabitants. AT: "Those who live in her weep and wail ... and their tears cover their cheeks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### weeps and wails

The word "wails" refers to the sounds that a person makes when they "weep" loudly. AT: "weeps loudly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### None of her lovers comfort her. All her friends have betrayed her

This speaks of the people groups that had been faithful to Jerusalem betraying Jerusalem, as if the people groups were Jerusalem's lovers and friends. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Lamentations 01:03

#### General Information:

In these verses, Jerusalem and Judah are spoken of as if they were women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### After poverty and affliction

"After suffering poverty and affliction"

#### Judah has gone into exile

Here Judah refers to its inhabitants. AT: "the people of Judah have gone into exile" or "the people of Judah have been taken into a foreign land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### She lives ... finds

Here the kingdom of Judah is described as a woman. "She" also stands for the citizens of Judah. AT: "Her people live ... they find" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### finds no rest

"does not find rest" or "is always afraid"

#### All her pursuers overtook her in her desperation

This speaks of the people of Judah being captured by their enemies as if they were a woman who was captured by those pursuing her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### All her pursuers overtook her

"Everyone who was chasing her managed to capture her" or "Everyone who was hunting for her found her"

#### in her desperation

The word "desperation" can be expressed as an adjective. AT: "when she was desperate" or "when she was distressed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Lamentations 01:04

#### General Information:

The city of Zion is spoken of as if it were a woman. In Lamentations, Zion and Jerusalem are names used to refer to the same city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The roads of Zion mourn

The author speaks of the roads that lead to Zion mourning as if they were human beings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the appointed feasts

"the feasts that God told them to celebrate"

#### All her gates are desolate

The word "her" refers to Zion. AT: "All of Zion's gates are empty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Her virgins are sorrowful and she herself is in complete distress

Here the people of Zion being distressed are spoken of as if they were a woman in distress. AT: "Zion's virgins are sorrowful, and its people despairing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Her adversaries have become her master; her enemies prosper

"Zion's adversaries rule over it; its enemies prosper"

#### Yahweh has afflicted her for her many sins

This speaks of Yahweh punishing the people of Zion for their sins as if they were a woman that Yahweh was punishing. AT: "Yahweh has afflicted her people because of the sins they have committed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Her little children go into captivity to her adversary

The word "captivity" can be expressed as a verb. AT: "Her enemy captures her little children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]

### Lamentations 01:06

#### General Information:

The city of Zion is spoken of as if it were a woman. In Lamentations, Zion and Jerusalem are names used to refer to the same city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Beauty has left the daughter of Zion

This speaks of everything beautiful in Zion being destroyed as if "beauty" were a person that left Zion. AT: "Everything that was beautiful about the daughter of Zion is destroyed"

#### daughter of Zion

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Her princes have become like deer that cannot find pasture

This speaks of Zion's princes having nothing to eat like deer that cannot find grass to eat. AT: "Her princes are starving, they are like deer that cannot find grass to eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### deer

A deer is a medium-sized, grass-eating animal that is often hunted by humans for food. It is also a beautiful animal to look at.

#### they go without strength before

"they are not strong enough to run away from" or "they are very weak before"

#### their pursuer

"the person that is pursuing them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/daughterofzion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/daughterofzion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Lamentations 01:07

#### In the days of her affliction and her homelessness

"During the time of her affliction and her homelessness"

#### Jerusalem will call to mind

Here "Jerusalem" refers to the people who live there. The phrase "call to mind" is an idiom. AT: "the people of Jerusalem will remember" or "Jerusalem will remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### precious treasures

This refers to their valuable possessions.

#### in former days

"in the past." This refers to the time before the people of Jerusalem were captured. AT: "before this disaster happened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### When her people fell into the hand of the adversary

Here the word "hand" refers the control of the enemy army. AT: "When the adversary conquered and captured her people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### saw her and laughed at her destruction

This means that they were glad and mocked Jerusalem when it was destroyed.

#### at her destruction

This word "destruction" can be expressed as a verb. AT: "because she was destroyed" or "while they destroyed her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Lamentations 01:08

#### General Information:

The city of Jerusalem is spoken of as if it were a woman. In Lamentations, Zion and Jerusalem are names used to refer to the same city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Jerusalem sinned greatly, therefore, she has become scorned as something that is filthy

This speaks of Jerusalem being scorned in the same way that a woman is scorned when she is unclean. According to the Law of Moses, a woman was considered unclean during her monthly bleeding. AT: "Jerusalem's sins have made her filthy and unclean, and therefore she was unacceptable before God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Jerusalem sinned greatly

This describes Jerusalem as a woman who sinned, while it also stands for the inhabitants of Jerusalem. AT: "The people of Jerusalem sinned greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has become scorned

This can be stated in active form. AT: "has become an object of scorn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### her nakedness

"her naked." Jerusalem is described as a woman whose private parts have been exposed to everyone to shame her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### She has become unclean beneath her skirts

According to the Law of Moses, a woman was considered unclean during her monthly bleeding. This speaks of Jerusalem being unclean, as if it were a menstruating woman. AT: "Jerusalem has become unclean, as when a woman is unclean beneath her skirts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### unclean

A person who God considers to be spiritually unacceptable or defiled is spoken of as if the person were physically unclean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Her fall was terrible

The phrase "her fall" is an idiom. AT: "Her downfall was astonishing" or "Those who saw her destruction were surprised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Look at my affliction, Yahweh

Possible meanings are that 1) the author of Lamentations now talks directly to Yahweh or 2) Jerusalem is described as talking to Yahweh like a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Look at

"Pay attention to"

#### the enemy has become too great

This means that they enemy army has become too large and powerful and has defeated Jerusalem. AT: "the enemy army has defeated me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Lamentations 01:10

#### has put his hand on

This is an idiom. AT: "has taken possession of" or "has stolen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### precious treasures

This refers to their valuable possessions.

#### She has seen

The word "She" refers to Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the nations

This refers to people from various nations, not the entire population of those nations. AT: "people from the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### you had commanded

The word "you" refers to Yahweh.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Lamentations 01:11

#### her people

The word "her" refers to Jerusalem which is described as if it were a woman. AT: "her inhabitants" or "the people of the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### bread

This refers to food in general. AT: "food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### They have given their precious treasures for food

This means they traded their wealth and their valuables in exchange for food. AT: "They have traded their precious treasures in exchange for food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### precious treasures

This refers to their valuable possessions.

#### to restore their lives

"to save their lives" or "to restore their strength"

#### Look, Yahweh, and consider me

Here Jerusalem speaks directly to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Is it nothing to you, all you who pass by?

This rhetorical question is an accusation aganist the people who walk past Jerusalem and do not care about its well-being. This question can be written as a statement. AT: "All you who pass by should care more for my affliction!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is it nothing to you

Here Jerusalem continues to speak, but now to people who pass by instead of to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Look and see

These words share similar meanings. Together they invite the reader to understand by seeing that no one has suffered so much. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the sorrow that is being inflicted on me

This can be stated in active form. AT: "the sorrow that Yahweh is inflicting upon me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on the day of his fierce anger

Here the word "day" is used as an idiom. AT: "when he was fiercely angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Lamentations 01:13

#### General Information:

In this section Jerusalem is portrayed as a woman speaking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### on high

This is an idiom. AT: "heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he has sent fire into my bones, and it has conquered them

This speaks of Yahweh punishing Jerusalem as if Jerusalem were a person that Yahweh were punishing with fire. AT: "he has sent a painful punishment into my inner being, and it has destroyed me" or "he has sent a destructive punishment into the middle of Jerusalem, and it has destroyed the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### has sent fire into my bones

Here "fire" represents pain and "bones" represents one's inner being. AT: "has sent pain into my bones" or "has sent pain into my inner being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He has spread a net for my feet

This speaks of Yahweh punishing Jerusalem as if Jerusalem were a person that Yahweh had set a trap for. This refers to a type of trap usually used to catch an animal. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### turned me back

This is an idiom. AT: "prevented my from walking any further" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The yoke of my transgressions ... They are knit together and placed upon my neck

This speaks of the people of Jerusalem's sins as if they were a yoke bearing a heavy burden that Yahweh had placed on their necks. Also, this can be stated in active form. AT: "My transgressions are like a yoke that he has bound together with his hands and placed upon my neck" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### given me over into their hands

"given me over into the hands of my enemies." Here their enemies' control is represented by their "hands." AT: "given my over to the control of my enemies" or "let my enemies defeat me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I am not able to stand

This is an idiom. AT: "I cannot resist them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/onhigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/onhigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Lamentations 01:15

#### General Information:

In this section Jerusalem is portrayed as a woman speaking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### mighty men

"strongest soldiers"

#### an assembly

Here the enemy army attacking Jerusalem is spoken of as if it were a meeting of people who have come together in order to accuse and condemn someone. AT: "a great army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to crush my vigorous men

This speaks of the enemy army defeating the soldiers of Jerusalem as if they crushed them. AT: "to defeat my vigorous men"

#### vigorous men

This refers to men at the strongest time of their lives.

#### The Lord has trampled ... in the winepress

Here the judgment of God is described as if Jerusalem were grapes on which he had trampled in order to squeeze out the juice. AT: "It is as though the Lord has trampled upon the virgin daughter of Judah in a winepress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the virgin daughter of Judah

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. The word "virgin" suggests that this woman is pure. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]

### Lamentations 01:16

#### General Information:

In this section Jerusalem is portrayed as a woman speaking about herself. In Lamentations, Zion and Jerusalem are names used to refer to the same city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### for a comforter is far from me, one who restores my life

This speaks of Jerusalem having no one to comfort her as if she did have a comforter, but that he was far away. The word "comforter" can be expressed as a verb. AT: "for there is no one to comfort me and restore my life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### restores my life

"revives me"

#### Zion has spread her hands wide

Here Jerusalem no longer speaks about herself; instead the author describes Jerusalem. He speaks of Zion as if it were a woman that lifts up her hands to ask for help. AT: "Zion has reached out for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### those around Jacob

"the people around Jacob" or "the nations surrounding Jacob"

#### around Jacob should be his adversaries

Here "Jacob" refers to his descendants, that is Israel. AT: "around Jacob's descendants should be their adversaries" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### unclean

A person who God considers spiritually unacceptable or defiled is spoken of as if the person were physically unclean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Lamentations 01:18

#### General Information:

In this section Jerusalem is portrayed as a woman speaking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Yahweh is righteous

This implies that what Yahweh has done,  he has done because he is righteous. AT: "Yahweh has acted out of his righteousness" or "What Yahweh has done is right"

#### see my sorrow

The word "sorrow" can be expressed as a "sad." AT: "see how extremely sad I am" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### My virgins and my vigorous men have gone into captivity

Here all of the people of Jerusalem who were taken into captivity are represented by the "virgins" and the "vigorous men" who were taken. AT: "Many of my people, including my virgins and vigorous men, have gone into captivity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### vigorous men

This refers to men at the strongest time of their lives. See how you translated this in [Lamentations 1:15](./15.md).

#### I called for my friends

"I called for my friends to help me" or "I called for my allies to help me"

#### they were treacherous toward me

This means that they betrayed him. AT: "they betrayed me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to restore their lives

"to save their lives" or "to restore their strength"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Lamentations 01:20

#### General Information:

In this section Jerusalem is portrayed as a woman speaking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Look, Yahweh, for I am in distress

Jerusalem continues to talk about herself as if she were a woman, but now talks directly to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### my stomach churns

The word "churn" means to move around violently, normally in a circular rotation. This does not mean the stomach is literally churning, but describes how the woman, representing Jerusalem, feels. AT: "my insides ache" or "my stomach hurts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my heart is disturbed within me

Here the woman, representing Jerusalem, refers to her "heart" to emphasize her feelings. AT: "my heart is broken" or "I am extremely sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the sword bereaves a mother

The "sword" represents the enemy. AT: "the enemy kills a mother's children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### inside the house there is only death

Possible meanings are 1) "inside the house, everyone is dying" or 2) "and inside the house the dead people are kept" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Lamentations 01:21

#### General Information:

In this section Jerusalem is portrayed as a woman speaking about herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### They have heard my groaning

"People have heard my groaning." Jerusalem continues to speak as if she were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### you have done it

Here the word "you" refers to Yahweh.

#### You have brought the day you promised

The phrase "the day" is an idiom that refers to a specific event happening. AT: "You have done what you have promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### now let them become like me

This is a request for Jerusalem's enemies to suffer as the people of Jerusalem have. AT: "now let them suffer like me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Let all their wickedness come before you

This is a request for Yahweh to judge Jerusalem's enemies for their wickedness. The phrase "come before you" is an idiom. AT: "Pay attention to all of the wickedness they have committed" or "Judge them for all of their wickedness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### deal with them as you have dealt with me

This is a request for Yahweh to punish Jerusalem's enemies as he punished the people of Jerusalem. AT: "punish them as you have punished me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### my heart is faint

Here the "heart" represents the whole person. AT: "I am faint" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Lamentations 01:intro

#### Lamentations 01 General Notes ####

####### Structure and formatting #######

######## Judah destroyed for her sin ########

Judah used to be great, but is now a slave. The temple is stripped of all its valuables. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

##### Links: #####

* __[Lamentations 01:01 Notes](./01.md)__
* __[Lamentations intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Lamentations 02

### Lamentations 02:01

#### General Information:

A new poem begins. The writer of Lamentations uses many different ways to express that the people of Israel have lost God's favor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The Lord has covered the daughter of Zion under the cloud of his anger

This speaks of the Lord's anger against Jerusalem (Zion) as if it were a dark cloud. Possible meanings are 1) God is threatening to harm the people of Jerusalem or 2) God has already harmed the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the daughter of Zion ... the daughter of Judah

These are poetic names for Jerusalem, which is spoken of here as if it were a woman. Translate "the daughter of Zion" as you did in [Lamentations 1:6](../01/06.md).(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### He has thrown the splendor of Israel down from heaven to earth

The phrase "the splendor of Israel" refers to Jerusalem. This passage speaks of the people of Jerusalem losing favor with the Lord as if he threw them out of his presence. The phrase "from heaven to earth" is a great distance used to represent how much they lost favor with the Lord. AT: "Jerusalem, the splendor of Israel, has lost all favor with the Lord" or "Jerusalem has lost all favor with the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He has not remembered his footstool

This is a reference to the Lord having considered Jerusalem his "footstool" in the past, which symbolized that he had authority over them and that they were submissive to him. This speaks of the Lord disregarding Jerusalem as his footstool as if he did not remember them. AT: "He disregarded Jerusalem as his footstool" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### not remembered

This speaks of the Lord not paying attention to Jerusalem as if he did not remember them. AT: "disregarded" or "paid no attention to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### on the day of his anger ... the days of his anger

Here "day" is used as an idiom that refers to a general period of time. AT: "at the time when he displays his anger ... the time of his anger" or "at the time he acts in his anger ... the time of his anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### swallowed up

This speaks of the Lord completely destroying the towns as if he were an animal who ate them. AT: "completely destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### all the towns of Jacob

Here "the towns of Jacob" refers to the towns where his descendants lived. AT: "all the towns of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the fortified cities of the daughter of Judah

Possible meanings are 1) the fortified cities throughout Judah or 2) the fortified walls of Jerusalem.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/footstool.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/footstool.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Lamentations 02:03

#### General Information:

The author continues the use of metaphors to express how the Lord opposed Judah.

#### he has cut off every horn of Israel

This speaks of the Lord taking away Israel's strength as if he were cutting off its horns. The word "horn" refers to an animal horn, not a musical instrument. AT: "he has taken away all of Israel's strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### withdrawn his right hand from before the enemy

Here the Lord's protection is represented by his "right hand." AT: "stopped protecting us from our enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He has burned up Jacob like a blazing fire that devours everything around it

This speaks of how the Lord has destroyed Jacob as if a fire has completely burned it. AT: "He has destroyed Jacob like a blazing fire destroys everything"

#### Jacob

Here "Jacob" refers to the places where his descendants lived. AT: "Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Like an enemy he has bent his bow toward us, with his right is ready to shoot

A soldier has to bend his bow in order to shoot an arrow from it. This speaks of the Lord preparing to attack Israel as if he were an enemy about to shoot them with a bow and arrow. AT: "He has prepared to kill us, like an enemy who has made his bow ready to shoot us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### in the tent of the daughter of Zion

The "daughter of Zion" is a poetic name for Jerusalem, which is spoken of here as if it were a woman. The phrase "tent of the daughter of Zion" speaks of Jerusalem as a "tent" emphasizing that it is the home of those who live there. AT: "who live in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he has poured out his wrath like fire

This speaks of the Lord's wrath as if it were a liquid that he were pouring out on the people. His wrath is also compared to a "fire" to emphasize how destructive it is. AT: "in his anger he has destroyed everything like a blazing fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]

### Lamentations 02:05

#### swallowed up

This speaks of the Lord completely destroying Israel as if he were animal who ate them. See how you translated this in [Lamentations 2:2](./01.md). AT: "completely destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### her palaces ... her strongholds

Israel is spoken of as if it were female.

#### He has increased mourning and lamentation within the daughter of Judah

The words "mourning" and "lamentation" can be expressed as verbs. AT: "He has caused more and more people within the daughter of Judah to mourn and lament" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### daughter of Judah

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. AT: "Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### He has attacked his tabernacle like a garden hut

This speaks of the tabernacle being easily destroyed, as if it were a garden hut. The Lord caused Israel's enemies to destroy it. He did not destroy it himself. AT: "He has caused their enemies to attack his tabernacle as easily as if it were a garden hut" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a garden hut

a very small building for holding farming tools or for sheltering someone who is guarding a garden

#### He has destroyed the place of the solemn assembly

The Lord caused Israel's enemies to destroy it. He did not destroy it himself. AT: "He has caused the place of the solemn assembly to be destroyed" or "He has caused their enemies to destroy the place of the solemn assembly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### caused both solemn assembly and Sabbath to be forgotten in Zion

This can be stated in active form. AT: "caused the people in Zion to forget both solemn assembly and Sabbath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the indignation of his anger

"because he was extremely angry with them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Lamentations 02:07

#### He has given over the walls of her palaces into the hand of the enemy

Here the enemy's "hand" refers to the enemy's control. AT: "He has allowed the enemy to capture the walls of her palaces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the walls of her palaces

Here the word "her" may refer either to the temple or to Jersualem. Possible translations are 1) "the walls of the temple" or 2) "the walls of Jerusalem's palaces." The word "walls" is a synecdoche for the whole building, and the building is a synecdoche for all of Jerusalem.  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### They have raised a shout in the house of Yahweh, as on the day of an appointed feast

This is an ironic comparison between the happy, noisy festivals of Israel and the loud shouts of victory of the Babylonians. AT: "They have raised a shout in the house of Yahweh, as the Israelites would during an appointed feast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### have raised a shout

This is an idiom. AT: "have shouted victoriously" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Lamentations 02:08

#### Yahweh decided to destroy the city wall

Yahweh chose to have the wall destroyed and caused Jerusalem's enemy to destroy it. He did not destroy it himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### daughter of Zion

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### He has stretched out the measuring line

This speaks of preparing to destroy the wall as if he measured it before he destroyed it, so that he knew how much to destroy. AT: "It is as though he has measured the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### has not withheld his hand from destroying

This can be stated without the double negatives. Also, here the Lord is referred to by his "hand." AT: "with his hand he has destroyed the wall" or "he has destroyed the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### He has made the ramparts and wall to lament; together they wasted away

The walls and ramparts are spoken of as if they were people who lamented and died. AT: "Because he has destroyed the ramparts and walls, they are like people who lament and have lost their strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### ramparts

Ancient cities had a main "wall" to keep attackers out, and an outer line of "ramparts" to keep attackers from the wall.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]

### Lamentations 02:10

#### daughter of Zion

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### sit on the ground in silence

Often people would sit on the ground to show they were mourning. AT: "sit on the ground, mourning in silence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### They have thrown dust on their heads and put on sackcloth

These are actions of mourning. AT: "To show their mourning, they have thrown dust on their heads and put on sackcloth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### have bowed their heads to the ground

This is an action of mourning. AT: "have sorrowfully bowed their heads to the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Lamentations 02:11

#### General Information:

The author shifts from describing Jerusalem to describing his own experience.

#### My eyes have failed from their tears

This is an idiom. AT: "I have cried until I cannot cry anymore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my stomach churns

The word "churn" means to move around violently, normally in a circular rotation. This does not mean the stomach is literally churning, but describes how the author feels. AT: "my insides ache" or "my stomach hurts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my inner parts are poured out to the ground

The author speaks of feeling grief in his inner being as if his inner body parts had fallen out of his body onto the ground. AT: "my entire inner being is in grief" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the daughter of my people

This is a poetic name of Jerusalem, which is spoken of here as if it were a woman. AT: "my people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Where is grain and wine?

This rhetorical question is used as a request for something to eat. The children are telling their mother that they are hungry. The phrase "grain and wine" represents food and drink. This question may be written as a statement. AT: "Give us something to eat and drink." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### as they faint like a wounded man

This speaks of the children fainting from hunger and thirst in the same way that a wounded man faints. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### their lives are poured out on the bosom of their mothers

This speaks of the children dying as if their lives were a liquid that was being poured out. AT: "they slowly die in the arms of their mothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Lamentations 02:13

#### General Information:

The author begins to address Jerusalem.

#### What can I say ... Jerusalem?

The author uses this rhetorical question to express that he does not know what to say to help Jerusalem. This question can be written as a statement. AT: "There is nothing that I can say ... Jerusalem." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### daughter of Jerusalem ... virgin daughter of Zion

These are poetic names for Jerusalem, which is spoken of here as if it were a woman. "Zion" is another name for Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### To what can I compare to you ... Zion?

The author uses this rhetorical question to express that he does not know how to give comfort to Jerusalem. This question can be written as a statement. AT: "There is nothing to which I can compare you ... Zion." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Your wound is as great as the sea

This speaks of Jerusalem's great suffering as if it were as terrible as the sea is great. AT: "Your suffering is as terrible as the sea is large" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Who can heal you?

"Who can restore you?" The author uses this rhetorical question to express that there is no one who can restore Jerusalem to the way it was before. This question can be written as a statement. AT: "No one can heal you." or "No one can restore you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### They have not exposed your iniquity to restore your fortunes

"They did not tell you about your sins to restore your fortunes." The word "fortune" refers to a person's wealth and prosperity.

#### for you they gave utterances

The word "utterances" can be expressed with the verb "spoke." AT: "they spoke things to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]

### Lamentations 02:15

#### clap their hands ... hiss and shake their heads

These actions are used to mock and insult others. AT: "mock you by clapping their hands ... hiss and shake their heads" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the daughter of Jerusalem

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Is this the city that they called 'The Perfection of Beauty,' 'The Joy for All of Earth'?

This rhetorical question is used to express sarcasm. This question can be written as a statement. AT: "This city that they called 'The Perfection of Beauty,' 'The Joy for All of Earth,' is not so beautiful or joyful anymore!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The Perfection of Beauty

"Perfectly Beautiful"

#### grind their teeth

This action shows a person's anger and that they are mocking others. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### We have swallowed her up

Here the people speak of destroying Jerusalem as if they were an animal swallowing its food. AT: "We have completely destroyed Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We have lived to see it

This is an idiom. AT: "We have greatly desired to see it happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]

### Lamentations 02:17

#### He has overthrown

"He has destroyed"

#### to rejoice over you

This means that the enemy rejoiced because they defeated them. AT: "to rejoice over defeating you"

#### he has lifted up the horn of your enemies

Here "horn" (that is, an animal horn) represents strength. AT: "he has increased the power of your enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Lamentations 02:18

#### Their heart cried out to the Lord

Here the word "heart" represents the whole person emphasizing one's innermost being. Possible meanings of who cried out are 1) the people of Jerusalem. AT: "The people of Jerusalem shouted to the Lord from their innermost being" or 2) the walls are being personified. AT: "You walls, cry out to the Lord from your innermost being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### walls of the daughter of Zion! Make your tears flow ... of every street

The writer speaks to the walls of Jerusalem. He wants the people of Jerusalem to do what he is telling the walls to do. Some translations take this whole section to be spoken to the "walls," though this can be written with the first phrase "walls of the daughter of Zion!" spoken to the "walls," and the rest of the section spoken directly to the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### the daughter of Zion

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Make your tears flow down like a river

This speaks of the people crying so much that their tears would flow like a river. AT: "Cry many, many tears" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### day and night

These two opposite times of day refer to all the time. AT: "all of the time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### Give yourself no relief, your eyes no relief

"Do not allow yourself and your eyes to rest from crying"

#### at the beginning of the night watches

"many times during the night." This refers to every time a watchman came on duty.

#### Pour out your heart like water before the face of the Lord

The phrase "pour out your heart like water" is an idiom. Here the Lord is represented by his "face" to emphasize his presence. AT: "Tell the Lord how you feel in your inner being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Lift up your hands to him

This was an action often performed while praying. AT: "Lift up your hands to him in prayer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### for the lives of your children

This means for them to request that the Lord save their children. AT: "to save the lives of your children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### at the corner of every street

The word "every" here is an exaggeration for "many." AT: "where the streets come together" or "by the roads" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]

### Lamentations 02:20

#### Should women eat the fruit of their wombs ... for?

This rhetorical question is asked to emphasize that it is not right for women to eat their children. This question can be written as a statement. AT: "Woman should not eat their own children ... for!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the fruit of their wombs

This speaks of children having come from their mother as if they were fruit that came from her womb. AT: "their children that they have given birth to" or "their own children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Should priest and prophet be slaughtered in the sanctuary of the Lord?

This rhetorical question is used to emphasize that the prophets and priests should not be killed. This question can be written as a statement. AT: "The prophets and priests should not be slaughtered in the sanctuary of the Lord!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Should priest and prophet be slaughtered

This can be stated in active form. AT: "Should our enemies slaughter priests and prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]

### Lamentations 02:21

#### Both the young and the old lie on the dust

It is implied here that this refers to dead people. AT: "The corpses of both the young and the old lie on the dust" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Both the young and the old

These phrases refer to people. These two opposites are used to refer to all ages of people. AT: "Both young people and old people" or "People of all ages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### My young women and my young men have fallen by the sword

Here the "sword" refers to their enemies. This is a euphemism that means that they were murdered by their enemies. AT: "My young women and my young men have been murdered by their enemies" or "My enemies have murdered my young women and my young men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### you have slaughtered them

This speaks of Yahweh allowing the poeple to be slaughtered as if he killed them himself. AT: "you allowed them to be slaughtered" or "you allowed this to happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### as you would call the people to a feast day

"as if they were coming to a feast." This speaks of how Yahweh summoned his enemies as if he were inviting them to a feast. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### my terrors

Here the people the author fears are referred to as his "terrors." AT: "the attackers I was afraid of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### on every side

This is an idiom. AT: "to attack from every direction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### on the day of the anger of Yahweh

Here "day" is used as an idiom that refers to a general period of time. AT: "at the time when Yahweh acted in his anger" or "during the time that Yahweh displayed his anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Lamentations 02:intro

#### Lamentations 02 General Notes ####

####### Structure and formatting #######

God has become Judah's enemy. He is determined to destroy them.

##### Links: #####

* __[Lamentations 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Lamentations 03

### Lamentations 03:01

#### Connecting Statement:

A new poem begins. Here the author speaks of the sufferings that his people experienced. He speaks about them as if God had personally attacked only him. However, the writer intends to speak for everyone in the city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### who has seen misery

Here "has seen" represents has experienced. AT: "who has experienced misery" or "who has suffered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### under the rod of Yahweh's fury

Being "under the rod" represents being beaten with a rod. The author speaks of God's punishment as if God had beaten him with a rod. AT: "because Yahweh was very angry and has beaten me with a rod" or "because Yahweh was very angry and has punished me severely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He drove me away

"He forced me to go away"

#### caused me to walk in darkness rather than light

Here "darkness" represents suffering. AT: "caused me to suffer terribly with no hope, like a person walking in darkness rather than light" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he turned his hand against me

Here "turned his hand against me" represents attacking him. The author speaks of God causing bad things to happen to him as if God had attacked him. AT: "he has attacked me" or "he has caused many bad things to happen to me, like someone who attacks a person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He made my flesh and my skin waste away; he broke my bones

Possible meanings are 1) these things are a result of being beaten or 2) these are more ways that God punished the man.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Lamentations 03:05

#### He built up siege works against me

Siege works are ramps that an army builds around a city to enable them to climb over the city walls and invade the city.

#### He built up siege works against me

Possible meanings are 1) the author speaks of God causing bad things to happen to him as if he were a city and God was an enemy that built up siege works against him. AT: "God attacked me like an enemy army that sets up siege works around a city" or 2) the author speaks of God causing the enemy army to attack Jerusalem as if God were the enemy. AT: "God caused the enemy army to build up siege works against me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### surrounded me with bitterness and hardship

This represents God causing him to experience much bitterness and hardship. AT: "caused me to experience much bitterness and hardship" or "caused me to suffer and have many problems" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bitterness

Here "bitterness" represents suffering. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He made me live in dark places, like those who died long ago

Here "dark places" is a metaphor for suffering. The author compares the intensity of his suffering to the intensity of the darkness that those who died long ago experience. AT: "The suffering that he causes me is intense like the darkness of the grave" or "He makes me suffer terribly, as if I were in the darkness of those who died long ago" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### He built a wall around me and I cannot escape. He made my chains heavy

This represents the continuing suffering. Like a person who cannot escape from prison, the author cannot make his suffering stop. AT: "My suffering continues. It is as though he has built a wall around me and put heavy chains on me, and I cannot escape" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he shut out my prayer

The author speaks about God refusing to listen to his prayers as though God was shutting his ears so that the author's prayers could not go into them. AT: "he refuses to hear my prayer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Lamentations 03:09

#### He blocked my path

The author speaks of God causing him to continue to suffer as if God was preventing him from escaping the suffering by blocking his path. AT: "It is as though he blocked my path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a wall of hewn stone

"a wall of cut stones." People would cut stones into regular shapes that could fit together well in order to build a strong wall.

#### he made my paths crooked

Crooked paths do not lead people to where they want to go. Here they represent unsuccessful ways of escaping suffering. AT: "it is as though he has made my paths crooked" or "I have tried to make the suffering stop, but God has prevented me, like one who prevents another from escaping by making his paths crooked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He is like a bear waiting to ambush me, a lion in hiding

The author speaks of God being ready to cause him to suffer more, as if God were a wild animal waiting to attack him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### he turned aside my paths

Possible meanings are 1) "he dragged me off the path" or 2) "he caused my path to turn in the wrong direction"

#### he has made me desolate

"he has made me hopeless" or "he has not allowed me to have any help"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]

### Lamentations 03:12

#### General Information:

God is often spoken of as if he were a warrior.

#### He bent his bow

A soldier has to bend his bow in order to shoot an arrow from it. The author speaks of God deciding to cause him trouble as if God were a warrior ready to shoot him with an arrow. See how you translated this in [Lamentations 2:4](../02/03.md). AT: "It was as if God made his bow ready to shoot"

#### He pierced my kidneys with the arrows of his quiver

The author speaks of the deep grief he feels as if God had shot his kidneys with an arrow. AT: "My grief is great. It is as if he pierced my kidneys with the arrows of his quiver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my kidneys

The kidneys are abdominal organs that move urine into the bladder. They are a metaphor for a person's emotions. AT: "deep into my body" or 2) "my heart" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### quiver

a bag worn on the back in which to store arrows

#### a laughingstock to all my people

The word "all" is a generalization, meaning "most." AT: "a laughingstock to most of my people" or "someone whom all my people mock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### laughingstock

someone whom many people mock

#### He filled me with bitterness

Here "bitterness" represents suffering. It is referred to as if it were something that could fill the speaker. AT: "He has caused me to suffer very much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### forced me to drink wormwood

Wormwood is the bitter juice from the leaves and flowers of a certain plant. Drinking that bitter juice represents suffering. AT: "it is as though he forced me to drink something very bitter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Lamentations 03:16

#### He crushed my teeth with gravel

Possible meanings are 1) the author speaks of God humiliating him as if God had forced him to chew gravel. AT: "He has humiliated me, like someone who forces another to chew gravel" or 2) the author speaks of God humiliating him as if God had pushed his face down into the gravel on the ground. AT: "He has humiliated me, like someone who pushes another man's face down into the gravel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he has pushed me down into the dust

The author speaks of God humiliating him as if God had pushed him down into the dust on the ground. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### My soul is deprived of peace

Possible meanings are 1) the author's experiences are not peaceful. AT: "I have no peace in my life" or 2) the author does not feel peace. AT: "I feel no peace in my soul"

#### My endurance has perished and so has my hope in Yahweh

The author speaks as if his ability to endure more suffering and his hope that Yahweh will help him were living beings that have died. AT: "I cannot endure anymore suffering and I can no longer hope that Yahweh will help me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### endurance

Some versions translate this as "glory" or "splendor."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Lamentations 03:19

#### General Information:

In verses 19 to 42, the writer thinks about the lessons that he and his fellow citizens should learn about God and his anger and mercy.

#### wormwood and bitterness

Wormwood is a plant that gives a liquid which is very bitter to drink. Together "wormwood" and "bitterness" represent severe suffering. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I am bowed down within me

The author speaks of his deep sadness and despair as if he were bowed down. AT: "I am depressed" or "I am discouraged" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### But I call this to mind

This means to intentionally think about something. The word "this" refers to something that the author will start to speak about in the next verse. AT: "But I choose to think about this" or "But I remember this"

#### I have hope

"I hope"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]

### Lamentations 03:22

#### The steadfast love of Yahweh never ceases

The abstract noun "steadfast love" can be expressed with the phrase "love faithfully." AT: "Yahweh never stops loving his people faithfully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### his compassions never end

The abstract noun "compassions" can be translated with the verb "care." AT: "he never stops caring for those who suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### they are new every morning

The word "they" refers to God's steadfast love and compassions. Their being new represents God continuing to act according to them. AT: "every morning he treats us again with steadfast love and compassion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your faithfulness

The word "your" refers to Yahweh.

#### Yahweh is my inheritance

When God gave each tribe of Israel their land, he called it an inheritance. The author speaks of Yahweh being all he needs as if Yahweh were the inheritance that he had received. AT: "Because Yahweh is with me, I have everything I need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Lamentations 03:25

#### Yahweh is good to those who wait for him

Here "good" refers to kindness. AT: "Yahweh is kind to those who wait for him" or "Yahweh does good things for those who wait for him"

#### those who wait for him

Possible meanings are 1) "all those who depend on him" or 2) "the one who waits patiently for him to act."

#### the one who seeks him

Possible meanings for "seeks him" are 1) asking God for help or 2) wanting to know God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that he bear the yoke in his youth

Here "bear the yoke" represents suffering. The abstract noun "his youth" can be expressed with the word "young." AT: "that he suffer while he is young" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Let him sit alone in silence

The phrase "in silence" refers to not speaking. Here it may refer specifically to not complaining. AT: "Let him sit alone without speaking" or "Let him sit alone and not complain"

#### when it is laid upon him

"when the yoke is laid upon him." Here the yoke represents suffering. AT: "when he suffers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let him put his mouth in the dust

Putting the mouth in the dust represents bowing down with one's face on the ground. AT: "Let him lie down with his mouth on the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]

### Lamentations 03:30

#### General Information:

The writer speaks of the one who waits for Yahweh ([Lamentations 3:25](./25.md)).

#### Let him offer his cheek to the one who strikes him

The word "him" refers to anyone who is suffering and who waits for Yahweh. Here "offer his cheek" represents allowing someone to strike his cheek. AT: "Let him allow people to hit him on the face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### let him be filled to the full with reproach

The author speaks of a person as if he were a container and reproach were a liquid. Being filled with reproach represents being reproached much. The implication is that he should be patient when this happens. AT: "let him be insulted much" or "let him be patient when people reproach him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### though he causes grief

"though the Lord causes people to suffer" or "though he afflicts people"

#### he will have compassion

"he will be compassionate to them"

#### For he does not afflict from his heart

Here the heart represents desire or pleasure, and afflicting from the heart represents afflicting with pleasure. AT: "For it does not make him happy to afflict people" or "He does not take pleasure in afflicting people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the children of mankind

This refers to people in general. AT: "human beings" or "people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md)]]

### Lamentations 03:34

#### General Information:

The author wrote in general terms about what is true for all people, but it shows God's concern for his people, the people of Israel, who were being mistreated by their enemies.

#### To crush ... to deny a man justice ... to deny justice

"If people crush ... if they deny a man justice ... if they deny justice"

#### To crush underfoot

Here "crush underfoot" represents abusing and mistreating people. AT: "To abuse" or "To mistreat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])-

#### to deny a man justice

This refers to not allowing a person to have what he deserves. AT: "to deny a person his rights" or "to keep a person from having what he deserves"

#### in the presence of the Most High

Doing something "in the presence of the Most High" represents doing it while knowing that God sees it. AT: "knowing that the Most High sees it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to deny justice to a person

Here "deny justice" refers to not making a just decision for a person in a legal concern. AT: "to judge a person wrongly in court" or "to keep a person who goes to a judge from getting what is right"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Lamentations 03:37

#### Who has spoken and it came to pass, unless the Lord decreed it?

The author uses this rhetorical question to teach that when someone commands something to happen, it will happen only if God has already decreed that it should happen. AT: "No one has spoken and it came to pass, unless the Lord decreed it." or "What someone has commanded to happen has never happened unless the Lord decreed it." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### has spoken

It can be expressed clearly that this refers to commanding something to happen. AT: "has commanded that something should happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### it came to pass

"what he said happened"

#### Is it not from the mouth of the Most High that both calamities and the good come?

The author uses this rhetorical question to teach that both calamities and good things happen only because God has commanded them to happen. AT: "It is only from the mouth of the Most High that both calamities and the good come." or "It is only because the Most High has commanded it that both calamities and good things happen." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### from the mouth of the Most High

Here "mouth" represents what God says or commands. AT: "from the command of the Most High" or "because the Most High has commanded it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### both calamities and the good come

Here "come" represents happening. Also, the nominal adjective "the good" can be stated as "good things." AT: "both calamities and good things happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### How can any person alive complain? How can a person complain about the punishment for his sins?

The author uses these rhetorical questions to teach that people should not complain when God punishes them. AT: "A person should not complain when God punishes him for his sins." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### How can any person alive complain

Possible meanings are 1) it is implied that mere people cannot fully understand God's actions. AT: "How can a mere person complain" or 2) it is implied that being alive is a gift from God. AT: "How can a person who is blessed to be alive complain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Lamentations 03:40

#### General Information:

The writer speaks again about the suffering that God has caused to Jerusalem, but here he speaks of "we" and "us," not "I" and "me."

#### General Information:

In verse 42 the author starts a prayer that he and the people of Israel should pray.

#### let us return to Yahweh

Here "return to Yahweh" represents submitting to him again. AT: "let us submit to Yahweh again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let us lift up our hearts and our hands

Here "lift up our hearts" represents praying sincerely. It was customary for the Israelites to raise their hands when praying to God. AT: "Let us pray sincerely with lifted hands" or "Let us lift up our hands and pray sincerely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### We have transgressed and rebelled

The words "transgressed" and "rebelled" share similar meanings. Together they indicate that transgression is the same as rebelling against Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### You have covered yourself with anger

Here anger is spoken of as if it were a garment that God has put on. Hebrew often spoke of emotions as if they were clothing. AT: "You have been angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you have killed

"you have killed many of us"

#### you have not spared

Here "spared" represents having pity. AT: "you have not had pity on us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Lamentations 03:44

#### Connecting Statement:

The prayer that began in [Lamentations 3:42](./40.md) continues.

#### You have covered yourself with a cloud so that no prayer can pass through

This represents God refusing to listen to the people's prayer. AT: "You refuse to listen to our prayers. It is as though you put a cloud between us and you so that our prayers cannot get to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You have made us like filthy scum and refuse among the nations

The people of Israel are compared to filthy scum and refuse. Possible meanings are 1) God has caused the nations to think of his people as worthless. AT: "You have made the nations think of us as scum and garbage" or 2) God's forcing his people to live among the nations is like throwing them away as garbage. AT: "You have thrown us away like filthy garbage among the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### panic and pitfall have come upon us, ruin and destruction

The abstract nouns "panic," "pitfall," "ruin" and "destruction" can be expressed with verbs. AT: "we are panicking. We are trapped, and we are being ruined and destroyed" or "we are terrified and trapped. We are being completely destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### pitfall

This refers to falling into a pit. Here it represents being trapped in any way.

#### have come upon us

"have happened to us"

#### ruin and destruction

These two words share similar meanings and refer to the destruction of Jerusalem. AT: "total destruction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]

### Lamentations 03:48

#### General Information:

The author speaks about himself again.

#### My eyes flow with streams of tears

Here the author speaks of the great amount of his tears as if they were streams. He uses exaggeration to show that he is very sad and has cried much. AT: "Tears flow from my eyes like water flowing in a river" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### because my people are destroyed

This can stated in active form. AT: "because enemies have destroyed my people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### without ceasing, without relief

Both of these phrases means the same thing. The author speaks of his continuing to cry as if his eyes were a person and had no rest from crying. AT: "without stopping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### until Yahweh from heaven looks down and sees

What the author hopes Yahweh will see can be stated clearly. AT: "until Yahweh looks down from heaven and sees what has happened to my people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Lamentations 03:51

#### My eyes cause me grief

The phrase "My eyes" represents what he sees. AT: "What I see causes me to grieve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### because of all the daughters of my city

It can be stated clearly that the "daughters of my city" are suffering. AT: "because the daughters of my city are suffering" or "because I see the daughters of my city suffering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all the daughters of my city

Possible meanings are 1) the women of Jerusalem or 2) all the inhabitants of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I have been hunted like a bird by those who were my enemies

The author speaks of people looking for him in order to kill him as if he were an animal that they were hunting. This can be stated in active form. AT: "My enemies have looked for me in order to kill me like people who hunt for a bird" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They cast me into a pit

"They threw me into a pit" or "They dropped me into a well"

#### threw a stone on me

Possible meanings are 1) "threw stones down on me" or 2) "covered the pit with a stone"

#### they caused waters to overflow, covering my head

"the level of the water in the pit rose up over my head"

#### I have been cut off

Being "cut off" often represents being killed. Here it represents dying very soon. AT: "I am about to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Lamentations 03:55

#### I called on your name

God's name represents his character, and here, "called on your name" represents trusting God's character and calling on him for help. AT: "I called to you for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from the depths of the pit

Possible meanings are 1) this refers to the pit that author had been thrown into. AT: "from the bottom of the pit" or 2) the author was afraid that he would die soon, so he spoke as if he were in the place of the dead. AT: "from the pit of the dead"

#### You heard my voice

Here "voice" represents what he said. AT: "You heard my words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Do not close your ear

Here "close your ear" represents refusing to listen. AT: "Do not refuse to listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You came near

People often come near to a person they help. Here "came near" represents helping the man. AT: "you helped me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Lamentations 03:58

#### you defended my case, you saved my life

The author speaks of God keeping him from being killed by his enemies as if God had defended him in court as a lawyer defends someone, and kept him from being killed. AT: "you saved my life from my enemies. It is as though you defended me in court" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you defended my case

Here "defended my case" represents arguing for him. AT: "you argued my case for me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### judge my case

Here God is no longer pictured as a lawyer, but as the judge. It can be stated clearly that he wanted God to judge in his favor. AT: "make a decision about me, and show my enemies that I am right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You have seen their insults, all their plots against me

The abstract nouns "insults" and "plots" can be expressed with verbs. AT: "You have seen how they have insulted me and how they have plotted against me many times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### You have heard their scorn ... and all their plans regarding me

The abstract noun "scorn" can be expressed with the verbs "taunt" or "mock." It can be stated clearly that the plans were to harm him. AT: "You heard how they have taunted me ... and all they plan to do to me" or "You have heard them mock me ... and plan ways to harm me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trial.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]

### Lamentations 03:62

#### The lips and the accusations ... come against me all the day

The author speaks of his enemies accusing him all day as if their accusations were soldiers that come to attack him all day. AT: "My enemies speak against me and accuse me through the whole day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The lips ... of my enemies

Here the lips represent what his enemies say. AT: "The words ... of my enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### how they sit and then rise up

These two actions together represent everything the people do. AT: "everything they do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]

### Lamentations 03:64

#### Pay back to them, Yahweh, according to what they have done

Here "Pay back to them" represents punishing them. What they have done can be stated clearly. AT: "Punish them, Yahweh, according to what they have done" or "Yahweh, they have made me suffer, so please make them suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You will let their hearts be shameless

Here the "heart" is a metonym that represents their attitudes and emotions, and being "shameless" means not feeling ashamed of their sins even though they should. Their not being ashamed would give even more reason for God to punish them. AT: "You will let them feel no shame for their sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### May your condemnation be upon them

The abstract noun "condemnation" can be expressed with the verbs "condemn" or "curse." AT: "Condemn them" or "Curse them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### from under the heavens

Here "from under the heavens" represents everywhere on earth. AT: "wherever they are on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Lamentations 03:intro

#### Lamentations 03 General Notes ####

####### Special concepts in this chapter #######

######## Troubles ########

Here the author speaks of the suffering experienced by the people of Jerusalem during the Babylonian siege and after the city's fall. He speaks of these sufferings as if they had been directed against him personally, as if God had personally attacked him. However, we should understand the writer's feelings as having been shared by everyone in the city.

In verse 19, the writer begins to think about the lessons that he and his fellow citizens should learn about God and his anger and his mercy. He also thinks about what it means to repent and to trust in God.

In verse 43, the writer speaks again about the suffering that God has caused to Jerusalem, but here the writer speaks of "we" and "us," not "I" and "me." But in verse 48, he begins to speak about how he himself will continually mourn over what has happened.

In verse 52, the writer begins to think about his personal enemies in Jerusalem, those who persecuted him for bringing Yahweh's messages to the city. He asks for God to show his enemies that he was doing right, and to take revenge on them for their crimes against him.

##### Links: #####

* __[Lamentations 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Lamentations 04

### Lamentations 04:01

#### General Information:

A new poem begins. See [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]].

#### The gold has become tarnished; how the purest gold has changed

The people of Jerusalem are spoken of as if they were gold that is no longer shiny, and therefore no longer valuable. AT: "The people of Jerusalem are like gold that is no longer shiny. They are like pure gold that is no longer beautiful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### how the purest gold has changed

This is an exclamation that shows the author's sadness that this has happened. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### The holy stones are scattered at the corner of every street

This may refer to the temple being destroyed and its stones scattered throughout the city. It may also be a metaphor for the people being scattered. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### at the corner of every street

"wherever the streets come together" or "by all the roads"

#### sons of Zion

Here people of a city are spoken of as if they were the sons of the city. Possible meanings are 1) this refers to only the young men of Jerusalem or 2) this refers to all the people of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they are worth no more than clay jars, the work of the potter's hands

The author speaks of the precious sons of Zion as if they were considered to be inexpensive clay jars. AT: "people consider them to be as worthless as the clay jars that potters make" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/precious.md)]]

### Lamentations 04:03

#### General Information:

Because of the lack of food in the city, the people of Jerusalem do not give their children all they need.

#### the jackals offer the breast to nurse their cubs

This means that mother jackals feed their baby jackals.

#### jackals

fierce wild dogs

#### the daughter of my people ... like the ostriches in the desert

The people in Jerusalem are compared to ostriches because they are cruel to their children. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the daughter of my people has

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. See how you translated this in [Lamentations 2:11](../02/11.md). AT: "my people have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### ostriches

large birds that abandon some of their eggs

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Lamentations 04:04

#### The tongue of the nursing baby sticks to the roof of his mouth by thirst

"Nursing babies are so thirsty that their tongues stick to the top of their mouths"

#### The ones who used to feast on expensive food

"The ones who used to eat a lot of expensive food"

#### now starve in the streets

These people no longer have homes, so they live outside along the streets.

#### those who were brought up wearing purple clothing

Wearing purple clothes was a sign that a person was wealthy. This can be stated in active form. AT: "those who grew up wearing purple clothing" or "those who wore expensive clothing when they were growing up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### now lie upon piles of garbage

These people no longer have homes and soft beds, so they sleep on piles of garbage.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]

### Lamentations 04:06

#### The punishment of the daughter of my people is greater than that of Sodom

The abstract noun "punishment" can be expressed with the verb "punish." AT: "The daughter of my people has been punished more severely than Sodom was punished"

#### the daughter of my people

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. See how you translated this in [Lamentations 2:11](../02/11.md). AT: "my people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### which was overthrown in a moment

The word "which" refers to Sodom. This can be stated in active form. AT: "which God destroyed in a moment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### no hands were wrung for her

This can be stated in active form. AT: "no one wrung their hands for her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### no hands were wrung for her

People sometimes rub and twist their hands when they are worried and cannot fix something, so wringing the hands here represents worrying. The word "her" refers to Jerusalem, which was called "the daughter of my people." AT: "no one was worried about her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md)]]

### Lamentations 04:07

#### Her leaders were purer than snow, whiter than milk

Possible meanings are 1) Jerusalem's leaders were beautiful to look at because they were physically healthy or 2) the leaders were morally pure as new snow and milk are pure white. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Her leaders

"Jerusalem's leaders"

#### their bodies were more ruddy than coral

"their bodies were redder than coral." This implies that they were healthy. AT: "their bodies were healthy and red" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### coral

a rock-hard red substance that comes from the ocean and was used for making decorations

#### sapphire

a costly blue stone used in jewelry

#### Their appearance now is darker than soot

This may be because 1) the sun has darkened the leaders' skin or 2) the soot from the fires that burned Jerusalem has covered their faces.

#### they are not recognized

This can be stated in active form. AT: "no one can recognize them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Their skin has shriveled on their bones

This implies that there was not much muscle or fat under the skin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### it has become as dry as wood

Their dry skin is compared to dry wood. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md)]]

### Lamentations 04:09

#### Those who have been killed by the sword

Here the "sword" represents an enemy's attack. It can be stated in active form. AT: "Those whom enemy soldiers have killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### those killed by hunger

Here "hunger" represents starvation. This can be stated in active form. AT: "those who starved to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]]and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who wasted away

"who became extremely thin and weak"

#### pierced by the lack of any harvest from the field

Here "harvest from the field" is a metonym that represents food to eat. Lack of food is spoken of here as if it were a sword that pierces people. AT: "who died because there was not enough food to eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The hands of compassionate women

Here the women are represented by their "hands." Because they were so hungry, women who had been compassionate in the past were no longer compassionate toward their children; instead they boiled them for food. AT: "Compassionate women" or "Women who had been compassionate in the past" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they became their food

"their children became the women's food"

#### the daughter of my people was

This is a poetic name for Jerusalem, which is spoken of here as if it were a woman. See how you translated this in [Lamentations 2:11](../02/11.md). AT: "my people were" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Lamentations 04:11

#### Yahweh showed all his wrath; he poured out his fierce anger

Yahweh was very angry, and he did everything he wanted to do to show that he was angry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### he poured out his fierce anger

God's punishing his people is spoken of as if his anger were a burning hot liquid that he poured out on them. AT: "because of his fierce anger, he punished his people" or "in fierce anger he responded to his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He kindled a fire in Zion

This represents God causing Israel's enemies to start a fire in Jerusalem. AT: "He caused a fire to start in Zion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### that consumed her foundations

Here "her foundations" represents the whole city, even the part of the city that would be ruined last. AT: "that burned down the city, even its foundations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]

### Lamentations 04:12

#### The kings of the earth did not believe, nor did any of the inhabitants of the world believe,

"The kings of the earth and the rest of the inhabitants of the world did not believe"

#### enemies or opponents

These two words mean basically the same thing and emphasize that these are people who desired to harm Jerusalem. AT: "any kind of enemy" or "any of Jerusalem's enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the sins of her prophets and the iniquities of her priests

These two lines share similar meanings and emphasize that these spiritual leaders were largely responsible for the fall of Jerusalem. AT: "the terrible sins of her prophets and priests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### who have shed the blood of the righteous

Both the priests and the prophets were guilty of murder. Here "shed the blood" represents murder. AT: "who have murdered the righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Lamentations 04:14

#### They wandered, blind, through the streets

The priests and prophets are spoken of as if they were blind because they wandered through the streets, not knowing where to go. AT: "They wandered through the streets like blind men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They were so defiled by that blood

Here "defiled" represents being unacceptable to God. Because the priests and prophets murdered people, they were ritually unclean, unable to worship God or be with ordinary people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### defiled by that blood

"defiled by the blood that they shed." Possible meanings are 1) the blood was on their clothes or 2) "blood" is a metonym for murder. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Away! Unclean

"Go away! You are unclean"

#### Away! Away! Do not touch

"Go away! Go away! Do not touch us"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]

### Lamentations 04:16

#### scattered them

"scattered the prophets and priests"

#### he does not watch over them anymore

Here "watch over them" represents being concerned about them and helping them. AT: "he does not care about them anymore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Lamentations 04:17

#### Our eyes failed, looking in vain for help

Their eyes failing represents their seeking and not being able to find what they were looking for. These two phrases together emphasize that they were trying hard to find help. AT: "We continued looking, but we could not find anyone to help us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for help

The abstract noun "help" can be expressed as a verb. AT: "for people to help us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### in vain

without succeeding

#### we watched for a nation that could not rescue us

Here "watched" represents hoping. It can be stated clearly that they were hoping that a nation would come and rescue them. AT: "we hoped for a nation to come and rescue us, but it could not rescue us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They followed our steps

Here "our steps" represents where they went. AT: "Our enemies followed us everywhere we went" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Our end was near

Here "near" is a metaphor for "soon." AT: "Our end would be soon" or "Our enemies would soon destroy us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Our end

Possible meanings are 1) "Our end" refers to the end of living in their own city because their enemies would destroy the city and capture them. AT: "Our destruction" or "Our capture" or 2) "Our end" refers to the end of their lives. AT: "Our death" or "The time for us to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### our days were numbered

Being numbered represents being so few that they could be easily counted. AT: "we had very little time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### our end had come

The phrase "had come" means that what they had expected was now happening. AT: "it was now the end for us" or "our enemies were attacking us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Lamentations 04:19

#### Our pursuers were swifter than the eagles in the sky

The author compares the speed of their pursuers to the speed of eagles flying. Eagles fly very quickly to catch other animals. AT: "Those who were chasing us were faster than eagles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### lay in wait for us

"waited to attack us"

#### The breath in our nostrils

This phrase refers to the king. He is spoken of as if he were breath; the breath keeps the body alive, and the king keeps his people alive by ruling them well and protecting them from their enemies. AT: "The one who is like breath in our nostrils" or "The one who protects our lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh's anointed one

Here being "anointed" represents being the king. God had told people to anoint whomever he had chosen to be king. AT: "the one whom Yahweh had chosen to be anointed as king" or "the king Yahweh chose" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he was the one who was captured in their pits

Here "pits" refers to the enemies' plans to capture him. This can be stated in active form. AT: "he was the one whom our enemies captured by their plans" or "our enemies made plans to capture our king, and they did capture him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### of whom it was said

This phrase with the quote following it gives us more information about the king. The quote shows what the people had hoped the king would do for them before he was trapped. It can be expressed in active form. AT: "even though we had said about him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Under his shadow we will live among the nations

Here "his shadow" represents him protecting them. AT: "Under his protection we will live among the nations" or "Though we may have to live in other nations, he will protect us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Lamentations 04:21

#### Rejoice and be glad

"Rejoice" and "be glad" mean basically the same thing and emphasize the intensity of gladness. The writer uses these words to mock the people. He knew that the people of Edom would be glad that Jerusalem is being destroyed. AT: "Be very glad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### daughter of Edom

The people of the land of Edom are spoken of as if they were a woman. They were Israel's enemy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### But to you also the cup will be passed

The cup is a metonym for the wine in it. The wine is a metaphor for punishment. AT: "But Yahweh will also punish you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Daughter of Zion

The people of Jerusalem are spoken of as if they were a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])\

#### your punishment will come to an end

"your punishment will end." The abstract noun punishment can be expressed with the verb "punish." AT: "Yahweh will stop punishing you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### he will not extend your exile

"Yahweh will not make your time in exile longer" or "Yahweh will not make you stay in exile longer"

#### he will uncover your sins

Here the sins not being known by others are spoken of as if they are under a cover. Removing the cover represents letting other people know about them. AT: "he will expose your sins" or "he will cause other people to know how you have sinned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/daughterofzion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/daughterofzion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Lamentations 04:intro

#### Lamentations 04 General Notes ####

####### Structure and formatting #######

The story of Judah being destroyed continues in this chapter. Famine destroyed the rulers and the priests. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]])

##### Links: #####

* __[Lamentations 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Lamentations 05

### Lamentations 05:01

#### General Information:

A new poem begins. See [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]].

#### Remember, Yahweh, what has happened to us

"Remember" here is an idiom. AT: "Yahweh, think about what has happened to us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### look and see our disgrace

"look at the shameful state we are in"

#### Our inheritance has been turned over to strangers; our houses to foreigners

The idea of things being turned over to others can be expressed with an active form. Since it is also understood in the second part of the sentence, those words can be repeated there. AT: "You have turned our inheritance over to strangers; you have turned our houses over to strangers" or "You have allowed strangers to take possession of our inheritance; you have allowed foreigners to take possession of our houses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### We have become orphans ... our mothers are like widows

The people of Jerusalem have no one to protect them because the men have either died in battle or have gone into exile. This speaks of the people not having their fathers and husbands present as if they had actually become orphans and widows. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### orphans, the fatherless

These two phrases have the same meaning and emphasize that the people no longer have their fathers. AT: "orphans who have no fathers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### We must pay silver for the water we drink ... our own wood

This means that their enemies are making them pay money to have the water and wood that they once used for free. AT: "We have to pay silver to our enemies in order to drink our own water ... our own wood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### we must pay silver to get our own wood

This can be stated in active form. AT: "our enemies sell us our own wood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Lamentations 05:05

#### Those who are coming after us

"Our enemies who are chasing after us." This refers to the Babylonian army.

#### we can find no rest

This speaks of being able to rest as if "rest" were an object that could be found. AT: "we are unable to rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We have given ourselves to Egypt and to Assyria to get enough food

This phrase "given ourselves" is an idiom. AT: "We have made a treaty with Egypt and with Assyria so that we would have food to eat" or "We have surrendered to Egypt and to Assyria to have enough food to remain alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they are no more

This refers to them being dead. AT: "they have died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### we bear their iniquities

Here "iniquities" represents the punishment received because of their ancestors' sins. AT: "we bear the punishment for their sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Lamentations 05:08

#### Slaves rule over us

Possible meanings are 1) "Now the people who rule over us are themselves slaves to their own masters in Babylon" or 2) "People who used to be slaves in Babylon now rule over us." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to deliver us from their hand

Here the word "hand" refers to control. AT: "to rescue us from their control" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### bread

Here "bread" refers to food in general. AT: "food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### because of the sword in the wilderness

Here robbers with swords are represented by their "swords." AT: "because there are robbers in the wilderness who kill others with swords" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Our skin has grown as hot as an oven because of the burning heat of hunger

This speaks of the peoples' bodies being hot and feverish as if their skin was as hot as an oven. The people have fever because of their hunger. AT: "Our skin has become hot like an oven, and we have a very high fever because we are extremely hungry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Lamentations 05:11

#### Women are raped in Zion, and virgins in the cities of Judah

These two phrases have similar meaning and emphasize that the women are being violated. The words "are raped" are understood in the second part of this sentence and can be repeated. AT: "Women are raped in Zion, and virgins are raped in the cities of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Women are raped ... and virgins

This can be stated in active form. AT: "Our enemies have raped the women ... and the virgins" or "Our enemies have violated the women ... and the virgins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Princes are hung up by their own hands

Possible meanings are 1) the word "their" refers to their enemies. AT: "With their own hands, they hung princes" or 2) they tied each prince's hands together with one end of a rope and tied the other end so the prince's feet could not touch the ground.

#### no honor is shown to the elders

This can be stated in active form. AT: "they have shown no honor to the elders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Lamentations 05:13

#### Young men are forced

This can be stated in active form. AT: "They force young men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### boys stagger under heavy loads of wood

The boys are forced to carry the loads of wood. AT: "boys stagger because they are forced to carry heavy loads of wood" or "they force the boys to carry heavy loads of wood which make them stagger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the city gate

This is where the elders would give legal advice, but also where people would meet socially.

#### the young men have left their music

Playing music was part of the social life at the city gate. This speaks of the men no longer playing their music as if the act of playing music were a place that they left. AT: "the young men have stopped playing their music" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Lamentations 05:15

#### The joy of our heart

Here the word "heart" refers to the whole person and emphasizes their emotions. AT: "Our joy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### The crown has fallen from our head

Possible meanings are 1) "We no longer wear flowers on our heads for celebrations" or 2) The "crown" represents their king and their "head" represents a place of authority over the people. AT: "We no longer have a king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Lamentations 05:17

#### For this our heart has become sick

The "heart" represents a person's emotions. This speaks of a person being discouraged as if their emotions were sick. AT: "Because of this we are discouraged" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for these things our eyes grow dim

This means that they have a hard time seeing because they are crying. AT: "and we can hardly see because our eyes are full of tears" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for Mount Zion lies desolate

Here "Mount Zion" refers to Jerusalem. The phrase "lies desolate" means that no one lives there.

#### jackals

These are fierce wild dogs. See how you translated this in [Lamentations 4:3](../04/03.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]

### Lamentations 05:19

#### sit upon your throne

Here sitting on the throne represents ruling as king. AT: "rule as king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from generation to generation

This is an idiom. AT: "always" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Why do you forget us forever? Why do you forsake us for so many days?

The author uses these rhetorical questions to express his feelings that Yahweh has forgotten them. These questions can be written as a statement. AT: "It is as though you will forget us forever or not come back to us for a very long time!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Restore us to yourself

"Bring us back to yourself"

#### Renew our days as they were long ago

Here "days" represents their lives. AT: "Make our lives good, like they used to be" or "Make us as great as we used to be" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### unless you have utterly rejected us and you are angry with us beyond measure

Possible meanings are 1) that the writer is afraid that Yahweh might be too angry to restore them or 2) that he is saying that Yahweh is too angry to restore them.

#### are angry with us beyond measure

This speaks of Yahweh being very angry as if his anger cannot be measured. This is an exaggeration. AT: "are extremely angry with us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Lamentations 05:intro

#### Lamentations 05 General Notes ####

####### Structure and formatting #######

Judah was destroyed for her sin. As slaves, life was very hard. The author wondered if God would be angry forever. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forever.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forever.md)]])

##### Links: #####

* __[Lamentations 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | __


## Lamentations front

### Lamentations front:intro

#### Introduction to Lamentations ####

##### Part 1: General Introduction #####

####### Outline of the Book of Lamentations #######

1. First lament: Jerusalem is captured and has been abandoned by Yahweh and by its people (1:1–22) 
1. Second lament: Yahweh caused this destruction because he was angry with Jerusalem (2:1–22)
1. Third lament
    - The city sorrows over its destruction (3:1–20)
    - There is comfort for those who turn back to Yahweh (3:21–39)
    - Judah is learning to return to Yahweh (3:40–54)
    - Judah cries out for vengeance upon its enemies (3:55–66)
1. Fourth lament: The terrors of the siege of Jerusalem
    - The punishment of Jerusalem was caused by the people's sin (4:1–20)
    - This punishment had satisfied Yahweh's wrath for their sin (4:21–22a)
    - Edom will be punished also (4:22b)
1. Fifth lament: The broken nation cries out to Yahweh in confession, petition and praise of him (5:1–22)

####### What is the Book of Lamentations about? #######

In the Book of Lamentations, the author expressed grief over the capture of the city of Jerusalem by the Babylonians in about 586 B.C. The book is organized into five poems. In them the writer described how God allowed Jerusalem to be destroyed because the people sinned against him. However, the author also stated that God is always loving and faithful to his people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Who wrote the Book of Lamentations? #######

The name of the author of Lamentations is not given in the text, but it became traditional to say that the author was Jeremiah. The author seems to have seen the destruction of Jerusalem personally. Certainly the serious and grieving words in the book of Jeremiah are similar to the Book of Lamentations. And, there is nothing to suggest that Jeremiah was not the author. 

####### How should the title of this book be translated? #######

Translators may call the book "Poems of Sadness." If translators want to keep to the traditional view that the prophet Jeremiah wrote this book, they might decide on a title such as "The Sad Sayings of Jeremiah." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### Did God abandon Israel? #######

The author of Lamentation often spoke of God abandoning Israel. But this did not mean that God had completely given up on Israel.
He rejected Israel for a period of time as the special place where he would be present. However, God remained faithful to what he promised Israel in his covenant. 

While it was common in the Ancient Neat East to think that a god might leave his city, he usually did so because he was too weak to defend it. In Lamentations, Yahweh abandons Jerusalem because the people sinned against him, not because he was too weak to defend the city. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

####### What is a funeral song? #######

It is common for cultures to sing songs at a funeral or when someone has died. Depending on the culture, these songs can sound either happy or sad. Lamentations is somewhat like a sad song sung at a funeral. Some scholars have said that the rhythm of the poems in Hebrew makes the poems sound slow or sluggish, like a funeral procession. 

##### Part 3: Important Translation Issues #####

####### What style of writing is Lamentations? #######

Lamentations is a collection of five poems. These laments may have been sung or chanted by the Jewish exiles living in captivity in Babylon. They may also have been sung by those Jews who remained in Jerusalem after the Babylonians conquered it. In Chapters 1, 2, and 4 each line of the poem begins with a different Hebrew letter in the order of their alphabet. The third chapter repeats three lines with the same letter. Then they are followed by the next three lines beginning with next letter in the Hebrew alphabet. 

####### Who are the woman and the man in Lamentations? #######

The author uses the image of an abandoned woman and a persecuted man to represent Judah and Jerusalem. This is a type of personification used to make the pain more understandable to the reader. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])



---

