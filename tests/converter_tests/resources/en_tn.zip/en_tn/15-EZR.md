# <a id="ezr"/>Ezra

## Ezra 01

### Ezra 01:01

#### first year

This refers to the beginning of the reign of King Cyrus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Yahweh fulfilled his word that came from the mouth of Jeremiah

Here "mouth" represents speaking. AT: "Yahweh did what Jeremiah prophesied that Yahweh would do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### Yahweh ... stirred Cyrus's spirit

Here Cyrus is represented by his spirit. This speaks of Yahweh causing Cyrus to want to act as if he "stirred" his spirit. AT: "Yahweh ... made Cyrus want to act" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Cyrus' voice went out over his entire kingdom

The voice is a metonym for the message the voice speaks, and the kingdom is a metonym for the people whom a king rules. AT: "Cyrus sent a message to everyone over whom he ruled" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### what was written and spoken

This can be translated in active form. It might be best to translate so the reader understands that other people might have helped Cyrus get the message to the people over whom he ruled. AT: "what Cyrus wrote and what his messengers read so people could hear them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all the kingdoms of the earth

Here "all" is an exaggeration, as there were kingdoms over which Cyrus did not rule. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### for him a house in ... Judea

You may need to make explicit that the house was for people to worship Yahweh. AT: "a house in ... Judea where people can worship him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeremiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jeremiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]

### Ezra 01:03

#### his people

the people who belong to Yahweh.

#### survivors of that land ... should provide them

Those Israelites who choose to stay where they are should help those who choose to go to Jerusalem physically and financially.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md)]]

### Ezra 01:05

#### their work

This refers to the work of the people roused by God in the previous verse.

#### everyone whose spirit God stirred to go

Stirring the spirit is a metonym for making someone want to act. See how you translated these words in [Esra 1:1](./01.md). AT: "everyone whom God had made want to go" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Ezra 01:07

#### Mithredath ... Sheshbazzar

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### put them into the hand of Mithredath the treasurer

Putting an object into someone's hand is a metaphor for allowing that person to do what he wants with that object. Here the reader should understand that Cyrus expected Mithredath to do what Cyrus wanted him to do. AT: "put Mithredath the treasurer in charge of them" or "made Mithredath the treasurer responsible for them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### treasurer

official in charge of money

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]

### Ezra 01:09

#### General Information:

This is a list of numbered items.

#### thirty ... one thousand ... twenty-nine ... 410

"30 ... 1,000 ... 29 ... four hundred and ten" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### basins ... bowls

objects used to hold water for washing

#### 5,400 ... in all

"five thousand four hundred ... in all." This is the total number of items returned to Jerusalem from Babylon, which are listed above individually. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Ezra 01:intro

#### Ezra 01 General Notes ####

####### Structure and formatting #######

The chapter records the story of the first Jews as they return from Persia to Judea.

####### Special concepts in this chapter #######

######## King Cyrus ########
King Cyrus allowed them to return because he wanted them to rebuild the temple. Those who stayed behind gave gifts to those who left to help them on their journey and resettlement. This practice was common under the reign of Cyrus and was used as a way to maintain peace throughout his kingdom. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

####### Possible translation difficulties in this chapter #######
######## Jews ########
Upon return to Judea, the focus of the rest of the Old Testament is on the Jewish people. 

##### Links: #####

* __[Esra Ezra 01:01 Notes](./01.md)__
* __[Esra intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Ezra 02

### Ezra 02:01

#### General Information:

This begins a list of the names of people who returned from the exile.

#### went up

This is an idiom that refers to traveling toward Jerusalem. AT: "returned" or "came back" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Seraiah, Reelaiah, Mordecai, Bilshan, Mispar, Bigvai, Rehum, and Baanah

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### This is the record

This refers to the list of men in 2:3-35.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Ezra 02:03

#### General Information:

This continues the list of the names of people who returned from the exile along with the number in each group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Parosh ... Shephatiah ... Arah ... Pahath-Moab ... Jeshua

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joab.md)]]

### Ezra 02:07

#### General Information:

This continues the list of the names of people who returned from the exile along with the number in each group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Zattu ... Zakkai ... Bani

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md)]]

### Ezra 02:11

#### General Information:

This continues the list of the names of people who returned from the exile along with the number in each group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Bebai ... Azgad ... Adonikam

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bigvai

This is a man's name. See how you translated this in [Esra 2:02](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Ezra 02:15

#### General Information:

This continues the list of the names of people who returned from the exile along with the number in each group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Adin ... Ater ... Bezai

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### ninety-eight

"98" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md)]]

### Ezra 02:19

#### General Information:

This continues the list of people who returned from the exile along with the number in each group. Notice that staring in 2:21 these now are the names of places from where they originally came. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Hashum ... Gibbar

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### ninety-five ... fifty-six

"95 ... 56" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### The men of Bethlehem

This begins to list the number of people whose ancestors had lived in towns in Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Netophah

This is the name of a town in Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]

### Ezra 02:23

#### General Information:

This continues the list people who returned from the exile along with the number in each group whose ancestors came from the places listed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Anathoth ... Azmaveth ... Kiriath Arim ... Kephirah ... Beeroth ... Geba

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### forty-two

"42" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md)]]

### Ezra 02:27

#### General Information:

This continues with the list of people who returned from the exile along with the number in each group whose ancestors came from the places listed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Michmas ... Nebo ... Magbish

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### fifty-two

"52" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]

### Ezra 02:31

#### General Information:

This continues with the list of people who returned from the exile along with the number in each group whose ancestors came from the places listed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Harim ... Lod ... Hadid ... Ono

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md)]]

### Ezra 02:34

#### General Information:

This continues with the list of people who returned from the exile along with the number in each group whose ancestors came from the places listed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Senaah

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Ezra 02:36

#### General Information:

This section lists the names of priests whose descendants returned from the exile along with the number in each group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Jedaiah ... Immer ... Pashhur ... Harim

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jeshua

This is a man's name. See how you translated this in [Esra 2:06](./03.md).

#### Harim

The "Harim" in [Esra 2:32](./31.md) is the name of a place, but here "Harim" is the name of a man.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Ezra 02:40

#### General Information:

This section lists the names of Levites whose descendants returned from the exile along with the number in each group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Kadmiel ... Hodaviah ... Shallum ... Talmon, Akkub, Hatita, and Shobai

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### seventy-four

"74" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### gatekeepers

those in charge of who goes through the gates of the temple

#### Ater

This is a man's name. See how you translated this in [Esra 2:16](./15.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md)]]

### Ezra 02:43

#### General Information:

This section continues listing the names of Levites whose descendants returned from the exile.

#### Ziha, Hasupha, Tabbaoth, Keros, Siaha, Padon, Lebanah, Hagabah ... Hagab, Shalmai, and Hanan

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Akkub

See how you translated this in [Esra 2:42](./40.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Ezra 02:47

#### General Information:

This section continues listing the names of Levites whose descendants returned from the exile. These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Ezra 02:51

#### General Information:

This section continues listing the names of Levites whose descendants returned from the exile. These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Ezra 02:55

#### General Information:

This section continues listing the names of Levites whose descendants returned from the exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 392 total descendants

"three hundred and ninety-two total descendants." This is the number of all the people in this group who came back from the exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Ezra 02:59

#### General Information:

This is a list of people who had returned to Israel from various Babylonian cities but could not prove their heritage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Tel Melah, Tel Harsha, Kerub, Addon, and Immer

These are the names of places in Babylon that no longer exist. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 652 descendants

"six hundred and fifty-two descendants." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Delaiah, Tobiah, and Nekoda

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Ezra 02:61

#### Habaiah ... Hakkoz ... Barzillai

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### their genealogical records

the records that told who their ancestors were

#### could not find them

"could not find their names in the records of the priests"

#### they were excluded from the priesthood as unclean

This can be translated in active form. The abstract noun "priesthood" can be translated as the verb "work as priests." AT: "the other priests treated them as if they were unclean and did not allow them to work as priests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### unclean

not fit to be priests

#### Urim and Thummim

two items like dice that the priests used to decide what God wanted them to do

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Ezra 02:64

#### whole group

This means the whole group that returned back to the land of Judah from the exile.

#### 42,360

"forty-two thousand three hundred and sixty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### their maidservants

"their female servants"

#### these were 7,337

"these were seven thousand three hundred and thirty-seven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### two hundred

"200" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### Ezra 02:66

#### General Information:

This is a list of the animals along with the numbers of each kind that returned with the people from the exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]

### Ezra 02:68

#### sixty-one thousand ... five thousand ... one hundred

"61,000 ... 5,000 ... 100" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### gold darics

A "daric" was a small gold coin used by the Persian Empire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### minas

A mina is a unit of weight. One mina equals 550 grams. Minas are normally linked with measuring silver. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### tunics

garments worn next to the skin

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Ezra 02:70

#### All the people in Israel were in their cities

Everyone went back to their home towns in Judea. Not everyone resettled in Jerusalem.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Ezra 02:intro

#### Ezra 02 General Notes ####

####### Special concepts in this chapter #######

######## Genealogy ########
People had to prove they were priests, or that they were Jews, through their genealogies. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]])

##### Links: #####

* __[Esra Ezra 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Ezra 03

### Ezra 03:01

#### the seventh month

This is the seventh month of the Hebrew calendar. It is at the end of the dry season and the beginning of the early rain season. It is during the last part of September and the first part of October on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### as one man

One man is in only one place and has only one purpose. AT: "for one purpose" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Jeshua

This is the name of a man. Translate the same as in [Esra 2:36](../02/36.md).

#### Shealtiel

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### rose up and built

Standing up is a metaphor for beginning to act. AT: "began to act and built" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### as it is written in the law of Moses

This can be translated in active form. You may need to make explicit whom and what Yahweh had commanded. AT: "as Yahweh had commanded them to do in the law of Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Ezra 03:03

#### established the altar on its stand

"mounted the altar on its stand" or "placed the altar on its stand so it would stay there"

#### dread was on them

This is an idiom. AT: "they were very afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### because of the people of the land

You may need to make explicit what it was about the people of the land that made the Jews afraid. AT: "because they thought the people of the land wanted to attack them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They offered burnt offerings to Yahweh at dawn and evening

One of the first things the people did was to begin offering sacrifices. This was before the temple was rebuilt.

#### the Festival of Shelters

This is a festival that was celebrated for eight days during the seventh month of the Hebrew calendar. It was associated with the time of the exodus when the Israelites lived in tents. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md)]]

### Ezra 03:06

#### the first day of the seventh month

This is the seventh month of the Hebrew calendar. The first day is near the middle of September on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the temple had not been founded

The Jews began the ceremonies of worship even before they started building the temple. AT: "they had not yet laid the foundation for the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as authorized for them by Cyrus, king of Persia

The letters sent by Cyrus gave the Jews permission to buy materials and build the temple.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joppa.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joppa.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]

### Ezra 03:08

#### second month

This is the second month of the Hebrew calendar. This is during the warm season when people are harvesting crops. It is during the last part of April and the first part of May on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the second year

This is during the year after the one in which they returned. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### to the house of God

You may need to make explicit that there was no house of God standing when they arrived. AT: "to where the house of God had stood" or "to where they were going to build the house of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Jeshua ... Jozadak ... Henadad

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### twenty years old

"20 years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Kadmiel

This is a man's name. See how you translated this in [Esra 2:40](../02/40.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zerubbabel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Ezra 03:10

#### laid a foundation

"foundation" in this sense was more than just the stone blocks to support the temple walls. It included the entire temple floor set in stone. This enabled all the temple worshipers to wear their special garments and keep them clean.

#### their garments

"their special robes"

#### cymbals

two thin, round metal plates that are hit together to make a loud sound (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### the hand of David ... had commanded

The hand of a king is a metonym for the power to give commands. AT: "as David ... had commanded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### thankfulness

A feeling and expression of appreciation and gratitude for the kindness of another.

#### His covenant faithfulness to Israel endures forever

The abstract noun "faithfulness" can be stated as "faithfully" or "faithful." AT: "He faithfully loves Israel forever" or "He is always faithful to his covenant with Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]

### Ezra 03:12

#### first house

This refers to the first temple that Solomon built, the house of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### before their eyes

The people are represented by their "eyes" to emphasize what they saw. AT: "in their sight" or "and they saw it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### wept loudly

This refers to emotional expression of sorrow involving tears and vocal sounds.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patriarchs.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patriarchs.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Ezra 03:intro

#### Ezra 03 General Notes ####

####### Structure and formatting #######

This chapter begins the story of the building of the temple and re-establishment of worship in the new temple. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

####### Special concepts in this chapter #######

######## Rebuilding the temple ########
They immediately began the temple worship, even though the temple had not yet been built because they feared the people of the surrounding nations. 

##### Links: #####

* __[Esra Ezra 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Ezra 04

### Ezra 04:01

#### General Information:

The non-Jewish people offer to help build the temple.

#### who had been exiled

This can be translated in active form. AT: "whom the Babylonians had taken into exile" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Zerubbabel

man's name. See how you translated this in [Esra 2:2](../02/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Esarhaddon, king of Assyria

He ruled in Assyria before Cyrus ruled in Persia. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]

### Ezra 04:03

#### Jeshua

man's name. See how you translated this in [Esra 2:06](../02/03.md).

#### It is not you, but we who must build

Possible meanings are 1) the Jewish leader felt that Cyrus had authorized only them to build the temple or 2) building the temple was the exclusive work of the Jews and no non-Jew would be permitted to contribute to the work.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Ezra 04:04

#### the people of the land

"the people who were living in the land at that time," which could include non-Jews and Jews whose families the Babylonians had not taken into exile

#### made the Judeans' hands weak

This speaks of the people of the land discouraging the Judeans as if they made their hands physically weak. AT: "discouraged the Judeans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Judeans

people who returned from Babylon and settled in the land of Judah

#### to frustrate their plans

"to make it so the Judeans could not build the temple as they had planned"

#### wrote an accusation against the inhabitants of Judah and Jerusalem

The abstract nouns "accusation" can be translated as a verb "accuse." You may need to make explicit what the enemies accused the Judeans of doing. AT: "wrote a letter in which they accused those who lived in Judah and Jerusalem of disobeying the king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Ezra 04:07

#### Bishlam ... Mithredath ... Tabeel ... Shimshai

names of men (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The letter

This is the letter spoken of in [Esra 4:6](./04.md).

#### Aramaic

the language used in that area at the time for official business

#### translated

into Persian

#### Rehum

man's name. See how you translated this in [Esra 2:1](../02/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]

### Ezra 04:09

#### Erech ... Susa

names of cities (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ashurbanipal

This is a name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]

### Ezra 04:11

#### This is a copy

Ezra includes in his writing the content of the letter sent to King Artaxerxes.

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated this in [Esra 4:10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### a rebellious city

The city is a metonym for the people who live in it. AT: "a city that they plan to live in and rebel against you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### repaired the foundations

"fixed the foundations" or "mended the foundations"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]

### Ezra 04:13

#### if this city is built and the wall is completed

This can be translated in active form. AT: "if they build the city and complete the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### but they will harm the kings

The word "harm" refers to the Judeans no longer giving money to the kings.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md)]]

### Ezra 04:14

#### we have eaten the palace salt

Possible meanings are that this refers to 1) the writers being loyal to the king or 2) the king giving the writers special honors. AT: "we are loyal to you" or "you have honored us by making us your officials" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a rebellious city

The city is a metonym for the people who live in it. AT: "a city in which live people who have rebelled against your father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the city was destroyed

This can be translated in active form, in which case you will need to make explicit who destroyed the city. The "city" represents the people who live in it. AT: "the Babylonians destroyed the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### if this city and wall are built

This can be translated in active form. See how you translated these words in [Esra 4:13](./13.md). AT: "if they build the city and wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### there will be nothing remaining for you

Here "nothing" is an exaggeration to make the king think that he will be losing much tax money if the Judeans rebel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated this in [Esra 4:10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]

### Ezra 04:17

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated this in [Esra 4:10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The letter that you sent me has been translated and read

This can be translated in active form, in which case you will need to make explicit who translated and read the letter to the king. AT: "I have had my servants translate and read the letter that you sent to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Rehum

man's name. See how you translated this in [Esra 2:2](../02/01.md).

#### Shimshai

man's name. See how you translated this in [Esra 4:8](./07.md).

#### the River

the Euphrates River

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]

### Ezra 04:20

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated this in [Esra 4:10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Tribute and taxes were paid to them

This can be translated in active form. AT: "The people in Jerusalem paid tribute and taxes to those kings" or "Those kings were able to collect tribute and taxes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### make a decree

"make a law"

#### Be careful not to neglect this

The litotes "not to neglect" is an understatement to emphasize that the writers want Artaxerxes to do what they tell him to do. AT: "Be careful to do this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Why allow this threat to grow and cause more loss for the royal interests?

Artaxerxes uses a question to tell them that he understands that he will lose taxes and honor if the city is built. AT: "You must make sure that this threat does not grow and cause more loss for the royal interests." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### threat to grow

Danger is spoken of as if it were a plant that could increase in size. AT: "danger to become worse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### cause more loss for the royal interests

The words "the royal interests" are a metonym for the king himself. AT: "cause more bad things to happen to the kings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Ezra 04:23

#### King Artaxerxes' decree was read

This can be translated in active form, in which case you will need to make explicit who read the decree from the king to the officials. AT: "The messengers from King Artaxerxes read his decree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Rehum

See how you translated this in [Esra 2:1](../02/01.md).

#### Shimshai

See how you translated this in [Esra 4:7](./07.md).

#### the work on the house of God in Jerusalem stopped until the second year of the reign of Darius

This delay lasted about 16 years.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]

### Ezra 04:intro

#### Ezra 04 General Notes ####

####### Structure and formatting #######

The story of the building of the temple and re-establishment of the temple worship continues in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

####### Special concepts in this chapter #######

######## Helping to build the temple ########
The people of the surrounding nations offered to help to build the temple. It is unknown why the Jews refused their help. These other people became their enemies and tried to hinder the work. They even persuaded the king of Persia to stop the Jews from building.

##### Links: #####

* __[Esra Ezra 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Ezra 05

### Ezra 05:01

#### Iddo ... Jeshua ... Jozadak

names of men (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shealtiel

man's name. See how you translated this in [Esra 3:1](../03/01.md).

#### to build the house of God

This was the temple of God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/haggai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/haggai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Ezra 05:03

#### Tattenai ... Shethar-Bozenai

men's names (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated it in [Esra 4:10](../04/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### God's eye was on

The eye represents the person watching over another person. AT: "God was watching over" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### for a letter to be sent to the king and for a decree to be returned to them

This can be translated in active form. AT: "for an official to send a letter to the king and for the king to send a letter back to them with a decree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Ezra 05:06

#### This is a copy of the letter

Ezra includes the contents of the letter to King Darius regarding their work on the temple.

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated this in [Esra 4:10](../04/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Ezra 05:08

#### General Information:

The letter from Tattenai to the king that began in [Esra 5:7](./06.md) continues.

#### timbers

wood for building

#### Who gave you a decree

"Who gave you permission"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Ezra 05:11

#### General Information:

The letter from Tattenai to the king that began in [Esra 5:7](./06.md) continues.

#### We are servants of the one

Possible meaning are 1) they were calling the Jewish people servants of God or 2) those who replied were from the tribe of Levi and Aaron, who were the ones actually responsible for the temple worship and sacrifices.

#### that had been built many years ago when the great king of Israel built it and completed it

This can be translated in active form. AT: "that the great king of Israel had built and supplied all the equipment for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### completed it

"supplied all the equipment for it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Ezra 05:12

#### General Information:

The letter from Tattenai to the king continues. Tattenai continues to tell the king what the Judeans had told him beginning in [Esra 5:11](./11.md).

#### enraged the God of heaven

"made the God of heaven become very angry with us"

#### he gave them into the hand of Nebuchadnezzar king of Babylon, the Chaldean, who destroyed this house and took the people

The hand is a metonym for power or control. Also, "Nebuchadnezzar" represents his army. AT: "allowed the army of Nebuchadnezzar, king of Babylon, the Chaldean, to destroy this house and to take the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### destroyed this house

"tore down this house"

#### Cyrus issued a decree to rebuild the house of God

Cyrus ordered that the people rebuild God's temple.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Ezra 05:14

#### General Information:

The letter from Tattenai to the king that began in [Esra 5:7](./06.md) continues. Tattenai continues to tell the king what the Judeans had told him beginning in ([Esra 5:11](./11.md)).

#### Sheshbazzar

See how you translated this in [Esra 1:7](../01/07.md).

#### He restored them

King Cyrus returned the temple objects.

#### Let the house of God be rebuilt

This can be translated in active form. AT: "I want the Judeans to rebuild the house of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]

### Ezra 05:16

#### General Information:

The letter from Tattenai to the king that began in [Esra 5:7](./06.md) continues. Tattenai continues to tell the king what the Judeans had told him beginning in ([Esra 5:11](./11.md)).

#### it is being constructed, but is not yet complete

This can be translated in active form. AT: "people are now constructing it, but they have not done all the work yet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### constructed

built

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Ezra 05:17

#### General Information:

The letter from Tattenai to the king that began in [Esra 5:7](./06.md) continues. Tattenai has finished telling the king what the Judeans told him and now asks the king to see if what the Judeans told him was true.

#### may it be investigated

This can be translated in active form. AT: "I would like you to have someone investigate this matter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### if a judgment from King Cyrus exists there

"if there is a record there that King Cyrus issued a law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Ezra 05:intro

#### Ezra 05 General Notes ####

####### Structure and formatting #######

The story of the building of the temple and re-establishment of the temple worship continues in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

####### Special concepts in this chapter #######

######## Rebuilding the temple ########
The prophets Haggai and Zechariah encouraged the Jews to begin again building the temple. This was very important to life in Judah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Links: #####

* __[Esra Ezra 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Ezra 06

### Ezra 06:01

#### ordered an investigation

The abstract noun "investigation" can be expressed with the verbs "investigate" or "search." AT: "ordered his officials to investigate" or "ordered his officials to search" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### ordered an investigation

What they were to investigate can be stated clearly. AT: "ordered his officials to investigate the records" or "ordered his officials to search and find out if there was a record of King Cyrus telling the Jews to build the house of God in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### house of archives

This is a building where the king's officials kept the important government records.

#### Ecbatana

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### a scroll was found

This can be stated in active form. AT: "they found a scroll" or "they found a scroll that told about Darius and Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]

### Ezra 06:03

#### General Information:

This begins the record of King Cyrus's command that the Jews rebuild God's temple in Jerusalem.

#### In the first year of King Cyrus

It can be stated clearly that this is the first year of his reign. AT: "In year 1 of the reign of King Cyrus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Let the house be rebuilt

This can be stated in active form. AT: "Let the Jews rebuild the house" or "The Jews must rebuild the house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sixty cubits

"60 cubits." You may convert this to a modern measure. AT: "twenty-seven meters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### cubits, with three rows of large stones and a row of new timber

This can be stated as a new sentence. Possible meanings are 1) this describes how to build the foundation. AT: "cubits. Build the foundation on three layers of large stones covered with one layer of timber" or 2) this describes how to build the walls. AT: "cubits. Build the house's walls with three layers of large stones alternating with one layer of timber" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### let the cost be paid by the king's house

The phrase "the king's house" represents King Cyrus's own wealth in the royal treasury. This can be stated in active form. AT: "I will pay for it with money from the royal treasury" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]

### Ezra 06:06

#### General Information:

This continues the record of King Cyrus's command that the Jews rebuild God's temple in Jerusalem, which began in [Esra 6:3](./03.md).

#### Tattenai ... Shethar-Bozenai

Darius writes directly to these men. Translate their names as in [Esra 5:3](../05/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated it in [Esra 4:10](../04/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Ezra 06:08

#### General Information:

This continues the record of King Cyrus's command that the Jews rebuild God's temple in Jerusalem, which began in [Esra 6:3](./03.md).

#### Funds from the king's tribute beyond the River will be used to pay these men

This can be stated in active form. AT: "Use funds from the king's tribute beyond the river to pay these men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Funds from the king's tribute beyond the River

"The king's tribute" refers to taxes that people pay the king. AT: "Money from the taxes that you collect for the king from the people beyond the river" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Whatever is needed

This can be translated in active form. AT: "Whatever they need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Ezra 06:11

#### General Information:

This continues the record of King Cyrus's command that the Jews rebuild God's temple in Jerusalem, which began in [Esra 6:3](./03.md).

#### a beam must be pulled from his house and he must be impaled on it. His house must then be turned into a rubbish heap

This can be translated in active form. AT: "I command my officials to pull a beam from his house and impale him on it. They are then to turn his house into a rubbish heap" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### beam

a long, sturdy piece of wood, supporting the roof of a house

#### impaled

pierced through

#### who lifts a hand to change ... or to destroy

Lifting the hand represents trying or daring to do something. AT: "who tries to change ... or to destroy" or "who dares to change ... or to destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to change this decree

The abstract noun "decree" can be expressed with the phrase "what I have decreed." AT: "to change what I have decreed" or "to say that I have decreed something else" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]

### Ezra 06:13

#### Tattenai ... Shethar-Bozenai

Translate the names of these men as you did in [Esra 5:03](../05/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The house was completed

This can be translated in active form. You may need to make explicit which house they completed. AT: "They completed God's house" or "They finished building the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the third day of the month of Adar

"Adar" is the name of the twelfth and last month of the Hebrew calendar. It is during the cold season. The third day is near the middle of February on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### sixth year

King Darius had been ruling for five years, so he was now in year number six of his reign. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/haggai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/haggai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cyrus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Ezra 06:16

#### the rest of the captives

These people had been captured and taken to Babylon, but they returned to Jerusalem. AT: "the rest of the people who had been taken captive to Babylon and had returned to Jerusalem" or "the rest of the people who had returned from captivity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### one hundred bulls ... four hundred lambs

"100 bulls ... 400 lambs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### to work divisions

The abstract noun "work divisions" can be expressed with a verbal phrase. AT: "to work in groups" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### work divisions

"groups that work together"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Ezra 06:19

#### fourteenth day of the first month

This is the first month of the Hebrew calendar. The fourteenth day is near the beginning of April on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### purified themselves

"made themselves pure." Being pure represents being acceptable to God. AT: "made themselves acceptable to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Ezra 06:21

#### separated themselves from the uncleanness of the people of the land

Separating themselves from uncleanness represents refusing to do things that make people unclean. AT: "They refused to do the things that the people of the land did that made them unclean" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the uncleanness of the people of the land

Here "uncleanness" represents being unacceptable to God. AT: "the things that the people of the land did that made them unacceptable to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sought Yahweh

Seeking Yahweh represents choosing to know, worship, and obey him. AT: "chose to obey Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### turned the heart of Assyria's king

Turning the king's heart represents making him think differently about the work of the temple. AT: "changed the attitude of Assyria's king" or "made Assyria's king willing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to strengthen their hands in the work of his house

Strengthening their hands in the work represents helping them to work. The Assyrian king did this by telling them to do the work and providing the money for it. AT: "to help them do the work of his house" or "to make it possible for them to do the work of his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the work of his house

This refers to building the temple.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]

### Ezra 06:intro

#### Ezra 06 General Notes ####

####### Structure and formatting #######

The completion of the story of the building of the temple and re-establishment of the temple worship occurs in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

####### Special concepts in this chapter #######

######## Temple taxes ########
The king said the Jews were right and ordered money from his taxes to be used to help them with their sacrifices. 

####### Other possible translation difficulties in this chapter #######
######## Darius ########
In this chapter, Darius is called the king of Assyria. In reality, besides ruling over the former Assyrian Empire, Darius was also king of Persia. Persia had conquered Babylon, which had previously conquered Assyria. This made the king of Persia, the king of Assyria as well. It was unusual to refer to Darius as the king or ruler of Assyria. Ezra may have referred to him in this way to contrast Darius' actions with those of the former rulers of Assyria, who had treated the Jews very cruelly. It was those earlier Assyrian rulers who had conquered the northern tribes of Israel and deported them to other lands. It was for this reasons that the northern tribes lost their identity and were no longer a distinct people group.   

##### Links: #####

* __[Esra Ezra 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Ezra 07

### Ezra 07:01

#### General Information:

Ezra's genealogy goes back to Aaron, the first high priest.

#### Ezra came up from Babylon

Where Ezra came up to can be stated clearly. AT: "Ezra came up to Jerusalem from Babylon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Seraiah

See how you translated this man's name in [Esra 2:2](../02/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shallum

See how you translated this man's name in [Esra 2:42](../02/40.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Azariah, Hilkiah, ... Zadok, Ahitub, Amariah, Azariah, Meraioth, Zerahiah, Uzzi, Bukki, Abishua, Phinehas, Eleazar

This list is all men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]

### Ezra 07:06

#### The king gave him anything he asked

"The king gave Ezra anything he asked for"

#### the hand of Yahweh was with him

The "hand" of Yahweh represents Yahweh's blessing or help. AT: "the blessing of Yahweh was with Ezra" or "Yahweh was blessing Ezra" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the seventh year of King Artaxerxes

This refers to the seventh year of his reign. AT: "in the seventh year that Artaxerxes was king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]

### Ezra 07:08

#### the fifth month

This is the fifth month of the Hebrew calendar. It is during the last part of July and the first part of August on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the first day of the first month

This is near the middle of March on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the first day of the fifth month

This is near the middle of July on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the good hand of God

"Hand" represents the power or control that God uses for good results. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Ezra had established his heart to study

Establishing his heart represents firmly deciding or committing himself to do something. AT: "Ezra committed his life to study" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### carry out

"obey"

#### the statutes and decrees of the law of Yahweh

These were the laws that God passed down to Israel through Moses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Ezra 07:11

#### This was the decree

The text following this statement was the decree given by King Artaxerxes.

#### The King of kings Artaxerxes

"The King of kings" was a title, meaning that he was the greatest of kings, the king that other kings obeyed. AT: "The Great King Artaxerxes" or "Artaxerxes, the greatest king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I am ordering that anyone ... who desires to go to Jerusalem

In those days people needed permission from the king to resettle and rebuild in an area previously destroyed by the conquering nation.

#### may go with you

The word "you" refers to Ezra.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Ezra 07:14

#### Connecting Statement:

This continues the decree that King Artaxerxes gave to Ezra.

#### I, the king, and my seven counselors

The word "I" and the phrase "the king" refer to the same person. The king is reminding the people who hear this letter that he is the author of this letter.

#### to inquire concerning Judah and Jerusalem according to God's law

What they were to inquire about can be stated more clearly. AT: "to investigate the situation in Judah and Jerusalem, in order to learn whether or not they are obeying God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You are to bring the silver and gold

Where they were to bring it can be stated clearly. AT: "You are to bring to Jerusalem the silver and gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the silver and gold that they have freely offered

"Freely" means that they were not forced to offer the money. They gave it because they wanted to. AT: "the silver and gold that they have willingly offered"

#### what is freely offered by the people and the priests

This can be expressed active form. AT: "what the people and the priests have freely offered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/inquire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/inquire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Ezra 07:17

#### Connecting Statement:

This continues the decree that King Artaxerxes gave to Ezra.

#### So buy in full ... offerings

The phrase "in full" means as many as are necessary to complete the task. They were to use the gold and silver to buy all they needed in order to worship God in the temple. AT: "Buy as many of the oxen, rams, lambs, grain and drink offerings as are needed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you and your brothers

The phrase "your brothers" refers to the people who were doing this work with Ezra. AT: "your co-workers" or "your companions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Ezra 07:19

#### Connecting Statement:

This continues the decree that King Artaxerxes gave to Ezra.

#### the objects that were freely given to you

This can be expressed in active form. AT: "the objects that we have freely given to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Place the objects ... before him

The word "him" refers to God.

#### for the service of the house of your God

The abstract noun "service" can be expressed with the verbs "serve" or "use." AT: "to use in the house of your God" or "to serve in the house of your God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### treasury

a secure place where money is stored

### Ezra 07:21

#### Connecting Statement:

This continues the decree that King Artaxerxes gave to Ezra.

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated it in [Esra 4:10](../04/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### that anything that Ezra asks from you should be given in full

This can be expressed in active form. "Give Ezra in full anything he asks of you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### should be given in full

The phrase "in full" here represents whatever quantity necessary to do the work. AT: "should be given as much as he needs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### one hundred silver talents

"100 talents of silver." You may convert this to a modern measure. AT: "3,300 kilograms of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### one hundred cors of grain

You may convert this to a modern measure. AT: "22,000 liters of grain" or "twenty thousand liters of grain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### one hundred baths of oil

You may convert this to a modern measure. AT: 2,200 liters of oil" or "two thousand liters of oil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### his house

This refers to God's temple.

#### For why should his wrath come upon the kingdom of me and my sons?

The king uses this question to say that he does not want God's wrath to come upon them. The implied information is that if they do not do give Ezra what he needs, then God will punish the kingdom. AT: "For we do not want God's wrath to come upon the kingdom of me and my sons." or "For if you do not do these things, God's wrath will come upon the kingdom of me and my sons." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### For why should his wrath come upon the kingdom of me and my sons

God's wrath represents God punishing them. AT: "For why should God punish the kingdom of me and my sons" or "For if you do not do these things, God will punish the kingdom of me and my sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Ezra 07:24

#### Connecting Statement:

This continues the decree that King Artaxerxes gave to Ezra.

#### We are informing them about you not to impose any tribute or taxes

"We are telling them not to impose any tribute or taxes"

#### musicians

people who play musical instruments

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Ezra 07:25

#### Connecting Statement:

This is the end of the decree that King Artaxerxes gave to Ezra.

#### with the wisdom that God has given you, you must appoint judges and discerning men

The abstract noun "wisdom" can be expressed with a verbal phrase. AT: "God has made you wise, so you must wisely appoint judges and discerning men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### whether by death, banishment, confiscation of their goods, or imprisonment

The abstract nouns can be translated with verbs. AT: "whether by killing them, banishing them, confiscating their goods, or imprisoning them" or "You may kill them, send them away, take the things the own, or put them in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Ezra 07:27

#### Connecting Statement:

Ezra praises God because of what King Artaxerxes decreed.

#### placed all this into the king's heart to glorify Yahweh's house in Jerusalem

Placing things in the king's heart represents causing him to have certain thoughts and desires. AT: "caused the king to want to glorify Yahweh's house in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh's house

This refers to Yahweh's temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who extended covenant faithfulness to me

The abstract noun "faithfulness" can be stated as "faithful" or "loyal." AT: "who has been faithful to me" or "who has been loyal to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### I have been strengthened

Being strengthened represents being encouraged. AT: I am encouraged" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by the hand of Yahweh my God

Here Yahweh's hand represents what he did to help Ezra. AT: "because Yahweh has helped me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Ezra 07:intro

#### Ezra 07 General Notes ####

####### Structure and formatting #######

Ezra begins his religious reforms.

####### Special concepts in this chapter #######

######## God's Law ########
The people no longer know the law of Moses. Therefore, the king allows Ezra to return to Judea to teach the people about God's law. Many people go with him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

##### Links: #####

* __[Esra Ezra 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Ezra 08

### Ezra 08:01

#### General Information:

There is an apparent shift in authorship beginning here. Chapters 1-7 were written as if the author was writing about Ezra. Chapter 8 was written as if the author was Ezra.

#### General Information:

Verses 2-14 are a list of leaders and their ancestors. All of them are men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Of the descendants of Phinehas, Gershom

This is the first item in the list. It can be written with the verb "was." AT: "The leader of the descendants of Phinehas was Gershom" or "Gershom was the leader of the descendants of Phinehas"

#### Of the descendants of Ithamar, Daniel

This is the second item in the list. It can be written with the verb "was." AT: "The leader of the descendants of Ithamar was Daniel" or "Daniel was the leader of the descendants of Ithamar"

#### Parosh

See how you translated this man's name in [Esra 2:03](../02/03.md).

#### Of the descendants of David, Hattush, who was ... Parosh; and Zechariah

This is the third item in the list. It can be written with the verb "were." AT: "The leaders of the descendants of David were Hattush who was ... Parosh; and Zechariah" or "The leaders of the descendants of David were Hattush and Zechariah. Hattush was from ... Parosh"

#### Hattush, who was of the descendants of Shecaniah, who was from the descendants of Parosh

This can be written as a separate sentence after "Zechariah." AT: "Hatush was a descendant of Shecaniah, who was a descendant of Parosh"

#### with him there were 150 males listed in the record of his genealogy

"with Zechariah there were 150 males listed in the record of his genealogy"

#### 150 males

"one hundred and fifty males" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]

### Ezra 08:04

#### General Information:

The list of men's names continues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Of the descendants of Pahath-Moab, Eliehoenai son of Zerahiah

This is the next item in the list. It can be written with the verb "was." AT: "The leader of the descendants of Pahath-Moab was Eliehoenai son of Zerahiah" or "Eliehoenai son of Zerahiah was the leader of the descendants of Pahath-Moab"

#### with him were two hundred males

"with Eliehoenai were two hundred males"

#### Zerahiah

See how you translated this man's name in [Esra 7:4](../07/01.md).

#### Adin

See how you translated this man's name in [Esra 2:15](../02/15.md).

#### two hundred ... three hundred ... fifty ... seventy

"200 ... 300 ... 50 ... 70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonathan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonathan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md)]]

### Ezra 08:08

#### General Information:

The list of men's names continues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Of the descendants of Shephatiah, Zebadiah son of Michael

This is the next item in the list. It can be written with the verb "was." AT: "The leader of the descendants of Shephatiah was Zebadiah son of Michael" or "Zebadiah son of Michael was the leader of the descendants of Shephatiah"

#### Shephatiah

See how you translated this man's name in [Esra 2:2](../02/03.md).

#### Michael

This is a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### with him were listed eighty males

"with Zebadiah were listed eighty males"

#### 218 males

"two hundred and eighteen males" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### 160 males

"one hundred and sixty males" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Bebai

See how you translated this in [Esra 2:11](../02/11.md).

#### eighty ... twenty-eight

"80 ... 28" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]

### Ezra 08:12

#### General Information:

This is the end of the list of men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Of the descendants of Azgad, Johanan son of Hakkatan

This is the next item in the list. It can be written with the verb "was." AT: "The leader of the descendants of Azgad was Johanan son of Hakkatan" or "Johanan son of Hakkatan was the leader of the descendants of Azgad"

#### with him were listed 110 males

"with Johanan were listed 110 males"

#### 110 males

"one hundred and ten males" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Those of the descendants of Adonikam

The word "those" refers to the leaders. AT: "The leaders of the descendants of Adonikam"

#### Azgad

See how you translated this man's name in [Esra 2:12](../02/11.md).

#### Adonikam

See how you translated this man's name in [Esra 2:13](../02/11.md).

#### Bigvai

See how you translated this man's name in [Esra 2:2](../02/01.md).

#### sixty ... seventy

"60 ... 70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Ezra 08:15

#### General Information:

The word "I" in chapter 8 refers to Ezra. He is the author.

#### General Information:

Verse 16 contains a list of men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the canal that goes to Ahava

Possible meanings are that the "canal" was 1) a waterway that men built or 2) an ordinary river. It can be translated in a more general way. AT: "the waterway that flows to Ahava"

#### Ahava

This is the name of a place (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shemaiah

See how you translated this man's name in [Esra 8:13](./12.md).

#### Elnathan ... Elnathan ... Elnathan

There were apparently three men with the same name.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]

### Ezra 08:17

#### Iddo

This is a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Next I sent them to Iddo

The word "them" refers to the nine leaders and two teachers written about in [Esra 8:16](./15.md). AT: "Next I sent those men to Iddo" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Kasiphia

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I told them what to say to Iddo ... that is, to send to us servants for the house of God

The words "that is" introduces what he told them to say. AT: "I told them to tell Iddo ... to send us servants for the house of God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Ezra 08:18

#### Sherebiah ... Mahli ... Hashabiah ... Jeshaiah ... Merari

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### So they sent us by our God's good hand a man

God's "good hand" represents his kindness in providing for them. AT: "Because God was kind to us, they sent us a man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a prudent man

This is a man of understanding and wisdom.

#### son of Levi son of Israel

Here "Israel" is a man's name. It is the name God gave to Jacob.

#### eighteen ... twenty

18 ... 20 (See:" [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Jeshaiah

See how you translated this man's name in [Esra 8:7](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### officials

people with specific authority within a government system

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]

### Ezra 08:21

#### the Ahava Canal

This is the name of the canal that flows to the place called Ahava. See how you translated Ahava and canal in [Esra 8:15](./15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### to seek a straight path from him for us, our little ones, and all our possessions

The word "seek" represents asking God to do something for them. Here a "straight path" represents safety while they travel. AT: "to ask God to give us, our little ones, and all our possessions safety while we travel" or "to ask God to protect us, our little ones, and all our possessions while we travel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The hand of our God is on all who seek him

The hand of God being on people is a metonym for God helping people. Seeking God is a metaphor for serving him. AT: "God helps all who serve him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but his might and wrath are on all who forget him

God's might and wrath being on people is a metonym for him punishing people. Forgetting God is a metaphor for refusing to serve him. AT: "but he punishes all who refuse to serve him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### So we fasted and sought God about this

Here seeking God is a metaphor for asking God to do something for them. AT: "So we fasted and asked God to help us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Ezra 08:24

#### Sherebiah, Hashabiah

See how you translated these men's names in [Esra 8:19](./18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Ezra 08:26

#### 650 talents of silver

"six hundred and fifty talents of silver." A talent weighs about thirty-three kilograms. You may convert this to a modern measure. AT: "22,000 kilograms of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### one hundred talents of silver objects

"100 talents of silver objects." You may convert this to a modern measure. AT: "3,300 kilograms of silver objects" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### one hundred talents of gold

"100 talents of gold." You may convert this to a modern measure. AT: "3,300 kilograms of gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### one thousand darics

"1,000 darics." A "daric" was a small gold coin that people in the Persian Empire used. You can translate this in terms of the number of coins or their weight. AT: "one thousand Persian gold coins" or "eight and one half kilograms of gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### bronze vessels

Bronze is a mixture of copper and another metal. It is stronger than pure copper.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Ezra 08:28

#### Then I said to them

"Then I said to the twelve priestly officials"

#### until you weigh them out before the priestly officials, Levites, and leaders

When they arrived in Jerusalem, they would weigh the silver, gold, and bronze to show that they had not taken any of it for themselves.

#### The priests and the Levites

According to the law of Moses, the tribe of Levi had the work of caring for the temple, its possessions, and the offerings.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Ezra 08:31

#### We went out from the Ahava Canal

"We left the Ahava Canal" or "We started traveling from the Ahava Canal"

#### Ahava Canal

This is the name of the canal that flows to the place called Ahava. See how you translated this in [Esra 8:21](./21.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### twelfth day of the first month

This is the first month of the Hebrew calendar. The twelfth day is near the end of March on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### The hand of our God was on us

The hand of God being on people is a metonym for God helping people. AT: "God was helping us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he protected us from the hand of the enemy and the ones ... road

The hand represents what those people might do. It specifically refers to the enemy attacking the group that was traveling. AT: "he protected us from the attack of the enemy and the ones who wished to ambush us along the road" or "He kept the enemy from attacking us and he kept robbers from ambushing us along the road" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the ones who wished to ambush us

This refers to thieves and robbers who wanted to attack them for their treasures.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Ezra 08:33

#### the silver, gold, and objects were weighed out

This can be translated in active form. AT: "the twelve priestly officials weighed out the silver, gold and objects" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the silver, gold, and objects were weighed out ... into the hand of Meremoth

Here "the hand of Meremoth" represents Meremoth's care of the silver, gold, and objects. The men weighed those things and gave them to Meremoth to take care of them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Meremoth ... Uriah ... Eleazar ... Phinehas ... Jozabad ... Jeshua ... Noadiah ... Binnui

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jeshua

See how you translated this man's name in [Esra 2:6](../02/03.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uriah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uriah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Ezra 08:35

#### The ones who came back from the captivity ... the people of exile

These two phrases refer to the Jewish people who were living as exiles in Babylon and who left Babylon and returned to Jerusalem in Judea. AT: "The ones who came back to Jerusalem from the captivity in Babylon, the people of exile"

#### twelve ... ninety-six ... seventy-seven ... twelve

"12 ... 96 ... 77 ... 12" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the governors in the Province Beyond the River

These were the Babylonian officials managing the people west of the Euphrates River, which included the people living in Judea.

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. It included Judea. See how you translated it in [Esra 4:10](../04/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Ezra 08:intro

#### Ezra 08 General Notes ####

####### Special concepts in this chapter #######

######## The people's return to Judah ########
Many people went back to Judah with Ezra. They trusted God to protect them and the precious items they carried with them, which had been given for the temple. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]])

##### Links: #####

* __[Esra Ezra 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Ezra 09

### Ezra 09:01

#### have not separated themselves

have married people from other lands and have adopted their religion

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md)]]

### Ezra 09:03

#### When I heard this

When Ezra heard that many Israelites had married foreign women and were worshiping their gods

#### I tore apart my clothing and robe and pulled out hair from my head and beard

Ezra was showing everyone how unhappy he was that people were doing things that offended God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### evening offering

a sacrifice that the priests would offer around the time the sun was going down

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Ezra 09:05

#### my position of humiliation

another way of saying he was "sitting ashamed" (﻿﻿[Esra 9:4](./03.md)). "where I was sitting on the ground to show how ashamed I was"

#### knelt down and spread my hands

"got on my knees and stretched out my arms with my hands open toward the sky"

#### our iniquities increase over our head, and our guilt grows to the heavens

These words are two ways of speaking of iniquity and guilt as if they were physical objects that could grow to be larger than people. The abstract nouns "iniquity" and "guilt" can be expressed as a noun and an adjective, respectively. AT: "we have committed wicked deeds and we are very guilty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/humiliate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/humiliate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Ezra 09:07

#### the days of our ancestors

"the time when our ancestors were alive"

#### in great guilt ... In our iniquities

The abstract nouns "guilt" and "iniquity" can be translated as an adjective and a verb, respectively. AT: "very guilty ... Because of the evil deeds we did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### we ... were given into the hand of kings

This can be translated in active form. AT: "you gave us ... into the hand of kings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### were given into the hand of kings of this world

Here "hand" represents power or control. AT: "were given into the control of the kings of this world" or "were given over to the kings of this world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to the sword, to captivity, and to plunder and ashamed faces

The sword is a metonym for people killing other people. The abstract nouns "captivity" and "plunder" can be stated as verb phrases. And, "faces" is a synecdoche representing the whole person. AT: "to our enemies to kill us, to capture us, to steal from us, and to cause us shame" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]

### Ezra 09:08

#### mercy from Yahweh our God has come

God deciding to be merciful is spoken of as if mercy were a person who could move. AT: "Yahweh our God has decided to be merciful to us and" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but has extended covenant faithfulness to us

The abstract noun "faithfulness" can be stated as "faithful" or "loyal." See how you translated a similar phrase in [Esra 7:28](../07/27.md). AT: "but he as been faithful to us" or "he has been loyal to us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### in the sight of the king of Persia

The king could not literally see the temple, but he did know about what was happening in Jerusalem. Here "sight" is a metonym for what a person knows. AT: "so that the king of Persia knows about it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### God's house

the temple

#### could give us a wall of safety

The wall that keeps people safe is a metaphor for Yahweh protecting his people. AT: "could keep us safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Ezra 09:10

#### for all time

"until the end of the ages"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Ezra 09:13

#### for our evil practices and our great guilt

The abstract nouns "practices" and "guilt" can be translated as a noun and an adjective, respectively. AT: "because of the bad things we did and because we were so guilty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### have held back what our iniquities deserve and left us survivors

"would be just if you killed us all, but you have not punished us and instead left some of us alive"

#### should we again break your commandments and make ... people?

This can be translated as a statement. AT: "it is very wrong that some of us have broken your commandments and made ... people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will you not be angry ... escape?

This can be translated as a statement. AT: "I am afraid that you will be angry ... escape." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Ezra 09:15

#### Look

"Pay attention to what I am about to say"

#### We are here before you in our guilt

"You can see that we are all guilty"

#### there is no one who can stand before you

"you do not think that any person is innocent"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]

### Ezra 09:intro

#### Ezra 09 General Notes ####

####### Special concepts in this chapter #######

######## Intermarriage ########
When Ezra found out that many Jews had married Gentile wives, he prayed to God and asked God why he had been so good to them by letting these few people return from captivity even though they sinned by marrying Gentile wives. They did this before and God had punished them for it. God forbid this type of marriage because it caused the people to worship other gods. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

##### Links: #####

* __[Esra Ezra 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Ezra 10

### Ezra 10:01

#### As Ezra prayed and confessed ... threw himself down

Ezra speaks of himself as if he were someone else. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### threw himself down

quickly went from standing to lying facedown

#### before God's house

in front of the temple

#### Shekaniah

See how you translated this in [Esra 8:5](../08/04.md).

#### Jehiel

See how you translated this in [Esra 8:9](../08/08.md).

#### We have been unfaithful to our God

This was made as a public confession, not as a boastful claim.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]

### Ezra 10:03

#### we are with you

"we will help you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Ezra 10:05

#### Jehohanan ... Eliashib

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]

### Ezra 10:07

#### Anyone who did not come ... forfeited all of his possessions and would be excluded

"The officials would take all the possessions away from anyone who did not come ... and would excuse them" or "The people of Judah and Jerusalem would take all the possessions away from anyone who did not come ... and would exclude them"

#### three days

3 days (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Ezra 10:09

#### in three days

"three days later"

#### ninth month and the twentieth day of the month

This is the ninth month of the Hebrew calendar. The twentieth day is near the middle of December on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### in the square

a large open courtyard in front of the temple

#### committed treason

The abstract noun "treason" can be translated as a verb. AT: "helped the enemies of your people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### so as to increase Israel's guilt

"and now God considers us guilty of worse sin than before"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]

### Ezra 10:11

#### Separate from

move away from, be different from

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Ezra 10:12

#### this is not only one or two days of work

This litotes can be translated in positive form. AT: "we will need a long time to do all this work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]

### Ezra 10:14

#### at the time that will be fixed with the city elders and the city judges

This can be translated in active form and as separate sentences. AT: "at the time that you will determine. Let them come with the city elder and the city judges" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Jonathan ... Asahel ... Jahzeiah ... Tikvah ... Meshullam ... Shabbethai

men's names (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jonathan son of Asahel and Jahzeiah son of Tikvah opposed this

Possible meanings are, 1) these men did not want the city officials to investigate the offenses or 2) they did not want anyone to investigate the people's marriages.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonathan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonathan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Ezra 10:16

#### did this

The people investigated who had married non-Jewish wives.

#### the first day of the tenth month

This is the tenth month of the Hebrew calendar. The first day is near the middle of December on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### first day of the first month

This is near the middle of March on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]

### Ezra 10:18

#### Jeshua

See how you translated this in [Esra 2:2](../02/01.md).

#### Jozadak

See how you translated this in [Esra 3:2](../03/01.md).

#### Maaseiah ... Gedaliah

names of men (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eliezer ... Jarib

See how you translated this in [Esra 8:16](../08/15.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]

### Ezra 10:20

#### General Information:

Ezra continues to list the men who married non-Jewish women.

#### Immer ... Pashhur

names of men. See how you translated this in [Esra 2:37](../02/36.md).

#### Hanani ... Elioenai ... Nethanel ... Elasah

names of men (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zebadiah

name of a man. See how you translated this in [Esra 8:08](../08/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Harim

name of a man. See how you translated this in [Esra 2:32](../02/31.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Maaseiah

name of a man. See how you translated this in [Esra 10:18](./18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shemaiah ... Jehiel

names of men. See how you translated this in [Esra 8:13](../08/12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jozabad

name of a man. See how you translated this in [Esra 8:33](../08/33.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ishmael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ishmael.md)]]

### Ezra 10:23

#### General Information:

Ezra continues to list the men who married non-Jewish women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jozabad

man's name. See how you translated this in [Esra 8:33](../08/33.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eliashib

man's name. See how you translated this in [Esra 10:6](./05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shallum

man's name. See how you translated this in [Esra 2:42](../02/40.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Parosh

man's name. See how you translated this in [Esra 2:03](../02/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eleazar

man's name. See how you translated this in [Esra 7:05](../07/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Ezra 10:26

#### General Information:

Ezra continues to list the men who married non-Jewish women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Elam ... Zattu ... Bani

These are men's names. See how you translated this in [Esra 2:7-10](../02/07.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jehiel

This is man's name. See how you translated this in [Esra 8:09](../08/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Elioenai

man's name. See how you translated this in [Esra 10:22](./20.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eliashib

This is a man's name. See how you translated this in [Esra 10:06](./05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bebai

This is a man's name. See how you translated this in [Esra 2:11](../02/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jehohanan

This is a man's name. See how you translated this in [Esra 10:06](./05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Meshullam

This is a man's name. See how you translated this in [Esra 8:16](../08/15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]

### Ezra 10:30

#### General Information:

Ezra continues to list the men who married non-Jewish women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Pahath-Moab

man's name. See how you translated this in [Esra 8:04](../08/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Benaiah ... Malchijah

men's names. See how you translated this in [Esra 10:25](./23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Maaseiah

man's name. See how you translated this in [Esra 10:18](./18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mattaniah

man's name. See how you translated this in [Esra 10:26](./26.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Binnui

man's name. See how you translated this in [Esra 8:33](../08/33.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Harim

man's name. See how you translated this in [Esra 2:32](../02/31.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eliezer

man's name. See how you translated this in [Esra 8:16](../08/15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Malluk

man's name. See how you translated this in [Esra 10:29](./26.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Ezra 10:33

#### General Information:

Ezra continues to list the men who married non-Jewish women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hashum

man's name. See how you translated this in [Esra 2:19](../02/19.md) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zabad

man's name. See how you translated this in [Esra 10:27](./26.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eliphelet

man's name. See how you translated this in [Esra 8:13](../08/12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Manasseh

man's name. See how you translated this in [Esra 10:30](./30.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shimei ... Benaiah

men's names. See how you translated this in [Esra 10:23](./23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bani

man's name. See how you translated this in [Esra 2:10](../02/07.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Meremoth

man's name. See how you translated this in [Esra 8:33](../08/33.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eliashib

man's name. See how you translated this in [Esra 10:06](./05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Ezra 10:37

#### General Information:

Ezra continues to list the men who married non-Jewish women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mattaniah ... Adaiah

men's names. See how you translated this in [Esra 10:26](./26.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mattenai

man's name. See how you translated this in [Esra 10:33](./33.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Binnui

man's name. See how you translated this in [Esra 8:33](../08/33.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shimei

man's name. See how you translated this in [Esra 10:23](./23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Ezra 10:41

#### General Information:

Ezra finishes to list the men who married non-Jewish women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shelemiah

man's name. See how you translated this in [Esra 10:39](./37.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shemariah

man's name. See how you translated this in [Esra 10:32](./30.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shallum

man's name. See how you translated this in [Esra 2:42](../02/40.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Amariah

man's name. See how you translated this in [Esra 7:03](../07/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Nebo

man's name. See how you translated this in [Esra 2:29](../02/27.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jeiel

man's name. See how you translated this in [Esra 8:13](../08/12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zabad

man's name. See how you translated this in [Esra 10:27](./26.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zebina ... Jaddai ... Joel

mens' names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Benaiah

man's name. See how you translated this in [Esra 10:25](./23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### All of these

all the men in the list beginning in [Esra 10:20](./20.md)

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Ezra 10:intro

#### Ezra 10 General Notes ####

####### Special concepts in this chapter #######

######## Intermarriages ########
The people agree to divorce their Gentile wives. Many Jews were involved in these mixed marriages. Divorce should not normally have been common for the Jews to engage in, but marriage with non-Jewish women was not allowed. 

##### Links: #####

* __[Esra Ezra 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | __


## Ezra front

### Ezra front:intro

#### Introduction to Ezra ####

##### Part 1: General Introduction #####

####### Outline of Ezra #######

1. The first Jewish exiles return to Jerusalem from Persia (1:1–2:70)
1. The rebuilding of the temple in Jerusalem and reestablishment of temple worship (3:1–6:22)
1. More exiles return, and Ezra leads religious reformation and implementation of the law of Yahweh (7:1–10:44)
    - Ezra teaches the people the Law of Yahweh and sets apart the priests and Levites for their service (8:1–36)
    - The problem of inter-marriage, and the solution (9:1–10:44)

####### What is the Book of Ezra about? #######

The Book of Ezra is about how the people of Israel returned from Babylon and tried to worship Yahweh again as the law required. To do this they needed to establish their nation again and affirm their covenant with Yahweh. They also needed to rebuild their temple so they could sacrifice to Yahweh.(See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]) 

####### How should the title of this book be translated? #######

The Book of Ezra is named for the priest Ezra who led the first group of Jews out of exile and back to Judah. Translators might choose to make the title clearer, for example, "The book about Ezra." 

##### Part 2: Important Religious and Cultural Concepts #####

####### Why were Israelites not allowed to marry people from other nations? #######

Foreigners worshiped many false gods. Yahweh did not allow his people to marry foreigners because he knew this would cause the people of Israel to worship other gods. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

####### Did all of the people of Israel return to their homeland? #######

Many of the Jews remained in Babylon instead of returning to the Promised Land. Many of them had become successful in Babylon and desired to remain there. However, this meant that they were unable to participate in the temple worship as their ancestors had done. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

##### Part 3: Important Translation Issues #####

####### How does the Book of Ezra use the term "Israel"? #######

The Book of Ezra uses the term "Israel" to refer to the kingdom of Judah, which was composed mostly of the two tribes of Judah and Benjamin. The other ten tribes had ended their loyalty to any kings descended from David. God allowed the Assyrians to conquer the other ten tribes and take them into exile. As a result, they became a part of other ethnic groups and did not return to the land of Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]])

####### Are the events in the Book of Ezra told in the order that they actually happened? #######

Some of the events in the Book of Ezra are not told in the order they actually happened. Translators should pay attention to notes that signal when events are probably out of order with each other.



---

