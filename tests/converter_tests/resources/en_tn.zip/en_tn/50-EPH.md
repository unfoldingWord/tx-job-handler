# <a id="eph"/>Ephesians

## Ephesians 01

### Ephesians 01:01

#### General Information:

Paul names himself as the writer of this letter to the believers at the church at Ephesus.

#### General Information:

Except where noted, all instances of "you" and "your" refers to the Ephesian believers as well as all believers and so are plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Paul, an apostle ... to God's holy people in Ephesus

Your language may have a particular way of introducing the author of a letter and its intended audience. AT: "I, Paul, an apostle ... write this letter to you, God's holy people Ephesus"

#### who are faithful in Christ Jesus

"In Christ Jesus" and similar expressions are metaphors that frequently occur in the New Testament letters. They express the strongest kind of relationship possible between Christ and those who believe in him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Grace to you and peace

This is a common greeting and blessing that Paul often uses in his letters.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Ephesians 01:03

#### Connecting Statement:

Paul opens his letter by talking about the believers' position and their safety before God.

#### General Information:

In this book, unless otherwise stated, the words "us" and "we" refer to Paul, the believers in Ephesus, as well as all believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### May the God and Father of our Lord Jesus Christ be praised

This can be stated in an active form. AT: "Let us praise the God and Father of our Lord Jesus Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who has blessed us

"for God has blessed us"

#### every spiritual blessing

"every blessing coming from the Spirit of God"

#### in the heavenly places

"in the supernatural world." The word "heavenly" refers to the place where God is.

#### in Christ

Possible meanings 1) the phrase "in Christ" refers to what Christ has done. AT: "through Christ" or "through what Christ has done"  or 2) "in Christ" is a metaphor referring to our close relationship with Christ. AT: "by uniting us with Christ" or "because we are united with Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### holy and blameless

Paul uses two similar words to emphasize moral goodness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]

### Ephesians 01:05

#### General Information:

The words "his," "He," and "he" refer to God.

#### God chose us beforehand for adoption

The word "us" refers to Paul, the Ephesian church, and all believers in Christ. AT: "God planned long ago to adopt us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### God chose us beforehand

"God chose us ahead of time" or "God chose us long ago"

#### for adoption as sons

Here "adoption" refers to becoming part of God's family. Here the word "sons" refers to males and females. AT: "to be adopted as his children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### through Jesus Christ

God brought believers into his family by the work of Jesus Christ.

####  he has freely given us in the One he loves.

"he has kindly given to us by means of the One he loves"

#### the One he loves

"the One he loves, Jesus Christ" or "his Son, whom he loves"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Ephesians 01:07

#### riches of his grace

Paul speaks of God's grace as if it were material wealth. AT: "greatness of God's grace" or "abundance of God's grace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He lavished this grace upon us

"He gave us this great amount of grace" or "He was extremely kind to us"

#### with all wisdom and understanding

Possible meanings are 1) "because he has all wisdom and understanding" 2) "so that we might have great wisdom and understanding"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]

### Ephesians 01:09

#### according to what pleased him

Possible meanings are 1) "because he wanted to make it known to us" or 2) "which was what he wanted."

#### which he demonstrated in Christ

"he demonstrated this purpose in Christ"

#### in Christ

"by means of Christ"

#### with a view to a plan

A new sentence can be started here. AT: "He did this with a view to a plan" or "He did this, thinking about a plan"

#### for the fullness of time

"for when the time is right" or "for the time that he has appointed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Ephesians 01:11

#### we were appointed as heirs

This can be stated in active form. AT: "God chose us to be heirs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### We were decided on beforehand

This can be stated in active form. AT: "God chose us ahead of time" or "God chose us long ago" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### we were appointed as heirs ... We were decided on beforehand

By means of these pronouns "we," Paul is referring to himself and the other Jewish Christians, those who trusted Christ before the Ephesian believers did. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### so that we might be the first

Again, the word "we" refers to the Jewish believers who first heard the good news, not the believers at Ephesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### so we would be for the praise of his glory

"so that we would live to praise him for his glory"

#### so that we might be the first ... so we would be for the praise

Once again, the pronouns "we" refer to Paul and the other Jewish believers, not to the Ephesian believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Ephesians 01:13

#### General Information:

Paul was speaking in the previous two verses about himself and the other Jewish believers, but now he begins speaking about the Ephesian believers.

#### the word of truth

"Word" here is a metonym for "message." AT: "God's message about truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### were sealed with the promised Holy Spirit

Wax was placed on a letter and stamped with a symbol representing the person who wrote the letter. Paul uses this custom as a picture to show how God has used the Holy Spirit to assure us that we belong to him. AT: "God has sealed you with the Holy Spirit that he promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the guarantee of our inheritance

Receiving what God has promised is spoken of as though one inherits property or wealth from a family member. AT: "the guarantee that we will receive what God has promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Ephesians 01:15

#### Connecting Statement:

Paul prays for the Ephesian believers and praises God for the power that believers have through Christ.

#### I have not stopped thanking God

Paul uses "not stopped" to emphasize that he continues to thank God. AT: "I continue to thank God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Ephesians 01:17

#### a spirit of wisdom and revelation in the knowledge of him

"spiritual wisdom to understand his revelation"

#### that the eyes of your heart may be enlightened

The phrase "eyes of your heart" expresses one's ability to gain understanding. AT: "that you may gain understanding and be enlightened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### that the eyes of your heart may be enlightened

This may be stated in the active tense. AT: that God may enlighten your heart" or "that God may enlighten your understanding" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### enlightened

"made to see"

#### inheritance

Receiving what God has promised believers, is spoken of as if one were inheriting property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### all God's holy people

"all those whom he has set apart for himself" or "all those who belong completely to him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Ephesians 01:19

#### the incomparable greatness of his power

God's power is far beyond all other power.

#### toward us who believe

"for us who believe"

#### the working of his great strength

"his great power that is at work for us"

#### raised him

"made him alive again"

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To come back from among them speaks of becoming alive again.

#### seated him at his right hand
To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "seated him in the place of honor and authority beside him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### in the heavenly places

"in the supernatural world." The word "heavenly" refers to the place where God is. See how you translated this in [Ephesians 1:3](./03.md).

#### far above all rule and authority and power and dominion

These are different terms for the ranks of supernatural beings, both angelic and demonic. AT: "far above all types of supernatural beings"

#### every name that is named

This can be stated in active form. AT: Possible meanings are 1) "every name that man gives" or 2) "every name that God gives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### name

Possible meanings are 1) title or 2) position of authority. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in this age

"at this time"

#### in the age to come

"in the future"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md)]]

### Ephesians 01:22

#### all things under Christ's feet

Here "feet" represents Christ's lordship, authority, and power. AT: "all things under Christ's power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### head ... his body

Just as with a human body, the head rules all things pertaining to its body, so Christ is the head of the church body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### head over all things

Here "head" refers to the leader or the one who is in charge. AT: "ruler over all things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the fullness of him who fills all in all

"Christ fills the church with his life and power just as he gives life to all things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Ephesians 01:intro

#### Ephesians 01 General Notes ####

####### Structure and formatting #######

######## "I pray" ########

This chapter is structured loosely as a prayer, but it is not a typical prayer. This is a unique "prayer" where Paul is not just talking to God. He is also giving written instructions to the church in Ephesus. 

####### Special concepts in this chapter #######

######## Predestination ########
Many scholars believe this chapter teaches on a subject known as "predestination." This is related to the biblical concept of "predestine." Some scholars take this to indicate that God has chosen some to be eternally saved before the foundation of the world. Since this is a source of theological diversity, extra care should be taken in translation, especially with regards to elements of causation in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md)]])

##### Links: #####

* __[Ephesians 01:01 Notes](./01.md)__
* __[Ephesians intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Ephesians 02

### Ephesians 02:01

#### Connecting Statement:

Paul reminds the believers of their past and the way they now are before God.

#### you were dead in your trespasses and sins

This shows how sinful people are unable to obey God in the same way a dead person is unable to respond physically. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your trespasses and sins

The words "trespasses" and "sins" have similar meanings. Paul uses them together to emphasize the greatness of the people's sin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### according to the ways of this world

The apostles also used "world" to refer to the selfish behaviors and corrupt values of the people living in this world. AT: "according to the values of people living in the world" or "following the principles of this present world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the ruler of the authorities of the air

This refers to the devil or Satan.

#### the spirit that is working

"the spirit of Satan, who is working"

#### the desires of the body and of the mind

The words "body" and "mind" represent the entire person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### children of wrath

people with whom God is angry (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Ephesians 02:04

#### God is rich in mercy

"God is abundant in mercy" or "God is very kind to us"

#### because of his great love with which he loved us

"because of his great love for us" or "because he loves us very much"

#### While we were dead in trespasses, he made us alive together in Christ

This shows how a sinful person is unable to obey God until he is given new spiritual life just like a dead person is unable to respond physically unless he is raised from the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he made us alive together in Christ

"In Christ" and similar expressions are metaphors that frequently occur in the New Testament letters. They express the strongest kind of relationship possible between Christ and those who believe in him.

#### by grace you have been saved

This can be stated in an active form. AT: "God saved us because of his great kindness toward us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### God raised us up together with Christ, and God made us sit together in the heavenly places in Christ Jesus

"Raised" here is an idiom for "established." AT: "God established us together with Christ, and God made us sit together in the heavenly places in Christ Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### in the heavenly places

"in the supernatural world." The word "heavenly" refers to the place where God is. See how this is translated in [Ephesians 1:3](../01/03.md).

#### in Christ Jesus

"In Christ Jesus" and similar expressions are metaphors that frequently occur in the New Testament letters. They express the strongest kind of relationship possible between Christ and those who believe in him.

#### in the ages to come

"in the future"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Ephesians 02:08

#### For by grace you have been saved through faith

God's kindness to us is the reason he made it possible for us to be saved from judgment if we simply trust in Jesus. AT: "God saved you by grace because of your faith in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this did not

The word "this" refers back to "by grace you have been saved by faith."

#### Grace is not from works and so no one may boast

"Grace is not based on what a person does, so that no one can boast and say that they earned it"

#### in Christ Jesus

"In Christ Jesus" and similar expressions are metaphors that frequently occur in the New Testament letters. They express the strongest kind of relationship possible between Christ and those who believe in him.

#### walk in

"Walk in" here is an idiom for "obey." "follow" or "do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Ephesians 02:11

#### Connecting Statement:

Paul reminds these believers that God has now made Gentiles and Jews into one body through Christ and his cross.

#### Gentiles in the flesh

This refers to people who were not born Jewish. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### uncircumcision

Non-Jewish people were not circumcised as babies and thus the Jews considered them people who do not follow any of God's laws. AT: "uncircumcised pagans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### circumcision

This was another term for Jewish people because all male infants were circumcised. AT: "circumcised people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### separated from Christ

"unbelievers"

#### what is called the "circumcision" in the flesh made by human hands

Possible meanings are 1) "Jews, who are circumcised by humans" or 2) "Jews, who circumcise the physical body."

#### by what is called

This can be translated with an active form. AT: "by what people call" or "by those whom people call" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### strangers to the covenants of the promise

Paul speaks to the Gentile believers as if they had been foreigners, kept out of the land of God's covenant and promise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Ephesians 02:13

#### But now in Christ Jesus

Paul is marking a contrast between the Ephesians before they believed in Christ and after they believed in Christ.

#### you who once were far away from God have been brought near by the blood of Christ

Not belonging to God due to sin is spoken of as being far away from God. Belonging to God because of the blood of Christ is spoken of as being brought near to God. AT: "you who once did not belong to God now belong to God because of the blood of Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by the blood of Christ

The blood of Christ is a metonym for his death. AT: "by Christ's death" or "when Christ died for us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he is our peace

"Jesus gives us his peace"

#### our peace

The word "our" refers to Paul and his readers and so is inclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### He made the two one

"He made the Jews and Gentiles one"

#### By his flesh

The words "his flesh," his physical body, are a metonym for his body dying. AT: "By the death of his body on the cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the wall of hostility

"the wall of hatred" or "the wall of ill will"

#### that divided us

The word "us" refers to Paul and the Ephesians. The Ephesians, as Gentiles, were separated from Paul and the other Jews. AT: "that separated us Jews and Gentiles from one another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### he abolished the law of commandments and regulations

Jesus' blood satisfied the law of Moses so that both the Jews and Gentiles can live at peace in God.

#### one new man

a single new people, the people of redeemed humanity (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in himself

It is union with Christ that makes reconciliation possible between Jews and Gentiles.

#### Christ reconciles both peoples

"Christ brings the Jews and the Gentiles together in peace"

#### through the cross

The cross here represents Christ's death on the cross. AT: "by means of Christ's death on the cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### putting to death the hostility

Stopping their hostility is spoken of as if he killed their hostility. By dying on the cross Jesus eliminated the reason for Jews and Gentiles to be hostile toward each other. Neither are now required to live according to the law of Moses. AT: "stopping them from hating one another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Ephesians 02:17

#### Connecting Statement:

Paul tells the Ephesian believers that present Gentile believers are also now made one with the Jewish apostles and prophets; they are a temple for God in the Spirit.

#### proclaimed peace

"announced the gospel of peace" or "declared the gospel of peace"

#### you who were far away

This refers to the Gentiles or non-Jews.

#### those who were near

This refers to the Jews.

#### For through Jesus we both have access

Here "we both" refers to Paul, the believing Jews, and the believing non-Jews. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### in one Spirit

All believers, both Jewish and Gentile, are given the right to enter into the presence of God the Father by the same Holy Spirit.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Ephesians 02:19

#### you Gentiles ... God's household

Paul is again speaking of the spiritual condition of Gentiles after they become believers as he would speak about foreigners becoming citizens of a different nation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You have been built on the foundation

Paul speaks of God's people as if they were a building. Christ is the cornerstone, the apostles are the foundation, and the believers are the structure. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You have been built

This can be stated in the active tense. AT: "God has built you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the whole building fits together and grows as a temple

Paul continues to speak of Christ's family as if it were a building. In the same way a builder fits stones together while building, so Christ is fitting us together. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### In him ... in the Lord ... in him

"In Christ ... in the Lord Jesus ... in Christ" These metaphors express the strongest kind of relationship possible between Christ and those who believe in him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you also are being built together as a dwelling place for God in the Spirit

This describes how believers are being put together to become a place where God will permanently live through the power of the Holy Spirit. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you also are being built together

This can be stated as active. AT: "God is also building you together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cornerstone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cornerstone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]

### Ephesians 02:intro

#### Ephesians 02 General Notes ####

####### Structure and formatting #######

This chapter focuses on a Christian's life before coming to faith in Jesus. Paul then uses this information to explain how a person's former way of living is distinct from a Christian's new identity "in Christ." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Special concepts in this chapter #######

######## One body ########
Paul teaches about the church in this chapter. The church is made of two different groups of people (Jews and Gentiles) who are now one group or "body." It is also known as Jesus's body because Jesus unites them.

####### Important figures of speech in this chapter #######

######## "Dead in trespasses and sins" ########
Paul teaches that those who are not Christians are "dead" in their sin. This means that they are in bondage or enslaved to their sin, which leads to death unless they come to faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## Metaphors for worldly living ########
Paul uses many different metaphors to describe how the non-Christian world acts. They "walked according to the age of this world," "walked according to the ruler of the authorities of the air," "acting according to the evil desires of our flesh," and "doing the will of the flesh and the mind."

####### Other possible translation difficulties in this chapter #######

######## "It is a gift of God" ########
Most scholars believe "it" refers to salvation, while others believe that it is faith that is the gift of God. Because of agreement in the Greek wording, it is more probable that salvation is what Paul refers to as the gift of God here.

######## Flesh ########

This is a complex issue. It is possible that "flesh" is a metaphor for a person's sinful nature. The phrase "Gentiles in the flesh" indicates the Ephesians once lived without any concern for God. "Flesh" is also used in this verse to refer to the physical part of man. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]])

##### Links: #####

* __[Ephesians 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Ephesians 03

### Ephesians 03:01

#### Connecting Statement:

To make clear the hidden truth about the church to believers, Paul refers back to the oneness of Jews and Gentiles and the temple of which believers are now a part.

#### Because of this

"Because of God's grace to you"

#### the prisoner of Christ Jesus

"the one whom Christ Jesus has put in prison"

#### the stewardship of the grace of God that was given to me for you

"the responsibility that God gave me to bring his grace to you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ephesians 03:03

#### according to the revelation made known to me

This can be stated in active form. AT: "according to what God revealed to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### about which I briefly wrote to you

Paul refers to another letter he had written to these people.

#### In other generations this truth was not made known to the sons of men

This can be stated in active form. AT: "God did not make these things known to people in the past" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### But now it has been revealed by the Spirit

This can be stated in active form. AT: "But now the Spirit has revealed it" or "But now the Spirit has made it known" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his apostles and prophets who were set apart for this work

"the apostles and prophets whom God set apart to do this work"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### Ephesians 03:06

#### the Gentiles are fellow heirs ... through the gospel

This is the hidden truth Paul began to explain in the previous verse. The Gentiles who receive Christ also receive the same things as the Jewish believers.

#### fellow members of the body

The church is often referred to as the body of Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in Christ Jesus

"In Christ Jesus" and similar expressions are metaphors that frequently occur in the New Testament letters. They express the strongest kind of relationship possible between Christ and those who believe in him.

#### through the gospel

Possible meanings are 1) because of the gospel the Gentiles are fellow sharers in the promise or 2) because of the gospel the Gentiles are fellow heirs and members of the body and fellow sharers in the promise.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Ephesians 03:08

#### God's holy people

"those whom God has set apart for himself"

#### unsearchable

unable to be completely known (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### riches of Christ

Paul speaks of the truth about Christ and the blessings he brings as if they were material wealth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bring to light to everyone what God's plan is

Bringing light to people represents teaching them. AT: "shine a light on God's secret plan so all people will know what it is" or "teach all people what God's secret plan is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### This plan had been hidden for ages in the past by God, who created all things

This can be stated in active form. "God, who created all things, had kept this plan hidden for long ages in the past" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]

### Ephesians 03:10

#### the rulers and authorities in the heavenly places would come to know the many-sided nature of the wisdom of God

"God will make his great wisdom known to the rulers and authorities in the heavenly places through the Church"

#### rulers and authorities

These words share similar meanings. Paul uses them together to emphasize that every spiritual being will know God's wisdom. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### in the heavenly places

"in the supernatural world." The word "heavenly" refers to the place where God is. See how this is translated in [Ephesians 1:3](../01/03.md).

#### the many-sided nature of the wisdom of God

God's complex wisdom (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### according to the eternal plan

"in keeping with the eternal plan" or "consistent with the eternal plan"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Ephesians 03:12

#### Connecting Statement:

Paul praises God in his sufferings and prays for these Ephesian believers.

#### we have boldness

"we are without fear" or "we have courage"

#### access with confidence

It may be helpful to state explicitly that this access is into God's presence. AT: "access into God's presence with confidence" or "freedom to enter into God's presence with confidence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### confidence

"certainty" or "assurance"

#### for you, which is your glory

Here "your glory" is a metonym for the pride they should feel or will feel in the future kingdom. The Christians in Ephesus should be proud of what Paul is suffering in prison. This can be stated as a new sentence. AT: "for you. This is for your benefit" or "for you. You should be proud of this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Ephesians 03:14

#### For this reason

You may need to make explicit what the reason is. AT: "Because God has done all this for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I bend my knees to the Father

Bowed knees are a picture of the whole person in an attitude of prayer. AT: "I bow down in prayer to the Father" or "I humbly pray to the Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### from whom every family in heaven and on earth is named

The act of naming here probably also represents the act of creating. AT: "who created and named every family in heaven and on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he would grant you, according to the riches of his glory, to be strengthened with power

"God, because he is so great and powerful, would allow you to become strong with his power"

#### would grant

"would give"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Ephesians 03:17

#### Connecting Statement:

Paul continues the prayer he began in [Ephesians 3:14](./14.md).

#### that Christ may live in your hearts through faith, that you will be rooted and grounded in his love

This is the second item for which Paul prays that God will "grant" the Ephesians "according to the riches of his glory." The first is that they would "be strengthened" ([Ephesians 3:16](./14.md)).

#### hearts through faith

Here "heart" represents a person's inner being, and "through" expresses the means by which Christ lives within the believer. Christ lives in the hearts of believers because God graciously allows them to have faith. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### faith, that you will be rooted and grounded in his love. May you have strength so you can understand

Possible meanings are 1) "faith. I pray that you will be rooted and grounded in his love so that you can understand" or 2) "faith so you will be rooted and grounded in his love. I also pray that you can understand"

#### that you will be rooted and grounded in his love

Paul speaks of their faith as if it were a tree that has deep roots or a house built on a solid foundation. AT: "that you will be like a firmly rooted tree and a building built on stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so you can understand

This is the second item for which Paul bends his knees and prays; the first is that God will grant that they be strengthened ([Ephesians 3:16](./14.md)) and that Christ may live in their hearts through faith ([Ephesians 3:17](./14.md)). And "understand" is the first thing that Paul prays that the Ephesians themselves will be able to do.

#### all the believers

"all believers in Christ" or "all the saints"

#### the width, the length, the height, and the depth

Possible meanings are 1) these words describe the greatness of God's wisdom, AT: "how very wise God is" or 2) these word describe the intensity of Christ's love for us. AT: "how much Christ loves us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that you may know the love of Christ

This is the second thing that Paul prays that the Ephesians will be able to do; the first is that they "understand." AT: "that you can know how great Christ's love for us is"

#### that you may be filled with all the fullness of God

This is the third item for which Paul bends his knees and prays ([Ephesians 3:14-16](./14.md)). The first is that they would "be strengthened" ([Ephesians 3:16](./14.md)), and the second is that they "can understand" (3:18).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ephesians 03:20

#### Connecting Statement:

Paul concludes his prayer with a blessing.

#### General Information:

The words "we" and "us" in this book continue to include Paul and all believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Now to him who

"Now to God, who"

#### to do far beyond all that we ask or think

"to do much more than all that we ask or think" or "to do things that are much greater than all that we ask him for or think about"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Ephesians 03:intro

#### Ephesians 03 General Notes ####

####### Structure and formatting #######

######## "I pray" ########

This chapter is structured loosely as a prayer, but it is not a typical prayer. This is a unique "prayer" where Paul is not just talking to God directly. He is also is giving written instructions to the church in Ephesus.

####### Special concepts in this chapter #######

######## Mystery ########
Paul refers to the church as a "mystery." The role of the church in the plans of God was once not known, but it has now been revealed by God. Part of this mystery involves the Gentiles' equal standing with the Jews in the current plans of God.

##### Links: #####

* __[Ephesians 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Ephesians 04

### Ephesians 04:01

#### Connecting Statement:

Because of what Paul has been writing to the Ephesians, he tells them how they should live their lives as believers and again emphasizes that believers are to agree with each other.

#### as the prisoner for the Lord

"as someone who is in prison because of his choice to serve the Lord"

#### walk worthily of the calling

Walking is a common way to express the idea of living one's life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to live with great humility and gentleness and patience

"to learn to be humble, gentle, and patient"

#### to keep the unity of the Spirit in the bond of peace

Here Paul speaks of "peace" as if it were a bond that ties people together. This is a metaphor for being united with other people by living peacefully with them. AT: "to live peacefully with one another and remain united as the Spirit made possible" (See: [https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Ephesians 04:04

#### one body

The church is often referred to as the body of Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### one Spirit

"only one Holy Spirit"

#### you were called in one certain hope of your calling

This can be stated in active form. AT: "God called you to have one confident hope in your calling" or "there is one thing that God also chose you to be confident in and expect him to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Father of all ... over all ... through all ... and in all

The word "all" here means "everything."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Ephesians 04:07

#### Connecting Statement:

Paul reminds believers of the gifts that Christ gives believers to use in the church, which is the whole body of believers.

#### General Information:

The quote here is from a song that King David wrote.

#### To each one of us grace has been given

This can be stated using an active form. AT: "God has given grace to each one of us" or "God gave a gift to each believer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### When he ascended to the heights

"When Christ went up into heaven"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]

### Ephesians 04:09

#### He ascended

"Christ went up"

#### he also descended

"Christ also came down"

#### into the lower regions of the earth

Possible meanings are 1) the lower regions are a part of the earth or 2) "the lower regions" is another way of referring to the earth. AT: "into the lower regions, the earth"

#### that he might fill all things

"so that he might be present everywhere in his power"

#### fill

"complete" or "satisfy"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Ephesians 04:11

#### He gave these offices

The one to whom Christ gave the gifts can be stated clearly. AT: "Christ gave these offices to the church" or "He gave people with these responsibilities to the church (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to equip his holy people

"to prepare the people he has set apart" or "to provide the believers"

#### for the work of service

"so they can serve others"

#### for the building up of the body of Christ

Paul is speaking of people who grow spiritually as if they were doing exercises to increase the strength of their physical bodies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### building up

"improvement"

#### body of Christ

The "body of Christ" refers to all of the individual members of Christ's Church.

#### reach the unity of faith and knowledge of the Son of God

The believers need to know Jesus as the Son of God if they are to be united in faith and mature as believers.

#### reach the unity of faith

"become equally strong in faith" or "become united together in faith"

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### become mature

"become mature believers"

#### mature

"fully developed" or "grown up" or "complete"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evangelism.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evangelism.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pastor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pastor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### Ephesians 04:14

#### be children

Paul refers to believers who have not grown spiritually as if they were children who have had very little experience in life. AT: "be like children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### tossed back and forth ... carried away by every wind of teaching

This speaks of a believer who has not become mature and follows wrong teaching as if that believer were a boat that the wind is blowing in different directions on the water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by the trickery of people in their deceitful schemes

"by crafty people who trick believers with clever lies"

#### into him who is the head ... makes the body grow so that it builds itself up in love

Paul uses the human body to describe how Christ causes believers to work together in harmony as the head of a body causes the body parts to work together to grow healthy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by every supporting ligament

A "ligament" is a strong band that connects bones or organs in place in the body.

#### in love

"as the members love one another"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Ephesians 04:17

#### Connecting Statement:

Paul tells them what they should no longer do now that they as believers are sealed by the Holy Spirit of God.

#### Therefore, I say and insist on this in the Lord

"Because what I have just said, I will say something more to strongly encourage you because we all belong to the Lord"

#### that you must no longer live as the Gentiles live, in the futility of their minds

"stop living like the Gentiles with their worthless thoughts"

#### They are darkened in their understanding

They no longer think or reason clearly. AT: "They have darkened their thoughts" or "They are not able to understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### alienated from the life of God because of the ignorance that is in them

This can be stated in active form. AT: "Because they do not know God, they cannot live the way God wants his people to live" or "They have cut themselves off from the life of God by their ignorance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### alienated

"cut off" or "separated"

#### ignorance

"lack of knowledge" or "lack of information"

#### because of the hardness of their hearts

"Hearts" here is a metonym for their attitudes and intentions. AT: because of their bad attitudes and intentions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### have handed themselves over to sensuality

Paul speaks of these people as if they were objects that they themselves were giving to other people, and he speaks of the way they want to satisfy their physical desires as if it were the person to whom they give themselves. AT: "only want to satisfy their physical desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exhort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exhort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ephesians 04:20

#### But that is not how you learned about Christ

The word "that" refers to the way the Gentiles live, as described in [Ephesians 4:17-19](./17.md). This emphasizes that what the believers learned about Christ was the opposite of that. AT: "But what you learned about Christ was not like that"

#### I assume that you have heard ... and that you were taught

Paul knows that the Ephesians have heard and been taught. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### you were taught in him

Possible meanings are 1) "Jesus' people have taught you" or 2) "someone has taught you because you are Jesus' people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as the truth is in Jesus

"as everything about Jesus is true"

#### to put off what belongs to your former manner of life

Paul is speaking of moral qualities as if they were pieces of clothing. AT: "to stop living according to your former manner of life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to put off the old man

Paul is speaking of moral qualities as if they were pieces of clothing. AT: "to stop living as your former self did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### old man

The "old man" refers to the "old nature" or "former self."

#### that is corrupt because of its deceitful desires

Paul speaks of the sinful human nature as if it were a dead body falling apart in its grave. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Ephesians 04:23

#### to be renewed in the spirit of your minds

This may be translated with an active form. AT: "to allow God to change your attitudes and thoughts" or "to allow God to give you new attitudes and thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to put on the new man that is created in the image of God

Paul is speaking of moral qualities as if they were pieces of clothing. AT: "to live your new life, which is created in the image of God" or "to start living in the new way because you were created in the image of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in true righteousness and holiness

"truly righteous and holy"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Ephesians 04:25

#### get rid of lies

"stop telling lies"

#### we are members of one another

"we belong to one another" or "we are members of God's family"

#### Be angry and do not sin

"You may get angry, but do not sin" or "If you become angry, do not sin"

#### Do not let the sun go down on your anger

The sun going down represents nightfall, or the end of the day. AT: "You must stop being angry before night comes" or "Let go of your anger before the day ends" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Do not give an opportunity to the devil

"Do not give the devil an opportunity to lead you into sin"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### Ephesians 04:28

#### filthy talk

This refers to speech that is cruel or rude.

#### for building others up

"for encouraging others" or "for strengthening others"

#### their needs, that your words would be helpful to those who hear you

"their needs. In this way you will help those who hear you"

#### do not grieve

"do not distress" or "do not upset"

#### for it is by him that you were sealed for the day of redemption

The Holy Spirit assures believers that God will redeem them. Paul speaks of the Holy Spirit as if he were a mark that God puts on believers to show that he owns them. AT: "for he is the seal that assures you that God will redeem you on the day of redemption" or "for he is the one who assures you that God will redeem you on the day of redemption" or (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]

### Ephesians 04:31

#### Connecting Statement:

Paul finishes his instructions on what believers should not do and ends with what they must do.

#### Put away all bitterness, rage, anger

"Put away" here is a metaphor for not continuing to have certain attitudes or behaviors. AT: "You must not allow these things to be part of your life: bitterness, rage, anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### rage

intense anger

#### Be kind

"Instead, be kind"

#### tenderhearted

able to understand what other people are thinking and whether they are happy or sad

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]

### Ephesians 04:intro

#### Ephesians 04 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry that is quoted from the Old Testament in 4:8.

####### Special concepts in this chapter #######

######## Spiritual gifts ########
Spiritual gifts are specific supernatural abilities given to Christians after coming to faith in Jesus. This is not an exhaustive list of the spiritual gifts. Some scholars believe there are some gifts given only in the early church because they were foundational to the development of the church. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## Unity ########
Paul places a great importance on unity in the church. This is a major theme of this chapter. 

####### Other possible translation difficulties in this chapter #######

######## Old man and new man ########
The term "old man" probably refers to the sinful nature that a person is born with, while the "new man" is the new nature or new life that is given to a person after coming to faith in Christ. Paul also uses the terms old/new self and old/new creation in the same way. 

##### Links: #####

* __[Ephesians 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Ephesians 05

### Ephesians 05:01

#### Connecting Statement:

Paul continues to tell the believers how they should and should not live as God's children.

#### Therefore be imitators of God

"Therefore you should do what God does." Therefore refers back to [Ephesians 4:32](../04/31.md) which tells why believers should imitate God, because Christ forgave believers.

#### as dearly loved children

God desires us to imitate or follow him since we are his children. AT: "as dearly loved children imitate their fathers" or "because you are his children and he loves you dearly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### walk in love

Walking is a common way to express the idea of living one's life. AT: "live a life of love" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a fragrant offering and sacrifice to God

"like a sweet-smelling offering and sacrifice to God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Ephesians 05:03

#### But there must not be even a suggestion among you of sexual immorality or any kind of impurity or of greed

"Do not do anything that would let anyone think that you are are guilty of sexual immorality or any kind of impurity or greed"

#### any kind of impurity

"any moral uncleanness"

#### Instead there should be thanksgiving

"Instead you should thank God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Ephesians 05:05

#### inheritance

Receiving what God has promised believers is spoken of as if it were inheriting property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### empty words

words that have no truth to them

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]

### Ephesians 05:08

#### For you were once darkness

Just as one cannot see in the dark, so people who love to sin lack spiritual understanding. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but now you are light in the Lord

Just as one can see in the light, so people whom God has saved understand how to please God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Walk as children of light

Walking on a path is a metaphor for how a person lives his life. AT: "Live as people who understand what the Lord wants them to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the fruit of the light consists in all goodness, righteousness, and truth

"Fruit" here is a metaphor for "result" or "outcome." AT: "the result of living in the light is good work, right living, and truthful behavior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do not associate with the unfruitful works of darkness

Paul speaks of the useless, sinful things that unbelievers do as if they are evil deeds people do in the dark so no one will see them. AT: "Do not do useless, sinful things with unbelievers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### unfruitful works

actions that do nothing good, useful, or profitable. Paul is comparing evil actions to an unhealthy tree that produces nothing good. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### expose them

Speaking against the works of darkness is spoken of as bringing them out into the light so that people can see them. AT: "bring them out into the light" or "uncover them" or "show and tell people how wrong these actions are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Ephesians 05:13

#### General Information:

It is unknown if this quotation is a combination of quotations from the prophet Isaiah or a quotation from a hymn sung by the believers.

#### anything that becomes visible is light

"people can clearly see everything that comes into the light." Paul makes this general statement in order to imply that God's Word shows people's actions to be good or bad. The Bible often speaks of God's truth as if it were light that could reveal the character of something. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Awake, you sleeper, and arise from the dead

Possible meanings are 1) Paul is addressing unbelievers who need to wake up from being dead spiritually just as a person who has died must come alive again in order to respond, or 2) Paul is addressing the Ephesian believers and using death as a metaphor for their spiritual weakness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To arise from among them speaks of becoming alive again.

#### you sleeper ... shine on you

These instances of "you" refer to the "sleeper" and are singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Christ will shine on you

Christ will enable an unbeliever to understand how evil his deeds are and how Christ will forgive him and give him new life, just as light shows what actually is there that darkness hid. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Ephesians 05:15

#### Look carefully how you live—not as unwise but as wise

Unwise people do not guard themselves against sin. Wise people, however, can identify sin and flee from it. AT: "Therefore you must be careful to live as a wise person rather than a foolish person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Redeem the time

Using time wisely is spoken of as if it were redeeming the time. AT: "Do the best things you can with your time" or "Use time wisely" or "Put time to its best use" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### because the days are evil

The word "days" is a metonym for what people do during those days. AT: "because the people around you are doing all kinds of evil things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Ephesians 05:18

#### Connecting Statement:

Paul ends his instructions on how all believers should live.

#### And do not get drunk with wine

"You should not get drunk from drinking wine"

#### Instead, be filled with the Holy Spirit

"Instead, you should be controlled with the Holy Spirit"

#### psalms and hymns and spiritual songs

Possible meanings are that 1) Paul is using these words as a merism for "all sorts of songs to praise God" or 2) Paul is listing specific forms of music. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### psalms

These are probably songs from the Old Testament book of Psalms that Christians sang.

#### hymns

These are songs of praise and worship that may have been written specifically for Christians to sing.

#### spiritual songs

Possible meanings are 1) these are songs that Holy Spirit inspires a person to sing right at that moment or 2) "spiritual songs" and "hymns" are doublets and mean basically the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### with all your heart

This is a synedoche for strong human emotion. AT: "with strong emotions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### in the name of our Lord Jesus Christ

"Name" here is a metonym for the person of Jesus Christ. AT: "by means of our Lord Jesus Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/psalm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/psalm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Ephesians 05:22

#### Connecting Statement:

Paul begins to explain how Christians are to submit themselves to one another ([Ephesians 5:21](./18.md)). He starts with instructions to wives and husbands on how they should act toward each other.

#### the head of the wife ... the head of the church

The word "head" represents the leader. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]

### Ephesians 05:25

#### General Information:

Here the words "himself" and "he" refer to Christ. The word "her" refers to the church.

#### love your wives

Here "love" refers to unselfish serving or giving love to wives.

#### gave himself up

"allowed people to kill him"

#### having cleansed her by the washing of water with the word

Possible meanings are 1) Paul is referring to God's making Christ's people clean by God's word and through water baptism in Christ or 2) Paul is saying God made us spiritually clean from our sins by the instructions from God as we make our bodies clean by washing with water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for her ... make her holy ... cleansed her

Paul speaks of the assembly of believers as though it were a woman whom Jesus will marry. AT: "for us ... make us holy ... cleansed us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### without stain or wrinkle

Paul speaks of the church as though it were a garment that is clean and in good condition. He uses the same idea in two ways to emphasize the church's purity. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### holy and without fault

The phrase "without fault" means basically the same thing as "holy." Paul uses the two together to emphasize the church's purity. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Ephesians 05:28

#### as their own bodies

That people love their own bodies may be stated explicitly. AT: "as husbands love their own bodies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but nourishes

"but feeds"

#### we are members of his body

Here Paul speaks of the close union of believers with Christ as if they were part of his own body, for which he would naturally care. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Ephesians 05:31

#### General Information:

The quotation is from the writings of Moses in the Old Testament.

#### General Information:

The words "his" and "himself" refer to a male believer who marries.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Ephesians 05:intro

#### Ephesians 05 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 5:14.

####### Special concepts in this chapter #######

######## Inheritance of the kingdom of Christ ########
This is a difficult concept to understand. Because all of these sins can be forgiven, it should be obvious the inheritance talked about here is not eternal life. Some scholars, though, believe those who continue to practice these things will not inherit eternal life. It seems to be more natural to see "inheriting the kingdom" as referencing a future kingdom. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]])

####### Other possible translation difficulties in this chapter #######

######## Wives, submit to your husbands ########
Scholars are divided over how to understand this passage in light of its historical and cultural context. Some scholars believe men and women are perfectly equal in all things (known as "egalitarianism"). Other scholars believe men and women were created to serve in distinctly different roles in marriage and the church (known as "complementarianism"). One's understanding of this issue will likely affect how this passage is translated. 

##### Links: #####

* __[Ephesians 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Ephesians 06

### Ephesians 06:01

#### Connecting Statement:

Paul continues to explain how Christians are to submit themselves to each other. He gives instructions to children, fathers, workers, and masters.

#### General Information:

The first word "your" is plural. Then Paul quotes Moses. Moses was talking to the people of Israel as though they were one person, so "your" and "you" are singular. You may need to translate them as plurals. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Children, obey your parents in the Lord

Paul reminds children to obey their physical parents.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Ephesians 06:04

#### do not provoke your children to anger

"do not make your children angry" or "do not cause your children to be angry"

#### raise them in the discipline and instruction of the Lord

"Raise" here is an idiom for "establish." AT: "establish them in the discipline and instruction of the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Ephesians 06:05

#### be obedient to

"obey." This is a command.

#### deep respect and trembling

The phrase "deep respect and trembling" uses two similar ideas to emphasize the importance of honoring their masters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### and trembling

Here "trembling" is an exaggeration used to emphasize how important it is that slaves obey their masters. AT: "and fear" or "as though you were shaking with fear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### in the honesty of your heart

"Heart" here is a synecdoche for truely honorable intentions. AT: "with your truely honorable intentions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### as slaves of Christ

Serve your earthly master as though your earthly master were Christ himself.

#### who do the will of God from your heart

"Heart" here is a metonym for "personal convictions." AT: "who do the will of God from your personal convictions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Serve with all your heart, as though you were serving the Lord and not people

"Heart" here is a metonym for one's "intentions" or "convictions." AT: "Serve with full conviction, realizing that you serve the Lord and not just people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]

### Ephesians 06:09

#### treat your slaves in the same way

"you also must treat your slaves well" or "just as slaves must do good to their masters, you also must do good to your slaves (See: [Ephesians 6:5](./05.md))

#### You know that he who is both their Master and yours is in heaven

"You know that Christ is the Master of both slaves and their masters, and that he is in heaven"

#### there is no favoritism with him

"he judges everyone the same way"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Ephesians 06:10

#### Connecting Statement:

Paul gives instructions to make believers strong in this battle we live for God.

#### the strength of his might

"his great power." See how "the strength of his power" is translated near the end of [Ephesians 1:21](../01/19.md).

#### Put on the whole armor of God, so that you may be able to stand against the scheming plans of the devil

Christians should use all the resources God gives to stand firmly against the devil just as a soldier puts on armor to protect himself from enemy attacks. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the scheming plans

"the tricky plans"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### Ephesians 06:12

#### flesh and blood

This expression refers to people, not spirits who do not have human bodies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the realm of evil darkness

"Darkness" here is a metonym for Satan's rule or kingdom. AT: "the areas of the universe where Satan is in control"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### Therefore put on the whole armor of God

Christians should use the protective resources God gives them in fighting the devil in the same way a soldier puts on armor to protect himself against his enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so that you may be able to stand in this time of evil

The words "stand firm" represent successfully resisting or fighting something. AT: "so that you may be able to resist evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ephesians 06:14

#### Stand, therefore

The words "stand" represents successfully resisting or fighting something. See how you translated "stand firm" in [Ephesians 6:13](./12.md). "So resist evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the belt of truth

Truth holds everything together for a believer just as a belt holds the clothing of a soldier together. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### truth ... righteousness

We are to know the truth and act in ways that please God.

#### the breastplate of righteousness

Possible meanings are 1) the gift of righteousness covers a believer's heart just as a breastplate protects the chest of a soldier or 2) our living as God wants us, gives us a clear conscience that protects our hearts the way a breastplate protects a soldier's chest. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Then as shoes for your feet, put on the readiness to proclaim the gospel of peace

Just as a soldier wears shoes to give him solid footing, the believer must have solid knowledge of the gospel of peace in order to be ready to proclaim it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### In all circumstances take up the shield of faith

The believer must use the faith that God gives for protection when the devil attacks, just as a soldier uses a shield to protect him from enemy attacks. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the flaming arrows of the evil one

The attacks of the devil against a believer are like flaming arrows shot at a soldier by an enemy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### Ephesians 06:17

#### take the helmet of salvation

Salvation given by God protects the believer's mind just as a helmet protects the head of a soldier. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the sword of the Spirit, which is the word of God

God's instructions to us, inspired by the Holy Spirit, are to be used to fight against and defend the believer from the devil just as a soldier uses his sword to fight and defend against enemy attacks. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### With every prayer and request, pray at all times in the Spirit

"Pray at all times in the Spirit as you pray and make specific requests"

#### To this end

"For this reason" or "Keeping this in mind." This refers to the attitude of taking God's armor.

#### be watching with all perseverance, as you offer prayers for all God's holy people

"persevere in being alert, and pray for all God's holy people" or "pray with constant alertness for all the believers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perseverance.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perseverance.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Ephesians 06:19

#### Connecting Statement:

In his closing, Paul asks them to pray for his boldness in telling the gospel while he is in prison and says he is sending Tychicus to comfort them.

#### that a message might be given to me

This can be stated in active form. AT: "that God might give me the word" or "God might give me the message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### when I open my mouth. Pray that I might make known with boldness

"when I speak. Pray that I boldly explain"

#### open my mouth

This is a metonym for speaking. AT: "speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### It is for the gospel that I am an ambassador who is kept in chains

The words "in chains" are a metonym for being in prison. AT: "I am now in prison because I am a representative of the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that I may declare it boldly, as I ought to speak

The word "pray" is understood from verse 19. AT: "so pray that whenever I teach the gospel, I will speak it as boldly as I should" or "pray that I may speak the gospel as boldly as I should" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ambassador.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ambassador.md)]]

### Ephesians 06:21

#### Tychicus

Tychicus was one of several men who served with Paul. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### so that he may encourage your hearts.

"Encourage your hearts" here is a synecdoche for strengthening the determination of the believers. AT: "so that he may strengthen your decision to follow God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Ephesians 06:23

#### Connecting Statement:

Paul closes his letter to the Ephesian believers with a blessing of peace and grace on all believers who love Christ.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Ephesians 06:intro

#### Ephesians 06 General Notes ####

####### Special concepts in this chapter #######

######## Slavery ########
This passage does not condone slavery as an acceptable practice. Paul's teaching on slavery would have been rather radical during his time because masters were not expected to treat their slaves in such a pleasant way. Overall, Paul's focus is on living in a way that pleases God despite the circumstances of one's life. Remember, Paul is in prison when he writes these words.

####### Important figures of speech in this chapter #######

######## Armor of God ########
This is an extended metaphor describing how Christians can protect themselves from spiritual "attacks" in their daily lives. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Ephesians 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | __


## Ephesians front

### Ephesians front:intro

#### Introduction to Ephesians ####

##### Part 1: General Introduction #####

####### Outline of Ephesians #######

1. Greeting and prayer for the spiritual blessings in Christ (1:1-23)
1. Sin and salvation (2:1-10)
1. Unity and peace (2:11-22)
1. Mystery of Christ in you, made known (3:1-13)
1. Prayer for riches of his glory to make them strong (3:14-21)
1. Unity of the Spirit, building up the Body of Christ (4:1-16)
1. New life (4:17-32)
1. Imitators of God (5:1-21)
1. Wives and husbands; children and parents; slaves and masters (5:22-6:9)
1. Armor of God (6:10-20)
1. Final greeting (6:21-24)

####### Who wrote the Book of Ephesians? #######

Paul wrote Ephesians. Paul was from the city of Tarsus. He had been known as Saul in his early life. Before becoming a Christian, Paul was a Pharisee. He persecuted Christians. After he became a Christian, he traveled several times throughout the Roman Empire telling people about Jesus.

The Apostle Paul helped start the church in Ephesus on one of his trips. He also lived in Ephesus for a year and a half and helped the believers there. Paul probably wrote this letter while he was in prison in Rome.

####### What is the Book of Ephesians about? #######

Paul wrote this letter to the Christians in Ephesus to explain God's love for them in Christ Jesus. He described the blessings that God was giving them because they were now united with Christ. He explained that all believers are united together, whether Jew or Gentile. Paul also wanted to encourage them to live in a way that pleases God.
 
####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Ephesians." Or they may choose a clearer title, such as "Paul's Letter to the Church in Ephesus" or "A Letter to the Christians in Ephesus." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### What was the "hidden truth" in the Book of Ephesians? #######

The expression translated in the ULB as "hidden truth" or "hidden" occurs six times. By it Paul always meant something that God had to reveal to human beings because they could not know it on their own. It always referred to something about how God planned to save mankind. Sometimes it was about his plan to cause peace between himself and mankind. Sometimes it was about his plan to unite Jews and Gentiles through Christ. Gentiles are now able to benefit from the promises of Christ as equals with the Jews. 

####### What did Paul say about salvation and righteous living? #######

Paul said much about salvation and righteous living in this letter and in many of his letters. He said that God has been very kind and saved Christians because they believe in Jesus. Therefore, after they become Christians, they should live in a righteous way to show that they have faith in Christ. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]) 

##### Part 3: Important Translation Issues #####

####### Singular and plural "you" #######

In this book, the word "I" refers to Paul. The word "you" is almost always plural and refers to the believers who may read this letter. The three exceptions to this are: 5:14, 6:2, and 6:3. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

####### What did Paul mean by the "new self" or the "new man"? #######

When Paul spoke of the "new self" or the "new man," he meant the new nature that a believer receives from the Holy Spirit. This new nature was created in God's image (See: 4:24). The phrase "new man" is also used for God causing peace between Jews and Gentiles. God brought them together as one people that belong to him (See: 2:15).

####### How are the ideas of "holy" and "sanctify" represented in Ephesians in the ULB? #######

The scriptures use such words to indicate any one of various ideas. For this reason, it is often difficult for translators to represent them well in their versions. In translating into English, the ULB uses the following principles:

* Sometimes the meaning in a passage implies moral holiness. Especially important for understanding the gospel is the use of "holy" to express the fact that God views Christians as sinless because they are united to Jesus Christ. Another use of "holy" is to express the idea that God is perfect and faultless. A third use is to express the idea that Christians are to conduct themselves in a blameless, faultless manner in life. In these cases, the ULB uses "holy," "holy God," "holy ones," or "holy people." (See: 1:1, 4)
* Sometimes the meaning in a passage indicates a simple reference to Christians without implying any particular role filled by them. In these cases, the ULB uses "believer" or "believers."
* Sometimes the meaning in a passage implies the idea of someone or something set apart for God alone. In these cases, the ULB uses "set apart," "dedicated to," or "reserved for." (See: 3:5)

The UDB will often be helpful as translators think about how to represent these ideas in their own versions.

####### What did Paul mean by the expression "in Christ," "in the Lord," etc.? #######

This kind of expression occurs in 1:1, 3, 4, 6, 7, 9, 10, 11, 12, 13, 15, 20; 2:6, 7, 10, 13, 15, 16, 18, 21, 22; 3:5, 6, 9, 11, 12, 21; 4:1, 17, 21, 32; 5:8, 18, 19; 6:1, 10, 18, 21. Paul meant to express the idea of a very close union with Christ and the believers. Please see the introduction to the Book of Romans for more details about this kind of expression.

####### What are the major issues in the text of the Book of Ephesians? #######

The following are the most significant textual issues in Ephesians:

* Some early manuscripts do not include "in Ephesus" (1:1) but this expression is probably in the original letter. The ULB, UDB, and many modern versions include it. 
* "because we are members of his body" (5:30). Most modern versions, including the ULB and UDB, read in this way. Some older versions read, "because we are members of his body and of his bones." Translators might decide to choose the second reading if other versions in their area have it that way. If translators do choose the second reading, they should put the additional words inside square brackets ([]) to indicate that they are probably not original to the Book of Ephesians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

