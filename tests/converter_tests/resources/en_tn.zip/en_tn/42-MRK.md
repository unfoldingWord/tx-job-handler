# <a id="mrk"/>Mark

## Mark 01

### Mark 01:01

#### General Information:

The book of Mark begins with the prophet Isaiah's foretelling the coming of John the Baptist, who baptizes Jesus.

#### General Information:

The author is Mark, also called John Mark, who is the son of one of the several women named Mary mentioned in the four Gospels. He is also the nephew of Barnabas.

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### before your face

This is an idiom that means "ahead of you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### your face ... your way

Here the word "your" refers to Jesus and is singular. When you translate this, use the pronoun "your" because this is a quote from a prophet, and he did not use Jesus' name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the one

This refers to the messenger.

#### will prepare your way

Doing this represents preparing the people for the Lord's arrival. AT: "will prepare the people for your arrival" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The voice of one calling out in the wilderness

This can be expressed as a sentence. AT: "The voice of one calling out in the wilderness is heard" or "They hear the sound of someone calling out in the wilderness"

#### Make ready the way of the Lord ... make his paths straight

These two phrases mean the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Make ready the way of the Lord

"Get the road ready for the Lord." Doing this represents being prepared to hear the Lord's message when he comes. People do this by repenting of their sins. AT: "Prepare to hear the Lord's message when he comes" or "Repent and be ready for the Lord to come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]

### Mark 01:04

#### General Information:

In these verses the words "he," "him," and "his" refer to John.

#### John came

Be sure your reader understands that John was the messenger spoken of by the prophet Isaiah in the previous verse.

#### The whole country of Judea and all the people of Jerusalem

The words "whole country" are a metaphor for the people who live in the country and a generalization that refers to a great number of people, not to every single person. AT: "Many people from Judea and Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### They were baptized by him in the Jordan River, confessing their sins

They did these things at the same time. The people were baptized because they repented of their sins. AT: "When they repented of their sins, John baptized them in the Jordan River"

#### he was eating locusts and wild honey
Locusts and wild honey are two kinds of foods that John customarily ate while he lived in the wilderness. This does not mean that John was actually eating these foods while he was baptizing people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]

### Mark 01:07

#### He proclaimed

"John proclaimed"

#### the strap of his sandals I am not worthy to stoop down and untie

John is comparing himself to a servant to show how great Jesus is. AT: "I am not even worthy to do the lowly task of removing his shoes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the strap of his sandals

At the time Jesus was on earth, people often wore sandals that were made of leather and tied to their feet with leather straps.

#### stoop down

"bend down"

#### but he will baptize you with the Holy Spirit

This metaphor compares John's baptism with water to the future baptism with the Holy Spirit. This means John's baptism only symbolically cleanses people of their sins. The baptism by the Holy Spirit will truly cleanse people of their sins. If possible, use the same word for "baptize" here as you used for John's baptism to keep the comparison between the two. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Mark 01:09

#### It happened in those days

This marks the beginning of a new event in the story line. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### he was baptized by John

This can be stated in active form. AT: "John baptized him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Spirit coming down on him like a dove

Possible meanings are 1) this is a simile, and the Spirit descended upon Jesus like a bird descends from the sky toward the ground or 2) the Spirit literally looked like a dove as he descended upon Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### A voice came out of the heavens

This represents God speaking. Sometimes people avoid referring directly to God because they respect him. AT: "God spoke from the heavens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### beloved Son

This is an important title for Jesus. The Father calls Jesus his "beloved Son" because of his eternal love for him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### Mark 01:12

#### Connecting Statement:

After Jesus' baptism, he is in the wilderness for 40 days and then goes to Galilee to teach and call his disciples.

#### compelled him to go out

"forced Jesus to go out"

#### He was in the wilderness

"He stayed in the wilderness"

#### forty days

"40 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### He was with

"He was among"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Mark 01:14

#### after John was arrested

"after John was placed in prison." This can be stated in active form. AT: "after they arrested John" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### proclaiming

"preaching"

#### The time is fulfilled

"It is now time"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Mark 01:16

#### he saw Simon and Andrew

"Jesus saw Simon and Andrew"

#### casting a net in the sea

The full meaning of this statement can be made explicit. AT: "throwing a net into the water to catch fish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Come, follow me

"Follow me" or "Come with me"

#### I will make you fishers of men

This metaphor means Simon and Andrew will teach people God's true message, so others will also follow Jesus. AT: "I will teach you to gather men to me like you gather fish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md)]]

### Mark 01:19

#### in the boat

It can be assumed that this boat belongs to James and John. AT: "in their boat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### mending the nets

"repairing the nets"

#### called them

It may be helpful to state clearly why Jesus called to James and John. AT: "called them to come with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### hired servants

"servants who worked for them"

#### they followed him

James and John went with Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]

### Mark 01:21

#### Connecting Statement:

Jesus teaches in the synagogue of the town of Capernaum on the Sabbath. By sending a demon out of a man he amazes the people in all the nearby area around Galilee.

#### came into Capernaum

"arrived at Capernaum"

#### for he was teaching them as someone who has authority and not as the scribes

The idea of "teach" can be stated clearly when talking about "someone who has authority" and "the scribes." AT: "for he was teaching them as someone who has authority teaches and not as the scribes teach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]

### Mark 01:23

#### What do we have to do with you, Jesus of Nazareth?

The demons ask this rhetorical question meaning there is no reason for Jesus to interfere with them and that they desire him to leave them. AT: "Jesus of Nazareth, leave us alone! There is no reason for you to interfere with us." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Have you come to destroy us?

The demons ask this rhetorical question to urge Jesus not to harm them. AT: "Do not destroy us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### threw him down

Here the word "him" refers to the demon-possessed man.

#### while crying out with a loud voice

The demon is the one who is crying out, not the man.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]

### Mark 01:27

#### they asked each other, "What is this? A new teaching with authority? ... and they obey him!"

The people used the two questions to show how amazed they were. The questions can be expressed as exclamations. AT: "they said to each other, 'This is amazing! He gives a new teaching, and he speaks with authority! ... and they obey him!'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### He even commands

The word "He" refers to Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]

### Mark 01:29

#### Connecting Statement:

After healing the demon-possessed man, Jesus healed Simon's mother-in-law and many other people.

#### Now Simon's mother-in-law was lying sick with a fever

The word "Now" introduces Simon's mother-in-law to the story and gives background information about her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### raised her up;

"Raised her up" here is an idiom "established her." AT: "caused her to stand;" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the fever left her

It can be shown clearly who healed her. AT: "Jesus healed her of the fever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### she started serving them

It is implied that food was served. AT: "she provided them with food and drinks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 01:32

#### General Information:

Here the words "him" and "he" refer to Jesus.

#### all who were sick or possessed by demons

The word "all" is an exaggeration to emphasize the great number of people who came. AT: "many who were sick or possessed by demons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### The whole city gathered together at the door

The word "city" is a metonym for the people who lived in the city. Here the word "whole" is probably a generalization to emphasize that most people from the city gathered. AT: "Many people from that city gathered outside the door" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### Mark 01:35

#### Connecting Statement:

Jesus takes time to pray in the midst of his time of healing people. He then goes to towns throughout Galilee to preach, heal, and cast out demons.

#### General Information:

Here the words "he" and "him" refer to Jesus.

#### a solitary place

"a place where he could be alone"

#### Simon and those who were with him

Here "him" refers to Simon. Also, those with him include Andrew, James, John, and possibly other people.

#### Everyone is looking for you

The word "Everyone" is an exaggeration to emphasize the very many people who were looking for Jesus. AT: "Many people are looking for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]

### Mark 01:38

#### General Information:

Here the words "he" and "I" refer to Jesus.

#### Let us go elsewhere

"We need to go to some other place." Here Jesus uses the word "us" to refer to himself, along with Simon, Andrew, James, and John.

#### He went throughout all of Galilee

The words "throughout all" are an exaggeration used to emphasize that Jesus went to many locations during his ministry. AT: "He went to many places in Galilee" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### Mark 01:40

#### A leper came to him. He was begging him; he knelt down and said to him

"A leper came to Jesus. He knelt down and was begging Jesus and said"

#### If you are willing, you can make me clean

In the first phrase, the words "to make me clean" are understood because of the second phrase. AT: "If you are willing to make me clean, then you can make me clean" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### are willing

"want" or "desire"

#### you can make me clean

In biblical times, a person who had any of certain skin diseases was considered unclean until his skin had healed enough that he was no longer contagious. AT: "you can heal me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Moved with compassion, Jesus

Here the word "moved" is an idiom meaning to feel emotion about another's need. AT: "Having compassion for him, Jesus" or "Jesus felt compassion for the man, so he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I am willing

It may be helpful to state what Jesus is willing to do. AT: "I am willing to make you clean" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leprosy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leprosy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 01:43

#### General Information:

The word "him" used here refers to the leper whom Jesus healed.

#### Be sure to say nothing to anyone

"Be sure to not say anything to anyone"

#### show yourself to the priest

Jesus told the man to show himself to the priest so that the priest could look at his skin to see if his leprosy was really gone. It was required in the law of Moses for a man to present himself to the priest if he had been cleansed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### show yourself

The word "yourself" here represents the skin of the leper. AT: "show your skin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### a testimony to them

It is best to use the pronoun "them," if possible, in your language. Possible meanings are 1) "a testimony to the priests" or 2) "a testimony to the people."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### Mark 01:45

#### But he went out

The word "he" refers to the man Jesus healed.

#### began to spread the news widely

Here "spread the news widely" is a metaphor for telling people in many places about what had happened. AT: "began to tell people in many places about what Jesus had done" (See: and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so much that

The man spread the news so much that

#### that Jesus could no longer enter a town openly

This was the result of the man spreading the news so much. Here "openly" is a metaphor for "publicly." Jesus could not enter the towns because many people would crowd around him. AT: "that Jesus could no longer enter a town publicly" or "that Jesus could no longer enter the towns in a way that many people would see him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### remote places

"lonely places" or "places where no one lived"

#### from everywhere

The word "everywhere" is a hyperbole used to emphasize how very many places the people came from. AT: "from all over the region" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 01:intro

#### Mark 01 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 1:2-3, which is quoted from the OT.

####### Special concepts in this chapter #######

######## "You can make me clean" ########
Leprosy was a disease of the skin that made a person unclean and unable to properly worship God. Jesus is capable of making people physically "clean" or healthy as well as spiritually "clean" or right with God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unclean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unclean.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]])

######## "The kingdom of God is near" ########

Scholars debate whether the "kingdom of God" was present at this time or is something that is still coming. English translations frequently use the phrase "at hand," but this can create difficulty for translators. Other versions use the phase "is coming" and "has come near."

##### Links: #####

* __[Mark 01:01 Notes](./01.md)__
* __[Mark intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Mark 02

### Mark 02:01

#### Connecting Statement:

After preaching and healing people throughout Galilee, Jesus returns to Capernaum where he heals and forgives the sin of a paralyzed man.

#### it was heard that he was at home

This can be stated in active form. AT: "the people there heard that he was staying at his home" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### So many gathered there

The word "there" refers to the house that Jesus stayed it in Capernaum. AT: "So many people gathered there" or "So many people came to the house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explcit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explcit.md)]])

#### there was no more space

This refers to there being no space inside the house. AT: "there was no more room for them inside" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Jesus spoke the word to them
"Word" is a metonym for "message. AT: "Jesus spoke his message to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]

### Mark 02:03

#### four people were carrying him

"four of them were carrying him." It is likely that there were more than four people within the group that brought the man to Jesus.

#### were bringing a paralyzed man

"were bringing a man who was unable to walk or use his arms"

#### could not get near him

"could not get close to where Jesus was"

#### they removed the roof ... they lowered

Houses where Jesus lived had flat roofs made of clay and covered with tiles. The process of making a hole in the roof can be explained more clearly or made more general so that it may be understood in your language. AT: "they removed the tiles from the part of the roof above where Jesus was. And when they had dug through the clay roof, they lowered" or "they made a hole in the roof above where Jesus was, and then they lowered"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 02:05

#### Seeing their faith

"Seeing the men's faith." Possible meanings are 1) that only the men who carried the paralyzed man had faith or 2) that the paralyzed man and the men who brought him to Jesus all had faith. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Son

The word "Son" here shows Jesus cared for the man as a father cares for a son. AT: "My son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your sins are forgiven

If possible translate this in such a way that Jesus does not clearly say who forgives the man's sins. AT: "your sins are gone" or "you do not have to pay for your sins" or "your sins do not count against you"

#### reasoned in their hearts

Here "their hearts" is a metonym for the people's thoughts. AT: "were thinking to themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### How can this man speak this way?

The scribes used this question to show their anger that Jesus said "Your sins are forgiven." AT: "This man should not speak this way!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Who can forgive sins but God alone?

The scribes used this question to say that since only God can forgive sins, then Jesus should not say "Your sins are forgiven." AT: "Only God can forgive sins!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Mark 02:08

#### in his spirit

"in his inner being" or "in himself"

#### they were thinking among themselves

Each of the scribes was thinking to himself; they were not talking to each other.

#### Why are you thinking this in your hearts?

Jesus uses this question to tell the scribes that what they are thinking is wrong. AT: "What you are thinking is wrong." or "Do not think that I am blaspheming." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### this in your hearts

The word "hearts" is a metonym for their inner thoughts and desires. AT: "this inside yourselves" or "these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### What is easier to say to the paralyzed man ... take up your bed, and walk'?

Jesus uses this question to make the scribes think about what might prove whether or not he could really forgive sins. AT: "I just said  to the paralyzed man, 'Your sins are forgiven.' You may think that it is harder to say 'Get up, take up your bed, and walk,' because the proof of whether or not I can heal him will be shown by whether or not he gets up and walks." or "You may think that it is easier to say to the paralyzed man 'Your sins are forgiven' than it is to say 'Get up, take up your bed, and walk.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]

### Mark 02:10

#### But in order that you may know

"But so that you may know." The word "you" refers to the scribes and the crowd.

#### that the Son of Man has authority

Jesus refers to himself as the "Son of Man." AT: "that I am the Son of Man and I have authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### in front of everyone

"while all the people there were watching"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Mark 02:13

#### Connecting Statement:

Jesus is teaching the crowd beside the Sea of Galilee, and he calls Levi to follow him.

#### the lake

This is the Sea of Galilee, which is also known as the Lake of Gennesaret.

#### the crowd came to him

"the people went where he was"

#### Levi son of Alphaeus

Alpheus was Levi's father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/matthew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/matthew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/taxcollector.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/taxcollector.md)]]

### Mark 02:15

#### Connecting Statement:

It is now later in the day, and Jesus is at Levi's house for a meal.

#### Levi's house

"the home of Levi"

#### sinful people

The Pharisees used the phrase "sinful people" to refer to people who did not keep the law as well as the Pharisees thought they should.

#### for there were many and they followed him

Possible meanings are 1) "for there were many tax collectors and sinful people who followed Jesus" or 2) "for Jesus had many disciples and they followed him."

#### Why does he eat with tax collectors and sinful people?

The scribes and Pharisees asked this question to show they disapproved of Jesus' hospitality. This can be worded as a statement. AT: "He should not eat with sinners and tax collectors!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/matthew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/matthew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/taxcollector.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/taxcollector.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]

### Mark 02:17

#### Connecting Statement:

Jesus responds to what the scribes had said to his disciples about his eating with tax collectors and sinful people.

#### he said to them

"he said to the scribes"

#### People who are strong in body do not need a physician; only people who are sick need one

Jesus used this proverb about sick people and doctors to teach them that only people who know that they are sinful realize that they need Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-proverbs.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-proverbs.md)]])

#### strong in body

"healthy"

#### I did not come to call righteous people, but sinful people

Jesus expects his hearers to understand he came for those who want help. AT: "I came for people who understand they are sinful, not for people who believe they are righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### but sinful people

The words "I came to call" are understood from the phrase before this. AT: "but I came to call sinful people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Mark 02:18

#### Connecting Statement:

Jesus tells parables to show why his disciples should not fast while he is with them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### the Pharisees were fasting ... the disciples of the Pharisees

These two phrases refer to the same group of people, but the second is more specific. Both refer to the followers of the Pharisee sect, but they do not focus on the leaders of the Pharisees. AT: "the disciples of the Pharisees were fasting ... the disciples of the Pharisees"

#### Some people

"Some men." It is best to translate this phrase without specifying exactly who these men are. If in your language you have to be more specific, the possible meanings are 1) these men were not among John's disciples or the disciples of the Pharisees or 2) these men were among John's disciples.

#### came and said to him

"came and said to Jesus"

#### Can the wedding attendants fast while the bridegroom is still with them?

Jesus uses this question to remind the people of something they already know and to encourage them to apply it to him and his disciples. AT: "Wedding attendants do not fast while the bridegroom is with them. Rather they celebrate and feast." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md)]]

### Mark 02:20

#### the bridegroom will be taken away

This can be stated in active form. AT: "the bridegroom will go away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### away from them ... they will fast

The word "them" and "they" refer to the wedding attendants.

#### No man sews a piece of new cloth on an old garment

Sewing a piece of new cloth on an old garment will make the hole on an old garment worse if the piece of new cloth has not yet shrunk. Both the new cloth and old garment will be ruined. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### No man

"No one." This phrase refers to all people, not just men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]

### Mark 02:22

#### Connecting Statement:

Jesus begins to tell another parable. This one is about putting new wine into old wineskins rather than into new wineskins. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### new wine

"grape juice." This refers to wine that has not fermented yet. If grapes are unknown in your area, use the general term for fruit juice.

#### old wineskins

This refers to wineskins that have been used many times.

#### wineskins

These were bags made out of animal skins. They could also be called "wine bags" or "skin bags."

#### the wine will burst the skins

New wine expands as it ferments, so it would cause old, brittle wineskins to tear open.

#### lost

"ruined"

#### fresh wineskins

"new wineskins" or "new wine bags." This refers to wineskins that have never been used.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Mark 02:23

#### Connecting Statement:

Jesus gives the Pharisees an example from scripture to show why the disciples were not wrong to pick grain on the Sabbath.

#### pick heads of grain ... doing something that is not lawful on the Sabbath day

Plucking grain in others' fields and eating it was not considered stealing. The question was whether it was lawful to do this on the Sabbath.

#### pick heads of grain

The disciples picked the heads of grain to eat the kernels, or seeds, in them. This can be worded to show the full meaning. AT: "pick heads of grain and eat the seeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### heads of grain

The "heads" are the topmost part of the wheat plant, which is a kind of tall grass. The heads hold the mature grain or seeds of the plant.

#### Look, why are they doing something that is not lawful on the Sabbath day?

The Pharisees ask Jesus a question to condemn him. This can be translated as a statement. AT: "Look! They are breaking the Jewish law concerning the Sabbath." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Look

"Look at this" or "Listen." This is a word used to get the attention of someone to show them something. If there is a word in your language that is used to draw a person's attention to something, you could use that here.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Mark 02:25

#### He said to them

"Jesus said to the Pharisees"

#### Have you never read what David ... those who were with him?

Jesus asks this question to remind the scribes and Pharisees of something David did on the Sabbath. The question is very long, so it can be divided into two sentences. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Have you never read what David did when he was in need and hungry—he and the men who were with him—how he ... him?

This can be stated as a command. AT: "Remember what you read about what David did ... him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### read what David

Jesus refers to reading about David in the Old Testament. This can be translated showing the implicit information. AT: "read in the scriptures what David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### how he went into the house of God ... to those who were with him?

This can be expressed as a statement separate from verse 25. AT: "He went into the house of God ... to those who were with him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### how he went

The word "he" refers to David.

#### bread of the presence

This refers to the twelve loaves of bread that were placed on a golden table in the tabernacle or temple building as a sacrifice to God during Old Testament times.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abiathar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abiathar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Mark 02:27

#### The Sabbath was made for mankind

Jesus makes clear why God established the Sabbath. This can be stated in active form. AT: "God made the Sabbath for mankind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### mankind

"man" or "people" or "the needs of people." This word here refers to both men and women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### not mankind for the Sabbath

The words "was made" are understood from the previous phrase. They can be repeated here. AT: "mankind was not made for the Sabbath" or "God did not make mankind for the Sabbath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Mark 02:intro

#### Mark 02 General Notes ####

####### Special concepts in this chapter #######

######## "Sinful people" ########
Mark refers to a group of people as "sinful." The Jewish leaders thought these people were sinful, but in reality it was the leaders were truly being sinful. This can be taken as irony. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

######## Fasting and Feasting ########
Fasting was often done during times of grief and repentance. It was not done during joyous times. During times of great joy and celebration, such as at weddings, people had a large feast. Having Jesus on the earth was a cause of celebration for mankind.

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
Rhetorical questions are used several times in this chapter. The Jewish leaders used them to express disbelief and anger. Jesus used them to show the Jewish leaders their ignorance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

##### Links: #####

* __[Mark 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Mark 03

### Mark 03:01

#### Connecting Statement:

Jesus heals a man on the Sabbath in the synagogue and shows how he feels about what the Pharisees had done with the Sabbath rules. The Pharisees and Herodians begin to plan to put Jesus to death.

#### a man with a withered hand

"a man with a crippled hand"

#### Some people watched him closely to see if he would heal him

"Some people watched Jesus closely to see if he would heal the man with the withered hand"

#### Some people

"Some of the Pharisees." Later, in [Mark 3:6](./05.md), these people are identified as Pharisees.

#### so that they could accuse him

If Jesus were to heal the man that day, the Pharisees would accuse him breaking the law by the working on the Sabbath. AT: "so that they could accuse him of wrongdoing" or "so that they could accuse him of breaking the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]

### Mark 03:03

#### in the middle of everyone

"in the middle of this crowd"

#### Is it lawful to do good on the Sabbath ... or to kill?

Jesus said this to challenge them. He wanted them to acknowledge that it is lawful to heal people on the Sabbath. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to do good on the Sabbath day or to do harm ... to save a life or to kill

These two phrases are similar in meaning, except that the second is more extreme. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### to save a life or to kill

It may be helpful to repeat "is it lawful," as that is the question Jesus is asking again in another way. AT: "is it lawful to save a life or to kill" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### a life

This refers to physical life and is a metonym for a person. AT: "someone from dying" or "someone's life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But they were silent

"But they refused to answer him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Mark 03:05

#### He looked around

"Jesus looked around"

#### was grieved

"was deeply saddened"

#### by their hardness of heart

This metaphor describes how the Pharisees were unwilling to have compassion on the man with the withered hand. AT: "because they were unwilling to have compassion on the man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Stretch out your hand

"Reach out with your hand"

#### his hand was restored

This can be stated with an active form. AT: "Jesus restored his hand" or "Jesus made his hand the way it was before" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### began to plot

"began to make a plan"

#### the Herodians

This is the name of an informal political party that supported Herod Antipas.

#### how they might put him to death

"how they might kill Jesus"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Mark 03:07

#### Connecting Statement:

A great crowd of people follows Jesus, and he heals many people.

#### the sea

This refers to the Sea of Galilee.

#### Idumea

This is the region, previously known as Edom, which covered the southern half of the province of Judea.

#### the things he was doing

This refers to the miracles Jesus was performing. AT: "the great miracles that Jesus was performing"

#### came to him

"came to where Jesus was"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]

### Mark 03:09

#### General Information:

Verse 9 tells what Jesus asked his disciples to do because of the large crowd of people around him. Verse 10 tells why such a large crowd was around Jesus. The information in these verses can be reordered to present the events in the order they happened, as in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]]

#### He asked his disciples to have a small boat ... not crush him

As the large crowd was pushing forward toward Jesus, he was in danger of being crushed by them. They would not crush him intentionally. It was just that there were so many people.

#### He asked his disciples

"Jesus told his disciples"

#### For he healed many, so that everyone ... to touch him

This tells why so many people were crowding around Jesus that he thought they might crush him. AT: "For, because Jesus had healed many people, everyone ... to touch him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]])

#### For he healed many

The word "many" refers to the large number of people Jesus had already healed. AT: "For he healed many people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### everyone who had afflictions eagerly approached him in order to touch him

They did this because they believed that touching Jesus would make them well. This can be expressed clearly. AT: "all the sick people pushed forward eagerly trying to touch him so that they might be healed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]]) 

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]

### Mark 03:11

#### saw him

"saw Jesus"

#### they fell down ... cried out, and they said

Here "they" refers to the unclean spirits. It is they who are causing the people they possess to do things. This can be made explicit. AT: "they caused the people they were possessing to fall down before him and to cry out to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they fell down before him

The unclean spirits did not fall down before Jesus because they loved him or wanted to worship him. They fell down before him because they were afraid of him.

#### You are the Son of God

Jesus has power over unclean spirits because he is the "Son of God."

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### He strictly ordered them

"Jesus strictly ordered the unclean spirits"

#### not to make him known

"not to reveal who he was"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Mark 03:13

#### General Information:

Jesus chooses the men he wants to be his apostles.

#### so that they might be with him and he might send them to proclaim the message

"so that they would be with him and he would send them to proclaim the message"

#### Simon, to whom he gave the name Peter

The author begins to list the names of the twelve apostles. Simon is the first man listed.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]

### Mark 03:17

#### to whom he gave

The phrase "to whom" refers to both James son of Zebedee and his brother John.

#### the name Boanerges, that is, sons of thunder

Jesus called them this because they were like thunder. AT: "the name Boanerges, which means men who are like thunder" or "the name Boanerges, which means thunder men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Thaddaeus

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### who would betray him

"who would betray Jesus" The word "who" refers to Judas Iscariot.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bartholomew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bartholomew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/matthew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/matthew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofalphaeus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofalphaeus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simonthezealot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simonthezealot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]

### Mark 03:20

#### Then he went home

"Then Jesus went to the house where he was staying."

#### they could not even eat bread

The word "bread" represents food. AT: "Jesus and his disciples could not eat at all" or "they could not eat anything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they went out to seize him

Members of his family went to the house, so that they could take hold of him and force him to go home with them.

#### for they said

Possible meanings for the word "they" are 1) his relatives or 2) some people in the crowd.

#### out of his mind

Jesus' family uses this idiom to describe how they think he is acting. AT: "crazy" or "insane" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### By the ruler of the demons he drives out demons

"By the power of Beelzebul, who is the ruler of the demons, Jesus drives out demons"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beelzebul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beelzebul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### Mark 03:23

#### Connecting Statement:

Jesus explains with a parable why it is foolish for people to think that Jesus is controlled by Satan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### Jesus called them to him

"Jesus called the people to come to him"

#### How can Satan cast out Satan?

Jesus asked this rhetorical question in response to the scribes saying that he cast out demons by Beelzebul. This question can be written as a statement. AT: "Satan cannot cast out himself!" or "Satan does not go against his own evil spirits!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### If a kingdom is divided against itself

The word "kingdom" is a metonym for the people who live in the kingdom. AT: "If the people who live in a kingdom are divided against each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### cannot stand

This phrase is a metaphor meaning that the people will no longer be united and they will fall. AT: "cannot endure" or "will fall"(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### house

This is a metonym for the people who live in a house. AT: "family" or "household" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Mark 03:26

#### If Satan has risen up against himself and is divided

The word "himself" is a reflexive pronoun that refers back to Satan, and it is also a metonym for his evil spirits. AT: "If Satan and his evil spirits were fighting one another" or "If Satan and his evil spirits have risen up against each other and are divided" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### is not able to stand

This is a metaphor meaning he will fall and cannot endure. AT: "will cease to be united" or "cannot endure and has come to an end" or "will fall and has come to an end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### plunder

to steal a person's valuables and possessions

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### Mark 03:28

#### Truly I say to you

This indicates that the statement that follows is especially true and important.

#### the sons of men

"those who have been born of man." This expression is used to emphasize peoples' humanity. AT: "people"

#### utter

"speak"

#### they were saying

"the people were saying"

#### has an unclean spirit

This is an idiom that means to be possessed by an unclean spirit. AT: "is possessed by an unclean spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### Mark 03:31

#### Then his mother and his brothers came
"Then Jesus' mother and brothers came"

#### They sent for him, summoning him

"They sent someone inside to tell him that they were outside and to have him come out to them"

#### are looking for you

"are asking for you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Mark 03:33

#### Who are my mother and my brothers?

Jesus uses this question to teach the people. AT: "I will tell you who are really my mother and brothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### whoever does ... that person is

"those who do ... they are"

#### that person is my brother, and sister, and mother

This is a metaphor that means Jesus' disciples belong to Jesus' spiritual family. This is more important than belonging to his physical family. AT: "that person is like a brother, sister, or mother to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Mark 03:intro

#### Mark 03 General Notes ####

####### Special concepts in this chapter #######

######## Sabbath ########
It was against the law of Moses to do work on the Sabbath. The Pharisees believed healing a sick person on the Sabbath was "work" and they prohibited it. Because of his compassion, Jesus healed on the Sabbath and did not consider it to be "work." It is ironic that the Jewish leaders wanted to kill Jesus for saving people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

######## "Blasphemy against the Spirit" ########

There is a great deal of controversy regarding properly identifying this specific sin. However, it seems to involve insulting the Holy Spirit and his work. Since part of his work is to convince people that they are sinners and that they need God's forgiveness, anyone who rejected this truth would be unwilling to come in repentance to God. For this reason, they would not be forgiven. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Other possible translation difficulties in this chapter #######

######## The twelve apostles ########

The following are the lists of the twelve apostles found in the Bible:

In Matthew: Simon (Peter), Andrew, James son of Zebedee, John son of Zebedee, Philip, Bartholomew, Thomas, Matthew, James son of Alphaeus, Thaddeus, Simon the Zealot and Judas Iscariot.

In Mark: Simon (Peter), Andrew, James the son of Zebedee, and John the son of Zebedee (to whom he gave the name Boanerges, that is, sons of thunder), Philip, Bartholomew, Matthew, Thomas, James the son of Alphaeus, Thaddaeus, Simon the Zealot, and Judas Iscariot,

In Luke: Simon (Peter), Andrew, James, John, Philip, Bartholomew, Matthew, Thomas, James, the son of Alphaeus, Simon, who was called the Zealot, Judas, the son of James, and Judas Iscariot,

It is probable that Thaddaeus and Jude, the son of James, are two names for the same person.

######## Brothers and Sisters ########
This chapter introduces the concept of "spiritual" brothers and sisters. Scripture often uses these terms to refer to the relationship between fellow Israelites. Here, those who follow Jesus are now referred to as brothers and sisters. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]])

##### Links: #####

* __[Mark 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Mark 04

### Mark 04:01

#### Connecting Statement:

As Jesus taught from a boat at the seaside, he told them the parable of the soils. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### the sea

This is the Sea of Galilee.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]

### Mark 04:03

#### Listen, the farmer

"Pay attention! The farmer"

#### his seed ... some seed ... devoured it ... Other seed ... it did not have ... it sprang ... it did not have

All of the seeds that the farmer sowed are spoken of here as if they are one seed. "his seeds ... some seeds ... devoured them ... Other seeds ... they did not have ... they sprang ... they did not have"

#### As he sowed, some seed fell on the road

"As he threw seed over the soil." In different cultures people sow seeds differently. In this parable the seeds were sown by throwing the seeds over the land that was prepared for growing.

#### it sprang up

"the seed that landed on the rocky soil began to grow quickly"

#### soil

This refers to the loose dirt on the ground in which you can plant seeds.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]

### Mark 04:06

#### the plants were scorched

This refers to the young plants. This may be stated in active form. AT: "it scorched the young plants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### because they had no root, they dried up

"because the young plants had no roots, they dried up"

#### Other seed ... choked it ... it did not produce

All of the seeds that the farmer sowed are spoken of here as if they are one seed. See how you translated this in [Mark 4:3](../04/03.md). "Other seeds ... choked them ... they did not produce"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]

### Mark 04:08

#### some brought forth thirty times as much

The amount of grain produced by each plant is being compared to the single seed from which it grew. AT: "Some plants bore thirty times as much as the seed that the man had planted" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### thirty ... sixty ... a hundred

"30 ... 60 ... 100." These may be written as numerals. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### some sixty, and some a hundred

Jesus continues to describe the amount of grain that was produced. Ellipsis is used here to shorten the phrases but they can be written out. AT: "some produced sixty times as much grain and some produced a hundred times as much grain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Whoever has ears to hear

This is a way of referring to everyone there who was hearing what Jesus was saying. AT: "Whoever can hear me" or "Everyone who can hear me (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### let him hear

Here the word "hear" means to pay attention. AT: "let him listen carefully" or "must pay careful attention to what I am saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]

### Mark 04:10

#### When Jesus was alone

This does not mean that Jesus was completely alone; rather, that the crowds were gone and Jesus was only with the twelve and some of his other close followers.

#### To you is given

This can be stated in active form. "God has given you" or "I have given you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to those outside

"but to those who are not among you." This refers to all the other people who were not among the twelve or Jesus' other close followers.

#### everything is in parables

It can be stated that Jesus gives the parables to the people. AT: "I have spoken everything in parables" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### when they look ... when they hear

It is assumed that Jesus is speaking about the people looking at what he shows them and hearing what he tells them. AT: "when they look at what I am doing ... when they hear what I am saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they look, but do not see

Jesus speaks of people understanding what they see as actually seeing. AT: "they look and do not understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### turn

This refers to turning away from sin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]

### Mark 04:13

#### Connecting Statement:

Jesus explains the parable of the soils to his followers and then tells them about using a lamp to show that hidden things will become known.

#### Then he said to them

"Then Jesus said to his disciples"

#### Do you not understand this parable? How then will you understand all the other parables?

Jesus used these questions to show how sad he was that his disciples could not understand his parable. AT: "If you cannot understand this parable, think about how hard it will be for you to understand all the other parables." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The farmer who sows his seed is

"The farmer who sows his seed represents"

#### the one who sows the word

The "word" represents God's message. Sowing the message represents teaching it. AT: "the one who teaches people God's message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### These are the ones that fall beside the road

"Some people are like the seeds that fall beside road" or "Some people are like the path where some of the seeds fell"

#### the road

"the path"

#### when they hear it

Here "it" refers to "the word" or "God's message."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### Mark 04:16

#### These are the ones

"And some people are like the seeds." Jesus begins to explain how some people are like the seeds that fell on the rocky soil. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They have no root in themselves

This is a comparison to the young plants that have very shallow roots. This metaphor means that the people were first excited when they received the word, but they were not strongly devoted to it. AT: "And they are like the young plants that have no roots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### no root

This is an exaggeration to emphasize how shallow the roots were. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### endure

In this parable, "endure" means "believe." AT: "continue in their belief" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### because of the word

It may be helpful to explain why tribulation comes. It came because people believed God's message. AT: "because they believed God's message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they stumble

In this parable, "stumble" means "stop believing God's message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]

### Mark 04:18

#### The others are the ones that were sown among the thorns

Jesus begins to explain how some people are like the seeds that fell among the thorns. AT: "And other people are like the seeds that were sown among the thorns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the cares of the world

"the worries in this life" or "the concerns about this present life"

#### the deceitfulness of riches

"the desires for riches"

#### enter in and choke the word

As Jesus continues to talk about people who are like the seeds that fell among the thorns, he explains what the desires and worries do to the word in their lives. AT: "enter in and choke God's message in their lives like thorns choke young plants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### it does not produce a crop

"the word does not produce a crop in them"

#### those that were sown in the good soil

Jesus begins to explain how some people are like the seeds that were sown in good soil. AT: "like the seeds that were sown in the good soil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### thirty, sixty, or a hundred times what was sown

This refers to the grain that the plants produce. AT: "some produce thirty grains, some produce sixty grains, and some produce a hundred grains" or "some produce 30 times the grain that was sown, some produce 60 times the grain that was sown, and some produce 100 times the grain that was sown" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] or [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Mark 04:21

#### Jesus said to them

"Jesus said to the crowd"

#### Do you bring a lamp inside the house to put it under a basket, or under the bed?

This question may be written as a statement. AT: "You certainly do not bring a lamp inside the house to put it under a basket, or under a bed!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### For nothing is hidden that will not be known ... come out into the open

This can be stated in positive form. AT: "For everything that is hidden will be made known, and everything that is secret will come out into to open" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### nothing is hidden ... nothing is secret

"there is nothing that is hidden ... there is nothing that is secret" Both of the phrases have the same meaning. Jesus is emphasizing that everything that is secret will be made known. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### If anyone has ears to hear, let him hear

See how you translated this in [Mark 4:9](./08.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]

### Mark 04:24

#### He said to them

"Jesus said to the crowd"

#### for the measure you use

Possible meanings are 1) Jesus is talking about a literal measure and giving generously to others or 2) this is a metaphor in which Jesus speaks of "understanding" as if it were "measuring." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will be measured to you, and more will be added to you.

This can be stated in active form. AT: "God will measure that amount for you, and he will add it to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to him will be given more ... even what he has will be taken

This can be stated in active form. AT: "to him God will give more ... from him God will take away" or "God will give more to him ... God will take away from him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

### Mark 04:26

#### Connecting Statement:

Jesus then tells the people parables to explain the kingdom of God, which he later explains to his disciples. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### like a man who sows his seed

Jesus likens the kingdom of God to a farmer who sows his seed. AT: "like a farmer who sows his seed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### He sleeps at night and gets up by day

This is something that the man habitually does. AT: "He sleeps each night and gets up each day" or "He sleeps each night and gets up the next day" 

#### gets up by day

"is up during the day" or "is active during the day"

#### though he does not know how

"though the man does not know how the seed sprouts and grows" 

#### the blade

the stalk or sprout

#### the ear

the head on the stalk or the part of the plant that holds the fruit

#### he immediately sends out the sickle

Here "the sickle" is a metonym that stands for the farmer or the people who the farmer sends out to harvest the grain. AT: "he immediately goes out with a sickle to harvest the grain" or "he immediately sends out people with sickles to harvest the grain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### sickle

a curved blade or a sharp hook used to cut grain

#### because the harvest has come

Here the phrase "has come" is an idiom for the grain being ripe for harvest. AT: "because the grain is ready to be harvested" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Mark 04:30

#### To what can we compare the kingdom of God, or what parable can we use to explain it?

Jesus asked this question to cause his hearers to think about what the kingdom of God is. AT: "With this parable I can explain what the kingdom of God is like." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### when it is sown

This can be stated in active form. AT: "when someone sows it" or "when someone plants it"

#### it forms large branches

The mustard tree is described as causing its branches to grow large. AT: "with large branches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]

### Mark 04:33

#### he spoke the word to them

"Word" here is a synecdoche for "the message of God." The word "them" refers to the crowds. AT: "he taught the message of God to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### as much as they were able to understand

"and if they were able to understand some, he kept telling them more"

#### when he was alone

This means that he was away from the crowds, but his disciples were still with him.

#### he explained everything

Here "everything" is an exaggeration. He explained all his parables. AT: "he explained all his parables" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### Mark 04:35

#### Connecting Statement:

As Jesus and his disciples take a boat to escape the crowds of people, a great storm arises. His disciples are afraid when they see that even the wind and the sea obey Jesus.

#### he said to them

"Jesus said to his disciples"

#### the other side

"the other side of the Sea of Galilee" or "the other side of the sea"

#### a violent windstorm arose

Here "arose" is an idiom for "began." AT: "a violent windstorm began" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the boat was almost full of water

It may be helpful to state that the boat was filling up with water. AT: "the boat was in danger of being filled with water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 04:38

#### Jesus himself

Here "himself" emphasizes that Jesus was alone in the stern. AT: "Jesus himself was alone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### the stern

This is at the very back of the boat. "the stern of the boat"

#### They woke him up

The word "they" refers to the disciples. Compare a similar idea in the next verse, verse 39, "He got up." "He" refers to Jesus.

#### do you not care that we are about to die?

The disciples asked this question to convey their fear. This question can be written as a statement. AT: "you need to pay attention to what is happening; we are all about to die!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### we are about to die

The word "we" includes the disciples and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Peace! Be still!

These two phrases are similar and used to emphasize what Jesus wanted the wind and the sea to do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### a great calm

"a great stillness over the sea" or "a great calm over the sea"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Mark 04:40

#### Then he said to them

"And Jesus said to his disciples"

#### Why are you afraid? Do you still not have faith?

Jesus asks these questions to make his disciples consider why they are afraid when he is with them. These questions can be written as statements. AT: "You should not be afraid. You need to have more faith." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Who then is this, because even the wind and the sea obey him?

The disciples ask this question in amazement at what Jesus did. This question can be written as a statement. AT: "This man is not like ordinary men; even the wind and the sea obey him!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### Mark 04:intro

#### Mark 04 General Notes ####

####### Structure and Format #######

Mark 4:3-10 forms one parable. The parable is explained in 4:14-23. 

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 4:12, which is quoted from the OT.

####### Special concepts in this chapter #######

######## Parables ########
There are many parables in this chapter. They are a way Jesus teaches about the kingdom of God. Jesus explains their meanings to the disciples, but not to the crowds. 

####### Other possible translation difficulties in this chapter #######

######## Implicit Information ########
In several parts of this chapter the author left some information implicit that his original readers would have understood and thought about. Modern readers might not know some of those things, so they might have trouble understanding all that the author was communicating. The UDB often shows how that information can be presented so that modern readers will be able to understand those passages. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Mark 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Mark 05

### Mark 05:01

#### Connecting Statement:

After Jesus calms the great storm, he heals a man who has many demons, but the local people in Gerasa are not glad about his healing, and they beg Jesus to leave.

#### They came

The word "They" refers to Jesus and his disciples.

#### the sea

This refers to the Sea of Galilee.

#### Gerasenes

This name refers to the people who live in Gerasa. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### with an unclean spirit

This is an idiom meaning that the man is "controlled" or "possessed" by the unclean spirit. AT: "controlled by an unclean spirit" or "that an unclean spirit possessed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### Mark 05:03

#### He had been bound many times

This can be written in active form. AT: "People had bound him many times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his shackles were shattered

This can be written in active form. AT: "shattered his shackles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### shackles

"bonds on his feet" or "metal bindings attached to his ankles to confine him"

#### chains

"handcuffs" or "chains attached to his wrists to confine him"

#### No one had the strength to subdue him

The man was so strong that no one could subdue him. AT: "He was so strong that no one was strong enough to subdue him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### subdue him

"control him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]

### Mark 05:05

#### cut himself with sharp stones

Often times when a person is possessed by a demon, the demon will cause the person to do self-destructive things, such as cutting himself.

#### When he saw Jesus from a distance

When the man first saw Jesus, Jesus would have been getting out of the boat. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### bowed down

This means that he knelt down before Jesus out of reverence and respect, not out of worship.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]

### Mark 05:07

#### General Information:

The information in these two verses may be reordered to present the events in the order that they happened, as in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])

#### He cried out

"The unclean spirit cried out"

#### What do I have to do with you, Jesus, Son of the Most High God?

The unclean spirit asks this question out of fear. This can be written as a statement. AT: "Leave me alone, Jesus, Son of the Most High God! There is no reason for you to interfere with me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Jesus ... do not torment me

Jesus has the power to torment unclean spirits.

#### Son of the Most High God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I beg you by God himself

Here the unclean spirit is swearing by God as he makes a request of Jesus. Consider how this type of request is made in your language. AT: "I beg you before God" or "I swear by God himself and beg you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### Mark 05:09

#### He asked him

"And Jesus asked the unclean spirit"

#### He answered him, "My name is Legion, for we are many."

One spirit was speaking for many here. He spoke of them as if they were a legion, a Roman army unit of about 6,000 soldiers. AT: "And the spirit said to him, 'Call us an army, for many of us are inside the man.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

### Mark 05:11

#### they begged him

"the unclean spirits begged Jesus"

#### he allowed them

It may be helpful to state clearly what Jesus allowed them to do. AT: "Jesus allowed the unclean spirits to do what they asked permission to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they rushed

"the pigs rushed"

#### into the sea, and about two thousand pigs drowned in the sea

You can make this a separate sentence: "into the sea. There were about two thousand pigs, and they drowned in the sea"

#### about two thousand pigs

"about 2,000 pigs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### Mark 05:14

#### in the city and in the countryside

It can be stated clearly that the men gave their report to the people who were in the city and countryside. AT: "to people in the city and in the countryside" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Legion

This was the name of the many demons that were in the man. See how you translated this in [Mark 5:9](./09.md).

#### in his right mind

This is an idiom meaning that he is thinking clearly. AT: "of a normal mind" or "thinking clearly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they were afraid

The word "they" refers to the group of people who went out to see what had happened.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]

### Mark 05:16

#### Those who had seen what happened

"The people who had witnessed what had happened"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 05:18

#### the demon-possessed man

Though the man is no longer demon-possessed, he is still described in this way. AT: "the man who had been demon-possessed"

#### But Jesus did not permit him

What Jesus did not allow the man to do can be stated clearly. AT: "But he did not allow the man to come with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Decapolis

This is the name of a region that means Ten Cities. It is located to the southeast of the Sea of Galilee. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### everyone was amazed

It may be helpful to state why the people were amazed. AT: "all the people who heard what the man said were amazed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 05:21

#### Connecting Statement:

After healing the demon-possessed man in region of the Gerasenes, Jesus and his disciples return across the lake to Capernaum where the one of the rulers of the synagogue asks Jesus to heal his daughter.

#### the other side

It may be helpful to add information to this phrase. AT: "the other side of the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### beside the sea

"on the seashore" or "on the shore"

#### the sea

This is the Sea of Galilee.

#### Jairus

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### So he went with him

"So Jesus went with Jairus." Jesus' disciples also went with him. AT: "So Jesus and the disciples went with Jairus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### lay your hands

"Laying on hands" refers to a prophet or teacher placing his hand on someone and imparting either healing or a blessing. In this case, Jarius is asking Jesus to heal his daughter.

#### that she may be made well and live

This can be stated in active form. AT: "and heal her and make her live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### pressed close around him

This means they crowded around Jesus and pressed themselves together to be closer to Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Mark 05:25

#### Connecting Statement:

While Jesus is on his way to heal the man's little 12-year-old girl, a woman who has been sick for 12 years interrupts by touching Jesus for her healing.

#### Now a woman was there

"Now" indicates that this woman is being introduced to the story. Consider how new people are introduced into a story in your language. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### who had a flow of blood for twelve years

The woman did not have an open wound; rather, her monthly flow of blood would not stop. Your language may have a polite way to refer to this condition. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### for twelve years

"for 12 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### she grew worse

"her sickness got worse" or "her bleeding increased"

#### the reports about Jesus

She had heard reports about Jesus of how he healed people. AT: "that Jesus healed people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### cloak

outer garment or coat

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 05:28

#### I will be healed

This can be stated in active form. AT: "it will heal me" or "his power will heal me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### she was healed from her affliction

This can be stated in active form. AT: "the sickness had left her" or "she was no longer sick" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]

### Mark 05:30

#### that power had gone out from him

When the woman touched Jesus, Jesus felt his power healing her. Jesus himself did not lose any of his power to heal people when he healed her. AT: "that his healing power had healed the woman"

#### this crowd pressed around you

This means they crowded around Jesus and pressed themselves together to be closer to Jesus. See how you translated this in [Mark 5:24](./21.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### Mark 05:33

#### fell down before him

"knelt down before him." She knelt down before Jesus as an act of honor and submission.

#### told him the whole truth

The phrase "the whole truth" refers to how she had touched him and became well. AT: "told him the whole truth about how she had touched him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Daughter

Jesus was using this term figuratively to refer to the woman as a believer.

#### your faith

"your faith in me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tremble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tremble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Mark 05:35

#### While he was speaking

"While Jesus was speaking"

#### some people came from the leader of the synagogue

Possible meanings are 1) these people had come from Jarius' house or 2) Jairus had previously given these people orders to go see Jesus or 3) these people had been sent by the man who was presiding as the synagogue leader in Jairus' absence.

#### the leader of the synagogue

The "leader of the synagogue" is Jairus.

#### saying

"saying to Jairus"

#### Why trouble the teacher any longer?

This question can be written as a statement. AT: "It is useless to bother the teacher any longer." or "There no need to bother the teacher any longer." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the teacher

This refers to Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]

### Mark 05:36

#### General Information:

The information in verses 37 and 38 may be reordered to present the events in the order that they happened, as in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])
 (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md)]])

#### Just believe

If necessary, you can state what Jesus is commanding Jairus to believe. AT: "Just believe I can make you daughter live"

#### He did not ... he saw

In these verses the word "he" refers to Jesus.

#### to accompany him

"to come with him." It may be helpful to state where they were going. AT: "to accompany him to Jairus' house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]

### Mark 05:39

#### he said to them

"Jesus said to the people who were weeping"

#### Why are you upset and why do you weep?

Jesus asked this question to help them see their lack of faith. This may be written as a statement. AT: "This is not a time to be upset and crying." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The child is not dead but sleeps

"Sleep" is the common euphemism for death among Christians. It could also be a metonym because of the hope for living again. AT: The child is not utterly dead but will wake again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### put them all outside

"sent all the other people outside the house"

#### those who were with him

This refers to Peter, James, and John.

#### went in where the child was

It may be helpful to state where the child is. AT: "went into the room where the child was lying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Mark 05:41

#### Talitha, koum

This is an Aramaic sentence, which Jesus spoke to the little girl in her language. Write these words as is with your alphabet. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### she was twelve years of age

"she was 12 years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### He strictly ordered them that no one should know about this. Then

This can be stated as a direct quote. AT: "He ordered them strictly, 'No one should know about this!' Then" or "He ordered them strictly, 'Do not tell anyone about what I have done!' Then" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### He strictly ordered them

"He strongly commanded them"

#### Then he told them to give her something to eat.

This can be stated as a direct quote. AT: "And he told them, 'Give her something to eat.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 05:intro

#### Mark 05 General Notes ####

####### Other possible translation difficulties in this chapter #######

######## "Talitha koum" ########
This is a phrase in Aramaic. Mark transliterates its sounds by writing them with Greek letters. Then he explains its meaning.
 

##### Links: #####

* __[Mark 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Mark 06

### Mark 06:01

#### Connecting Statement:

Jesus returns to his hometown, where he is not accepted.

#### his hometown

This refers to the town of Nazareth, where Jesus grew up and where his family lived. This does not mean that he owned land there.

#### What is this wisdom that has been given to him?

This question, which contains passive construction, can be asked in active form. AT: "What is this wisdom that he has gained?"

#### that he does with his hands

This phrase emphasizes that Jesus himself does the miracles. AT: "that he himself works"

#### Is this not the carpenter, the son of Mary and the brother of James and Joses and Judas and Simon? Are his sisters not here with us?

These questions can be written as a statement. AT: "He is just an ordinary carpenter! We know him and his family. We know Mary his mother. We know his younger brothers James, Joses, Judas and Simon. And his younger sisters also live here with us." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]

### Mark 06:04

#### to them

"to the crowd"

#### A prophet is not without honor, except

This sentence uses a double negative to create emphasis of the positive equivalent. AT: "A prophet is always honored, except" or "The only place a prophet is not honored is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### to lay his hands on a few sick people

Prophets and teachers would put their hands on people in order to heal them or bless them. In this case, Jesus was healing people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 06:07

#### Connecting Statement:

Jesus sends his disciples out in sets of two to preach and to heal.

#### General Information:

Jesus' instructions in verses 8 and 9 can be reordered to separate what he told the disciples to do from what he told them not to do, as  in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md)]])

#### he called the twelve

Here the word "called" means that he summoned the twelve to come to him.

#### two by two

"2 by 2" or "in pairs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### no bread

Here "bread" is a synecdoche for food in general. AT: "no food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### no money in their belts

In that culture, men carried their money tucked into their belt. AT: "no money in their moneybags" or "no money"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tunic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tunic.md)]]

### Mark 06:10

#### He said to them

"Jesus said to the twelve"

#### remain until you go away from there

Here "remain" represents daily going back to that house to eat and sleep there. AT: "eat and sleep in that house until you leave that place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### as a testimony to them

"as a testimony against them." It may be helpful to explain how this action was a testimony to them. "as a testimony to them. By doing that, you will be testifying that they did not welcome you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### Mark 06:12

#### They went out

The word "They" refers to the twelve and does not include Jesus. Also, it may be helpful to state that they went out to various towns. AT: "They went out to various towns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### turn away from their sins

"repent of their sins"

#### They cast out many demons

It may be helpful to state that they cast the demons out of people. AT: "They cast many demons out of people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Mark 06:14

#### Connecting Statement:

When Herod hears about Jesus' miracles, he worries, thinking that someone has raised John the Baptist from the dead. (Herod had caused John the Baptist to be killed.)

#### King Herod heard this

The word "this" refers to everything that Jesus and his disciples had been doing in various towns, including casting out demons and healing people.

#### Some were saying, "John the Baptist has been

Some people were saying that Jesus was John the Baptist. This can be stated more clearly. AT: "Some were saying, 'He is John the Baptist who has been" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### John the Baptist has been raised

"Raised" here is an idiom for "caused to live again." This can be stated in active form. AT: "John the Baptist has been caused to live again" or "God raised John the Baptist" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Some others said, "He is Elijah."

It may be helpful to state why some people thought he was Elijah. AT: "Some others said, 'He is Elijah, whom God promised to send back again.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### Mark 06:16

#### General Information:

In verse 17 the author begins to give background information about Herod and why he beheaded John the Baptist. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### whom I beheaded

Here Herod uses the word "I" to refer to himself. The word "I" is a metonym for Herod's soldiers. AT: "whom I commanded my soldiers to behead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has been raised

This can be stated in active form. AT: "has become alive again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Herod sent to have John arrested and he had him bound in prison

This can be stated in active form. AT: "Herod sent his soldiers to arrest John and had them bind him in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sent to have

"ordered to have"

#### on account of Herodias

"because of Herodias"

#### his brother Philip's wife

"the wife of his brother Philip." Herod's brother Philip is not the same Philip who was an evangelist in the book of Acts or the Philip who was one of Jesus' twelve disciples. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### because he had married her

"because Herod had married her"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodias.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodias.md)]]

### Mark 06:18

#### wanted to kill him, but she could not

Herodias is the subject of this phrase and "she" is a metonym as she wants someone else to execute John. AT: "she wanted someone to kill him, but she could not have him killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for Herod feared John; he knew

These two clauses can be linked differently to show more clearly why Herod feared John. AT: "for Herod feared John because he knew" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]])

#### he knew that he was a righteous

"Herod knew that John was a righteous"

#### Listening to him

"Listening to John"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodias.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodias.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Mark 06:21

#### Connecting Statement:

The author continues to give background information about Herod and the beheading of John the Baptist. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### he made a dinner for his officials ... of Galilee

Here the word "he" refers to Herod and is a metonym for his servant whom he would have commanded to prepare a meal. AT: "he had a dinner made for his officials ... of Galilee" or "he invited his officials ... of Galilee to eat and celebrate with him"

#### a dinner

a formal meal or banquet

#### Herodias herself

The word "herself" is a reflexive pronoun used to emphasize that it was significant that it was Herodias' own daughter who danced at the dinner. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### came in

"came into the room"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodias.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodias.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Mark 06:23

#### Whatever you ask ... my kingdom

"I will give you up to half of what I own and rule, if you ask for it"

#### went out

"went out of the room"

#### on a wooden platter

"on a board" or "on a large wooden dish"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Mark 06:26

#### because of the oath he had made and because of his dinner guests

The content of the oath, and the relationship between the oath and the dinner guests can be stated clearly. AT: "because his dinner guests had heard him make the oath that he would give her anything she asked for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### on a platter

"on a tray"

#### When his disciples

"When John's disciples"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### Mark 06:30

#### Connecting Statement:

After the disciples return from preaching and healing, they go somewhere to be alone, but there are many people who come to hear Jesus teach. When it becomes late, he feeds the people and then sends everyone away while he prays alone.

#### a deserted place

a place where there are no people

#### many were coming and going

This means that people were continually coming to the apostles and then going away from them.

#### they did not even

The word "they" refers to the apostles.

#### So they went away

Here the word "they" includes both the apostles and Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 06:33

#### they saw them leaving

"the people saw Jesus and the apostles leaving"

#### on foot

The people are going on foot by land, which contrasts with how the disciples went by boat.

#### he saw a great crowd

"Jesus saw a great crowd"

#### they were like sheep without a shepherd

Jesus compares the people to sheep who are confused when they do not have their shepherd to lead them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Mark 06:35

#### When the hour was late

This means it was late in the day. AT: "When it was getting late" or "Late in the afternoon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a deserted place

This refers to a place where there are no people. See how you translated this in [Mark 6:31](./30.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### Mark 06:37

#### But he answered and said to them

"But Jesus answered and said to his disciples"

#### Can we go and buy two hundred denarii worth of bread and give it to them to eat?

The disciples ask this question to say that there is no way they could afford to buy enough food for this crowd. AT: "We could not buy enough bread to feed this crowd, even if we had two hundred denarii!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### two hundred denarii

"200 denarii." The singular form of the word "denarii" is "denarius." A denarius was a Roman silver coin worth one day's wages. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### loaves

"loaves of bread." A loaf of bread is a lump of dough that is shaped and baked.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Mark 06:39

#### green grass

Describe the grass with the color word used in your language for healthy grass, which may or may not be the color green.

#### groups of hundreds and fifties

This refers to the number of people in each of the groups. AT: "about fifty people in some groups and about a hundred people in other groups" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### looking up to heaven

This means that he looked up toward the sky, which is associated with the place where God lives.

#### he blessed

"he spoke a blessing" or "he gave thanks"

#### He also divided the two fish among them all

"he divided the two fish so that everyone could have some"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### Mark 06:42

#### They took up

Possible meaning are 1) "The disciples took up" or 2) "The people took up."

#### broken pieces of bread, twelve baskets full

"twelve baskets full of broken pieces of bread"

#### twelve baskets

"12 baskets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### five thousand men

"5,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### There were five thousand men who ate the loaves

The number of women and children was not counted. If it would not be understood that women and children were present, it can be made explicit. AT: "And there were five thousand men who ate the loaves. They did not even count the women and children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

### Mark 06:45

#### to the other side

This refers to the Sea of Galilee. This can be stated clearly. AT: "to the other side of the Sea of Galilee" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Bethsaida

This is a town on the northern shore of the Sea of Galilee. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### When they were gone

"When the people had left"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]

### Mark 06:48

#### Connecting Statement:

A storm arises while the disciples are trying to cross the lake. Seeing Jesus walking on the water terrifies them. They do not understand how Jesus can calm the storm.

#### fourth watch

This is the time between 3 a.m. and sunrise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### a ghost

the spirit of a dead person or some other kind of spirit

#### Be courageous! ... Do not be afraid!

These two sentences are similar in meaning, emphasizing to his disciples that they did not need to be afraid. They can be combined into one if necessary. AT: "Do not fear me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimewatch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimewatch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courage.md)]]

### Mark 06:51

#### They were completely amazed

If you need to be more specific, it can stated what they were amazed by. AT: "They were completely amazed at what he had done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### what the loaves meant

Here the phrase "the loaves" refers to when Jesus multiplied the loaves of bread. AT: "what it meant when Jesus multiplied the loaves of bread" or "what it meant when Jesus caused the few loaves to become many" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### their hearts were hardened

Having a hard heart represents being too stubborn to understand. AT: "they were too stubborn to understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Mark 06:53

#### Connecting Statement:

When Jesus and his disciples arrive at Gennesaret in their boat, people see him and bring people for him to heal. This happens wherever they go.

#### Gennesaret

This is the name of the region to the northwest of the Sea of Galilee. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### they ran throughout the whole region

It may be helpful to state why they ran through the region. AT: "they ran throughout the whole district in order to tell others that Jesus was there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they ran ... they heard

The word "they" refers to the people who recognized Jesus, not to the disciples.

#### the sick

This phrase refers to people. AT: "the sick people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 06:56

#### Wherever he entered

"Wherever Jesus entered"

#### they would put

Here "they" refers to the people. It does not refer to Jesus' disciples.

#### the sick

This phrase refers to people. AT: "the sick people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### They begged him

Possible meanings are 1) "The sick begged him" or 2) "The people begged him."

#### let them touch

The word "them" refers to the sick.

#### the edge of his garment

"the hem of his robe" or "the edge of his clothes"

#### as many as

"all those who"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Mark 06:intro

#### Mark 06 General Notes ####

####### Special concepts in this chapter #######

######## "Anointed with oil" ########
In the ancient Near East, people would anoint or smear oil on sick people so that they might be healed.

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
Mark uses many rhetorical questions in this chapter to show that people did not understand who Jesus was. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

##### Links: #####

* __[Mark 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Mark 07

### Mark 07:01

#### Connecting Statement:

Jesus rebukes the Pharisees and scribes.

#### gathered around him

"gathered around Jesus"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 07:02

#### General Information:

In verses verses 3 and 4, the author gives background information about the Pharisees' washing traditions in order to show why the Pharisees were bothered that Jesus' disciples did not wash their hands before eating. This information can be reordered in order to make it easier to understand, as in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md)]])

#### They saw

"The Pharisees and the scribes saw"

#### that is, unwashed

The word "unwashed" explains why the disciples' hands were defiled. It can be expressed in active form. AT: "that is, with hands that they had not washed" or "that is, that they had not washed their hands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-active.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-active.md)]])

#### elders

Jewish elders were leaders in their communities and were also judges for the people.

#### copper vessels

"copper kettles" or "metal containers"

#### the couches upon which they eat

"benches" or "beds." At that time, the Jews would recline when eating.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Mark 07:05

#### Why do your disciples not walk according to the tradition of the elders, for they eat their bread with unwashed hands?

The Pharisees and scribes asked this question to challenge Jesus' authority. This can be written as two statements. AT: "Your disciples disobey the traditions of our elders! They should wash their hands using our rituals." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

"Walk" is an idiom for "obey." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### bread

This is a synecdoche, representing food in general. AT: "food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Mark 07:06

#### General Information:

Here Jesus quotes the prophet Isaiah, who had written scripture many years earlier.

#### with their lips

Here "lips" is a metonym for speaking. AT: "by what they say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but their heart is far from me

Here "heart" refers to a person's thoughts or emotions. This is a way of saying the people are not truly devoted to God. AT: "but they do not really love me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Empty worship they offer me

"They offer me useless worship" or "They worship me in vain"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doctrine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doctrine.md)]]

### Mark 07:08

#### Connecting Statement:

Jesus continues to rebuke the scribes and Pharisees.

#### abandon

"refuse to follow"

#### hold fast to

"hold strongly to" or "only keep"

#### How well you reject the commandment ... keep your tradition

Jesus uses this ironic statement to rebuke his listeners for forsaking God's commandment. AT: "You think you have done well in how you have rejected the commandment of God so you may keep your own traditions, but what you have done is not good at all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### How well you reject

"How skillfully you reject"

#### who speaks evil of

"who curses"

#### will surely die

"must be put to death"

#### He who speaks evil of his father or mother will surely die

This may be stated in active form. AT: "The authorities must execute a person who speaks evil about his father or mother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Mark 07:11

#### General Information:

In verses 11 and 12, Jesus shows how the Pharisees teach people that they do not have to obey God's commandment to honor their parents.

#### General Information:

In verse 11 Jesus tells what the Pharisees allow people to say about their possessions, and in verse 12 he tells how that shows the Pharisees' attitude toward people helping their parents. This information can be reordered to first tell about the Pharisees' attitude toward people helping their parents and then tell how that attitude is shown in what the Pharisees allow people to say about their possessions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md)]])

#### Whatever help you would have received from me is Corban

The tradition of the scribes said that once money or other things were promised to the temple, they could not be used for any other purpose. 

#### is Corban

"Corban" here is a Hebrew word that refers to things that people promise to give to God. Translators normally transliterate it using the target language alphabet. Some translators translate its meaning, and then leave out Mark's explanation of the meaning that follows.  AT: "is a gift to God" or "belongs to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### Given to God

This phrase explains the meaning of the Hebrew word "Corban." It can be stated in active form. Mark explained the meaning so that his non-Jewish readers could understand what Jesus said. AT: "I have given it to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### then you no longer permit him to do anything for his father or his mother

By doing this, the Pharisees are allowing people not to provide for their parents, if they promise to give to God what they would have given to them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### void

canceled or done away with

#### many similar things you do

"you are doing may other things similar to this"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md)]]

### Mark 07:14

#### Connecting Statement:

Jesus tells a parable to the crowd to help them understand what he has been saying to the scribes and Pharisees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### He called

"Jesus called"

#### Listen to me, all of you, and understand

The words "Listen" and "understand" are related. Jesus uses them together to emphasize that his hearers should pay close attention to what he is saying. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### understand

It may be helpful to state what Jesus is telling them to understand. AT: "try to understand what I am about to tell you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### nothing from outside of a person

Jesus is speaking about what a person eats. This is in contrast to "what come out of the person." AT: "nothing from outside a person that he can eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It is what comes out of the person

This refers to the things a person does or says. This is in contrast to "what is outside a person that enters into him." AT: "It is what comes out of a person that he says or does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]

### Mark 07:17

#### Connecting Statement:

The disciples still do not understand what Jesus has just said to the scribes, Pharisees, and crowds. Jesus explains his meaning more thoroughly to them.

#### Now

This word is used here to mark a break in the main story line. Jesus is now away from the crowd, in a house with his disciples.

#### Are you also still without understanding?

Jesus uses this question to express his disappointment that they do not understand. This can be expressed as a statement. AT: "After all I have said and done, I would expect you to understand." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### it cannot go into his heart

"Heart" here is a metonym for "thoughts and intentions." AT: "it cannot affect how he thinks or intends to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Do you not see that whatever enters ... latrine?

Jesus uses this question to teach his disciples something they should already know. It can be expressed as a statement. AT: "Whatever enters ... latrine." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### because it

Here "it" refers to what goes into a person; that is, what a person eats.

#### all foods clean

It may be helpful to explain clearly what this phrase means. AT: "all foods clean, meaning that people can eat any food without God considering the eater defiled" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]

### Mark 07:20

#### He said

"Jesus said"

#### It is that which comes out of the person that defiles him

"What defiles a person is what comes out of him" 

#### sensuality

not controlling one's lustful desires

#### come from within

Here the word "within" describes a person's heart. AT: "come from within a person's heart" or "come from within a person's thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### out of the heart, proceed evil thoughts

"Heart" here is a metonym for "thoughts and intentions." AT: "from one's own natural desires, evil thoughts come"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Mark 07:24

#### Connecting Statement:

When Jesus goes away to Tyre, he heals the daughter of a Gentile woman who has extraordinary faith.

#### had an unclean spirit

This is an idiom meaning that she was possessed by the unclean spirit. AT: "was possessed by an unclean spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### fell down

"knelt." This is an act of honor and submission.

#### Now the woman was a Greek, a Syrophoenician by descent

The word "Now" marks a break in the main story line, as this sentence gives us background information about the woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Syrophoenician

This is the name of the woman's nationality. She was born in the Phoenician region in Syria. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### Mark 07:27

#### Let the children first be fed. For it is not right ... throw it to the dogs

Here Jesus speaks about the Jews as if they are children and the Gentiles as if they are dogs. AT: "Let the children of Israel first be fed. For it is not right to take the children's bread and throw it to the Gentiles, who are like dogs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let the children first be fed

This can be stated in active form. AT: "We must first feed the children of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### bread

This refers to food in general. AT: "food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### dogs

This refers to small dogs kept as pets.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Mark 07:29

#### you are free to go

"Free" here is an idiom meaning capable of doing as one wants. AT: "you may go now" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The demon has gone out of your daughter

Jesus has caused the unclean spirit to leave the woman's daughter. This can be expressed clearly. AT: "I have caused the evil spirit to leave your daughter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### Mark 07:31

#### Connecting Statement:

After healing people in Tyre, Jesus goes to the Sea of Galilee. There he heals a deaf man, which amazes the people.

#### went out again from the region of Tyre

"left the region of Tyre"

#### up into the region

Possible meanings are 1) "in the region" as Jesus is at the sea in the region of the Decapolis or 2) "through the region" as Jesus went through the region of the Decapolis to get to the sea.

#### Decapolis

This is the name of a region that means Ten Cities. It is located to the southeast of the Sea of Galilee. See how you translated this in [Mark 5:20](../05/18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They brought

"And people brought"

#### who was deaf

"who was not able to hear"

#### they begged him to lay his hand on him

Prophets and teachers would put their hands on people in order to heal them or bless them. In this case, people are begging Jesus to heal a man. AT: "they begged Jesus to put his hand on the man to heal him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Mark 07:33

#### He took him

"Jesus took the man"

#### he put his fingers into his ears

Jesus is putting his own fingers in the man's ears.

#### after spitting, he touched his tongue

Jesus spits and then touches the man's tongue.

#### after spitting

It may be helpful to state that Jesus spit on his fingers. AT: "after spitting on his fingers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### looked up to heaven

This means that he looked up toward the sky, which is associated with the place where God lives.

#### Ephphatha

Here the author refers to something by an Aramaic word. This word should be copied as is into your language using your alphabet. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### he sighed

This means that he groaned or that he let out a long deep breath that could be heard. It probably shows Jesus' sympathy for the man.

#### said to him

"said to the man"

#### his ears were opened

This means he was able to hear. AT: "his ears were opened and he was able to hear" or "he was able to hear"

#### his tongue was released

This can be stated in active form. AT: "Jesus took away what prevented his tongue from speaking" or "Jesus loosened his tongue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 07:36

#### the more he ordered them

The refers to him ordering them not to tell anyone about what he had done. AT: "the more he ordered them not to tell anyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the more abundantly

"the more widely" or "the more"

#### were extremely astonished

"were utterly amazed" or "were exceedingly astonished" or "were astonished beyond all measure"

#### the deaf ... the mute

These refer to people. AT: "deaf people ... mute people" or "people who cannot hear ... people who cannot speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 07:intro

#### Mark 07 General Notes ####

####### Structure and Format #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 7:6-7, which is quoted from the OT.

####### Special concepts in this chapter #######

######## Hand washing ########
This was a practice done by the Pharisees, but it was not an obligation according to the law of Moses. The Pharisees had many rituals involving washing in an attempt to make themselves clean. This is ironic because no amount of water could make them spiritually clean. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

####### Other possible translation difficulties in this chapter #######

######## "Ephphatha" ########

This is an Aramaic word. Mark "transliterates" its sounds by writing them with Greek letters. After transliterating the word, Mark explains what it means. 

##### Links: #####

* __[Mark 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Mark 08

### Mark 08:01

#### Connecting Statement:

A great, hungry crowd is with Jesus. He feeds them using only seven loaves and a few fish before Jesus and his disciples get in a boat to go to another place.

#### In those days

This phrase is used to introduce a new event in the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### they continue to be with me already for three days and have nothing to eat

"this is this third day these people have been with me, and they have nothing to eat"

#### they may faint

Possible meanings are 1) literal, "they may lose consciousness temporarily" or 2) hyperbolic exaggeration, "they may become weak." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Where can we get enough loaves of bread in such a deserted place to satisfy these people?

The disciples are expressing surprise that Jesus would expect them to be able to find enough food. AT: "This place is so deserted that there is no place here for us to get enough loaves of bread to satisfy these people!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### loaves of bread

Loaves of bread are lumps of dough that have been shaped and baked.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Mark 08:05

#### He asked them

"Jesus asked his disciples"

#### He commanded the crowd to sit down on the ground

This can be written as a direct quote. "Jesus commanded the crowd, 'Sit down on the ground'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### sit down

Use your language's word for how people customarily eat when there is no table, whether sitting or lying down.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### Mark 08:07

#### They also had

Here the word "they" is used to refer to Jesus and his disciples.

#### he gave thanks for them

"Jesus gave thanks for the fish"

#### They ate

"The people ate"

#### they picked up

"the disciples picked up"

#### the remaining broken pieces, seven large baskets

This refers to the broken pieces of fish and bread that were left over after the people ate. AT: "the remaining broken pieces of bread and fish, which filled seven large baskets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Then he sent them away

It may be helpful to clarify when he sent them away. AT: "After they ate, Jesus sent them away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they went into the region of Dalmanutha

It may be helpful to clarify how they got to Dalmanutha. AT: "they sailed around the Sea of Galilee to the region of Dalmanutha" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Dalmanutha

This is the name of a place on the northwestern shore of the Sea of Galilee. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Mark 08:11

#### Connecting Statement:

In Dalmanutha, Jesus refuses to give the Pharisees a sign before he and his disciples get in a boat and leave.

#### They sought from him

"They asked him for"

#### a sign from heaven

They wanted a sign that would prove that Jesus' power and authority were from God. Possible meanings are 1) The word "heaven" is a metonym for God. AT: "a sign from God" or 2) the word "heaven" refers to the sky. AT: "a sign from the sky"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to test him

The Pharisees tried to test Jesus to make him prove that he was from God. Some information can be made explicit. AT: "to prove that God had sent him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He sighed deeply in his spirit

This means that he groaned or that he let out a long deep breath that could be heard. It probably shows Jesus' deep sadness that the Pharisees refused to believe him.  See how you translated this in [Mark 7:34](../07/33.md).

#### in his spirit

"in himself"

#### Why does this generation seek for a sign?

Jesus is scolding them. This question may be written as a statement. AT: "This generation should not seek a sign." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### this generation

When Jesus speaks of "this generation," he is referring to the people who lived at that time. There Pharisees are included in this group. AT: "you and the people of this generation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no sign will be given

This can be stated in active form. AT: "I will not give a sign" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he left them, got into a boat again

Jesus' disciples went with him. Some information can be made explicit. AT: "he left them, got into a boat again with his disciples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to the other side

This describes the Sea of Galilee, which can be stated clearly. AT: "to the other side of the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]

### Mark 08:14

#### Connecting Statement:

While Jesus and his disciples are in a boat, they have a discussion about the lack of understanding among the Pharisees and Herod, though they had seen many signs.

#### Now

This word is used here to mark a break in the main story line. Here the author tells background information about the disciples forgetting to bring bread. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### no more than one loaf

The negative phrase "no more" is used to emphasize how small an amount of bread they had. AT: "only one loaf" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Keep watch and be on guard

These two terms have a common meaning and are repeated here for emphasis. They can be combined. AT: "Keep watch" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### yeast of the Pharisees and the yeast of Herod

Here Jesus is speaking to his disciples in a metaphor they do not understand. Jesus is comparing the Pharisees' and Herod's teachings to yeast, but you should not explain this when you translate it because the disciples themselves did not understand it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md)]]

### Mark 08:16

#### It is because we have no bread

In this statement, it may be helpful to state that "it" refers to what Jesus had said. AT: "He must have said that because we have no bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no bread

The word "no" is an exaggeration. The disciples did have one loaf of bread ([Mark 8:14](./14.md)), but that was not much different from having no bread at all. AT: "very little bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Why are you reasoning about not having bread?

Here Jesus is mildly rebuking his disciples because they should have understood what he had been talking about. This can be written as a statement. AT: "You should not be thinking that I am talking about actual bread." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Do you not yet perceive? Do you not understand?

These questions have the same meaning and are used together to emphasize that they do not understand. This can be written as one question or as a statement. AT: "Do you not yet understand?" or "You should perceive and understand by now the things I say and do." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Have your hearts become so dull?

"Hearts" here is a metonym for "thoughts and intentions." AT: "Your thinking has become so dull!" and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]

### Mark 08:18

#### You have eyes, do you not see? You have ears, do you not hear? Do you not remember?

Jesus continues to mildly rebuke his disciples. These questions can be written as statements. AT: "You have eyes, but you do not understand what you see. You have ears, but you do not understand what you hear. You should remember." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the five thousand

This refers to the 5,000 people Jesus fed. AT: "the 5,000 people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### how many baskets full of broken pieces of bread did you take up

It may be helpful to state when they collected the baskets of pieces. AT: "how many baskets full of broken pieces of bread did you collect after everyone finished eating" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Mark 08:20

#### the four thousand

This refers to the 4,000 people Jesus fed. AT: "the 4,000 people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### how many basketfuls did you take up

It may be helpful to state when they collected these. AT: "how many baskets full of broken pieces of bread did you collect after everyone finished eating" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Do you not yet understand?

Jesus is mildly rebuking his disciples for not understanding. This can be written as a statement. AT: "You should understand by now the things I say and do." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

### Mark 08:22

#### Connecting Statement:

When Jesus and his disciples get out of their boat at Bethsaida, Jesus heals a blind man.

#### Bethsaida

This is a town on the northern shore of the Sea of Galilee. See how you translated the name of this town in [Mark 6:45](../06/45.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### to touch him

It may be helpful to state why they wanted Jesus to touch the man. AT: "to touch him in order to heal him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### When he had spit on his eyes ... he asked him

"When Jesus had spit on the man's eyes ... Jesus asked the man"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 08:24

#### He looked up

"The man looked up"

#### I see men who look like walking trees

The man sees men walking around, yet they are not clear to him, so he compares them to trees. AT: "Yes, I see people! They are walking around, but I cannot see them clearly. They look like trees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Then he again

"Then Jesus again"

#### and the man opened his eyes, his sight was restored

The phrase "his sight was restored" can be written in active form. AT: "restoring the man's sight, and then the man opened his eyes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]

### Mark 08:27

#### Connecting Statement:

Jesus and his disciples talk on their way to the villages of Caesarea Philippi about who Jesus is and what will happen to him.

#### They answered him and said

"They answered him, saying,"

#### John the Baptist

The disciples answer that this was who some people said Jesus was. This can be shown more clearly. AT: "Some people say that you are John the Baptist" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Others say ... others

The word "others" refers to other people. This refers to their responses to Jesus' question. AT: "Other people say you are ... other people say you are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesarea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesarea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### Mark 08:29

#### He asked them

"Jesus asked his disciples"

#### Jesus warned them not to tell anyone about him

Jesus did not want them to tell anyone that he was the Christ. This can be made more explicit. Also, this can also be written as a direct quote. AT: "Jesus warned them not to tell anyone that he is the Christ" or "Jesus warned them, 'Do not tell anyone that I am the Christ'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 08:31

#### Son of Man

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### would be rejected by the elders ... and after three days rise up

This can be stated in active form. AT: "that the elders and the chief priests and the scribes would reject him, and that men would kill him, and that after three days he would rise up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He said this clearly

"He said this in a way that was easy to understand"

#### began to rebuke him

Peter rebuked Jesus for saying the things he said would happen to the Son of Man. This can be made explicit. AT: "began to rebuke him for saying these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]

### Mark 08:33

#### Connecting Statement:

After rebuking Peter for his not wanting Jesus to die and rise, Jesus tells both his disciples and the crowd how to follow him.

#### Get behind me, Satan! You are not setting

Jesus means that Peter is acting like Satan because Peter is trying to prevent Jesus from accomplishing what God sent him to do. AT: "Get behind me, because you are acting like Satan! You are not setting" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Get behind me

"Get away from me"

#### follow me

Following Jesus here represents being one of his disciples. AT: "be my disciple" or "be one of my disciples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### must deny himself

"must not give in to his own desires" or "must forsake his own desires"

#### take up his cross, and follow me

"carry his cross and follow me." The cross represents suffering and death. Taking up the cross represents being willing to suffer and die. AT: "must obey me even to the point of suffering and dying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### follow me

Following Jesus here represents obeying him. AT: "obey me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]

### Mark 08:35

#### For whoever wants

"For anyone who wants"

#### life

This refers to both physical life and spiritual life.

#### for my sake and for the gospel

"because of me and because of the gospel." Jesus is talking about people who lose their lives because they follow Jesus and the gospel. This can be stated clearly. AT: "because he follows me and tells others the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### What does it profit a person to gain the whole world and then forfeit his life?

This can be written as a statement. AT: "Even if a person gains the whole world, it will not benefit him if he forfeits his life." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

##### to gain the whole world and then forfeit his life

This can also be expressed as a condition starting with the word "if." AT: "if he gains the whole world and then forfeits his life"

#### to gain the whole world

The words "the whole world" are an exaggeration for great riches. AT: "to gain everything he ever wanted" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### forfeit

To forfeit something is to lose it or to have another person take it away.

#### What can a person give in exchange for his life?

This can be written as a statement. AT: "There is nothing a person can give in exchange for his life." or "No one can give anything in exchange for his life." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### What can a person give

If in your language "giving" requires someone to receive what is given, "God" can be stated as the receiver. AT: "What can a person give to God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Mark 08:38

#### ashamed of me and my words

"Words" here is a metonym for all of Jesus' message. AT: "ashamed of me and my message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in this adulterous and sinful generation

Jesus speaks of this generation as "adulterous," meaning that they are unfaithful in their relationship with God. AT: "in this generation of people who have committed adultery against God and are very sinful" or "in this generation of people who are unfaithful to God and are very sinful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Son of Man

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### when he comes

"when he comes back"

#### in the glory of his Father

When Jesus returns he will have the same glory as his Father.

#### with the holy angels

"accompanied by the holy angels"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Mark 08:intro

#### Mark 08 General Notes ####

####### Special concepts in this chapter #######

######## Bread ########
Bread is a special image in this chapter. When Jesus miraculously provides bread for a large crowd of people, they would have thought about when God miraculously provided food for the people of Israel when they were in the wilderness. 

Yeast is the ingredient that causes bread to rise before it is baked. The scriptures use yeast as a metaphor for things that influence people. In this chapter, Jesus also uses this metaphor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## "Adulterous generation" ########
This is a common image in scripture used to represent a generation of God's people who were unfaithful to him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unfaithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unfaithful.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
Jesus uses many rhetorical questions in this chapter as a way of both teaching the disciples and of convicting the Pharisees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [Mark 8:17-21](./16.md))

####### Other possible translation difficulties in this chapter #######

######## The use of paradox ########

A paradox is a seemingly absurd statement, which appears to contradict itself, but it is not absurd. A paradox occurs in this chapter: "Whoever wants to save his life will lose it" ([Mark 8:35-37](./35.md)).

##### Links: #####

* __[Mark 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Mark 09

### Mark 09:01

#### Connecting Statement:

Jesus has just been talking to the people and his disciples about following him. Six days later, Jesus goes with three of his disciples up a mountain where his appearance temporarily changes to what he will look like one day in the kingdom of God.

#### He said to them

"Jesus said to his disciples"

#### the kingdom of God come with power

The kingdom of God coming represents God showing himself as king. AT: "God show himself with great power as king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### alone by themselves

The author uses the reflexive pronoun "themselves" here to emphasize that they were alone and that only Jesus, Peter, James, and John went up the mountain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### he was transfigured

This can be stated in active form. AT: "he appeared very different" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### before them

"in front of them"

#### radiantly brilliant

"shining" or "glowing." Jesus' garments were so white they were emitting or giving off light.

#### extremely

"very, very"

#### whiter than any bleacher on earth could bleach them

Bleaching describes the process of making natural white wool even whiter by using chemicals like bleach or ammonia. AT: "whiter than any person on earth could whiten them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]

### Mark 09:04

#### Elijah with Moses appeared

It may be helpful to state who these men are. AT: "two prophets who had lived long ago, Elijah and Moses, appeared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they were talking

The word "they" refers to Elijah and Moses.

#### Peter answered and said to Jesus

"Peter said to Jesus." Here the word "answered" is used to introduce Peter into the conversation. Peter was not answering a question.

#### it is good for us to be here

It is not clear whether "us" refers only to Peter, James, and John, or if it refers to everyone there, including Jesus, Elijah, and Moses. If you can translate so that both options are possible, do so. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### shelters

"tents." This refers to simple temporary dwellings.

#### For he did not know what to say, for they were terrified

This parenthetical sentence tells background information about Peter, James, and John. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### terrified

"very frightened" or "very afraid"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]

### Mark 09:07

#### came and overshadowed

"appeared and covered"

#### Then a voice came out of the cloud

Here "a voice came out" is a metonym for someone speaking. It can also be stated clearly who spoke. AT: "Then someone spoke from the cloud" or "Then God spoke from the cloud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### This is my beloved Son. Listen to him

God the Father expresses his love for his "beloved Son," the Son of God.

#### beloved Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### when they looked

Here "they" refers to Peter, James, and John.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 09:09

#### he commanded them to tell no one ... until the Son of Man had risen

This implies that he was permitting them to tell people about what they had seen only after he rose from being dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### risen from the dead ... rising from the dead

"risen from among the dead ... to rise from among the dead." This speaks of becoming alive again. The phrase "the dead" refers to "dead people" and is a metonym for death. AT: "risen from death ... rising from death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### So they kept the matter to themselves

Here "kept the matter to themselves" is an idiom that means they did not tell anyone about what they had seen. AT: "So they did not tell anyone about what they had seen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Mark 09:11

#### Connecting Statement:

Though Peter, James, and John wondered what Jesus might mean by "rising from the dead," they asked him instead about Elijah's coming.

#### They asked him

The word "they" refers to Peter, James, and John.

#### Why do the scribes say that Elijah must come first?

Prophecy foretold that Elijah would come again from heaven. Then the Messiah, who is the Son of Man, would come to rule and reign. The disciples are confused about how the Son of Man could die and rise again. AT: "Why do the scribes say that Elijah must come first before the Messiah comes?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Elijah does come first to restore all things

By saying this, Jesus affirms that Elijah would come first.

#### Why then is it written ... be despised?

Jesus uses this question to remind his disciples that the scriptures also teach that the Son of Man must suffer and be despised. This may be expressed as a statement. AT: "But I also want you to consider what is written about the Son of Man. The scriptures say that he must suffer many things and be hated." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### be despised

This may be stated in active form. AT: "people would hate him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they did whatever they wanted to him

It may be helpful to state what people did to Elijah. AT: "our leaders treated him very badly, just as they wanted to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]

### Mark 09:14

#### Connecting Statement:

When Peter, James, John, and Jesus came down from the mountain, they found the scribes arguing with the other disciples.

#### When they came to the disciples

Jesus, Peter, James, and John returned to the other disciples who had not gone with them up the mountain.

#### they saw a great crowd around them

"Jesus and those three disciples saw a great crowd around the other disciples"

#### scribes were arguing with them

The scribes were arguing with the disciples who had not gone with Jesus.

#### was amazed

It may be helpful to state why they were amazed. AT: "was amazed that Jesus had come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 09:17

#### Connecting Statement:

To explain what the scribes and other disciples were arguing about, a father of a demon-possessed man tells Jesus that he has asked the disciples to send the demon out of his son, but they could not. Jesus then casts the demon out of the boy. Later the disciples ask why they were not able to send the demon away.

#### He has a spirit

This means the boy is possessed by an unclean spirit. "He has an unclean spirit" or "He is possessed by an unclean spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he foams at the mouth

A convulsion, or seizure, can cause a person to have trouble breathing or swallowing. This causes white foam to come out of the mouth. If your language has a way to describe that, you could use it. AT: "bubbles come out of his mouth"

#### he becomes rigid

"he becomes stiff" or "his body becomes rigid"

#### they could not

This refers to the disciples not being about to drive the spirit out of the boy. AT: "they could not drive it out of him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### He answered them

Though it was the boy's father who made a request of Jesus, Jesus responds to the whole crowd. This can be made clear. AT: "Jesus responded to the crowd" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Unbelieving generation

"You unbelieving generation." Jesus calls the crowd this, as he begins to respond to them.

#### how long will I have to stay with you? ... bear with you?

Jesus uses these questions to express his frustration. Both questions have the same meaning. They can be written as statements. AT: "I have become weary by your unbelief!" or "Your unbelief tires me! I wonder how long I must bear with you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### bear with you

"endure you" or "put up with you"

#### Bring him to me

"Bring the boy to me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Mark 09:20

#### spirit

This refers to the unclean spirit. See how you translated this in [Mark 9:17](./17.md).

#### convulsion

This is a condition where a person has no control over his body, and his body shakes violently.

#### Since childhood

"Since he was a small child." It may be helpful to state this as a full sentence. AT: "He has been like this since he was a small child" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### have pity

"have compassion"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Mark 09:23

#### 'If you are able'?

Jesus repeated what the man had said to him. AT: "Do you say to me 'If you are able'?" or "Why do you say 'If you are able'?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### 'If you are able'?

Jesus used this question to rebuke the man's doubt. It can be expressed as a statement. AT: "You should not say to me, 'If you are able.'" or "You ask me if I am able. Of course I am able." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### All things are possible for the one who believes

"God can do anything for people who believe in him"

#### for the one

"for the person" or "for anyone"

#### believes

This refers to belief in God. AT: "believes in God"

#### Help my unbelief

The man is asking Jesus to help him overcome his unbelief and increase his faith. AT: "Help me when I do not believe" or "Help me have more faith"

#### the crowd running to them

This means that more people were running toward where Jesus was and that the crowd there was growing larger.

#### You mute and deaf spirit

The words "mute" and "deaf" can be explained. AT: "You unclean spirit, you who are causing the boy to be unable to speak and unable to hear"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Mark 09:26

#### It cried out

"The unclean spirit cried out"

#### convulsed the boy greatly

"shook the boy violently"

#### came out

It is implied that the spirit came out of the boy. AT: "came out of the boy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The boy looked like one who was dead

The boy's appearance is compared to that of a dead person. AT: "The boy appeared dead" or "The boy looked like a dead person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### so that many

"so that many people"

#### took him by the hand

This means that Jesus grasped the boy's hand with his own hand. AT: "grasped the boy by the hand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### lifted him up

"helped him get up"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Mark 09:28

#### privately

This means they were alone.

#### cast it out

"cast the unclean spirit out." This refers to casting the spirit out of the boy. AT: "cast the unclean spirit out of the boy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### This kind cannot be cast out except by prayer

The words "cannot" and "except" are both negative words. In some languages it is more natural to use a positive statement. AT: "This kind can be cast out only by prayer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### This kind

This describes unclean spirits. AT: "This kind of unclean spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Mark 09:30

#### Connecting Statement:

After he heals the demon-possessed boy, Jesus and his disciples leave the house where they are staying. He takes time to teach his disciples alone.

#### They went out from there

"Jesus and his disciples left that region"

#### passed through

"traveled through" or "passed by"

#### for he was teaching his disciples

Jesus was teaching his disciples privately, away from the crowd. This can be stated clearly. AT: "for he was teaching his disciples privately" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The Son of Man

Here Jesus refers to himself as the Son of Man. This is an important title for Jesus. "I, the Son of Man," (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### will be delivered

"Delivered" here is a metaphor for "taken to." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### into the hands of men

Here "hands" is a metonym for control. AT: "into the control of men" or "to the control of men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### When he has been put to death, after three days he

This can be stated in active form. AT: "After they have put him to death and three days have passed, he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they were afraid to ask him

They were afraid to ask Jesus what his statement meant. AT: "they were afraid to ask him what it meant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Mark 09:33

#### Connecting Statement:

When they come to Capernaum, Jesus teaches his disciples about being humble servants. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### they came to

"they arrived at." The word "they" refers to Jesus and his disciples.

#### discussing

"discussing with one another"

#### they were silent

They were silent because they were ashamed to tell Jesus what they had been discussing. AT: "they were silent because they were ashamed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who was the greatest

Here "the greatest" refers to "the greatest" among the disciples. AT: "who was the greatest among them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If anyone wants to be first, he must be last of all

Here the words "first" and "last" are opposites of one another. Jesus speaks of being the "most important" as being "first" and of being the "least important" as being "last." AT: "If anyone wants God to consider him to be the most important person of all, he must consider himself to be the least important of all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### of all ... of all

"of all people ... of all people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Mark 09:36

#### in their midst

"among them." The word "their" refers to the crowd.

#### He took him in his arms

This means that he hugged the child or picked him up and placed him on his lap.

#### such a child

"a child like this"

#### in my name

This means to do something because of love for Jesus. AT: "because he loves me" or "for my sake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the one who sent me

This refers to God, who has sent him to earth. AT: "God, who has sent me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### Mark 09:38

#### John said to him

"John said to Jesus"

#### driving out demons

"sending away demons." This refers to casting demons out of people. AT: "driving demons out of people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in your name

Here "name" is associated with Jesus' authority and power. AT: "by the authority of your name" or "by the power of your name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he does not follow us

This means that he is not among their group of disciples. AT: "he is not one of us" or "he does not walk with us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Mark 09:40

#### is not against us

"is not opposing us"

#### is for us

It can be explained clearly what this means. AT: "is trying to achieve the same goals that we are"

#### gives you a cup of water to drink because you belong to Christ

Jesus speaks about giving someone a cup of water as an example of how one person may help another. This is a metaphor for helping someone in any way. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### not lose

This negative sentence emphasizes the positive meaning. In some languages, it is more natural to use a positive statement. AT: "definitely receive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]

### Mark 09:42

#### millstone

a large, round stone used for grinding grain into flour

#### If your hand causes you to stumble

Here "hand" is a metonym for desiring to do something sinful that you would do with your hand. AT: "If you want to do something sinful with one of your hands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to enter into life maimed

"to be maimed and then to enter into life" or "to be maimed before entering into life"

#### to enter into life

Dying and then beginning to live eternally is spoken of as entering into life. AT: "to enter into eternal life" or "to die and begin to live forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### maimed

missing a body part as a result of having it removed or being injured. Here it refers to missing a hand. AT: "without a hand" or "missing a hand"

#### into the unquenchable fire

"where the fire cannot be put out"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]

### Mark 09:45

#### If your foot causes you to stumble

Here the word "foot" is a metonym for desiring to do something sinful that you would do with your feet, such as going to a place you should not go to. AT: "If you want to do something sinful with one of your feet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to enter into life lame

"to be lame and then to enter into life" or "to be lame before entering into life"

#### to enter into life

Dying and then beginning to live eternally is spoken of as entering into life. AT: "to enter into eternal life" or "to die and begin to live forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lame

"unable to walk easily." Here it refers not being able to walk well because of missing a foot. AT: "without a foot" or "missing a foot"

#### be thrown into hell

This can be stated in active form. AT: "for God to throw you into hell" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]

### Mark 09:47

#### If your eye causes you to stumble, tear it out

Here the word "eye" is a metonym for either 1) desiring to sin by looking at something. AT: "If you want to do something sinful by looking at something, tear your eye out" or 2) Desiring to sin because of what you have looked at. AT: "If you want to do something sinful because of what you look at, tear your eye out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to enter into the kingdom of God with one eye than to have two eyes

This refers to the state of a person's physical body when he dies. A person does not take his physical body with him into eternity. AT: "to enter into the kingdom of God after having lived on earth with only one eye than to have lived on earth with two eyes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to be thrown into hell

This can be stated in the active form. AT: "for God to throw you into hell" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### where their worm does not die

The meaning of this statement can be made explicit. AT: "where worms that eat people there do not die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]

### Mark 09:49

#### everyone will be salted with fire

This can be stated in active form. AT: "God will salt everyone with fire" or "Just as salt purifies a sacrifice, God will purify everyone by allowing them to suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will be salted with fire

Here "fire" is a metaphor for suffering, and putting salt on people is a metaphor for purifying them. So "will be salted with fire" is a metaphor for being purified through suffering. AT: "will be made pure in the fire of suffering" or "will suffer in order to be purified as a sacrifice is purified with salt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### its saltiness

"its salty taste"

#### how can you make it salty again?

This can be written as a statement. AT: "you cannot make it salty again." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### salty again

"taste salty again"

#### Have salt among yourselves

Jesus speaks of doing good things for one another as if good things were salt that people possess. AT: "Do good to each other, like salt adds flavor to food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Mark 09:intro

#### Mark 09 General Notes ####

####### Special concepts in this chapter #######

######## Transfiguration ########

The glory of God is seen as a great, brilliant light in scripture. God's grandeur always produces fear in the person who sees it. Such an event is presented in this chapter. It is called the "transfiguration" because Jesus is changed or transfigured and he shows some of his divine glory. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]) 

####### Important figures of speech in this chapter #######

######## "It would be better" ########

This phrase introduces teachings that are intended to be taken as hyperbole. Otherwise, the church would be full of people without any hands. It is best to ensure your readers know these instructions are general principles not to be taken literally. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [Mark 9:42-48](./42.md))

####### Other possible translation difficulties in this chapter #######

######## Elijah and Moses ########
Elijah and Moses suddenly appear to Jesus, James, John, and Peter, and then they disappear. The translator may ask: is this a vision or did they actually appear to these men in physical form? Because all four of them saw Elijah and Moses, and because Elijah and Moses spoke with JEsus, it is best to translate this passage in a way that implies that Elijah and Moses appeared physically.

######## "Son of Man" ########
Jesus refers to himself as the "Son of Man" in this passage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Paradox ########

A paradox is a seemingly absurd statement, which appears to contradict itself, but it is not absurd. For example, "If anyone wants to be first, he must be last of all and servant of all." (See: [Mark 9:35](./33.md))

##### Links: #####

* __[Mark 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Mark 10

### Mark 10:01

#### Connecting Statement:

After Jesus and his disciples leave Capernaum, Jesus reminds the Pharisees, as well as his disciples, what God really expects in marriage and divorce.

#### Jesus left that place

Jesus' disciples were traveling with him. They were leaving Capernaum. AT: "Jesus and his disciples left Capernaum" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### and to the area beyond the Jordan River

"and to the land on the other side of the Jordan River" or "and to the area east of the Jordan River"

#### He was teaching them again

The word "them" refers to the crowds.

#### he was accustomed to do

"was his custom" or "he usually did"

#### What did Moses command you

Moses gave the law to their ancestors, which they now were also supposed to follow. AT: "What did Moses command your ancestors about this"

#### a certificate of divorce

This was a paper saying that the woman was no longer his wife.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divorce.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divorce.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Mark 10:05

#### "It was because ... this law," Jesus said to them. "But

In some languages speakers do not interrupt a quote to say who is speaking. Rather they say who is speaking at the beginning or end of the complete quote. AT: "Jesus said to them, 'It was because ... this law. But" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-quotations.md)]])

#### your hard hearts that he wrote you this law

Long before this time, Moses wrote this law for the Jews and their descendants because they had hard hearts. The Jews of Jesus' time also had hard hearts, so Jesus included them by using the words "your" and "you." AT: "because your ancestors and you had hard hearts that he wrote this law"

#### your hard hearts

"Hearts" here is a metonym for "thoughts and intentions. AT: "your stubbornness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### God made them male and female

Jesus quoted this from what God said in the book of Genesis.

#### God made them

"God made people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Mark 10:07

#### For this reason a man ... one flesh

Jesus continues to quote what God said in the book of Genesis.

#### For this reason

"Therefore" or "Because of this"

#### be united to his wife

"join with his wife"

#### they are no longer two, but one flesh

This is a metaphor to illustrate their close union as husband and wife. AT: "the two people are like one person" or "they are no longer two, but together they are one body" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Therefore what God has joined together, let no man tear apart

The phrase "what God has joined together" refers to any married couple. AT: "Therefore since God has joined together husband and wife, let no one tear them apart" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Mark 10:10

#### When they were

"When Jesus and his disciples were"

#### were in the house

Jesus' disciples were speaking to him privately. AT: were alone in the house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### asked him again about this

The word "this" refers to the conversation that Jesus had just had with the Pharisees about divorce.

#### Whoever

"Anyone who"

#### commits adultery against her

Here "her" refers to the first woman he was married to.

#### she commits adultery

In this situation she commits adultery again her previous husband. AT: "she commits adultery against him" or "she commits adultery against the first man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divorce.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divorce.md)]]

### Mark 10:13

#### Connecting Statement:

When the disciples rebuke the people for bringing their little children to Jesus, he blesses the children and reminds the disciples that people must be as humble as a child to enter the kingdom of God.

#### Then they brought

"Now people were bringing." This is the next event in the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### he might touch them

This means that Jesus would touch them with his hands and bless them. AT: "he might touch them with his hands and bless them" or "he might lay his hands on them and bless them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### rebuked them

"rebuked the people"

#### Jesus noticed it

The word "it" refers to the disciples rebuking the people who were bringing the children to Jesus.

#### was very displeased

"became angry"

#### Permit the little children to come to me, and do not forbid them

These two clauses have similar meanings, repeated for emphasis. In some languages it is more natural to emphasize this in another way. AT: "Be sure to allow the little children to come to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### do not forbid

This is a double negative. In some languages it is more natural to use a positive statement. AT: "allow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### for the kingdom of God belongs to those who are like them

The kingdom belonging to people represents the kingdom including them. AT: "the kingdom of God includes people who are like them" or "because only people like them are members of the kingdom of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]

### Mark 10:15

#### whoever will not receive ... child will definitely not enter it

"if anyone will not recieve ... child, he will definitely not enter it"

#### as a little child

Jesus is comparing how people must receive the kingdom of God to how little children would receive it. AT: "in the same manner as a child would" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### will not receive the kingdom of God

"will not accept God as their king"

#### definitely not enter it

The word "it" refers to the kingdom of God.

#### he took the children into his arms

"he hugged the children"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Mark 10:17

#### to inherit eternal life

Here the man speaks of "receiving" as if it were "inheriting." This metaphor is used to emphasize the importance of receiving. Also, "inherit" here does not mean that someone has to die first. AT: to receive eternal life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Why do you call me good?

Jesus asks this question to remind the man that no man is good the way God is good. AT: "You do not understand what you are saying when you call me good." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### good except God alone

"good. Only God is good"

#### do not testify falsely

"do not testify falsely against anyone" or "do not lie about someone in court"

#### honor

"respect and obey"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Mark 10:20

#### One thing you lack

"There is one thing you are missing." Here "lack" is a metaphor for needing to do something. AT: "One thing you need to do" or "There is one thing you have not yet done" or  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### give it to the poor

Here the word "it" refers to the things he sells and is a metonym for the money he receives when he sells them. AT: "give the money to the poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the poor

This refers to poor people. AT: "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### treasure

"riches"

#### had many possessions

"owned many things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Mark 10:23

#### How difficult it is

"It is very difficult"

#### Jesus said to them again

"Jesus said to his disciples again"

#### Children, how

"My children, how." Jesus is teaching them as a father would teach his children. AT: "My friends, how" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### how hard it is

"it is very hard"

#### It is easier ... kingdom of God

Jesus uses an exaggeration to emphasize how very difficult it is for rich people to get into the kingdom of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### It is easier for a camel

This speaks of an impossible situation. If you cannot state this in this way in your language, it can be written as a hypothetical situation. AT: "It would be easier for a camel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### the eye of a needle

"the hole of a needle." This refers to the small hole in the end of a sewing needle that thread passes through.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]

### Mark 10:26

#### They were

"The disciples were"

#### Then who can be saved?

This can be written as a statement. AT: "If that is so, then no one will be saved!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### With people it is impossible, but not with God

The understood information may be supplied. AT: "It is impossible for people to save themselves, but God can save them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Look, we have left everything and have followed you

Here the word "Look" is used to draw attention to the words that come next. Similar emphasis can be expressed in other ways. AT: "We have left everything and have followed you"

#### have left everything

"have left everything behind"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]

### Mark 10:29

#### there is no one who has left ... who will not receive

This can be stated positively. AT: "Everyone who has left ... will receive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### lands

"plots of ground"

#### for my sake

"for my cause" or "for me"

#### for the gospel

"to proclaim the gospel"

#### this world

"this life" or "this present age"

#### brothers, and sisters, and mothers, and children

Like the list in verse 29, this describes the family in general. The word "fathers" is missing in verse 30, but it does not significantly change the meaning.

#### with persecutions, and in the world to come, eternal life

This can be reworded so that the ideas in the abstract noun "persecution" are expressed with the verb "persecute." Because the sentence is so long and complicated, "will receive" can be repeated. AT: "and even though people persecute them, in the world to come, they will receive eternal life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnoun.md)]])

#### in the world to come

"in the future world" or "in the future

#### are first will be last, and the last first

Here the words "first" and "last" are opposites of one another. Jesus speaks of being the "important" as being "first" and of being the "unimportant" as being "last." AT: "are important will be unimportant, and those who are unimportant will be important" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the last first

The phrase "the last" refers to people who are "last." Also, the understood verb in this clause may be supplied. AT: "those who are last will be first" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Mark 10:32

#### They were on the road ... and Jesus was going ahead of them

"Jesus and his disciples were walking on the road ... and Jesus was in front of his disciples"

#### those who were following behind

"those who were following behind them." Some people were walking behind Jesus and his disciples.

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you"

#### the Son of Man will

Jesus is speaking about himself. This can be stated clearly. AT: "I, the Son of Man, will" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Son of Man will be delivered to

This can be stated in active form. AT: "someone will deliver the Son of Man to" or "they will hand the Son of Man over to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They will condemn

The word "They" refers to the chief priests and the scribes.

#### deliver him

"taken to" or "hand him over to." This means Jesus will be given over to the control of the Gentiles. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They will mock

"People will mock"

#### put him to death

"kill him"

#### he will rise

This refers to rising from the dead. AT: "he will rise from being dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Mark 10:35

#### we ... us

These words refer only to James and John. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### in your glory

"when you are glorified." The phrase "in your glory" refers to when Jesus is glorified and rules over his kingdom. AT: "when you rule in your kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]

### Mark 10:38

#### You do not know

"You do not understand"

#### drink the cup which I will drink

Here "cup" refers to what Jesus must suffer. Suffering is often referred to as drinking from a cup. AT: "drink the cup of suffering that I will drink" or "drink from the cup of suffering that I will drink from" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### endure the baptism with which I will be baptized

Here "baptism" and being baptized represent suffering. Just as water covers a person during baptism, suffering will overwhelm Jesus. AT: "endure the baptism of suffering which I will suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We are able

They respond this way, meaning that they are able to drink the same cup and endure the same baptism. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### you will drink

"you will drink as well"

#### But who is to sit at my right hand ... is not mine to give

"But I am not the one who allows people to sit at my right hand or my left hand"

#### but it is for those for whom it has been prepared

"but those places are for those for whom they have been prepared." The word "it" refers to the places to his right hand and to his left hand.

#### it has been prepared

This can be stated in active form. AT: "God has prepared it" or "God has prepared them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Mark 10:41

#### heard about this

The word "this" refers to James and John asking to sit at Jesus' right and left hands.

#### Jesus called them

"Jesus called his disciples"

#### those who are considered rulers of the Gentiles

This can be stated in active form. AT: "those whom the people consider to be the rulers of the Gentiles" or "those who rule over the Gentiles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### considered

"recognized as"

#### dominate

"have control of" or "have power over"

#### exercise authority

"flaunt their authority." This means that they show or use their authority in an overbearing way.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofzebedee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Mark 10:43

#### But it shall not be this way among you

This refers back to the previous verse about the Gentile rulers. This can be stated clearly. AT: "But do not be like them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### become great

"be highly respected"

#### to be first

This is a metaphor for being the most important. AT: "to be the most important" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For the Son of Man did not come to be served

This can be translated in active form. AT: "For the Son of Man did not come to have people serve him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to be served, but to serve

"to be served by people, but to serve people"

#### for many

"for many people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md)]]

### Mark 10:46

#### Connecting Statement:

As Jesus and his disciples continue walking toward Jerusalem, Jesus heals blind Bartimaeus, who then walks with them.

#### the son of Timaeus, Bartimaeus, a blind beggar

"a blind beggar named Bartimaeus, the son of Timaeus." Bartimaeus is the name of a man. Timaeus is his father's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### When he heard that it was Jesus

Bartimaeus heard people saying that it was Jesus. AT: "When he heard people saying that it was Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Son of David

Jesus is called the Son of David because he is a descendant of King David. AT: "You who are the Messiah descended from King David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Many rebuked

"Many people rebuked"

#### all the more

"even more"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### Mark 10:49

#### commanded him to be called

This can be translated in active form or as as a direct quote. AT: "commanded others to call him" or "commanded them, 'Call him to come over here.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### They called

The word "They" refers to the crowd.

#### brave

"courageous"

#### He is calling for you

"Jesus is calling for you"

#### sprang up

"jumped up"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]

### Mark 10:51

#### answered him

"answered the blind man"

#### to receive my sight

"to be able to see"

#### Your faith has healed you

This phrase is written this way to place emphasis on the man's faith. Jesus heals the man because he believes that Jesus can heal him. This can be made explicit. AT: "I am healing you because you believed in me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he followed him

"he followed Jesus"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Mark 10:intro

#### Mark 10 General Notes ####

####### Structure and Format #######

Some translations indent quotations from the Old Testament. The ULB does this with the quoted material in 10:7-8.

####### Special concepts in this chapter #######

######## Jesus' teaching about divorce ########

In this chapter, Jesus teaches about divorce in response to a challenge from the Pharisees. Jesus bases his teaching on God's original intentions in creating marriage. Jesus  shows the mistakes the religious leaders made in their traditions about marriage. 

####### Important figures of speech in this chapter #######

######## Metaphors ########
There are many metaphors in this chapter. Jesus uses them in his teaching to explain difficult issues. He also uses metaphors to conceal the truth about his death because it has not yet occurred. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## Paradox ########

A paradox is a seemingly absurd statement, which appears to contradict itself, but it is not absurd. For example, "Whoever wishes to become great among you must be your servant." (See: [Mark 10:43](./43.md))

##### Links: #####

* __[Mark 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Mark 11

### Mark 11:01

#### Now as they came to Jerusalem ... Bethphage and Bethany, at the Mount of Olives

"When Jesus and his disciples came near to Jerusalem, they came to Bethphage and Bethany near the Mount of Olives" They have come to Bethphage and Bethany in the vicinity of Jerusalem.

#### Bethphage

This is the name of a village. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### opposite us

"ahead of us"

#### a colt

This refers to a young donkey that is large enough to carry a man.

#### that has never been ridden

This can be written in active form. AT: "that no one has ever ridden" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Why are you doing this

It can be written clearly what the word "this" refers to. AT: "Why are you untying and taking the colt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### has need of it

"needs it"

#### will immediately send it back here

Jesus will send it back promptly when he is finished using it. AT: "will immediately send it back when he no longer needs it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Mark 11:04

#### They went

"The two disciples went"

#### colt

This refers to a young donkey that is large enough to carry a man. See how you translated this in [Mark 11:2](./01.md).

#### They spoke

"They responded"

#### as Jesus told them

"as Jesus had told them to respond." This refers to how Jesus had told them to respond to people's questions about taking the colt.

#### let them go their way

This means that they allowed them to continue doing what they were doing. AT: "let them take the donkey with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Mark 11:07

#### threw their cloaks on it so Jesus could ride it

"laid their cloaks on its back so Jesus could ride it." It is easier to ride a colt or a horse when there is a blanket or something similar on its back. In this case, the disciples threw their cloaks on it.

#### cloaks

"coats" or "robes"

#### Many people spread their garments on the road

It was a tradition to lay garments on the road in front of important people to honor them. This can be made explicit. AT: "Many people spread their garments on the road to honor him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### others spread branches they had cut from the fields

It was a tradition to lay palm branches on the road in front of an important people to honor them. AT: "others spread branches on the road that they had cut from the fields, also to honor him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who followed

"who followed him"

#### Hosanna

This word means "save us," but people also shouted it joyfully when they wanted to praise God. You can translate it according to how it was used, or you can write "Hosanna" using your language's way of spelling that word. AT: "Praise God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### Blessed is the one

This is referring to Jesus. This can be stated clearly. AT: "Blessed are you, the one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in the name of the Lord

This is a metonym for the Lord's authority. AT: "the authority of the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Blessed is the coming kingdom of our father David

"Blessed is our father David's coming kingdom." This refers to Jesus coming and ruling as king. The word "blessed" can be translated as an active verb. AT: "Blessed be the coming of your kingdom" or "May God bless you as you rule your coming kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Blessed is

"May God bless"

#### of our father David

Here David's descendant who will rule is referred to as David himself. AT: "of the greatest descendant of our father David" or "that David's greatest descendant will rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Hosanna in the highest

Possible meanings are 1) "Praise God who is in heaven" or 2) "Let those who are in heaven shout 'Hosanna'."

#### the highest

Here heaven is spoken of as "the highest." AT: "the highest heaven" or "heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]

### Mark 11:11

#### the time being late

"because it was late in the day"

#### he went out to Bethany with the twelve

"he and his twelve disciples left Jerusalem and went to Bethany"

#### when they returned from Bethany

"while they were going back to Jerusalem from Bethany"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]

### Mark 11:13

#### Connecting Statement:

This happens while Jesus and his disciples are walking to Jerusalem.

#### if he could find any fruit on it

"if there was any fruit on it"

#### he found nothing but leaves

This means that he did not find any figs. AT: "he found only leaves and no figs on the tree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### the season

"the time of year"

#### He spoke to it, "No one will ever eat fruit from you again

Jesus speaks to the fig tree and curses it. He speaks to it so that his disciples hear him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### He spoke to it

"He spoke to the tree"

#### his disciples heard it

The word "it" refers to Jesus speaking to the fig tree.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### Mark 11:15

#### They came

"Jesus and his disciples came"

#### began to cast out the sellers and the buyers in the temple

Jesus is driving these people out of the temple. This can be written clearly. AT: "began to drive the sellers and buyers out of the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the sellers and the buyers

"the people who were buying and selling"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]

### Mark 11:17

#### General Information:

God had said earlier in his word, through the prophet Isaiah, that his temple would be a house of prayer for all the nations.

#### Is it not written, 'My house will be called ... the nations'?

Jesus is rebuking the Jewish leaders for their misuse of the temple. This can be written as a statement. AT: "It is written in the scriptures that God said, 'I want my house to be called a house where people from all nations may pray.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### But you have made it a den of robbers

Jesus compares the people to robbers and the temple to a robbers' den. AT: "But you are like robbers who have made my house into a robbers' den" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a den of robbers

"a cave where robbers hide"

#### they looked for a way

"they were seeking a way"

#### When evening came

"In the evening"

#### they left the city

"Jesus and his disciples left the city"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md)]]

### Mark 11:20

#### Connecting Statement:

Jesus uses the example of the fig tree to remind the disciples to have faith in God.

#### walked by

"were walking along the road"

#### the fig tree withered away to its roots

Translate this statement to clarify that the tree died. AT: "the fig tree withered away down to its roots and died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### withered away

"dried up"

#### Peter remembered

It may be helpful to state what Peter remembered. AT: "Peter remembered what Jesus had said to the fig tree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Mark 11:22

#### Jesus answered them

"Jesus replied to his disciples"

#### Truly I say to you

"I tell you the truth." This phrase adds emphasis to what Jesus says next.

#### whoever says

"if anyone says"

#### if he does not doubt in his heart but believes

Here "not doubt" is a double negative meaning "truly believe" and "heart" is a metonym for "inner thoughts and intentions." Jesus says it both ways for emphasis. AT: "if he truly believes in his heart" or "if he does not doubt but believes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### God will do

"God will make happen"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Mark 11:24

#### Therefore I say to you

"So I tell you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]])

#### it will be yours

It is understood that this will happen because God will provide what you ask for. This can be stated clearly. AT: "God will give it to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### When you stand and pray

It is common in Hebrew culture to stand when praying to God. AT: "When you pray"

#### whatever you have against anyone

"whatever grudge you have against anyone." Here the word "whatever" refers to any grudge you hold against someone for sinning against you or any anger you have against someone.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]

### Mark 11:27

#### Connecting Statement:

The next day when Jesus returns to temple, he gives the chief priests, scribes, and elders an answer to their question about his casting the money changers out of the temple area, by asking them another question, which they were not willing to answer.

#### They came to

"Jesus and his disciples came to"

#### Jesus was walking in the temple

This means that Jesus was walking around inside of the temple; he was not walking into the temple.

#### They said to him

The word "They" refers to the chief priests, the scribes, and the elders.

#### By what authority do you do these things, and who gave you the authority to do them?

Possible meanings: 1) Both of these questions have the same meaning and are asked together to strongly question Jesus' authority and so can be combined. AT: "Who gave you authority to do these things?" 2) They are two separate questions, the first asking about the nature of the authority and the second about who gave it to him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### you do these things

The words "these things" refer to Jesus turning over the sellers' tables in the temple and speaking against what the chief priests and scribes taught. AT: "things like those you did here yesterday" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Mark 11:29

#### Tell me

"Answer me"

#### The baptism of John

"The baptism that John performed"

#### was it from heaven or from men

"was it authorized by heaven or by men"

#### from heaven

Here "heaven" refers to God. AT: "from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from men

"from people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Mark 11:31

#### If we say, 'From heaven,'

This refers to the source of the baptism of John. AT: "If we say, 'It was from heaven,'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### From heaven

Here "heaven" refers to God. See how you translated this in [Mark 11:30](./29.md). AT: "From God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### not believe him

The word "him" refers to John the Baptist.

#### But if we say, 'From men,'

This refers to the source of the baptism of John. AT: "But if we say, 'It was from men,'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### From men

"From people"

#### But if we say, 'From men,' ... .

The religious leaders imply that they will suffer from the people if they give this answer. AT: "But if we say, 'From men,' that would not be good." or "But we do not want to say that it was from men." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### They were afraid of the people

The author, Mark, explains why the religious leaders did not want to say that John's baptism was from men. This can be stated clearly. "They said this to each other because they were afraid of the people" or "They did not want to say that John's baptism was from men because they were afraid of the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### We do not know

This refers to the baptism of John. This understood information may be supplied. AT: "We do not know where the baptism of John came from" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Mark 11:intro

#### Mark 11 General Notes ####

####### Structure and Format #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 11:9-10, 17, which is quoted from the OT.

####### Special concepts in this chapter #######

######## Colt ########

The way in which Jesus entered Jerusalem, riding on an animal, was similar to the way a king would have entered a city after a great victory. And for the kings of Israel, it was traditional to ride on a donkey instead of on a horse. Matthew, Mark, Luke, and John all wrote about this event, but they did not all give the same details. Matthew wrote about there being both a donkey and a colt, but it is not clear which one Jesus rode on. It is best to translate each of these passages as it appears in the ULB without trying to make them all say exactly the same thing. (See:[Matthew 21:1-7](../../mat/21/01.md) and [John 12:14-15](../../jhn/12/14.md))

##### Links: #####

* __[Mark 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Mark 12

### Mark 12:01

#### Connecting Statement:

Jesus speaks this parable against the chief priests, the scribes, and the elders. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### Then Jesus began to teach them

The word "them" here refers to the chief priests, the scribes, and the elders to whom Jesus had been talking in the previous chapter.

#### put a hedge around it

He put a barrier around the vineyard. It could have been a row of shrubs, a fence, or a stone wall.

#### dug a pit for a winepress

This means that he carved a pit on the rock, which would be the bottom part of the winepress used for collecting the squeezed grape juice. AT: "carved a pit into rock for the winepress" or "he made a vat to collect the juice from the winepress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### leased the vineyard to vine growers

The owner still owned the vineyard, but he allowed the vine growers to take care of it. When the grapes became ripe, they were to give some of them to the owner and keep the rest.

#### At the right time

This refers to the time of harvest. This can be made clear. AT: "When the time came to harvest the grapes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### But they took him

"But the vine growers took the servant"

#### with nothing

This means that they did not give him any of the fruit. AT: "without any grapes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]

### Mark 12:04

#### he sent to them

"the owner of the vineyard sent to the vine growers"

#### they wounded him in the head

This can be written more clearly. AT: "they beat that one on the head, and they hurt him terribly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### yet another ... many others

These phrases refer to other servants. AT: "yet another servant ... many other servants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### They treated many others in the same way

This refers to servants that the owner sent. The phrase "in the same way" refers to them being mistreated. This can be written clearly. AT: "They also mistreated many other servants whom he sent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Mark 12:06

#### a beloved son

It is implied that this is the owner's son. AT: "his beloved son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the heir

This is the owner's heir, who would inherit the vineyard after his father died. AT: "the owner's heir" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the inheritance

The tenants are referring to the vineyard as "the inheritance." AT: "this vineyard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Mark 12:08

#### They seized him

"The vine growers seized the son"

#### Therefore, what will the owner of the vineyard do?

Jesus asks a question and then gives the answer to teach the people. The question may be written as a statement. AT: "So I will tell you what the owner of the vineyard will do." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Therefore

Jesus uses this word to show that he has finished telling the parable and is now asking the people what they think will happen next. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]])

#### destroy

kill

#### will give the vineyard to others

The word "others" refers to other vine growers who will care for the vineyard. AT: "he will give the vineyard to vine growers to care for it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]

### Mark 12:10

#### General Information:

This scripture was written long before in God's word.

#### Have you not read this scripture?

Jesus reminds the people of a scripture passage. He uses a rhetorical question here to rebuke them. This can be written as a statement. AT: "Surely you have read this scripture." or "You should remember this scripture." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### has been made the cornerstone

This can be stated in active form. AT: "the Lord made into the cornerstone"

#### This was from the Lord

"The Lord has done this"

#### it is marvelous in our eyes

Here "in our eyes" stands for seeing, which is a metaphor for the people's opinion. AT: "we have seen it and think that it is marvelous" or "we think that it is wonderful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They sought to arrest Jesus

"They" refers to the chief priests, scribes, and elders. This group may be referred to as the "Jewish leaders."

#### sought

"wanted"

#### but they feared the crowd

They were afraid of what the crowd would do to them if they arrested Jesus. This can be made clear. AT: "but they feared what the crowd would do if they arrested him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### against them

"to accuse them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cornerstone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cornerstone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]

### Mark 12:13

#### Connecting Statement:

In an effort to trap Jesus, some of the Pharisees and Herodians, and then the Sadducees, come to Jesus with questions.

#### Then they sent

"Then the Jewish leaders sent"

#### the Herodians

This was the name of an informal political party that supported Herod Antipas.

#### to trap him

Here the author describes tricking Jesus as "trapping him." AT: "to trick him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### When they came, they said

Here "they" refers to those sent from among the Pharisees and the Herodians.

#### you care for no one's opinion

This means that Jesus is not concerned. The negation can modify the verb instead. AT: "you do not care about people's opinions" or "you are not concerned with earning people's favor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Jesus knew their hypocrisy

They were acting hypocritically. This can be explained more clearly. AT: "Jesus knew that they did not really want to know what God wanted them to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Why do you test me?

Jesus rebukes the Jewish leaders because they were trying to trick him. This can be written as a statement. AT: "I know you are trying to make me say something wrong so you can accuse me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### denarius

This coin was worth a day's wages. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/herodantipas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]

### Mark 12:16

#### They brought one

"The Pharisees and the Herodians brought a denarius"

#### likeness and inscription

"picture and name"

#### They said, "Caesar's

Here "Caesar's" refers to his likeness and inscription. AT: "They said, 'They are Caesar's likeness and inscription" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Give to Caesar the things that are Caesar's

Jesus is teaching that his people must respect the government by paying taxes. This figure of speech can be clarified by changing Caesar to Roman government. AT: "Give to the Roman government the things that belong to the Roman government" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### and to God

The understood verb may be supplied. AT: "and give to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### They marveled at him

They were amazed at what Jesus had said. This can be made explicit. AT: "They marveled at him and at what he had said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 12:18

#### who say there is no resurrection

This phrase explains who the Sadducees were. This can be written more clearly. AT: "who say there is no resurrection from the dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Moses wrote for us, 'If a man's brother dies

The Sadducees are quoting what Moses had written in the law. Moses' quote can be expressed as an indirect quote. AT: "Moses wrote for us that if a man's brother dies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### wrote for us

"wrote for us Jews." The Sadducees were a group of Jews. Here they use the word "us" to refer to themselves and all Jews.

#### the man should take the brother's wife

"the man should marry his brother's wife"

#### raise up a descendant for his brother

"have a son for his brother." The man's first son would be considered to be the dead brother's son, and the son's descendants would be considered to be the dead brother's descendants. This can be stated clearly. AT: "have a son who will be considered to be the dead brother's son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sadducee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sadducee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Mark 12:20

#### There were seven brothers

The Sadducees propose a scenario to test Jesus. This is a hypothetical situation. AT: "Suppose there were seven brothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### the first ... the second ... the third

These numbers refer to each of the brothers and can be expressed as such. AT: "the first brother ... the second brother ... the third brother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### The seven

This refers to all the brothers. AT: "The seven brothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the first took a wife ... the second took her

"the first married a woman ... the second married her." Here marrying a woman is spoken of as "taking" her.

#### the third likewise

It may be helpful to explain what "likewise" means. AT: "the third brother married her as his other bothers did, and he also died leaving no children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The seven left no children

Each of the brothers married the woman and then died before he had any children with her. This can be stated clearly. AT: "Eventually all seven brothers married that woman one by one, but none of them had any children with her, and one by one they died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### In the resurrection, when they rise again, whose wife will she be?

The Sadducees are testing Jesus by asking this question. If your readers can only understand this as a request for information, this can be written as a statement. AT: "Now tell us whose wife she will be in the resurrection, when they all rise again." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Mark 12:24

#### Is this not the reason you are mistaken ... power of God?

Jesus rebukes the Sadducees because they are mistaken about God's law. This may be written as a statement. AT: "You are mistaken because ... power of God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### you do not know the scriptures

This means that they do not understand what is written in the Old Testament scriptures.

#### the power of God

"how powerful God is"

#### For when they rise

Here the word "they" refers to the brothers and the woman from the example.

#### rise

Waking and getting up from sleep is a metaphor for becoming alive after having been dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To rise from among them speaks of becoming alive again.

#### they neither marry nor are given in marriage

"they do not marry, and they are not given in marriage"

#### are given in marriage

This can be stated in active form. AT: "and no one gives them in marriage" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### heaven

This refers to the place where God lives.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Mark 12:26

#### that are raised

This can be expressed with an active verb. AT: "who rise" or "who rise to live again" [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Book of Moses

"the book that Moses wrote"

#### the account about the bush

This refers to the part of the Book of Moses that tells about when God spoke to Moses out of a bush that was burning but that did not burn up. AT: "the passage about the burning bush" or "the words about the fiery bush" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the bush

This refers to a shrub, a woody plant that is smaller than a tree.

#### how God spoke to him

"about when God spoke to Moses"

#### I am the God of Abraham ... Isaac ... Jacob

This means that Abraham, Isaac, and Jacob worship God. These men have died physically, but they are still alive spiritually and still worship God.

#### not the God of the dead, but of the living

Here "the dead" refers to people who are dead, and "the living" refers to people who are alive. Also, the words "the God" can be stated clearly in the second phrase. AT: "not the God of dead people, but the God of living people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the living

This includes people who are alive physically and spiritually.

#### You are quite mistaken

It may be helpful to state what they are mistaken about. AT: "When you say that dead people do not rise again, you are quite mistaken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### quite mistaken

"completely mistaken" or "very wrong"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]

### Mark 12:28

#### He asked him

"The scribe asked Jesus"

#### the most important of all ... The most important is

"The most important" refer to the most important commandment. AT: "the most important commandment of all ... The most important commandment says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### Hear, Israel, the Lord our God, the Lord is one

"Listen, O Israel! The Lord our God is one Lord"

#### with all your heart, with all your soul

The idiom "with all ... heart" means "completely" and "with all ... soul" means "with all ... being." See how you translated these two phrases in [Deuteronomy 4:29](../../deu/04/29.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### with all your mind

The mind is what people use to think.

#### love your neighbor as yourself

Jesus uses this simile to compare how people are to love each other with the same love as they love themselves. AT: "love your neighbor as much as you love yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### than these

Here the word "these" refers to the two commandments that Jesus had just told the people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Mark 12:32

#### Good, Teacher

"Good answer, Teacher" or "Well said, Teacher"

#### God is one

This means that there is only one God. AT: "there is only one God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### that there is no other

The word "God" is understood from the previous phrase. AT: "that there is no other God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### with all the heart ... all the understanding ... all the strength

"Heart" here is a metonym for "thoughts and intentions." AT: "in all that we want and feel, in all that we think, and in all that we do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to love one's neighbor as oneself

This simile compares how people are to love each other with the same love that they love themselves. AT: "to love your neighbor as much as you love yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### is even more than

This idiom means that something is more important than something else. In this case, these two commandments are more pleasing to God that burnt offering and sacrifices. This may be written clearly. AT: "is even more important than" or "is even more pleasing to God than" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### You are not far from the kingdom of God

This can be stated in positive form. Here Jesus speaks of the man being ready to submit to God as king as being physically close to the kingdom of God, as if it where a physical place. AT: "You are close to submitting to God as king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### no one dared

This can be stated in positive form. AT: "everyone was afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]

### Mark 12:35

#### While Jesus was teaching in the temple courts, he said

Some time has passed and Jesus is now in the temple. This is not part of the previous conversation. AT: "Later, while Jesus was teaching in the temple area, he said to the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### How is it that the scribes say the Christ is the son of David?

Jesus uses this question to get the people to think deeply about the Psalm he is about to quote. This can be written as a statement. AT: "Consider why the scribes say the Christ is the son of David." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the son of David

"a descendant of David"

#### David himself

This word "himself" refers to David and is used to place emphasis on him and what he said. AT: "It was David who" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### in the Holy Spirit

This means that he was inspired by the Holy Spirit. That is, the Holy Spirit directed David in what he said. AT: "inspired by the Holy Spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### said, 'The Lord said to my Lord

Here David calls God "The Lord" and calls the Christ "my Lord." This can be written more clearly. AT: "said about the Christ, 'The Lord God said to my Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Sit at my right hand

Jesus is quoting a psalm. Here God is speaking to the Christ. To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "Sit in the place of honor beside me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### until I make your enemies your footstool

In this quote, God speaks of defeating enemies as making them into a footstool. AT: "until I completely defeat your enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### calls him 'Lord,'

Here the word "him" refers to the Christ.

#### so how can the Christ be David's son?

This can be written as a statement. AT: "so consider how the Christ can be a descendant of David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/footstool.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/footstool.md)]]

### Mark 12:38

#### the greetings they receive in the marketplaces

The noun "greetings" can be expressed with the verb "greet." These greetings showed that the people respected the scribes. AT: "to be greeted respectfully in the marketplaces" or "people to greet them respectfully in the marketplaces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They also devour widows' houses

Here Jesus describes the scribes' cheating of widows and stealing of their houses as "devouring" their houses. AT: "They also cheat widows in order to steal their houses from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### widows' houses

The words "widows" and "houses" are synecdoches for helpless people and all of a person's important possessions, respectively. AT: "everything from helpless people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### These men will receive greater condemnation

This can be stated in active form. AT: "God will certainly punish them with greater condemnation" or "God will certainly punish them severely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will receive greater condemnation

The word "greater" implies a comparison. Here the comparison is to other men who are punished. AT: "will receive greater condemnation than other people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]

### Mark 12:41

#### Connecting Statement:

Still in the temple area, Jesus comments on the value of the widow's offering.

#### an offering box

This box, which everyone could use, held temple offerings.

#### two mites

"two small copper coins." These were the least valuable coins available. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### worth about a penny

"worth very little." A penny is worth very little. Translate "penny" with the name of the smallest coin in your language if you have one that is worth very little.

### Mark 12:43

#### General Information:

In verse 43 Jesus says that the widow put more money in the offering than the rich people put in, and in verse 44 he tells his reason for saying that. The information can be reordered so that Jesus tells his reason first and then says that the widow put in more, as in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md)]])

#### He called

"Jesus called"

#### Truly I say to you

This indicates that the statement that follows is especially true and important. See how you translated this in [Mark 3:28](../03/28.md).

#### all of them who contributed to

"all the other people who put money into"

#### abundance

"plenty." This refers to their wealth.

#### her poverty

"lack" or "the little she had"

#### to live on

"to survive on"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Mark 12:intro

#### Mark 12 General Notes ####

####### Structure and Format #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 12:10-11, 36, which is quoted from the OT.

####### Important figures of speech in this chapter #######

######## Hypothetical Situations ########
Jesus uses hypothetical situations when he tries to teach people. The Pharisees also use hypothetical situations to try to trap Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

##### Links: #####

* __[Mark 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Mark 13

### Mark 13:01

#### General Information:

As they leave the temple area, Jesus tells his disciples what will happen in the future to the wonderful temple that Herod the Great has built.

#### the wonderful stones and wonderful buildings

The "stones" refer to the stones that the buildings were built with. AT: "the wonderful buildings and the wonderful stones that they are made of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Do you see these great buildings? Not one stone

This question is used to draw attention to the buildings. This can be written as a statement. AT: "Look at these great buildings! Not one stone" or "You see these great buildings now, but not one stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Not one stone will be left on another which will not be torn down

It is implied that enemy soldiers will tear down the stones. This can be stated in active form. AT: "Not one stone will remain on top of another, for enemy soldiers will come and destroy these buildings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]

### Mark 13:03

#### Connecting Statement:

In answer to the disciples' questions about the temple's destruction and what was going to happen, Jesus tells them what was going to take place in the future.

#### As he sat on the Mount of Olives opposite the temple, Peter

It can be expressed clearly that Jesus and his disciples had walked to the Mount of Olives. AT: "After arriving at the Mount of Olives, which is opposite the temple, Jesus sat down. Then Peter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### privately

"when they were alone"

#### these things happen ... are about to happen

This refers to what Jesus had just said will happen to the stones of the temple. This can be made clear. AT: "these things happen to the buildings of the temple ... are about to happen to the temple buildings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### when all these things

"that all these things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofalphaeus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofalphaeus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]

### Mark 13:05

#### to them

"to his disciples"

#### leads you astray ... they will lead many astray

Here "leads ... astray" is a metaphor for persuading someone to believe what is not true. AT: "deceives you ... they will deceive many people" (See: [https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in my name

Possible meanings are 1) "claiming my authority" or 2) "claiming that God sent them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I am he

"I am the Christ"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]

### Mark 13:07

#### hear of wars and rumors of wars

"hear of wars and reports about wars." Possible meanings are 1) "hear the sounds of wars close by and news of wars far away" or 2) "hear of wars that have started and reports about wars that are about to start"

#### but the end is not yet

"but it is not yet the end" or "but the end will not happen until later" or "but the end will be later"

#### the end

This probably refers to the end of the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### will rise against

This idiom means to fight against one another. AT: "will fight against" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### kingdom against kingdom

The words "will rise" are understood from the previous phrase. AT: "kingdom will rise against kingdom" or "the people of one kingdom will fight against the people of another kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### These are the beginnings of birth pains

Jesus speaks of these disasters as the beginnings of birth pains because more severe things will happen after them. AT: "These events will be like the first pains a woman suffers when she is about to bear a child" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md)]]

### Mark 13:09

#### Be on your guard

"Be ready for what people will do to you"

#### deliver you up to

This means to take someone and put them under someone else's control. AT: "take you and give you over to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you will be beaten

This can be stated in active form. AT: "people will beat you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You will stand before

This means to be put on trial and judged. AT: "You will be put on trial before" or "You will be brought to trial and judged by" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### for my sake

"because of me" or "on account of me"

#### as a testimony to them

This means they will testify about Jesus. This can be made clear. AT: "and testify to them about me" or "and you will tell them about me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### But the gospel must first be proclaimed to all the nations

Jesus is still speaking about things that must happen before the end comes. This can be made clear. AT: "But the gospel must first be proclaimed to all the nations before the end will come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Mark 13:11

#### hand you over

Here this means to put people under the control of the authorities. AT: "give you over to the authorities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### but the Holy Spirit

The words "will speak" are understood from the previous phrase. AT: "but the Holy Spirit will speak through you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Brother will deliver up brother to death

This means that some people will betray their bothers, and this betrayal will cause their brothers to be killed. AT: "Brothers will betray their brothers, handing them over to be put to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Brother ... brother

This refers to both brothers and sisters. AT: "People ... their siblings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### a father his child

The words "will deliver up to death" are understood from the previous phrase. This means that some fathers will betray their children, and this betrayal will cause their children to be killed. AT: "fathers will deliver up their children to death" or "fathers will betray their children, handing them over to be killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Children will rise up against their parents

This means that children will oppose their parents and betray them. AT: "Children will oppose their parents" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### cause them to be put to death

This means that the authorities will sentence the parents to be put to death. This can be stated in active form. AT: "cause the authorities to sentence the parents to die" or "the authorities will kill the parents" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You will be hated by everyone

This can be stated in active form. AT: "Everyone will hate you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### because of my name

Jesus uses the metonym "my name" to refer to himself. AT: "because of me" or "because you believe in me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### whoever endures to the end, that person will be saved

This may be stated in active form. AT: "whoever endures to the end, God will save that person" or "God will save whoever endures to the end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### whoever endures to the end

Here "endures" represents continuing to be faithful to God even while suffering. AT: "whoever suffers and stays faithful to God to the end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to the end

Possible meanings are 1) "to the end of his life" or 2) "to the end of that time of trouble"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Mark 13:14

#### the abomination of desolation

This phrase is from the book of Daniel. His audience would have been familiar with this passage and the prophecy about the abomination entering the temple and defiling it. AT: "the shameful thing that defiles the things of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### standing where it should not be standing

Jesus' audience would have known that this refers to the temple. This can be made explicit. AT: "standing in the temple, where it should not be standing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### let the reader understand

This is not Jesus speaking. Matthew added this to get the readers' attention, so that they would listen to this warning. AT: "may everyone who is reading this pay attention to this warning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### on the housetop

Housetops where Jesus lived were flat, and people could stand on them.

#### not return

This refers to returning to his house. This can be made explicit. AT: "not return to his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### to take his cloak

"to get his cloak"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]

### Mark 13:17

#### are with child

This is a polite way to say that someone is pregnant. AT: "are pregnant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### Pray that it

"Pray that these times" or "Pray that these things"

#### the winter

"the cold season" or "the cold, rainy season." This refers to the time of year when it is cold and unpleasant and difficult to travel.

#### such as has not been

"greater than there has ever been." This describes how great and terrible the tribulation will be. There has never been a tribulation as terrible as this one will be.

#### no, nor ever will be again

"and greater than there will ever be again" or "and after that tribulation, there will never again be a tribulation like it"

#### had shortened the days

"had shortened the time." It may be helpful to specify which "days" are referred to. AT: "had reduced the days of suffering" or "had shortened the time of suffering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no flesh would be saved

The word "flesh" refers to people, and "saved" refers to physical salvation. AT: "no one would be saved" or "everyone would die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### for the sake of the elect

"in order to help the elect"

#### the elect, those whom he chose

The phrase "those whom he chose" means the same thing as "the elect." Together, they emphasize that God chose these people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]

### Mark 13:21

#### General Information:

In verse 21 Jesus gives a command, and in 22 he tells the reason for the command. This can be reordered with the reason first, and the command second, as in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-versebridge.md)]])

#### false Christs

"people who claim they are Christ"

#### so as to deceive

"in order to deceive" or "hoping to deceive" or "trying to deceive"

#### so as to deceive, if possible, even the elect

The phrase "even the elect" implies that the false Christs and false prophets will expect to deceive some people, but they will not know if they will be able to deceive the elect. AT: "in order to deceive people, and even deceive the elect, if that is possible" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the elect

"the people whom God has chosen"

#### Be on guard

"Be watchful" or "Be alert"

#### I have told you all these things ahead of time

Jesus told them these things to warn them. AT: "I have told you all these things ahead of time to warn you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]

### Mark 13:24

#### the sun will be darkened

This can be stated in active form. AT: "the sun will become dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the moon will not give its light

Here the moon is spoken of as if it were alive and able to give something to someone else. AT: "the moon will not shine" or "the moon will be dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the stars will fall from the sky

This does not mean that they will fall to earth but that they will fall from where the are now. AT: "the stars will fall from their places in the sky" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the powers that are in the heavens will be shaken

This can be stated in active form. AT: "the powers in the heavens will shake" or "God will shake the powers that are in the heavens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the powers that are in the heavens

"the powerful things in the heavens." Possible meanings are 1) this refers to the sun, moon, and stars or 2) this refers to powerful spiritual beings

#### in the heavens

"in the sky"

#### Then they will see

"Then people will see"

#### with great power and glory

"powerfully and gloriously"

#### he will gather

The word "he" refers to God and is a metonym for his angels, as they are the ones who will gather the elect. AT: "they will gather" or "his angels will gather" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the four winds

The whole earth is spoken of as "the four winds," which refer to the four directions: north, south, east, and west. AT: "the north, south, east, and west" or "all parts of the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from the ends of the earth to the ends of the sky

These two extremes are given to emphasize that the elect will be gathered from the entire earth. AT: "from every place on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]

### Mark 13:28

#### Connecting Statement:

Jesus gives two short parables here to remind people to be aware when the things that he has been explaining happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### the branch becomes tender and puts out its leaves

The phrase "the branch" refers to the branches of the fig tree. AT: "its branches become tender and put out their leaves"

#### tender

"green and soft"

#### puts out its leaves

Here the fig tree is spoken of as if it were alive and able to willingly cause its leaves to grow. AT: "its leaves begin to sprout" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### summer

the warm part of the year or the growing season

#### these things

This refers to the days of tribulation. AT: "these things I have just described" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he is near

"the Son of Man is near"

#### close to the gates

This idiom means that he is very near and has almost arrived, referring to a traveler being close to arriving at the city gates. AT: "and is almost here" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Mark 13:30

#### Truly I say to you

This indicates that the statement that follows is especially important. See how you translated this in [Mark 3:28](../03/28.md).

#### will not pass away

This is a polite way to talk about someone dying. AT: "will not die" or "will not end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### until all of these things

The phrase "these things" refers to the days of tribulation.

#### Heaven and earth

The two extremes are given to refer to all of the sky, including the sun, moon, stars, and planets, and all of the earth. AT: "The sky, the earth, and everything in them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### will pass away

"will cease to exist." Here this phrase refers to the world ending.

#### my words will never pass away

Jesus speaks of words not losing their power as if they were something that will never physically die. AT: "my words will never lose their power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that day or that hour

This refers to the time that the Son of Man will return. AT: "that day or that hour that the Son of Man will return" or "the day or the hour that I will return" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no one knows, not even the angels in heaven, nor the Son, but the Father

These words specify some of those who do not know when the Son of Man will return, different from the Father, who does know. AT: "no one knows—neither the angels in heaven nor the Son know—but the Father" or "neither the angels in heaven nor the Son know; no one knows but the Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the angels in heaven

Here "heaven" refers to the place where God lives.

#### but the Father

It is best to translate "Father" with the same word that your language naturally uses to refer to a human father. Also, this is an ellipsis, stating that the Father knows when the Son will return. AT: "but only the Father knows" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Mark 13:33

#### what time it is

It can be stated clearly what "time" refers to here. AT: "when all these events will happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### each one with his work

"telling each one what work he should do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Mark 13:35

#### it could be in the evening

"he could return in the evening"

#### rooster crows

The rooster is a bird that "crows" very early in the morning by making a loud call.

#### find you sleeping

Here Jesus speaks of not being ready as "sleeping." AT: "find you not ready for his return" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Mark 13:intro

#### Mark 13 General Notes ####

####### Structure and format #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 13:24-25, which is quoted from the OT.

There is a large section in this chapter which explains the circumstances surrounding the return of Christ (see: [Mark 13:6-37](./05.md)). It would have been natural for people to worry about this event happening because of the judgment associated with it. Jesus assures them that the time of judgment has not yet come. 

####### Special concepts in this chapter #######

######## "I am he" ########
Before Jesus actually returns, many people will claim to be the returning Christ. But Jesus' return will be obvious to all.

##### Links: #####

* __[Mark 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Mark 14

### Mark 14:01

#### Connecting Statement:

Just two days before the Passover, the chief priests and scribes are secretly plotting to kill Jesus.

#### stealthily

without people noticing

#### For they were saying

The word "they" refers to the chief priests and the scribes.

#### Not during the feast

This refers to them not arresting Jesus during the feast. AT: "We must not do it during the feast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]

### Mark 14:03

#### Connecting Statement:

Though some were angry that the oil was used to anoint Jesus, Jesus says that the woman has anointed his body for burial before he will die.

#### Simon the leper

This man previously had leprosy but was no longer ill. This is a different man than Simon Peter and Simon the Zealot. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### he was reclining at the table

In Jesus' culture, when people gathered to eat, they reclined on their sides, propping themselves up on pillows beside a low table.

#### alabaster jar

This is a jar made from alabaster. Alabaster was a very expensive yellow-white stone. AT: "beautiful white stone jar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### of very costly liquid, which was pure nard

"that contained expensive, fragrant perfume called nard." Nard was a very expensive, sweet-smelling oil used to make perfume. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### on his head

"on Jesus' head"

#### What is the reason for this waste?

They asked this question to show that they disapproved of the woman pouring the perfume on Jesus. This can be written as a statement. AT: "It is terrible that she wasted that perfume!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### This perfume could have been sold

Mark wants to show his readers that those present were more concerned about money. This can be stated in active form. AT: "We could have sold this perfume" or "She could have sold this perfume" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### three hundred denarii

"300 denarii." Denarii are Roman silver coins. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### given to the poor

The phrase "the poor" refers to poor people. This refers to giving the money from the sale of the perfume to the poor. AT: "the money given to poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leprosy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leprosy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]

### Mark 14:06

#### Why are you troubling her?

Jesus rebukes the guests for questioning this woman's action. This can be written as a statement. AT: "You should not trouble her!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the poor

This refers to poor people. AT: "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### Truly I say to you

This indicates that the statement that follows is especially true and important. See how you translated this in [Mark 3:28](../03/28.md).

#### wherever the gospel is preached

This can be stated in active form. AT: "wherever my followers preach the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what this woman has done will be spoken of

"what this woman has done will also be spoken of"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Mark 14:10

#### Connecting Statement:

After the woman anoints Jesus with perfume, Judas promises to deliver Jesus to the chief priests.

#### so that he might deliver him over to them

Judas did not deliver Jesus over to them yet, rather he went to make arrangements with them. AT: "in order to arrange with them to bring Jesus to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### deliver

"Deliver" here is a metaphor, meaning "to bring." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### When the chief priests heard it

It may be helpful to state clearly what the chief priests heard. AT: "When the chief priests heard what he was willing to do for them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Mark 14:12

#### Connecting Statement:

Jesus sends two of the disciples to prepare the Passover meal.

#### when they sacrificed the Passover lamb

At the beginning of the Festival of Unleavened Bread, it was customary to sacrifice a lamb. AT: "when it was customary to sacrifice the Passover lamb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### bearing a pitcher of water

"carrying a large jar full of water"

#### The Teacher says, "Where is my guest room ... with my disciples?"

This can be written as an indirect quote. Translate this so that it is a polite request. AT: "Our Teacher would like to know where the guest room is where he may eat the Passover with his disciples." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### guest room

a room for visitors

#### eat the Passover

Here the "Passover" refers to the Passover meal. AT: "eat the Passover meal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]

### Mark 14:15

#### Make the preparations for us there

They were to prepare the meal for Jesus and his disciples to eat. AT: "Prepare the meal for us there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The disciples left

"The two disciples left"

#### as he had said

"as Jesus had said"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]

### Mark 14:17

#### Connecting Statement:

That evening as Jesus and the disciples eat the Passover meal, Jesus tells them that one of them will betray him.

#### he came with the twelve

It may be helpful to state where they came to. AT: "he came with the twelve to the house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### lying down at the table

In Jesus' culture, when people gathered to eat, they lay down on their sides, propping themselves up on pillows beside a low table.

#### Truly I say to you

This indicates that the statement that follows is especially true and important. See how you translated this in [Mark 3:28](../03/28.md).

#### one by one

This means that "one at a time" each disciple asked him.

#### Surely not I?

Possible meanings are 1) this was a question for which the disciples expected the answer to be no or 2) this was a rhetorical question that did not require a response. AT: "Surely I am not the one who will betray you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### Mark 14:20

#### It is one of the twelve, the one now

"He is one of the twelve of you, the one now"

#### dipping bread with me in the bowl

In Jesus' culture, people would often eat bread, dipping it in a shared bowl of sauce or of oil mixed with herbs.

#### For the Son of Man will go the way that the scripture says about him

Here Jesus refers to the scriptures prophesying about his death. If you have a polite way to talk about death in your language, use it here. AT: "For the Son of Man will die in the way that the scriptures say"

#### through whom the Son of Man is betrayed

This can be stated more directly. AT: "who betrays the Son of Man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### Mark 14:22

#### bread

This was a flat loaf of unleavened bread, which was eaten as part of the Passover meal.

#### broke it

This means that he broke the bread into pieces for the people to eat. AT: "broke it into pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Take this. This is my body

"Take this bread. It is my body." Though most understand this to mean that the bread is a symbol of Jesus' body and that it is not actual flesh, it is best to translate this statement literally. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### He took a cup

Here "cup" is a metonym for wine. AT: "He took the cup of wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### This is my blood of the covenant, the blood that is poured out for many

The covenant is for the forgiveness of sins. This can be written more explicitly. AT: "This is my blood that confirms the covenant, the blood that is poured out so that many may receive the forgiveness of sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### This is my blood

"This wine is my blood." Though most understand this to mean that the wine is a symbol of Jesus' blood and that it is not actual blood, it is best to translate this statement literally. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### Truly I say to you

This indicates that the statement that follows is especially true and important. See how you translated this in [Mark 3:28](../03/28.md).

#### fruit of the vine

"wine." This is a descriptive way to refer to wine.

#### new

Possible meanings are 1) "again" or 2) "in a new way"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]

### Mark 14:26

#### hymn

A hymn is a type of song. It was traditional for them to sing an Old Testament psalm.

#### Jesus said to them

"Jesus said to his disciples"

#### will fall away

This is an idiom that means leave. AT: "will leave me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I will strike

"kill." Here "I" refers to God.

#### the sheep will be scattered

This can be stated in active form. AT: "I will scatter the sheep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Mark 14:28

#### Connecting Statement:

Jesus clearly tells Peter he will deny him. Peter and all of the disciples are certain they will not deny Jesus.

#### I am raised up

This means that God will raise Jesus from the dead. This can be written in active form. AT: "God raises me from the dead" or "God makes me alive again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I will go ahead of you

"I will go before you"

#### Even if all fall away, I will not

"I will not" can be fully expressed as "I will not fall away." The phrase "not fall away" is a double negative and carries a positive meaning. This can be expressed in the positive if needed. AT: "Even if everyone else leaves you, I will stay with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]

### Mark 14:30

#### Truly I say to you

This indicates that the statement that follows is especially true and important. See how you translated this in [Mark 3:28](../03/28.md).

#### rooster crows

The rooster is a bird that calls out very early in the morning. The loud sound he makes is "crowing."

#### twice

"two times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### you will deny me

"you will say that you do not know me"

#### If I must die

"Even if I must die"

#### They all made the same promise

This means that all of the disciples said the same thing that Peter said.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Mark 14:32

#### Connecting Statement:

When they go to Gethsemane on the Mount of Olives, Jesus encourages three of his disciples to stay awake while he prays. Twice he awakens them, and the third time he tells them to wake up because it is time for the betrayal.

#### They came to the place

The word "they" refers to Jesus and his disciples.

#### distressed

overwhelmed with sorrow

#### deeply troubled

The word "deeply" refers to Jesus being greatly troubled in his soul. AT: "extremely troubled" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### My soul is

Jesus speaks of himself as his "soul." AT: "I am" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### even to the point of death

Jesus is exaggerating because he feels so much distress and sorrow that he feels like he is about to die, though he knows he will not die until after the sun rises. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### watch

The disciples were to stay alert while Jesus prayed. This does not mean that they were supposed to watch Jesus pray.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gethsemane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gethsemane.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofalphaeus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamessonofalphaeus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]

### Mark 14:35

#### if it were possible

This means that if God would allow it to happen. AT: "if God would allow it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the hour might pass

Here "this hour" refers to Jesus' time of suffering, both now in the garden and later. AT: "that he would not have to go through this time of suffering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Abba

a term used by Jewish children to address their father. Since it is followed by "Father," it is best to transliterate this word. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Remove this cup from me

Jesus speaks of the suffering that he must endure as if it were a cup. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But not my will, but yours

Jesus is asking God to do what he wants to be done and not what Jesus wants. AT: "But do not do what I want, do what you want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Mark 14:37

#### found them sleeping

The word "them" refers to Peter, James, and John.

#### Simon, are you asleep? Could you not watch for one hour?

Jesus rebukes Simon Peter for sleeping. This can be written as a statement. AT: "Simon, you are asleep when I told you to stay awake. You could not even stay awake for one hour." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### that you do not enter into temptation

Jesus speaks of being tempted as if it were entering into a physical place. AT: "that you are not tempted" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The spirit indeed is willing, but the flesh is weak

Jesus warns Simon Peter that he is not strong enough to do what he wants to do in his own strength. AT: "You are willing in your spirit, but you are too weak to do what you want to do" or "You want to do what I say, but you are weak"

#### The spirit ... the flesh

These refer to two different aspects of Peter. "The spirit" is his inmost desires. "The flesh" is his human ability and strength. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### used the same words

"prayed again what he prayed before"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Mark 14:40

#### found them sleeping

The word "them" refers to Peter, James, and John.

#### for their eyes were heavy

Here the author speaks of a sleepy person having a hard time keeping his eyes open as having "heavy eyes." AT: "for they were so sleepy they were having a hard time keeping their eyes open" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He came the third time

Jesus had gone and prayed again. Then he returned to them a third time. This can be made clear. AT: "Then he went and prayed again. He returned the third time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Are you still sleeping and taking your rest?

Jesus rebukes his disciples for not staying awake and praying. You can translate this rhetorical question as a statement if needed. AT: "You are still sleeping and resting!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The hour has come

The time of Jesus' suffering and betrayal is about to begin.

#### Look!

"Listen!"

#### The Son of Man is being betrayed

Jesus warns his disciples that his betrayer is approaching them. This can be stated in active form. AT: "I, the Son of Man, am being betrayed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### Mark 14:43

#### Connecting Statement:

Judas betrays Jesus with a kiss, and the disciples all flee.

#### General Information:

Verse 44 gives background information about how Judas had arranged with the Jewish leaders to betray Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Now his betrayer

This refers to Judas.

#### he is the one

Here "the one" refers to the man that Judas was going to identify. AT: "he is the one you want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he kissed him

"Judas kissed him"

#### laid hands on him and seized him

These two phrases have the same meaning to emphasize that they seized Jesus. AT: "grabbed Jesus and seized him" or "seized him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Mark 14:47

#### who stood by

"who was standing nearby"

#### Jesus said to them

"Jesus said to the crowd"

#### Do you come out, as against a robber, with swords and clubs to capture me?

Jesus is rebuking the crowd. This can be written as a statement. AT: "It is ridiculous that you come here to seize me with swords and clubs, as if I were a robber!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### But this was done that

"But this has happened so that"

#### All those with Jesus

This refers to the disciples.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]

### Mark 14:51

#### linen

cloth made from the fibers of a flax plant

#### that was wrapped around him

This can be stated in active form. AT: "that he had wrapped around himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### When the men seized him

"When the men seized that man"

#### he left the linen garment

As the man was trying to run away, the others would have grabbed at his clothing, trying to stop him.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]

### Mark 14:53

#### Connecting Statement:

After the crowd of the chief priests, scribes, and elders lead Jesus to the high priest, Peter watches nearby while some stand to give false testimony against Jesus.

#### There were gathered with him all the chief priests, the elders, and the scribes

This can be reordered so that it is easier to understand. "All of the chief priests, the elders, and the scribes had gathered there together"

#### Now

This word is used here to mark a shift in the story line as the author begins telling us about Peter.

#### as far as the courtyard of the high priest

As Peter followed Jesus, he stopped at the high priest's courtyard. This can be written clearly. AT: "and he went as far as the courtyard of the high priest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He sat among the guards

Peter sat with the guards who were working at the courtyard. AT: "He sat in the courtyard among the guards" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]

### Mark 14:55

#### Now

This word is used here to mark a shift in the story line as the author continues telling us about Jesus being put on trial.

#### they might put him to death

They were not the ones who would execute Jesus; rather, they would order someone else to do it. AT: "they might have Jesus executed" or "they might have someone execute Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But they did not find any

They did not find testimony against Jesus with which they could convict him and have him put to death. AT: "But they did not find any testimony with which to convict him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### brought false testimony against him

Here speaking false testimony is described as if it were a physical object that someone can carry. AT: "accused him by speaking false testimony against him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their testimony did not agree

This can be written in positive form. "but their testimony contradicted each other"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]

### Mark 14:57

#### brought false testimony against him

Here speaking false testimony is described as if it were a physical object that someone can carry. AT: "accused him by speaking false testimony against him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We heard him say

"We heard Jesus say." The word "we" refers to the people who brought false testimony against Jesus and does not include the people to whom they are speaking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### made with hands

Here "hands" refers to men. AT: "made by men ... without man's help" or "built by men ... without man's help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### in three days

"within three days." This means that the temple would be built within a three-day period.

#### will build another

The word "temple" is understood from the previous phrase. It may be repeated. AT: "will build another temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### did not agree

"contradicted each other." This can be written in positive form.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### Mark 14:60

#### Connecting Statement:

When Jesus answers that he is the Christ, the high priest and all of the leaders there condemn him as one who deserves to die.

#### stood up among them

Jesus stands up in the middle of the angry crowd to speak to them. Translate this to show who was present when Jesus stood up to speak. AT: "stood up among the chief priests, scribes, and elders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Have you no answer? What is it these men testify against you?

The chief priest is not asking Jesus for information about what the witnesses said. He is asking Jesus to prove what the witnesses said is wrong. AT: "Are you not going to reply? What do you say in response to the testimony these men are speaking against you?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Son of the Blessed

Here God is called "the Blessed." It is best to translate "Son" with the same word your language would naturally use to refer to a "son" of a human father. AT: "the Son of the Blessed One" or "the Son of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I am

This likely has a double meaning: 1) to respond to the high priest's question and 2) to call himself "I Am," which is what God called himself in the Old Testament.

#### he sits at the right hand of power

Here "power" is a metonnymm that represents God. To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "he sits in the place of honor beside the all-powerful God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### comes with the clouds of heaven

Here the clouds are described as accompanying Jesus when he returns. AT: "when he comes down through the clouds in the sky" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Mark 14:63

#### tore his garments

The high priest tore his clothes purposefully to show his outrage and horror at what Jesus has said. AT: "tore his garments in outrage"

#### Do we still need witnesses?

This can be written as a statement. AT: "We certainly do not need any more people who will testify against this man!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You have heard the blasphemy

This refers to what Jesus said, which the high priest called blasphemy. AT: "You have heard the blasphemy he has spoken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They all ... Some began to

These phrases refer to the people in the crowd.

#### to cover his face

They covered his face with a cloth or blindfold, so he could not see. AT: "to cover his face with a blindfold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Prophesy

They mocked him, asking him to prophesy who was hitting him. AT: "Prophesy who hit you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### officers

"guards"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### Mark 14:66

#### Connecting Statement:

As Jesus had predicted, Peter denies Jesus three times before the rooster crows.

#### below in the courtyard

"outside in the courtyard"

#### one of the servant girls of the high priest

The servant girls worked for the high priest. AT: "one of the servant girls who worked for the high priest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### denied

This means to claim that something is not true. In this case, Peter was saying that what the servant girl said about him was not true.

#### neither know nor understand what you are talking about

Both "know" and "understand" have the same meaning here. The meaning is repeated to add emphasis to what Peter is saying. AT: "I really do not understand what you are talking about" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]

### Mark 14:69

#### the servant girl

This is the same servant girl who identified Peter previously.

#### one of them

The people were identifying Peter as one of Jesus' disciples. This can be made more clear. AT: "one of Jesus' disciples" or "one of those who have been with that man they arrested" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]

### Mark 14:71

#### to put himself under curses

If in your language you have to name the person who curses someone, state God. AT: "to say for God to curse him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### rooster immediately crowed

The rooster is a bird that calls out very early in the morning. The loud sound he makes is "crowing."

#### a second time

"Second" here is an ordinal number. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### he broke down

This idiom means that he was overwhelmed with grief and lost control of his emotions. AT: "he was overwhelmed with grief" or "he lost control of his emotions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Mark 14:intro

#### Mark 14 General Notes ####

####### Structure and format #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 14:27, 62, which is quoted from the OT.

####### Special concepts in this chapter #######

######## The eating of the body and blood ########

To this day, this symbolic action is practiced in nearly all churches in remembrance of Christ's sacrifice for the sins of man. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Other possible translation difficulties in this chapter #######

######## "Son of Man" ########

Jesus refers to himself as the "Son of Man" in this passage.

######## Abba, Father ########
"Abba" is an Aramaic word. It was an informal, loving way to refer to  a person's father in ancient Israel. Mark "transliterates" its sounds by writing them with Greek letters, and then gives its meaning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

######## "I am" ########
This is a reference to the name of God, Yahweh. Jesus is explicitly claiming to be Yahweh. (See: [Mark 14:62](./60.md) and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Mark 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## Mark 15

### Mark 15:01

#### Connecting Statement:

When the chief priests, the elders, the scribes, and the council gave Jesus over to Pilate, they accused Jesus of doing many bad things. When Pilate asked if what they said was true, Jesus did not answer him.

#### they bound Jesus and led him away

They commanded for Jesus to be bound, but it would have been the guards who actually bound him and led him away. AT: "they commanded for Jesus to be bound and then he was led away" or "they commanded the guards to bind Jesus and then they led him away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They handed him over to Pilate

They had Jesus led to Pilate and transferred control of Jesus over to him.

#### You say so

Possible meanings are 1) by saying this, Jesus was saying that Pilate, not Jesus, was the one calling him the King of the Jews. AT: "You yourself have said so" or 2) by saying this, Jesus implied that he is the King of the Jews. AT: "Yes, as you said, I am" or "Yes. It is as you said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### were presenting many charges against Jesus

"were accusing Jesus of many things" or "were saying that Jesus had done many bad things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]

### Mark 15:04

#### Pilate again asked him

"Pilate asked Jesus again"

#### Do you give no answer

This can be stated in positive form. AT: "Do you have an answer"

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you"

#### that amazed him

It surprised Pilate that Jesus did not reply and defend himself.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 15:06

#### Connecting Statement:

Pilate, hoping the crowd will choose Jesus, offers to release a prisoner, but the crowd asks for Barabbas instead.

#### Now

This word is used here to mark a break in the main story line as the author shifts to telling background information about Pilate's tradition of releasing a prisoner at feasts and about Barabbas. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### There with the rebels in prison ... in the rebellion, was a man named Barabbas

"At that time there was a man called Barabbas, who was in prison with some other men. They had committed murder when they rebelled against the Roman government"

#### to do for them as he had done in the past

This refers to Pilate releasing a prisoner at feasts. This can be made clear. AT: "to release a prisoner to them as he had done in the past" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md)]]

### Mark 15:09

#### For he knew that it was because of envy ... Jesus over to him

This is background information about why Jesus was handed over to Pilate. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### it was because of envy that the chief priests

They envied Jesus, probably because so many people were following him and becoming his disciples. AT: "the chief priests were envious of Jesus. This is why they" or "the chief priests were envious of Jesus' popularity among the people. This is why they" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### stirred up the crowd

The author speaks of the chief priests rousing or urging the crowd as if the crowd were a bowl of something that they were stirring. AT: "roused the crowd" or "urged the crowd" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### released instead

They requested Barabbas to be released instead of Jesus. AT: "released instead of Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md)]]

### Mark 15:12

#### Connecting Statement:

The crowd asks for Jesus' death, so Pilate turns him over to the soldiers, who mock him, crown him with thorns, strike him, and lead him out to crucify him.

#### What then should I do with the King of the Jews

Pilate asks what he should do with Jesus if he releases Barabbas to them. This can be written clearly. AT: "If I release Barabbas, what then should I do with the King of the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]

### Mark 15:14

#### Pilate said to them

"Pilate said to the crowd"

#### satisfy

"please"

#### He scourged Jesus

Pilate did not actually scourge Jesus but rather his soldiers did.

#### scourged

"flogged." To "scourge" is to beat with an especially painful whip.

#### then handed him over to be crucified

Pilate told his soliders to take Jesus away to crucify him. This can be stated in active form. AT: "told his soldiers to take him away and crucify him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Mark 15:16

#### the courtyard (which is the government headquarters)

This was where the Roman soldiers in Jerusalem lived, and where the governor stayed when he was in Jerusalem. AT: "the courtyard of the soldiers' barracks" or "the courtyard of the governor's residence"

#### the whole cohort of soldiers

"the whole unit of soldiers"

#### They put a purple robe on Jesus

Purple was a color worn by royalty. The soldiers did not believe that Jesus was king. They clothed him this way to mock him because others said that he was the King of the Jews.

#### a crown of thorns

"a crown made of thorny branches"

#### Hail, King of the Jews

The greeting "Hail" with a raised hand was only used to greet the Roman emperor. The soldiers did not believe that Jesus was the king of the Jews. Rather they said this to mock him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]

### Mark 15:19

#### a reed

"a stick" or "a staff"

#### bent their knees

A person who kneels bends his knees, so those who kneel are sometimes said to "bend their knees." AT: "kneeled" or "knelt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they forced him to carry his cross

According to Roman law, a solider could force a man he came upon along the road to carry a load. In this case, they forced Simon to carry Jesus' cross.

#### from the country

"from outside the city"

#### A certain man, ... Rufus), and

This is background information about the man whom the soldiers forced to carry Jesus' cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Simon ... Alexander ... Rufus

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Cyrene

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]

### Mark 15:22

#### Connecting Statement:

The soldiers bring Jesus to Golgotha, where they crucify him with two others. Many people mock him.

#### Place of a Skull

"Skull Place" or "Place of the Skull." This the name of a place. It does not mean that there are lots of skulls there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Skull

A skull is the head bones, or a head without any flesh on it.

#### wine mixed with myrrh

It may be helpful to explain that myrrh is a pain-relieving medicine. AT: "wine mixed with a medicine called myrrh" or "wine mixed with a pain-relieving medicine called myrrh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/golgotha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/golgotha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]

### Mark 15:25

#### the third hour

"Third" here is a ordinal number. This refers to nine o'clock in the morning. AT: "nine o'clock in the morning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### On a sign

The soldiers attached this sign to the cross above Jesus. AT: "They attached to the cross above Jesus' head a sign on which" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### charge

"accusation"

#### robbers

"armed thieves"

#### one on the right of him and one on his left

This can be written more clearly. AT: "one on a cross on the right side of him and one on a cross on the left side of him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md)]]

### Mark 15:29

#### shaking their heads

This is an action people do to show that they disapproved of Jesus.

#### Aha!

This is a exclamation of mockery. Use the appropriate exclamation in your language. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### You who would destroy the temple and rebuild it in three days

The people refer to Jesus by what he earlier prophesied that he would do. AT: "You who said you would destroy the temple and rebuild it in three days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]

### Mark 15:31

#### In the same way

This refers to the way that the people who were walking by Jesus were mocking him.

#### were mocking him with each other

"were saying mocking things about Jesus among themselves"

#### Let the Christ, the King of Israel, come down

The leaders did not believe that Jesus is the Christ, the King of Israel. AT: "He calls himself the Christ and the King of Israel. So let him come down" or "If he is really the Christ and the King of Israel, he should come down" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### believe

The means to believe in Jesus. AT: "believe in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### taunted

"mocked" or "insulted"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]

### Mark 15:33

#### Connecting Statement:

At noon darkness covers the whole land until three o'clock, when Jesus cries out with a loud voice and dies. When Jesus dies, the temple curtain rips from the top to the bottom.

#### the sixth hour

This refers to noon or 12 p.m.

#### darkness came over the whole land

Here the author describes it becoming dark outside as if the darkness were a wave that moved over the land. AT: "the whole land became dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### At the ninth hour

This refers to three o'clock in the afternoon. AT: "At three o'clock in the afternoon" or "In the middle of the afternoon"

#### Eloi, Eloi, lama sabachthani

These are Aramaic words that should be copied as is into your language with similar sounds. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### is interpreted

"means"

#### Some of those standing by heard his words and said

It can be stated clearly that they misunderstood what Jesus said. AT: "When some of those standing there heard his words, they misunderstood and said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]

### Mark 15:36

#### sour wine

"vinegar"

#### reed staff

"stick." This was a staff made from a reed.

#### gave it to him

"gave it to Jesus." The man held up the staff so that Jesus could drink wine from the sponge. AT: "held it up to Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The curtain of the temple was split in two

Mark is showing that God himself split the temple curtain. This can be translated in active form. AT: "God split the curtain of the temple in two" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### Mark 15:39

#### the centurion

This is the centurion who supervised the soldiers who crucified Jesus.

#### who stood and faced Jesus

"who stood in front of Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that he had died in this way

"how Jesus had died" or "the way Jesus had died"

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### looked on from a distance

"watched from far away"

#### (the mother of James ... and of Joses)

"who was the mother of James ... and of Joses." This can be written without the parentheses.

#### James the younger

"the younger James." This man was referred to as "the younger" probably to distinguish him from another man named James.

#### Joses

This Joses was not that same person as the younger brother of Jesus. See how you translated the same name in [Mark 6:3](../06/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Salome

Salome is the name of a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### When he was in Galilee they followed him ... with him to Jerusalem

"When Jesus was in Galilee these women followed him ... with him to Jerusalem." This is background information about the women who watched the crucifixion from a distance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### came up with him to Jerusalem

Jerusalem was higher than almost any other place in Israel, so it was normal for people to speak of going up to Jerusalem and going down from it.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/centurion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/centurion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Mark 15:42

#### Connecting Statement:

Joseph of Arimathea asks Pilate for the body of Jesus, which he wraps in linen and puts in a tomb.

#### evening had come

Here evening is spoken of as if it were something that is able to "come" from one place to another. AT: "it had become evening" or "it was evening" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Joseph of Arimathea came there. He was a respected

The phrase "came there" refers to Joseph coming to Pilate, which is also described after the background information is given, but his coming is referenced before for emphasis and to help introduce him to the story. There may be a different way to do this in your language. AT: "Joseph of Arimathea was a respected" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### Joseph of Arimathea

"Joseph from Arimathea." Joseph is the name of a man, and Arimathea is the name of the place his is from. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He was a respected member of the council ... for the kingdom of God

This is background information about Joseph. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### went in to Pilate

"went to Pilate" or "went in to where Pilate was"

#### asked for the body of Jesus

It can be stated clearly that he wanted to get the body so that he could bury it. AT: "asked for permission to get the body of Jesus in order to bury it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Pilate was amazed that Jesus was already dead; he called the centurion

Pilate heard people saying that Jesus was dead. This surprised him, so he asked the centurion if it was true. This can be made clear. AT: "Pilate was amazed when he heard that Jesus was already dead, so he called the centurion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 15:45

#### he gave the body to Joseph

"he permitted Joseph to take Jesus' body"

#### linen

Linen is cloth made from the fibers of a flax plant. See how you translated this in [Mark 14:51](../14/51.md).

#### He took him down ... Then he rolled a stone

You may need to make explicit that Joseph probably had help from other people when he took Jesus' body down from the cross, prepared it for the tomb, and closed the tomb. AT: "He and others took him down ... Then they rolled a stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a tomb that had been cut out of a rock

This can be stated in active form. AT: "a tomb that someone had previously cut out of solid rock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a stone against

"a huge flat stone in front of"

#### Joses

This Joses was not that same person as the younger brother of Jesus. See how you translated the same name in [Mark 6:3](../06/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the place where Jesus was buried

This can be stated in active form. AT: "the place where Joseph and the others buried Jesus' body" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/centurion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/centurion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md)]]

### Mark 15:intro

#### Mark 15 General Notes ####

####### Special concepts in this chapter #######

######## "The curtain of the temple was split in two" ########
This is an important symbol. In the temple the curtain symbolically separated God and man. God could not be directly accessed because of his holiness. The death of Christ changed this.

####### Important figures of speech in this chapter #######

######## "King of the Jews" ########
This is sarcasm, which is the use of irony to insult someone. The phrases "save yourself and come down from the cross," "Let the Christ, the King of Israel, come down now from the cross, that we may see and believe" and "Let us see if Elijah comes to take him down" are also sarcasm. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

####### Other possible translation difficulties in this chapter #######

######## Eloi, Eloi, lama sabachthani? ########
This is a phrase in Aramaic. Mark transliterates its sounds by writing them using Greek letters. He then explains its meaning.

##### Links: #####

* __[Mark 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## Mark 16

### Mark 16:01

#### Connecting Statement:

On the first day of the week, women come early because they expect to use spices to anoint Jesus' body. They are surprised to see a young man who tells them Jesus is alive, but they are afraid and do not tell anyone.

#### When the Sabbath day was over

That is, after the Sabbath, the seventh day of the week, had ended and the first day of the week had begun.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### Mark 16:03

#### the stone had been rolled away

This can be stated in active form. AT: "someone had rolled away the stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### Mark 16:05

#### He is risen!

The angel is emphatically stating that Jesus has risen from the dead. This can be translated in active form. AT: "He arose!" or "God raised him from the dead!" or "He raised himself from the dead!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]

### Mark 16:08

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### Mark 16:09

#### Connecting Statement:

Jesus appears first to Mary Magdalene, who tells the disciples, then he appears to two others as they walk in the country, and later he appears to the eleven disciples.

#### on the first day of the week

"on Sunday"

#### They heard

"They heard Mary Magdalene say"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Mark 16:12

#### he appeared in a different form

The "two of them" saw Jesus, but he looked different from how he had looked previously.

#### two of them

two of "those who were with him" ([Mark 16:10](./09.md))

#### they did not believe them

The rest of the disciples did not believe what the two who had been walking in the country said.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### Mark 16:14

#### Connecting Statement:

When Jesus meets with the eleven, he rebukes them for their unbelief and tells them to go out into all the world to preach the gospel.

#### the eleven

These are the eleven apostles who remained after Judas left them.

#### they were reclining at the table

This is a metonym for eating, which was the usual way people in that day ate meals. AT: "they were eating a meal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### reclining

In Jesus' culture, when people gathered to eat, they lay down on their sides, propping themselves up on pillows beside a low table.

#### hardness of heart

Jesus is rebuking his disciples because they would not believe in him. Translate this idiom so it is understood that the disciples were not believing Jesus. AT: "refusal to believe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Go into all the world

Here "the world" is a metonym for the people in the world. AT: "Go everywhere there are people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the entire creation

This is an exaggeration and a metonym for people everywhere. AT: "absolutely everybody" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### He who believes and is baptized will be saved

The word "He" refers to anyone. This sentence can be made active. AT: "God will save all people who believe and allow you to baptize them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he who does not believe will be condemned

The word "he" refers to anyone. This clause can be made active. AT: "God will condemn all people who do not believe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]

### Mark 16:17

#### These signs will go with those who believe

Mark speaks of miracles as though they were people going along with the believers. AT: "People watching those who believe will see these things happen and know that I am with the believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### In my name they

Possible meanings are 1) Jesus is giving a general list: "In my name they will do things like these: They" or 2) Jesus is giving an exact list: "These are the things they will do in my name: They."

#### In my name

Here "name" is associated with Jesus' authority and power. See how "in your name" is translated in [Mark 9:38](../09/38.md). AT: "By the authority of my name" or "By the power of my name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]

### Mark 16:19

#### he was taken up into heaven and sat

This can be stated in active form. AT: "God took him up into heaven, and he sat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sat down at the right hand of God

To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "sat in the place of honor beside God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### confirmed the word

This idiom means they proved that their message was true. AT: "showed that his message, which they were speaking, was true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]

### Mark 16:intro

#### Mark 16 General Notes ####

####### Special concepts in this chapter #######

######## Burial Practices ########
It was customary in ancient Israel to place important or wealthy people in tombs and to close up the tombs with a large rock. Only wealthy families could usually afford this kind of burial place. 

###### Other possible translation difficulties in this chapter ######

######## A young man dressed in a white robe ########
Matthew, Mark, Luke, and John all wrote about angels in white clothing with the women at Jesus' tomb. Two of the authors called them men, but that is only because the angels were in human form. Two of the authors wrote about two angels, but the other two authors wrote about only one of them. It is best to translate each of these passages as it appears in the ULB without trying to make the passages all say exactly the same thing. (See: [Matthew 28:1-2](../../mat/28/01.md), [Mark 16:5](../../mrk/16/05.md) and [Luke 24:4](../../luk/24/04.md) and [John 20:12](../../jhn/20/11.md))

##### Links: #####

* __[Mark 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | __


## Mark front

### Mark front:intro

#### Introduction to the Gospel of Mark ####

##### Part 1: General Introduction #####

####### Outline of the Book of Mark #######

1. Introduction (1:1–13)
1. The ministry of Jesus in Galilee
    - Early ministry (1:14–3:6)
    - Jesus becomes more popular among the people (3:7–5:43)
    - Moving away from Galilee and then returning (6:1–8:26)
1. Progress toward Jerusalem, repeated times when Jesus predicts his own death; the disciples misunderstand, and Jesus teaches them how difficult it will be to follow him (8:27–10:52)
1. Last days of ministry and preparation for final conflict in Jerusalem (11:1–13:37)
1. The death of Christ and the empty tomb (14:1–16:8)

####### What is the Book of Mark about? #######

The Gospel of Mark is one of four books in the New Testament that describe some of the life of Jesus Christ. The authors of the gospels wrote about different aspects of who Jesus was and what he did. Mark wrote much about how Jesus suffered and died on the cross. He did this to encourage his readers who were being persecuted. Mark also explained Jewish customs and some Aramaic words. This may indicate that Mark expected most of his first readers to be Gentiles. 

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "The Gospel of Mark," or "The Gospel according to Mark." They may also choose a title that may be clearer, such as, "The Good News about Jesus that Mark wrote." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Mark? #######

The book does not give the name of the author. However, since early Christian times, most Christians have thought that the author was Mark. Mark was also known as John Mark. He was a close friend of Peter. Mark may not have witnessed what Jesus said and did. But many scholars think that Mark wrote in his gospel what Peter told him about Jesus.

##### Part 2: Important Religious and Cultural Concepts #####

####### What were Jesus' teaching methods? #######

The people regarded Jesus as a rabbi. A rabbi is a teacher of God's law. Jesus taught in similar ways as other religious teachers in Israel. He had students who followed him wherever he went. These students were called disciples. He often told parables. Parables are stories that teach moral lessons. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]])

##### Part 3: Important Translation Issues #####

####### What are the Synoptic Gospels? #######

The Gospels of Matthew, Mark, and Luke are called the Synoptic Gospels because they have many similar passages. The word "synoptic" means to "see together."

The texts are considered "parallel" when they are the same or almost the same among two or three gospels. When translating parallel passages, translators should use the same wording and make them as similar as possible.

####### Why does Jesus refer to himself as the "Son of Man"? #######

In the gospels, Jesus calls himself the "Son of Man." It is a reference to Daniel 7:13-14. In this passage there is a person described as a "son of man." That means the person was someone who looked like a human being. God gave authority to the son of man to rule over the nations forever. And all the people will worship him forever. 

Jews of Jesus' time did not use "Son of Man" as a title for anyone. Therefore, Jesus used it for himself to help them understand who he truly was. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]])

Translating the title "Son of Man" can be difficult in many languages. Readers may misunderstand a literal translation. Translators can consider alternatives, such as "The Human One." It may also be helpful to include a footnote to explain the title.

####### Why does Mark frequently use terms indicating short periods of time? #######

The Gospel of Mark uses the word "immediately" forty-two times. Mark does this to make the events more exciting and vivid. It moves the reader quickly from one event to the next.

####### What are the major issues in the text of the Book of Mark? #######

These are the most significant textual issues in the Book of Mark:

* "If any man has ears to hear, let him hear." (7:16)
* "where their worm never dies and the fire is never quenched" (9:44)
* "where their worm never dies and the fire is never quenched" (9:46)
* "And the scripture was fulfilled that says, 'He was counted with the lawless ones'" (15:28)
* "Early on the first day of the week, after he arose, he appeared first to Mary Magdalene, from whom he had cast out seven demons. She went and told those who were with him, while they were mourning and weeping. They heard that he was alive and that he had been seen by her, but they did not believe. After these things he appeared in a different form to two of them, as they were walking out into the country. They went and told the rest of the disciples, but they did not believe them. Jesus later appeared to the eleven as they were reclining at the table, and he rebuked them for their unbelief and hardness of heart, because they did not believe those who saw him after he rose from the dead. He said to them, 'Go into all the world, and preach the gospel to the entire creation. He who believes and is baptized will be saved, and he who does not believe will be condemned. These signs will go with those who believe: In my name they will cast out demons. They will speak in new languages. They will pick up snakes with their hands, and if they drink anything deadly, it will not hurt them. They will lay hands on the sick, and they will get well.' After the Lord had spoken to them, he was taken up into heaven and sat down at the right hand of God. The disciples left and preached everywhere, while the Lord worked with them and confirmed the word by the signs that went with them." (16:9-20)

Translators are advised not to include these passages. However, if in the translators' region, there are older versions of the Bible that include one or more of these passages, the translators can include them. If they are included, they should be put inside square brackets ([]) to indicate that they were probably not original to Mark's Gospel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])





---

