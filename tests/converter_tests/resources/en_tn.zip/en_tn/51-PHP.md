# <a id="php"/>Philippians

## Philippians 01

### Philippians 01:01

#### General Information:

Paul and Timothy wrote this letter to the church at Philippi.

#### General Information:

Because Paul writes later in the letter saying "I," it is generally assumed that he is the author and that Timothy, who is with him, writes as Paul speaks. All instances of "you" and "your" in the letter refer to the believers in the Philippian church and are plural. The word "our" probably refers to all believers in Christ, including Paul, Timothy, and the Philippian believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Paul and Timothy ... and deacons

If your language has a particular way of introducing the authors of a letter, use it here.

#### Paul and Timothy, servants of Christ Jesus

"Timothy, who are servants of Christ Jesus"

#### all those set apart in Christ Jesus

This refers to those whom God chose to belong to him by being united to Christ. AT: "all God's people in Christ Jesus" or "all those who belong to God because they are united with Christ"

#### the overseers and deacons

"the leaders of the church"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philippi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philippi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/deacon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/deacon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Philippians 01:03

#### I give thanks for your fellowship in the gospel

Paul is expressing thanks to God that the Philippians have joined him in teaching people the gospel. He may have been referring to them praying for him and sending money so that he could travel and tell others. AT: "I give thanks to God that you are helping me proclaim the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I am confident

"I am sure"

#### he who began

"God, who began"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]

### Philippians 01:07

#### It is right for me

"It is proper for me" or "It is good for me"

#### I have you in my heart

This idiom expresses strong affection. AT: "I love you very much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### have been my partners in grace

"have been partakers of grace with me" or "have shared in grace with me"

#### God is my witness

"God knows" or "God understands"

#### with the compassion of Christ Jesus

The abstract noun "compassion" can be translated with the verb "love." AT: "and I love you as Christ Jesus dearly loves us all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Philippians 01:09

#### Connecting Statement:

Paul prays for the believers in Philippi and talks about the joy there is in suffering for the Lord.

#### may abound

Paul speaks of love as if it were objects that people could obtain more of. AT: "may increase" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in knowledge and all understanding

Here "understanding" refers to understanding about God. This can be stated clearly. AT: "as you learn and understand more about what pleases God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### approve

This refers to examining things and taking only those that are good. AT: "test and choose"

#### what is excellent

"what is most pleasing to God"

#### sincere and without offense

The words "sincere" and "without offense" mean basically the same thing. Paul combines them to emphasize moral purity. AT: "completely blameless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### you also will be filled with the fruit of righteousness that comes through Jesus Christ

Being filled with something is a metaphor that represents being characterized by it or by habitually doing it. Possible meanings of "fruit of righteousness" are that 1) it is a metaphor that represents righteous behavior. AT: "you also will habitually do what is righteous because Jesus Christ enables you" or 2) it is a metaphor that represents good deeds as a result of being righteous. AT: "you also will habitually do good works because Jesus makes you righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to the glory and praise of God

Possible meanings are 1) "Then other people will see how you honor God" or 2) "Then people will praise and give honor to God because of the good things they see you do." These alternate translations would require a new sentence.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Philippians 01:12

#### General Information:

Paul says that two things have happened because of "the progress of the gospel": many people inside and outside the palace have found out why he is in prison, and other Christians are no longer afraid to proclaim the good news.

#### Now I want

Here the word "Now" is used to mark a new part of the letter.

#### brothers

Here this means fellow Christians, including both men and women, because all believers in Christ are members of one spiritual family, with God as their heavenly Father.

#### that what has happened to me

Paul is talking about his time in prison. AT: "that the things I suffered because I was put into prison for preaching about Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### has really served to advance the gospel

"has caused more people to hear the gospel"

#### my chains in Christ came to light

"Chains in Christ" here is a metonym for being in prison for the sake of Christ. "Came to light" is a metaphor for "became known." AT: "It became known that I am in prison for the sake of Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my chains in Christ came to light ... guard ... everyone else

This can be stated in active form. AT: "the palace guards and many other people in Rome know that I am in chains for the sake of Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my chains in Christ

Here Paul uses the preposition "in" to mean "for the sake of." AT: "my chains for the sake of Christ" or "my chains because I teach people about Christ"

#### my chains

Here the word "chains" is a metonym for imprisonment. AT: "my imprisonment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### palace guard

This is a group of soldiers that helped protect the Roman emperor.

#### fearlessly speak the word

"Word" here is a metonym for "message." AT: "fearlessly speak God's message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Philippians 01:15

#### Some indeed even proclaim Christ

"Some people preach the good news about Christ"

#### out of envy and strife

"because they do not want people listening to me, and they want to cause trouble"

#### and also others out of good will

"but other people do it because they are kind and they want to help"

#### The latter

"Those who proclaim Christ out of good will"

#### I am put here for the defense of the gospel

This can be stated in active form. Possible meanings are 1) "God chose me to defend the gospel" or 2) "I am in prison because I defend the gospel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for the defense of the gospel

"to teach everyone that the message of Jesus is true"

#### But the former

"But the others" or "But the ones who proclaim Christ out of envy and strife"

#### while I am in chains

Here the phrase "in chains" is a metonym for imprisonment. AT: "while I am imprisoned" or "while I am in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]

### Philippians 01:18

#### What then?

Paul uses this question to tell how he feels about the situation he wrote about in [Philippians 15-17](./15.md). Possible meanings are 1) this is an idiom that means "It does not matter." or 2) the words "shall I think about this" are understood as part of the question. AT: "What then shall I think about this?" or "This is what I think about it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Only that in every way—whether from false motives or from true—Christ is proclaimed

"As long as people preach about Christ, it does not matter if they do it for good reasons or for bad reasons"

#### in this I rejoice

"I am happy because people are preaching about Jesus"

#### I will rejoice

"I will celebrate" or "I will be glad"

#### this will result in my deliverance

"because people proclaim Christ, God will deliver me"

#### in my deliverance

"Deliverance" here is an abstract noun that refers to one person bringing another person to a safe place. You may have to specify that it is God whom Paul expects to deliver him. AT: "in my being brought to a safe place" or "in God bringing me to a safe place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### through your prayers and the help of the Spirit of Jesus Christ

"because you are praying and the Spirit of Jesus Christ is helping me"

#### Spirit of Jesus Christ

"Holy Spirit"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Philippians 01:20

#### It is my eager expectation and certain hope

Here the word "expectation" and the phrase "certain hope" mean basically the same thing. Paul uses them together to emphasize how strong his expectation is. AT: "I eagerly and confidently hope" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### but that I will have complete boldness

This is part of Paul's expectation and hope. AT: "but that I will be very bold"

#### Christ will be exalted in my body

The phrase "my body" is a metonym for what Paul does with his body. This can be stated in active form. Possible meanings are 1) "I will honor Christ by what I do" or 2) "people will praise Christ because of what I do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### whether by life or by death

"whether I live or die" or "if I go on living or if I die"

#### For to me

These words are emphatic. They indicate that this is Paul's personal experience.

#### to live is Christ

Here pleasing and serving Christ is spoken of as Paul's only purpose for living. AT: "to go on living is an opportunity to please Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to die is gain

Here death is spoken of as "gain." Possible meanings for "gain" are 1) Paul's death will help spread the message of the gospel or 2) Paul will be in a better situation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Philippians 01:22

#### But if I am to live in the flesh

The word "flesh" here is a metonym for the body, and "living in the flesh" is a metonym for being alive. AT: "But if I am to remain alive in my body" or "But if I continue to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yet which to choose?

"But which should I choose?"

#### that means fruitful labor for me

The word "fruit" here refers to the good results of Paul's work. AT: "that means I will be able to work and my work will produce good results" or "then I will have more chances to encourage people to believe in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### For I am hard pressed between the two

Paul speaks of how hard it is for him to choose between living and dying as if two heavy objects, like rocks or logs, were pushing on him from opposite sides at the same time. Your language might prefer the objects to pull rather than push. AT: "I am under tension. I do not know if I should choose to live or to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### My desire is to depart and be with Christ

Paul uses a euphemism here to show that he is not afraid of dying. AT: "I would like to die because I will go to be with Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Philippians 01:25

#### Being convinced of this

"Since I am sure that it is better for you that I stay alive"

#### I know that I will remain

"I know that I will continue to live" or "I know that I will keep on living"

#### so that in me

"so that because of me" or "so that because of what I do"

#### that you are standing firm in one spirit, with one mind striving together for the faith of the gospel

The phrases "standing firm in one spirit" and "with one mind striving together" share similar meanings and emphasize the importance of unity. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### with one mind striving together

"striving together with one mind." Agreeing with one another is spoken of as having one mind. AT: "agreeing with one another and striving together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### striving together

"working hard together"

#### for the faith of the gospel

Possible meanings are 1) "to spread the faith that is based on the gospel" or 2) "to believe and live as the gospel teaches us"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Philippians 01:28

#### Do not be frightened in any respect

This is a command to the Philippian believers. If your language has a plural command form, use it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### This is a sign to them of their destruction, but of your salvation—and this from God

"Your courage will show them that God will destroy them. It will also show you that God will save you"

#### and this from God

"and this is from God." Possible meanings are the word "this" refers to 1) the believers' courage or 2) the sign or 3) destruction and salvation.

#### having the same conflict which you saw in me, and now you hear in me

"suffering in the same way that you saw me suffer, and that you hear I am still suffering"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]

### Philippians 01:intro

#### Philippians 01 General Notes ####

####### Structure and formatting #######

It was possible at this time to begin an informal letter from a religious leader with a prayer. This is how Paul begins this letter. 

####### Special concepts in this chapter #######

######## The day of Christ ########
This is probably a reference to the day when Christ returns. It was common for Paul to connect the return of Christ with motivation for godly living. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]])

####### Other possible translation difficulties in this chapter #######

######## The use of paradox ########

A paradox is a seemingly absurd statement, which appears to contradict itself, but it is not absurd. This statement in 1:21is a paradox: "to die is gain." In 1:23 Paul explains why it is better to die. ([Philippians 1:21](./20.md))

##### Links: #####

* __[Philippians 01:01 Notes](./01.md)__
* __[Philippians intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Philippians 02

### Philippians 02:01

#### Connecting Statement:

Paul advises the believers to have unity and humility and reminds them of Christ's example.

#### If there is any encouragement in Christ

"If Christ has encouraged you "

#### if there is any comfort from his love

"if his love has given you any comfort"

#### if there is any fellowship of the Spirit

"if you have fellowship with the Spirit"

#### if there are any tender mercies and compassions

"if you have experienced many of God's acts of tender mercy and compassion"

#### make my joy full

Paul speaks here of joy as if it were a container that can be filled. AT: "cause me to rejoice greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Philippians 02:03

#### Do nothing out of selfishness or empty conceit

"Do not serve yourselves or think of yourselves as better than others"

#### Each of you should take care not only for your own needs, but also for the needs of others

"Do not care only about what you need, but also about what others need"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]

### Philippians 02:05

#### You should have the same attitude toward one another as was in Christ Jesus

"Have the same attitude that Christ Jesus had" or "Think about one another the way Christ Jesus thought of people"

#### He existed in the form of God
The word translated here as "form"  refers to the true inner nature of something. AT: "He was in nature God" or "He was divine" or "He was truly God"

#### he did not consider his equality with God as something to hold on to

Here "equality" refers to "equal status" or "equal honor." Holding onto equality with God represents demanding that he continue to be honored as God is honored. Christ did not do that. Though he did not cease to be God, he ceased to act as God. AT: "he did not think that he had to have the same status as God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he emptied himself

Paul speaks of Christ as if he were a container in order to say that Christ refused to act with his divine powers during his ministry on earth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he was born in the likeness of men

"he was born a human being" or "he became a human being"

#### became obedient to the point of death

Paul speaks of death here in a figurative way. The translator can understand "to the point of death" either as a metaphor of location (Christ went all the way to death) or as a metaphor of time (Christ was obedient even until the time that he died). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### even death of a cross

"even to dying on a cross"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]

### Philippians 02:09

#### the name that is above every name

Here "name" is a metonym that refers to rank or honor. AT: "the rank that is above any other rank" or "the honor that is above any other honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### above every name

The name is more important, more to be praised than any other name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the name of Jesus

Possible meanings are 1) "when everyone hears the name Jesus" or 2) "in honor of Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### every knee should bend

Here "knee" refers to the whole person, and bending the knee to kneel on the ground is a metonym for worship. AT: "every person will worship God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### under the earth

Possible meanings are 1) the place where people go when they die or 2) the place where demons dwell.

#### every tongue

Here "tongue" refers to the whole person. AT: "every person" or "every being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### to the glory of God the Father

Here the word "to" expresses result: "with the result that they will praise God the Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Philippians 02:12

#### Connecting Statement:

Paul encourages the Philippian believers and shows them how to live the Christian life before others and reminds them of his example.

#### my beloved

"my dear fellow believers"

#### in my presence

"when I am there with you"

#### in my absence

"when I am not there with you"

#### work out your own salvation with fear and trembling

The abstract noun "salvation" can be expressed with a phrase about God saving people. AT: "with fear and trembling, continue to work hard to do what is proper for those whom God saves" or "with awe and reverence for God, work hard to do the good things that show that he has saved you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### with fear and trembling

Paul uses the words "fear" and "trembling" together to show the attitude of reverence that people should have for God. AT: "trembling with fear" or "with deep reverence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### both to will and to work for his good pleasure

"so that you will want to do what pleases him and will be able to do what pleases him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Philippians 02:14

#### blameless and honest

The words "blameless" and "honest" are very similar in meaning and are used together to strenghten the idea. AT: "completely innocent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### so that you may shine as lights in the world

Light represents goodness and truth. Shining as lights in the world represents living in a good and righteous way so that people in the world can see that God is good and true. AT:  "so that you will be like lights in the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the world, in the middle of a crooked and depraved generation

Here the word "world" refers to the people of the world. The words "crooked" and "depraved" are used together to emphasize that the people are very sinful. AT: "in the world, among people who are very sinful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Hold tightly to the word of life

"Hold tightly" represents firmly believing. AT: "Continue to firmly believe the word of life"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the word of life

"Word is a metonym for "message" AT: "the message that brings life" or "the message that shows how to really live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to glory

"to rejoice" or "to be very glad"

#### on the day of Christ

This refers to when Jesus comes back to set up his kingdom and rule over the earth. AT: "when Christ returns"

#### I did not run in vain or labor in vain

The phrases "run in vain" and "labor in vain" here mean the same thing. Paul uses them together to emphasize how hard he has worked to help people believe in Christ. AT: "I did not work so hard for nothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### run

The scriptures often use the image of walking  to represent conducting one's life. Running is living life intensively. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Philippians 02:17

#### But even if I am being poured out as an offering on the sacrifice and service of your faith, I am glad and rejoice with you all

Paul speaks of his death as if he were a drink offering which is poured upon the animal sacrifice to honor God. What Paul means is that he would gladly die for the Philippians if that would make them more pleasing to God. AT: "But, even if the Romans kill me and it is as if my blood pours out as an offering, I will be glad and rejoice with you all if my death will make your faith and obedience more pleasing to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Philippians 02:19

#### Connecting Statement:

Paul tells the Philippian believers about his plan to send Timothy soon and that they should treat Epaphroditus as special.

#### But I have hope in the Lord Jesus

"But I confidently expect the Lord Jesus to allow me"

#### For I have no one else with his same attitude

"No one else here loves you as much as he does"

#### For they all

Here the word "they" refers to a group of people Paul does not feel he can trust to send to Philippi. Paul is also expressing his displeasure with the group, who should have been able to go, but Paul does not trust them to fulfill their mission.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Philippians 02:22

#### as a child serves his father, so he served with me

Paul speaks of Timothy, who served Christ with Paul, as if he were a child serving his father. Paul is emphasizing the close father-son relationship he has with Timothy in serving Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### in the gospel

Here "the gospel" stands for the activity of telling people about Jesus. AT: "in telling people about the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I am confident in the Lord that I myself will also come soon

"I am sure, if it is the Lord's will, that I will also come soon"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Philippians 02:25

#### Epaphroditus

This is the name of a man sent by the Philippian church to minister to Paul in prison. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### fellow worker and fellow soldier

Here Paul is speaking of Epaphroditus as if he were a soldier. He means that Epaphroditus is trained and is dedicated to serving God, no matter how great the hardship he must suffer. AT: "fellow believer who works and struggles along with us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your messenger and servant for my needs

"who brings your messages to me and helps me when I am in need"

#### he was very distressed, and he longed to be with you all

"he was very worried and wanted to be with you all"

#### sorrow upon sorrow

The cause of the sorrow can be made explicit. AT: "the sorrow of losing him added to the sorrow I already have from being in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### Philippians 02:28

#### I can be free from anxiety

"I will be less anxious" or "I will not worry as much as I have been"

#### Welcome Epaphroditus

"Gladly receive Epaphroditus"

#### in the Lord with all joy

"as a fellow believer in the Lord with all joy" or "with the great joy we have because the Lord Jesus loves us"

#### he came near death

Paul here speaks of death as if it were a place that one could go to. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fill up what you could not do in service to me

Paul speaks of his needs as if they were a container that Epaphroditus filled with good things for Paul. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Philippians 02:intro

#### Philippians 02 General Notes ####

####### Structure and formatting #######

Some translations, like the ULB, prefer to set apart the lines of 2:6-11. This is a description of the "mind of Christ." This is an important teaching on the person of Jesus. 

####### Special concepts in this chapter #######

######## Practical instructions ########
This chapter contains many practical instructions that Paul gives to the church in Philippi. 

####### Other possible translation difficulties in this chapter #######

######## "If any" ########
This appears to be a type of hypothetical statement, but it is not because it is assumed to be true. The translator may also translate as "since."

##### Links: #####

* __[Philippians 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Philippians 03

### Philippians 03:01

#### Connecting Statement:

In order to warn his fellow believers about Jews who would try to get them to follow the old laws, Paul gives his own testimony about when he persecuted believers.

#### Finally, my brothers

"Now moving along, my brothers" or "Concerning other matters, my brothers"

#### brothers

See how you translated this in [Philippians 1:12](../01/12.md).

#### rejoice in the Lord

"be happy because of all the Lord has done"

#### For me to write these same things again to you is no trouble for me

"It is no trouble for me to write these things again to you"

#### and it keeps you safe

Here "these things" refers to Paul's teachings. You can add this alternate translation to the end of the previous sentence. AT: "because these teachings will protect you from those who teach what is not true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Watch out for

"Beware of" or "Look out for"

#### the dogs ... those evil workers ... those who mutilate the flesh

These are three different ways of describing the same group of false teachers. Paul is using strong expressions to convey his feeling about these Jewish Christian teachers.

#### dogs

The word "dogs" was used by the Jews to refer to those who were not Jews. They were considered unclean. Paul speaks of the false teachers as though they were dogs, to insult them. If you have a different animal in your culture that is considered unclean or whose name is used as an insult, you could use this animal instead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### mutilate

Paul is exaggerating about the act of circumcision to insult the false teachers. The false teachers said God will only save a person who is circumcised, who cuts off the foreskin. This action was required by the law of Moses for all male Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### For we are

Paul uses "we" to refer to himself and all true believers in Christ, including the Philippian believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### the circumcision

Paul uses this phrase to refer to believers in Christ who are not physically circumcised but are spiritually circumcised, which means they have received the Holy Spirit through faith. AT: "the truly circumcised ones" or "truly God's people"

#### have no confidence in the flesh

"do not trust that only cutting our flesh will please God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Philippians 03:04

#### Even so

"Although if I wanted to." Paul is introducing a hypothetical situation that could not possibly exist. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### I myself could have confidence in the flesh. If anyone thinks he has confidence in the flesh, I could have even more

This is a hypothetical situation that Paul does not believe is possible. Paul says if it were possible that God would save people based on what they did, then God would certainly have saved him. AT: "No one can do enough things to please God, but if anyone could do enough things to please God, I could do more good things and please God more than anyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### I myself

Paul uses "myself" for emphasis. AT: "certainly I" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### I was circumcised

This can be stated in active form. AT: "A priest circumcised me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the eighth day

"seven days after I was born"

#### a Hebrew of Hebrews

Possible meanings are 1) "a Hebrew son with Hebrew parents" or 2) "the purest Hebrew."

#### with regard to the law, a Pharisee

"as a Pharisee, I was completely devoted to the law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]

### Philippians 03:06

#### As for zeal, I persecuted the church

Paul says here that he had been very eager to punish people for following Christ. "I was very determined to hurt Christian believers"

#### as for righteousness under the law, I was blameless

"I obeyed the law completely"

#### whatever things were a profit for me

Paul is referring here to the praise he received for being an eager Pharisee. He speaks of this praise as if he had viewed it in the past as a businessman's profit. AT: "anything that other Jews praised me for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### profit ... loss

These are common business terms. If many people in your culture do not understand formal business terms, you could translate these terms as "things that made my life better" and "things that made my life worse."

#### I considered them as loss

Paul speaks of that praise as if he were now viewing it as a business loss instead of a profit. In other words, Paul says that all his religious acts of righteousness are worthless before Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Philippians 03:08

#### In fact

"Really" or "Truly"

#### now I count

The word "now" emphasizes how Paul has changed since he quit being a Pharisee and became a believer in Christ. AT: "now that I have trusted in Christ, I count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I count all things to be loss

Paul is continuing the business metaphor from [Philippians 3:7](./06.md), saying it is worthless to trust in anything other than Christ. AT: "I consider everything to be worthless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### because of the surpassing value of the knowledge of Christ Jesus my Lord

"because knowing Christ Jesus my Lord is worth so much more"

#### I have given up all things

Use your usual way of expressing the willingness to give up everything you have for Christ, if that is God's will for you.

#### I consider them rubbish

Paul speaks of the things a person may trust in as if it were waste that is thrown out. He is emphasizing how worthless they really are. AT: "I think of them as trash" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so that I may gain Christ

"so that I may have only Christ"

#### be found in him

The phrase "be found" is an idiom that emphasizes the idea of "to be." AT: "be truly united with Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I do not have a righteousness of my own from the law

"I am not trying to please God on my own by obeying the law"

#### the power of his resurrection

"his power that gives us life"

#### the fellowship of his sufferings

"what it is like to suffer as he suffered" or "what it is like to participate in suffering with him"

#### I want to be transformed into the likeness of his death

Possible meanings are 1) Paul wants Christ to change him so that he can die as Christ died or 2) he wants his desire to sin to become as dead as Jesus was before he was raised. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so somehow I may experience the resurrection from the dead

The word "somehow" means Paul does not know what is going to happen to him in this life, but whatever happens, it will result in eternal life. "so that, no matter what happens to me now, I will come back to life after I die"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fellowship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Philippians 03:12

#### Connecting Statement:

Paul urges the believers at Philippi to follow his present example because of heaven and the new bodies that wait for believers. He speaks of how he works as hard as he can to be like Christ, knowing that God will allow him to live forever in heaven, as if he were a runner racing for the finish line.

#### received these things

These include knowing Christ, knowing the power of his resurrection, sharing in Christ's suffering, and being united with Christ in his death and resurrection ([Philippians 3:8-11](./08.md)).

#### or that I have become complete

"so I am not yet perfect" or "so I am not yet mature"

#### But I press on

"But I keep trying"

#### I may grasp that for which I was grasped by Christ Jesus

Receiving spiritual things from Christ is spoken of as if Paul could grasp them with his hands. And, Jesus choosing Paul to belong to him is spoken of as if Jesus grasped Paul with his hands. This can be stated in an active form. AT: "I may receive these things because that is why Jesus claimed me as his own" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Brothers

See how you translated this in [Philippians 1:12](../01/12.md).

#### I myself have yet grasped it

Receiving spiritual things from Christ is spoken of as if Paul could grasp them with his hands. AT: "all these things belong to me yet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I forget what is behind and strain for what is ahead

Like a runner in a race is no longer concerned about the part of the race that is completed but only focuses on what is ahead, Paul speaks of setting aside his religious works of righteousness and only focusing on the race of life that Christ has set before him to complete. AT: "I do not care what I have done in the past; I only work as hard as I can on what is ahead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I press on toward the goal to win the prize of the upward calling of God in Christ Jesus

As a runner presses onward to win the race, Paul presses onward in serving and living in obedience to Christ. AT: "I do all I can to be like Christ, like a runner racing to the finish line, so that I may belong to him, and God may call me to himself after I die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the upward calling

Possible meanings are that Paul speaks of living eternally with God as if God were to call Paul to ascend 1) to heaven as Jesus did or 2) the steps to the podium where winners of races received prizes, as a metaphor for meeting God face to face and receiving eternal life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Philippians 03:15

#### All of us who are mature, let us think this way

Paul wants his fellow believers to have the same desires he listed in [Philippians 3:8-11](./08.md). AT: "I encourage all of us believers who are strong in the faith to think the same way"

#### God will also reveal that to you

"God will also make it clear to you" or "God will make sure you know it"

#### whatever we have reached, let us hold on to it

Paul uses "we" to include the Philippian believers. AT: "let us all continue obeying the same truth we have already received" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]

### Philippians 03:17

#### Be imitators of me

"Do what I do" or "Live as I live"

#### brothers

See how you translated this in [Philippians 1:12](../01/12.md).

#### those who are walking by the example that you have in us

"those who already are living as I live" or "those who already are doing what I do"

#### Many are walking ... as enemies of the cross of Christ

These words are Paul's main thought for this verse.

#### Many are walking

A person's behavior is spoken of as if that person were walking along a path. AT: "Many are living" or "Many are conducting their lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### those about whom I have often told you, and now I am telling you with tears

Paul interrupts his main thought with these words that describe the "many." You can move them to the beginning or end of the verse if you need to.

#### I have often told you

"I have told you many times"

#### am telling you with tears

"am telling you with great sadness"

#### as enemies of the cross of Christ

Here "the cross of Christ" refers to Christ's suffering and death. The enemies are those who say they believe in Jesus but are not willing to suffer or die like Jesus did. AT: "in a way that shows they are actually against Jesus, who was willing to suffer and die on a cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Their end is destruction

"Someday God will destroy them." The last thing that happens to them is that God will destroy them.

#### their god is their stomach

Here "stomach" refers to a person's desires for physical pleasure. Calling it their god means that they want these pleasures more than they want to obey God. AT: "they desire food and other physical pleasures more than they desire to obey God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their pride is in their shame

Here "shame" stands for the actions that the people should be ashamed about but are not. AT: "they are proud of the things that should cause them shame" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They think about earthly things

Here "earthly" refers to everything that gives physical pleasure and does not honor God. AT: "All they think about is what will please themselves rather than what will please God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Philippians 03:20

#### General Information:

By Paul's use of "our" and "we" here, he includes himself and the believers in Philippi. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### our citizenship is in heaven

Possible meanings are 1) "we are citizens of heaven" or 2) "our homeland is heaven" or 3) "our true home is heaven."

#### He will transform our lowly bodies

"He will change our weak, earthly bodies"

#### into bodies formed like his glorious body

"into bodies like his glorious body"

#### body, formed by the might of his power to subject all things to himself

This can be stated in active form. AT: "body. He will change our bodies with the same power he uses to control all things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Philippians 03:intro

#### Philippians 03 General Notes ####

####### Structure and formatting #######

Philippians 3:4-8 contains a list of Paul's "qualifications" for being considered a righteous Jew. In every conceivable way, Paul was an exemplary Jew. He uses this to contrast with the greatness of knowing Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

####### Special concepts in this chapter #######

######## Dogs ########
In the ancient Near East, dogs were used as an image to refer to people in a negative way. Not all cultures will use the term "dogs" in this way and some cultures may have positive connotations associated with dogs. 

######## Resurrected Bodies ########
Very little is known about what people will look like in heaven. It is apparent from this chapter, people will have bodies and they will be free from sin. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Important figures of speech in this chapter #######

######## Prize ########
Paul uses an extended illustration to describe the Christian life. The goal of the Christian life is attempting to grow in likeness to Christ until a person dies. This goal can never be perfectly achieved but must be strived for. 

##### Links: #####

* __[Philippians 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Philippians 04

### Philippians 04:01

#### Connecting Statement:

Paul continues with some specific instructions to the believers in Philippi on unity and then gives instructions to help them live for the Lord.

#### General Information:

When Paul says, "my true companion," the word "you" is singular. Paul does not say the name of the person. He calls him that to show he worked with Paul to spread the gospel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Therefore, my beloved brothers whom I long for

"My fellow believers, I love you and I greatly desire to see you"

#### brothers

See how you translated this in [Philippians 1:12](../01/12.md).

#### my joy and crown

Paul uses the word "joy" to mean that the Philippian church is the cause of his happiness. A "crown" was made of leaves, and a man wore it on his head as a sign of honor after he won an important game. Here the word "crown" means the Philippian church brought honor to Paul before God. AT: "You give me joy because you have believed in Jesus, and you are my reward and honor for my work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in this way stand firm in the Lord, beloved friends

"so continue living for the Lord in the way that I have taught you, dear friends"

#### I am pleading with Euodia, and I am pleading with Syntyche

These are women who were believers and helped Paul in the church at Philippi. AT: "I beg Euodia, and I beg Syntyche" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### be of the same mind in the Lord

The phrase "be of the same mind" means to have the same attitude or opinion. AT: "agree with each other because you both believe in the same Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yes, I ask you, my true companion

Here "you" refers to the "true fellow worker" and is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### true companion

This metaphor is from farming, where two animals would be bound to the same yoke, and so they work together. AT: "fellow worker" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### along with Clement

Clement was a man who was a believer and worker in the church at Philippi. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### whose names are in the Book of Life

"whose names God has written in the Book of Life"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md)]]

### Philippians 04:04

#### Rejoice in the Lord

"be happy because of all the Lord has done." See how you translated this in [Philippians 3:1](../03/01.md).

#### The Lord is near

Possible meanings are 1) The Lord Jesus is near to the believers in spirit or 2) the day the Lord Jesus will return to the earth is near.

#### in everything by prayer and petition with thanksgiving, let your requests be known to God

"whatever happens to you, ask God for everything you need with prayer and thanks"

#### the peace of God

"the peace that God gives"

#### which surpasses all understanding

"which is more than we can understand"

#### will guard your hearts and your thoughts

This presents God's peace as a soldier who protects our emotions and thoughts from worrying. AT: "will be like a soldier and guard your emotions and thoughts from worrying about the troubles of this life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Philippians 04:08

#### Finally

As Paul ends his letter, he gives a summary of how believers should live to have peace with God.

#### brothers

See how you translated this in [Philippians 1:12](../01/12.md).

#### whatever things are lovely

"whatever things are pleasing"

#### whatever things are of good report

"whatever thing people admire" or "whatever things people respect"

#### if there is anything excellent

"if they are morally good"

#### if there is anything to be praised

"and if they are things that people praise"

#### that you have learned and received and heard and seen in me

"that I have taught and shown you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Philippians 04:10

#### Connecting Statement:

Paul begins to thank the Philippians for a gift that they have sent him. He begins in verse 11 to explain that he is thanking them for this gift simply because he is grateful, not because he needs them to give him anything more.

#### to be content

"to be satisfied" or "to be happy"

#### in all circumstances

"no matter what my situation is"

#### I know what it is to be poor ... to have plenty

Paul knows how to live happily having either no possessions or many possessions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### how to be well-fed or to be hungry, and how to have an abundance or to be in need

These two phrases mean basically the same thing. Paul uses them to emphasize that he has learned how to be content in any situation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### I can do all things through him who strengthens me

"I can do all things because Christ gives me strength"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Philippians 04:14

#### Connecting Statement:

Paul continues explaining that he is thanking the Philippians for their gift to him simply because he is grateful, not because he needs them to give him anything more (see [Philippians 3:11](../03/10.md)).

#### in my difficulties

Paul speaks of his hardships as if they were a place that he was in. AT: "when things became difficult" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the beginning of the gospel

Paul refers to the gospel here as meaning his preaching of the gospel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### no church supported me in the matter of giving and receiving except you alone

This can be stated in the positive. AT: "you were the only church that sent me money or helped me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### I seek the fruit that increases to your credit

Paul is speaking of the Philippians' gift as if it were a person's bank account that increases more and more. In this case, it is God who acknowledges the good things done by the Philippian believers. Paul wants the Philippians to give gifts so they can receive spiritual blessings. AT: "I do want to see God give you more and more spiritual blessings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/macedonia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/macedonia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thessalonica.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thessalonica.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Philippians 04:18

#### Connecting Statement:

Paul finishes thanking the Philippians for their gift (see [Philippians 3:11](../03/10.md)) and assures them that God will take care of them.

#### I have received everything in full

Possible meanings are 1) Paul has received everything that the Philippians sent or 2) Paul is using humor to continue the business metaphor from [Philippians 3:8](../03/08.md) and saying that this part of the letter is a receipt for commercial goods that Epaphroditus delivered.

#### even more

Paul means plenty of the things that he needs for himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They are a sweet-smelling aroma, a sacrifice acceptable and pleasing to God

Paul speaks of the gift from the Philippian church as if it were a sacrifice offered to God on an altar. Paul implies that the church's gift is very pleasing to God, like the sacrifices that the priests burned, which had a smell that pleased God. AT: "I assure you these gifts are very pleasing to God, like an acceptable sacrifice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will meet all your needs

This is the same word translated "have been well-supplied" in verse 18. It is an idiom meaning "will provide everything you need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### according to his riches in glory in Christ Jesus

"from his glorious riches that he gives through Christ Jesus"

#### Now to our God

The word "Now" marks the closing prayer and the end of this section of the letter.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Philippians 04:21

#### The brothers

This refers to those people who were either ministering with or to Paul.

#### brothers

See how you translated this in [Philippians 1:12](../01/12.md).

#### every believer ... All the believers

Some versions translate this as "every holy person ... All the holy people."

#### especially those of Caesar's household

This refers to servants who worked in Caesar's palace. "especially the fellow believers who work in the palace of Caesar"

#### with your spirit

Paul refers to the believers by using the word "spirit," which is what enables humans to relate to God. AT: "with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Philippians 04:intro

#### Philippians 04 General Notes ####

####### Special concepts in this chapter #######

######## "My joy and my crown" ########
Paul considered the Philippians' spiritually maturity an important achievement that he helped to achieve. He takes pride in discipling other Christians and encouraging spirtual growth as an important part of the Christian life. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]])

####### Other possible translation difficulties in this chapter #######

######## Euodia and Syntyche ########
Apparently, there was a disagreement between these two women and Paul was encouraging unity and harmony between them. The exact details of their disagreement is insignificant (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Philippians 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | __


## Philippians front

### Philippians front:intro

#### Introduction to Philippians ####

##### Part 1: General Introduction #####

####### Outline of the Book of the Philippians #######

1. Greeting, thanksgiving and prayer (1:1-11)
1. Paul's report on his ministry (1:12-26)
1. Instructions
    - To be steadfast (1:27-30)
    - To be united (2:1-2)
    - To be humble (2:3-11)
    - To work out our salvation with God working in you (2:12-13)
    - To be innocent and light (2:14-18)
1. Timothy and Epaphroditus (2:19-30)
1. Warning about false teachers (3:1-4:1)
1. Personal instruction (4:2-5)
1. Rejoice and do not be anxious (4:4-6)
1. Final remarks
    - Values (4:8-9)
    - Contentment (4:10-20)

####### Who wrote the Book Philippians? #######

Paul wrote Philippians. Paul was from the city of Tarsus. He had been known as Saul in his early life. Before becoming a Christian, Paul was a Pharisee. He persecuted Christians. After he became a Christian, he traveled several times throughout the Roman Empire telling people about Jesus.

Paul wrote this letter while in prison in Rome.

####### What is the Book of Philippians about? #######

Paul wrote this letter to the believers in Philippi, a city in Macedonia. He wrote it to thank the Philippians for the gift they had sent him. He wanted to tell them about how he was doing in prison and to encourage them to rejoice even if they are suffering. He also wrote to them about a man named Epaphroditus. He was the one who brought the gift to Paul. While visiting Paul, Epaphroditus became ill. So, Paul decided to send him back to Philippi. Paul encouraged the believers in Philippi to welcome and to be kind to Epaphroditus when he returns. 

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Philippians." Or they may choose a clearer title, such as "Paul's Letter to the Church in Philippi," or "A Letter to the Christians in Philippi." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### What was the city of Philippi like? #######

Philip, the father of Alexander the Great, founded Philippi in the region of Macedonia. This meant that the citizens of Philippi were also considered citizens of Rome. The people of Philippi were proud of being citizens of Rome. But Paul told the believers that they are citizens of heaven (3:20).

##### Part 3: Important Translation Issues #####

####### Singular and plural "you" #######

In this book, the word "I" refers to Paul. The word "you" is almost always plural and refers to the believers in Philippi. The exception to this is 4:3. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

####### Who were the "enemies of the cross of Christ" (3:18) in this letter? #######

The "enemies of the cross of Christ" were probably people who called themselves believers, but they did not obey God's commands. They thought that freedom in Christ meant that believers could do whatever they desired and God would not punish them (3:19).

####### Why were the words "joy" and "rejoice" frequently used in this letter? #######

Paul was in prison when he wrote this letter (1:7). Even though he suffered, Paul said many times that he was joyful because God had been kind to him through Jesus Christ. He wanted to encourage his readers to have the same trust in Jesus Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

####### What does Paul mean by the expression "in Christ," "in the Lord," etc.? #######

This kind of expression occurs in 1:1, 8, 13, 14, 26, 27; 2:1, 5, 19, 24, 29; 3:1, 3, 9, 14; 4:1, 2, 4, 7, 10, 13, 19, 21. Paul meant to express the idea of a very close union with Christ and the believers. See the introduction to the Book of Romans for more details about this kind of expression.

####### What are the major issues in the text of the Book of Philippians? #######

The following is the most significant textual issue in Philippians:

* Some versions have "Amen" at the end of the final verse in the letter (4:23). The ULB, UDB, and other many modern versions do not.

If "Amen" is included, it should be put inside square brackets ([]) to indicate that it is probably not original to the Book of Philippians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

