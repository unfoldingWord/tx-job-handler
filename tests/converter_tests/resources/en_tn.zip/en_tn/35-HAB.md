# <a id="hab"/>Habakkuk

## Habakkuk 01

### Habakkuk 01:01

#### The message that Habakkuk the prophet received,

These words introduce the first two chapters of the book. It is implicit that Habakkuk received this message from Yahweh. This can be stated as a complete sentence. AT: "This is the message that Habakkuk the prophet received from Yahweh." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### how long shall I cry for help, and you will not hear?

The reader should understand that Habakkuk has been crying to Yahweh for help for a long time. He asks this question because he is frustrated and wants to know how much longer it will be before Yahweh responds. AT: "how much longer shall I cry for help before you will respond?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/habakkuk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/habakkuk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Habakkuk 01:03

#### General Information:

Habakkuk continues his prayer to God.

#### Destruction and violence are before me

The words "destruction" and "violence" can be translated with a verbal phrase. The idiom "before me" means that Habakkuk witnesses these things happening. AT: "I witness people destroying things and acting violently" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### contention rises up

The word "contention" refers to conflict between people and can be translated with a verbal phrase. Habakkuk speaks of there being more contention between people as if contention rises up. AT: "there is more conflict between people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the law is weakened

Habakkuk speaks of people not obeying or enforcing the law as if they had made the law weak and unable to act. AT: "no one enforces the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the wicked surround the righteous

Habakkuk speaks of wicked people causing righteous people to suffer injustice as if the wicked people surrounded the righteous people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### false justice goes out

Habakkuk speaks of judges giving decisions that they say are just but that are not as if "false justice" were going out to the people. AT: "judges give verdicts that are not just" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Habakkuk 01:05

#### General Information:

Yahweh responds to Habakkuk.

#### be amazed and astonished

The words "amazed" and "astonished" share similar meanings. Together they emphasize the strength of the emotion. AT: "be very amazed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### in your days

This idiom refers to Habakkuk's lifetime. AT: "during your lifetime" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### when it is reported to you

This can be stated in active form. AT: "when someone reports it to you" or "when you hear about it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### look!

The word "look!" here alerts us to pay attention to the surprising information that follows.

#### I am about to raise up the Chaldeans

Yahweh speaks of making the Chaldeans powerful as if he were raising them up. AT: "I am about to make the Chaldeans very powerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### impetuous

Possible meanings are 1) "violent" or 2) "hasty."

#### the breadth of the land

This can mean 1) everywhere in Judah or 2) everywhere in the world. This would be an exaggeration to emphasize how powerful the Chaldean army is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### They are terrifying and fearsome

The words "terrifying" and "fearsome" share similar meanings. Together they emphasize the fear that the Chaldeans instilled in other people. AT: "They cause others to be greatly terrified" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### their judgment and splendor proceed from themselves

The word "splendor" represents their pride in how they view themselves. Yahweh speaks of their opinion of themselves as if the qualities of judgment and splendor came from them. AT: "because they are prideful, they decide for themselves what judgment looks like" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/chaldeans.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/chaldeans.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]

### Habakkuk 01:08

#### Their horses ... their horses

the horses of the Chaldean soldiers

#### leopards

large, swift cats (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### the evening wolves

This refers to wolves that hunt their prey at night.

#### their horsemen

the Chaldean soldiers who ride the horses

#### they fly like an eagle hurrying to eat

Yahweh speaks of how quickly the Chaldeans move in order to conquer their enemies as if they were flying, like an eagle flies swiftly to capture its prey. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their multitudes go like the desert wind

Yahweh speaks of how quickly the Chaldeans move as if they were a strong wind that blows in the desert. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they gather captives like sand

Possible meanings are 1) the Chaldeans take people captive as easily as one would scoop up sand with his hand. AT: "they gather captives as one gathers sand" or 2) the Chaldeans take a great number of people captive, as if those people were as many as the grains of sand in the desert. AT: "they capture as many people as there are grains of sand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wolf.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wolf.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]

### Habakkuk 01:10

#### General Information:

Yahweh continues to describe the Chaldean soldiers.

#### So they mock kings, and rulers are only a mockery for them

These two phrases mean basically the same thing. The word "mockery" can be translated with a verbal phrase. AT: "So they mock kings, and rulers are only something for them to mock" or "So all they do is mock kings and rulers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the wind will rush on

Yahweh speaks of how swiftly the Chaldean army moves from one city to the next as it conquers each one as if it were a wind that blows swiftly along. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### guilty men, those whose might is their god

This refers to the Chaldean soldiers.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Habakkuk 01:12

#### General Information:

Habakkuk speaks to Yahweh about the Chaldeans.

#### Are you not from ancient times, Yahweh my God, my Holy One?

Habakkuk asks this rhetorical question to emphasize the positive answer. It can be translated as a statement. AT: "You surely are from ancient times, Yahweh my God, my Holy One." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### from ancient times

"eternal"

#### has ordained them for judgment, and you, Rock, have established them for correction

The word "them" refers to the Chaldeans. The words "judgment" and "correction" can be translated with verbs. The reader should understand that the Chaldeans will judge and correct Yahweh's people. AT: "has ordained them to judge his people, and you, Rock, have established them to correct your people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Rock

Habakkuk speaks of Yahweh being the one who protects him and keeps him safe as if he were a rock upon which Habakkuk could stand in order to be out of his enemies' reach. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Habakkuk 01:13

#### General Information:

Habakkuk continues speaking to Yahweh about the Chaldeans.

#### Your eyes are too pure

Here the word "eyes" represents Yahweh who sees. AT: "You are too pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### those who betray

This refers to the Chaldeans. The word "betray" refers to people who have been disloyal or have broken agreements that they have made.

#### Why are you silent while the wicked swallow up those more righteous than they are?

Habakkuk speaks of wicked people destroying others as if the wicked were swallowing them. AT: "Why are you silent while the wicked destroy those more righteous than they are?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### those more righteous than they are

This refers to the Israelites, about whom Habakkuk had been complaining. The reader should understand that these are wicked people, but they are "more righteous than" or not as wicked as the Chaldeans. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### You make men like fish in the sea

Habakkuk compares the way in which the Chaldeans will kill people without remorse with the way in which people will kill fish without remorse. AT: "You cause men to become no more important than fish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### like creeping things without a ruler over them

The words "creeping things" refer to insects and other bugs that crawl about. Just as insects have no ruler to organize and defend them, the people are defenseless before the Chaldean army. The verb may be supplied from the previous phrase. AT: "you make men as defenseless as insects that have no ruler" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Habakkuk 01:15

#### General Information:

Habakkuk continues speaking to Yahweh about the Chaldeans.

#### He brings ... he continually slaughter

In 1:15-17 the singular pronoun "he" and "his" refer to a Babylonian solider who represents all of the Babylonian soldiers. These pronouns can be stated as plural. AT: "They bring ... they continually slaughter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### all of them ... drags men away ... gathers them

Here "them" and "men" refer to people in general. This can be stated in first person to include Habakkuk as one of the people. AT: "all of us ... drags us away ... gathers us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### He brings all of them up with a fishhook ... in his dragnet

Habakkuk speaks of the Chaldeans conquering people easily as if the people were fish that the Chaldeans catch with fishhooks and fishnets. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fishhook ... fishnet ... dragnet

tools used to catch fish

#### he sacrifices to his net and burns incense to his dragnet

Habakkuk speaks of the weapons that the Chaldeans use to conquer people and nations as if the weapons were fishing nets that they use to catch fish. AT: "they offer sacrifices and burn incense to the weapons that they use in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Will he therefore keep emptying his net, and will he continually slaughter the nations without mercy?

Habakkuk asks this question because he is frustrated and wants to know how long Yahweh will allow the Chaldeans to continue to destroy people and nations. AT: "Will you therefore let them empty their fishing nets and continue to slaughter the nations while they feel no compassion?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### keep emptying his net

Habakkuk speaks of the Chaldeans preparing to conquer more nations as if they were fishermen who empty their nets so that they can use them to catch more fish. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]

### Habakkuk 01:intro

#### Habakkuk 01 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 1:1-17.

This chapter is arranged in a series of questions and answers between Yahweh and Habakkuk.

####### Special concepts in this chapter #######

######## Injustice ########

Habakkuk sees great injustice, especially in the defeat of Israel by the Assyrians. He cries out to Yahweh to ask him to put an end to it. He is questioning Yahweh, but he trusts in him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]])

######## Chaldeans ########
Yahweh will raise up the Chaldeans to bring justice to the Hebrew people. They will defeat the Assyrians. At this time, the Chaldeans were an insignificant city and people group. This was probably intended to show the power of Yahweh.

##### Links: #####

* __[Habakkuk 01:01 Notes](./01.md)__
* __[Habakkuk intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Habakkuk 02

### Habakkuk 02:01

#### I will stand at my guard post and station myself on the watchtower

These two phrases mean basically the same thing. Possible meanings are 1) Habakkuk went to an actual post in the watchtower or 2) this is a metaphor in which Habakkuk speaks of waiting eagerly for Yahweh's response as if he were a watchman waiting at his post for the arrival of a messenger. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to see what he will say to me

"to see what Yahweh will say to me"

#### how I should turn from my complaint

Here the word "turn" refers to returning an answer. Habakkuk considers what answer he will give concerning the things that he has said. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]

### Habakkuk 02:02

#### General Information:

Yahweh answers Habakkuk.

#### Record this vision, and write plainly on the tablets

Both of these phrases are saying the same thing in two different ways. AT: "Write this vision clearly on the tablets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### tablets

These are flat pieces of stone or clay that were used for writing.

#### so that the one reading them might run

Possible meanings are 1) that the message is easy enough to read that a messenger can read it as he runs from place to place proclaiming the message. AT: "so that the one reading the tablets might be able to run as he reads" or 2) this is a metaphor in which Yahweh speaks of reading something very quickly as if the person who reads it is running. AT: "so that the one reading the tablets might be able to read quickly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the vision ... will finally speak

Yahweh speaks of the events in the vision happening as if the vision were a person who speaks. AT: "the vision ... will finally happen" or "the vision ... will finally come true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Though it delays, wait for it. For it will surely come and will not tarry

Yahweh speaks of the events of the vision taking a long time to happen as if the vision were a person who does not arrive soon at his destination. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### will not tarry

Possible meanings are 1) "will not be late" or 2) "will not come slowly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]

### Habakkuk 02:04

#### General Information:

Yahweh continues to answer Habakkuk. Here he speaks of the Chaldeans as if they were one prideful, drunken man who can never have enough. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Look!

The word "Look!" here adds emphasis to what follows.

#### is puffed up

Yahweh speaks of the person who is prideful as if the person were "puffed up." AT: "is very prideful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For wine is a betrayer of the arrogant young man

Yahweh speaks of how a person's judgment is impaired by drinking too much wine as if wine were a person who betrays the one who drinks it. AT: "For the arrogant young man does not get from wine what he wants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### so that he will not abide

Here the word "abide" refers to dwelling in a home and is a metaphor for having no place to rest. AT: "so that he will not be able to rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### enlarges his desire like the grave and, like death, is never satisfied

Yahweh speaks of there always being more people to die as if "the grave" and "death" were people who are never satisfied with eating. In the same way, this person always wants more and is never satisfied. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He gathers to himself every nation and gathers up for himself all of the peoples

These two phrases mean basically the same thing. Yahweh speaks of conquering nations and capturing the people as if it were gathering nations and peoples to oneself. AT: "He conquers for himself the people of every nation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Habakkuk 02:06

#### General Information:

Yahweh continues to answer Habakkuk and to speak of the Chaldeans as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Will not all these create

The words "all these" refer to the nations and peoples from [Habakkuk 2:5](./04.md). This negative rhetorical question emphasizes the positive answer. It can be translated as a statement. AT: "All of these nations and peoples will certainly create" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Woe to the one increasing what is not his

It is implicit that he is increasing his possession of things that do not belong to him. AT: "Woe to the one who claims for himself more and more things that do not belong to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### For how long will you increase the weight of the pledges you have taken?

The word "pledges" refers to objects that people give to others from whom they have borrowed money as a guarantee that they will repay their debt. As the man collects more and more pledges, the total weight of the pledges that he carries increases.

#### For how long will you increase the weight of the pledges you have taken?

The Chaldeans robbing the people of the nations of their wealth is spoken of as if the Chaldeans were a person who forces others to give him pledges and to pay him what they do not owe. AT: "For how long will you make yourself rich by extorting others?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Will the ones biting at you not rise up suddenly, and the ones terrifying you awaken?

This negative rhetorical question emphasizes the positive answer. It can be translated as a statement. AT: "The ones biting at you will certainly rise up suddenly, and the ones terrifying you will awaken." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the ones biting at you

The Hebrew word translated here as "the ones biting" can also mean "the ones paying interest" or "debtors." In this context, the word probably has both meanings. The phrase is a metaphor in which those whom the man has oppressed and made debtors by forcing them to give him pledges will now oppress him, which is spoken of as if they were biting him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the ones terrifying you

This refers to the same debtors. They will terrify the Chaldeans by attacking them in revenge for the pledges that they were forced to give.

#### rise up ... awaken

The people of the nations beginning to act against the Chaldeans is spoken of as if they were to "rise up" and to "awaken" from sleep. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### plunder

to rob or take things by force

#### you have shed human blood

The idiom "to shed blood" means "to murder." AT: "you have murdered people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### Habakkuk 02:09

#### General Information:

Yahweh continues to answer Habakkuk and to speak of the Chaldeans as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the one who carves out evil gains

A person making a profit by violent means is spoken of as if he were "carving out" gains from something. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the one who carves out evil gains for his house

Possible meanings are 1) the word "house" is a metaphor in which the Babylonian empire is spoken of as if it were a house that the man builds by means of profits that he gained through violence. AT: "the one who builds his house with riches that he gained through violence" or 2) the word "house" is a metonym for "family" and the man has made his family rich through violence. AT: "the one who makes his family rich by violent means" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so he can set his nest on high to keep himself safe from the hand of evil

The person who builds his house is spoken of as if he were a bird that builds its nest in a high place. The man thinks that his house is secure and free from danger, just as predators are unable to reach the nest. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### safe from the hand of evil

Here the word "hand" is a metonym for power, and the word "evil" is a metonym for people who do evil things. AT: "safe from the power of evil" or "safe from people who will harm him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You have devised shame for your house

Here to "devise shame" means that the plans that the man devised have resulted in shame. One possible meaning is that the word "house" is a metaphor in which the Babylonian empire is spoken of as if it were a house that the man has built. AT: "By your plans, you have brought shame on the house that you have built" Another possibility is that the word "house" is a metonym for "family." AT: "By your plans, you have brought shame on your family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### cutting off many people

Killing many people is spoken of as if it were cutting those people off, like one would cut a branch from a tree. AT: "killing many people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### have sinned against yourself

The idiom "to sin against oneself" means that the person has done things that will result in his own death or destruction. AT: "have caused your own ruin" or "have brought about your own death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### For the stones will cry out from the wall, and the rafters of timber will answer them

Here the materials with which the man has built his house are personified as witnesses of the crimes that he has committed. If your culture uses different materials to build houses, you can consider using those materials here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### cry out

"cry out against you" or "cry out to accuse you"

#### will answer them

"will agree with the stones"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]

### Habakkuk 02:12

#### General Information:

Yahweh continues to answer Habakkuk and to speak of the Chaldeans as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Woe to the one who builds a city with blood, and who establishes a town in iniquity

These two phrases are saying the same thing in different ways. AT: "A warning to the Chaldeans who built their cities with what they have stolen from the people they have killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the one who builds a city with blood

Here the word "blood" is a metonym for murder. It is implicit that the person builds a city by means of the goods that he stole from those whom he has killed. AT: "the one who kills people and steals their goods in order to build a city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who establishes a town in iniquity

It is implicit that the person builds a city by means of the goods that he stole from those whom he has killed. Here the word "establishes" means "to begin." AT: "who starts a town by means of the profit that he has acquired through evil behavior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Is it not from Yahweh of hosts that peoples labor for fire and all the other nations weary themselves for nothing?

This negative rhetorical question emphasizes the positive answer that it anticipates. The two clauses share similar meanings that the work that people do will not last. The question can be translated as a statement. AT: "Yahweh is the one who has determined that the things that people work hard to build will be destroyed by fire and result in nothing." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### peoples labor for fire

This means that the things that people labor to build are ultimately destined to be fuel for fire. AT: "peoples labor to build things that will be used as fuel for fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the land will be filled with the knowledge of the glory of Yahweh as the waters cover the sea

This simile compares the way in which people everywhere will know of Yahweh's glory with how water fills every part of the sea. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the land will be filled with the knowledge of the glory of Yahweh

The word "knowledge" can be translated with a verbal phrase. This can be stated in active form. AT: "people throughout the land will know the glory of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Habakkuk 02:15

#### General Information:

Yahweh continues to answer Habakkuk and to speak of the Chaldeans as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the one who forces his neighbors to drink ... you make them drunk

The way that the Chaldeans cruelly treated other nations is spoken of as if they were a man who forces his neighbors to become drunk so that he can humiliate them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the one who forces his neighbors to drink

It is implied that he makes his neighbor drink wine. AT: "the one who forces his neighbors to drink wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in order to look at their nakedness

"so you can look at them when they are naked." This refers to the practice of publicly humiliating people by stripping them naked in front of others. AT: "so that you can humiliate them publicly by stripping them naked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You will be filled with shame instead of glory

The Chaldeans passionately pursuing their own glory is spoken of as if they were eating or drinking it greedily and excessively. Instead of attaining glory, they will find only shame. AT: "You will bring shame upon yourself instead of the glory that you seek" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Drink

Others treating the Chaldeans the way that the Chaldeans had treated others is spoken of as if the Chaldeans were to drink the wine that they had forced others to drink. AT: "Drink from the cup" or "Drink the wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you will expose your uncircumcised foreskin

This phrase is similar to the Chaldeans forcing others to strip naked so that they could look at their nakedness. Here the words "uncircumcised foreskin" indicate that they will be humiliated not just by being naked, but because their uncircumcision proves that they do not belong to Yahweh's people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The cup in Yahweh's right hand is coming around to you

Yahweh punishing the Chaldeans is spoken of as if he were forcing them to drink wine from a cup that he holds in his hand. Yahweh's right hand represents his power. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The cup in Yahweh's right hand

"The cup that Yahweh holds in his right hand" or "The cup that Yahweh is holding"

#### is coming around to you

"will come to you as it did to others" or "will pass along to you"

#### disgrace will cover your glory

The Chaldeans experiencing disgrace instead of glory is spoken of as if disgrace were an object that covers the glory that they thought they had. AT: "disgrace will replace your glory" or "people will disgrace you instead of honor you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Habakkuk 02:17

#### General Information:

Yahweh continues to answer Habakkuk and to speak of the Chaldeans as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The violence done to Lebanon will overwhelm you

The Chaldeans being punished for the violence done to Lebanon is spoken of as if their violent actions were a person who will overpower them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The violence done to Lebanon

Possible meanings for the word "Lebanon" are 1) it represents the forest of Lebanon. AT: "The violence done to the trees of Lebanon" or 2) it represents the people of Lebanon. AT: "The violence done to the people of Lebanon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the destruction of animals will terrify you

The Chaldeans being punished for destroying the animals in Lebanon is spoken of as if their destruction were a person who will terrify them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### For you have shed human blood ... all who live in them

See how you translated this sentence in [Habakkuk 2:8](./06.md).

#### you have shed human blood

The idiom "to shed blood" means "to murder." AT: "you have murdered people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### Habakkuk 02:18

#### General Information:

Yahweh continues to answer Habakkuk and to speak of the Chaldeans as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### What does the carved figure profit you?

This rhetorical question emphasizes the negative answer that it anticipates. The question can be translated as a statement. AT: "The carved figure profits you nothing!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### you

The word "you" refers to the Chaldeans.

#### molten metal

This describes metal when it is in its liquid form.

#### a teacher of lies

This phrase refers to the one who carved or cast the figure. By making a false god, he is teaching a lie.

#### Or to the silent stone

The verb may be supplied from the previous phrase. AT: "Woe to the one saying to the silent stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Do these things teach?

This rhetorical question emphasizes the negative answer that it anticipates. The question can be translated as a statement. AT: "These things cannot teach." or "Wood and stone cannot teach." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### See, it is overlaid

"Look at it. You can see for yourself that it is overlaid"

#### it is overlaid with gold and silver

This can be stated in active form. AT: "a person overlays the wood or stone with gold and silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### there is no breath at all within it

The idiom "no breath ... within it" means that it is not alive, but dead. AT: "it is not alive" or "it is dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### all the land

Here the word "land" is a metonym for the people who live in the land. AT: "everyone in the land" or "everyone on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### Habakkuk 02:intro

#### Habakkuk 02 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 2:1-20.

This chapter is arranged in a series of questions and answers between Yahweh and Habakkuk.

####### Special concepts in this chapter #######

######## "The righteous will live by his faith" ########
This is an important phrase in Scripture. Paul also uses it to explain that man is justified by his faith. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

##### Links: #####

* __[Habakkuk 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Habakkuk 03

### Habakkuk 03:01

#### The prayer of Habakkuk the prophet:

These words introduce the third chapter of this book. This can be stated as a complete sentence. AT: "This is the prayer that Habakkuk the prophet prayed to Yahweh." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I have heard your report

Possible meanings are 1) "I have heard people talk about what you have done in the past" or 2) "I have heard what you just said."

#### revive your work

Habakkuk speaks of Yahweh doing again the things that he has done in the past as if Yahweh were to cause his work to live again. AT: "bring your work back to life" or "what you did before, do again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the midst of these times

This idiom refers to the time at which Habakkuk prayed this prayer, as opposed to times when Yahweh had acted in the past to rescue his people. AT: "in our own times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### make it known

"make your work known" or "cause people to know your work"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Habakkuk 03:03

#### General Information:

Habakkuk begins to describe his vision of Yahweh coming to judge his enemies and to save his people. The vision continues through [Habakkuk 3:15](./14.md). It is full of metaphorical language and uses different kinds of parallelism. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### God came from Teman, and the Holy One from Mount Paran

Teman and Mount Paran were both located south of Judah. Habakkuk speaks of God coming to Judah from the direction of Mount Sinai.

#### His glory covered the heavens

"His splendor covered the sky." Here the word "glory" refers to the bright light that biblical writers often associate with God's presence.

#### the earth was full of his praise

Here the word "praise" is a metonym for God's qualities that cause people to praise him. AT: "the earth was full of his glory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/selah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/selah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Habakkuk 03:04

#### General Information:

Habakkuk continues to describe his vision of Yahweh.

#### With brightness like the light

Here the word "brightness" likely refers to the brightness that is often associated with Yahweh's glory. Possible meanings are 1) the brightness of Yahweh's glory was like flashes of lightning or 2) the brightness of Yahweh's glory was like the rising of the sun.

#### two-pronged rays flash from his hand

Habakkuk speaks of flashes of lightning as if they were two-pronged weapons that Yahweh holds in his hand. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### there he hid his power

The word "there" refers to Yahweh's hand. Possible meanings are 1) the lightning bolts that Habakkuk can see are only a small representation of the full power that he cannot see hidden in Yahweh's hand or 2) Yahweh hides his power in his hand until he is ready to use it.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]

### Habakkuk 03:06

#### General Information:

Habakkuk continues to describe his vision of Yahweh.

#### He stood

This means that Yahweh stopped walking and stood still, not that he stood up from a seated position.

#### measured the earth

Possible meanings are 1) the word translated as "measured" can be "shook" or 2) he surveyed the earth the way a conqueror would before assigning portions to his governors.

#### eternal mountains ... everlasting hills

"mountains that have existed since the beginning of time ... hills that will exist until the end of time." If your language has no different words for "hills" and "mountains" or for "eternal" and "everlasting," you can combine them as the UDB has done.

#### Even the eternal mountains were shattered

This can be stated in active form. AT: "Even the eternal mountains crumbled" or "He shattered even the eternal mountains" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the everlasting hills bowed down

The hills being flattened like level ground is spoken of as if they were people who bow down before Yahweh. AT: "the everlasting hills collapsed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### His path is everlasting

Possible meanings are 1) the words "His path" may be a metaphor that speaks of Yahweh and his actions as a path on which he walks. AT: "He is everlasting" or 2) Habakkuk speaks of the path upon which Yahweh walks in the vision as being everlasting, indicating that this is the same path that Yahweh had taken in ancient times. AT: "He walks along an ancient path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Habakkuk 03:07

#### General Information:

Habakkuk continues to describe his vision of Yahweh.

#### I saw the tents of Cushan in affliction, and the fabric of the tents in the land of Midian trembling

Possible meanings are 1) the words "the tents" and "the fabric of the tents" are metonyms for the people who live in those tents. AT: "I saw the people who live in tents in the land of Cushan in affliction, and the people who live in tents in the land of Midian trembling" or 2) this is a metaphor in which Habakkuk speaks of the tents in Cushan and Midian being blown about by a storm as if the tents were people who were trembling in affliction. AT: "I saw the tents of Cushan blown about like people in affliction, and the fabric of the tents in the land of Midian trembling as if they were people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Cushan

This can be 1) the name of a people group otherwise unknown or 2) the same as Cush. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### you rode upon your horses and your victorious chariots

The phrases "your horses" and "your victorious chariots" both refer to the same thing. This speaks of Yahweh as if he were a warrior riding a horse-drawn chariot into battle. AT: "you rode your horse-drawn chariots to victory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]

### Habakkuk 03:09

#### General Information:

Habakkuk continues to describe his vision of Yahweh.

#### You have brought out your bow without a cover

This means that Yahweh has removed his bow from its protective case and is prepared to shoot. AT: "You have prepared to shoot your bow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You divided the earth with rivers

Possible meanings are 1) "You created rivers that divide the lands through which they run" or 2) "You split open the earth and rivers flowed forth."

#### The mountains saw you and twisted in pain

The effects that Yahweh's presence has on the mountains is spoken of as if the mountains were people who writhe in pain. This may refer either to the mountains shaking from an earthquake or to the water from the storm eroding the sides of the mountains as the streams flow down. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Downpours of water passed over them

Possible meanings are 1) torrential rains fell on the mountains or 2) the rain caused raging streams to flow down the mountains.

#### the deep sea raised a shout

The loud noises that the sea makes as the wind and storm pass over it are spoken of as if the sea were a person who begins to shout loudly. AT: "the deep sea became loud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### It lifted up its waves

The level of the water in the sea rising and the storm winds causing waves in the sea is spoken of as if the sea were a person who lifts its waves. AT: "Waves began to form in the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]

### Habakkuk 03:11

#### General Information:

Habakkuk continues to describe his vision of Yahweh.

#### The sun and moon stood still

The sun and moon not moving in the sky is spoken of as if they were people who stopped walking and stood still. AT: "The sun and moon stopped moving" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### in their high places

"in the sky"

#### at the flash of your arrows ... at the lightning of your flashing spear

These two phrases share similar meanings and tell why the sun and moon have stood still. The lightning flashes in the sky are spoken of as if they were arrows that Yahweh shoots from his bow or a shining spear that he throws through the sky. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the flash of your arrows as they fly

"the flash of your flying arrows"

#### indignation

"great anger" or "fury"

#### you have threshed the nations

Yahweh punishing the people of the nations is spoken of as if he threshed the nations. Threshing refers to the practice of having an ox or some other animal trample upon grain stalks in order to crush them and remove the grain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Habakkuk 03:13

#### General Information:

Habakkuk continues to describe his vision of Yahweh. The last sentence in this verse is difficult to translate. Read each of the translationNotes on that sentence below to see different ways to translate it.

#### You went out for the salvation of your people

The word "salvation" can be translated with a verb. AT: "You went out to save your people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### your anointed one

"the one whom you have anointed." Here this phrase refers to one whom Yahweh has chosen. Possible meanings are 1) "the people you have chosen" or "the nation you have chosen" or 2) "the king you have chosen."

#### You shatter the head of the house of the wicked to lay bare from the base up to the neck

Possible meanings are 1) killing the leader and destroying the people is spoken of as if someone were destroying a house. Here the leader is the head, that is, the roof of the house; and "base" and "neck" represent other parts of the house. AT: "You destroy the roof of the wicked house and demolish the rest of the building" or "You kill the leader of the wicked nation and completely destroy the nation" or 2) Killing the leader and removing honor and power from the people is spoken of as if someone were shattering a person's head and stripping off all of his clothes. Here the leader is the "head," and "house" represents the people who are the body. AT: "The wicked people and their leader are like a man whose head you crush and whose body you strip naked from foot to neck" or "You kill the leader of the wicked people and completely remove all of the people's power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Habakkuk 03:14

#### General Information:

Habakkuk continues to describe his vision of Yahweh.

#### You have pierced the head of his warriors with his own arrows

The word "his" refers to the leader of the Chaldeans. Possible meanings are 1) this is a metaphor in which the warriors are spoken of as if they were a body and the leader were the head. AT: "You have killed with his own spear the one who leads the warriors" or 2) the word "head" refers to the heads of each of the warriors. AT: "With the leader's own spear, you have pierced the heads of each of his warriors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they came like a storm

The power and quickness of the Chaldeans as they attacked the people of Israel is compared to the coming of a sudden storm. AT: "they came quickly like a storm" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### their gloating was like one who devours the poor in a hiding place

The word "gloating" here means to rejoice for bad reasons and can be translated with a verb. The warriors treating people cruelly or killing them is spoken of as if the warriors were wild beasts who carry their prey to their hiding places in order to eat it. AT: "they gloated like a person who secretly abuses poor people" or "they rejoiced when they oppressed the poor, acting as if they would eat them like a beast eats its prey in its den" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### heaped up the great waters

Yahweh causing the waters to surge is spoken of as if he heaped the water up into piles. AT: "caused the great waters to surge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Habakkuk 03:16

#### General Information:

Habakkuk describes his reaction to his vision of Yahweh.

#### I heard

You may indicate what it is that Habakkuk heard. Possible meanings are 1) "I heard everything in that vision" or 2) "I heard Yahweh approach like a great storm" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### my inner parts trembled

The word translated here as "inner parts" is literally "belly." If your language has a specific internal organ that it uses to express the feeling of great fear, you can consider using it here. AT: "my heart beat rapidly" or "my stomach turned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### My lips quivered at the sound

Quivering lips is another spontaneous response that comes with great fear.

#### Decay comes into my bones

Habakkuk speaks of having no strength in his body as if his bones began to decay. You may consider using an idiom from your own language here. AT: "My body goes limp, as if my bones were rotting" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### under myself I tremble

The words "under myself" refer to what is below him. Possible meanings for the idiom are 1) "my legs tremble" or 2) "I tremble where I stand." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

### Habakkuk 03:17

#### General Information:

Habakkuk describes his reaction to his vision of Yahweh.

#### though the produce of the olive tree disappoints

"though the produce of the olive tree fails" or "though the olive tree fails to produce olives"

#### though the flock is cut off from the fold

The word "flock" may refer to sheep or goats, or both. The word "fold" refers to the fenced-in area where shepherds keep their flock. Habakkuk speaks of the flock dying as if someone were to cut off the flock, as a person would cut a branch from a tree. AT: "though all the flock dies and the folds are empty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Habakkuk 03:18

#### General Information:

Habakkuk continues to describe his reaction to his vision of Yahweh and determines to praise him.

#### the God of my salvation

The word "salvation" can be translated with a verb. AT: "the God who saves me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### he makes my feet like the deer's. He makes me go forward on my high places

Habakkuk speaks of Yahweh keeping him safe and enabling him to survive during difficult times as if Yahweh were to make him as sure-footed as a deer that can climb easily on rugged and dangerous mountain sides. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md)]]

### Habakkuk 03:intro

#### Habakkuk 03 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 3:1-19.

####### Special concepts in this chapter #######

######## Poetry ########
Although this is a prayer, it is in the form of poetry. Habakkuk uses startling imagery to show his fear of Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]])

##### Links: #####

* __[Habakkuk 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | __


## Habakkuk front

### Habakkuk front:intro

#### Introduction to Habakkuk ####

##### Part 1: General Introduction #####

####### Outline of Habakkuk #######

1. Will sins go unpunished? (1:1–4)
1. Yahweh's answer: The Babylonians are his chosen instruments to punish Israel (1:5–11)
1. How can Yahweh use wicked, unholy, godless people as his instruments of punishment? (1:12–2:1)
1. Yahweh's answer: All people will be punished, but the "righteous will live by his faith" (2:2–4)
1. The five woes of Habakkuk 
    - Woe against the thieves (2:6–8)
    - Woe against those who use unjust means to gain riches (2:9–11)
    - Woe against those who kill in order to build a town (2:12–14)
    - Woe against those who abuse their neighbors and do violence to them (2:15–18)
    - Woe against those who worship idols when Yahweh is in his holy temple (2:19–20)
1. The prayer of Habakkuk about the glory of Yahweh (3:1–19) 

####### What is the Book of Habakkuk about? #######

While many other prophets complained about Israel's sin and failure to obey the law of Yahweh, Habakkuk questioned Yahweh about the things he did. God said he would punish the people of Judah by sending the Babylonian army. Habakkuk complained because the Babylonians were more wicked than the people of Judah. God assured Habakkuk that he would also punish the Babylonians. Justice is a major concern for Habakkuk in this book. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]])

####### How should the title of this book be translated? #######

Translators may decide to translate this traditional title "The Book of Habakkuk" in a way that is clearer to the readers. They may decide to call it "The Sayings of Habakkuk." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote Habakkuk? #######

Very little is known about Habakkuk. The Chaldean empire, another name for the Babylonian empire, was mentioned in several places in Habakkuk. This helps us to date Habakkuk's life. The Chaldean empire had power from about 720 to 538 BC. It is probable that Habakkuk worked about the time of Jeremiah, Zephaniah, and Nahum during the reigns of Kings Josiah, Jehoahaz, and Jehoiakim in Judah.

##### Part 2: Important Religious and Cultural Concepts #####

####### Why did God use an evil nation to punish Judah? #######

Habakkuk wanted to know why God used an evil nation to punish Judah. In this book it is explained that everyone who does evil must be punished. However, it is God who determines when and how to punish the person.

##### Part 3: Important Translation Issues #####

####### How do I identify the speaker? #######

It should be noted that Habakkuk often spoke to Yahweh and Yahweh replied to him. The translator should be careful to identify whether the speaker is Habakkuk or Yahweh in each section. The translator may wish to make the identity of the speaker explicit. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### What style of writing is the Book of Habakkuk? #######

While much of the book of Habakkuk is a conversation between the prophet and God, the third chapter is a psalm. This chapter contains information about how to sing this psalm. The author included musical terms. 

####### Does Habakkuk question or challenge God? #######

There are times when Habakkuk spoke directly to God in a way that can be interpreted as challenging God. Habakkuk was not intending to question the authority of Yahweh. He was telling God that he does not understand what God is doing. In some cultures, it may be improper to speak to an authority in this way. It may be necessary to rephrase Habakkuk's questions to emphasize his sincere desire to learn why God is doing what he is doing, without doubting him.



---

