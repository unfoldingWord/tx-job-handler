# <a id="gal"/>Galatians

## Galatians 01

### Galatians 01:01

#### General Information:

Paul, an apostle, writes this letter to the churches in the area of Galatia.

#### General Information:

Unless noted otherwise, all instances of "you" and "your" in this letter refer to the Galatians and are plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### who raised him

"who raised Jesus Christ"

#### raised

"Raised" here is an idiom for "caused to live again" AT: "whom God caused to live again"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### brothers

Here this means fellow Christians, including both men and women, since all believers in Christ are members of one spiritual family, with God as their heavenly Father. AT: "brothers and sisters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galatia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galatia.md)]]

### Galatians 01:03

#### for our sins

"Sins" represents the punishment for sin. AT: "to take the punishment we deserved because of our sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### that he might deliver us from this present evil age

Here "this ... age" represents the powers at work in the age. AT: "that he might bring us to a place of safety from the evil powers at work in the world today" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### deliver

"Deliver" here is a metaphor for "bring to a place of safety." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### our God and Father

This refers to "God our Father." He is our God and our Father.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Galatians 01:06

#### Connecting Statement:

Paul gives his reason for writing this letter: he reminds them to continue to understand the gospel.

#### I am amazed

"I am surprised" or "I am shocked." Paul was disappointed that they were doing this.

#### you are turning away so quickly from him ... to a different gospel

"Turning away" here is an idiom for "changing direction toward." Possible meanings are 1) "you have so quickly stopped trusting in him" or 2) "you have so quickly stopped being loyal to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### him who called you

"God, who called you"

#### called

Here this means God has appointed or chosen people to be his children, to serve him, and to proclaim his message of salvation through Jesus.

#### by the grace of Christ

"because of Christ's grace" or "because of Christ's gracious sacrifice"

#### you are turning to a different gospel

"Turning" here is an idiom for "changing direction toward." AT: "you are instead believing a different gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### men

"people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]

### Galatians 01:08

#### should proclaim

This is describing something that has not happened and should not happen. AT: "would proclaim" or "were to proclaim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### other than the one

"different from the gospel" or "different from the message"

#### let him be cursed

"God should punish that person forever." If your language has a common way of calling a curse down on someone, you should use that.

#### For am I now seeking the approval of men or God? Am I seeking to please men?

These rhetorical questions expect the answer "no." AT: "I do not seek the approval of men, but instead I seek the approval of God. I am not seeking to please men." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### If I am still trying to please men, I am not a servant of Christ

Both the "if" phrase and the "then" phrase are contrary to fact. "I am not still trying to please men; I am a servant of Christ" or "If I were still trying to please men, then I would not be a servant of Christ"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Galatians 01:11

#### Connecting Statement:

Paul explains that he did not learn the gospel from others; he learned it from Jesus Christ.

#### brothers

See how you translated this in [Galatians 1:2](./01.md).

#### not man's gospel

By using this phrase, Paul was not trying to say that Jesus Christ is not himself human. Because Christ is both man and God, however, he is not a sinful human being. Paul is writing about where the gospel came from; that it did not come from other sinful human beings, but it came from Jesus Christ.

#### it was by revelation of Jesus Christ to me

Possible meanings are 1) "Jesus Christ himself revealed the gospel to me" or 2) "God made me know the gospel when he showed me who Jesus Christ was."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Galatians 01:13

#### former life

"behavior at one time" or "prior life" or "earlier life"

#### I advanced

This metaphor pictures Paul as being ahead of other Jews his age in their goal to be perfect Jews.

#### those who were my own age

"the Jewish people who are the same age as I am"

#### my fathers

"my ancestors"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judaism.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judaism.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md)]]

### Galatians 01:15

#### who called me through his grace

Possible meanings are 1) "God called me to serve him because he is gracious" or 2) "He called me by means of his grace."

#### to reveal his Son in me

Possible meanings are 1) "to allow me to know his Son" or 2) "to show the world through me that Jesus is God's Son."

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### proclaim him

"proclaim that he is God's Son" or "preach the good news about God's Son"

#### consult with flesh and blood

This is an expression that means talking with other people. AT: "ask people to help me understand the message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### go up to Jerusalem

"go to Jerusalem." Jerusalem was in a region of high hills, making it necessary to climb many hills in order to get there, and so it was common to describe travel to Jerusalem as "going up to Jerusalem."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md)]]

### Galatians 01:18

#### I saw none of the other apostles except James

This double negative emphasizes that James was the only apostle whom Paul saw. AT: "the only other apostle I saw was James" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### before God

Paul wants the Galatians to understand that Paul is completely serious and that he knows that God hears what he says and will judge him if he does not tell the truth.

#### In what I write to you, I assure you before God, that I am not lying

Paul uses litotes to emphasize that he is telling the truth. AT: "I am not lying to you in the messages I write to you" or "in the things I write to you I am telling you the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Galatians 01:21

#### regions of

"part of the world called"

#### They only heard it being said

"but they only knew what they heard others saying about me"

#### I was still not personally known to the churches of Judea that are in Christ

"None of the people in the churches of Judea that are in Christ had ever met me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/syria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/syria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cilicia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cilicia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Galatians 01:intro

#### Galatians 01 General Notes ####

####### Structure and formatting #######

The introduction to this letter is slightly different than Paul's other letters. It states, "I am not an apostle from men nor through a man, but through Jesus Christ and God the Father, who raised him from the dead." This statement is probably included because there were false teachers who opposed Paul and tried to undermine  his authority.

####### Special concepts in this chapter #######

######## Heresy ########
There is only one gospel that is capable of saving a person eternally. This is the true, biblical gospel, any other version of the gospel is under condemnation from God. Those who teach a false gospel are considered accursed and it is possible that they are outside of salvation. They should be treated as non-Christians. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]])

######## Paul's qualifications ########

There was an issue in the early church whereby certain people taught that Gentiles needed to obey the law of Moses. In this chapter, Paul gives his credentials or qualifications as an "exemplary" Jew in order to refute this teaching (1:11-24). As a Jew, and the apostle to the Gentile people, Paul is uniquely qualified to address this issue. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Other possible translation difficulties in this chapter #######

######## "You are turning so quickly to a different gospel" ########
Galatians was probably the first letter Paul wrote, making this line one of the first recorded statements about the early church. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Galatians 01:01 Notes](./01.md)__
* __[Galatians intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Galatians 02

### Galatians 02:01

#### Connecting Statement:

Paul continues to give the history of how he learned the gospel from God, not the apostles.

#### went up

"traveled." Jerusalem is located in hilly country. The Jews also viewed Jerusalem as the place on earth that is closest to heaven, so Paul may have been speaking figuratively, or it may be that it was reflecting the difficult, uphill, journey to get to Jerusalem.

#### those who seemed to be important

"the most important leaders among the believers"

#### I was not running—or had not run—in vain

Paul uses running as a metaphor for work, and he uses a double negative to emphasize that the work he had done was profitable. AT: "I was doing, or had done, profitable work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in vain

"for no benefit" or "for nothing"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/titus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/titus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]

### Galatians 02:03

#### to be circumcised

This can be stated in active form. AT: "to have someone circumcise him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The false brothers came in secretly

"People who pretended to be Christians came into the church," or "People who pretended to be Christians came among us"

#### spy on the liberty

secretly watch people to see how they live in liberty

#### liberty

freedom

#### They desired

"These spies desired" or "These false brothers wanted"

#### to make us slaves

"to make us slaves to the law." Paul is speaking about being forced to follow the Jewish rituals that the law commanded. He is speaking about this as if it were slavery. The most important ritual was circumcision. AT: "to force us to obey the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### yield in submission

"submit" or "listen"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/titus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/titus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Galatians 02:06

#### added nothing to me

The word "me" here represents what Paul was teaching. AT: "added nothing to what I teach" or "did not tell me to add anything to what I teach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### On the contrary

"Instead" or "Rather"

#### I had been entrusted

This can be stated in active form. AT: "God trusted me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]

### Galatians 02:09

#### built up the church

They were men who taught people about Jesus and convinced people to believe in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### understood the grace that had been given to me

The abstract noun "grace" can be translated as the verb "be kind." AT: "understood that God had been kind to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the grace that had been given to me

This can be stated in active form. AT: "the grace that God had given to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### gave ... the right hand of fellowship

Grasping and shaking the right hand was a symbol of fellowship. AT: "welcomed ... as fellow workers" or "welcomed ... with honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the right hand

"their right hands"

#### remember the poor

You may need to make explicit what about the poor he was to remember. AT: "remember to take care of the needs of the poor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Galatians 02:11

#### I opposed him to his face

The words "to his face" are a metonym for "where he could see and hear me." AT: "I confronted him in person" or "I challenged his actions in person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Before

in relation to time

#### he stopped

"he stopped eating with them"

#### He was afraid of those who were demanding circumcision

The reason Cephas was afraid can be stated explicitly. AT: "He was afraid that these men who required circumcision would judge that he was doing something wrong" or "He was afraid that these men who required circumcision would blame him for doing something wrong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### those who were demanding circumcision

Jews who had become Christians, but who demanded that those who believe in Christ live according to Jewish customs

#### kept away from

"stayed away from" or "avoided"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/antioch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/antioch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Galatians 02:13

#### Even Barnabas was led astray with them by their hypocrisy
Here to be "led astray" is a metaphor for being persuaded to do something wrong. The phrase "led astray" can be stated in active form. AT: "Even Barnabas acted like them and did what was wrong" (See: [https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md))

#### not following the truth of the gospel

"they were not living like people who believe the gospel" or "they were living as though they did not believe the gospel"

#### how can you force the Gentiles to live like Jews?

This rhetorical question is a rebuke and can be translated as a statement. The word "you" is singular and refers to Peter. AT: "you are wrong to force the Gentiles to live like Jews." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### force

Possible meanings are 1) force by using words or 2) persuade .

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]

### Galatians 02:15

#### Connecting Statement:

Paul tells the believers that Jews who know the law, as well as Gentiles who do not know the law, are saved only by faith in Christ and not by keeping the law.

#### not Gentile sinners

"not those whom the Jews call Gentile sinners"

#### We also came to faith in Christ Jesus

"We believed in Christ Jesus"

#### we

This probably refers to Paul and others but not to the Galatians, who were primarily Gentiles. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### no flesh

The word "flesh" is a synecdoche for the whole person. AT: "no person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]

### Galatians 02:17

#### while we seek to be justified in Christ

The phrase "justified in Christ" means justified because we are united with Christ and justified by means of Christ.

#### we too, were found to be sinners

The words "were found to be" are an idiom that emphasizes that "we are" certainly sinners. AT: "we see that we also certainly are sinners" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Absolutely not!

"Of course, that is not true!" This expression gives the strongest possible negative answer to the preceding rhetorical question "Does Christ become a servant of sin?" You may have a similar expression in your language that you could use here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Galatians 02:20

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I do not set aside

Paul states a negative to emphasize the positive. AT: "I confirm the value of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### if righteousness could be gained through the law, then Christ died for nothing

Paul is describing a situation that never existed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### if righteousness could be gained through the law

"if people could become righteous by obeying the law"

#### then Christ died for nothing

"then Christ would have accomplished nothing by dying"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Galatians 02:intro

#### Galatians 02 General Notes ####

####### Structure and formatting #######

This chapter continues the discussion of Paul's qualifications that began in [Galatians 1:11](../01/11.md).

####### Special concepts in this chapter #######

######## Freedom and slavery ########

These two concepts are used in contrast to each other. The Christian has freedom in Christ to be able to do many different things, but the Christian who attempts to follow the law of Moses, even one point, is under obligation to follow the whole of the law. This attempt to follow the law enslaves the Christians to have to follow it all. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Other possible translation difficulties in this chapter #######

######## "I do not negate the grace of God" ########

Paul teaches that, if a Christian attempts to follow the law of Moses, they fail to understand the grace God has shown to them. This is a fundamental error, but Paul uses this statement as a type of hypothetical situation. The purpose of this statement could be seen as, "if you could be saved by following the law, then it would negate the grace of God." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

##### Links: #####

* __[Galatians 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Galatians 03

### Galatians 03:01

#### Connecting Statement:

Paul reminds the believers in Galatia that God gave them God's Spirit when they believed the gospel by faith, not by their doing God's law.

#### General Information:

Paul is rebuking the Galatians by asking rhetorical questions.

#### Who has put a spell on you?

Paul is using irony and a rhetorical question to say that the Galatians are acting as though someone has put a spell on them. He does not really believe that someone has put a spell on them. AT: "You behave as if someone has put a spell on you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### put a spell on you

"done magic on you" or "done witchcraft on you"

#### It was before your eyes that Jesus Christ was publicly displayed as crucified

Paul speaks of his clear teaching of Jesus being crucified as if he had put on public display a picture of Jesus being crucified. And he speaks of the Galatians having heard his teaching as if they had seen the picture. AT: "You yourselves heard the clear teaching about Jesus being crucified" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### This is the only thing I want to learn from you

This continues the irony from verse 1. Paul knows the answers to the rhetorical questions he is about to ask. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### Did you receive the Spirit by the works of the law or by believing what you heard?

Translate this rhetorical question as a question if you can, because the reader will be expecting a question here. Also, be sure that the reader knows that the answer to the question is "by believing what you heard," not "by doing what the law says." AT: "You received the Spirit, not by doing what the law says, but by believing what you heard." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Are you so foolish?

This rhetorical question shows that Paul is surprised and even angry that the Galatians are foolish. AT: "You are very foolish!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### by the flesh

The word "flesh" is a metonym for effort. AT: "by your own effort" or "by your own work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Galatians 03:04

#### Have you suffered so many things for nothing ... ?

Paul uses this question to remind the Galatians that when they were suffering, they believed that they would receive some benefit. AT: "Surely you did not think that you were suffering so many things for nothing ... !" or "Surely you knew that there was some good purpose for suffering so many things ... !" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Have you suffered so many things for nothing

It can be stated clearly that they had suffered these things because of people who opposed them for their faith in Christ. AT: "Have you suffered so many things by those who opposed you for your faith in Christ for nothing" or "You believed in Christ, and you suffered many things by those who oppose Christ. Were your belief and suffering for nothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for nothing

"uselessly" or "without the hope of receiving something good"

#### if indeed it was for nothing?

Possible meanings are 1) Paul uses this rhetorical question to warn them not to let their experiences be for nothing. AT: "Do not let it be for nothing!" or "Do not stop believing in Jesus Christ and let your suffering be for nothing." or 2) Paul uses this question to assure them that their suffering was not for nothing. AT: "It was certainly not for nothing!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Does he ... do so by the works of the law, or by hearing with faith?

Paul asks another rhetorical question to remind the Galatians how people receive the Spirit. AT: "He ... does not do it by the works of the law; he does it by hearing with faith." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### by the works of the law

This represents people doing the works that the law requires. AT: "because you do what the law tells us to do"

#### by hearing with faith

Your language may require that what the people heard and whom they trusted be stated explicitly. AT: "because you heard the message and had faith in Jesus" or "because you listened to the message and trusted in Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Galatians 03:06

#### Connecting Statement:

Paul reminds the Galatian believers that even Abraham received righteousness by faith and not by the law.

#### it was credited to him as righteousness

God saw Abraham's faith in God, so then God considered Abraham righteous.

#### those of faith

"those who have faith." The meaning of the noun "faith" can be expressed with the verb "believe." AT: "those who believe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### children of Abraham

This represents people whom God views as he viewed Abraham. AT: "righteous in the same way as Abraham" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### foreseeing

Because God made the promise to Abraham and they wrote it down before the promise came through Christ, the scripture is like someone who knows the future before it happens. AT: "predicted" or "saw before it happened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### In you

"Because of what you have done" or "Because I have blessed you." The word "you" refers to Abraham and is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### all the nations

"all the people-groups in the world." God was emphasizing that he was not favoring only the Jewish people, his chosen group. His plan of salvation was for both Jews and non-Jews.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Galatians 03:10

#### All who rely on ... the law are under a curse

Being under a curse represents being cursed. Here it refers to being eternally punished. "Those who rely on ... the law are cursed" or "God will eternally punish those who rely on ... the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Now it is clear

What is clear can be stated explicitly. AT "The scriptures are clear" or "The scriptures teach clearly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no one is justified before God by the law

This can be stated with an active verb. AT: "God justifies no one by the law"

#### no one is justified before God by the law

Paul is correcting their believe that if they obeyed the law, God would justify them. AT: "no one is justified before God by obeying the law" or "God does not justify anyone for their obedience to the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the righteous will live by faith

The nominal adjective "righteous" refers to righteous people. AT: "righteous people will live by faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the works of the law

"what the law says we must do"

#### must live by them

Possible meanings are 1) "must obey them all" or 2) "will be judged by his ability to do what the law demands."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Galatians 03:13

#### Connecting Statement:

Paul reminds these believers again that keeping the law could not save a person and that the law did not add a new condition to the promise by faith given to Abraham.

#### from the curse of the law

The noun "curse" can be expressed with the verb "curse." AT: "from being cursed because of the law" or "from being cursed for not obeying the law"

#### by becoming a curse for us

The noun "curse" can be expressed with the verb "curse." AT: "by being cursed for us" or "when God cursed him instead of us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### from the curse of the law ... becoming a curse for us ... Cursed is everyone

Curse here represents being condemned. AT: "from being condemned by the law ... being condemned instead of us ... Condemned is everyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hangs on a tree

Paul expected his audience to understand that he was referring to Jesus hanging on the cross.

#### might

"will"

#### we

The word "we" includes the people who would read the letter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hang.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hang.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Galatians 03:15

#### Brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### in human terms

"as a person" or "of things most people understand"

#### Now

This word shows that Paul has stated a general principle and is now beginning to introduce a specific case.

#### referring to many

"referring to many descendants"

#### to your descendant

The word "your" is singular and refers to a specific person, who is a particular descendant of Abraham (and that descendant is identified as "Christ"). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Galatians 03:17

#### 430 years

"four hundred and thirty years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### For if the inheritance comes by the law, then it no longer comes by promise

Paul is speaking of a situation that did not exist to emphasize that the inheritance came only by means of the promise. AT: "the inheritance comes to us by means of the promise, because we could not keep the demands of God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### inheritance

Receiving what God has promised believers is spoken of as if it were an inheritance of property and wealth from a family member, and eternal blessings and redemption. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Galatians 03:19

#### Connecting Statement:

Paul tells the believers in Galatia why God gave the law.

#### What, then, was the purpose of the law?

Paul uses a rhetorical question to introduce the next topic he wants to discuss. It can also be translated as a statement. AT: "I will tell you what the purpose of the law is." or "Let me tell you why God gave the law." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### It was added

This can be stated in active form. AT: "God added it" or "God added the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The law was put into force through angels by a mediator

This can be stated in active form. AT: "God issued the law with the help of angels, and a mediator put it into force" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a mediator

"a representative"

#### Now a mediator implies more than one person, but God is one

God gave his promise to Abraham without a mediator, but he gave the law to Moses with a mediator. As a result, Paul's readers may have thought that the law somehow made the promise to no effect. Paul is stating what his readers might have thought here, and he will respond to them in the verses that follow.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md)]]

### Galatians 03:21

#### General Information:

The word "us" in this section refers to all Christians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### against

"opposed to" or "in conflict with"

#### if a law had been given that could give life

This can be stated in active form, and the abstract noun "life" can be translated with the verb "live." AT: "if God had given a law that enabled those who kept it to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### righteousness would certainly have come by the law

"we could have become righteous by obeying that law"

#### scripture imprisoned everything under sin. God did this so that the promise to save us by faith in Jesus Christ might be given to those who believe

Other possible meanings are 1) "because we all sin, God put all things under the control of the law, like putting them in prison, so that what he has promised to those who have faith in Christ Jesus he might give to those who believe" or 2) "because we sin, God put all things under the control of the law, like putting them in prison. He did this because what he has promised to those who have faith in Christ Jesus he wants to give to those who believe."

#### scripture

Paul is treating scripture as though it were a person and is speaking of God, who wrote scripture. AT: "God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Galatians 03:23

#### Connecting Statement:

Paul reminds those in Galatia that believers are free in God's family, not slaves under the law.

#### we were held captive under the law, imprisoned

This can be stated in active form. AT: "the law held us captive and we were in prison" or "the law held us captive in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### we were held captive under the law, imprisoned

The way the law controlled us is spoken of as if the law were a prison guard holding us as captives. AT: "the law controlled us like a prison guard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### until faith should be revealed

This can be stated in active form, and who this faith is in can be stated clearly. AT: "until God would reveal that he justifies those who have faith in Christ" or "until God would reveal that he justifies those who trust in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### guardian

More than simply "one who gives oversight to a child," this was usually a slave who was responsible for enforcing rules and behaviors given by the parent and would report to the parent on the child's actions.

#### until Christ came

"until the time when Christ came"

#### so that we might be justified

Before Christ came, God had planned to justify us. When Christ came, he carried out his plan to justify us. This can be stated in active form. AT: "so that God would declare us to be righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Galatians 03:27

#### For as many of you who were baptized into Christ

"For all of you who were baptized into Christ"

#### have clothed yourselves with Christ

Possible meanings are 1) this is a metaphor meaning that they have been united to Christ. AT: "have become united with Christ" or "belong to Christ" or 2) this is a metaphor meaning that they have become like Christ. AT: "have become like Christ"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### There is neither Jew nor Greek, there is neither slave nor free, there is neither male nor female

"God sees no difference between Jew and Greek, slave and free, male and female"

#### heirs

The people to whom God has made promises are spoken of as if they were to inherit property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Galatians 03:intro

#### Galatians 03 General Notes ####

####### Special concepts in this chapter #######

######## Equality in Christ ########
In the church, there is equality between all members. Race, ethnic identity, sex and economic standing do not matter. All have equal standing with each other and in the eyes of God. 

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
Paul uses many different rhetorical questions to convince the Galatians of their sin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Other possible translation difficulties in this chapter #######

######## "Those who believe are sons of Abraham" ########
Scholars are divided over what this means. Some believe Christians inherit the promises of Abraham, replacing the physical descendants of Israel. Others believe Christians are those who follow in the spiritual footsteps of Abraham, but they do not inherit the promises given to Abraham.  In light of Paul's other teachings, and the context here, it is probable that Paul is talking about the Jewish Christians as living in equality with the Gentile Christians; but this does not negate the specific future and inheritance of the physical descendants of Abraham. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Galatians 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Galatians 04

### Galatians 04:01

#### Connecting Statement:

Paul continues to remind the Galatian believers that Christ came to redeem those who were under the law, and that he made them no more slaves but sons.

#### no different from

"the same as"

#### guardians

people with legal responsibility for children

#### trustees

people whom others trust to keep valuable items safe

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Galatians 04:03

#### General Information:

The word "we" here refers to all Christians, including Paul's readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### we were enslaved to the elemental principles of the world

This is a metaphor, comparing the control of the "principles of the world" to a master-slave relationship. AT: "the customs and laws of our ancestors controlled our behavior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) 

#### the elemental principles of the world

Possible meanings are 1) this refers to the laws or moral principles of the world, or 2) this refers to spiritual powers, which some people thought control what happens on earth.

#### redeem

Paul uses the metaphor of a person buying back lost property or buying the freedom of a slave as a picture of Jesus paying for his people's sins by dying on the cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Galatians 04:06

#### you are sons ... you are no longer a slave, but a son

Paul uses the word for male child here because the subject is inheritance. In his culture and that of his readers, inheritance passed most commonly, but not always, to male children. He was neither specifying nor excluding female children here.

#### God has sent the Spirit of his Son into our hearts, who calls out, "Abba, Father."

By calling out "Abba, Father" the Spirit assures us that we are God's children and he loves us.

#### sent the Spirit of his Son into our hearts

The heart is metonym for the part of a person that thinks and feels. AT: "sent his Son's Spirit to show us how to think and act" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### who calls

The Spirit is the one who calls.

#### Abba, Father

This is the way a young child would address his father in Paul's home language, but not in the language of the Galatian readers. To keep the sense of a foreign language, translate this as a word that sounds as much like "Abba" as your language allows.

#### you are no longer a slave ... you are also an heir

Paul is addressing his readers as though they are one person, so "you" here is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### heir

The people to whom God has made promises are spoken of as if they were to inherit property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]

### Galatians 04:08

#### Connecting Statement:

Paul reminds the Galatian believers that they are again trying to live under God's laws rather than living by faith.

#### General Information:

He continues to rebuke the Galatians by asking rhetorical questions.

#### those who are

"those things that are" or "those spirits who are"

#### you are known by God

This can be stated in active form. AT: "God knows you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### how is it that you are turning back to ... principles?

"Turning back" here is an idiom for "changing directions toward." This is the first of two rhetorical questions. AT: "you should not go back to ... principles." or "you should not change back to ... principles." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### elemental principles

See how you translated this phrase in [Galatians 4:3](./03.md).

#### Do you want to be enslaved all over again?

This question can be translated as a statement. AT: "You should not want to be slaves all over again!" or "It seems that you do want to be slaves again." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]]) "Enslaved" is a metaphor for the way their former customs controlled their lives, like masters. AT: "It seems that you want to be controlled all over again!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Galatians 04:10

#### You observe days and new moons and seasons and years

Paul is speaking of their being careful to celebrate certain times, thinking that doing that will make them right with God. AT: "You carefully celebrate days and new moons and seasons and years"

#### may have been for nothing

"may have been useless" or "has not had any effect effect"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Galatians 04:12

#### Connecting Statement:

Paul reminds the Galatian believers how kindly they treated him when he was with them, and he encourages them to continue to trust him while he is not there with them.

#### beg

Here this means to ask or urge strongly. This is not the word used to ask for money or food or physical objects.

#### brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### You did me no wrong

This can be stated in positive form. AT: "You treated me well" or "You treated me as you should have"

#### Though my physical condition put you to the test

"Though it was difficult for you to see me so physically ill"

#### despise

"hate very much"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Galatians 04:17

#### to win you over

"to convince you to join them"

#### to shut you out

"to shut you out from us" or "to make you stop being loyal to us"

#### zealous for them

"zealous to do what they tell you to do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md)]]

### Galatians 04:19

#### Connecting Statement:

Paul tells believers that grace and law cannot work together.

#### My little children

This is a metaphor for disciples or followers. AT: "You who are disciples because of me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I am in the pains of childbirth for you until Christ is formed in you

Paul uses childbirth as a metaphor for his concern about the Galatians. AT: "I am in pain as though I were a woman having to give birth to you, and I will continue to be in pain until Christ truly controls you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md)]]

### Galatians 04:21

#### Tell me

"I want to ask a question" or "I want to tell you something"

#### do you not listen to the law?

Paul is introducing what he will say next. AT: "you need to learn what the law really says." or "let me tell you what the law really says." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Galatians 04:24

#### Connecting Statement:

Paul begins a story to illustrate a truth—that law and grace cannot exist together.

#### These things may be interpreted as an allegory

"This story of the two sons is like a picture of what I will tell you now"

#### as an allegory

An "allegory" is a story in which the people and things in it represent other things. In Paul's allegory, the two women referred to in [Galatians 4:22](./21.md) represent two covenants.

#### Mount Sinai

"Mount Sinai" here is a synecdoche for the law that Moses gave to the Israelites there. AT: "Mount Sinai, where Moses gave the law to Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### she gives birth to children who are slaves

Paul treats the law as if it were a person. AT: "The people under this covenant are like slaves who have to obey the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### represents

"is a picture of"

#### she is in slavery with her children

Hagar is a slave and her children are slaves with her. AT: "Jerusalem, like Hagar, is a slave, and her children are slaves with her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hagar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hagar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Galatians 04:26

#### is free

"is not bound" or "is not a slave"

#### Rejoice

be happy

#### you barren one ... you who are not suffering

Here "you" refers to the barren woman and is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md)]]

### Galatians 04:28

#### brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### children of promise

Possible meanings are that the Galatians have become God's children 1) by believing God's promise or 2) because God worked miracles to fulfill his promises to Abraham, first by giving Abraham a son and then by making the Galatians children of Abraham and thus sons of God.

#### according to the flesh

This refers to Abraham's becoming Ishmael's father by taking Hagar as a wife. AT: "by means of human action" or "because of what people did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### according to the Spirit

"because of something the Spirit did"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Galatians 04:30

#### brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### but of the free woman

The words "we are children" are understood from the previous phrase. This can be translated as a separate sentence. AT: "Rather, we are children of the free woman" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Galatians 04:intro

#### Galatians 04 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry that is quoted from the Old Testament in 4:27.

####### Special concepts in this chapter #######

######## Sonship ########
This is a complex issue discussed in this chapter. Scholars have many views on the issue of Israel's sonship. Not all of Abraham's physical descendants inherit the promises of Abraham. Only the children of Abraham, through his sons Isaac and Jacob, can inherit those promises and only those who follow him spiritually. It is through their faith that they become adopted into the family as sons with an inheritance ("children of promise"). (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]])

####### Other possible translation difficulties in this chapter #######

######## Abba, Father ########
Abba is an Aramaic word. It was an informal way to refer to a person's father in ancient Israel. Paul "transliterates" its sounds by writing it with Greek letters. 
##### Links: #####

* __[Galatians 4:1](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Galatians 05

### Galatians 05:01

#### Connecting Statement:

Paul applies the allegory by reminding the believers to use their liberty in Christ because all the law is fulfilled in loving neighbors as ourselves.

#### For freedom Christ has set us free

"It is so that we can be free that Christ has set us free." It is implied that Christ sets believers free from the law. Here freedom from the law is a metaphor for not being obligated to obey the law. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Stand firm

Standing firm here represents being determined not to change. How they are not to change can be stated clearly. AT: "Do not give in to the arguments of people who teach something else" or "Be determined to stay free" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### if you let yourselves be circumcised

Paul is using circumcision as a metonym for Judaism. AT: "if you turn to the Jewish religion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### do not again be put under the control of a yoke of slavery

Here being under control of a yoke of slavery represents being obligated to obey the law. AT: "do not live like one who is under the control of a yoke of slavery to the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])
#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Galatians 05:03

#### testify

"declare" or "serve as a witness"

#### to every man who lets himself be circumcised

Paul is using circumcision as a metonym for being Jewish. AT: "to every person who has become a Jew" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### obligated

"bound" or "constrained" or "enslaved"

#### You are cut off from Christ

Here "cut off" is a metaphor for separation from Christ. AT: "You have ended your relationship with Christ" or "You are no longer united with Christ"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you who would be justified by the law

Paul is speaking ironically here. He actually teaches that no one can be justified by trying to do the deeds required by the law. AT: "all you who think you can be justified by doing the deeds required by the law" or "you who want to be justified by the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### you no longer experience grace

Who that grace comes from can be stated clearly. AT: "God will not be gracious to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Galatians 05:05

#### General Information:

Here the word "we" refers to Paul and those who oppose the circumcision of Christians. He is probably including the Galatians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### For through the Spirit

"This is because through the Spirit"

#### by faith, we eagerly wait for the hope of righteousness

Possible meanings are 1) "we are waiting by faith for the hope of righteousness" or 2) "we are waiting for the hope of righteousness that comes by faith."

#### we eagerly wait for the hope of righteousness

"we are waiting patiently and with excitement for God to put us right with himself forever, and we expect him to do it"

#### neither circumcision nor uncircumcision

These are metonymy for being a Jew or a non-Jew. AT: "neither being a Jew nor not being a Jew" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but only faith working through love

"Rather, God is concerned with our faith in him, which we show by loving others"

#### means anything

is worthwhile

#### You were running

"You were practicing what Jesus taught"

#### This persuasion does not come from him who calls you

"The one who persuades you to do that is not God, the one who calls you"

#### him who calls you

What he calls them to can be stated clearly. AT: "the one who calls you to be his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### persuasion

To persuade someone is to get that person to change what he believes and so to act differently.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]

### Galatians 05:09

#### you will take no other view

"you will not believe anything different from what I am telling you"

#### The one who is troubling you will pay the penalty

"God will punish the one who is troubling you"

#### is troubling you

"is causing you to be uncertain about what is truth" or "stirs up trouble among you"

#### whoever he is

Possible meanings are 1) Paul does not know the names of the people who are telling the Galatians that they need to obey the law of Moses or 2) Paul does not want the Galatians to care about whether those who "confuse" them are rich or poor or great or small or religious or not religious.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Galatians 05:11

#### Brothers, if I still proclaim circumcision, why am I still being persecuted?

Paul is describing a situation that does not exist to emphasize that people are persecuting him because he is not preaching that people need to become Jews. This can be stated in active form. AT: "Brothers, you can see that I am not still proclaiming circumcision because the Jews are persecuting me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### Brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### In that case the stumbling block of the cross has been removed

Paul is describing a situation that does not exist to emphasize that people persecute him because he is preaching that God forgives people because of Jesus' work on the cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### In that case

"If I were still saying that people need to become Jews"

#### the stumbling block of the cross has been removed

This can be stated in active form. AT: "the teaching about the cross has no stumbling block" or "there is nothing in the teaching of the cross that would cause people to stumble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the stumbling block of the cross has been removed

Stumbling represents sinning, and a stumbling block represents something that causes people to sin. In this case the sin is to reject the truth of the teaching that in order to be made right with God, people only need to believe that Jesus died on the cross for us. AT: "the teaching about the cross that causes people to reject the truth has been removed" or "there is nothing in the teaching about Jesus dying on the cross that would lead people to reject the teaching" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### castrate themselves

Possible meanings are 1) literal, to cut off their male organs so as to become eunuchs or 2) metaphorical, completely withdraw from the Christian community. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]

### Galatians 05:13

#### For

Paul is giving the reason for his words in [Galatians 5:12](./11.md).

#### you were called to freedom

This can be expressed in an active form. AT: "God has called you to freedom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you were called to freedom

"Freedom" here is an idiom meaning the ability to live as one wants. AT: "God has chosen you to be his people so that you can live as you truly want"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### an opportunity for the sinful nature

The relationship between the opportunity and the sinful nature can be stated more clearly. AT: "an opportunity for you to behave according to your sinful nature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the whole law is fulfilled in one command

Possible meanings are 1) "you can state the whole law in just one commandment, which is this" or 2) "by obeying one commandment, you obey all the commandments, and that one commandment is this."

#### You must love your neighbor as yourself

The words "you," "your," and "yourself" are all singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Galatians 05:16

#### Connecting Statement:

Paul explains how the Spirit gives control over sin.

#### walk by the Spirit

Walking is a metaphor for living. AT: "conduct your life in the power of the Holy Spirit" or "live your life in dependence on the Spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will not carry out the desires of the sinful nature

The phrase "carry out someone's desires" is an idiom meaning "do what someone desires." AT: "You will not do what your sinful nature desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the desires of the sinful nature

The sinful nature is spoken of as if it were a person and wanted to sin. AT: "what you want to do because of your sinful nature" or "the things you want to do because you are sinful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### not under the law

"not obligated to obey the law of Moses"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Galatians 05:19

#### the works of the sinful nature

The abstract noun "works" can be translated with the verb "does." AT: "what the sinful nature does"

#### the works of the sinful nature

The sinful nature is spoken of as if it were a person who does things. AT: "what people do because of their sinful nature" or "the things people do because they are sinful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### inherit

Receiving what God has promised believers is spoken of as if it were inheriting property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]

### Galatians 05:22

#### the fruit of the Spirit is love ... self-control

Paul uses fruit as a metaphor for what people can see in other people. AT: "people whom the Spirit controls will display love ... self-control like a tree produces fruit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fruit of the Spirit

"Fruit" here is a metaphor for "result" or "outcome." AT: "what the Spirit produces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### have crucified the sinful nature with its passions and desires

Paul speaks of Christians who refuse to live according to their sinful nature as if it were a person and they have killed it on a cross. AT: "refuse to live according the sinful nature with its passions and desires, as if they killed it on a cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the sinful nature with its passions and desires

The sinful nature is spoken of as if it were a person that had passions and desires. AT: "their sinful nature, and the things they strongly want to do because of it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/selfcontrol.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/selfcontrol.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Galatians 05:25

#### If we live by the Spirit

"Since God's Spirit has caused us to be alive"

#### walk by the Spirit

"Walk" here is a metaphor for living every day. AT: "allow the Holy Spirit to guide us so we do things that please and honor God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let us

"We should"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Galatians 05:intro

#### Galatians 05 General Notes ####

####### Structure and formatting #######

Paul continues talking about the law of Moses as something which traps or enslaves a person. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]) 

####### Special concepts in this chapter #######

######## Fruit of the Spirit ########
Many scholars have observed that the phrase "the fruit of the Spirit" is singular and not plural, even though it begins a list of several things. The singular form should remain in translation in a singular form if possible. Do not translate: "the fruits of the spirit are" in attempt to force agreement. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]])

####### Important figures of speech in this chapter #######

######## Illustrations ########
Paul uses several metaphors to illustrate his points. Running a race and yeast are two metaphors he uses in this chapter to help explain complicated issues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## Flesh ########

This is a complex issue and it is possible that "flesh" is a metaphor for a person's sinful nature. It is not the physical part of man that is sinful and it appears that Paul is teaching that while man remains alive ("in the flesh"), he will remain sinful regardless of his effort, but his new nature will be fighting against his old nature. Flesh is used in this chapter to contrast with that which is spiritual. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]])

######## "You are cut off from Christ, you who would be justified by the law; you no longer experience grace." ########
Some scholars believe Paul teaches that being circumcised in order to fulfill the law causes a person to lose their salvation. It is more probable that Paul is saying these people have walked away from grace as a rule, and have exchanged it for the law.  (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]])

##### Links: #####

* __[Galatians 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Galatians 06

### Galatians 06:01

#### Connecting Statement:

Paul teaches believers how they should treat other believers and how God rewards.

#### Brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### if someone

"if anyone among you"

#### if someone is caught in any trespass

Possible meanings are 1) someone else found that person in the act. AT: "if someone is discovered in an act of sin" or 2) that person committed the sin without intending to do evil. AT: "if someone gave in and sinned"

#### you who are spiritual

"those of you who are guided by the Spirit" or "you who are living in the guidance of the Spirit"

#### restore him

"correct the person who sinned" or "exhort the person who sinned to return to a correct relationship with God"

#### in a spirit of gentleness

Possible meanings are 1) that the Spirit is directing the one who is offering correction or 2) "with an attitude of gentleness" or "in a kind way."

#### Be concerned about yourself

These words treat the Galatians as though they are all one person to emphasize that he is talking to each of them. AT: "Be concerned about yourselves" or "I say to each one of you, 'Be concerned about yourself'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### so you also may not be tempted

This can be stated in active form. AT: "so that nothing will tempt you also to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]

### Galatians 06:03

#### For if

"Because if." The words that follow tell why the Galatians should 1) "carry one other's burdens" ([Galatians 6:2](./01.md)) or 2) be careful that they themselves are not tempted ([Galatians 6:1](./01.md)) or 3) "not become conceited" ([Galatians 5:26](../05/25.md)).

#### he is something

"he is someone important" or "he is better than others"

#### he is nothing

"he is not important" or "he is not better than others"

#### Each one should

"Each person must"

#### each one will carry his own load

"each person will be judged by his own work only" or "each person will be responsible for his own work only"

#### each one will

"each person will"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md)]]

### Galatians 06:06

#### The one

"The person"

#### word

"Word" here is a metonym for "message." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]]) Here this means everything God has said or commanded, as in "the word of God" or "the word of truth."

#### for whatever a man plants, that he will also gather in

Planting represents doing things that end in some kind of result, and gathering in represents experiencing the results of what one has done. AT: "for just as a farmer gathers in the fruit of whatever kind of seeds he plants, so everyone experiences the results of whatever he does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### whatever a man plants

Paul is not specifying males here. AT: "whatever a person plants" or "whatever someone plants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### plants seed to his own sinful nature

Planting seeds is a metaphor for doing deeds that will have consequences later. In this case, the person is doing sinful actions because of his sinful nature. AT: "plants seed according to what he wants because of his sinful nature" or "does the things he wants to do because of his sinful nature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will gather in destruction

God punishing the person is spoken of as if the person were harvesting a crop. AT: "will receive punishment for what he did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### plants seed to the Spirit

Planting seeds is a metaphor for doing deeds that will have consequences later. In this case, the person is doing good actions because he is listening to God's Spirit. AT: "does the things God's Spirit loves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will gather in eternal life from the Spirit

"will receive eternal life as a reward from God's Spirit"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Galatians 06:09

#### Let us not become weary in doing good

"We should continue to do good"

#### doing good

doing good to others for their well-being

#### for at the right time

"for in due time" or "because at the time God has chosen"

#### So then

"As a result of this" or "Because of this"

#### especially ... to those

"most of all ... to those" or "in particular ... to those"

#### those who belong to the household of faith

"those who are members of God's family through faith in Christ"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Galatians 06:11

#### Connecting Statement:

As Paul closes this letter, he gives one more reminder that the law does not save and that they should remember the cross of Christ.

#### large letters

This can mean that Paul wants to emphasize 1) the statements that follow or 2) that this letter came from him.

#### with my own hand

Possible meanings are 1) Paul probably had a helper who wrote most of this letter as Paul told him what to write, but Paul himself wrote this last part of the letter or 2) Paul wrote the whole letter himself.

#### make a good impression

"cause others to think well of them" or "cause others to think that they are good people"

#### in the flesh

"with visible evidence" or "by their own efforts"

#### compel

"force" or "strongly influence"

#### only to avoid being persecuted for the cross of Christ

"so that the Jews will not persecute them for claiming that the cross of Christ alone is what saves people"

#### the cross

The cross here represents what Christ did for us when he died on the cross. AT: "the work Jesus did on the cross" or "the death and resurrection of Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they want

"those people who are urging you to be circumcised want"

#### so that they may boast about your flesh

"so that they may be proud that they have added you to the people who try to keep the law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Galatians 06:14

#### But may I never boast except in the cross

"I do not ever want to boast in anything other than the cross" or "May I boast only in the cross"

#### the world has been crucified to me

This can be stated in active form. AT: "I think of the world as already dead" or "I treat the world like a criminal God has killed on a cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I to the world

The words "have been crucified" are understood from the phrase before this. AT: "and I have been crucified to the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### I to the world

Possible meanings are 1) "the world thinks of me as already dead" or 2) "the world treats me like a criminal that God has killed on the cross"

#### the world

Possible meanings are 1) the people of the world, those who care nothing for God or 2) the things that those who care nothing for God think are important.

#### counts for anything

"is important to God"

#### a new creation

Possible meanings are 1) a new believer in Jesus Christ or 2) the new life of a believer.

#### peace and mercy be upon them, even upon the Israel of God

Possible meanings are 1) that believers in general are the Israel of God or 2) "may peace and mercy be upon Gentile believers and upon the Israel of God" or 3) "may peace be upon those who follow the rule, and may mercy be upon even the Israel of God."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Galatians 06:17

#### From now on

This can also mean "Lastly" or "As I end this letter."

#### let no one trouble me

Possible meanings are 1) Paul is commanding the Galatians not to trouble him, "I am commanding you this: do not trouble me," or 2) Paul is telling the Galatians that he is commanding all people not to trouble him, "I am commanding everyone this: do not trouble me," or 3) Paul is expressing a desire, "I do not want anyone to trouble me."

#### trouble me

Possible meanings are 1) "speak of these matters to me" or 2) "cause me hardship" or "give me hard work."

#### for I carry on my body the marks of Jesus

These marks were scars from people who beat and whipped Paul because they did not like him teaching about Jesus. AT: "for the scars on my body show that I serve Jesus"

#### May the grace of our Lord Jesus Christ be with your spirit

"I pray that the Lord Jesus will be kind to your spirit"

#### brothers

See how you translated this in [Galatians 1:2](../01/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Galatians 06:intro

#### Galatians 06 General Notes ####

####### Structure and formatting #######

Overall, this chapter serves as a conclusion to Paul's letter. It contains some concluding thoughts, which may not be as connected to the rest of the material contained in the letter. There are also some other issues that Paul wished to address in the church in Galatia. 

######## Brothers ########
This chapter is addressed to Christians and this should be seen as a reference to Paul's Christian brothers and not his Jewish brothers.

####### Special concepts in this chapter #######

######## New Creation ########

This is a concept related to being born again. Those who are born again are said to be a new creation in Christ. To Paul, this is more significant than a person's ancestry. It also is related to the idea that the Christian has been given new life in Christ, and has a new nature in them after they come to faith in Christ. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Other possible translation difficulties in this chapter #######

######## Flesh ########

This is a complex issue and it is possible that "flesh" is still a subject used in distinction to the "spirit." The person of the flesh is controlled by their sinful desires while the spiritual is controlled by the Spirit. Flesh is also used to refer to the physical body in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]])

##### Links: #####

* __[Galatians 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | __


## Galatians front

### Galatians front:intro

#### Introduction to Galatians ####

##### Part 1: General Introduction #####

####### Outline of the Book of Galatians #######

1. Paul declares his authority as an apostle of Jesus Christ; he says that he is surprised by the false teachings that the Christians in Galatia have accepted from other people (1:1-10).
1. Paul says that people are saved by trusting in Christ alone, not by keeping the law (1:11-2:21).
1. God puts people right with himself only when they trust in Christ; the example of Abraham; the curse which the law brings (and not a means of salvation); slavery and freedom compared and illustrated by Hagar and Sarah (3:1-4:31).
1. When people are joined to Christ, they become free from having to keep the law of Moses. They are also free to live as the Holy Spirit guides them. They are free to refuse the demands of sin. They are free to bear each other's burdens (5:1-6:10).
1. Paul warns the Christians not to trust in being circumcised and in keeping the law of Moses. Instead, they must trust in Christ (6:11-18).

####### Who wrote the Book of Galatians? #######

Paul from the city of Tarsus was the author. He had been known as Saul in his early life. Before becoming a Christian, Paul was a Pharisee. He persecuted Christians. After he began to trust in Jesus Christ, he traveled several times throughout the Roman Empire telling people about Jesus. 

It is uncertain when Paul wrote this letter and where he was when he wrote it. Some scholars think Paul was in the city of Ephesus and wrote this letter after the second time he traveled to tell people about Jesus. Other scholars think Paul was in the city of Antioch in Syria and wrote the letter soon after the first time he traveled.

####### What is the Book of Galatians about? #######

Paul wrote this letter to both Jewish and non-Jewish Christians in the region of Galatia. He wanted to write against the false teachers who said that Christians need to follow the law of Moses. Paul defended the gospel by explaining that a person is saved by believing in Jesus Christ. People are saved as result of God being kind and not as a result of people doing good works. No person can perfectly obey the law. Any attempt to please God by obeying the law of Moses will only result in God condemning them. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]])

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Galatians." Or they may choose a clearer title, such as "Paul's Letter to the Church in Galatia." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### What does it mean to "live like Jews" (2:14)? #######

To "live like Jews" means to obey the law of Moses, even though one trusts in Christ. The people among the early Christians who taught that this was necessary were called "Judaizers."

##### Part 3: Important Translation Issues #####

####### How did Paul use the terms "law" and "grace" in the Book of Galatians? #######

These terms are used in a unique way in Galatians. There is an important teaching in Galatians about Christian living. Under the law of Moses, righteous or holy living required a person to obey a set of rules and regulations. As Christians, holy living is now motivated by grace. This means that Christians have freedom in Christ and are not required to obey a specific set of rules. Instead, Christians are to live a holy life because they are thankful that God has been so kind to them. This is called "the law of Christ." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

####### What did Paul mean by the expression "in Christ," "in the Lord," etc.? #######

This kind of expression occurs in 1:22; 2:4, 17; 3:14, 26, 28; 5:6, 10. Paul meant to express the idea of a very close union with Christ and the believers. At the same time, he often intended other meanings as well. See, for example, "when we seek for God to justify us in Christ" (2:17), where Paul spoke of being justified by means of Christ.

Please see the introduction to the Book of Romans for more details about this kind of expression.

####### What are the major issues in the text of the Book of Galatians? #######

The following passage is the most significant textual issue in the Book of Galatians:

* "Foolish Galatians, whose evil eye has harmed you? Was not Jesus Christ depicted as crucified before your eyes?" (3:1) The ULB, UDB, and the other modern versions have this reading. However, older versions of the Bible add, "[so] that ye should not obey the truth." Translators are advised not to include this expression. However, if in the translators' region there are older Bible versions that have the passage, the translators can include it. If it is translated, it should be put inside square brackets ([]) to indicate that it is probably not original to Galatians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

