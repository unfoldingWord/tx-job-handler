# <a id="sng"/>Song of Solomon

## Song of Solomon 01

### Song of Solomon 01:01

#### General Information:

See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]]

#### General Information:

Part One of the book begins in [Song of Songs 1:2](./01.md).

#### The Song of Songs

"The Best Song" or "The Most Excellent Song"

#### which is Solomon's

Possible meanings are "which is about Solomon" or "which Solomon composed."

#### your love is better than wine

"I enjoy having you near me more than I enjoy drinking wine"

#### Your anointing oils

"The oils that you put on your body"

#### have a delightful fragrance

"smell wonderful"

#### your name is like flowing perfume

Perfume has a good smell that spreads as the air moves. The name is either a metonym for 1) the person's reputation, what other people think of him. Here the speaker says that people always think that the hearer is a good person, or 2) the person himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with you

"The word "you" refers to the man and so is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Take

"Pull" or "Drag." Here the woman described as being like a captive who is willing to follow her captor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### we will run

The word "we" refers to the young woman together with the man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### We are glad ... We rejoice ... let us celebrate

The woman speaks of herself as if she were more than one person. Many versions change the pronoun to "I" as the UDB does. Other versions present these as the words of the woman's friends speaking about either the woman or the man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### about you

"because of you"

#### let us celebrate

"let us praise"

#### It is natural for the other women to adore you

"Women who adore you are doing as they should do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/delight.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/delight.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Song of Solomon 01:05

#### I am dark but lovely

"My skin is dark, but I am still beautiful" or "Even though my skin is dark, I am beautiful"

#### daughters of Jerusalem

"young women of Jerusalem." These young women could not hear her and were not present, but the woman speaks as if they were present and could hear her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### dark like the tents of Kedar

The nomadic tribes in Kedar used black goat skins to build their homes. The woman is comparing her skin to these tents. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### lovely like the curtains of Solomon

Solomon produced beautiful curtains either for his own palace or for the Temple. She says that her skin is beautiful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### scorched

This exaggeration for "burned" or "made black" refers to the sun changing her skin from light to dark. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### My mother's sons

"My half-brothers." These brothers probably had the same mother as the woman but not the same father.

#### made me keeper of the vineyards

"made me take care of the vineyards"

#### but my own vineyard I have not kept

The woman compares herself to a vineyard. AT: "but I have not been able to take care of myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/curtain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/curtain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]

### Song of Solomon 01:07

#### my soul loves

The soul is a metonym for the person. AT: "I love" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### feed your flock

"graze your flocks"

#### rest your flock

"have your flock lie down"

#### Why should I be like someone who wanders beside the flocks of your companions?

The woman asks this question to emphasize that she has a closer relationship to the man than other women do. This question can be translated as a statement. AT: "Tell me so that I will not need to wander around among the flocks of your companions when I am looking for you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### wanders

"goes all around." She does not want to have to look for the man. Perhaps she is afraid other men will think she is a prostitute looking for business. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### companions

"friends" or "co-workers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Song of Solomon 01:08

#### most beautiful among women

"you who are the most beautiful of all women"

#### follow the tracks of my flock

"follow along behind the flock"

#### tracks

marks of the hooves of the flock on the ground

#### pasture your young goats

"graze your young goats" or "let your young goats eat"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Song of Solomon 01:09

#### General Information:

The man continues speaking to the woman.

#### I compare you, my love, to a mare among Pharaoh's chariot horses

The Jews of those days considered horses beautiful, and the Pharaoh's horses would have been the most beautiful he could find. The man considers the young woman beautiful. AT: "My love, you are as beautiful as any of Pharaoh's chariot horses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### my love

"you whom I love"

#### Pharaoh's chariot horses

"the horses that pull Pharaoh's chariots"

#### Your cheeks are beautiful with ornaments

These ornaments could be 1) jewels hanging from a band around the head or 2) earrings or 3) a metaphor for her long hair. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We will make

The man speaks as if he were many people. Some versions change this to singular "I." Other versions take these to be the words of the woman's friends. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### with silver studs

"with spots of silver"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Song of Solomon 01:12

#### lay on his couch

"sat eating his special meal." This probably refers to one of the couches on which people would lie around a table at a banquet. You could translate using the common word for what people do with their bodies when they eat special meals.

#### nard

an oil that people got from the expensive nard or spikenard (valerian plant with small pink or white flowers) and used to make their skin soft and to have a pleasant odor.

#### emitted its fragrance

"gave off its good smell"

#### My beloved is to me like a bag of myrrh ... breasts

Women would place a small bag or pouch of myrrh on a necklace so it would lie between their breasts and they could enjoy its pleasant fragrance. This woman enjoys having her beloved close to her. She adds "to me" to show that she does not expect anyone else to enjoy her beloved in this way. AT: "I enjoy my beloved as much as I enjoy having a bag of myrrh ... breasts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### My beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." AT: "My dear one" or "My lover" 

#### lying between my breasts

If this phrase would offend your readers, you could use a euphemism. AT: "close to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### My beloved is to me like a cluster of henna flowers

Henna flowers have a fragrance that people enjoy. The woman enjoys her beloved. She adds "to me" to show that she does not expect anyone else to enjoy her beloved in this way. AT: "I enjoy my beloved as much as I enjoy the smell of clusters of henna flowers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### henna flowers

flowers from a small desert tree that people used as a perfume

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/engedi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/engedi.md)]]

### Song of Solomon 01:15

#### Listen

"Listen carefully" or "What I am about to say is important." You could use a word in your language that tells the hearer to listen carefully.

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](./09.md)

#### your eyes are doves

Possible meaning are 1) the Israelites considered doves to be gentle and soft birds, and the man considers the woman's eyes beautiful because the way the woman looks at him makes him think she is gentle. AT: "you are very gentle" or 2) the man is speaking of the woman's white eyeballs or the shape of her eyes as being like the shape of a dove. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]

### Song of Solomon 01:16

#### Listen

"Listen carefully" or "What I am about to say is important." You could use a word in your language that tells the hearer to listen carefully.

#### handsome

Use the word in your language that describes a good-looking man.

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"  

#### lush plants are our bed

This speaks of the lush plants as if they were a bed. AT: "lush plants are what we lie down on to sleep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The lush plants

plants that are green, moist, and grow abundantly

#### The beams of our house are cedars; our rafters are firs

The woman describes the forest as though it were a house in which they were lying down. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### beams ... rafters

Possible meanings are 1) "beams" refers to large logs used to support everything above the walls and "rafters" refers to the large pieces of wood to which the roof is attached or 2) "beams" refers to the rafters and "rafters" refers to the strips attached to the beams, onto which the builders attached the roofing materials.

#### cedars ... firs

Cedars were large and strong trees. The word translated "firs" is a general term for trees like cedars but smaller. If cedar and fir trees are unknown in your area, you could use general terms for the tallest and strongest trees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]

### Song of Solomon 01:intro

#### Song of Songs 01 General Notes ####

####### Special concepts in this chapter #######

######## Kisses ########
The kisses in this chapter are a type of kiss that was only done between a husband and a wife. It is an intimate kiss. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Love and affection ########
This chapter is centered on the feelings of love, affection, and attraction. Different cultural standards may make translation difficult and the translator may use euphemisms to avoid offending people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

####### Important figures of speech in this chapter #######

######## Metaphors ########
In the ancient Near East, it was common to describe a woman using metaphors involving animals. In many cultures today, this can be considered offensive. Different metaphors of beauty are used in different cultures. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## "I am dark" ########
In the ancient Near East, rich people usually had lighter skin because they did not need to work outside in the sun. This young woman had to work out in the sun, and her skin became darker than it was when she was younger.

##### Links: #####

* __[Song of Songs 01:01 Notes](./01.md)__
* __[Song of Songs intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Song of Solomon 02

### Song of Solomon 02:01

#### General Information:

See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]]

#### I am a meadow flower of Sharon

The woman speaks as if she were one of many flowers in a land known for beautiful flowers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Sharon

the name of a land that is flat, has no trees, and grows many different kinds of grasses and flowers

#### lily of the valleys

The woman speaks as if she were one of many flowers in a land known for beautiful flowers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lily

a sweet smelling flower that grows in places where there is much water. See how you translated this in [Song of Songs 2:1-2](./01.md).

#### valleys

flat areas between mountains and near water

#### As a lily among thorns ... young women

A flower is much more beautiful than a thorn bush. The man thinks the woman is much more beautiful than the other women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](../01/09.md).

#### the young women

"the other young women"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Song of Solomon 02:03

#### As an apricot tree ... the young men

People enjoy the fruit of an apricot tree, but the trees of the forest do not bear fruit. The woman enjoys being with the man, but not with the other young men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### apricot tree

a tree that produces a small yellow fruit that is very sweet. If your readers will not know what this is, you could use the word for another fruit tree or the general word "fruit tree."

#### the forest

The Hebrew word here refers to land where trees grow for which people have no use.

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"  

#### I sit down under his shadow with great delight

The woman finds great joy and comfort in being so near to the man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his fruit is sweet to my taste

The woman enjoys eating sweet fruit, and she enjoys being near to the man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the house of wine

Possible meanings are 1) the very large room where the king would serve many people large meals with wine or 2) a small booth in a vineyard where the man and woman could be alone together.

#### his banner over me was love

Possible meanings are 1) the banner is a metonym for a military escort. And, the military escort is a metaphor that represents the man's love which gives courage to the woman who was nervous to enter the large room where the king served many people. AT: "but his loving protection guided me and gave me courage" or 2) the woman knew that the man wanted to make love to her from the way he looked at her. AT: "he looked at me lovingly" or "when he looked at me, I knew he wanted to make love to me" or 3) they made love. AT: "he lovingly covered me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Song of Solomon 02:05

#### Revive me

"Return my strength" or "Give me energy"

#### with raisin cakes

"by giving me raisin cakes to eat." Raisin cakes were cakes made of dried grapes pressed together.

#### refresh me with apricots

"support me by giving me apricots" or "help me by giving me apricots"

#### for I am weak with love

The woman speaks of feeling weak because her love is so strong as if love were a kind of sickness. AT: "because my love is so strong that I feel feeble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### left hand ... right hand

"left arm ... right arm"

#### embraces me

"holds me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Song of Solomon 02:07

#### daughters of Jerusalem

"young women of Jerusalem." These young women could not hear her and were not present, but the woman speaks as if they were present and could hear her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### by the gazelles and the does of the fields

Although the daughters of Jerusalem could not hear her, the woman speaks to them as if they could hear saying that the gazelles and the does will punish them they break their promise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### the gazelles

These are animals that look like deer and move quickly.

#### does

female deer

#### of the fields

"that live in the countryside." This was land that has not been farmed.

#### will not awaken or arouse love until she pleases

Here "love" is spoken of as if it were a person asleep that does not want to be awakened. This is a metaphor that represents the man and woman who do not want to be disturbed until they are finished making love. AT: "will not disturb us until we have finished making love" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will not awaken or arouse

If your language has only one word for waking people out of sleep, you could combine these words. AT: "will not awaken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]

### Song of Solomon 02:08

#### General Information:

Here begins Part Two of the book.

#### General Information:

It is not clear whether the woman is speaking to herself or to the daughters of Jerusalem.

#### Listen

Possible meanings are 1) "Listen carefully to what I am about to say." You could use a word in your language that tells the hearer to listen carefully, or 2) "Listen so you can hear him coming."

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"  

#### leaping ... jumping ... gazing ... peering

The woman shows that she is excited to see the man come by using as few words as possible to describe what he is doing. Your language may have a different way of showing that the speaker is excited about what is happening.

#### leaping over the mountains, jumping over the hills

"leaping on the mountains, running quickly on the hills." The woman speaks of the man as if he were "a gazelle or a young stag" (verse 9) coming quickly toward her over rough ground. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### like a gazelle or a young stag

Gazelles and young stags move quickly over rough ground. The woman imagines the man coming as fast as he can to be with her. You could translate using animals in your language that people think of as fast. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a gazelle

This is an animal that looks like a deer and moves quickly. Translate as the singular of "the gazelles" as in [Song of Songs 2:7](./07.md).

#### a young stag

"a young male deer"

#### look

"listen carefully" or "what I am about to say is important." You could use a word in your language that tells the hearer to listen carefully.

#### behind our wall

"on the other side of our wall." The woman is in a house and the man is outside the house.

#### our wall

The word "our" refers to the woman and the other people in the house with her. If she is speaking to herself, it is inclusive, but if she is speaking to the daughters of Jerusalem, whether she is referring to herself and her companions or to herself only in plural, as in "We are glad ... We rejoice ... let us celebrate" ([Song of Songs 1:4](../01/01.md)), it is exclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### gazing through the window

"he stares in through the windows"

#### peering through the lattice

"he peeks through the lattice"

#### lattice

a cover for a window or some other entrance that someone has made by weaving long strips of wood together. Lattices have holes that people can look through.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]

### Song of Solomon 02:10

#### My beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "My dear one" or "My lover"

#### Arise, my love

"Get out of bed, my love"

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](../01/09.md)

#### Look

"Listen carefully" or "What I am about to say is important." You could use a word in your language that tells the hearer to listen carefully.

#### the winter is past; the rain is over and gone

In winter it is too cold and wet to make love outside, but the cold, wet time has passed.

#### the winter is past

Winter is the cold time of year when plants do not grow and people prefer to stay inside their houses. You could use the term in your language for that time of year.

#### the rain is over and gone

In Israel it only rains during the winter. The rain here is cold and unpleasant, not the refreshing rain of the hot season.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Song of Solomon 02:12

#### The flowers have appeared

"People can see flowers"

#### in the land

"all over this land"

#### pruning

cutting off branches from a plant so that it will produce more fruit or look better

#### the singing of birds

"for birds to sing"

#### the sound of the doves is heard

This can be translated in active form. AT: "people can hear the sound of doves" or "the doves are cooing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The fig tree ripens her green figs

The tree is spoken of as if it were actively causing its fruit to ripen. This is a collective singular and can be translated as a plural. AT: "The figs on the trees are becoming ripe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### vines are in blossom

"vines are flowering" or "vines have flowers"

#### they give off

The word "they" refers to the blossoms on the vines.

#### fragrance

"sweet smell"

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](../01/09.md)

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]

### Song of Solomon 02:14

#### General Information:

The man is speaking.

#### My dove

The Israelites considered doves beautiful birds with pleasant voices. The man thinks the woman's face and voice are beautiful. If calling a woman a "dove" would be offensive, you could leave out the metaphor. AT: "My beautiful woman" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### clefts

large cracks in the side of mountain rocks large enough for people to hide in

#### crags

"steep rocks"

#### your face

Some versions translate this as "your appearance" or "your form" or "what you look like."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Song of Solomon 02:15

#### Catch

This is plural, as if the woman is speaking to more than one man, but most versions translate who she is speaking to as the man, so you could translate this as singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the foxes

These animals look like small dogs and were often used in love poetry to represent eager young men who would spoil a young woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for us ... our vineyard

The words "us" and "our" could possibly be 1) exclusive, referring to the woman herself, as in [Song of Songs 1:4](../01/01.md), or 2) inclusive, referring to the woman and the man, or 3) exclusive, referring to the woman and the rest of her family. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### foxes

Another possible meaning is "jackals." A jackal is a type of thin wild dog with long legs.

#### the little foxes that spoil

Foxes spoil or destroy vineyards by digging holes and eating vines and grapes. This could be a metaphor for young men who spoil young women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in blossom

This implies that the vineyard is healthy and the grapes have appeared, but they are not ready for harvest. This could be a metaphor for a young lady ready for marriage and bearing children. See how you translated this in [Song of Songs 2:13](./12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]

### Song of Solomon 02:16

#### My beloved is mine

"My beloved belongs to me"

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### I am his

"I belong to him"

#### he grazes

"feeds" or "eats grass." The woman speaks of the man as if he were "a gazelle or a young stag" (verse 17) that eats plants among the lilies. Grazing is probably a metaphor for lovemaking ([Song of Songs 2:1-2](./01.md)). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lilies

sweet-smelling flowers that grow in places where there is much water. Translate as the plural of "lily" in [Song of Songs 2:1](./01.md).

#### dawn

the part of the day when the sun is rising

#### the shadows flee away

The woman describes the shadows as though they were running away from the light of the sun. AT: "the shadows disappear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### like a gazelle or a young stag

See how you translated this in [Song of Songs 2:9](./08.md).

#### gazelle

an animal that looks like a deer and moves quickly. Translate as the singular of "gazelles" as in [Song of Songs 2:7](./07.md).

#### stag

an adult male deer

#### rugged

"rocky" or "rough"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md)]]

### Song of Solomon 02:intro

#### Song of Songs 02 General Notes ####

####### Important figures of speech in this chapter #######

######## Metaphor ########
Women are compared to flowers in this chapter. This metaphor may describe a woman's beauty and delicacy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## Euphemisms ########
It is possible that some of the metaphors used in this chapter are actually euphemisms. These euphemisms would refer to sex or the physical love between a husband and a wife.  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

##### Links: #####

* __[Song of Songs 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Song of Solomon 03

### Song of Solomon 03:01

#### I was longing for him ... could not find him

"I had a strong desire to be with him ... loves, but he was not there"

#### him whom my soul loves

The soul is a metonym for the whole person. Here it makes a stronger statement of the woman's love for the man than "my beloved" ([Song of Songs 1:14](../01/12.md)). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### go through the city

"walk through the city"

#### through the streets and squares

The word "squares" indicates the center area of a town where streets or roads come together. It is often an area where people sell items, a market, and a place where people come together to talk.

#### search

"to look for"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Song of Solomon 03:03

#### watchmen

men who have the job of keeping guard of the town at night to keep the people safe

#### as they were making their rounds in the city

"who were walking around the city on the walls"

#### him whom my soul loves

The soul is a metonym for the whole person. Here it makes a stronger statement of the woman's love for the man than "my beloved" ([Song of Songs 1:14](../01/12.md)). See how you translated this in [Song of Songs 3:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### bedroom

"the room for sleeping"

#### the one who had conceived me

This is a metonym for her mother. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/conceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/conceive.md)]]

### Song of Solomon 03:05

#### General Information:

Translate this verse as in [Song of Songs 2:7](../02/07.md).

#### daughters of Jerusalem

"young women of Jerusalem." These young women could not hear her and were not present, but the woman speaks as if they were present and could hear her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### by the gazelles and the does of the fields

Although the daughters of Jerusalem are not there to hear her, the woman is telling them that the gazelles and the does will punish them they break their promise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### the gazelles

animals that look like deer and move quickly.

#### does

female deer

#### of the fields

"that live in the countryside." This refers to land that has not been farmed.

#### will not awaken or arouse love until she pleases

Here "love" is spoken of as if it were a person asleep that does not want to be awakened. This is a metaphor that represents the man and woman who do not want to be disturbed until they are finished making love. AT: "will not disturb us until we have finished making love" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will not awaken or arouse

If your language has only one word for waking people out of sleep, you could combine these words. AT: "will not awaken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md)]]

### Song of Solomon 03:06

#### General Information:

Here begins Part Three of the book. It begins with a description of sixty men carrying Solomon's bed up from the wilderness to Jerusalem.

#### What is that coming up from the wilderness

The group of people is traveling from the wilderness to Jerusalem. They must go up in order to reach Jerusalem because the wilderness is low in the Jordan valley and Jerusalem is high in the mountains.

#### What is that

Many versions translate this "Who is that."

#### like a column of smoke

The dust looked like smoke from far away because the people raised much dust in the air as they traveled. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### perfumed with myrrh and frankincense

"with the sweet smell of myrrh and frankincense"

#### with all the powders sold by merchants

The words "perfumed with" are understood from the previous phrase. They can be repeated here. AT: "perfumed with all the powders sold by merchants" or "and with the sweet smell of all the powders that merchants sell" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### powders

a fine dust made by crushing something solid

#### Look

"Listen carefully" or "What I am about to say is important." You could use a word in your language that tells the hearer to listen carefully. The speaker now discovers the answer to the question in verse 6.

#### it is the bed

This refers to a bed with a cover that can be carried from one place to another.

#### sixty warriors surround it, sixty soldiers of Israel

These two phrases refer to the same sixty people. The second phrase clarifies that the "warriors" are "soldiers of Israel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### warriors

men who fight

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Song of Solomon 03:08

#### General Information:

The description of sixty men carrying Solomon's bed up from the wilderness to Jerusalem, begun in [Song of Songs 3:6](./06.md), continues.

#### Connecting Statement:

A description of the bed itself begins in verse 9. You could use words in your language that show that this is background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### are experienced in warfare

"can fight battles well"

#### armed against

"so that he can fight against"

#### terrors of the night

The abstract noun "terrors" is a metonym for evil people who frighten others by attacking them. AT: "evil people who attack others at night" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### sedan chair

This is a chair or couch for important people to sit or lie on. It rests on long poles that people can use to carry it

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]

### Song of Solomon 03:10

#### Connecting Statement:

The description of the bed itself that began in [Song of Songs 3:9](./08.md) continues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Its posts

The word "its" refers to King Solomon's sedan chair.

#### posts

The word "posts" here refers to pieces either made of silver or made of wood covered with silver that hold up the tent of cloth around his chair.

#### Its interior was

"The inside of it was"

#### with love

Possible meanings are 1) "with love," indicating that the women made the sedan beautiful in a special way to show their love for Solomon, or 2) "with leather."

#### daughters of Zion

"you young women who live in Zion"

#### gaze on King Solomon

"look at King Solomon." The word "gaze" refers to look at someone or something for a long time, usually with strong emotional feeling.

#### bearing the crown

"wearing the crown"

#### the day of the joy of his heart

The word "heart" is a metonym for the person. AT: "the day on which he truly rejoiced" or "the happiest day of his life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]

### Song of Solomon 03:intro

#### Song of Songs 03 General Notes ####

####### Special concepts in this chapter #######

######## Longing ########
This chapter describes a feeling of longing, or the waiting in anticipation of the one you love. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Other possible translation difficulties in this chapter #######

######## Metaphors ########
In the ancient Near East, it was common to describe a woman using metaphors involving animals. In many cultures today, this can be considered offensive. Different metaphors of beauty are used in different cultures. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Song of Songs 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Song of Solomon 04

### Song of Solomon 04:01

#### General Information:

See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]]

#### Your eyes are doves

One possibility is that the man is speaking of the woman's white eyeballs or the shape of her eyes, the shape of a dove. Another possibility is that the Israelites considered doves to be gentle and soft birds, and the man considers the woman's eyes beautiful because the way the woman looks at him makes him think she is gentle. See how you translated this in [Song of Songs 1:15](../01/15.md). AT: "You are very gentle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](../01/09.md).

#### Your hair is like a flock of goats going down from Mount Gilead

Goats in Israel were usually dark in color. The woman's hair was probably dark. You may need to specify that the goats were dark or even use another simile that the reader will understand that refers to something dark and beautiful. People thought of Mount Gilead as beautiful and fertile. The speaker considered the woman beautiful and ready to become the mother of his children. If you remove the simile of the goats, you may have to remove the simile of the mountain as well. AT: "Your hair is as dark as storm clouds above a fertile land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Song of Solomon 04:02

#### Your teeth are like a flock of newly shorn ewes

After sheep have their wool cut off, they are washed and their skin looks very white. The woman's teeth are white. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a flock of newly shorn ewes

This can be translated in active form. AT: "a flock of ewes whose wool people have cut off" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### coming up from the washing place

The ewes are coming up out of the water. AT: "that are coming up out of the water after people have washed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Each one has a twin

Sheep usually give birth to two lambs at one time. These twin lambs usually look like one another. Each of the woman's teeth has a matching tooth on the other side of her mouth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### none among them is bereaved

Each of the woman's teeth has a matching tooth on the other side of her mouth. She has not lost any of her teeth.

#### bereaved

lost a loved one who has died

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Song of Solomon 04:03

#### General Information:

The man continues to praise the woman.

#### are like a thread of scarlet

Scarlet is a beautiful red color, and scarlet thread was very expensive. The woman's lips were red. AT: "are a deep red like scarlet thread" or "are red and very beautiful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### scarlet

a dark red color that is very similar to the color of blood

#### is lovely

"is beautiful"

#### are like pomegranate halves

Pomegranates are smooth, round, and rich red. The man thinks the woman's cheeks are beautiful and show that she is healthy. AT: "are red and round like two halves of a pomegranate" or "are red and full and healthy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### behind your veil

See how you translated this in [Song of Songs 4:1](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md)]]

### Song of Solomon 04:04

#### General Information:

The man continues to praise the woman.

#### Your neck is like the tower of David

No one knows if this was a real tower. A tower is a tall, slender building, and saying that David built it implies that it was beautiful. The man considered the woman's neck long and slender and so beautiful. AT: "Your neck is long and beautiful like the tower of David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### of David

"that David built"

#### built in rows of stone

Women had necklaces that covered their entire necks with rows of decorations. The man compares these rows of decorations with the rows of stone on the tower. AT: "that has many rows of stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### with a thousand shields

The man compares the decorations of the woman's necklace with shields hanging on the tower. The necklace probably went around her neck many times. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a thousand shields

"1,000 shields." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### all the shields of soldiers

"all of the shields belong to mighty warriors"

#### two breasts

If the word "two" seems unnecessary and so out of place, you could omit it.

#### like two fawns, twins of a gazelle

The man implies that the woman's breasts are matching, soft, and perhaps small. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### twins

the babies of a mother who gave birth to two babies at one time

#### gazelle

an animal that looks like a deer and moves quickly. Translate as the singular of "gazelles" as in [Song of Songs 2:7](../02/07.md).

#### grazing among the lilies

"eating plants among the lilies." While it is clear that the man "grazing among the lilies" is a metaphor for making love ([Song of Songs 2:16](../02/16.md)), it is not clear what these words refer to. It is best to translate them literally.

#### lilies

sweet-smelling flowers that grow in places where there is much water. Translate as the plural of "lily" in [Song of Songs 2:1](../02/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deer.md)]]

### Song of Solomon 04:06

#### General Information:

The man continues to praise the woman.

#### Until the dawn arrives and the shadows flee away

Translate similar wording in this line as you did the line in [Song of Songs 2:17](../02/16.md).

#### I will go to the mountain of myrrh and to the hill of frankincense

The "mountain of myrrh" and "hill of frankincense" are metaphors for the woman's breasts (See: [Song of Songs 1:13](../01/12.md)). AT: "I will lie close to your breasts, which are like mountains that smell like myrrh and frankincense" or "I will lie close to your breasts, which smell very sweet" or "I will go to the sweet-smelling mountains" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the mountain of myrrh

"the mountain made of myrrh" or "the mountain that has myrrh growing on it"

#### the hill of frankincense

"the hill where there are clouds of smoke from burning frankincense in the air"

#### You are beautiful in every way

"Every part of you is beautiful" or "All of you is beautiful"

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](../01/09.md).

#### there is no blemish in you

"you have no blemish"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blemish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blemish.md)]]

### Song of Solomon 04:08

#### General Information:

The man continues to speak to the woman. He speaks of them not being free to make love as if they were in a wild, dangerous, foreign place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from Lebanon

"away from Lebanon"

#### my bride

This Hebrew word can refer to a woman who is married or to one whom a man has arranged to become his son's wife. If your language has a polite word that a man would use to his wife and that has not been used yet in this book, you could use it here. Otherwise you could use any polite term a man would use with his wife.

#### Amana

the name of a mountain north of Israel (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Senir

the name of a mountain near Amana and Hermon. Some people think that this refers to the same mountain as Hermon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### dens

places where lions and leopards live, like caves or holes in the ground

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mounthermon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mounthermon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leopard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leopard.md)]]

### Song of Solomon 04:09

#### General Information:

The man continues to speak to the woman.

#### You have stolen my heart

Possible meanings of this idiom are 1) "My heart now belongs completely to you" or 2) "I strongly desire to make love to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my sister

This is an idiom of affection. They are not actually brother and sister. AT: "my dear" or "my darling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my bride

This Hebrew word can refer to a woman who is married or to one whom a man has arranged to become his son's wife. If your language has a polite word that a man would use to his wife and that has not been used yet in this book, you could use it here. Otherwise you could use any polite term a man would use with his wife. See how you translated this in [Song of Songs 4:8](./08.md).

#### heart, with just one look at me, with just one jewel

"heart. All you have to do is look at me once or show me just one jewel." Both the woman's eyes and her jewelry attract the man to her.

#### necklace

This necklace probably went around her neck many times (See: [Song of Songs 4:4](./04.md)).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]

### Song of Solomon 04:10

#### General Information:

The man continues to praise the woman.

#### How beautiful is your love

"Your love is wonderful"

#### my sister

This is an idiom of affection. They are not actually brother and sister. See how you translated this in [Song of Songs 4:9](./08.md). AT: "my dear" or "my darling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my bride

This Hebrew word can refer to a woman who is married or to one whom a man has arranged to become his son's wife. If your language has a polite word that a man would use to his wife and that has not been used yet in this book, you could use it here. Otherwise you could use any polite term a man would use with his wife. See how you translated this in [Song of Songs 4:9](./08.md).

#### How much better is your love than wine

"Your love is much better than wine." See how you translated a similar phrase in [Song of Songs 1:2](../01/01.md).

#### the fragrance of your perfume than any spice

The verb may be supplied from the previous phrase. AT: "how much better is the fragrance of your perfume than the fragrance of any spice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### fragrance ... perfume

See how you translated these words in [Song of Songs 1:3](../01/01.md).

#### spice

dried plants or seeds that have a good smell or taste

#### Your lips ... drip honey

Possible meanings are that honey is a metaphor for 1) the sweet taste of the woman's kisses or 2) the woman's words. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### honey and milk are under your tongue

Because "milk and honey" is a common phrase in the Bible, you should translate literally. Possible meanings are that honey is a metaphor for 1) the sweet taste of the woman's kisses or 2) the woman's words. Milk is a metaphor for luxury, owning many things that help people enjoy life. When the woman kisses the man, he enjoys life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the fragrance of your garments is like the fragrance of Lebanon

"the smell of your clothes is like the smell of Lebanon." Many cedar trees grew in Lebanon. Cedar trees smell very good, so Lebanon would have smelled sweet and fresh.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]

### Song of Solomon 04:12

#### General Information:

The man continues to praise the woman.

#### My sister

This is an idiom of affection. They are not actually brother and sister. See how you translated this in [Song of Songs 4:9](./09.md). AT: "My dear" or "My darling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my bride

This Hebrew word can refer to a woman who is married or to one whom a man has arranged to become his son's wife. If your language has a polite word that a man would use to his wife and that has not been used yet in this book, you could use it here. Otherwise you could use any polite term a man would use with his wife. See how you translated this in [Song of Songs 4:9](./09.md).

#### is a garden locked up

"is a garden that no one can enter." The garden is a metaphor for the woman, and the lock is a metaphor for her still being a virgin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a spring that is sealed

"a spring with a cover on it." The spring or well is a metaphor for the woman, and the cover is a metaphor for her being a virgin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Your branches

branches or channels of rivers, a clear euphemism for the female body part. If any reference to this would be offensive, translate it as a synecdoche for the whole person. AT: "You" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### a grove

a place where many trees grow together

#### with choice fruits

"with the best kinds of fruits"

#### nard plants

plants that give oil that people used to make their skin soft and to have a pleasant odor. See how you translated this in [Song of Songs 1:14](../01/12.md).

#### henna

small desert trees that people used as a perfume. See how you translated this in [Song of Songs 1:14](../01/12.md).

#### saffron

a spice that comes from the dried parts from the yellow thread in the center of a certain flower

#### calamus

a reed with a pleasant smell that people used to make anointing oil.

#### cinnamon

a spice made from the bark of a tree that people used for cooking

#### myrrh

See how you translated this in [Song of Songs 1:13](../01/12.md).

#### aloes

a type of large plant that had a very sweet smell

#### all the finest spices

"all the best spices"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]

### Song of Solomon 04:15

#### General Information:

The man continues to praise the woman.

#### You are a garden spring

"You are a spring in a garden." A garden spring gives sweet, clean water that people enjoy drinking. The man enjoys being close to the woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fresh water

water that is good to drink

#### streams flowing down from Lebanon

Because Lebanon had mountains covered with trees, the streams from Lebanon were clean and cool.

#### Awake, north wind; come, south wind; blow

The woman speaks to the north wind and the south wind as though they were people. AT: "I wish the north wind and south wind would come and blow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Awake, north wind

"North wind, start blowing"

#### blow on my garden

The garden is a metaphor for her body, which she has covered with sweet-smelling oils ([Song of Songs 4:14](./12.md)). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### may give off their fragrance

"may send out their good smells"

#### May my beloved ... choice fruit

The woman is inviting the man to make love to her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### choice fruit

"wonderful fruit"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Song of Solomon 04:intro

#### Song of Songs 04 General Notes ####

####### Special concepts in this chapter #######

######## Beauty ########
The woman is described as the epitome of beauty in ancient Israel. Not all cultures share the same the same standards of beauty. 

####### Other possible translation difficulties in this chapter #######

######## Metaphors ########
In the ancient Near East, it was common to describe a woman using metaphors involving animals. In many cultures today, this can be considered offensive. Different metaphors of beauty are used in different cultures. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## "My sister, my bride" ########
The woman described is not the sister of her husband. They are not related. Instead, this is a reference to a woman who is a fellow Israelite. 

##### Links: #####

* __[Song of Songs 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Song of Solomon 05

### Song of Solomon 05:01

#### General Information:

See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]]

#### I have come

It is clearly the woman's lover who is speaking.

#### have come into my garden

The word "garden" is a metaphor for the woman. The man is finally able to fully enjoy the woman as they make love. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### my sister

This is an idiom of affection. They are not actually brother and sister. See how you translated this in [Song of Songs 4:9](../04/08.md). AT: "my dear" or "my darling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my bride

This Hebrew word can refer to a woman who is married or to one whom a man has arranged to become his son's wife. If your language has a polite word that a man would use to his wife and that has not been used yet in this book, you could use it here. Otherwise you could use any polite term a man would use with his wife. See how you translated this in [Song of Songs 4:9](../04/08.md).

#### myrrh ... spice ... honeycomb ... honey ... wine ... milk

These are all metaphors for the man enjoying the woman's body ([Song of Songs 1:13](../01/12.md), [Song of Songs 2:04](../02/03.md), [Song of Songs 4:11](../04/10.md), and [Song of Songs 4:14](../04/12.md)). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### spice

plants that have a strong smell or taste

#### Eat ... drink ... be drunk with love

Eating and drinking are metaphors for making love. AT: "Make love ... make love ... make love until you are fully satisfied" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Song of Solomon 05:02

#### General Information:

Here begins Part Four of the book

#### General Information:

The young woman uses euphemisms to describe her dream so that it can be interpreted in two different ways: 1) the woman describes a dream about a night when the man came to visit her at her house; and 2) the woman describes a dream about starting to sleep with the man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### but my heart was awake

The heart is the center of thought and feeling. AT: "but I could think clearly" or "but I knew what I was feeling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### Open to me

Possible meanings are 1) literal, "Open the door for me," or 2) metaphorical, "Let me make love to you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my sister

This is an idiom of affection. They are not actually brother and sister. See how you translated this in [Song of Songs 4:9](../04/09.md). AT: "my dear" or "my darling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](../01/09.md).

#### my dove

See how you translated this in [Song of Songs 2:14](../02/14.md).

#### undefiled one

"my perfect one" or "my faithful one" or "my innocent one"

#### dew

drops of water or mist that form as the night becomes cool

#### my hair with the night's dampness

The words "is wet" are understood from the previous phrase. They can be repeated here. AT: "my hair is wet with the night's dampness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]

### Song of Solomon 05:03

#### "I have taken off my robe ... dirty?"

This is what the woman thought to herself when she heard the man speak. ([Song of Songs 5:2](./02.md)). This could be translated with the woman saying that this is what she was thinking, or the woman could just explain the situation and her thoughts as in the UDB. AT: "I thought to myself, 'I have taken off my robe ... dirty?'" or "I had taken off my robe and I did not want to put it on again. I had washed my feet and I did not want to get them dirty." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### robe

thin linen clothing that people wore on their skin

#### must I put it on again?

This can be translated as a statement. AT: "I do not want to put it on again." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I have washed my feet

While the word "feet" can be a euphemism for private parts, this probably refers to literal feet. The woman seems more likely to want to make love than to want to refrain from lovemaking because she has just bathed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### must I get them dirty?

This can be translated as a statement. AT: "I do not want to get them dirty."

#### My beloved put in his hand through the opening of the door latch

Possible interpretations are 1) literal, the lover reaches into the house through a hole in the door in order to open the door or 2) euphemisic, they have begun to make love. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### My beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "My dear one" or "My lover"

#### door latch

"door lock"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Song of Solomon 05:05

#### I got up to open the door for my beloved

Possible meanings are 1) literal, the young woman got out of bed in order to let the man into the house, or 2), metaphorical. AT: "I prepared myself to make love with my beloved" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my hands ... my fingers ... door handle

While these may be euphemisms for the woman's and man's bodies, it is best to translate literally. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### with moist myrrh

"with liquid myrrh"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]

### Song of Solomon 05:06

#### General Information:

The woman continues to describe her dream.

#### my beloved

See how you translated this in [Song of Songs 1:13](../01/12.md).

#### My heart sank

The heart is a metaphor for the person, and sinking, going down, is a metaphor for becoming weak or sad. AT: "I was very sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]

### Song of Solomon 05:07

#### The watchmen

men who have the job of keeping guard of the town at night to keep the people safe. See how you translated this in [Song of Songs 3:3](../03/03.md).

#### as they were making their rounds in the city

"who were walking around the city on the walls." See how you translated this in [Song of Songs 3:3](../03/03.md).

#### found me

found the woman

#### struck me

"beat me" or "hit me"

#### wounded me

"injured me"

#### the guards on the walls

"the men who guard the walls"

#### cloak

a garment that people wore over the other clothing on their upper body when they went outdoors in public

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]

### Song of Solomon 05:08

#### I want you to swear

See how you translated this in [Song of Songs 2:7](../02/07.md).

#### daughters of Jerusalem

"young women of Jerusalem." These young women could not hear her and were not present, but the woman speaks as if they were present and could hear her. See how you translated this in [Song of Songs 2:7](../02/07.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### my beloved—What will you make known to him?—that I am

The woman uses a question to introduce what she wants the daughters of Jerusalem to tell her beloved. AT: "my beloved, this is what I want you to say to him: tell him that" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### sick from love

She loves the man so strongly that she feels sick. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Song of Solomon 05:09

#### your beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for the other women to refer to him as "your lover." See how you translated "my beloved" in [Song of Songs 1:13](./12.md). AT: "your dear one" or "your lover"  

#### most beautiful among women

"you who are the most beautiful of all women." See how you translated this in [Song of Songs 1:8](../01/08.md).

#### Why is your beloved better

"What makes your beloved better"

#### that you ask us to take an oath like this

"and causes you to have us take this oath"

#### an oath like this

the oath in [Song of Songs 5:8](./08.md)

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Song of Solomon 05:10

#### My beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "My dear one" or "My lover"

#### is radiant and ruddy

This phrase refers to his complexion. AT: "has radiant and ruddy skin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### radiant

"is completely healthy" or "is pure." The man has skin that does not have any problems.

#### ruddy

a healthy color of the skin that is brownish red

#### outstanding among ten thousand

"the best of 10,000." AT: "better than anyone else" or "no one else is like him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### His head is the purest gold

The man's head is as precious to the woman as the purest gold. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a raven

a bird with very black feathers (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Song of Solomon 05:12

#### General Information:

The young woman continues to describe the man.

#### His eyes are like doves

Translate "eyes are like doves" as in [Song of Songs 1:15](../01/15.md). Possible meanings are 1) the Israelites considered doves to be gentle and soft birds, and the woman considers the man's eyes beautiful because the way the man looks at her makes her think he is gentle. AT: "His eyes are gentle like doves" or 2) the woman is speaking of the man's white eyeballs or the shape of his eyes, the shape of a dove. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### doves beside streams of water

Birds that the Israelites considered gentle sitting beside a gently flowing stream are a metaphor for a gentle person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### streams of water

"gently flowing water"

#### bathed in milk

Milk is a metaphor for the whiteness of the doves. AT: "doves that are white like milk" or 2) milk is a metaphor for the white part of the man's eyes. AT: "his pupils are like doves bathing in white milk"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### mounted like jewels

His eyes are beautiful. Jewels that a craftsman has carefully put in place are beautiful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]

### Song of Solomon 05:13

#### General Information:

The young woman continues to describe the man.

#### His cheeks ... aromatic scents

This explains that his cheeks are like beds of spices because they both give off wonderful smells. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### beds of spices

gardens or parts of gardens where people grow spices. Spices give people pleasure. The man's body gives the woman pleasure. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### yielding aromatic scents

"that give off wonderful smells."

#### His lips are lilies

The woman probably compares his lips with lilies because they are beautiful and smell wonderful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lilies

See how you translated this in [Song of Songs 2:16](../02/16.md).

#### dripping liquid myrrh

"that drip with the best myrrh." His lips are moist and have a wonderful smell like myrrh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]

### Song of Solomon 05:14

#### General Information:

The young woman continues to describe the man.

#### His arms are rounded gold set with jewels

"His arms are cylinders of gold that have jewels all over them." The woman uses this image to say that his arms are beautiful and precious. The first readers would have understood this as a metaphor for the male body part (See: [Song of Songs 5:3](./03.md)), but this would be difficult to bring out in translation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his abdomen is ivory covered with sapphires

"his belly is smooth ivory that has sapphires all over it." The woman uses this image to say that his belly is beautiful and precious. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### ivory

the white tusk or tooth of an animal that is similar to bone. People use ivory to make smooth and shiny pieces of art.

#### sapphires

valuable stones that are either 1) blue or 2) clear and either blue or golden

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Song of Solomon 05:15

#### General Information:

The woman continues to describe the man.

#### His legs are pillars of marble, set on bases of pure gold

Marble and gold are strong and beautiful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### marble

a very strong stone that has many different colors and that people polish to make very smooth

#### his appearance is like Lebanon

"he looks like Lebanon." Lebanon was a very beautiful area with many mountains and cedar trees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]

### Song of Solomon 05:16

#### General Information:

The young woman continues to describe the man.

#### His mouth is most sweet

The mouth is a metonym for either 1) the man's sweet kisses or 2) the sweet words that he says. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he is completely lovely

"every part of him is lovely" or "all of him is lovely"

#### This is my beloved, and this is my friend

The word "This" refers to the man that the woman has just finished describing. AT: "That is what the one I love is like, and that is what my friend is like"

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### daughters of Jerusalem

"young women of Jerusalem." These young women could not hear her and were not present, but the woman speaks as if they were present and could hear her. See how you translated this in [Song of Songs 2:7](../02/07.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Song of Solomon 05:intro

#### Song of Songs 05 General Notes ####

####### Structure and formatting #######

Verses 2-7 describe a dream the woman had. 

####### Special concepts in this chapter #######

######## Beauty ########
The woman is described as the epitome of beauty in ancient Israel. Not all cultures share the same standards of beauty. 

####### Important figures of speech in this chapter #######

######## Metaphors ########
In the ancient Near East, it was common to describe a woman using metaphors involving animals. In many cultures today, this can be considered offensive. Different metaphors of beauty are used in different cultures. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## "My sister, my bride" ########
The woman described is not the sister of her husband. They are not related. Instead, this is a reference to a woman who is a fellow Israelite. 

##### Links: #####

* __[Song of Songs 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Song of Solomon 06

### Song of Solomon 06:01

#### General Information:

See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]]

#### In what direction has your beloved gone

"Which way did your beloved go"

#### your beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for the other women to refer to him as "your lover." See how you translated "my beloved" in [Song of Songs 1:13](./12.md). AT: "your dear one" or "your lover"  or "the man you love"

#### most beautiful among women

"you who are the most beautiful of all women." See how you translated this in [Song of Songs 1:8](../01/08.md).

#### gone, so that we may seek him with you?

The words "tell us" are understood from the context. They can be stated clearly AT: "gone? Tell us, so that we can look for him with you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Song of Solomon 06:02

#### My beloved has gone down to his garden

The word "garden" is a metaphor for the woman. The man is finally able to fully enjoy the woman as they make love. See the explanation of this metaphor in [Song of Songs 5:1](../05/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### beds of spices

gardens or parts of gardens where people grow spices. See how you translated this in [Song of Songs 5:13](../05/13.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to graze in the garden and to gather lilies

These words are metaphors for the man enjoying her body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### graze

"feeds" or "eats grass." The woman speaks of the man as if he were "a gazelle or a young stag" ([Song of Songs 2:17](../02/16.md)) that eats plants among the lilies. Grazing is probably a metaphor for lovemaking ([Song of Songs 2:1-2](../02/01.md)). See how you translated "he grazes" in [Song of Songs 2:16](../02/16.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to gather lilies

"to pick lilies"

#### lilies

sweet-smelling flowers that grow in places where there is much water. Translate as the plural of "lily" in [Song of Songs 2:1](../02/01.md).

#### I am my beloved's, and my beloved is mine

See how you translated the similar phrase "My beloved is mine, and I am his" in [Song of Songs 2:16](../02/16.md).

#### he grazes among the lilies with pleasure

See how you translated this in [Song of Songs 2:16](../02/16.md).

### Song of Solomon 06:04

#### General Information:

Here begins Part Five of the book

#### as beautiful as Tirzah, my love, as lovely as Jerusalem

These cities were famous for being beautiful and pleasant to be in. The man thinks the woman is beautiful, and he takes pleasure in being with her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### my love

"you whom I love." See how you translated this in [Song of Songs 1:9](../01/09.md).

#### lovely

See how you translated this in [Song of Songs 1:5](../01/05.md).

#### as awe-inspiring as an army with its banners

The beauty of the woman is so powerful that it makes the man feel helpless, as if an army were approaching him.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tirzah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tirzah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Song of Solomon 06:05

#### General Information:

The man continues to praise the woman.

#### overwhelm me

"terrify me." The eyes of the woman are so beautiful that it makes the man feel weak and afraid because he cannot resist their power.

#### Your hair ... from the slopes of Gilead

Translate "Your hair ... from Mount Gilead" as in [Song of Songs 4:1](../04/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Song of Solomon 06:06

#### General Information:

The man continues to praise the woman.

#### Your teeth are like a flock of ewes

After sheep have their wool cut off, they are washed and their skin looks very white. The woman's teeth are white. See how "Your teeth are like a flock of newly shorn ewes" is translated in [Song of Songs 4:2](../04/02.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### coming up from the washing place

The ewes are coming up out of the water. See how you translated this in [Song of Songs 4:2](../04/02.md). AT: "that are coming up out of the water after people have washed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Each one has a twin

Sheep usually give birth to two lambs at one time. These twin lamb usually look like one another. Each of the woman's teeth has a matching tooth on the other side of her mouth. See how you translated this in [Song of Songs 4:2](../04/02.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### none among them is bereaved

Each of the woman's teeth has a matching tooth on the other side of her mouth. She has not lost any of her teeth. See how you translated this in [Song of Songs 4:2](../04/02.md).

#### bereaved

lost a loved one who has died. See how you translated this in [Song of Songs 4:2](../04/02.md).

#### are like pomegranate halves

Pomegranates are smooth, round, and rich red. The man thinks the woman's cheeks are beautiful and show that she is healthy. See how you translated this in [Song of Songs 4:3](../04/03.md). AT: "are red and round like two halves of a pomegranate" or "are red and full and healthy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### behind your veil

See how you translated this in [Song of Songs 4:1](../04/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md)]]

### Song of Solomon 06:08

#### There are sixty queens, eighty concubines ... young women without number

These numbers are to be large, then larger, and then beyond counting. AT: "There are 60 queens, 80 concubines ... more young women than anyone could count" or "There are many queens, even more concubines, and more young women than anyone could count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### My dove

The Israelites considered doves beautiful birds with pleasant voices. The man thinks the woman's face and voice are beautiful. If calling a woman a "dove" would be offensive, you could leave out the metaphor. See how you translated this in [Song of Songs 2:14](../02/14.md). AT: "You beautiful woman" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my undefiled

"my perfect one" or "my faithful one" or "my innocent one." See how you translated this in [Song of Songs 5:2](../05/02.md).

#### the only daughter of her mother

This is an exaggeration. AT: "her mother's special daughter" or "completely different from her mother's other daughters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the woman who bore her

"the woman who gave birth to her." This phrase refers to her mother.

#### young women ... queens ... concubines

the women spoken of in verse 8

#### called her blessed

"said that things had gone especially well for her"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Song of Solomon 06:10

#### General Information:

The ULB understands this to be what the queens and the concubines said about the woman. However, some versions understand these to be the words of the man.

#### Who is this who appears like the dawn ... banners?

They are using this question to say that they think the young woman is amazing. AT: "This is an amazing woman! She comes into view like the dawn ... banners!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### who appears like the dawn

The dawn is beautiful. The woman is beautiful. AT: "who comes into view like the dawn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### as awe-inspiring as an army with its banners

The beauty of the woman is so powerful that it makes the other women feel helpless, as if an army were approaching them. See how you translated this in [Song of Songs 6:4](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]

### Song of Solomon 06:11

#### General Information:

The man finishes speaking to himself. Looking to see if plants had matured is probably a metaphor for enjoying the sight of the woman's body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### grove

See how you translated this in [Song of Songs 4:13](../04/12.md).

#### young growth

"young plants" or "new shoots"

#### had budded

"had grown their buds." Buds are the small round parts of plants which open up into flowers.

#### were in bloom

"were opening their flowers"

#### I was so happy that I felt I was riding in the chariot of a prince

The man uses this image to express how happy he is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Song of Solomon 06:13

#### General Information:

This is 7:1, the first verse of chapter seven, in some versions. The ULB understands this to be the friends and the woman talking to each other. Some versions understand this to be the man speaking to the woman.

#### Turn back ... gaze on you

Possible interpretations are 1) the friends are speaking to the woman or 2) the man is referring to himself in plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### Turn back, turn back

"Come back, come back." This is repeated for emphasis.

#### we may gaze

Some versions understand the plural to refer to the man speaking of himself. AT: "I may gaze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### gaze

look intently for a long time

#### Why do you gaze on the perfect woman ... armies

Possible interpretations are 1) the woman refers to herself as another person and is speaking to the friends or 2) the woman is speaking to the man as if he were many men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### as if on the dance between two armies

"as if she were dancing between two armies"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]

### Song of Solomon 06:intro

#### Song of Songs 06 General Notes ####

####### Special concepts in this chapter #######

######## Beauty ########
The woman is described as the epitome of beauty in ancient Israel. Not all cultures share the same standards of beauty. 

####### Other possible translation difficulties in this chapter #######

######## Metaphors ########
In the ancient Near East, it was common to describe a woman using metaphors involving animals. In many cultures today, this can be considered offensive. Different metaphors of beauty are used in different cultures. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Song of Songs 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Song of Solomon 07

### Song of Solomon 07:01

#### General Information:

This is 7:2, the second verse of chapter seven, in some versions.

#### How beautiful your feet appear in your sandals

It may be that the woman is dancing ([Song of Songs 6:13](../06/13.md)). AT: "Your feet are so very beautiful in your sandals as you dance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### prince's daughter

Another possible interpretation is "you who have a noble character."

#### The curves of your thighs are like jewels

The shape of the woman's thighs remind the speaker of a beautiful precious stone that a skilled workman has carved. AT: "The curves of your thighs are beautiful like the beautiful curves of jewel that a skilled craftsman has made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### your thighs

The word "thighs" refers to the hips of a woman and the part of her legs that is above her knee.

#### the work of the hands of a master craftsman

The hands are a synecdoche for the person. AT: "the work of a master craftsman" or "something that a master craftsman has made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Song of Solomon 07:02

#### General Information:

The young woman's lover continues describing the one he loves.

#### Your navel is like a round bowl

A bowl is round. The woman's navel is round. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### navel

the spot on the stomach left from the cord that attaches a baby to its mother

#### may it never lack mixed wine

People used large bowls to mix wine with water or spices at feasts. Drinking wine is a metaphor for enjoying beauty. The litotes can be translated as a positive. AT: "may it always contain mixed wine" or "may I always enjoy its beauty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Your belly is like a mound of wheat encircled with lilies

The Israelites thought mounds of wheat and lilies were pleasant to look at. Much wheat was a sign that there would be much food to eat. They threshed wheat in high, dry places, and lilies grow in low, wet places, so this simile combines beautiful sights that people would not usually see at the same time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Your belly is like a mound of wheat

People thought that the color of wheat was the most beautiful color of skin and that round piles of wheat were beautiful. AT: "Your belly has a beautiful color and is round like a pile of wheat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a mound of wheat

This is a pile of the grains of wheat after people remove the parts of it that they do not use.

#### encircled with lilies

"with lilies all around it"

#### lilies

sweet-smelling flowers that grow in places where there is much water. Translate as the plural of "lily" in [Song of Songs 2:1](../02/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]

### Song of Solomon 07:03

#### General Information:

The man continues describing the woman.

#### two breasts

If the word "two" seems unnecessary and so out of place, you could omit it. See how you translated this in [Song of Songs 4:5](../04/04.md).

#### like two fawns, twins of a gazelle

The man implies that the woman's breasts are matching, soft, and perhaps small. See how you translated this in [Song of Songs 4:5](../04/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### twins

the babies of a mother who gave birth to two babies at one time. See how you translated this in [Song of Songs 4:5](../04/04.md).

#### gazelle

an animal that looks like a deer and moves quickly. Translate as the singular of "gazelles" as in [Song of Songs 2:7](../02/07.md).

#### Your neck is like a tower of ivory

A tower is long and straight. Ivory is white. The woman's neck is long and straight, and her skin is light in color. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a tower of ivory

"a tower that people have decorated with ivory"

#### ivory

the white tusk or tooth of an animal that is similar to bone. People use ivory to make art and to make things look beautiful.

#### your eyes are the pools in Heshbon

The woman's eyes are spoken of as if they are clear pools of water. Pools of water are clear and sparkle in the sunlight and so are pleasant to look at. The woman's eyes are clear and sparkle and so are pleasant to look at. This can be stated as a simile. AT: "your eyes are as clear as the pools in Heshbon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Heshbon

the name of a city east of the Jordan River (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bath Rabbim

the name of a city (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### nose is like the tower in Lebanon

A tower is tall and straight, and her nose is tall and straight. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### that looks toward Damascus

The tower looking is a metonym for people on the tower looking. AT: "that allows people to look toward Damascus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/damascus.md)]]

### Song of Solomon 07:05

#### General Information:

The man continues to describe the woman.

#### Your head is on you like Carmel

Mount Carmel is higher than everything else around it. The man wants to look at the woman's head more than at anything else. AT: "Your head is on you like a crown, higher than anything else" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### dark purple

Other possible translations are 1) "dark black" or 2) "dark red."

#### The king is held captive by its tresses

This can be translated in active form. AT: "Your hair that hangs down is so beautiful that the king is not able to stop admiring it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### tresses

the clusters of hair that hang down from a woman's head.

#### love

"you whom I love" or "you who are loved"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/purple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Song of Solomon 07:07

#### General Information:

The man describes what he would like to do with the woman .

#### Your height is like that of a date palm tree

"You stand up like a date palm tree." Date palm trees are tall and straight, and their branches are only at the top, with the fruit under the branches. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### date palm tree

a tall, straight tree that produces a sweet, brown, and sticky fruit that grows in groups

#### your breasts like clusters of fruit

The dates on a palm tree grow soft and round in large bunches that hang from the tree just below the branches, which are all at the top. The woman's breasts are soft and round and are just lower than her arms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### I said

"I thought" or "I said to myself." The man said this silently.

#### I want to climb ... its branches

The man wants to embrace the woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### May your breasts be like clusters of grapes

The man wants to touch her breasts. Clusters of grapes are round and soft. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### may the fragrance of your nose be like apricots

The word "nose" is a metonym for the breath coming out of the nose. AT: "may the breath coming from your nose smell sweet like apricots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### apricots

sweet yellow fruit

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]

### Song of Solomon 07:09

#### General Information:

The man continues describing what he would like to do with the woman.

#### May your palate be like the best wine

The palate is a metonym for the lips. Wine tastes good. The man wants to kiss the woman's lips. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### flowing smoothly for my beloved

"that flows smoothly for the one I love." The man enjoys the smooth kisses of the woman.

#### gliding over the lips of those who sleep

"that flows over our lips as we sleep"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Song of Solomon 07:10

#### I am my beloved's

See how you translated a similar phrase in [Song of Songs 6:3](../06/01.md).

#### my beloved's

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one's" or "my lover's"

#### he desires me

"he wants to make love to me" or "he wants me"

#### spend the night in the villages

Though the words here translated "spends the night" and "villages" appear together in [Song of Songs 1:13-14](../01/12.md) as "spends the night" and "henna flowers," and the context both here and there is lovemaking, the ULB chooses this reading because the immediate metaphor is of the man and woman sleeping in the village, rising in the morning, and going out into the vineyards. The word for "henna plants" and the word for "villages" sound exactly the same.

### Song of Solomon 07:12

#### General Information:

The woman continues to speak to the man.

#### rise early

"get up early" or "wake up early"

#### have budded

"have begun to bloom"

#### blossoms

flowers when they are open

#### are in flower

"have flowers open on the plant"

#### I will give you my love

"I will make love with you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Song of Solomon 07:13

#### General Information:

The woman continues to speak to the man.

#### mandrakes

This is the name of plants that give off a strong but pleasant scent. The scent is slightly intoxicating and stimulating, which increases the desire to make love. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### give off their fragrance

"produce their scent" or "smell very nice"

#### at the door

The doors belong to their house. AT: "above the entrances of our house" or "by the doors of our house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### are all sorts of choice fruits, new and old

"is every kind of the best fruit, both old fruit and new fruit"

#### stored up for you

"saved so I can give to you"

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Song of Solomon 07:intro

#### Song of Songs 07 General Notes ####

####### Special concepts in this chapter #######

######## Beauty ########
The woman is described as the epitome of beauty in ancient Israel. Not all cultures share the same the same standards of beauty. 

####### Important figures of speech in this chapter #######

######## Similes ########
There are many similes in this chapter. Their purpose is to describe the beauty of the woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

##### Links: #####

* __[Song of Songs 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Song of Solomon 08

### Song of Solomon 08:01

#### General Information:

See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]]

#### you were like my brother

A woman could show affection for her brother in public. This woman wanted to be able to show affection for the man in public. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### you outside

"you in public"

#### I could kiss you

A woman would probably kiss her brother on his cheek order to greet him.

#### would despise me

"would think that I am a bad person"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]

### Song of Solomon 08:02

#### General Information:

The young woman continues to speak to the man.

#### I would lead you and bring you into my mother's house

If the man were her brother, she could bring him to the family home. This was normal in that culture and is still today in some.

#### she who taught me

taught her how to make love (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I would give you spiced wine to drink and some of the juice of my pomegranates

The woman uses these images to say that she will give herself to the man and make love with him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### spiced wine

"wine with spices" or "wine that has spices in it." This represents the intoxicating power of lovemaking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### His left hand ... embraces me

See how you translated this in [Song of Songs 2:6](../02/05.md).

#### left hand ... right hand

"left arm ... right arm"

#### embraces me

"holds me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pomegranate.md)]]

### Song of Solomon 08:04

#### I want you to swear

See how you translated this in [Song of Songs 2:7](../02/07.md)

#### daughters of Jerusalem

"young women of Jerusalem." These young women could not hear her and were not present, but the woman speaks as if they were present and could hear her. See how you translated this in [Song of Songs 2:7](../02/07.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### that you will ... until it is over

See how you translated this in [Song of Songs 2:7](../02/07.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]

### Song of Solomon 08:05

#### General Information:

Here begins Part Six of the book, the final part

#### Who is this who is coming up

They are using this question to say that they think the young woman is amazing. A similar phrase was translated in in [Song of Songs 6:10](../06/10.md). AT: "Look at this amazing woman as she comes up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I awakened you

"I woke you up" or "I aroused you"

#### the apricot tree

a tree that produces a small yellow fruit that is very sweet. If your readers will not know what this is, you could use the word for another fruit tree or the general word "fruit tree." See how you translated this in [Song of Songs 2:3](../02/03.md).

#### there

under the apricot tree

#### she delivered you

"she bore you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/conceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/conceive.md)]]

### Song of Solomon 08:06

#### General Information:

The young woman continues to speak to the man.

#### Set me as a seal over your heart, like a seal on your arm

Possible meanings are 1) because seals were very important, people always kept them around their neck or on their hand. The woman wants to be with the man constantly like a seal, or 2) a seal shows who owns the thing that has the seal on it, and the woman wants herself as the seal on the man's heart and arm to show that all of his thoughts, emotions, and actions belong to her. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### for love is as strong as death

Death is very strong because it overcomes even the most powerful people of the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### as unrelenting as Sheol

"as tough as Sheol." Sheol never allows people to come back to life after they have already died. Love is as persistent as Sheol because it never changes. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### its flames burst out ... any other fire

Love is very powerful like fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### burst out

"burn suddenly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Song of Solomon 08:07

#### General Information:

The young woman continues to speak to the man.

#### Surging waters cannot quench love

Love is so strong that it is like a fire that is so hot that it cannot be put out even with an ocean full of water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Surging waters

"Oceans of water" or "Huge amounts of water"

#### cannot quench

"cannot extinguish" or "cannot put out"

#### nor can floods sweep it away

Love never changes and always stays the same so it is like something that not even a powerful flood can move. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### floods

In Israel, water from the rain flows into deep and narrow valleys. This creates a flood of water so powerful that it can move huge boulders and trees.

#### sweep it away

"carry it away" or "wash it away"

#### If a man gave ... the offer would utterly be despised

This is something that could possibly happen. AT: "Even if a man ... he would be utterly despised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### gave

offered to give

#### all the possessions in his house

"everything he owns"

#### for love

"in order to get love" or "in order to buy love"

#### the offer would utterly be despised

This can be translated in active form. AT: "people would completely despise him" or "people would harshly ridicule him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Song of Solomon 08:08

#### little sister

"young sister"

#### What can we do ... in marriage?

The speaker uses this question to introduce what he wants to say. AT: "This is what we will do ... in marriage." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### she will be promised in marriage

This can be translated in active form. AT: "a man comes and wants to marry her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Song of Solomon 08:09

#### General Information:

The young woman's brothers continue to speak among themselves.

#### If she is a wall ... If she is a door

The little sister ([Song of Songs 8:8](./08.md)) has very small breasts that either have not grown or are very small. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### we will build on her a tower of silver ... we will adorn her with boards of cedar

The brothers decide to decorate the little sister with silver and cedar, symbols of riches, so that she will be more likely to attract a good husband. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will adorn her

"will decorate her"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]

### Song of Solomon 08:10

#### I was a wall

The wall is a metaphor for a woman with small breasts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my breasts are now like fortress towers

Fortress towers are tall. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### I am in his eyes as one

Here eyes are a metonym for judgment or value. AT: "I am in his judgment as one" or "he thinks of me as one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### brings peace

You may need to make explicit to whom the woman brings peace. AT: "brings him peace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### peace

"well-being"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]

### Song of Solomon 08:11

#### General Information:

Possible interpretations: 1) The woman contrasts the way she wants to give herself to the man, who will give her his love, to the way Solomon leases out his vineyard to those who will give him money. 2) The man contrasts the woman, whom he will not give to another man, to Solomon's vineyard, which he gave to other men.

#### Baal Hamon

This is the name of a town in the northern part of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### gave the vineyard

leased, agreed to let other people pay him so they could grow grapes in the vineyard

#### to those who would maintain it

"to people who would take care of it"

#### Each one was to bring a thousand shekels of silver for its fruit

It may be helpful to state that this payment was for the fruit of the vineyard. AT: "Each man was supposed to give Solomon a thousand shekels as payment for the fruit of the vineyard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### to bring a thousand shekels of silver

"to bring 1,000 shekels of silver." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### My vineyard, my very own

The woman refers to herself as a vineyard, as in [Song of Songs 1:6](../01/05.md). Here she emphasizes that she and no one else will decide what she dies with the "vineyard." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### is before me

This is an idiom that means the a person has the right to do what they want with something. AT: "is at my disposal" or "is mine to do with as I desire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the thousand shekels are for you, Solomon

The woman knows that Solomon has leased out the vineyard so he can get money, but she does not want money.

#### shekels

"coins"

#### Solomon

Some versions understand the woman to be speaking directly to Solomon. Others understand her to be speaking in an apostrophe to her friends, to the man, or to herself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### the two hundred shekels

The speaker has not mentioned these before, but the hearer would understand that she is speaking of the money that those who worked the vineyard would have left for their own after they paid Solomon.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Song of Solomon 08:13

#### You who live

The man is speaking to the woman, so "you" and "live" are feminine singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### listening for your voice

The voice is a metonym for what the person says. If your language has a word for thinking only of what one is listening for, you could use it here. AT: "waiting to hear you start speaking" or "waiting to hear what you have to say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### let me hear it

"let me hear your voice."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Song of Solomon 08:14

#### my beloved

This phrase refers to the man whom the woman loves. In some languages it may be more natural for her to refer to him as "my lover." See how you translated this in [Song of Songs 1:13](./12.md). AT: "my dear one" or "my lover"

#### like a gazelle or a young stag

See how you translated this in [Song of Songs 2:9](../02/08.md).

#### gazelle

a type of slender deer-like animal with long curved horns

#### stag

an adult male deer

#### the mountains of spices

"the mountains that have spices all over them." The woman uses this metaphor to invite the man to make love to her. See how the man uses the metaphor of a mountain of myrrh and a hill of frankincense in [Song of Songs 4:6](../04/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Song of Solomon 08:intro

#### Song of Songs 08 General Notes ####

####### Special concepts in this chapter #######

######## Kisses ########
The kisses in this chapter are a type of kiss that was only done between a husband and a wife. It is an intimate kiss. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Passion ########
The chapter describes the passion that can exist between a husband and a wife. This is the feeling of strong or uncontrollable desire for another person. 

##### Links: #####

* __[Song of Songs 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | __


## Song of Solomon front

### Song of Solomon front:intro

#### Introduction to The Song of Songs ####

##### Part 1: General Introduction #####

####### Outline of The Song of Songs #######

1. The bride longs for the bridegroom to arrive (1:1–2:7)
1. The bridegroom praises the woman he loves (2:8–3:5)
1. The bridegroom arrives and praises the bride (3:6–5:1)
1. The bride longs for the bridegroom (5:2–6:9)
1. The bridegroom praises the beauty of his bride (6:1–8:4)
1. Final thoughts about love between a man and a woman (8:5–14)

####### What is the Song of Songs about? #######

The Song of Songs is a poem or a series of poems about the love between a man and a woman. It became traditional for Jews to interpret the book as a picture of God's love for the people of Israel. In the same way, it became traditional for Christians to interpret it as a picture of Christ's love for all Christian believers.

####### How should the title of this book be translated? #######

This book may also be called the "Songs of Love," "Great Poems of Love" or "The Love Songs of Solomon." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]]) 

####### Who wrote The Song of Songs? #######

The idea that Solomon, king of Israel, was its author comes from the opening verse of the book ("The Song of Songs, which is Solomon's"). However, there are different ways to interpret this verse, so not everyone is persuaded that Solomon was the book's author.

##### Part 2: Important Religious and Cultural Concepts #####

####### What place do the descriptions of sexual behavior have in The Song of Songs? #######

The Song of Songs shows approval of sexual behavior as an expression of love between a husband and wife. 

##### Part 3: Important Translation Issues #####

####### How many characters are in The Song of Songs? #######

The two main characters in this book are the man and the woman, who love each other. There is also the group of women to whom the young woman speaks. The women also make comments. However, it is possible that the group of women is not real and the woman is only imagining them.

Some interpreters believe there may be more characters than these, but this is not certain. The interpretation adopted by the ULB and UDB recognizes only the man, the woman, and the group of women.

####### What are the lines about people speaking? #######

The Song of Songs is a poem that shows the thoughts and words of a man, a woman, and the woman’s friends. The author did not identify the speakers and their audience throughout the poem. So to help readers understand the poem, some translations attempt to identify the speaker and the audience. It is not always certain who the speaker is, so sometimes translations disagree about who is speaking.

Before each speech, the ULB identifies the speaker and the audience like this: "The woman speaking to the other women," "The woman speaking to the man," "The man speaking to the woman," and "The woman speaking to herself." Translators are encouraged to include these ways of identifying the speaker and the audience, and to format them differently from the scripture text. The translators should also include a note explaining that these explanations are not actually part of the scripture.

####### How should one translate The Song of Songs if the readers will view certain terms as coarse, vulgar, or improper? #######

There are many images or forms appearing in the Song of Songs that, when translated, may be considered improper. The translator should try to avoid offensive language if possible, by using expressions that will not cause offense. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

####### How do I translate metaphors in this book? #######

There are many metaphors in this book. These metaphors are often ambiguous. If they have sexual meanings, metaphors describing feelings or emotions are often used to avoid offense by veiling their meaning. However, since their meanings are often very unclear, ambiguity in translation is encouraged. You might choose to translate the words as they are written in order to avoid committing to a specific meaning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])



---

