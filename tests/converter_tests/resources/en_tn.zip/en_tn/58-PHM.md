# <a id="phm"/>Philemon

## Philemon 01

### Philemon 01:01

#### General Information:

Three times Paul identifies himself as the author of this letter. Evidently Timothy was with him and probably wrote the words down as Paul said them. Paul greets others who meet for church at Philemon's house.

#### General Information:

All instances of "I," "me," and "my" refer to Paul. Philemon is the main person to whom this letter is written. All instances of "you" and "your" refer to him and are singular unless otherwise noted. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Paul, a prisoner of Christ Jesus, and the brother Timothy to Philemon

Your language may have a particular way of introducing the authors of a letter. AT: "I, Paul, a prisoner of Christ Jesus, and Timothy, our brother, are writing this letter to Philemon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### a prisoner of Christ Jesus

"a prisoner for the sake of Christ Jesus." People who opposed Paul's preaching had punished him by putting him into prison.

#### brother

Here this means a fellow Christian.

#### Philemon, our dear friend ... Apphia our sister ... Archippus our fellow soldier

The word "our" here refers to Paul and those with him but not to the reader. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### and fellow worker

"who, like us, works to spread the gospel"

#### Apphia our sister

Here "sister" means she was a believer, and not a relative. AT: "Apphia our fellow believer" or "Apphia our spiritual sister" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Archippus

This is the name of a man in the church with Philemon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### our fellow soldier

Paul speaks here of Archippus as if they were both soldiers in an army. He means that Archippus works hard, as Paul himself works hard, to spread the gospel. AT: "our fellow spiritual warrior" or "who also fights the spiritual battle with us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### May grace be to you and peace from God our Father and the Lord Jesus Christ

"May God our Father and the Lord Jesus Christ give you grace and peace." This is a blessing.

#### God our Father

The word "our" here refers to Paul, those with him, and the reader. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### our Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Philemon 01:04

#### General Information:

The word "us" is plural and refers to Paul, those with him, and all Christians, including the readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### that the fellowship of your faith

"that your working together with us"

#### be effective for the knowledge of everything good

"result in knowing what is good"

#### in Christ

"because of Christ"

#### the hearts of the believers have been refreshed by you

"Hearts" here is a metonym for "inner convictions" or "thoughts and intentions." AT: "the thoughts and intentions of the believers have been refreshed by you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]]) This can be stated in active form. AT: "you encouraged believers" or "you have helped the believers" [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you, brother

"you, dear brother" or "you, dear friend." Paul called Philemon "brother" because they were both believers and he emphasizing their friendship.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Philemon 01:08

#### Connecting Statement:

Paul begins his plea and the reason for his letter.

#### all the boldness in Christ

Possible meanings are 1) "authority because of Christ" or 2) "courage because of Christ." AT: "courage because Christ has given me authority"

#### yet because of love

Possible meanings: 1) "because I know that you love God's people" 2) "because you love me" or 3) "because I love you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Philemon 01:10

#### General Information:

Onesimus is the name of a man. He was apparently Philemon's slave and had stolen something and ran away.

#### my child Onesimus

"my son Onesimus." Paul speaks of the way he is friends with Onesimus as if it were the way a father and his son love each other. Onesimus was not Paul's actual son, but he received spiritual life when Paul taught him about Jesus, and Paul loved him. AT: "my spiritual son Onesimus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Onesimus

The name "Onesimus" means "profitable" or "useful." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### whom I have fathered in my chains

Here "fathered" is a metaphor that means Paul converted Onesimus to Christ. AT: "who became my spiritual son when I taught him about Christ and he received new life while I was in my chains" or "who became like a son to me while I was in my chains" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in my chains ... while I am in chains

Prisoners were often bound in chains. Paul was in prison when he taught Onesimus and was still in prison when he wrote this letter. AT: "while I was in prison ... while I am in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I have sent him back to you

Paul was probably sending Onesimus with another believer who carried this letter.

#### who is my very heart

"Heart" here is a metonym for inner life, or "motivation for living." AT: "who is my very motivation for living" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])
#### so he could serve me for you

"so that, since you cannot be here, he might help me" or "so that he could help me in your place"

#### for the sake of the gospel

Paul was in prison because he preached the gospel publicly. This can be stated explicitly. AT: "because I preach the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]

### Philemon 01:14

#### But I did not want to do anything without your consent

Paul states a double negative to mean the opposite. AT: "But I wanted to keep him with me only if you approved" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### I did not want your good deed to be from necessity but from good will

"I did not want you to do this good deed because I commanded you to do it, but because you wanted to do it"

#### but from good will

"but because you freely chose to do the right thing"

#### Perhaps for this he was separated from you for a time, so that

This can be stated in active form. AT: "Perhaps the reason God took Onesimus away from you for a time was so that" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for a time

"during this time"

#### better than a slave

"more valuable than a slave"

#### a beloved brother

"a dear brother" or "a precious brother in Christ"

#### much more so to you

"he means even more to you"

#### in both the flesh

"both as a man." Paul is referring to Onesimus' being a trustworthy servant. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the Lord

"as a brother in the Lord" or "because he belongs to the Lord"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Philemon 01:17

#### if you have me as a partner

"if you think of me as a fellow worker for Christ"

#### charge that to me

"say that I am the one who owes you"

#### I, Paul, write this with my own hand

"I, Paul, write this myself." Paul wrote this part with his own hand so that Philemon would know that the words were really from Paul. Paul really would pay him.

#### not to mention

"I do not need to remind you" or "You already know." Paul says he does not need to tell Philemon this, but then continues to tell him anyway. This emphasizes the truth of what Paul is telling him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### you owe me your own self

"you owe me your own life." Paul was implying that Philemon should not say that Onesimus or Paul owed him anything because Philemon owed Paul even more. The reason Philemon owed Paul his life can be made explicit. AT: "you owe me much because I saved your life" or "you owe me your own life because what I told you saved your life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### refresh my heart

Here "refresh" is a metaphor for comfort or encourage. How Paul wanted Philemon to do this can be made explicit. AT: "encourage me" or "comfort me" or "refresh my heart by accepting Onesimus kindly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]

### Philemon 01:21

#### Connecting Statement:

Paul closes his letter and gives a blessing on Philemon and the believers that met for church in Philemon's house.

#### General Information:

Here the words "your" and "you" are plural and refer to Philemon and the believers that met at his house. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Confident about your obedience

"Because I am sure that you will do what I ask"

#### At the same time

"Also"

#### prepare a guest room for me

"make a room in your house ready for me." Paul asked Philemon to do this for him.

#### I will be given back to you

"those who are keeping me in prison will set me free so that I can go to you."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Philemon 01:23

#### Epaphras

This is a fellow believer and prisoner with Paul. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### my fellow prisoner in Christ Jesus

"who is in prison with me because he serves Christ Jesus"

#### So do Mark, Aristarchus, Demas, and Luke, my fellow workers

"Mark, Aristarchus, Demas, and Luke, my fellow workers, also greet you"

#### Mark ... Aristarchus ... Demas ... Luke

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### my fellow workers

"the men who work with me" or "who all work with me."

#### May the grace of our Lord Jesus Christ be with your spirit

The word "your" here refers to Philemon and all who met in his house. The words "your spirit" are a synecdoche and represent the people themselves. AT: "May our Lord Jesus Christ be kind to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnmark.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnmark.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/luke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/luke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

## Philemon front

### Philemon front:intro

#### Introduction to Philemon ####

##### Part 1: General Introduction #####

####### Outline of the Book of Philemon #######

1. Paul greets Philemon (1:1-3)
1. Paul makes requests of Philemon about Onesimus (1:4-21)
1. Conclusion (1:22-25)

####### Who wrote the Book of Philemon? #######

Paul wrote Philemon. Paul was from the city of Tarsus. He had been known as Saul in his early life. Before becoming a Christian, Paul was a Pharisee. He persecuted Christians. After he became a Christian, he traveled several times throughout the Roman Empire telling people about Jesus.

Paul was in a prison when he wrote this letter.

####### What is the Book of Philemon about? #######

Paul wrote this letter to a man named Philemon. Philemon was a Christian who lived in the city of Colossae. He owned a slave named Onesimus. Onesimus had run away from Philemon and possibly stole something from him as well. Onesimus went to Rome and visited Paul in prison. 

Paul told Philemon that he was sending Onesimus back to him. Philemon had the right to execute Onesimus according to Roman law. But Paul said that Philemon should accept Onesimus back as a Christian brother. He even suggested that Philemon should allow Onesimus to come back to Paul and help him in prison.

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Philemon." Or they may choose a clearer title, such as "Paul's Letter to Philemon" or "The Letter Paul wrote to Philemon." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### Does this letter approve of the practice of slavery? #######

Paul sent Onesimus back to his former master. But that did not mean Paul thought slavery was an acceptable practice. Instead, Paul was more concerned with people serving God in whatever situation they were in.

####### What does Paul mean by the expression "in Christ," "in the Lord," etc.? #######

Paul meant to express the idea of a very close union with Christ and the believers. See the introduction to the Book of Romans for more details about this kind of expression.

##### Part 3: Important Translation Issues #####

####### Singular and plural "you" #######

In this book, the word "I" refers to Paul. The word "you" is almost always singular and refers to Philemon. The two exceptions to this are 1:22 and 1:25. There "you" refers to Philemon and the believers that met at his house. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])



---

