# <a id="jas"/>James

## James 01

### James 01:01

#### General Information:

The apostle James writes this letter to all the Christians. Many of them were Jews, and they lived in many different places.

#### James, a servant of God and of the Lord Jesus Christ

The phrase "this letter is from" is implied. AT: "This letter is from James, a servant of God and of the Lord Jesus Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to the twelve tribes

Possible meanings are 1) this is a synecdoche for Jewish Christians, or 2) this is a metaphor for all Christians. AT: "to God's faithful people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the dispersion

The term "dispersion" normally referred to the Jews who were scattered in other countries, away from their homeland Israel. This abstract noun can be expressed with a phrase with the verb "scattered." AT: "who are scattered around the world" or "who live in other countries" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Greetings!

a basic greeting, such as "Hello!" or "Good day!"

#### Consider it all joy, my brothers, when you experience various troubles

"My fellow believers, think of all your different kinds of troubles as something to celebrate"

#### the testing of your faith produces endurance

The expressions "the testing," "your faith," and "endurance" are nouns that stand for actions. God does the testing, that is, he finds out how much the believers trust and obey him. Believers ("you") believe in him and endure suffering. AT: "when you suffer hardships, God is finding out how much you trust him. As a result, you will become able to endure even more hardships" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]

### James 01:04

#### Let endurance complete its work

Here endurance is spoken of as if it were a person at work. AT: "Learn to endure any hardship" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### fully developed

able to trust in Christ and obey him in all circumstances

#### not lacking anything

This can be stated in the positive. AT: "having all that you need" or "being all that you need to be"

#### ask for it from God, the one who gives

"ask God for it. He is the one who gives"

#### gives generously and without rebuke to all

"gives generously and does not rebuke any"

#### he will give it

"God will do it" or "God will answer your prayer"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]

### James 01:06

#### in faith, doubting nothing

This can be stated in the positive. AT: "with complete certainty that God will answer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### For anyone who doubts is like a wave in the sea that is driven by the wind and tossed around

Anyone who doubts that God will help him is said to be like the water in the ocean or in a large lake, which keeps moving in different directions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### is double-minded

The word "double-minded" refers to a person's thoughts when he is unable to make a decision. AT: "cannot decide if he will follow Jesus or not" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### unstable in all his ways

Here this person is spoken of as if he cannot stay on one path but instead goes from one to another. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### James 01:09

#### the poor brother

"the believer who does not have much money"

#### boast of his high position

Someone whom God has honored is spoken of as if he were standing in a high place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but the rich man of his low position

The words "let boast" are understood from the previous phrase. AT: "but let the rich man boast of his low position" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### but the rich man

"but the man who has a lot of money." Possible meanings are 1) the rich man is a believer or 2) the rich man is an unbeliever.

#### of his low position

A rich believer should be happy if God causes him to suffer. AT: "should be happy that God has given him difficulties" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### he will pass away as a wild flower in the grass

Rich people are spoken of as being similar to wild flowers, which are alive for only a short time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### its beauty perishes

A flower no longer being beautiful is spoken of as if its beauty dies. AT: "and it is no longer beautiful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the rich man will fade away in the middle of his journey

Here the flower simile is probably continued. As flowers do not die suddenly but instead fade away over a short time, so also the rich people may not die suddenly but instead take a little time to disappear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### in the middle of his journey

A rich man's activities in daily life are spoken of as if they are a journey that he is making. This metaphor implies that he is giving no thought to his coming death, and that it will takes him by surprise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### James 01:12

#### Connecting Statement:

James reminds the believers who have fled that God does not cause temptation; he tells them how to avoid temptation.

#### Blessed is the man who endures testing

"The man who endures testing is fortunate" or "The man who endures testing is well off"

#### endures testing

remains faithful to God during hardships

#### passed the test

he has been approved by God

#### receive the crown of life

Eternal life is spoken of as if it were a wreath of leaves placed on the head of a victorious athlete. AT: "receive eternal life as his reward" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### has been promised to those who love God

This can be stated in active form. AT: "God has promised to those who love him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### when he is tempted

"when he desires to do something evil"

#### I am tempted by God

This can be stated in active form. AT: "God is trying to make me do something evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### God is not tempted by evil

This can be stated in active form. AT: "No one can make God desire to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### nor does he himself tempt anyone

"and God himself does not try to persuade anyone do evil"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### James 01:14

#### each person is tempted by his own desire

A person's desire is spoken of as if it were someone else who was tempting him to sin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### which drags him away and entices him

Evil desire continues to be spoken of as if it were a person who could drag away someone else. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### entices

attracts, persuades someone to do evil

#### Then after the desire conceives, it gives birth to sin, and after the sin is full grown, it gives birth to death

Desire continues to be spoken of as a person, this time clearly as a woman who becomes pregnant with a child. The child is identified as sin. Sin is another female baby that grows up, becomes pregnant, and gives birth to death. This chain of metaphors is a picture of someone who ends up dying both spiritually and physically because of his evil desires and his sin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do not be deceived

"Do not let anyone deceive you" or "Stop deceiving yourselves"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### James 01:17

#### Every good gift and every perfect gift

These two phrases mean basically the same thing. James uses them to emphasize that anything good that a person has comes from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the Father of lights

God, the creator of all the lights in the sky (sun, moon, and stars), is said to be their "Father." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### With him there is no changing or shadow because of turning

This expression pictures God as an unchanging light, like the sun, moon, planets, and stars in the sky. This is in contrast to shadows here on earth that constantly change. AT: "God does not change. He is as as constant as the sun, moon, and stars in the sky, rather than like shadows which appear and disappear on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### to give us

The word "us" refers to James and his audience. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### give us birth

God, who brought us eternal life, is spoken of as if he had given us birth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the word of truth

The true message of God. This is spoken of as if it were the means by which God "gave us birth." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### a kind of firstfruits

James is using the traditional Hebrew idea of firstfruits as a way to describe the value of the Christian believers to God. He implies that there will be many more believers in the future. AT: "a kind of first offering to be made to God in the great celebration of harvest"(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]

### James 01:19

#### You know this

Possible meanings are 1) "Know this" as a command, to pay attention to what I am about to write or 2) "You know this" as a statement, that I am about to remind you of something that you already know.

#### Let every man be quick to hear, slow to speak

These sayings are idioms that mean people should first listen intently, and then consider carefully what they say. Here "slow to speak" does not mean speaking slowly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### slow to anger

"not get angry quickly"

#### the anger of man does not work the righteousness of God

When a person is always angry, he cannot do God's work, which is righteous.

#### take off all sinful filth and abundant amounts of evil

Sin and evil are spoken of here as if they were clothing that could be taken off. AT: "stop doing all filthy sins and stop doing abundant amounts of evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### take off all sinful filth and abundant amounts of evil

Here the expressions "sinful filth" and "evil" share similar meanings. James uses them to emphasize how bad sin is. AT: "stop doing every kind of sinful behavior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### sinful filth

Here "filth," that is, dirt, stands for sin and evil. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### In humility

"Without pride" or "Without arrogance"

#### receive the implanted word

The expression "implant" means to place one thing inside of another. Here God's word is spoken of as if it were a plant made to grow inside believers. AT: "obey the message God has spoken to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### receive the implanted word

Here "word," is a synecdoche for the message of salvation that God speaks to believers. When they believe it, God saves them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### save your souls

What a person is saved from can be made explicit. AT: "save you from God's judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### your souls

Here the word "souls" refers to persons.AT: "yourselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]

### James 01:22

#### Be doers of the word

AT: "Be people who follow God's instructions"(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]]).

#### deceiving yourselves

"fooling yourselves"

#### For if anyone is a hearer of the word

AT: "For if anyone listens to the God's message in the scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### but not a doer

The word "is" and "of the word" are understood from the previous phrase. The noun "doer" can also be expressed with the verbs "do" or "obey." AT: "but is not a doer of the word" or "but does not obey the word" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### he is like a man who examines his natural face in a mirror

A person who hears God's word is like someone who looks in the mirror. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### his natural face

The word "natural" clarifies that James is using the ordinary meaning of the word "face." AT: "his face"

#### then goes away and immediately forgets what he was like

It is implied that though he may see that he needs to do something, such as wash his face or fix his hair, he walks away and forgets to do it. This what a person who does not obey God's word is like. AT: "then goes away and immediately forgets to do what he saw he needed to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and  [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the person who looks carefully into the perfect law

This expression continues the image of the law as a mirror. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the perfect law of freedom

"Freedom" here is an idiom for the ability to live as one truly wants to live. AT: "the perfect way of living exactly the way you want to live"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### this man will be blessed in his actions

This can be stated in active form. AT: "God will bless this man as he obeys the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### James 01:26

#### thinks himself to be religious

"thinks he worships God correctly"

#### his tongue

Controlling one's tongue stands for controlling one's speech. AT: "what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### deceives

"fools" or "misleads"

#### his heart

Here "heart" refers to his belief or thoughts. AT: "himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his religion is worthless

"he worships God uselessly"

#### pure and unspoiled

James speaks of religion, the way one worships God, as if it could be physically pure and unspoiled. These are traditional ways for Jews to say that something is acceptable to God. AT: "Completely acceptable" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### before our God and Father

directed to God (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the fatherless

"the orphans"

#### in their affliction

The fatherless and widows are suffering because their fathers or husbands have died.

#### to keep oneself unstained by the world

Sin in the world is spoken of as something dirty that can stain a person. AT: "to not allow the evil in the world to cause oneself to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### James 01:intro

#### James 01 General Notes ####

####### Special concepts in this chapter #######

== Temptation and testing==
These two words have a lot of overlap in their meaning. The translator should be aware that there are some significant differences between the meaning of "temptation" here ([James 1:13](./12.md)) and God "testing" man ([Hebrews 11:17](../../heb/11/17.md)). 

######## Crowns ########
Crowns are a significant image used in Scripture. There are several Greek words translated as "crowns" in English. The crown referenced here is a type of reward. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]])

######## Light ########
Light is an important image used in Scripture. It is always used in a positive manner.

####### Important figures of speech in this chapter #######

######## Metaphors ########
James uses many metaphors in this chapter. They help to give his instructions a gentle, pastoral tone. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## "God is not tempted" ########
This phrase can be difficult to understand in light of the fact that Jesus, true man and true God, was tempted in the wilderness. While Satan tried to tempt Jesus, he was not successful in persuading Jesus to sin. 

######## "To the twelve tribes in dispersion" ########
It appears the author wrote this letter to Christians, but he also uses this phrase, which is more typically understood in reference to Jews. There is uncertainty as to its meaning. Since the author gives many practical instructions for holy living, it is likely that he is referring to Jews who are also Christians. When this letter was written the church was exclusively made up of Jews.

##### Links: #####

* __[James 01:01 Notes](./01.md)__
* __[James intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## James 02

### James 02:01

#### Connecting Statement:

James continues to tell the scattered Jewish believers how to live by loving one another and reminds them not to favor rich people over poor brothers.

#### My brothers

James considers his audience to be Jewish believers. AT: "My fellow believers" or "My brothers and sisters in Christ"

#### hold to faith in our Lord Jesus Christ

Believing in Jesus Christ is spoken of as if it were an object that one could hold onto. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### our Lord Jesus Christ

The word "our" includes James and his fellow believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### favoritism toward certain people

the desire to help some people more than others

#### Suppose that someone

James starts to describe a situation where the believers might give more honor to a rich person than to a poor person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### wearing gold rings and fine clothes

"dressed like a wealthy person"

#### sit here in a good place

sit in this place of honor

#### stand over there

move to a place with less honor

#### Sit at my feet

move to a humble place

#### are you not judging among yourselves? Have you not become judges with evil thoughts?

James is using rhetorical questions to teach and possibly scold his readers. AT: "you are making judgments among yourselves and becoming judges with evil thoughts." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### James 02:05

#### Listen, my beloved brothers

James was exhorting his readers as family. "Pay attention, my dear fellow believers"

#### did not God choose ... love him?

Here James uses a rhetorical question to teach his readers not to show favoritism. It can be made a statement. AT: "God has chosen ... love him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the poor

This refers to poor people in general. AT: "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### be rich in faith

Having much faith is spoken of as being wealthy or rich. The object of faith may have to be specified. AT: "have strong faith in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### heirs

The people to whom God has made promises are spoken of as if they were to inherit property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### But you have

James is speaking to his whole audience. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### have dishonored the poor

"you have shamed poor people"

#### Is it not the rich who oppress you?

Here James uses a rhetorical question to correct his readers. AT: "It is rich people who oppress you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the rich

This refers to rich people in general. AT: "rich people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### who oppress you

"who treat you badly"

#### Are they not the ones ... to court?

Here James uses a rhetorical question to correct his readers. It can be made a statement. AT: "The rich people are the ones ... to court." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### drag you to court

"forcibly take you to court to accuse you in front of judges" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Do they not insult ... have been called?

Here James uses a rhetorical question to correct and teach his readers. It can be made a statement. AT: "The rich people insult ... have been called." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the good name by which you have been called

This refers to Christ's name. AT: "the name of Christ who called you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### James 02:08

#### you fulfill

The word "you" refers to the Jewish believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### fulfill the royal law

"obey God's law." God originally gave laws to Moses, recorded in the books of the Old Testament.

#### You shall love your neighbor as yourself

James is quoting from the book of Leviticus.

#### your neighbor

"all people" or "everyone"

#### you do well

"you are doing well" or "you are doing what is right"

#### if you favor

"give special treatment to" or "give honor to"

#### committing sin

"sinning." That is, breaking the law.

#### convicted by the law as lawbreakers

Here the law is spoken of as if it were a human judge. AT: "guilty of breaking God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### James 02:10

#### For whoever obeys

"For anyone who obeys"

#### except that he stumbles ... the whole law

Stumbling is falling down while one is trying to walk. Disobeying one point of the law is spoken of as if it were stumbling while walking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in just a single way

because of disobedience to just one requirement of the law

#### For the one who said

This refers to God, who gave the law to Moses.

#### Do not commit

To "commit" is to do an action.

#### If you ... but if you ... you have

Here "you" means "each one of you." Although James was writing to many Jewish believers, in this case, he used the singular form as if he was writing to each person individually. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]

### James 02:12

#### So speak and act

"So you must speak and obey." James commanded the people to do this.

#### who will be judged by means of the law of freedom

This can be stated in active form. AT: "who know that God will judge them by means of the law of freedom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by means of the law

This passage implies that it is God who will judge according to his law.

#### the law of freedom

"the law that gives true freedom"

#### Mercy triumphs over

"Mercy is better than" or "Mercy defeats." Here mercy and justice are spoken of as if they were persons. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### James 02:14

#### Connecting Statement:

James encourages the scattered believers to show their faith before others, just as Abraham showed others his faith by his works.

#### What good is it, my brothers, if someone says he has faith, but he has no works?

James is using a rhetorical question to teach his audience. AT: "It is no good at all, fellow believers, if someone says he has faith, but he has no works." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### if someone says he has faith, but he has no works

The can be restated to remove the abstract nouns "faith" and "works." AT: "if someone says he believes in God but he does not do what God commands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Can that faith save him?

James is using a rhetorical question to teach his audience. This can be restated to remove the abstract noun "faith." AT: "That faith cannot save him." or "If a person does not do what God commands, then just saying he believes in God will not save him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### save him

"spare him from God's judgment"

#### stay warm

This means either "have enough clothes to wear" or "have a place to sleep." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### be filled

The thing that fills them is food. This can be stated explicitly. AT: "be filled with food" or "have enough to eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for the body

to eat, to wear, and to live comfortably (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### what good is that?

James uses a rhetorical question to teach his audience. AT: "that is not good." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### brother or sister

a fellow believer in Christ, whether male or female

#### faith by itself, if it does not have works, is dead

James speaks of faith as if it were alive if one does good works, and of faith as if it were dead if one does not do good deeds. This can be restated to remove the abstract nouns "faith" and "works." AT: "a person who says he believes God, but does not do what God commands, does not really believe God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### James 02:18

#### Yet someone may say

James describes a hypothetical situation where someone objects to his teaching. James seeks to correct his audience's understanding of faith and works. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### "You have faith, and I have works." Show me your faith without works, and I will show you my faith by my works

James is describing how someone may argue against his teaching and how he would respond. This can be restated to remove the abstract nouns "faith" and "works." AT: "'It is acceptable that you believe God and that I do what God commands.' Prove to me that you can believe God and not do what he commands, and I will prove to you that I believe God by doing what he commands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the demons believe that, and they tremble

"the demons also believe, but they shake with fear." James contrasts the demons with those who claim to believe and not do good deeds. James states that the demons are wiser because they fear God while the others do not.

#### Do you want to know, foolish man, that faith without works is useless?

James uses this question to introduce the next part of his teaching. AT: "Listen to me, foolish man, and I will show that faith without works is useless." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### that faith without works is useless

This can be restated to remove the abstract nouns "faith" and "works." AT: "that if you do not do what God commands, then it is useless for you to say that you believe in God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### James 02:21

#### General Information:

Since these are Jewish believers, they know the story of Abraham, about whom God had told them long ago in his word.

#### Was not Abraham our father justified ... on the altar?

This rhetorical question is used to rebut the foolish man's arguments from [James 2:18](./18.md), who refuses to believe that faith and works go together. AT: "Abraham our father was certainly justified ... on the altar." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### justified by works

James speaks of works as if they were objects that one can own. AT: "justified by doing good deeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### father

Here "father" is used in the sense of "ancestor."

#### You see

The word "you" is singular, referring to the hypothetical man. James is addressing his whole audience as if they were one person.

#### You see

The word "see" is a metonym. AT: "You understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### faith worked with his works, and that by works his faith was fully developed

James speaks as if "faith" and "works" are things that can work together and help each other. AT: "because Abraham believed God, he did what God commanded. And because Abraham did what God commanded, he believed God completely"

#### The scripture was fulfilled

This can be stated in active form. AT: "This fulfilled the scripture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it was counted to him as righteousness

"God regarded his faith as righteousness." Abraham's faith and righteousness were treated as if they were able to be counted as having value. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You see

James again addresses his audience directly by using the plural form of "you."

#### it is by works that a man is justified, and not only by faith

"actions and faith are what justify a person, and not only faith." James speaks of works as if they were objects to obtain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### James 02:25

#### In the same way also ... justified by works

James says that what was true of Abraham was also true of Rahab. Both were justified by works.

#### was not Rahab the prostitute justified by works ... another road?

James is using this rhetorical question to instruct his audience. AT: "it was what Rahab the prostitute did that justified her ... another road." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Rahab the prostitute

James expected his audience to know the Old Testament story about the woman Rahab.

#### justified by works

James speaks of works as something to possess. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### messengers

people who bring news from another place

#### sent them away by another road

"then helped them escape and leave the city"

#### For as the body apart from the spirit is dead, even so faith apart from works is dead

James is speaking of faith without works as if it were a dead body without the spirit. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### James 02:intro

#### James 02 General Notes ####

####### Special concepts in this chapter #######

######## Favoritism ########
It is wrong to show favoritism in the church. There were people who showed special favor (favoritism) towards rich and powerful people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]])

######## Justification ########
Justification means "the process of declaring someone righteous." There are two types of justification. One is to be declared righteous in the opinion of God and one is to be declared righteous in the opinion of other people. A person is not justified according to God by their actions. Abraham was declared righteous according to God by his faith. He was declared righteous according to other people when his actions showed his faith, by being willing to offer up his son Isaac as a sacrifice to God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Other possible translation difficulties in this chapter #######

######## Quotation marks ########
There is some controversy regarding where to place the quotation marks in James 2:18. The ULB states "Yet someone will say, 'You have faith, and I have works.' Show me your faith without works, and I will show you my faith by my works." It is also possible to translate this as "Yet someone will say, 'You have faith, and I have works. Show me your faith without works, and I will show you my faith by my works.'" The length of this hypothetical statement can have significant theological implications. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])
##### Links: #####

* __[James 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## James 03

### James 03:01

#### Not many of you

James is making a generalized statement. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### my brothers

"my fellow believers"

#### we who teach will be judged more strictly

This passage speaks of stricter judgment that will come from God on those who teach others about him. AT: "God will judge us who teach more severely because we know his word better than some people whom we have taught" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### we who teach

James includes himself and other teachers, but not the readers, so the word "we" is exclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### we all stumble

James speaks of himself, other teachers, and the readers, so the word "we" is inclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### stumble

Sinning is spoken of as if it were stumbling while walking. AT: "fail" or "sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### does not stumble in words

"does not sin by saying wrong things"

#### he is a perfect man

"he is spiritually mature"

#### control even his whole body

James is referring to one's heart, emotions, and actions. AT: "control his behavior" or "control his actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]

### James 03:03

#### General Information:

James is developing an argument that small things can control big things.

#### Now if we put bits into horses' mouths

James speaks about horses' bits. A bit is a small piece of metal that is placed into a horse's mouth to control where it goes.

#### Now if

"If" or "When"

#### horses

A horse is a large animal used to carry things or people.

#### Notice also that ships ... are steered by a very small rudder

A ship is like a truck that floats on water. A rudder is a flat piece of wood or metal at the back of the ship, used to control where it goes. The word "rudder" could also be translated as "tool."

#### are driven by strong winds,

This can be stated in active form. AT: "strong winds push them, they" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### are steered by a very small rudder to wherever the pilot desires

"have a small tool that a person can use to control where the ship goes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### James 03:05

#### Likewise

This word signals the analogy of the tongue to the horses' bits and the ships' rudders mentioned in the previous verses. AT: "In the same way"

#### boasts great things

Here "things" is a general word for everything about which these people are proud.

#### Notice also

"Think about"

#### how small a fire sets on fire a large forest

In order to help people understand the harm that the tongue can cause, James speaks of the harm that a small flame can cause. AT: "how a small flame can start a fire that burns many trees"

#### The tongue is also a fire

The tongue is a metonym for what people say. James calls it a fire because of the great damage it can do. AT: "The tongue is like a fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a world of sinfulness set among our body parts

The enormous effects of sinful speaking are spoken of as if they were a world by themselves. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It stains the whole body

Sinful speaking is spoken of metaphorically as if it stained one's body. And becoming unacceptable to God is spoken of as if it were dirt on the body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sets on fire the course of life

The phrase "course of life" refers to a person's entire life. AT: "it ruins a person's entire life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### life. It is itself set on fire by hell

The word "itself" refers to the tongue. Also, here "hell" refers to the powers of evil or to the devil. This can be stated in active form. AT: "life because the devil uses it for evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]

### James 03:07

#### For every kind of ... mankind

The phrase "every kind" is a general statement referring to all or many kinds of wild animals. This can be stated in active form. AT: "People have learned to control many kinds of wild animals, birds, reptiles, and sea creatures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### reptile

This is an animal that crawls on the ground. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### sea creature

an animal that lives in the sea

#### But no human being can tame the tongue

James speaks of the tongue as if it were a wild animal. Here "tongue" represents a person's desire to speak evil thoughts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### It is a restless evil, full of deadly poison

James speaks of the harm that  people can cause by what they say as if the tongue were an evil and poisonous creature that can kill people. AT: "It is like a restless and evil creature, full of deadly poison" or "It is like a restless and evil creature that can kill people with its venom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### James 03:09

#### With it we

"We use the tongue to say words that"

#### we curse men

"we ask God to harm men"

#### who have been made in God's likeness

This can be stated in active form. AT: "whom God made in his likeness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Out of the same mouth come blessing and cursing

The nouns "blessing" and "cursing" can be translated with a verbal phrase. AT: "With the same mouth, a person blesses people and curses people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### My brothers

"Fellow Christians"

#### these things should not happen

"these things are wrong"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### James 03:11

#### Connecting Statement:

After James stresses that the words of believers should not both bless and curse, he gives examples from nature to teach his readers that people who honor God by worshiping him should also live in right ways.

#### Does a spring pour out from its opening both sweet and bitter water?

James uses a rhetorical question to remind believers about what happens in nature. This can be expressed as a sentence. AT: "You know that a spring does not pour out both sweet water and bitter water." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Does a fig tree, my brothers, make olives?

James uses another rhetorical question to remind the believers about what happens in nature. AT: "Brothers, you know that a fig tree cannot grow olives." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my brothers

"my fellow believers"

#### Or a grapevine, figs?

The word "make" is understood from the previous phrase. James uses another rhetorical question to remind the believers about what happens in nature. AT: "Or does a grapevine make figs?" or "And a grapevine cannot grow figs." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]

### James 03:13

#### Who is wise and understanding among you?

James uses this question to teach his audience about proper behavior. The words "wise" and "understanding" are similar. AT: "I will tell you how a wise and understanding person is to act." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Let that person show a good life by his works in the humility of wisdom

This can be restated to remove the abstract nouns "humility" and "wisdom." AT: "That person should live a good life by doing the kind of deeds that come from being humble and wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### if you have bitter jealousy and ambition in your heart

The word "heart" refers to emotions or thoughts. This can be restated to remove the abstract nouns "jealousy" and "ambition." AT: "if you are jealous and selfish" or "if you desire what other people have and you want to succeed even if it harms others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### do not boast and lie against the truth

The abstract noun "truth" can be stated as "true." AT: "do not boast that you are wise, because that is not true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### James 03:15

#### This is not the wisdom that comes down from above

Here "This" refers to the "bitter jealousy and strife" described in the previous verses. The phrase "from above" is a metonym that represents "heaven" which represents God himself. AT: "This is not the kind of wisdom that God teaches us from heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### This is not the wisdom that comes down from above. Instead, it is earthly, unspiritual, demonic

The abstract noun "wisdom" can be stated as "wise." - AT: "Whoever acts like this is not wise according to what God in heaven teaches us. Instead this person is earthly, unspiritual, and demonic" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### earthly

The word "earthly" refers to the values and behaviors of the people who do not honor God. AT: "not honoring to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### unspiritual

"not from the Holy Spirit" or "not spiritual"

#### demonic

"from demons"

#### For where there are jealousy and ambition, there is confusion and every evil practice

This can be restated to remove the abstract nouns "jealousy," "ambition," and "confusion." AT: "For when people are jealous and selfish, this causes them to act in disorderly and evil ways" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### there is confusion

"there is disorder" or "there is chaos"

#### every evil practice

"every kind of sinful behavior" or "every kind of wicked deed"

#### But the wisdom from above is first pure

Here "from above" is metonym that represents "heaven" which represents God himself. The abstract noun "wisdom" can be stated as "wise." AT: "But when a person is wise according to what God in heaven teaches, he acts in ways that are first pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### is first pure

"is first holy"

#### good fruits

"Fruits" here is a metaphor for "results" or "outcomes." AT: "good results" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sincere

"honest" or "truthful"

#### The fruit of righteousness is sown in peace among those who make peace

The good results of righteousness are spoken of as if they were crops that had been sown by farmers. AT: "Those who live in peace are doing what God says is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### make peace

"live in peace." The abstract noun "peace" can be stated as "peacefully." AT: "cause people to live peacefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### James 03:intro

#### James 03 General Notes ####

####### Important figures of speech in this chapter #######

######## Metaphors ########
The author uses many different metaphors to convict his readers and to encourage them to display godliness by the way they speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]])

####### Other possible translation difficulties in this chapter #######

######## Implicit information ########
What a person says can reveal his spiritual state. This is because his speech can be heard by other people. If a person is unable to control his actions when he is seen by others, he will not be able to control his actions when no one is looking. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[James 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## James 04

### James 04:01

#### Connecting Statement:

James rebukes these believers for their worldliness and their lack of humility. He again urges them to watch how they speak to and about each other.

#### General Information:

In this section, the words "yourselves," "your," and "you" are plural and refer to the believers to whom James writes.

#### Where do quarrels and disputes among you come from?

The abstract nouns "quarrels" and "disputes" mean basically the same thing and can be translated with verbs. AT: "Why do you quarrel and dispute among yourselves?" or "Why do you fight among yourselves?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Do they not come from your desires that fight among your members?

James uses this question to rebuke his audience. This can be translated as a statement. AT: "They come from your evil desires for things, desires that fight among your members." or "They come from your desires for evil things, desires that fight among your members." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Do they not come from your desires that fight among your members?

James speaks of desires as they were enemies who waged war against the believers. In reality, of course, it is the people who have these desires who fight among themselves. AT: "They come from your desires for evil things, by which you end up harming each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### among your members

Possible meanings are 1) there is fighting among the local believers, or 2) the fighting, that is, the conflict, is inside each believer.

#### You kill and covet, and you are not able to obtain

The phrase "You kill" expresses how badly the people behave in order to get what they want. It can be translated as "You do all kinds of evil things to get what you cannot have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### You fight and quarrel

The words "fight" and "quarrel" mean basically the same thing. James uses them to emphasize how much the people argue among themselves. AT: "You constantly fight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### you ask badly

Possible meanings are 1) "you ask with wrong motives" or "you ask with bad attitudes" or 2) "you are asking for wrong things" or "you are asking for bad things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### James 04:04

#### You adulteresses!

James speaks of believers as being like wives who sleep with men other than their husbands. AT: "You are not being faithful to God!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do you not know ... God?

James uses this question to teach his audience. This can be translated as a statement. AT: "You know ... God!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### friendship with the world

This phrase refers to identifying with or participating in the world's value system and behavior. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### friendship with the world

Here the world's value system is spoken of as if it were a person that others could be friends with. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### friendship with the world is hostility against God

One who is friends with the world is an enemy of God. Here "friendship with the world" stands for being friends with the world, and "hostility against God" stands for being hostile against God. AT: "friends of the world are enemies of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Or do you think the scripture says in vain

This is a rhetorical question James uses to exhort his audience. To speak in vain is to speak uselessly. AT: "There is a reason that scripture says"

#### The Spirit he caused to live in us

Some versions, including the ULB and UDB, understand this as a reference to the Holy Spirit. Other versions translate this as "the spirit" and mean by it the human spirit that each person has been created to have. We suggest that you use the meaning that is presented in other translations used by your readers.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### James 04:06

#### But God gives more grace

How this phrase relates to the previous verse can be made explicit: "But, even though our spirits may desire what we cannot have, God gives us even more grace, if we will humble ourselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so the scripture ... So submit

"Because God gives more grace, the scripture ... Because God gives grace to the humble, submit"

#### the proud

This refers to proud people in general. AT: "proud people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the humble

This refers to humble people in general. AT: "humble people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### submit to God

"obey God"

#### Resist the devil

"Oppose the devil" or "Do not do what the devil wants"

#### he will flee

"he will run away"

#### you

Here this pronoun is plural and refers to James' audience. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### James 04:08

#### General Information:

The word "you" here is plural and refers to the scattered believers to whom James writes. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Come close to God

Here the idea of coming close stands for becoming honest and open with God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Cleanse your hands, you sinners, and purify your hearts, you double-minded

These are two phrases in parallel with each other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Cleanse your hands

This expression is a command for people to do righteous acts instead of unrighteous acts. AT: "Behave in a way that honors God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### purify your hearts

Here "hearts" refers to a person's thoughts and emotions. AT: "make your thoughts and intentions right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### double-minded

The word "double-minded" refers to a person who cannot make a firm decision about something. AT: "double-minded people" or "people who cannot decide if you want to obey God or not" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Grieve, mourn, and cry

These three words have similar meanings. James uses them together to emphasize that the people should be truly sorry for not obeying God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### Let your laughter turn into sadness and your joy into gloom

This is saying the same thing in different ways for emphasis. The abstract nouns "laughter," "sadness," "joy," and "gloom" can be translated as verbs or adjectives. AT: "Stop laughing and be sad. Stop being joyful and be gloomy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Humble yourselves before the Lord

"Be humble toward God." Actions done with God in mind are often spoken of as being done in his physical presence. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will lift you up

James indicates that God will honor the humble person by saying God will pick that person up off the ground physically from where that person had prostrated himself in humility. AT: "he will honor you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### James 04:11

#### General Information:

The words "you" and "your" in this section refer to the believers to whom James writes.

#### speak against

"speak badly about" or "oppose"

#### brothers

James speaks of the believers as if they are biological brothers. The term here includes women as well as men. AT: "fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### but a judge

"but you are acting like the person who gives the law"

#### Only one is the lawgiver and judge

This refers to God. "God is the only one who gives laws and judges people"

#### Who are you, you who judge your neighbor?

This is a rhetorical question James uses to scold his audience. This can be expressed as a statement. AT: "You are just a human and cannot judge another human." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### James 04:13

#### spend a year there

James speaks of spending time as if it were money. "stay there for a year" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Who knows what will happen tomorrow, and what is your life?

James uses these questions to correct his audience and to teach these believers that physical life is not that important. They can be expressed as statements. AT: "No one knows what will happen tomorrow, and your life does not last very long!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### For you are a mist that appears for a little while and then disappears

James speaks of people as if they were a mist that appears and then quickly goes away. AT: "You live for only a short amount of time, and then you die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### James 04:15

#### Instead, you should say

"Instead, your attitude should be"

#### we will live and do this or that

"we will live long enough to do what we have planned to do." The word "we" does not directly refer to James or his audience but is part of the example of how James' audience should consider the future.

#### for anyone who knows to do good but does not do it, for him it is sin

Anyone who fails to do the good he knows he should do is guilty of sin.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### James 04:intro

#### James 04 General Notes ####

####### Special concepts in this chapter #######

######## Adultery ########
Adultery is a common metaphor in Scripture. It is always used negatively and indicates a child of God is acting in an ungodly manner. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md)]])

######## Law ########
It is unclear whether this is a reference to the law of Moses. It is probably a reference to the "law" of God in general. This is the general standard of righteousness based on the character of God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
James uses many rhetorical questions to teach his readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

####### Other possible translation difficulties in this chapter #######

######## "The humble" ########
This is probably not a reference to those who act humbly, but a reference to those who humble themselves and trust in Jesus for their salvation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/salvation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/salvation.md)]])

##### Links: #####

* __[James 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## James 05

### James 05:01

#### Connecting Statement:

James warns rich people about their focus on pleasure and riches.

#### you who are rich

Possible meanings are 1) James is giving a strong warning to wealthy believers or 2) James is talking about wealthy unbelievers. AT: "you who are rich and say you honor God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### because of the miseries coming on you

James states that these people will suffer terribly in the future and writes as if their sufferings were objects that were coming toward them. The abstract noun "miseries" can be translated as a verb. AT: "because you will suffer terribly in the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Your riches have rotted, and your clothes have become moth-eaten. Your gold and your silver have become tarnished

Earthly riches do not last nor do they have any eternal value. James speaks of these events as if they had already happened. AT: "Your riches will rot, and your clothes will be eaten by moths. Your gold and silver will become tarnished" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### riches ... clothes ... gold ... silver

These things are mentioned as examples of things that are valuable to wealthy people.

#### have become tarnished ... their rust

These phrases are used here to describe how gold and silver are ruined. AT: "are ruined ... their ruined condition" or "are corroded ... their corrosion"

#### their rust will be a witness against you. It

James wrote of their valuable things being ruined as if they were a person in a courtroom accusing the wicked of their crimes. AT: "and when God judges you, your ruined treasures will be like someone who accuses you in court. Their corrosion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] )

#### will consume ... like fire

Here the corrosion is spoken of as if it were a fire that will burn up their owners. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your flesh

Here "flesh" stands for the physical body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### fire

The idea of fire here is meant to lead people to remember that fire often stands for God's punishment that will come on all the wicked. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for the last days

This refers to the time right before God comes to judge all people. The wicked think they are storing up riches for the future, but what they are doing is storing up judgment. AT: "for when God is about to judge you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]]

### James 05:04

#### Connecting Statement:

James continues to warn rich people about thier focus on pleasure and riches.

#### the pay of the laborers is crying out—the pay that you have withheld from those who harvested your fields

The money that should have been paid is spoken of as a person who is shouting because of the injustice done to him. AT: "the fact that you did not pay those you hired to work in your fields shows that you have done wrong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the cries of the harvesters have gone into the ears of the Lord of hosts

The shouts of the harvesters are spoken of as if they could be heard in heaven. AT: "the Lord of hosts has heard the cries of the harvesters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### into the ears of the Lord of hosts

God is spoken of as if he had ears as humans have. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You have fattened your hearts for a day of slaughter

Here people are viewed as if they were cattle, luxuriously fed on grain so they would become fattened to be slaughtered for a feast. However, no one will feast at the time of judgment. AT: "Your greed has only prepared you for harsh eternal judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your hearts

The "heart" was considered to be the center of human desire, and here stands for the entire person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You have condemned ... the righteous person

This is probably not "condemned" in the legal sense of a judge passing a sentence of death on a criminal. Instead, it probably refers to the wicked and powerful people who decide to mistreat the poor until they die.

#### the righteous person. He does not

"the people who do what is right. They do not." Here "the righteous person" refers to righteous people in general and not to a specific person. AT: "righteous people. They do not" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### resist you

"oppose you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### James 05:07

#### Connecting Statement:

James changes topics from a rebuke of the rich people to an exhortation to the believers.

#### General Information:

In closing, James reminds the believers about the Lord's coming and gives several short lessons on how to live for the Lord.

#### So be patient

"Because of this, wait and be calm"

#### until the Lord's coming

This phrase refers to the return of Jesus, when he will begin his kingdom on the earth and judge all people. AT: "until Christ's return" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the farmer

James makes an analogy using farmers and believers to teach what it means to be patient. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Make your hearts strong

James is equating the believers' hearts to their will to remain committed. AT: "Stay committed" or "Keep your faith strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Lord's coming is near

"the Lord will return soon"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### James 05:09

#### Do not complain, brothers ... you

James is writing to all the scattered Jewish believers.

#### against one another

"about each other"

#### you will be not judged

This can be stated in the active. AT: "Christ will not judge you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the judge is standing at the door

James compares Jesus, the judge, to a person about to walk through a door to emphasize how soon Jesus will return to judge the world. AT: "the judge is coming soon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the suffering and patience of the prophets, those who spoke in the name of the Lord

"how the prophets who spoke in the name of the Lord suffered persecution with patience"

#### spoke in the name of the Lord

"Name" here is a metonym for the person of the Lord. AT: "by the authority of the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]]) "spoke for the Lord to the people"

#### See

Here "See" adds emphasis to what follows. AT: "Listen carefully" or "Remember"

#### those who endured

"those who continued obeying God even through hardship"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/job.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/job.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### James 05:12

#### Above all, my brothers,

"This is important, may brothers:" or "Especially, my brothers,"

#### my brothers

This refers to all believers including women. AT: "my fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### do not swear

To "swear" is to say that you will do something, or that something is true, and to be held accountable by a higher authority. AT: "do not make an oath" or "do not make a vow"

#### either by heaven or by the earth

The words "heaven" and "earth" refer to the spiritual or human authorities that are in heaven and earth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### let your "Yes" mean "Yes" and your "No" mean "No,"

"do what you say you will do, or say that something is true, without making an oath"

#### so you do not fall under judgment

Being condemned is spoken of as if one had fallen, crushed by the weight of something heavy. AT: "so God will not punish you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### James 05:13

#### Is anyone among you suffering hardship? Let him pray

James uses this question to cause the readers to reflect on their need. This can be translated as a statement. AT: "If anyone is enduring troubles, he should pray" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is anyone cheerful? Let him sing praise

James uses this question to cause the readers to reflect on their blessings. This can be translated as a statement. AT: "If anyone is happy, he should sing songs of praise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is anyone among you sick? Let him call

James uses this question to cause the readers to reflect on their need. This can be translated as a statement. AT: "If anyone is sick, he should call" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### in the name of the Lord
"Name" is a metonym for the person of Jesus Christ. AT: "by the authority of the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### The prayer of faith will heal the sick person, and the Lord will raise him up

When believers pray for sick people, the Lord will hear their prayer and will heal those people. "Raise" here is an idiom for "establish." AT: "The Lord will hear believers praying in faith and will heal the sick person, and the Lord will establish him" or "The Lord will hear believers praying in faith, and he will heal the sick person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]

### James 05:16

#### General Information:

As these were Jewish believers, James reminds them to pray by recalling one of the prophets of old and that prophet's practical prayers.

#### So confess your sins

Admit to other believers things you did wrong so that you can be forgiven.

#### to one another

"to each other"

#### so that you may be healed

This can be stated in active form. AT: "so that God may heal you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The prayer of a righteous person is very strong in its working

Prayer is presented as if it were an object that was strong or powerful. AT: "When the person who obeys God prays, God will do great things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### prayed earnestly

"prayed eagerly" or "prayed passionately"

#### three ... six

"3 ... 6" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### The heavens gave rain

"The heavens" probably refers to the sky, which is presented as the source of the rain. AT: "Rain fell from the sky"

#### the earth produced its fruit

Here the earth is presented as the source of the crops.

#### fruit

Here "fruit" stands for all the crops of the farmers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### James 05:19

#### brothers

Here this word probably refers to both men and women. AT: "fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### if anyone among you wanders from the truth, and someone brings him back

A believer who stops trusting in God and obeying him is spoken of as if he were a sheep that wandered away from the flock. The person who persuades him to trust in God again is spoken of as if he were a shepherd who went to search for the lost sheep. AT: "whenever anyone stops obeying God, and another person helps him start obeying again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### whoever turns a sinner from his wandering way ... will cover over a great number of sins

James means that God will use the actions of this person to persuade the sinner to repent and be saved. But James speaks as if it were this other person who actually saved the sinner's soul from death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will save him from death, and will cover over a great number of sins

Here "death" refers to spiritual death, eternal separation from God. AT: "will save him from spiritual death, and God will forgive the sinner for all of his sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### will cover over a great number of sins

Possible meanings are 1) the person who brings back the disobedient brother will have his sins forgiven or 2) the disobedient brother, when he returns to the Lord, will have his sins forgiven. Sins are spoken of as if they were objects that God could cover so that he would not see them, so that he would forgive them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### James 05:intro

#### James 05 General Notes ####

####### Special concepts in this chapter #######

######## Eternity ########
This chapter contrasts living for things of this world, which will not last, with living for things that will last for eternity. It is also important to live with the expectation that Jesus will return soon. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]])

######## Oaths ########
Scholars are divided over whether this passage teaches all oaths are wrong. Most scholars believe some oaths are permissible and James instead is teaching Christians to have integrity.

####### Other possible translation difficulties in this chapter #######

######## Elijah ########
This story will be difficult to understand if the books of 1 and 2 Kings and 1 and 2 Chronicles have not yet been translated. 

######## "Save his soul from death" ########
This probably teaches that the person who stops their sinful lifestyle will not be punished with physical death as a consequence of their sin. On the other hand, some scholars believe this passage teaches about eternal salvation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]])

##### Links: #####

* __[James 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | __


## James front

### James front:intro

#### Introduction to James ####

##### Part 1: General Introduction #####

####### Outline of the Book of James #######

1. Greetings (1:1)
1. Testing and maturity (1:2-18)
1. Hearing and doing the Word of God (1:19-27)
1. True faith seen in works 
    - Word of God (1:19-27)
    - Royal law of love (2:1-13)
    - Works (2:14-26)
1. Difficulties in community 
    - Dangers of the tongue (3:1-12)
    - Wisdom from above (3:13-18)
    - Worldly desires (4:1-12)
1. God's perspective on your decisions
    - Boasting about tomorrow (4:13-17)
    - Warning about riches (5:1-6)
    - Suffering with patience (5:7-11)
1. Closing exhortations
    - Oaths (5:12)
    - Prayer and healing (5:13-18)
    - Care for one another (5:19-20)

####### Who wrote the Book of James? #######

The author identifies himself as James. This was probably James, the half-brother of Jesus. James was a leader in the early church and was part of the Jerusalem council. The Apostle Paul also called him a "pillar" of the church. 

This is not the same man as the Apostle James. The Apostle James was killed before this letter was written.

####### What is the Book of James about? #######

In this letter, James encouraged believers who were suffering. He told them know that God uses their suffering to help them become mature Christians. James also told them of the need for believers to do good deeds. He wrote much in this letter about how believers should live and treat one another. For example, he commanded them to treat one another fairly, to not fight with one another, and to use riches wisely.

James taught his readers by using many examples from nature such as in 1:6, 11 and 3:1-12. Also, many parts of this letter are similar to what Jesus wrote in the Sermon on the Mount (Mat 5-7). 

####### Who were the "twelve tribes in the dispersion"? #######

James said he was writing to the "twelve tribes in the dispersion" (1:1). Some scholars think that James was writing to Jewish Christians. Other scholars think that James was writing to all Christians in general. This letter is known as one of the "General Epistles" since it was not written to a specific church or individual.

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "James." Or they may choose a clearer title, such as "A Letter from James" or "The Letter James Wrote." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### Did James disagree with Paul about how a person is justified before God? #######

Paul taught in Romans that Christians are justified by faith and not by works. James seems to teach that Christians are justified by works. This can be confusing. But a better understanding of what Paul and James taught shows that they agree with one another. Both of them taught that a person needs faith in order to be justified. And they both taught that true faith will cause a person to do good works. Paul and James taught about these things in different ways because they had different audiences who needed to know different things about being justified. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]])

##### Part 3: Important Translation Issues #####

####### How should the translator signal transitions between topics in the Book of James? #######

The letter quickly changes topics. Sometimes James does not tell the readers that he is about to change topics. It is acceptable to allow the verses to appear disconnected from each other. It may make sense to set the passages apart by starting a new line or putting a space between topics. 

####### What are the major issues in the text of the Book of James? #######

The following is the most significant textual issue in the Book of James:

* "Do you want to know, foolish man, that faith without works is useless?" (2:20). The ULB, UDB, and modern versions read this way. Some older versions read, "Do you want to know, foolish man, that faith without works is dead?"

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

