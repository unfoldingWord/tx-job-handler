# <a id="oba"/>Obadiah

## Obadiah 01

### Obadiah 01:01

#### The vision of Obadiah

This is the title of the book. Here "vision" is used in the general sense of a message from Yahweh, rather than to indicate how Obadiah received the message. AT: "The message of Obadiah" or "The prophesy of Obadiah"

#### The Lord Yahweh says this concerning Edom

This tells the reader that the entire book is a message about Edom.

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### an ambassador has been sent

This can be stated in active form. AT: "Yahweh has sent an ambassador" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Rise up

"Stand up." This phrase is used to tell people to get ready.

#### rise up against her

Here "her" refers to Edom. This is a metonym for the people of Edom, so it could also be translated as "them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Behold, I will make you

Beginning in verse 2, Obadiah records the words that Yahweh speaks directly to Edom.

#### Behold

This alerts the reader to pay special attention to what follows. AT: "Look" or "Pay attention to what I am about to tell you"

#### I will make you small among the nations, you will be greatly despised

These two phrases mean similar things and are used to emphasize that Edom will lose its important status. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### I will make you small among the nations

Something that is insignificant is spoken of as if it is of small size, and can easily be overlooked. AT: "I will make you insignificant among the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will be greatly despised

This can be stated in active form. AT: "the people of other nations will hate you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ambassador.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ambassador.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Obadiah 01:03

#### General Information:

Obadiah's vision concerning Edom continues.

#### The pride of your heart has deceived you

The "heart" was associated with emotions. The Edomites' pride caused them to be deceived about their security. AT: "Your pride has deceived you" or "Your pride causes you think you are safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the clefts of the rock

"in the cracks in the rock." This here has the sense of a place that is protected because it is surrounded by rocks.

#### in your lofty home

"in your home that was built in a high place"

#### say in your heart

Here "in your heart" is an idiom that means "to yourself." AT: "say to yourselves" or "think" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Who will bring me down to the ground?

This question expresses that the Edomites were proud and felt safe. AT: "No one can bring me down to the ground." or "I am safe from all attackers." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Though you soar high like the eagle and though your nest is set among the stars

Both of these exaggerations say that Edom is built in a very high place by saying it is built much higher than possible. AT: "And I tell you that even if you had wings and could fly higher than eagles fly, and if you could make your homes among the stars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### I will bring you down from there

Pride is associated with height while humility is associated with being low. To "bring down" is an idiom that means to humble someone. AT: "I will humble you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Obadiah 01:05

#### General Information:

Yahweh continues giving Obadiah his message to Edom.

#### If thieves came to you ... would they not steal only as much as they needed?

This question is used to imply that Yahweh's punishment of Edom would be worse than what thieves would do when they steal. This can be stated explicitly. AT: "If thieves came to you ... they would only steal as much as they needed, but I will take everything from you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If thieves came to you, if robbers came by night

These two phrases mean the same thing and are used to emphasize people who steal. They can be combined. AT: "When thieves break into someone's house during the night" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md)]])

#### if robbers came by night

"or if robbers came during the night"

#### robbers

people who steal things from other people

#### how you will be ruined!

Yahweh adds this phrase in the middle of another sentence to express that the punishment of Edom is shocking. AT: "you are completely destroyed!"

#### If grape gatherers came to you, would they not leave the gleanings?

This question is used to imply that Yahweh's punishment of Edom would be more thorough than what grape gatherers would do when they harvest grapes. This can be stated explicitly. AT: "If grape gatherers came to you, they would leave some grapes, but I will take everything from you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### How Esau has been ransacked, his hidden treasures will be searched out

This can be stated in active form. AT: "Ah, enemies have stolen everything from Esau; they have found his hidden treasure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Esau

The people of Edom were the descendants of Esau. Therefore, in this book "Edom" and "Esau" refer to the same group of people.

#### has been ransacked

This means the enemies have search through Esau's things, taken everything valuable, and left everything else in a mess or damaged.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]

### Obadiah 01:07

#### General Information:

Yahweh continues giving Obadiah his message to Edom.

#### All the men of your alliance ... The men who were at peace with you ... They who eat your bread

All three of these phrases refer to Edom's allies.

#### your alliance

The word "your" refers to the nation of Edom.

#### will send you on your way to the border

"will send you out of their land." The people of Edom will try to take refuge in the land of their allies, but their allies will not let the people of Edom stay in their land.

#### There is no understanding in him.

Possible meanings are 1) the allies say this about Edom. AT: "They say, 'Edom does not understand anything.'" or 2) this is a statement about the betrayal of the allies. AT: "No one can understand why they did this."

#### Will I not on that day," says Yahweh, "destroy ... mountain of Esau?

Yahweh uses this question to emphasize the certainty of the destruction of Edom. AT: "'On that day,' says Yahweh, 'I surely will destroy ... mountain of Esau." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the mountain of Esau

Most of the land of Esau was mountains, so this is one way of referring to the land of Edom.

#### Your mighty men will be dismayed

"Your strong warriors will be afraid"

#### Teman

This is the name of a region in the land of Edom. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### so that every man may be cut off from the mountain of Esau by slaughter

This can be stated in active form. AT: "so that there will be no more people in the mountains of Esau because enemies killed them" or "so that they will slaughter every person in the mountain of Esau" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### be cut off

"be destroyed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]

### Obadiah 01:10

#### General Information:

Yahweh continues giving Obadiah his message to Edom.

#### your brother Jacob

Here "Jacob" represents his descendants. Because Jacob was the brother of Esau, the people of Edom are spoken of as if they were the brothers of the descendants of Jacob. AT: "your relatives who are the descendants of Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you will be covered with shame

To be covered with something is an idiom for fully experiencing it. AT: "you will be completely ashamed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will be cut off forever

This can be stated in active form. AT: "will never exist again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### stood aloof

"watched and did nothing to help"

#### strangers

people from other nations

#### his wealth

The word "his" refers to "Jacob," which is another way of referring to the people of Israel.

#### cast lots for Jerusalem

This phrase means "they cast lots to decide who would get the valuable things that they took from Jerusalem." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you were like one of them

"it was as though you were one of these strangers and foreigners." This implies that they did not help the Israelites. This can be made explicit. AT: "you were like one of the enemies and did not help Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Obadiah 01:12

#### General Information:

Yahweh continues giving Obadiah his message to Edom.

#### General Information:

Verses 12-14 consist of a series of negative commands that Yahweh gives to tell the people of Edom how not to treat the Israelites.

#### do not gloat over

"do not be happy because of" or "do not take pleasure in"

#### your brother's day

Here "your brother" refers to the people of Israel because Jacob and Esau were brothers.

#### the day

Each of the several occurrences of "day" refer to the time when Babylon attacked and destroyed Jerusalem.

#### misfortune

"disaster" or "trouble"

#### in the day of their destruction

"at the time when their enemies destroy them"

#### in the day of their distress

"at the time when they suffer"

#### calamity ... disaster ... ruin

These are all different translations of the same word. If your language has one word that can translate all three of these ideas, you could use it here.

#### over their affliction

"because of the bad things that happen to them"

#### do not loot their wealth

"do not take their wealth" "or "do not steal their wealth"

#### crossroads

a place where two roads come together

#### to cut down his fugitives

"to kill the people of Israel who are trying to escape" or "to catch those who were trying to escape"

#### do not deliver up his survivors

"do not capture those who are still alive and give them to their enemies"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Obadiah 01:15

#### General Information:

Yahweh concludes his message to Edom in verse 15. In verses 16-21, Yahweh speaks through Obadiah to tell the people of Judah that they will possess the land of Edom.

#### For the day of Yahweh is near ... will return on your own head

Bible experts are not certain whether verse 15 goes with verse 14 as the end of the previous section, or goes with verse 16 as the beginning of the new section.

#### For the day of Yahweh is near upon all the nations

"Soon the time will come when Yahweh will show all the nations that he is Lord"

#### As you have done, it will be done to you

This can be stated in active form. AT: "I will do to you the same things that you did to others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### your deeds will return on your own head

Here "return on your own head" means they will be punished for those things. AT: "you will suffer the consequences for the things you have done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### For as you

The word "you" is plural and probably refers to the people of Judah.

#### as you have drunk

The punishment that Judah received from the enemy nations is spoken of as if a bitter liquid that they drank. AT: "as you have drunk suffering" or "as I have punished you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my holy mountain

This was a way of referring to Jerusalem.

#### so will all the nations drink continually

Yahweh's punishment of the other nations is spoken of as if it was a bitter liquid that he will cause them to drink continually. AT: "so all the nations will drink in suffering continually" or "so I will punish all of the nations without stopping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They will drink and swallow and it will be as though they had never existed

Yahweh continues the metaphor of drinking punishment. Here "swallow" expresses that they will fully experience the punishment, with the result that it will destroy them completely. AT: "They will drink in my punishment fully until they cease to exist" or "I will continue to punish them fully until I completely destroy them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Obadiah 01:17

#### General Information:

In verses 16-21, Yahweh speaks through Obadiah to tell the people of Judah that they will possess the land of Edom.

#### those that escape

These are the people of Jerusalem that are still alive after Yahweh has finished punishing the city. This can be made explicit. AT: "some of the Israelites who escape the punishment of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### it will be holy

The word "it" refers to "mount Zion."

#### house of Jacob will be a fire ... Joseph a flame

Yahweh speaks of the houses of Jacob and Joseph as if they were fire because they will destroy Esau like a fire that quickly and completely burns up straw. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the house of Jacob

The word "house" is a metonym for the family that lives in the house. In this case it refers to Jacob's descendants. AT: "descendants of Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### stubble

"straw" or "chaff." The dry pieces of plant that are left after grain is harvested.

#### and they

The word "they" refers to the house of Jacob and the house of Joseph.

#### will burn them

The word "them" refers to the descendants of Esau, who are the nation of Edom.

#### There will be no survivors to the house of Esau

"Not one person of the house of Esau will survive"

#### the house of Esau

The word "house" is a metonym for the family that lives in the house. In this case it refers to Esau's descendants. AT: "descendants of Esau" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for Yahweh has spoken it

This is an oath formula that means it will certainly happen because Yahweh said it.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Obadiah 01:19

#### General Information:

In verses 16-21, Yahweh speaks through Obadiah to tell the people of Judah that they will possess the land of Edom.

#### Those from the Negev will possess the mount of Esau

"The Israelites in the Negev will take the land of the Edomites"

#### those of the Shepelah

This refers to Israelites in the western foothills of Israel who will capture the land of the Philistines in battle.

#### They will possess

Here "They" appears to refer to the people of Israel in general.

#### Benjamin will possess

"the tribe of Benjamin will possess" or "the descendants of Benjamin will possess"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Obadiah 01:20

#### General Information:

In verses 16-21, Yahweh speaks through Obadiah to tell the people of Judah that they will possess the land of Edom.

#### The exiles of this host of the people of Israel

Possible meanings are 1) this refers to the exiles taken to Assyria from the northern kingdom of Israel or 2) this refers to the people of Judah who lived outside of Jerusalem and were taken to exile in Babylon.

#### host

a very large group of people

#### as far as Zarephath

Zarephath was a Phoenician city north of Israel on the coast of the Mediterranean between Tyre and Sidon. At: "as far north as Zarephath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The exiles of Jerusalem

This group is contrasted with either the Israelites from the northern kingdom, or with the people of Judah who lived outside of Jerusalem.

#### Sepharad

This is the name of a place whose location is unknown. Some experts suggest it refers to the city of Sardis in the region of Lydia. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Deliverers will go up to Mount Zion to rule over the hill country of Esau

"Deliverers will go up to Jerusalem and rule over Edom from there"

#### Deliverers

Possible meanings are 1) this refers to various Israelite military leaders whom God will use to defeat the nation of Edom or 2) the text should read "Those who will be delivered" and refers to the returning Jewish exiles.

#### the kingdom will belong to Yahweh

This phrase emphasizes that Yahweh will personally rule over the kingdom. AT: "Yahweh will be their king"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

## Obadiah front

### Obadiah front:intro

#### Introduction to Obadiah ####

##### Part 1: General Introduction #####

####### Outline of the Book of Obadiah #######

1. God's judgments on the nation of Edom
    - The destruction of Edom is predicted (1:1–4)
    - The complete desolation and destruction of the city is predicted (1:5–9)
    - The hatred of Edom for Israel (1:10–14)
    - Edom and the other nations will be punished (1:15–16)
1. God promises to rescue his people; they will live in their land again (1:17–19)
1. Yahweh promises to restore his kingdom (1:20–21)

####### What is the Book of Obadiah about? #######

After Jerusalem was destroyed, the Edomites captured fleeing Jews and gave them to Babylon. The book of Obadiah is about God's judgment against the Edomites for harming his people. The book was intended to give comfort to the people of Judah in exile.

####### How should the title of this book be translated? #######

Translators may decide to translate this traditional title, "The Book of Obadiah," in a way that is clearer to the readers. Translators may decide to call it, "The Sayings of Obadiah." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]]) 

####### Who wrote the Book of Obadiah? #######

Obadiah probably wrote this book. We know nothing more about the writer than that his name in Hebrew means, "Servant of Yahweh."

##### Part 2: Important Religious and Cultural Concepts #####

####### What was Edom's relationship to Israel? #######

Obadiah referred to Edom as Israel's brother. This is because the Edomites were descendants of Esau, and the Israelites were descendants of Jacob. Jacob and Esau were brothers. This made Edom's betrayal of Israel much worse.

##### Part 3: Important Translation Issues #####

####### How do I translate the concept of "pride"? #######

Obadiah spoke a lot about "pride" in his book. When Obadiah spoke about the "pride" of Edom, he meant that the Edomites thought they were more powerful than Yahweh and that he would not or was not able to punish them. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]])



---

