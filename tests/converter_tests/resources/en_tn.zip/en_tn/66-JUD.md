# <a id="jud"/>Jude

## Jude 01

### Jude 01:01

#### General Information:

Jude identifies himself as the writer of this letter and greets his readers. He was probably the half-brother of Jesus. There are two other Judes mentioned in the New Testament.

#### General Information:

The word "you" in this letter refers to the Christians to whom Jude was writing and is always plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Jude, a servant of

Jude is the brother of James. AT: "I am Jude, a servant of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### brother of James

James and Jude were half brothers of Jesus.

#### May mercy and peace and love be multiplied to you

"may mercy, peace, and love be increased many times for you." These ideas are spoken of as if they were objects that could grow in size or number. This can be restate to remove the abstract nouns "mercy," "peace," and "love." AT: "May God continue to be merciful to you so that you live peacefully and love one another more and more (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jamesbrotherofjesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Jude 01:03

#### Connecting Statement:

Jude tells the believers his reason for writing this letter.

#### General Information:

The word "our" in this letter includes both Jude and believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### our common salvation

"the salvation we share"

#### I had to write

"I felt a great need to write" or "I felt an urgent need to write"

#### to exhort you to struggle earnestly for the faith

"to encourage you to defend the true teaching"

#### once for all

"finally and completely"

#### believers

"saints." Some versions translate this as "holy ones." It gives the idea of Christian believers with no special emphasis on their moral qualities, but rather believers who are made saints by belief in Jesus' death for salvation.

#### For certain men have slipped in secretly among you

"For some men have come in among the believers without drawing attention to themselves"

#### men who were marked out for condemnation

This can also be put into the active voice. AT: "men whom God chose to condemn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who pervert the grace of our God into sensuality

God's grace is spoken of as if it were a thing that could be changed into something horrible. AT: "who change the grace of our God into filthy lust" or "who teach that God's grace permits one to continue to live in sexual sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### deny our only Master and Lord, Jesus Christ

Possible meanings are 1) they teach that he is not God or 2) these men do not obey Jesus Christ.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exhort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exhort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Jude 01:05

#### Connecting Statement:

Jude gives examples from the past of those who did not follow the Lord.

#### I wish to remind you

"I want you to remember"

#### although once you fully knew it

"although at one time you completely knew this"

#### the Lord saved a people out of the land of Egypt

"the Lord rescued the Israelites long ago from Egypt"

#### the Lord

Some texts read "Jesus."

#### their own position of authority

"the responsibilities God entrusted to them"

#### left their proper dwelling place

"abandoned their own assigned places"

#### God has kept them in everlasting chains, in utter darkness

"God has put these angels in a dark prison from which they will never escape"

#### utter darkness

"Darkness" here is a metaphor, representing the absence of God. AT: "complete separation from God"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the great day

the final day when God will judge everyone

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Jude 01:07

#### the cities around them

Here "cities" stands for the people who lived in them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### also indulged themselves

The sexual sins of Sodom and Gomorrah were the result of the same kind of rebellion as the angels' evil ways.

#### as examples of those who suffer the punishment

The destruction of the people of Sodom and Gomorrah became an example of the fate of all who reject God.

#### these dreamers

the people who disobey God, probably because they claimed to see visions that gave them authority to do so

#### pollute their bodies

This metaphor says that their sin makes their bodies—that is, their actions—unacceptable the way garbage in a stream makes the water undrinkable. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### say slanderous things

"speak insults"

#### glorious ones

This refers to spiritual beings, such as angels.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Jude 01:09

#### General Information:

Balaam was a prophet who refused to curse Israel for an enemy but then taught that enemy to get the people to marry unbelievers and become idol worshipers.

#### General Information:

Korah was a man of Israel who rebelled against Moses' leadership and Aaron's priesthood.

#### did not dare to bring

"controlled himself. He did not bring" or "was not willing to bring"

#### a slanderous judgment

"an evil-speaking judgment" or "an evil judgment"

#### these people

the ungodly people

#### bring a slanderous judgment against

"say evil, untrue things about"

#### whatever they do not understand

"anything of which they do not know the meaning." Possible meanings are 1) "everything good that they do not understand" or 2) "the glorious ones, which they do not understand" ([Jude 1:8](./07.md)).

#### walked in the way of Cain

"Walked in the way" here is an idiom for "lived in the same way as." AT: "lived in the same way as Cain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]

### Jude 01:12

#### Connecting Statement:

Jude uses a series of metaphors to describe the ungodly men. He tells the believers how to recognize these men when they are among them.

#### These are the ones

The word "These" refers to the "ungodly men" of [Jude 1:4](./03.md).

#### hidden reefs

Reefs are large rocks that are very close to the surface of water in the sea. Because sailors cannot see them, they are very dangerous. Ships can easily be destroyed if they hit these rocks. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### autumn trees without fruit

Possible meanings are that these people are like 1) trees from which people expect to harvest fruit, but they have none, or 2) trees that never bear fruit. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fruit

This is a metaphor for a life that pleases God and helps other people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### twice dead, torn up by the roots

A tree that someone has uprooted is a metaphor for death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### torn up by the roots

Like trees that have been completely pulled out of the ground by their roots, the ungodly people have been separated from God, who is the source of life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### violent waves in the sea

As the sea's waves are blown by a strong wind, so the ungodly people are easily moved in many directions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### foaming out their own shame

As wind causes wild waves to stir up dirty foam—so these men, through their false teaching and actions, shame themselves. AT: "and just as waves bring up foam and dirt, these men pollute others with their shame" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wandering stars

Those who studied the stars in ancient times noticed that what we call planets do not move the way that stars do. AT: "disorderly stars" or "moving stars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for whom the gloom of thick darkness has been reserved forever

"Darkness" here is a metaphor for separation from God. AT: For them God has set aside a place of complete separation from Himself, where he will keep them forever."  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Jude 01:14

#### the seventh from Adam

If Adam is counted as the first generation of mankind, Enoch is the seventh. If Adam's son is counted as the first, Enoch is sixth in line.

#### Look

"Listen" or "Pay attention to this important thing I am going to say"

#### to execute judgment on

"to make judgment on" or "to judge"

#### grumblers, complainers

People who do not want to obey and speak against godly authority. "Grumblers" tend to speak quietly, while "complainers" speak openly.

#### loud boasters

People who praise themselves so that others can hear.

#### flatter others

"give false praise to others"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/enoch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/enoch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/adam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/adam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Jude 01:17

#### will follow their own ungodly desires

These people are spoken of as if their desires were kings who ruled over them. AT: "are never able to stop dishonoring God by doing the evil things they wish to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will follow their own ungodly desires

Ungodly desires are spoken of as if they were a path that a person will follow. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It is these

"It is these mockers" or "These mockers are the ones"

#### are worldly

think as other ungodly people think, they value the things that unbelievers value (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they do not have the Spirit

The Holy Spirit is spoken of as if he were something that people can possess. AT: "the Spirit is not within them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Jude 01:20

#### Connecting Statement:

Jude tells the believers how they should live and how they should treat others.

#### But you, beloved

"Do not be like them, beloved. Instead"

#### build yourselves up

Becoming increasingly able to trust in God and obey him is spoken of as if it were the process of constructing a building. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Keep yourselves in God's love

Remaining able to receive God's love is spoken of as if one were keeping oneself in a certain place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wait for

"eagerly look forward to"

#### the mercy of our Lord Jesus Christ that brings you eternal life

Here "mercy" stands for Jesus Christ himself, who will show his mercy to the believers by making them live forever with him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Jude 01:22

#### those who doubt

"those who do not yet believe that Jesus is God"

#### snatching them out of the fire

The picture is that of pulling people from a fire before they start to burn. AT: "doing for them whatever needs to be done to keep them from dying without Christ. This is like pulling them from the fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### To others be merciful with fear

"Be kind to others, but be afraid of sinning the way they did"

#### Hate even the garment stained by the flesh

Jude exaggerates to warn his readers that they can become like those sinners. AT: "Treat them as though you could become guilty of sin just by touching their clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Jude 01:24

#### Connecting Statement:

Jude closes with a blessing.

#### to cause you to stand before his glorious presence

His glory is brilliant light that represents his greatness. AT: "and to allow you to enjoy and worship his glory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### glorious presence without blemish and with

Here sin is spoken of as if it were dirt on one's body or a flaw on one's body. AT: "glorious presence, where you will be without sin and have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to the only God our Savior through Jesus Christ our Lord

"to the only God, who saved us because of what Jesus Christ did." This emphasizes that God the Father as well as the Son is the Savior.

#### be glory, majesty, dominion, and power, before all time, now, and forevermore

God has always had, now has, and always will have glory, absolute leadership, and complete control of all things.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

## Jude front

### Jude front:intro

#### Introduction to Jude ####

##### Part 1: General Introduction #####

####### Outline of the Book of Jude #######

1. Introduction (1:1-2)
1. Warning against false teachers (1:3-4)
1. Old Testament examples (1:5-16)
1. Proper response (1:17-23)
1. Praises to God (1:24-25)

####### Who wrote the Book of Jude? #######

The author identified himself as Jude the brother of James. Both Jude and James were half-brothers of Jesus. It is unknown whether this letter was intended for a specific church. 

####### What is the Book of Jude about? #######

Jude wrote this letter to warn believers against false teachers. Jude often referred to the Old Testament. This may suggest that Jude was writing to a Jewish Christian audience. This letter and 2 Petter have similar content. They both speak about angels, Sodom and Gomorrah, and false teachers.

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Jude." Or they may choose a clearer title, such as "The Letter from Jude" or "The Letter Jude Wrote." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### Who were the people Jude spoke against? #######

It is possible that the people Jude spoke against were those who would become known as Gnostics. These teachers distorted the teachings of scripture for their own gain. They lived in immoral ways and taught others to do the same. 



---

