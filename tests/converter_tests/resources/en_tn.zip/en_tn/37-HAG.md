# <a id="hag"/>Haggai

## Haggai 01

### Haggai 01:01

#### In the second year of Darius the king

"In the second year of the reign of Darius the king" or "After Darius had been king for more than a year" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Darius ... Haggai ... Zerubbabel ... Shealtiel ... Joshua ... Jehozadak

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in the sixth month, on the first day of the month

"on the first day of the sixth month." This is the sixth month of the Hebrew calendar. The first day is near the middle of August on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the word of Yahweh came

This idiom is used to introduce a special message from God. AT: "Yahweh gave a message" or "Yawheh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### by the hand of Haggai

Here the word "hand" refers to Haggai himself. Yahweh used Haggai as the agent to deliver his command. See how you translated this in [Haggai 1:1](./01.md). AT: "through Haggai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Yahweh's house

the temple

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Haggai 01:03

#### the word of Yahweh came

This idiom is used to introduce a special message from God. See how you translated this in [Haggai 1:1](./01.md). AT: "Yahweh gave a message" or "Yawheh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### by the hand of Haggai

Here the word "hand" refers to Haggai himself. Yahweh used Haggai as the agent to deliver his command. See how you translated this in [Haggai 1:1](./01.md). AT: "through Haggai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Is it a time for you ... ruined?

Yahweh is rebuking the people. This rhetorical question can be translated as a statement. AT: "Now is not the time for you ... ruined." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### this house

the temple of Yahweh

#### but cannot get drunk

There is not enough wine to satisfy the people's thirst and not nearly enough for drunkenness. The reader should understand that the text is not calling drunkenness a good thing.

#### the wage earner earns money only to put it into a bag full of holes

Not earning enough money to buy necessary goods is spoken of as if the person were losing the money that falls out through holes in the money bag. AT: "the money the worker earns is gone before he finishes buying everything he needs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Haggai 01:07

#### bring timber

This represents only a part of what they needed to build the temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### behold

"look" or "listen" or "pay attention to what I am about to tell you"

#### I blew it away

The people not being able to find what they were looking for is spoken of as if Yahweh had blown on dust so it would go away. AT: "I made sure there was nothing there for you to find" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### declares Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Haggai 01:10

#### the heavens withhold the dew from you

The dew that appears at night is spoken of as if it formed in the sky and fell like rain. The sky is spoken of as if it were a person who refused to give a present or a parent who refused to feed his child. AT: "the sky does not allow the dew to fall" or "no dew forms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I have summoned a drought upon the land

Rain not falling for a long time is spoken of as if Yahweh had told a person to come and make the land dry. AT: "I have kept the rain from falling on the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### upon the new wine, upon the oil

"Wine" and "oil" are metonyms for grapes and olives. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### all the labor of your hands

The abstract noun "labor" can be translated using the phrase "work hard." The labor that the hands perform is a metonym for the things that the labor produces. The hand is a metonym for the person. AT: "everything you have worked hard to make" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Haggai 01:12

#### Zerubbabel ... Shealtiel ... Joshua ... Jehozadak ... Haggai

See how you translated these men's names in [Haggai 1:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### obeyed the voice of Yahweh ... the words of Haggai

The voice and the words are metonyms for the persons. AT: "obeyed Yahweh and Haggai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the people feared the face of Yahweh

Possible meanings are 1) the face could be a synecdoche for the person. AT: "the people feared Yahweh" or 2) the face could be a metonym for the person's presence. AT: "the people were afraid to be in Yahweh's presence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### this is Yahweh's declaration

"this is what Yahweh has declared" or "this is what I, Yahweh, have declared"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]

### Haggai 01:14

#### Yahweh stirred up the spirit of the governor of Judah, Zerubbabel son of Shealtiel, and the spirit of the high priest Joshua son of Jehozadak, and the spirit of all the remnant of the people

Stirring the spirit is a metonym for making someone want to act. AT: "Yahweh made the governor of Judah, Zerubbabel son of Shealtiel, and the high priest Joshua son of Jehozadak, and all the remnant of the people want to act" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### remnant

people who were still alive after being captive in Babylon and had returned to Jerusalem

#### in the twenty-fourth day of the sixth month

This is just 23 days after he received the vision. This is the sixth month of the Hebrew calendar. The twenty-fourth day is near the middle of September on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the second year of Darius the king

"second year of the reign of Darius the king" or "after Darius had been king for more than one year" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Haggai 01:intro

#### Haggai 01 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in this chapter.

####### Special concepts in this chapter #######

######## Farming imagery ########
Scripture frequently uses the imagery of farming in reference to spiritual matters. The statement "You have sown much seed, but bring in little harvest" indicates that they had done a lot but have very little to show for it. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md)]])

##### Links: #####

* __[Haggai 01:01 Notes](./01.md)__
* __[Haggai intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Haggai 02

### Haggai 02:01

#### In the seventh month on the twenty-first day of the month

This is the seventh month of the Hebrew calendar. The twenty-first day is near the middle of October on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the word of Yahweh came

This idiom is used to introduce a special message from God. See how you translated this in [Haggai 1:1](../01/01.md). AT: "Yahweh gave a message" or "Yawheh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### by the hand of Haggai

Here the word "hand" refers to Haggai himself. Yahweh used Haggai as the agent to deliver his command. See how you translated this in [Haggai 1:1](../01/01.md). AT: "through Haggai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Haggai ... Zerubbabel ... Shealtiel ... Joshua ... Jehozadak

See how you translated these men's names in [Haggai 1:1](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Haggai 02:03

#### General Information:

Yahweh speaks to the people about the new temple they are building. They are building it on the same place their ancestors built the former temple, which Nebuchadnezzar completely destroyed. This new temple is much smaller than the former temple.

#### Who is left among you who saw this house in its former glory?

Yahweh speaks of the new temple as if it were the same building as the old temple. He is telling those who had seen the former temple to pay attention. This rhetorical question can be translated as a statement. AT: "I want those among you who saw this house in its former glory to pay attention." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### How do you see it now?

Yahweh is telling them that he knows what they are thinking about the new temple. He speaks of the new temple as if it were the same building as the old temple. This rhetorical question can be translated as a statement. AT: "I know what you think of this new temple." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Is it not like nothing in your eyes?

Yahweh is telling the people that he understands that they are disappointed because the new temple is so small. This rhetorical question can be translated as a statement. AT: "I know that you think it is not important at all." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### Now, be strong

"From now on, be strong"

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Haggai 1:9](../01/07.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Haggai 02:06

#### I will ... shake the heavens ... the earth ... the sea ... the dry land ... every nation

The words "I will shake the earth" could be translated as "I will cause an earthquake," and that earthquake would shake "the sea" as well as "the dry land," a merism for the entire earth. Yahweh speaks of the heavens and every nation as if they also were solid objects that he could shake. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### shake

Use the verb you usually use for pushing trees back and forth to get fruit or other objects to fall from them.

#### I will fill this house with glory

Yahweh speaks of glory as if it were a solid or liquid that could be put into a container, the temple. Possible meanings are 1) the temple will become very beautiful. AT: "I will make this house very beautiful" or 2) the "precious things" that "every nation will bring" include much silver and gold and other forms of wealth. AT: "I will have people bring many beautiful things into this house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Haggai 02:08

#### The silver and gold are mine

The words "silver and gold" are a metonym for the treasures that the nations would bring into the temple ([Haggai 2:7](./06.md)). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Haggai 1:9](../01/07.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Haggai 02:10

#### On the twenty-fourth day of the ninth month

This is the ninth month of the Hebrew calendar. The twenty-fourth day is near the middle of December on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### in the second year of Darius

"in the second year of the reign of Darius" or "when Darius had been king for more than one year" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Darius ... Haggai

See how you translated these men's names in [Haggai 1:1](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the word of Yahweh came

This idiom is used to introduce a special message from God. See how you translated this in [Haggai 1:1](../01/01.md). AT: "Yahweh gave a message" or "Yawheh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### meat that is set apart to Yahweh ... holy

The words "that is set apart to Yahweh" and the word "holy" translate the same Hebrew word. "holy meat ... holy"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Haggai 02:13

#### because of death

"because he has touched a dead body"

#### So Haggai answered and said, "So it is ... is unclean

Haggai answers the priests with the words that Yahweh told Haggai to tell the priests. AT: "So Haggai answered and told them Yahweh's words: 'So it is ... is unclean"

#### So it is with this people and this nation before me

"I look at this people and this nation the same way." Yahweh reminds the priests that a clean thing that touches an unclean thing becomes unclean. He then reminds them that he thinks of them as unclean because they have been worshiping idols, and so everything they touch and make becomes unclean.

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Haggai 1:9](../01/07.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Haggai 02:15

#### Before stone was placed upon stone in the temple

This can be translated in active form. AT: "Before you laid the first stones for the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### twenty measures

"20 measures." A "measure" is an unknown amount. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### fifty measures

"50 measures." A "measure" is an unknown amount. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### all the work of your hands

"everything you made" or "your crops"

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Haggai 1:9](../01/07.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Haggai 02:18

#### the twenty-fourth day of the ninth month

This is the ninth month of the Hebrew calendar. The twenty-fourth day is near the middle of December on Western calendars. See how you translated this in [Haggai 2:10](./10.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the day that the foundation of Yahweh's temple was laid

This can be translated in active form. AT: "the day that you laid the foundation of Yahweh's temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Is there still seed in the storehouse?

Yahweh is preparing the people for the promise he is about to give them. This rhetorical question can be translated as a statement. AT: "You can see that there is no seed in the storehouse." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The vine, the fig tree, the pomegranate, and the olive tree

"Your grape vines, fig trees, pomegranate trees, and olive trees"

#### the pomegranate

This is a type of sweet fruit. You may need to make explicit that the tree is being spoken of. AT: "the pomegranate tree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]

### Haggai 02:20

#### the word of Yahweh came

This idiom is used to introduce a special message from God. See how you translated this in [Haggai 1:1](../01/01.md). AT: "Yahweh gave a message" or "Yawheh spoke this message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Haggai ... Zerubbabel

These are names of men. See how you translated this in [Haggai 1:1](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### on the twenty-fourth day of the month

You may need to make explicit which month is spoken of. AT: "on the twenty-fourth day of the ninth month" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### I will shake the heavens and the earth

The words "I will shake the earth" could be translated as "I will cause an earthquake." Yahweh speaks of the heavens as if they also were solid objects that he could shake. See how these ideas are translated in [Haggai 2:6](./06.md).(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### shake

Use the verb you usually use for pushing trees back and forth to get fruit or other objects to fall from them. See how you translated this in [Haggai 2:6](./06.md).

#### the heavens and the earth

This is a merism for "the whole universe" or "everything that exists." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### I will overthrow the throne of kingdoms

The throne is a metonym for the person sitting on the throne. AT: "I will take kings off of their thrones" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the throne of kingdoms

Here "throne" is a metonym for the king who sits on it. AT: "government ruled by kings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will ... destroy the strength of the kingdoms of the nations

You may need to make explicit that "the nations" are Israel's enemies. AT: "I will make it so the kingdoms of the nations that are Israel's enemies are no longer strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### each one because of his brother's sword

The sword here is a metonym for violent death. AT: "each one because his brother has killed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Haggai 02:23

#### On that day

"On the day I choose to act"

#### this is the declaration of Yahweh of hosts

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Haggai 1:9](../01/07.md). AT: "this is what Yahweh of hosts has declared" or "this is what I, Yahweh of hosts, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Zerubbabel ... Shealtiel

See how you translated these men's names in [Haggai 1:1](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### this is Yahweh's declaration

Yahweh speaks of himself by name to express the certainty of what he is declaring. See how you translated this in [Haggai 1:9](../01/07.md). AT: "this is what Yahweh has declared" or "this is what I, Yahweh, have declared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I will make you like a signet ring

Kings used a signet ring to seal documents to show that they truly had his authority. Zerubbabel would have authority from Yahweh because he would speak Yahweh's words. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]

### Haggai 02:intro

#### Haggai 02 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 2:3-9, 21-23.

####### Important figures of speech in this chapter #######

######## Unclean ########
Haggai uses an extended metaphor in this chapter related to ritual cleanliness. While the Jews were not unclean by nature as the Gentiles were, their actions made them unclean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unclean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unclean.md)]]) 

##### Links: #####

* __[Haggai 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | __


## Haggai front

### Haggai front:intro

#### Introduction to Haggai ####

##### Part 1: General Introduction #####

####### Outline of Haggai #######

1. The temple must be completed if Yahweh's blessings are going to be restored to the nation (1:1–15)
1. The smaller and less impressive temple will be more glorious than the first (2:1–9)
1. Disobedience causes failure in worship; sinful selfishness leads to crop failures (2:10–19)
1. A promise made to Zerubbabel (2:20–23) 

####### What is the Book of Haggai about? #######

Haggai told the people that they were having so many troubles because they were not obeying Yahweh. If they would listen to him and start rebuilding the temple, then Yahweh would cause the troubles to end. The people listened and began to work on the temple. Yahweh encouraged the people, the priests, and the leaders and told them that he was with them and would bless them. 

####### How should the title of this book be translated? #######

Translators may decide to translate this traditional title "The Book of Haggai" in a way that is clearer to the readers. They may decide to call it "The Sayings of Haggai." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Haggai? #######

The prophet Haggai wrote this book, but very little is known about him. The book was written after the exiles returned from Babylon They returned during the reign of Darius I in Persia. The prophecies of Haggai probably all occurred during a four month period. Haggai lived at the same time as the prophet Zechariah.

##### Part 2: Important Religious and Cultural Concepts #####

####### Did Haggai prophesy before Ezra and Nehemiah? #######

It is likely that Haggai prophesied before the time of Ezra and Nehemiah.

##### Part 3: Important Translation Issues #####

####### What does "consider your ways" mean? #######

The Lord told the people to "consider your ways" several times in this book. This means that God wants them to think carefully about their lives and how they have behaved.



---

