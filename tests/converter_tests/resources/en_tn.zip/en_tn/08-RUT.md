# <a id="rut"/>Ruth

## Ruth 01

### Ruth 01:01

#### It happened

"It was" or "This is what happened." This is a common way of beginning a historical story.

#### in the days when the judges ruled

"during the time when judges led and governed Israel"

#### in the land

This refers to the land of Israel. AT: "in the land of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a certain man

"a man." This is a common way of introducing a character into a story.

#### Ephrathites of Bethlehem of Judah

They were people from the tribe of Ephraim who settled at Bethlehem in the region of Judea.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]

### Ruth 01:03

#### she was left with her two sons

"Naomi had only her two sons with her"

#### took wives

"married women." This is an idiom for marrying women. They did not take women who were already married. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### from the women of Moab

Naomi's sons married women who were from the tribe of Moab. The Moabites worshiped other gods.

#### the name of one ... the name of the other

"the name of one woman ... the name of the other woman"

#### ten years

Ten years after Elimelek and Naomi came to the country of Moab, their sons Mahlon and Kilion died.

#### leaving Naomi

Naomi was widowed.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Ruth 01:06

#### she had heard in the region of Moab

"while Naomi was living in Moab she heard." It is implied that the news came from Israel. AT: "she heard from Israel while in the region of Moab" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### had helped his people in need

God saw their need and provided good harvests for them.

#### daughters-in-law

the women who married Naomi's sons

#### they walked down the road

"they walked along the road." To walk down a road is an expression for walking away. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Ruth 01:08

#### daughters-in-law

"sons' wives" or "sons' widows"

#### each of you

Naomi was talking to two people, so languages that have a dual form of "you" would use that throughout her talk. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### your mother's house

"to the home of each of your mothers"

#### shown kindness

"demonstrated that you are loyal"

#### kindness

"kindness" includes the ideas of love, kindness, and faithfulness.

#### toward the dead

"to your husbands, who died." Naomi was referring to her two sons that died. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### grant you

"give you" or "allow you to have"

#### rest

"Rest" here includes security in marriage.

#### in the house of another husband

with their new husbands, not someone else's husband. This refers to both a physical house that belongs to the husband, and to the protection from shame by being married. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they raised their voices and cried

This means that the daughters cried out loud or wept bitterly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### We will return

When Orpah and Ruth said "we," they were referring to themselves and not Naomi. So languages that have inclusive and exclusive "we" would use the exclusive form here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### with you

Here "you" is the singular form referring to Naomi. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Ruth 01:11

#### Why will you go with me?

This is a rhetorical question. AT: "It does not make sense for you to go with me." or "You should not go with me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Do I still have sons in my womb for you, so that they may become your husbands?

Naomi uses this question to say she cannot have other sons for them to marry. AT: "Obviously it is not possible for me to have any more sons who could become your husbands." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### too old to have a husband

The reason a husband would be important can be stated clearly. AT: "too old to marry again and bear more children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### give birth to sons

"bear children" or "deliver baby boys"

#### would you therefore wait until they were grown? Would you choose not to marry a husband?

These are rhetorical questions, which do not expect an answer. AT: "you would not wait until they were grown up so that you could marry them. You would choose to marry a husband now." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### It is exceedingly bitter to me

Bitterness is a metaphor for grief, and what grieves her can be stated clearly. AT: "It greatly grieves me that you have no husbands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] or [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the hand of Yahweh has gone out against me

The word "hand" refers to Yahweh's power or influence. AT: "Yahweh has caused terrible things to happen to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Ruth 01:14

#### lifted up their voices and cried

This means that they cried out loud or wept bitterly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Listen

"What I am about to say is important"

#### Ruth held on to her

"Ruth clung to her." AT: "Ruth refused to leave her" or "Ruth would not leave her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### your sister-in-law

"the wife of your husband's brother" or "Orpah"

#### her gods

Before Orpah and Ruth married Naomi's sons, they worshiped the gods of Moab. During their marriage, they began to worship Naomi's God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Ruth 01:16

#### where you stay

"where you live"

#### your people will be my people

Ruth is referring to Naomi's people, the Israelites. AT: "I will consider the people of your country as being my own people" or "I will consider your relatives as my own relatives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Where you die, I will die

This refers to Ruth's desire to spend the rest of her life living in the same place and town as Naomi. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### May Yahweh punish me, and even more, if

This refers to Ruth asking God to punish her if she does not do what she said like the english idiom "God forbid, if." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### she stopped arguing with her

"Naomi stopped arguing with Ruth"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Ruth 01:19

#### It happened

"It came about." This is marking a new story line. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### the entire town

The "town" refer to the people who live there. AT: "everyone in the town" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Is this Naomi?

Since it has been many years since Naomi lived in Bethlehem and no longer has her husband and two sons, it is likely the women were expressing doubt as to if this woman was actually Naomi. Treat as a real question, not rhetorical.

#### Do not call me Naomi

The name "Naomi" means "my delight." Since Naomi lost her husband and sons, she no longer feels her life matches her name.

#### Bitter

This is a translation of the meaning of the name. It is also often translated according to its sound as "Mara." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I went out full, but Yahweh has brought me home again empty

When Naomi left Bethlehem, her husband and two sons were living, and she was happy. Naomi blames Yahweh for the death of her husband and sons, saying that he has caused her to return to Bethlehem without them, and now she is bitter and unhappy.

#### condemned me

"judged me guilty"

#### has afflicted me

"has brought calamity on me" or "has brought tragedy to me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]

### Ruth 01:22

#### So Naomi and Ruth

This begins a summary statement. English marks this by the word "so." Determine how your language marks concluding or summary statements and do the same. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md)]])

#### at the beginning of the barley harvest

The phrase "the barley harvest" can be translated with a verbal phrase. AT: "when the farmers were just beginning to harvest barley" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Ruth 01:intro

#### Ruth 01 General Notes ####

####### Structure and formatting #######

######## "It happened in the days when the judges ruled" ########
The events of this book occur during the period of Judges. The book is concurrent with the book of Judges. To understand the historical context of the book, the translator may wish to review the book of Judges.

####### Special concepts in this chapter #######

######## Women without a husband or children ########
In the ancient Near East, if a woman lacked a husband or sons, she was considered to be in a dire circumstance. She would not have been able to provide for herself. This is why Naomi told her daughters to remarry.

####### Other possible translation difficulties in this chapter #######

######## Contrast ########
The actions of Ruth the Moabite are intended to contrast with the actions of Naomi the Jew. Ruth shows great faith in Naomi's god, while Naomi does not trust in Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]])

##### Links: #####

* __[Ruth 01:01 Notes](./01.md)__
* __[Ruth intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Ruth 02

### Ruth 02:01

#### Now Naomi had a relative of her husband

This phrase introduces new information before the story continues. Your language may have a way to introduce new information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### a worthy man

"a prominent, wealthy man." This means that Boaz was prosperous and well known in his community, with a good reputation.

#### Ruth, the Moabite woman

Here the story resumes. You need to see how your language restarts a story after a break.

#### the Moabite woman

This is another way of saying the woman was from the country or tribe of Moab.

#### glean what remains among the ears of grain

"gather kernels of grain left behind by the harvesters" or "pick up kernels of grain left behind by the harvesters"

#### ears

"heads" or "stalks." The "ears" are the parts of a grain plant that contain the grain.

#### in whose eyes I will find favor

The phrase "found favor" is an idiom which means to be approved of by someone. Ruth speaks of gaining someone's favor as gaining permission or approval. Also, the eyes represent seeing, and seeing represents thoughts and judgement. AT: "who will grant me permission to glean" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### daughter

Ruth was caring for Naomi as if she were her own mother. Make sure it is possible in your language to use this word for someone who is not an actual daughter.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]

### Ruth 02:03

#### She happened to come

Ruth was not aware that the field she picked to glean in belonged to Naomi's relative Boaz.

#### Behold, Boaz

The word "behold" alerts us to the important event of Boaz arriving at the field. Your language may also have a specific way of introducing important events or characters.

#### came from Bethlehem

The fields were an unspecified distance outside of Bethlehem.

#### bless you

"give you good things" or "make you happy"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Ruth 02:05

#### What man does this young woman belong to?

Possible meanings are 1) Boaz was asking about Ruth's husband or 2) Boaz was asking about Ruth's parents or current guardians.

#### supervising

"in charge of" or "managing"

#### house

"hut" or "shelter." This was a temporary shelter or garden hut in the field that provided shade from the sun.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]

### Ruth 02:08

#### Are you listening to me, my daughter

This can be reworded as a command. AT: "Listen to me, my daughter" or "Note well what I am telling you, my daughter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my daughter

This was a kind way of addressing a younger woman. Ruth was not the actual daughter of Boaz, so make sure the translation of this does not make it sound like she was. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Keep your eyes only on the field

The eyes represent watching something or paying attention to something. AT: "Watch only the field" or "Pay attention only to the field" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Have I not instructed the men ... you?

Boaz used this question to emphasize what he had already done to help Ruth. AT: "I have given the men strict instructions ... you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### men ... the other women

"young male workers ... young female workers." The word "men" is used three times to refer to the young men who are harvesting in the field. Some languages can say this using one word, and they have a different word that means young women workers.

#### not to touch you

Possible meanings are 1) the men were not to harm Ruth or 2) the men were not to stop her from gleaning in his field.

#### the water that the men have drawn

To draw water means to pull up water from a well or to take it out of a storage vessel.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]

### Ruth 02:10

#### she bowed down before Boaz, touching her head to the ground

These are acts of respect and reverence. She was showing honor to Boaz out of gratefulness for what he had done for her. It was also a posture of humility.

#### Why have I found such favor ... a foreigner?

Ruth is asking a real question.

#### foreigner

Ruth had pledged her loyalty to the God of Israel in private, but she was known publicly as "the Moabitess."

#### It has been reported to me

This can be stated in active form. AT: "People have reported to me" or "People have told me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to come to a people

Boaz is referring to Ruth coming to dwell with Naomi in a village and community, a country, and religion she did not know. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### reward you

"repay you" or "pay you back"

#### for your deed

This is an act of faith, choosing to live with Naomi in Bethlehem and trusting Naomi's God.

#### May you receive full payment from Yahweh

This is a poetic expression that is very similar to the previous sentence. AT: "May Yahweh give back to you even more than you have given" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### under whose wings you have found refuge

Boaz uses the picture of a mother bird gathering her chicks under her wings to protect them, in order to describe God's protection for those who trust in him. AT: "in whose safe care you have placed yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Ruth 02:13

#### Let me find favor in your eyes

Here "find favor" is an idiom that means be approved of or that he is pleased with her. Here "eyes" are a metonym for sight, and  sight is a metaphor representing his evaluation. AT: "Please accept me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I am not one of your female servants

Possible meanings are 1) Ruth was not one of Boaz's female servants or 2) Ruth did not think her marriage to Naomi's son granted her any privilege in Bethlehem.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Ruth 02:14

#### At mealtime

This refers to the noontime meal.

#### dip your morsel in the wine vinegar

This was a simple meal eaten in the field. People would sit on the ground around a cloth that had a bowl of wine vinegar on it and plates of broken bread. They would dip their bread in the vinegar bowl to wet it and add flavor before they ate it.

#### wine vinegar

a sauce that bread was dipped in. The Israelites further fermented some of their wine to make vinegar.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]

### Ruth 02:15

#### As she got up to gather up grain, Boaz commanded his young men

In the context of the commands, it is likely that Ruth was far enough away not to hear Boaz's instructions. AT: "And when Ruth got up to gather up grain, Boaz privately told his young men"

#### As she got up

"As she stood up"

#### even among the bundles

Here "even" denotes "above and beyond what one normally does." Boaz instructs his workers to let Ruth glean around the bundles of grain. People who were gleaning were normally forbidden from working that close to the harvested grain.

#### pull out for her some ears of grain from the bundles

"take some stalks of grain out of the bundles and leave them for her" or "leave behind stalks of grain for her to collect"

#### do not rebuke her

"do not cause her shame" or "do not dishonor her"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]

### Ruth 02:17

#### beat out

She separated the edible part of the grain from the hull and stalk, which is thrown away.

#### ears of grain

This refers to the eatable part of the grain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### about an ephah of barley

An ephah is a unit of measurement equal to about 22 liters. AT: "about 22 liters of barley" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### She lifted it up and went into the city

It is implied that Ruth carried the grain home. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### her mother-in-law saw

"Naomi saw"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]

### Ruth 02:19

#### Where have you gleaned today? Where did you go to work?

Naomi said almost the same thing in two different ways to show that she was very interested in knowing what had happened to Ruth that day. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### he be blessed by Yahweh

Naomi is asking God to reward Boaz for his kindness to Ruth and herself.

#### who has not left off his loyalty

"who has continued to be loyal." Possible meanings are 1) Boaz remembered his obligations to Naomi as a family member or 2) Naomi is referring to Yahweh, who was acting through Boaz or 3) Yahweh has continued to be faithful to the living and the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### to the living

"to the people who are still living." Naomi and Ruth were the "living."

#### the dead

Naomi's husband and sons were the "dead." This can be stated differently to remove the nominal adjective "the dead." AT: "the people who have already died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### near of kin to us, one of our kinsman-redeemers

The second phrase repeats and expands the first. This is a Hebrew style of emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### kinsman-redeemers

A kinsman-redeemer was a close male relative who could rescue a childless widow from financial ruin by marrying her and having a child with her. He would also reacquire the land his relatives had lost due to poverty and redeem family members who had sold themselves into slavery.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]

### Ruth 02:21

#### Indeed, he said to me

"He even said to me." This indicates that what follows is the most important part of Boaz's words to Ruth.

#### keep close to my young men

Boaz was referring to the physical protection his men can provide her.

#### go out with

"work with"

#### come to harm

Possible meanings are 1) other workers might abuse Ruth or try to seize her and sleep with her or 2) in another field, the owner might interfere or stop her from gleaning until the end of the harvest.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Ruth 02:23

#### she stayed close

Ruth worked in Boaz's fields with his workers during the day, so she would be safe.

#### She lived with her mother-in-law

Ruth went to Naomi's home to sleep at night.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]

### Ruth 02:intro

#### Ruth 02 General Notes ####

####### Other possible translation difficulties in this chapter #######

######## "Do not go and glean in another field" ########
Boaz said this because he could not guarantee their safety in another person's field. It is assumed that not everyone was as gracious and obedient to the law of Moses as Boaz. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Ruth 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Ruth 03

### Ruth 03:01

#### mother-in-law

Naomi is the mother of Ruth's dead husband.

#### My daughter

Ruth became Naomi's daughter by marrying her son and further by her actions in caring for Naomi after returning to Bethlehem.

#### should I not seek a place for you to rest ... for you?

Naomi uses this question to tell Ruth what she planned to do. AT: "I must look for a place for you to rest ... for you." or "I must find a husband to care for you ... for you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### a place for you to rest

Possible meanings are 1) literally in finding a house for her to live in or 2) figuratively in finding a husband to care for her. Naomi probably had both senses in mind. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### female workers you have been with

The translation can make explicit that she was working in the fields with these female workers. AT: "female workers you have been with in the fields" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### is he not our kinsman?

Naomi probably used this question to remind Ruth of something she had already told her. AT: "he is our relative." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Look

This term indicates that the following statement is very important.

#### winnowing

To winnow means to separate grain from the unwanted chaff by tossing both the grain and chaff into the air, allowing the wind to blow the chaff away.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winnow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winnow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]

### Ruth 03:03

#### anoint yourself

This is probably a reference to rubbing sweet-smelling oil on oneself, much as women put on perfume today.

#### go down to the threshing floor

This refers to leaving the city and heading to the threshing area. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### uncover his feet

This means to remove the cloak or blanket covering his feet so that they would be exposed to the cold. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### lie down there

"lie down at his feet"

#### Then he will tell you what to do

The specific custom of that time is unclear, but this is usually understood as a culturally acceptable way for a woman to tell a man that she was willing to marry him. Boaz would understand the custom and accept or reject her offer.

#### Then he will

"When he wakes up, he will"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]

### Ruth 03:06

#### his heart was merry

Here Boaz is referred to by his heart. It does not imply Boaz was overly drunk. AT: "he was satisfied" or "he was in a good mood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### she came softly

"she sneaked in" or "she came in quietly so no one would hear her"

#### uncovered his feet

"removed his blanket from his feet"

#### lay down

"lay down at his feet"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]

### Ruth 03:08

#### It came about

This phrase is used here to mark an important event in the story. If your language has a way for doing this, you could consider using it here.

#### at midnight

"in the middle of the night"

#### was startled

It is not clear what startled Boaz. Perhaps he suddenly felt the cold air on his feet.

#### He turned over

He looked to see what startled him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a woman was lying at his feet

The woman was Ruth, but Boaz could not recognize her in the darkness.

#### your female servant

Ruth spoke with humility to Boaz.

#### Spread your cloak over your female servant

This was a cultural idiom for marriage. AT: "Marry me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### near kinsman

a close relative with special responsibilities toward their extended family

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]

### Ruth 03:10

#### my daughter

Boaz used this expression as a sign of respect toward Ruth as a younger woman.

#### more kindness in the latter end than at the beginning

"even more kindness now than before"

#### more kindness in the latter end

This refers to Ruth asking Boaz to marry her. By marrying Naomi's relative, Ruth would provide for Naomi and demonstrate great kindness to Naomi.

#### at the beginning

This refers to the way Ruth had earlier provided for her mother-in-law by staying with her and gleaning grain for food for them.

#### because you have not gone after

"you have not pursued marriage with." Ruth could have ignored Naomi's need and looked for a husband for herself outside of Naomi's relatives. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]

### Ruth 03:12

#### kinsman nearer than I

It was the duty of the closest male relative to help the widow.

#### if he will perform for you the duty of a kinsman

Boaz is referring to the expectation that the closest male relative of Ruth's dead husband would marry her and help carry on his family name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### by the life of Yahweh

"as surely as Yahweh lives." This was a common Hebrew vow.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Ruth 03:14

#### she lay at his feet

Ruth slept at Boaz' feet. They did not have sex.

#### before anyone could recognize another person

This time of day can be spoken of in terms of darkness. AT: "while it was still dark"

#### shawl

a piece of cloth worn over the shoulders

#### six large measures of barley

The actual amount is not stated. It was enough to be considered generous, yet small enough for Ruth to carry alone. Some think it was about 30 kilograms.

#### put the load on her

The amount of grain was so great that Ruth needed help picking it up to carry it.

#### Then he went into the city

Most ancient copies have "he went," but some have "she went." There are English versions with both. The better choice is "he went."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md)]]

### Ruth 03:16

#### How did you do, my daughter?

What Ruth meant by this question can be made more clear. AT: "What happened, my daughter?" or "How did Boaz act toward you?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all that the man had done

"all that Boaz had done"

#### Do not go empty

"Do not go empty-handed" or "Do not go with nothing" or "Be sure to take something"

#### finished this thing

This refers to the decision about who will buy Naomi's property and marry Ruth.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md)]]

### Ruth 03:intro

#### Ruth 03 General Notes ####

####### Special concepts in this chapter #######

######## Boaz's integrity ########
Boaz showed great integrity in this chapter by not having sexual relations with Ruth. He was also concerned with how people would see Ruth if they caught her in this position. Boaz's character is important for this story. 

####### Other possible translation difficulties in this chapter #######

######## "So that things may go well for you" ########
Naomi attempted to make Ruth desirable to Boaz so that he would want to marry her. Even though she was a Gentile by birth, Boaz could marry her because she was, by marriage, Naomi's daughter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Ruth 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Ruth 04

### Ruth 04:01

#### gate

"gate of the city" or "gate of Bethlehem." This was the main entrance to the walled town of Bethlehem. There was an open area by the gate that was used as a meeting place to discuss community matters.

#### the near kinsman

This was the closest living relative to Elimelek.

#### elders of the city

"leaders of the city"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Ruth 04:03

#### Naomi ... is selling the parcel of land

It was the responsibility of the kinsman to buy back his relative's land and to care for his family. In this case, it meant the man must buy Naomi's land, marry Ruth, and care for Naomi.

#### in the presence of

This would make the transaction legal and binding.

#### redeem it

This meant to buy the land to keep it within their family.

#### I am after you

Boaz was the next kinsman in line to redeem the land.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]

### Ruth 04:05

#### On the day that you buy ... you must also

Boaz uses this expression to inform his relative of the additional responsibility he will have if he buys the land.

#### from the hand of Naomi

Here the word "hand" represents Naomi, who owns the field. AT: "from Naomi" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### you must also take Ruth

"you must also marry Ruth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Ruth ... the widow of a dead man

"Ruth ... the widow of Elimelek's son"

#### to raise up the name of the dead

"that she may have a son to inherit the property and carry on the name of her dead husband"

#### damaging my own inheritance

He would have to give some of his own wealth to the children that Ruth might bear.

#### You take my right of redemption for yourself

"You redeem it yourself" or "You yourself redeem it instead of me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]

### Ruth 04:07

#### Now this was the custom

The writer of the book explains of the custom of exchange during the time of Ruth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### in former times

"in earlier times." This implies that the customs had changed from when the story took place until the book was written. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### shoe

"sandal"

#### his neighbor

This refers to the person with whom he was making the agreement. In this situation the near kinsman gave Boaz his shoe.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]

### Ruth 04:09

#### to the elders and to all the people

This refers to all the people who were present at the meeting place, not to everyone in the town.

#### all that was Elimelek's and all that was Kilion's and Mahlon's

This refers to all the land and possessions of Naomi's dead husband and sons.

#### from the hand of Naomi

The hand of Naomi represents Naomi. She was responsible for the money exchange. AT: "from Naomi" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### in order that I might raise up the name of the dead man on his inheritance

The first son that Ruth bore would be legally considered Mahlon's son and would inherit the land that Boaz bought from Naomi. AT: "so that I might give her a son who will inherit the dead man's property"

#### so that his name will not be cut off from among his brothers and from the gate of his place

Being forgotten is spoken of as if one's name were being cut off from a list of people who had lived earlier. AT: "so that he will not be forgotten by his brothers' descendants and the people of this town" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the gate of his place

The gate of the town is where important legal decisions were made, such as decisions about who owns a piece of land.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Ruth 04:11

#### people who were in the gate

"people who were meeting together near the gate"

#### come into your house

This has literal and figurative meaning. As Ruth marries Boaz, she will move into his house. House can also refer to becoming part of Boaz's family by being his wife. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### like Rachel and Leah

These were the two wives of Jacob, whose name was changed to Israel.

#### built up the house of Israel

"bore many children who became the nation of Israel"

#### may you prosper in Ephrathah

Ephrathah is the name of the clan to which Boaz belonged in Bethlehem.

#### May your house be like

God abundantly blessed Judah through his son Perez. The people were asking God to bless Boaz in a similar way through Ruth's children. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Tamar bore to Judah

Tamar was also a widow. Judah fathered a son with her, which continued the family name.

#### through the offspring that Yahweh will give you

Yahweh would give Boaz children through Ruth.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rachel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rachel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/leah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/leah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Ruth 04:13

#### Boaz took Ruth

"Boaz married Ruth" or "Boaz took Ruth as a wife"

#### He slept with her

This is a euphemism that refers to having sexual intercourse. AT: "He had sexual relations with her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### who has not left you today without a near kinsman

This phrase can be expressed positively. AT: "who has provided you today with a near kinsman" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### May his name be famous

This refers to the reputation and character of Naomi's grandson.

#### a restorer of life

This phrase probably refers to how Naomi will again experience joy and hope in her life as a result of having a new grandson. AT: "one who brings joy to you again" or "one who will make you feel young again"

#### a nourisher of your old age

"he will take care of you when you become old"

#### better to you than seven sons

"Seven" was the Hebrew number of completeness. Naomi's sons both died before they produced any offspring, but Ruth bore a grandson to Naomi by Boaz. AT: "better to you than any son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ruth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Ruth 04:16

#### Naomi took the child

This refers to Naomi holding the child. Make sure it does not sound like she took him away from Ruth.

#### laid him in her bosom

"held him close against her chest." This is a statement of love and affection for the child.

#### A son has been born to Naomi

"The child is like a son to Naomi." It was understood that the child was Naomi's grandson, not her physical son.

#### father of David

"father of King David." Though "king" is not stated, it was clear to the original audience that David was King David. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jesse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jesse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]

### Ruth 04:18

#### the descendants of Perez

"the successive descendants." Because it was mentioned earlier that Perez was the son of Judah, the writer continues listing the family line that came from Perez.

#### Hezron ... Ram

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/boaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jesse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jesse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]

### Ruth 04:intro

#### Ruth 04 General Notes ####

####### Special concepts in this chapter #######

######## King David ########
Despite being a Moabitess, Ruth became an ancestor of David. David was Israel's greatest king. It is shocking a Gentile would become a part of such an important lineage. She had great faith in Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Other possible translation difficulties in this chapter #######

######## "You must also take Ruth the Moabitess" ########
Because Naomi had no son, her daughter-in-law Ruth needed to be provided for. Therefore, the relative who wanted to use her land had to also help Ruth to have a son who would come to provide for her. 

######## "This was the custom in former times" ########
This is a comment made by the writer of the text. He functions as a narrator in this instance. It indicates that there was a considerable period of time between the events that occurred and the time they were written down. 
##### Links: #####

* __[Ruth 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | __


## Ruth front

### Ruth front:intro

#### Introduction to Ruth ####

##### Part 1: General Introduction #####

####### Outline of Ruth #######

1. Naomi and Elimelek leave Bethlehem and go to Moab (1:1–5)
1. Orpah leaves for Moab but Ruth chooses to stay with Naomi (1:6–18)
1. Naomi and Ruth return to Bethlehem (1:19–22)
1. Boaz helps Ruth (2:1–23)
1. Boaz begins to assume responsibility for Ruth, but seeks to follow the rules of the "kinsman-redeemer," (3:1–18)
1. Boaz becomes the "kinsman-redeemer" by buying the field owned by Naomi and taking Ruth as his wife (4:1–16)
1. The birth of Ruth's son with Boaz and the genealogy of Obed (4:17–22)

####### What is the Book of Ruth about? #######

This book is about a non-Israelite woman named Ruth. It tells how she came to join the people of Yahweh. The book also explains how Ruth became an ancestor of King David.

####### How should the title of this book be translated? #######

Translators should use a self-explanatory title such as, "The Book about Ruth." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]]) 

####### When did the events in the Book of Ruth occur? #######

The story of Ruth is set during the time when there were "judges" in Israel. These were leaders whom God chose to help the Israelites defeat their enemies. They also helped the people by deciding disputes among them. And, they helped them make important decisions. Many of these leaders served the entire people of Israel, but some of these leaders seem to have served only certain tribes.

##### Part 2: Important Religious and Cultural Concepts #####

####### Why does Scripture include a book about a woman from the foreign land of Moab? #######

In a period when Israel is often unfaithful to Yahweh, Yahweh finds a woman from Moab who shows great faith in him. The Israelites' frequent lack of faith in Yahweh is contrasted with the faith of one of their enemies. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unfaithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unfaithful.md)]])

####### What important marriage custom is found in the Book of Ruth? #######

Israelites practiced what is called "levirate marriage." This was a custom for the closest male relative to provide for a childless widow by marrying her. Any children born to them were to be regarded as children of the dead man. They did this so that dead man would still have descendants. If the closest relative did not marry the woman, another relative could.

####### What was a "kinsman-redeemer" (2:20 ULB)? #######

A person's close relative or relatives were expected to act as "kinsmen-redeemers" for him or her. They were responsible to provide for a relative in need. In other situations, they were also responsible for taking revenge on anyone who dared to injure or kill one of their relatives. In the Book of Ruth, Boaz is one such kinsman-redeemer.

####### What was gleaning in the Book of Ruth? #######

Gleaning occurred when very poor people were allowed to follow after the men who harvested a field. These "gleaners" picked up sheaves of grain that the harvesters missed or dropped by accident. In this way, poor people were able to find some food for themselves. Ruth became a gleaner in a field belonging to Boaz.

####### What is covenant faith or covenant loyalty? #######

Covenant faith or covenant loyalty is when a person does what he said he would do according to a covenant he has with someone else. God promised that he would love and be faithful to the Israelites. The Israelites were to do the same toward him and toward each other.
 
In the Book of Ruth, the obligations of kinsmen-redeemers to their relatives are shown to be part of the obligations in God's covenant with Israel. The story of Boaz, Ruth and Naomi gives good examples to all of Israel of the good effects of covenant faithfulness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]])

####### What function did city gates have in the Ancient Near East? #######

City gates in the time of Boaz were natural meeting places for the city elders. Elders were honored men who decided business matters and legal matters together. The city walls were large, perhaps two to three meters in width. Therefore the gateway opening provided a comfortable and shady area for public meetings. For this reason, Boaz and the other elders sat in the gateway. 

Some English Bible versiosn speak of Boaz sitting "at" the city gate. It may be best for translators to make clear that Boaz sat "in" the city gate.
 
##### Part 3: Important Translation Issues #####

####### How does Ruth change from one topic to another topic? #######

The book of Ruth transitions often to new topics or new parts of the story. The ULB uses various words to indicate these transitions, such as "so," "then," and "now." Translators should use the ways most natural in their own languages to signal these developments in the narrative.



---

