# <a id="rom"/>Romans

## Romans 01

### Romans 01:01

#### Paul

Your language may have a particular way of introducing the author of a letter. You may also need to tell in this same verse who the people are to whom Paul wrote the letter ([Romans 1:7](./07.md)). AT: "I, Paul, wrote this letter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### called to be an apostle, and set apart for the gospel of God

You can translate this in an active form. AT: "God called me to be an apostle and chose me to tell people about the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### called

This means that God has appointed or chosen people to be his children, to be his servants and proclaimers of his message of salvation through Jesus.

#### This is the gospel—that he promised beforehand by his prophets in the holy scriptures

God promised his people that he would set up his kingdom. He told the prophets to write these promises in the Scriptures.

#### which is about his Son

This refers to "the gospel of God," the good news that God promised to send his Son into the world.

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### who was a descendant of David according to the flesh

Here the word "flesh" refers to the physical body. AT: "who is a descendant of David according to the physical nature" or "who was born into the family of David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Romans 01:04

#### Connecting Statement:

Paul talks here about his obligation to preach.

#### he was declared to be the Son of God

The word "he" refers to Jesus Christ. You can translate this in an active form. AT: "God declared him to be the Son of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by the resurrection from the dead

"by raising him from among the people who are dead." This expression speaks of all dead people together in the underworld, and coming alive again is spoken of as resurrection from among them.

#### Spirit of holiness

This refers to the Holy Spirit.

#### we have received grace and apostleship

God has given Paul the gift of being an apostle. You can translate this in an active form. AT: "God caused me to be an apostle. This is a special privilege" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### we

Here the word "we" refers to Paul and to the apostles that followed Jesus but excludes the believers in the church in Rome. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### for obedience of faith among all the nations, for the sake of his name

Paul uses the word "name" as a metonym to refer to Jesus. AT: "in order to teach all nations to obey because of their faith in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]

### Romans 01:07

#### This letter is to all who are in Rome, the beloved of God, who are called to be holy people

You can translate this in an active form. AT: "I am writing this letter to all of you in Rome whom God loves and has chosen to become his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### May grace be to you, and peace

You can translate this in an active form. AT: "May God give you grace and peace" or "May God bless you and give you inner peace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### God our Father

The word "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rome.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rome.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Romans 01:08

#### the whole world

the world Paul and his readers knew and could travel in, which was the Roman Empire

#### For God is my witness

Paul emphasizes that he earnestly prays for them and that God has seen him praying. The word "for" is often left untranslated.

#### in my spirit

A person's spirit is the part of him that can know God and believe in him.

#### the gospel of his Son

The good news (gospel) of the Bible is that the Son of God has given himself as the Savior of the world.

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I make mention of you

"I talk to God about you"

#### I always request in my prayers that ... I may at last be successful ... in coming to you

"Every time I pray, I ask God that ... I may succeed ... in coming to visit you"

#### by any means

"in whatever way God allows"

#### at last

"eventually" or "finally"

#### by the will of God

"because God desires it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Romans 01:11

#### Connecting Statement:

Paul continues his opening statements to the people in Rome by stating his desire to see them in person.

#### For I desire to see you

"Because I really want to see you"

#### some spiritual gift, in order to strengthen you

Paul wants to strengthen the Roman Christians spiritually. AT: "some gift that will help you to grow spiritually" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### That is, I long to be mutually encouraged among you, through each other's faith, yours and mine

You can translate this in an active form. AT: "I mean that I want us to encourage each other by sharing our experiences of faith in Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Romans 01:13

#### I do not want you to be uninformed

Paul is emphasizing that he wanted them to have this information. You can translate this double negative in a positive form. AT: "I want you to know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### brothers

Here this means fellow Christians, including both men and women.

#### but I was hindered until now

You can translate this in an active form. AT: "something has always prevented me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in order to have a harvest among you

The word "harvest" is a metaphor that represents people in Rome whom Paul wants to believe the gospel. AT: "that more people among you might trust in Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the rest of the Gentiles

the Gentiles in the other regions where he had gone

#### I am a debtor both to

Using the metaphor "debtor," Paul speaks of his duty to serve God as if he owed God a financial debt. AT: "I must take the gospel to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]

### Romans 01:16

#### I am not ashamed of the gospel

You can translate this in a positive form. AT: "I trust completely in the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### it is the power of God for salvation for everyone who believes

Here "believes" means that one puts his trust in Christ. AT: "it is through the gospel that God powerfully saves those who put their trust in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for the Jew first and for the Greek

"for Jewish people and also for Greek people"

#### first

Here "first" means coming before all others in order of time.

#### For in it

Here "it" refers to the gospel. Paul explains why he completely trusts in the gospel.

#### God's righteousness is revealed from faith to faith

Paul speaks about the gospel message as if it were an object that God could physically show to people. You can translate this in an active form. AT: "God has told us that it is by faith from beginning to end that people become righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as it has been written

You can translate this in an active form. AT: "as someone has written in the Scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The righteous will live by faith

Here "righteous" refers to those who trust in God. AT: "It is people who trust in God that he considers right with him, and they will live forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Romans 01:18

#### Connecting Statement:

Paul reveals God's great anger against sinful man.

#### For the wrath of God is revealed

Paul explains why people need to hear the gospel. You can translate this in an active form. AT: "Because God reveals his anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### against

"toward"

#### all ungodliness and unrighteousness of people

"all the ungodly and unrighteous things that people do"

#### hold back the truth

Here "truth" refers to true information about God. AT: "hide the true information about God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### that which is known about God is visible to them

You can translate this in an active form. AT: "they can know about God because of what they can plainly see" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For God has enlightened them

Here "enlightened them" means God has shown them the truth about him. AT: "Because God has shown everyone what he is like" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Romans 01:20

#### For his invisible qualities ... have been clearly seen

Paul speaks of people understanding God's invisible qualities as if people have seen those qualities. This can be translated in active form. AT: "For people have clearly understood God's invisible qualities, namely his eternal power and divine nature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### divine nature

"all the qualities and characteristics of God" or "the things about God that make him God"

#### world

This refers to the heavens and the earth, as well as everything in them.

#### in the things that have been made

This can be translated in active form. AT: "because of the things that God has made" or "because people have seen the things that God has made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they are without excuse

"these people can never say that they did not know"

#### became foolish in their thoughts

You can translate this in an active form. AT: "began to think foolish things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### their senseless hearts were darkened

Here "darkness" is a metaphor that represents the people's lack of understanding. AT: "they became unable to understand what God wanted them to know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/divine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/divine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]

### Romans 01:22

#### They claimed to be wise, but they became foolish

"While they were claiming that they were wise, they became foolish"

#### They ... they

the people in [Romans 1:18](./18.md)

#### exchanged the glory of the imperishable God

"traded the truth that God is glorious and will never die" or "stopped believing that God is glorious and will never die"

#### for the likenesses of an image of

"and instead chose to worship idols that looked like"

#### perishable man

"some human being that will die"

#### of birds, of four-footed beasts, and of creeping things

"or that looked like birds, four-footed beasts, or creeping things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Romans 01:24

#### Therefore

"Because what I have just said is true"

#### God gave them over to

"God allowed them to indulge in"

#### them ... their ... themselves ... they

the "mankind" of [Romans 1:18](./18.md)

#### the lusts of their hearts for uncleanness

Here "lusts of their hearts" is a synecdoche that represents the evil things they wanted to do. AT: "the morally impure things they desired greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### for their bodies to be dishonored among themselves

This is a euphemism that means they committed immoral sexual acts. You can translate this in an active form. AT: "and they committed sexually immoral and degrading acts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who worshiped and served the creation

Here "creation" refers to what God created. AT: "They worshiped things that God created" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### instead of

"rather than"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Romans 01:26

#### this

"idolatry and sexual sin"

#### God gave them over to

"God allowed them to indulge in"

#### dishonorable passions

"shameful sexual desires"

#### for their women

"because their women"

#### exchanged natural relations for those that were unnatural

The idea of relations "that were unnatural" is a euphemism for immoral sexuality. AT: "started practicing sexuality in a way God did not design" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### men also left their natural relations with women

Here "natural relations" is a euphemism for sexual relationships. AT: "many men stopped having natural sexual desire for women" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### burned in their lust for one another

"experienced strong sexual desire for other men"

#### shameless

"disgraceful" or "sinful"

#### received in themselves the penalty they deserved for their perversion

Here "in themselves" refers to "in their bodies." You can translate this in an active form. AT: "God has punished them by sicknesses in their bodies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### perversion

behavior that is evil and disgusting

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]

### Romans 01:28

#### Because they did not approve of having God in their awareness

"They did not think it was necessary to know God"

#### they ... their ... them

These words refer to the "mankind" of [Romans 1:18](./18.md).

#### he gave them up to a depraved mind

Here "a depraved mind" means a mind that thinks only about immoral things. AT: "God allowed their minds, which they had filled with worthless and immoral thoughts, to completely control them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### not proper

"disgraceful" or "sinful"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Romans 01:29

#### They have been filled with

You can translate this in an active form. AT: "They have in them a strong desire for" or "They strongly desire to do deeds of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They are full of envy, murder, strife, deceit, and evil intentions

You can translate this in an active form. AT: "Many are constantly envying other people ... Many constantly desire to murder people ... to cause arguments and quarrels among people ... to deceive others ... to speak hatefully about others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### slanderers

A slanderer says false things about another person in order to damage that person's reputation.

#### They are inventors of evil things

"They try to think of new ways to do evil things to others"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gossip.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### Romans 01:32

#### They understand the regulations of God

"They know how God wants them to live"

#### that those who practice such things

Here "practice" refers to continually or habitually doing things that are evil. AT: "and that those who keep on doing wicked things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### are deserving of death

"deserve to die"

#### these things

"these kinds of evil things"

#### who do them

Here the verb "do" refers to continuing to do things that are evil. AT: "who keep on doing evil things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Romans 01:intro

#### Romans 01 General Notes ####

####### Structure and formatting #######

The first verse is a type of introduction and was typical of a letter in the ancient Mediterranean region. Sometimes this is called a "salutation." 

####### Special concepts in this chapter #######

######## The gospel ########
This chapter refers to the contents of the book of Romans as "the gospel" ([Romans 1:2](./01.md)). Romans is not a gospel like Matthew, Mark, Luke and John. Instead, chapters 1-8 are a presentation of the biblical gospel: Jesus died for the sins of mankind and was raised again as proof of eternal life for those who believe in him. 

######## Fruit ########
The imagery of fruit is used in this chapter. The image of fruit usually refers to a person's faith producing acts of righteousness in their life. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

== Universal Condemnation and the Wrath of God==
This chapter explains that the whole world is without excuse and has enough knowledge to seek after and believe in the true God, Yahweh. Because of man's sin and depravity, all of mankind is deserving of a punishment of death to appease the wrath of God. This wrath was satisfied by the death of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Important figures of speech in this chapter #######

######## "God gave them over" ########
Many scholars view the phrases "God gave them over" and "God gave them up" as theologically significant. For this reason, it is important to translate these phrases with God playing a passive role in the action. God simply allows men to pursue their own desires, he does not force them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

####### Other possible translation difficulties in this chapter #######

######## Difficult phrases and concepts ########

There are many abstract concepts in this chapter and Paul's personal style makes many of the phrases in this chapter difficult to translate. The translator may need to use the UDB to understand the meaning of the phrases, and it may be necessary to use more freedom in translating these phrases. The difficult phrases include: "obedience of faith," "whom I serve in my spirit," "from faith to faith" and "exchanged the glory of the imperishable God for the likenesses of an image of perishable man."

##### Links: #####

* __[Romans 01:01 Notes](./01.md)__
* __[Romans intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Romans 02

### Romans 02:01

#### Connecting Statement:

Paul has affirmed all men are sinners and continues to remind them that all people are wicked.

#### Therefore you are without excuse

The word "therefore" marks a new section of the letter. It also makes a concluding statement based on what Paul said in [Romans 1:1-32](../01/32.md). AT: "Since God will punish those who continually sin, he will certainly not excuse your sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you are

Paul is writing here as if he were addressing a Jewish person who is arguing with him. Paul is doing this to teach his audience that God will punish everyone who continually sins, whether Jew or Gentile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### you

Here the pronoun "you" is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### you person, you who judge

Paul uses the word "person" here to scold anyone who might think he can act like God and judge others. AT: "You are just a human being, yet you judge others and say they deserve God's punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for what you judge in another you condemn in yourself

"But you are only judging yourself because you do the same wicked deeds as they do"

#### But we know

Here the pronoun "we" may include Christian believers and also Jews who are not Christians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### God's judgment is according to truth when it falls on those

Here Paul speaks of "God's judgment" as if it were alive and could "fall" on people. AT: "God will judge those people truly and fairly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### those who practice such things

"the people who do those wicked deeds"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Romans 02:03

#### But consider this

"So consider this" or "Therefore, consider this"

#### consider this

"think about what I am going to tell you"

#### person

Use the general word for a human being "whoever you are"

#### you who judge those who practice such things although you do the same things

"you who say someone deserves God's punishment while you do the same wicked deeds"

#### Will you escape from the judgment of God?

This remark appears in the form of a question to add emphasis. You can also translate this question as a strong negative statement. AT: "You will certainly not escape God's judgment!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Or do you think so little of the riches of his goodness, his delayed punishment, and his patience ... repentance?

This remark appears in the form of a question to add emphasis. You can also translate this as a strong statement. AT: "You should not act like it does not matter that God is good and that he patiently waits a long time before he punishes people, so that his goodness will cause them to repent!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### think so little of the riches ... patience

"consider the riches ... patience unimportant" or "consider ... not good"

#### Do you not know that his goodness is meant to lead you to repentance?

This remark appears in the form of a question to add emphasis. You can also translate this as a strong statement. AT: "You must know that God shows you he is good so that you might repent!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]

### Romans 02:05

#### Connecting Statement:

Paul continues to remind the people that all people are wicked.

#### But it is to the extent of your hardness and unrepentant heart

Paul uses a metaphor to compare a person who refuses to obey God to something hard, like a stone. He also uses the metonym "heart" to represent the whole person. AT: "It is because you refuse to listen and repent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hardness and unrepentant heart

This is a doublet that you can combine as "unrepentant heart." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### you are storing up for yourself wrath

The phrase "storing up" implies a metaphor that usually refers to a person gathering his treasures and putting them in a safe place. Paul says, instead of treasures, that the person is gathering God's punishment. The longer they go without repenting, the more severe the punishment. AT: "you are making your punishment worse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### on the day of wrath ... the day of the revelation of God's righteous judgment

Both of these phrases refer to the same day. AT: "when God shows everyone that he is angry and that he judges all people fairly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### pay back

"give a fair reward or punishment"

#### to every person the same measure of his actions

"according to what each person has done"

#### have sought

This means that they act in a way that will lead to a positive decision from God on judgment day.

#### praise, honor, and incorruptibility

They want God to praise and honor them, and they want to never die.

#### incorruptibility

This refers to physical, not moral, decay.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Romans 02:08

#### Connecting Statement:

Though this section is speaking to the non-religious wicked person, Paul sums it up by stating both non-Jews and Jews are wicked before God.

#### self-seeking

"selfish" or "only concerned with what makes themselves happy"

#### disobey the truth but obey unrighteousness

These two phrases mean basically the same thing. The second intensifies the first. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### wrath and fierce anger will come

The words "wrath" and "fierce anger" mean basically the same thing and emphasize God's anger. AT: "God will show his terrible anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### wrath

Here the word "wrath" is a metonym that refers to God's severe punishment of wicked people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### tribulation and distress on

The words "tribulation" and "distress" mean basically the same thing here and emphasize how bad God's punishment will be. AT: "awful punishments will happen to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### on every human soul

Here, Paul uses the word "soul" as a synecdoche that refers to the whole person. AT: "upon every person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### has practiced evil

"has continually done evil things"

#### to the Jew first, and also to the Greek

"God will judge the Jewish people first, and then those who are not Jewish people"

#### first

Possible meanings are 1) "first in order of time" or 2) "most certainly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]

### Romans 02:10

#### But praise, honor, and peace will come

"But God will give praise, honor, and peace"

#### practices good

"continually does what is good"

#### to the Jew first, and also to the Greek

"God will reward the Jewish people first, and then those who are not Jewish people"

#### first

You should translate this the same way you did in [Romans 2:9](./08.md).

#### For there is no partiality with God

You can translate this in a positive form. AT: "For God treats all people the same" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### For as many as have sinned

"For those who have sinned"

#### without the law will also perish without the law

Paul repeats "without the law" to emphasize that it does not matter if people do not know the law of Moses. If they sin, God will judge them. AT: "without knowing the law of Moses will certainly still die spiritually" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### as many as have sinned

"all those who have sinned"

#### with respect to the law will be judged by the law

God will judge sinful people according to his law. You can translate this in an active form. AT: "and who do know the law of Moses, God will judge them according to that law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Romans 02:13

#### Connecting Statement:

Paul continues to let the reader know that perfect obedience to God's law is required even for those who never had God's law.

#### For

Verses 14 and 15 interrupt Paul's main argument to give the reader extra information. If you have a way to mark an interruption like this in your language, you can use it here.

#### it is not the hearers of the law

Here "the law" refers to the law of Moses. AT: "it is not those who only hear the law of Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who are righteous before God

"whom God considers righteous"

#### but it is the doers of the law

"but it is those who obey the law of Moses"

#### who will be justified

You can translate this in an active form. AT: "whom God will accept" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Gentiles, who do not have the law ... are a law to themselves

The phrase "law to themselves" is an idiom that means that these people naturally obey God's laws. AT: "have God's laws already inside them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they do not have the law

Here "the law" refers to the law of Moses." AT: "they do not actually have the laws that God gave to Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]

### Romans 02:15

#### By this they show

"By naturally obeying the law they show"

#### the actions required by the law are written in their hearts

You can translate this in an active form. "Hearts" here is a metonym for the entire person. AT: "what God requires them to do has clearly been shown to them, in their minds, soul and will" or "God has written on their hearts what the law requires them to do" or "God has shown them what the law requires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### bears witness to them, and their own thoughts either accuse or defend them to themselves

Here "bears witness" refers to the knowledge they gain from the law that God has written in their hearts. AT: "tells them if they are disobeying or obeying God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### on the day when God will judge

This finishes Paul's thought from [Romans 2:13](./13.md). "This will happen when God judges"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Romans 02:17

#### Connecting Statement:

Here begins Paul's discussion that the law the Jews possess actually condemns them because they do not obey it.

#### if you call yourself a Jew

"since you call yourself a Jew"

#### rest upon the law

The phrase "rest upon the law" represents believing that they can become righteous by obeying the law. AT: "rely on the law of Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### know his will

"and know God's will"

#### because you have been instructed from the law

This can be stated in active form. AT: "because people have taught you what is right from the law" or "because you have learned from the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that you yourself are a guide to the blind, a light to those who are in darkness

Here "the blind" and "those who walk in darkness" represent people who do not understand the law. AT: "that because you teach the law, you yourself are like a guide to blind people, and you are like a light to people who are lost in the dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a corrector of the foolish

"you correct those who do wrong"

#### a teacher of little children

Here Paul compares those who do not know anything about the law to very small children. AT: "and you teach those who do not know the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### and that you have in the law the form of knowledge and of the truth

The knowledge of the truth that is in the law comes from God. AT: "because you are sure you understand the truth that God has given in the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Romans 02:21

#### You who teach others, do you not teach yourself?

Paul is using a question to scold his listeners. You can translate this as a strong statement. AT: "You teach others, but you do not teach yourself!" or "You teach others, but you do not do what you teach!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You who preach against stealing, do you steal?

Paul is using a question to scold his listeners. You can translate this as a strong statement. AT: "You tell people not to steal, but you steal!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You who say that one must not commit adultery, do you commit adultery?

Paul is using a question to scold his listeners. You can translate this as a strong statement. AT: "You tell people not to commit adultery, but you commit adultery!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You who hate idols, do you rob temples?

Paul is using a question to scold his listener. You can translate this as a strong statement. AT: "You say you hate idols, but you rob temples!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### rob temples

Possible meanings are 1) "steal items from local pagan temples to sell and make a profit" or 2) "do not send to the Jerusalem temple all the money that is due to God."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### Romans 02:23

#### You who boast in the law, do you dishonor God by breaking the law?

Paul uses a question to scold his listener. You can translate this as a strong statement. AT: "It is wicked that you claim to be proud of the law, while at the same time you disobey it and bring shame to God!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the name of God is dishonored among the Gentiles

You can translate this in an active form. AT: "Your wicked actions bring shame to God in the minds of the Gentiles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### name of God

The word "name" is a metonym that refers to the entirety of God, not just his name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]

### Romans 02:25

#### Connecting Statement:

Paul continues to show that God, by his law, condemns even the Jews who have God's law.

#### For circumcision indeed benefits you

"I say all of this because being circumcised does benefit you"

#### if you break the law

"if you do not obey the commandments found in the law"

#### your circumcision becomes uncircumcision

"it is as though you were no longer circumcised"

#### the uncircumcised person

"the person who is not circumcised"

#### keeps the requirements of the law

"obeys what God commands in the law"

#### will not his uncircumcision be considered as circumcision? And will not the one who is naturally uncircumcised condemn you ... the law?

Paul asks two questions here to emphasize that circumcision is not what makes one right before God. You can translate these questions as statements in an active form. AT: "God will consider him as circumcised. The one who is not physically circumcised will condemn you ... the law." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]

### Romans 02:28

#### outwardly

This refers to Jewish rituals, such as circumcision, which people can see.

#### merely outward in the flesh

This refers to the physical change to a man's body when someone circumcises him.

#### flesh

This is a synecdoche for the whole body. AT: "body" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he is a Jew who is one inwardly, and circumcision is that of the heart

These two phrases have similar meanings. The first phrase, "he is a Jew who is one inwardly," explains the second phrase, "circumcision is that of the heart." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### inwardly

This refers to the values and motivations of the person whom God has transformed.

#### of the heart

Here "heart" is a metonym for the inner person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the Spirit, not in the letter

Here "letter" is a synecdoche that refers to written Scripture. AT: "through the work of the Holy Spirit, not because you know the Scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### in the Spirit

This refers to the internal, spiritual part of a person that "God's Spirit" changes .

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Romans 02:intro

#### Romans 02 General Notes ####

####### Structure and formatting #######

This chapter shifts its audience from Roman Christians to those who "judge" and do not believe in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]])

######## "Therefore you are without excuse" ########
This phrase looks back at chapter 1 and, in some ways, it is actually a conclusion to the argument of chapter 1. This phrase explains the reasons why everyone in the world is required to worship the true God. 

####### Special concepts in this chapter #######

######## "Doers of the Law" ########
It is not those who obey the law who will be justified by their obedience to it. It is those who earnestly try to follow the law of Moses who are justified by their faith which this demonstrates. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
These are frequently used in this chapter. It appears the intent of these rhetorical questions is to make the reader feel guilty or to convict them in their sin and ultimately bring them to faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## Hypothetical Situation ########
In light of the context, "He will give eternal life" is a hypothetical statement. If a person could live a perfect life, they would earn eternal life as a reward. Only Jesus was able to live a perfect life. There is another hypothetical situation in 2:17-29. This situation explains that even those who earnestly try to obey the law of Moses are guilty of violating the law. In English, this is about those who follow the "letter" of the law but cannot follow the "spirit" or general principles of the law. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

####### Other possible translation difficulties in this chapter #######

######## "You who judge" ########
At times, this could be translated in a simpler way, but it is translated in this relatively awkward way because Paul is referencing "people who judge" in such a way as to also say that everyone judges. It is possible to translate this as "those who judge (and everyone judges)."

##### Links: #####

* __[Romans 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Romans 03

### Romans 03:01

#### Connecting Statement:

Paul proclaims the advantage that Jews have because God gave them his law.

#### Then what advantage does the Jew have? And what is the benefit of circumcision?

Paul presents ideas that people might have after they hear what he wrote in chapter 2. He does this in order to respond to them in verse 2. AT: "Some people might say, 'Then what advantage does the Jew have? And what is the benefit of circumcision?'" or "Some people might say, 'If that is true, then the Jews do not have any advantage, and there is no benefit in being circumcised.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### It is great in every way

Paul now responds to the concerns brought up in verse 1. Here "It" refers to being a member of the Jewish people. AT: "But there is great advantage to being a Jew"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### First of all

Possible meanings are 1) "First in order of time" or 2) "Most certainly" or 3) "Most importantly."

#### the Jews were entrusted with revelation from God

Here "revelation" refers to God's words and promises. You can translate this in an active form. AT: "God gave his words that contain his promises to the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Romans 03:03

#### For what if some Jews were without faith? Will their unbelief abolish God's faithfulness?

Paul uses these questions to make people think. AT: "Some Jews have not been faithful to God. Should we conclude from this that God will not fulfill his promise?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### May it never be

This expression strongly denies that this could happen. You may have an expression in your language that you could use here. "That is not possible!" or "Certainly not!"

#### Instead, let

"We should say this instead, let"

#### let God be found to be true

God will always be true and will keep his promises. AT: "God always does what he has promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### even though every man is a liar

The words "every" and "liar" are exaggerations here to add emphasis that God alone is always true to his promises. AT: "even if every man were a liar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### As it has been written

You can translate this in an active form. AT: "The Scriptures themselves agree with what I am saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### That you might be shown to be righteous in your words, and that you might prevail when you come into judgment

These two phrases have very similar meanings. You can translate this in an active form. AT: "Everyone must acknowledge that what you say is true, and you will always win your case when anyone accuses you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Romans 03:05

#### But if our unrighteousness shows the righteousness of God, what can we say? Can we say that God is unrighteous to bring his wrath upon us?

Paul uses these questions to present what some people were arguing and to get his readers to think about whether or not this argument is true. AT: "Some people say that since our unrighteousness shows God's righteousness, then God is unrighteous when he punishes us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to bring his wrath upon us

Here "wrath" is a metonym for punishment. AT: "to bring his punishment upon us" or "to punish us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I am using a human argument

"I am saying here what some people say" or "This is what some people say"

#### May it never be

"We must never say that God is unrighteous"

#### For then how would God judge the world?

Paul uses this question to show that the arguments against the gospel are not valid, since the Jews believe that God will judge all people. AT: "We all know that God will in fact judge the world!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the world

The "world" is a metonym for the people who live in the world. AT: "anyone in the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Romans 03:07

#### But if the truth of God through my lie provides abundant praise for him, why am I still being judged as a sinner?

Here Paul imagines someone continuing to reject the Christian gospel. That adversary argues, because his sin shows the righteousness of God, then God should not declare that he is a sinner on judgment day if, for example, he tells lies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Why not say ... come"?

Here Paul raises a question of his own, to show how ridiculous the argument of his imaginary adversary is. AT: "I might as well be saying ... come!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### as we are falsely reported to say

"some lie to tell others that this is what we are saying"

#### The judgment on them is just

It will be only fair when God condemns these enemies of Paul, for telling lies about what Paul has been teaching.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]

### Romans 03:09

#### Connecting Statement:

Paul sums up that all are guilty of sin, none are righteous, and no one seeks God.

#### What then? Are we excusing ourselves?

Paul asks these questions to emphasize his point. AT: "We Jews should not try to imagine we are going to escape God's judgment, just because we are Jewish!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Not at all

These words are stronger than a simple "no," but not as strong as "absolutely not!"

#### This is as it is written

You can translate this in an active form. AT: "This is as the prophets have written in the Scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 03:11

#### There is no one who understands

There is no one who understands what is right. AT: "No one really understands what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### There is no one who seeks after God

Here the phrase "seeks after God" means to have a relationship with God. AT: "No one sincerely tries to have a right relationship with God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They have all turned away

This is an idiom that means the people do not even want to think about God. They want to avoid him. AT: "They have all turned away from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### They together have become useless

Since no one does what is good, they are useless to God. AT: "Everyone has become useless to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 03:13

#### Their ... Their

The word "their" refers to the "Jews and Greeks" of [Romans 3:9](./09.md).

#### Their throat is an open grave

The word "throat" is a metonym for everything that people say that is unrighteous and disgusting. Here "open grave" is a metaphor that refers to the stench of the evil words of the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Their tongues have deceived

The word "tongues" is a metonym for the false words that people speak. AT: "People speak lies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The poison of snakes is under their lips

Here "poison of snakes" is a metaphor that is used to represent the great harm of the evil words that the people speak. The word "lips" refers to the words of the people. AT: "Their evil words injure people just like the poison of a venomous snake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Their mouths are full of cursing and bitterness

Here "mouths" is a metonym that represents the evil words of the people. The word "full" exaggerates how often people speak bitterly and curse. AT: "They often speak curses and cruel words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Romans 03:15

#### Their ... their ... These people ... their

These words refer to the Jews and Greeks in [Romans 3:9](./09.md).

#### Their feet are swift to pour out blood

Here "feet" is a synecdoche that represents the people themselves. The word "blood" is a metaphor that refers to killing people. AT: "They are in a hurry to harm and murder people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Destruction and suffering are in their paths

Here "destruction and suffering" are metonyms that represent the harm that these people cause others to suffer. AT: "They try to destroy others and cause them to suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a way of peace

"how to live at peace with others." A "way" is a road or path.

#### There is no fear of God before their eyes

Here "fear" is a metonym that represents respect for God and willingness to honor him. AT: "Everyone refuses to give God the respect he deserves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Romans 03:19

#### whatever the law says, it speaks to

Paul speaks of the law here as if it were alive and had its own voice. AT: "everything that the law says people should do is for" or "all the commands that Moses wrote in the law are for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the ones who are under the law

"those who must obey the law"

#### in order that every mouth may be shut

Here "mouth" is a synecdoche that means the words people speak. You can translate this in an active form. AT: "so that no people will be able to say anything valid to defend themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the whole world held accountable to God

Here "world" is a synecdoche that represents all the people who live in the world. AT: "that God can declare everyone in the world guilty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### flesh

Here "flesh" refers to all human beings.

#### For

Possible meanings are 1) "Therefore" or 2) "This is because"

#### through the law comes the knowledge of sin

"when someone knows God's law, he realizes that he has sinned"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Romans 03:21

#### Connecting Statement:

The word "but" here shows Paul has completed his introduction and is now beginning to make his main point.

#### now

The word "now" refers to the time since Jesus came to the earth.

#### apart from the law the righteousness of God has been made known

You can translate this in an active form. AT: "God has made known a way to be right with him without obeying the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### It was witnessed by the Law and the Prophets

The words "the Law and the Prophets" refer to the parts of scripture that Moses and the prophets wrote in the Jewish scriptures. Paul describes them here as if they were people testifying in court. You can translate this in an active form. AT: "What Moses and the prophets wrote confirms this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the righteousness of God through faith in Jesus Christ

Here "righteousness" means being right with God. AT: "being right with God through trusting Jesus Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### For there is no distinction

Paul implies that God accepts all people in the same way. AT: "There is no difference at all between the Jews and the Gentiles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Romans 03:23

#### come short of the glory of God

Here the "glory of God" is a metonym that refers to the image of God and his nature. AT: "have failed to be like God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they are freely justified by his grace through the redemption that is in Christ Jesus

Here "justified" refers to being made right with God. You can translate this in an active form. AT: "God makes them right with himself as a free gift, because Christ Jesus sets them free" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they are freely justified

This means that they are justified without having to earn or merit being justified. God freely justifies them. AT: "they are made right with God without earning it" 

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Romans 03:25

#### in his blood

This is a metonym for the death of Jesus as a sacrifice for sins. AT: "in his death as a sacrifice for sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### disregard

Possible meanings are 1) ignoring or 2) forgiving.

#### This all happened for the demonstration of his righteousness at this present time

"He did this to show how God makes people right with himself"

#### This was so he could prove himself just, and to show that he justifies anyone because of faith in Jesus

"By this he shows that he is both just and the one who declares everyone righteous who has faith in Jesus"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/propitiation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/propitiation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]

### Romans 03:27

#### Where then is boasting? It is excluded

Paul asks this question to show that there is no reason for people to boast about obeying the law. AT: "So there is no way that we can boast that God favors us because we obeyed those laws. Boasting is excluded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### On what grounds? Of works? No, but on the grounds of faith

Paul asks and answers these rhetorical questions to emphasize that each point he is making is certainly true. You can translate this by including the words that Paul implies, and by using an active form. AT: "On what grounds should we exclude boasting? Should we exclude it because of our good works? No, rather, we should exclude it because of faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### without

"apart from" or "with no consideration for"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Romans 03:29

#### Or is God the God of Jews only?

Paul asks this question for emphasis. AT: "You who are Jews certainly should not think that you are the only ones whom God will accept!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is he not also the God of Gentiles? Yes, of Gentiles also

Paul asks this question to emphasize his point. AT: "He will also accept non-Jews, that is, Gentiles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### he will justify the circumcision by faith, and the uncircumcision through faith

Here "circumcision" is a metonym that refers to Jews and "uncircumcision" is a metonym that refers to non-Jews. AT: "God will make both Jews and non-Jews right with himself through their faith in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Romans 03:31

#### Connecting Statement:

Paul confirms the law though faith.

#### Do we then nullify the law through faith?

Paul asks a question that one of his readers might have. AT: "Someone might say that we can ignore the law because we have faith." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### May it never be

This expression gives the strongest possible negative answer to the preceding rhetorical question. You may have a similar express in your language that you could use here. AT: "This is certainly not true" or "Certainly not" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### we uphold the law

"we obey the law"

#### we

This pronoun refers to Paul, other believers, and the readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Romans 03:intro

#### Romans 03 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 3:4, 10-18, which is quoted from the OT.

Chapter 2 explained that all Jews are condemned because they violated the law of Moses and that Gentiles could be saved. Chapter 3 answers the question: what advantage does being a Jew have over being a Gentile? (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]])

####### Special concepts in this chapter #######

######## Universal Condemnation ########

This chapter explains that the whole world is without excuse and has enough knowledge to seek after and believe in the true God, Yahweh. Sin is a problem for all of mankind and enslaves the unbeliever in their sin. This refutes the common understanding that "all people are basically good." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

######## "For all have sinned and come short of the glory of God" ########
The standard required for entrance into heaven and being in the presence of God is perfection. Anything less than perfect leads to condemnation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]])

######## The purpose of the law of Moses ########
Obedience to the law cannot justify a person. The Law does not justify a person but is a way a person displays their faith in God. It has always been faith that justified a person. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
These are frequently used in this chapter. It appears the intent of these rhetorical question is to make the reader feel guilty, or to convict them in their sin and ultimately bring them to faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]])

##### Links: #####

* __[Romans 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Romans 04

### Romans 04:01

#### Connecting Statement:

Paul confirms that even in the past believers were made right with God by faith and not by the law.

#### What then will we say that Abraham, our forefather according to the flesh, found?

Paul uses the question to catch the attention of the reader and to start talking about something new. AT: "This is what Abraham our physical ancestor found" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### For what does the scripture say

Paul uses this question to add emphasis. He speaks of the Scriptures as if they were alive and could talk. AT: "For we can read in the scripture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### it was counted to him as righteousness

You can translate this in an active form. AT: "God considered Abraham as a righteous person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 04:04

#### what he is paid is not counted as a gift

This can be translated in active form. AT: "no one counts what the employer pays him as a gift from the employer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### but as what is owed

You can translate this in an active form. AT: "but as what his employer owes him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the one who justifies

"in God, who justifies"

#### his faith is counted as righteousness

You can translate this in an active form. AT: "God considers that person's faith as righteousness" or "God considers that person righteous because of his faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 04:06

#### David also pronounces blessing on the man to whom God counts righteousness without works

"David also wrote about how God blesses the man whom God makes righteous without works"

#### whose lawless deeds are forgiven ... whose sins are covered ... against whom the Lord will not count sin

The same concept is stated in three different ways. You can translate this in an active form. AT: "the Lord has forgiven those who have broken the law ... whose sins the Lord has covered ... whose sins the Lord will not count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Romans 04:09

#### Then is this blessing pronounced only on those of the circumcision, or also on those of the uncircumcision?

This remark appears in the form of a question to add emphasis. AT: "Does God bless only those who are circumcised, or also those who are not circumcised?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### those of the circumcision

This is a metonym that refers to the Jewish people. AT: "the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### those of the uncircumcision

This is a metonym that refers to the people who are not Jews. AT: "the Gentiles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Faith was counted to Abraham as righteousness

You can translate this in an active form. AT: "God considered the faith of Abraham as righteousness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### So how was it counted? When Abraham was in circumcision, or in uncircumcision?

Paul asks these questions to add emphasis to his remarks. AT: "When did God consider Abraham to be righteous? Was it before his circumcision, or after it?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### It was not in circumcision, but in uncircumcision

"It happened before he was circumcised, not after he was circumcised"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 04:11

#### a seal of the righteousness of the faith that he had already possessed when he was in uncircumcision

Here "righteousness of the faith" means that God considered him to be righteous. AT: "a visible sign that God considered him righteous because he had believed in God before he was circumcised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### even if they are in uncircumcision

"even if they are not circumcised"

#### This means that righteousness will be counted for them

You can translate this in an active form. AT: "This means that God will consider them righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Abraham became the father of the circumcision

Here "the circumcision" refers to those who are true believers in God, both Jews and Gentiles.

#### who follow in the steps of faith of our father Abraham

Here "follow in the steps of faith" is an idiom that means to follow someone's example of follow. AT: "who follow our father Abraham's example of faith" or "who have faith as our father Abraham did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Romans 04:13

#### heirs

The people to whom God has made promises are spoken of as if they were to inherit property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but through the righteousness of faith

The words "the promise came" are understood from the first phrase. You can translate this by adding these implied words. AT: "but the promise came through faith, which God considers as righteousness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### if those who live by the law are to be the heirs

Here "live by the law" refers to obeying the law. AT: "if those who obey the law are the ones who will inherit the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### faith is made empty, and the promise is void

"faith has no value, and the promise is meaningless"

#### there is no trespass

This can be restated to remove the abstract noun "trespass." AT: "no one can break the law" or "it is impossible to disobey the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]

### Romans 04:16

#### For this reason

"So"

#### it is by faith

The word "it" refers to receiving what God had promised. AT: "it is by faith that we receive the promise" or "we receive the promise by faith"

#### in order that the promise may rest on grace

Here "the promise may rest on grace" represents God giving what he promised because of his grace. AT: "so that what he promised might be a free gift" or "so that his promise would be because of his grace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### be guaranteed to all of Abraham's descendants

This can be stated in active form. AT: "all of Abraham's descendants might certainly receive what God has promised to give" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### those who are under the law

This refers to the Jewish people, who were obligated to obey the law of Moses.

#### those who share the faith of Abraham

This refers to those who have faith as Abraham did before he was circumcised. AT: "those who believe as Abraham did"

#### father of us all

Here the word "us" refers to Paul and includes all Jewish and non-Jewish believers in Christ. Abraham is the physical ancestor of the Jewish people, but he is also the spiritual father of those who have faith. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### as it is written

Where it is written can be made explicit. You can also translate this in an active form. AT: "as someone has written in the Scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I have made you

Here the word "you" is singular and refers to Abraham. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Abraham was in the presence of him whom he trusted, that is, God, who gives life to the dead

Here "of him whom he trusted" refers to God. AT: "Abraham was in the presence of God whom he trusted, who gives life to those who have died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### calls the things that do not exist into existence

"created everything from nothing"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Romans 04:18

#### In hope he believed against hope

This idiom means that Abraham trusted God even though it did not seem that he could have a son. AT: "Even though it seemed impossible for him to have descendants, he believe God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### according to what he had been told

You can translate this in an active form. AT: "just as God said to Abraham" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### So will your descendants be

The full promise God gave to Abraham can be made explicit. AT: "You will have more descendants than you can count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Without becoming weak in faith,

You can translate this in a positive form. AT: "He remained strong in his faith, although" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sarah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sarah.md)]]

### Romans 04:20

#### did not hesitate in unbelief

You can translate this double negative in a positive form. AT: "kept on acting in faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### he was strengthened in faith

You can translate this in an active form. AT: "he became stronger in his faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He was fully convinced

"Abraham was completely sure"

#### he was also able to accomplish

"God was able to do"

#### Therefore this was also counted to him as righteousness

You can translate this in an active form. AT: "Therefore God counted Abraham's belief as righteousness" or "Therefore God considered Abraham righteous because Abraham believed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 04:23

#### Now it was

"Now" is used here to connect Abraham's being made right by faith to present-day believer's being made right by faith in Christ's death and resurrection.

#### only for his benefit

"for Abraham only"

#### that it was counted for him

You can translate this in an active form. AT: "that God counted righteousness to him" or "God considered him righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for us

The word "us" refers to Paul and includes all believers in Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### It was written also for us, for whom it will be counted, we who believe

You can translate this in an active form. AT: "It was also for our benefit, because God will consider us righteous also if we believe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### him who raised Jesus our Lord from the dead

"Raised" here is an idiom for "caused to live again" AT: "him who caused Jesus our Lord to live again from the dead ones"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### This is the one who was delivered up for our trespasses

You can translate this in an active form. AT: "This is the one whom God brought to those who killed him, so he may pay the penalty for our sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### delivered

"brought"

#### was raised for our justification

You can translate this in an active form. AT: "whom God brought back to life so God could make us right with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]

### Romans 04:intro

#### Romans 04 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 4:7-8, which is quoted from the OT.

####### Special concepts in this chapter #######

######## The purpose of the law of Moses ########
Paul builds upon material from chapter 3 and explains how Abraham, the father of Israel, was justified. Obedience cannot justify a person, even the great Abraham. Obeying the law of Moses does not justify a person, it is a way a person displays their faith in God. It is faith which has always justified a person. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## Circumcision ########
Circumcision was important to the Israelites. It identified a person as a descendant of Abraham and was a sign of the covenant between Abraham and Yahweh. Paul explains that one of the reasons for circumcision was to display the Israelite's faith. The practice of circumcision itself was not able to justify anyone. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
These are frequently used in this chapter. It appears the intent of these rhetorical questions is to make the reader feel guilty, or to convict them of their sin and ultimately bring them to faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Romans 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Romans 05

### Romans 05:01

#### Connecting Statement:

Paul begins to tell many different things that happen when God makes believers right with him.

#### Since we are justified

"Because we are justified"

#### we ... our

All occurrences of "we" and "our" refer to all believers and should be inclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### through our Lord Jesus Christ

"because of our Lord Jesus Christ"

#### Lord

Here "Lord" means that Jesus is God.

#### Through him we also have our access by faith into this grace in which we stand

Here "by faith" refers to our trust in Jesus, which allows us to stand before God. AT: "Because we trust in Jesus, God allows us to come into his presence"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Romans 05:03

#### Not only this

The word "this" refers to the ideas described in [Romans 5:1-2](./01.md).

#### we ... our ... us

All occurrences of "we," "our," and "us" refer to all believers and should be inclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### certain hope

This is the certainty that God will fulfill all his promises for those who trust in Christ.

#### that hope does not disappoint

Paul uses personification here as he speaks of "confidence" as if it were alive. AT: "we are very confident that we will receive the things that we wait for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the love of God has been poured into our hearts

"Hearts" here is a metonym for the entire human experience. AT: "we have experienced the love of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Romans 05:06

#### we

The word "we" here refers to all believers and so should be inclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### For one will hardly die for a righteous man

"It is hard to find someone who is willing to die, even for a righteous man"

#### That is, perhaps someone would dare to die for a good person

"But you might find someone who is willing to die for such a good person"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 05:08

#### proves

You can translate this verb in past tense using "demonstrated" or "showed."

#### us ... we

All occurrences of "us" and "we" refer to all believers and should be inclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Much more, then, now that we are justified by his blood

Here "justified" means that God puts us in a right relationship with himself. You can translate this in an active form. AT: "How much more will God do for us now that he has made us right with himself because of the death of Jesus on the cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### blood

This is a metonym for the sacrificial death of Jesus on the cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### saved

This means that through Jesus' sacrificial death on the cross, God has forgiven us and rescued us from being punished in hell for our sin.

#### the wrath of God

Here "wrath" is a metonym that refers to God's punishment of those who have sinned against him. AT: "God's punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Romans 05:10

#### we were

All occurrences of "we" refer to all believers and should be inclusive. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### his Son ... his life

"God's Son ... the life of God's Son"

#### we were reconciled to God through the death of his Son

The death of the Son of the God has provided eternal forgiveness and made us friends with God, for all who believe in Jesus. You can translate this in an active form. AT: "God allowed us to have a peaceful relationship with him because his son died for us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### after having been reconciled

You can translate this in an active form. AT: "now that God has made us his friends again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Romans 05:12

#### Connecting Statement:

Paul explains why death happened even before God gave the law to Moses.

#### through one man sin entered ... death entered through sin

Paul describes sin as a dangerous thing that came into the world through the actions of "one man," Adam. This sin then became an opening through which death, pictured here as another dangerous thing, also came into the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### For until the law, sin was in the world

This means that the people sinned before God gave the law. AT: "People in the world sinned before God gave his law to Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but there is no accounting for sin when there is no law

This means that God did not charge the people with sinning before he gave the law. AT: "but God recorded no sin against the law before he gave the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]

### Romans 05:14

#### Nevertheless, death

"Even though what I have just said is true, death" or "There was no written law from the time of Adam to the time of Moses, but death." (See: [Romans 5:13](./12.md))

#### death ruled from Adam until Moses

Paul is speaking of death as if it were a king who ruled. AT: "people continued to die from the time of Adam until the time of Moses as a consequence of their sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### even over those who did not sin like Adam's disobedience

"even people whose sins were different from Adam's continue to die"

#### who is a pattern of him who was to come

Adam was a pattern of Christ, who appeared much later. He had much in common with him.

#### For if by the trespass of one the many died

Here "one" refers to Adam. AT: "For if by one man's sin, many died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### how much more did the grace of God and the gift by the grace of the one man, Jesus Christ, abound for the many

Here "grace" refers to God's free gift that he made available to everyone through Jesus Christ. AT: "even more through the man Jesus Christ, who died for us all, did God kindly offer us this gift of everlasting life, although we do not deserve it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/adam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/adam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]

### Romans 05:16

#### For the gift is not like the outcome of that one man's sin

Here "the gift" refers to God's freely erasing the record of our sins. AT: "The gift is not like the result of Adam's sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The judgment followed one trespass and brought condemnation, but the gift ... justification

Here Paul gives two reasons why "the gift is not like the result of Adam's sin." The "judgment of condemnation" implies that we all deserve God's punishment for our sins. AT: "Because on the one hand, God declared that all people deserve to be punished because of the sin of one man, but on the other hand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the gift followed many trespasses and brought justification

This refers to how God makes us right with him even when we do not deserve it. AT: "God's kind gift to put us right with himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### followed many trespasses

"after the sins of many"

#### trespass of the one

This refers to the sin of Adam.

#### death ruled

Here Paul speaks of "death" as a king who ruled. The "rule" of death causes everyone to die. AT: "everyone died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Romans 05:18

#### by one trespass

"through the one sin committed by Adam" or "because of Adam's sin"

#### condemnation came to all people

Here "condemnation" refers to God's punishment. AT: "all people deserve God's punishment for sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### one act

the sacrifice of Jesus Christ

#### justification and life for all people

Here "justification" refers to God's ability to make people right with him. AT: "God's offer to make all people right with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### one man's disobedience

the disobedience of Adam

#### the many were made sinners

You can translate this in an active form. AT: "many people sinned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the obedience of the one

the obedience of Jesus

#### will the many be made righteous

You can translate this in an active form. AT: "God will make many people right with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 05:20

#### the law came in

Here Paul speaks of the law as if it were a person. AT: "God gave his law to Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### abounded

"increased"

#### grace abounded even more

Here "grace" refers to God's undeserved blessings. AT: "God continued to act even more kindly toward them, in a way that they did not deserve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### as sin ruled in death

Here Paul speaks of "sin" as if it were a king that ruled. AT: "as sin resulted in death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### even so grace might rule through righteousness for everlasting life through Jesus Christ our Lord

Paul speaks of "grace" here as if it were a king that ruled. AT: "grace gave people everlasting life through the righteousness of Jesus Christ our Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so grace might rule through righteousness

Paul speaks of "grace" here as if it were a king that ruled. The word "righteousness" refers to God's ability to make people right with him. AT: "so God might give his free gift to people to make them right with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### our Lord

Paul includes himself, his readers, and all believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Romans 05:intro

#### Romans 05 General Notes ####

####### Structure and formatting #######

Many scholars view 5:12-17 as some of the most important, but difficult, verses in Scripture to understand. Some of their richness and meaning has undoubtedly been lost in their translation from the original Greek construction.

####### Special concepts in this chapter #######

######## Results of justification ########
A major aspect of this chapter involves Paul's explanation of the results of justification. These include: peace with God, access to God, confidence about our future destiny, an ability to rejoice in sufferings, eternal salvation and reconciliation with God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]])

######## "All sinned" ########
Scholars are divided over how this worked. Some believe that all of mankind was present in the "seed of Adam" and that, as Adam is the father of all mankind, all of mankind was present when Adam sinned. Others believe that Adam served as a representative head for mankind and when he sinned all of mankind "fell" as a result. Whether people today played an active or passive role in Adam's original sin is one difference between these views. Other passages will help one to come to a conclusion regarding this issue. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

######## The second Adam ########
Adam was the first man and the first "son" of God. He was a creation of God and brought sin and death into the world by eating the forbidden fruit. Paul describes Jesus as the "second Adam" in this chapter and the true son of God. He brings life and overcomes sin and death by his death on the cross. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]])

##### Links: #####

* __[Romans 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Romans 06

### Romans 06:01

#### Connecting Statement:

Under grace, Paul tells those who believe in Jesus to live a new life as though dead to sin and alive to God.

#### What then will we say? Should we continue in sin so that grace may abound?

Paul asks these rhetorical questions to get the attention of his readers. AT: "So, what should we say about all of this? We certainly should not keep on sinning so that God will give us more and more grace! (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### we say

The pronoun "we" refers to Paul, his readers, and other people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### We who died to sin, how can we still live in it?

Here "died to sin" means that those who follow Jesus are now like dead people who cannot be affected by sin. Paul uses this rhetorical question to add emphasis. AT: "We are now like dead people on whom sin has no effect! So we certainly should not keep on sinning!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Do you not know that as many as were baptized into Christ Jesus were baptized into his death?

Paul uses this question to add emphasis. AT: "Remember, when someone baptized us to show that we have a relationship with Christ, this also shows that we died with Christ on the cross! (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Romans 06:04

#### We were buried, then, with him through baptism into death

Here Paul speaks of a believer's baptism in water as if it were a death and burial. AT: "When someone baptized us, it is just like that person buried us with Christ in the tomb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### just as Christ was raised from the dead by the glory of the Father, so also we might walk in newness of life

This compares a believer's new spiritual life to Jesus coming back to life physically. The believer's new spiritual life enables that person to obey God. You can translate this in an active form. AT: "just as the Father brought Jesus back to life after he died, we might have new spiritual life and obey God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To be raised from among them speaks of becoming alive again.

#### become united with him in the likeness of his death ... be united with his resurrection

Paul compares our union with Christ to death. Those who are joined with Christ in death will share in his resurrection. You can translate this in an active form. AT: "died with him ... come back to life with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]

### Romans 06:06

#### our old man was crucified with him

The "old man" is a metaphor that refers to the person before he believes in Jesus. Paul describes our old sinful person as dying on the cross with Jesus when we believe in Jesus. You can translate this in an active form. AT: "our sinful person died on the cross with Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### old man

This means the person who once was, but who does not exist now.

#### the body of sin

This is a metonym that refers to the whole sinful person. AT: "our sinful nature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### might be destroyed

You can translate this in an active form. AT: "might die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### we should no longer be enslaved to sin

Paul compares the power sin has over a person to a master who controls a slave. A person without the Holy Spirit is not free to do what pleases God. You can translate this in an active form. AT: "our sinful nature will no longer force us to do what is wrong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He who has died is declared righteous with respect to sin

Here "righteous" refers to God's ability to make people right with him. You can translate this in an active form. AT: "When God declares a person right with him, that person is no longer controlled by sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 06:08

#### we have died with Christ

Here "died" refers to the fact that believers are no longer controlled by sin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### We know that Christ has been raised from the dead

You can translate this in an active form. AT: "We know God brought Christ back to life after he died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To be raised from among them is to become alive again.

#### Death no longer rules over him

Here "death" is described as a king or ruler that has power over people. AT: "He can never die again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Romans 06:10

#### For in regard to the death that he died to sin, he died once for all

The phrase "once for all" means to finish something completely. You can make this full meaning explicit in your translation. AT: "For when he died he broke the power of sin completely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### In the same way, you also must consider

"For this reason consider"

#### consider yourselves

"think of yourselves as" or "see yourselves as"

#### dead to sin

Just as one cannot force a corpse to do anything, sin has no power to force believers to dishonor God. AT: "as if you were dead to the power of sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### dead to sin, but alive to God

"dead to the power of sin, but living to honor God"

#### alive to God in Christ Jesus

"living to honor God through the power Christ Jesus gives you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Romans 06:12

#### Connecting Statement:

Paul reminds us that grace rules over us, not the law; we are not sin's slaves, but God's slaves.

#### do not let sin rule ... Do not allow sin to rule

Paul describes sin as a person's king or master. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### your mortal body

This phrase refers to the physical part of a person, which will die. AT: "you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### in order that you may obey its lusts

As master, "sin" wants the sinner to obey its commands to do evil things.

#### Do not present the parts of your body to sin, to be tools used for unrighteousness

The picture is of the sinner offering the "parts of his body" to his master or king. One's "body parts" are a synecdoche for the whole person. AT: "Do not offer yourselves to sin so that you do what is not right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### But present yourselves to God, as those who have been brought from death to life

Here "now living" refers to the believer's new spiritual life. AT: "But offer yourselves to God, because he has given you new spiritual life" or "But offer yourselves to God, as those who had died and are now alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### present the parts of your body to God as tools to be used for righteousness

Here "parts of your body" is a synecdoche that refers to the whole person. AT: "let God use you for what is pleasing to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Do not allow sin to rule over you

Paul speaks of "sin" here as if it were a king who rules over people. AT: "Do not let sinful desires control what you do" or "Do not allow yourselves to do the sinful things you want to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### For you are not under law

To be "under law" means to be subject to its limitations and weaknesses. You can make the full meaning explicit in your translation. AT: "For you are no longer bound to the law of Moses, which could not give you the power to stop sinning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but under grace

To be "under grace" means that God's free gift provides the power to keep from sinning. You can make the full meaning explicit in your translation. AT: "but you are bound to God's grace, which does give you the power to stop sinning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Romans 06:15

#### What then? Shall we sin because we are not under law, but under grace? May it never be

Paul is using a question to emphasize that living under grace is not a reason to sin. AT: "However, just because we are bound to grace instead of the law of Moses certainly does not mean we are allowed to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### May it never be

"We would never want that to happen!" or "May God help me not to do that!" This expression shows an extremely strong desire that this does not take place. You may have a similar expression in your language that you could use here. See how you translated it in [Romans 3:31](../03/31.md).

#### Do you not know that the one to whom you present yourselves as servants is the one to which you are obedient, the one you must obey?

Paul uses a question to scold anyone who may think God's grace is a reason to keep sinning. You can translate this as a strong statement. AT: "You should know that you are slaves to the master you choose to obey!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### This is true whether you are servants to sin which leads to death, or servants to obedience which leads to righteousness

Here, Paul describes "sin" and "obedience" as masters that a slave would serve. AT: "You are either a slave to sin, which results in spiritual death, or you are a slave to obedience, which results in doing the things that God wants you to do (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 06:17

#### But thanks be to God!

"But I thank God!"

#### For you were servants of sin

Here "sin" is described as a master that a slave would serve. Also, "sin" refers to the power that lives in us that makes us choose to do what is sinful. AT: "For you were slaves to the power of sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but you have obeyed from the heart

Here the word "heart" refers to having sincere or honest motives for doing something. AT: "but you truly obeyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the pattern of teaching that you were given

Here "pattern" refers to the way of living that leads to righteousness. The believers change their old way of living to match this new way of living that Christian leaders teach to them. You can translate this in an active form. AT: "the teaching that Christian leaders gave you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You have been made free from sin

You can translate this in an active form. AT: "Christ has freed you from the power of sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### free from sin

"Free from sin" here is an idiom meaning ability to live without sin hindering one's life. AT: "the ability to live without sin hindering one's life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### servants of righteousness

"you are now a servant for doing what is right"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 06:19

#### I speak like a man

"Here I am using examples from everyday life"

#### because of the weakness of your flesh

Often Paul uses the word "flesh" as the opposite of "spirit." AT: "because you do not fully understand spiritual things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### presented the parts of your body as slaves to uncleanness and to evil

Here, "body parts" refers to the whole person. AT: "offered yourselves as slaves to everything that is evil and not pleasing to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### present the parts of your body as slaves to righteousness for sanctification

Here "body parts" refers to the whole person. AT: "offer yourselves as slaves to what is right before God so that he might set you apart and give you the power to serve him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### you were free from righteousness.

"Free from righteousness" involves an idiom meaning they had the ability to do whatever they wanted (They were "free") because they had no thoughts about living a righteous life. AT: "you were able to live without thinking about righteousness.  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### At that time, what fruit then did you have of the things of which you are now ashamed?

"Fruit" here is a metaphor for "result" or "outcome." Paul is using a question to emphasize that sinning results in nothing good. AT: "Nothing good came from those things that now cause you shame" or "You gained nothing by doing those things that now cause you shame" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Romans 06:22

#### But now that you have been made free from sin and are enslaved to God

This can be stated in active form. AT: "But now that you have become free from sin and have become God's slaves" or "But now that God has freed you from sin and made you his slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]]) 

#### But now that you have been made free from sin

Being "free from sin" is a metaphor for being able not to sin. AT: "But now that God has made you able not to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### and are enslaved to God

Being "enslaved" to God is a metaphor for being able to serve and obey God. AT: "and God has made you able to serve him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you have your fruit for sanctification

Here "fruit" is a metaphor for "result" or "benefit." AT: "the benefit is your sanctification" or "the benefit is that you live in a holy way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The result is eternal life

"The result of all of this is that you will live forever with God"

#### For the wages of sin are death

The word "wages" refers to a payment given to someone for their work. "For if you serve sin, you will receive spiritual death as payment" or "For if you continue sinning, God will punish you with spiritual death"

#### but the gift of God is eternal life in Christ Jesus our Lord

"but God gives eternal life to those who belong to Christ Jesus our Lord"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Romans 06:intro

#### Romans 06 General Notes ####

####### Structure and formatting #######

This chapter begins by answering a possible or hypothetical objection to Paul's teaching in chapter 5. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]]) 

####### Special concepts in this chapter #######

######## Against the Law ########
This chapter refutes the teaching that Christians can live however they want after they have received salvation. Scholars call this teaching antinomianism or being "against the law" because people are attempting to live without any type of rules in their life. Paul recalls the great price Jesus paid for a Christian's salvation as motivation for godly living. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]])

######## Servants of sin ########
Before coming to faith in Jesus, people are servants or slaves of sin. After salvation, a Christian is freed from this bondage and is able to choose to serve Christ in their life. Paul explains that when a Christian chooses to sin, it is because the person has willingly chosen sin. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

######## Fruit ########
The imagery of fruit is used in this chapter. The image of fruit usually refers to faith producing acts of righteousness in a person's life. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
These are frequently used in this chapter. It appears the intent of these rhetorical questions is to make the reader feel guilty, or to convict them of their sin and ultimately bring them to faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Other possible translation difficulties in this chapter #######

######## Death ########
Death is used many different ways in this chapter. Physical death, spiritual death, the reign of sin in the heart of man and to put an end to something. Sin and death are supposed to contrast the new life provided by Christ and the new way a Christian is supposed to live after they receive salvation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]])

##### Links: #####

* __[Romans 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Romans 07

### Romans 07:01

#### Connecting Statement:

Paul explains how the law controls those who want to live under the law.

#### do you not know, brothers ... that the law controls a person for as long as he lives?

Paul asks this question to add emphasis. AT: "So you certainly know that people have to obey laws only while they are alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### brothers

Here this means fellow Christians, including both men and women.

#### the law controls a person for as long as he lives

Paul gives an example of this in [Romans 7:2-3](./02.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]

### Romans 07:02

#### the married woman is bound by law to the husband

Here "bound by law to the husband" is a metaphor for a woman being united to her husband according to the law of marriage. AT: "according to the law, the married woman is united to the husband" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the married woman

This refers to any woman who is married.

#### she will be called an adulteress

You can translate this in an active form. AT: "God will consider her an adulteress" or "people will call her an adulteress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### she is free from the law,

"Free" here is an idiom meaning the ability to live without being accused by the law of committing adultery. AT: "she is able to live without being accused of committing adultery."  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]

### Romans 07:04

#### Therefore, my brothers

This relates back to [Romans 7:1](./01.md).

#### brothers

Here this means fellow Christians, including both men and women.

#### you were also made dead to the law through the body of Christ

You can translate this in an active form. AT: "you also died to the law when through Christ you died on the cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to him who was raised from the dead

"Raised" here is an idiom for "caused to live again" AT: "to him who was caused to live again"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### we might produce fruit for God

Here "fruit" is a metaphor for actions that please God. AT: "we might be able to do things pleasing to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to bear fruit for death

Here "fruit" is a metaphor for a "result of one's actions" or "outcome of one's actions." AT: "which resulted in spiritual-death" or "the outcome of which was our own spiritual death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Romans 07:06

#### Connecting Statement:

Paul reminds us that God does not make us holy by the law.

#### we have been released from the law

You can translate this in an active form. AT: "God has released us from the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### we

This pronoun refers to Paul and the believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### to that by which we were held

This refers to the law. You can translate this in an active form. AT: "to the law which held us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the letter

This refers to the law of Moses. AT: "the law of Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Romans 07:07

#### What will we say then?

Paul is introducing a new topic. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### May it never be

"Of course that is not true!" This expression gives the strongest possible negative answer to the preceding rhetorical question. You may have a similar expression in your language that you could use here. See how you translated this in [Romans 9:14](../09/14.md).

#### I would never have known sin, if it were not through the law ... But sin took the opportunity ... brought about every lust

Paul is comparing sin to a person who can act. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### sin

"my desire to sin"

#### lust

This word includes both the desire to have what belongs to other people and wrong sexual desire.

#### without the law, sin is dead

"if there were no law, there would be no breaking of the law, so there would be no sin"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Romans 07:09

#### sin regained life

This can mean 1) "I realized that I was sinning" or 2) "I strongly desired to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The commandment that was to bring life turned out to be death for me

Paul speaks of God's condemnation as if it resulted primarily in physical death. AT: "God gave me the commandment so I would live, but it killed me instead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Romans 07:11

#### For sin took the opportunity through the commandment and deceived me. Through the commandment it killed me

As in [Romans 7:7-8](./07.md), Paul is describing sin as a person who can do 3 things: take the opportunity, deceive, and kill. AT: "Because I wanted to sin, I deceived myself into thinking that I could sin and obey the commandment at the same time, but God punished me for disobeying the commandment by separating me from him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### sin

"my desire to sin"

#### took the opportunity through the commandment

Paul is comparing sin to a person who can act. See how you translated this in [Romans 7:8](./07.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### it killed me

Paul speaks of God's condemnation on sinners as if it resulted primarily in physical death. AT: "it separated me from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### holy

Morally perfect, without sin

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 07:13

#### Connecting Statement:

Paul talks about the struggle inside his inner man between sin in his inner man and his mind with the law of God—between sin and good.

#### So

Paul is introducing a new topic.

#### did what is good become death to me?

Paul uses this question to add emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### what is good

This refers to God's law.

#### become death to me

"cause me to die"

#### May it never be

This expression gives the strongest possible negative answer to the preceding rhetorical question. You may have a similar expression in your language that you could use here. AT: "Of course that is not true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### sin ... brought about death in me

Paul is viewing sin as though it were a person who could act. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### brought about death in me

"separated me from God"

#### through the commandment

"because I disobeyed the commandment"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Romans 07:15

#### Connecting Statement:

Paul talks about the struggle inside his inner man between his flesh and the law of God—between sin and good.

#### For what I do, I do not really understand

"I am not sure why I do some of the things that I do"

#### For what I do

"because what I do"

#### what I want to do, I do not do

The words "I do not do" are an exaggeration to emphasize that Paul does not do what he wants to do as often as he would like or that he does what he does not want to do too often. AT: "I do not always do what I want to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### what I hate, I do

The words "I do," which implies that he always does what he hates to do, are an exaggeration to emphasize that Paul does what he does not want to do too often. AT: "the things that I know are not good are the things that I sometimes do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### But if I do

"However, if I do"

#### I agree with the law

"I know God's law is good"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 07:17

#### the sin that lives in me

Paul describes sin as a living being that has the power to influence him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### my flesh

Here "flesh" is a metonym for the sinful nature. AT: "my sinful nature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 07:19

#### the good

"the good deeds" or "the good actions"

#### evil

"evil deeds" or "evil actions"

#### rather sin that lives in me

Paul speaks of "sin" as if it were alive and living inside him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### that evil is actually present in me

Paul speaks of "evil" here as if it were alive and living inside him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]

### Romans 07:22

#### the inner man

This is the newly-revived spirit of a person who trusts in Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### But I see a different principle in my body parts. It fights against that new principle in my mind. It takes me captive

"I am able only to do what my old nature tells me to do, not to live the new way the Spirit shows me"

#### new principle

This is the new spiritually alive nature.

#### a different principle in my body parts

This is the old nature, the way people are when they are born.

#### the principle of sin that is in my body parts

"my sinful nature"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]

### Romans 07:24

#### Who will deliver me from this body of death?

Paul uses this question to express great emotion. If your language has a way of showing great emotion through an exclamation or a question, use it here. AT: "I want someone to set me free from the control of what my body desires!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### this body of death

This is a metaphor that means a body that will experience physical death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### But thanks be to God through Jesus Christ our Lord

This is the answer to the question in 7:24.

#### So then, I myself serve the law of God with my mind. However, with the flesh I serve the principle of sin

The mind and flesh are used here to show how they compare to serve either God's law or the principle of sin. With the mind or intellect one can choose to please and obey God and with the flesh or physical nature to serve sin. AT: "My mind chooses to please God, but my flesh chooses to obey sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Romans 07:intro

#### Romans 07 General Notes ####

####### Structure and formatting #######

######## "Or do you not know" ########
This phrase is used to mark the narrative and shifts the topic of the discussion. It connects this discussion with the previous teaching. 

####### Special concepts in this chapter #######

######## "We have been released from the law" ########
Paul explains that the law of Moses is no longer in effect. While this is true, the principles behind the law are a reflection of the character of God and are timeless. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Important figures of speech in this chapter #######

######## Marriage ########
Marriage is a common metaphor used in Scripture. Here it is used to describe the church's relationship to the law of Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## Flesh ########
This is a complex issue and it is possible that "flesh" is a metaphor for a person's sinful nature. It is not the physical part of man that is sinful and it appears Paul is teaching that while man remains alive ("in the flesh"), he will remain sinful regardless of his effort, but his new nature will be fighting against his old nature. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Romans 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Romans 08

### Romans 08:01

#### Connecting Statement:

Paul gives the answer to the struggle he has with sin and good.

#### There is therefore now no condemnation for those who are in Christ Jesus

Here "condemnation" refers to punishing people. AT: "God will not condemn and punish those who are joined to Christ Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### therefore

"for that reason" or "because what I have just told you is true"

#### the law of the Spirit of life in Christ Jesus

This refers to God's Spirit. AT: "God's Spirit in Christ Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####  has set you free from the law of sin and death.

"Free" here is an idiom meaning the ability to live without fear of the effects of their sin and ultimately, their death. AT: "has given you the ability to live without fear of being punished for your sins and of dying." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the law of sin and death

This refers to our sinful nature that forces us to sin.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Romans 08:03

#### For what the law was unable to do because it was weak through the flesh, God did

Here the law is described as a person who could not break the power of sin. AT: "For the law did not have the power to stop us from sinning, because the power of sin within us was too strong. But God did stop us from sinning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### through the flesh

"because of people's sinful nature"

#### He ... sent his own Son in the likeness of sinful flesh ... an offering for sin ... he condemned sin

The Son of God forever satisfied God's holy anger against our sin by giving his own body and human life as the eternal sacrifice for sin.

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### in the likeness of sinful flesh

"who looked like any other sinful human being"

#### to be an offering for sin

"so that he could die as a sacrifice for our sins"

#### he condemned sin in the flesh

"God broke the power of sin through the body of his Son"

#### the requirements of the law might be fulfilled in us

You can translate this in an active form. AT: "we might fulfill what the law requires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### we who walk not according to the flesh

"we who do not obey our sinful desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### but according to the Spirit

"but who obey the Holy Spirit"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Romans 08:06

#### Connecting Statement:

Paul continues to contrast the flesh with the Spirit we now have.

#### the mind set on the flesh ... the mind set on the Spirit

Here Paul speaks of both the "flesh" and the "spirit" as if they were living persons. AT: "the way sinful people think ... the way people who listen to the Holy Spirit think" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### death

Here this means the separation of a person from God.

#### Those who are in the flesh

This refers to people who do what their sinful nature tells them to do.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Romans 08:09

#### in the flesh

"acting according to your sinful natures." See how "the flesh" was translated in [Romans 8:5](./03.md).

#### in the Spirit

"acting according to the Holy Spirit"

#### Spirit ... God's Spirit ... Spirit of Christ

These all refer to the Holy Spirit.

#### if it is true that

This phrase does not mean Paul doubts that some of them have God's Spirit. Paul wants them to realize that they all have God's Spirit. AT: "since" or "because"

#### If Christ is in you

How Christ lives in a person could be made explicit. AT: "If Christ lives in you through the Holy Spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the body is dead with respect to sin

Possible meanings are 1) a person is spiritually dead to the power of sin or 2) the physical body will still die because of sin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the spirit is alive with respect to righteousness

Possible meanings are 1) a person is spiritually alive because God has given him power to do what is right or 2) God will bring the person back to life after he dies because God is righteous and gives believers eternal life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 08:11

#### If the Spirit ... lives in you

Paul assumes that the Holy Spirit lives in his readers. AT: "Since the Spirit ... lives in you"

#### of him who raised

"of God, who raised"

#### raised

"Raised" here is an idiom for "caused to live again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### mortal bodies

"physical bodies" or "bodies, which will die someday"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Romans 08:12

#### So then

"Because what I have just told you is true"

#### brothers

Here this means fellow Christians, including both men and women.

#### we are debtors

Paul is speaking of obedience as if it were paying back a debt. AT: "we need to obey" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but not to the flesh to live according to the flesh

Again Paul speaks of obedience as if it were paying back a debt. You can include the implied word "debtors." AT: "but we are not debtors to the flesh, and we do not have to obey our sinful desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For if you live according to the flesh

"Because if you live only to please your sinful desires"

#### you are about to die

"you will certainly be separated from God"

#### but if by the Spirit you put to death the body's actions

Paul speaks of the "old man," crucified with Christ, as the person who is responsible for his sinful desires. AT: "but if by the power of the Holy Spirit you stop obeying your sinful desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Romans 08:14

#### For as many as are led by the Spirit of God

You can translate this in an active form. AT: "For all the people whom the Spirit of God leads" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sons of God

Here this means all believers in Jesus and is often translated as "children of God."

#### by which we cry

"who causes us to cry out"

#### Abba, Father

"Abba" is "Father" in the Aramaic language. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonsofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonsofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Romans 08:16

#### heirs of God

Paul speaks of the Christian believers as if they will inherit property and wealth from a family member. AT: "we also will one day receive what God has promised us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### we are joint heirs with Christ

Paul speaks of the Christian believers as if they will inherit property and wealth from a family member. God will give to us what he gives to Christ. AT: "we will also receive what God has promised us and Christ together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that we may also be glorified with him

God will honor Christian believers when he honors Christ. You can translate this in an active form. AT: "that God may glorify us along with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Romans 08:18

#### Connecting Statement:

Paul reminds us as believers that our bodies will be changed at the redemption of our bodies in this section which ends in [Romans 8:25](./23.md).

#### For

This emphasizes "I consider." It does not mean "because."

#### I consider that ... are not worthy to be compared with

You can translate this in an active form. AT: "I cannot compare the sufferings of this present time with" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will be revealed

You can translate this in an active form. AT: "God will reveal" or "God will make known" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the eager expectation of the creation waits for

Paul describes everything that God created as a person who eagerly waits for something. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### for the revealing of the sons of God

You can translate this in an active form. AT: "for the time when God will reveal his children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sons of God

Here this means all believers in Jesus. You can also translate this as "children of God."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonsofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonsofgod.md)]]

### Romans 08:20

#### For the creation was subjected to futility

You can translate this in an active form. AT: "For God caused what he had created to be unable to achieve what he intended" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### not of its own will, but because of him who subjected it

Here Paul describes "creation" as a person who can desire. AT: "not because this is what the created things wanted, but because it is what God wanted" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### in the certain hope that the creation itself will be delivered

You can translate this in an active form. AT: "Because God knew that he would save creation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from slavery to decay

Paul speaks of the uselessness of all things affected by sin as if they were a dead body rotting away. He then speaks about all things experiencing this as if they were slaves to a master. AT: "from rotting and dying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### into the freedom of the glory of the children of God

"Freedom" here is an idiom for the ability to live as one wants. AT: "to be able to live beautifully as the children of God"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### For we know that the whole creation groans and labors in pain together even now

The creation is compared to a woman groaning while giving birth to a baby. AT: "For we know that everything that God created wants to be free and groans for it like a woman giving birth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md)]]

### Romans 08:23

#### who have the firstfruits of the Spirit

Paul compares believers' receiving the Holy Spirit to the firstfruits and vegetables of the season to grow. This emphasizes that the Holy Spirit is only the beginning of what God will give to believers. AT: who have the first of the gifts God gives to us, namely, the Holy Spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### waiting for our adoption, the redemption of our body

Here "our adoption" means when we become full members of God's family, as adopted children. The word "redemption" means when God saves us. AT: "waiting for when we are fully members of God's family and he saves our bodies from decay and death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For in this certain hope we were saved

You can translate this in an active form. AT: "For God saved us because we hoped in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Now hope that is seen is not hope. For who hopes for what he can see?

Paul uses a question to help his audience understand what "hope" is. AT: "But if we are confidently waiting, that means we do not yet have what we want. No one can confidently wait if he already has what he wants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Romans 08:26

#### Connecting Statement:

Though Paul has been emphasizing that there is a struggle in believers between the flesh and the Spirit, he affirms that the Spirit is aiding us.

#### inexpressible groans

"groanings that we cannot express in words"

#### He who searches the hearts

This refers to God. "Searches the hearts" is a meonym for  "examines our thoughts and feelings." AT: "God, who knows all our thoughts and feelings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/intercede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/intercede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Romans 08:28

#### Connecting Statement:

Paul reminds the believers that nothing can separate them from God's love.

#### for those who are called

You can translate this in an active form. AT: "for those whom God chose" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### those whom he foreknew

"those whom he knew before he even created them"

#### he also predestined

"he also made it their destiny" or "he also planned in advance"

#### to be conformed to the image of his Son

God planned from before the beginning of creation to grow those who believe in Jesus, the Son of God, into persons who are like Jesus. You can translate this in an active form. AT: "that he would change them to be like his Son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### that he might be the firstborn

"so that his Son would be the firstborn"

#### among many brothers

Here "brothers" refers to all believers, both male and female. AT: "among many brothers and sisters who belong to the family of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Those whom he predestined

"Those whom God made plans for in advance"

#### these he also justified

Here "justified" is in the past tense to emphasize that this will certainly happen. AT: "these he also put right with himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### these he also glorified

The word "glorified" is in the past tense to emphasize that this will certainly happen. AT: "these he will also glorify" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreordain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreordain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Romans 08:31

#### What then shall we say about these things? If God is for us, who is against us?

Paul uses questions to emphasize the main point of what he said previously. AT: "This is what we should know from all of this: since God is helping us, no one can defeat us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### He who did not spare his own Son

God the Father sent the Son of God, Jesus Christ, to the cross as the holy, infinite sacrifice necessary to satisfy God's infinite, holy nature against the sin of humanity. Here "Son" is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### but delivered him up

"Delivered" here is a metaphor for "brought and gave over to." AT: "but gave him over to his enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### how will he not also with him freely give us all things?

Paul is using a question for emphasis. AT: "he will certainly and freely give us all things!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### freely give us all things

"kindly give us all things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]

### Romans 08:33

#### Who will bring any accusation against God's chosen ones? God is the one who justifies

Paul uses a question for emphasis. AT: "No one can accuse us before God because he is the one who makes us right with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Who is the one who condemns?

Paul uses a question for emphasis. He does not expect an answer. AT: "No one will condemn us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### more than that, who was raised

You can translate this in an active form. AT: "whom even more importantly God raised from the dead" or "who even more importantly came back to life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who is at the right hand of God

To be at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "who is at the place of honor beside God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/intercede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/intercede.md)]]

### Romans 08:35

#### Who will separate us from the love of Christ?

Paul uses this question to teach that nothing can separate us from the love of Christ. AT: "No one will ever separate us from the love of Christ!" or "Nothing will ever separate us from the love of Christ!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Tribulation, or distress, or persecution, or hunger, or nakedness, or danger, or sword?

The words "shall separate us from the love of Christ" are understood from the previous question.  AT: "Shall tribulation, or distress, or persecution, or hunger, or nakedness, or danger, or sword separate us from the love of Christ?"(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Tribulation, or distress, or persecution, or hunger, or nakedness, or danger, or sword?

Paul uses this question to emphasize that even these things cannot separate us from the love of Christ. AT: "Even tribulation, distress, persecution, hunger, nakedness, danger, and sword cannot separate us from the love of Christ." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Tribulation, or distress, or persecution, or hunger, or nakedness, or danger, or sword?

The abstract nouns can be expressed with verb phrases. Here "sword" is a metonym that represents being killed violently. AT: "Even if people cause us trouble, hurt us, take away our clothes and food, or kill us, they cannot separate us from the love of Christ." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Tribulation, or distress

These words both mean the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### For your benefit

Here "your" is singular and refers to God. AT: "For you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### we are killed all day long

Here "we" refers to the one who wrote this part of Scripture, but not his audience, who was God. The phrase "all day long" is an exaggeration to emphasize how much danger they are in. Paul uses this part of Scripture to show that all who belong to God should expect difficult times. This can be translated in an active form. AT: "our enemies continually seek to kill us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### We were considered as sheep for the slaughter

Here Paul compares to livestock those whom people kill because they are loyal to God. You can translate this in an active form. AT: "Our lives have no more value to them than the sheep they kill" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Romans 08:37

#### we are more than conquerors

"we have complete victory"

#### through the one who loved us

You can make explicit the kind of love that Jesus showed. AT: "because of Jesus, who loved us so much he was willing to die for us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I have been convinced

"I am convinced" or "I am confident"

#### governments

Possible meanings are 1) demons or 2) human kings and rulers.

#### nor powers

Possible meanings are 1) spiritual beings with power or 2) human beings with power.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Romans 08:intro

#### Romans 08 General Notes ####

####### Structure and formatting #######

The first verse of this chapter forms a transitional sentence. It concludes the teaching of chapter 7 and anticipates the material of chapter 8.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 8:36. All of these lines are quoted from the OT.

####### Special concepts in this chapter #######

######## Indwelling of the Spirit ########
The Holy Spirit is said to live inside a person or inside their heart. The presence of the Spirit is a sign of a person's salvation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]) 

######## "These are sons of God" ########
While Jesus is the Son of God in a unique way, Christians are also said to be children of God by adoption. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]])

####### Important figures of speech in this chapter #######

######## Metaphor ########
Verses 38 and 39 form an extended metaphor producing a poetic presentation of Paul's teaching. Its explains that nothing can separate a person from the love of God in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## On the one hand ... on the other hand ########
These phrases are used to speak of two things simultaneously. These two things are usually contrasted with each other, but it is not necessary that they contrast.

####### Other possible translation difficulties in this chapter #######

######## No condemnation ########
This phrase must be translated careful to avoid doctrinal confusion. People are still guilty of their sin and God disapproves of their actions, even after they come to faith in Jesus. Their sins are still punished but the punishment for sin has been paid and this is what Paul expresses here. There are several possible meanings to the word "condemn." Here "condemn" emphasizes that people who believe in Jesus are are no longer punished eternally for their sin by being "condemned to hell." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]])

######## Flesh ########

This is a complex issue and it is possible that "flesh" is a metaphor for a person's sinful nature. It is not the physical part of man that is sinful and it appears that Paul is teaching that while man remains alive ("in the flesh"), he will remain sinful regardless of his effort. His new nature will fight against his old nature. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]])

##### Links: #####

* __[Romans 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Romans 09

### Romans 09:01

#### Connecting Statement:

Paul tells of his personal desire that the people of the nation of Israel will be saved. Then he emphasizes the different ways in which God has prepared them to believe.

#### I tell the truth in Christ. I do not lie

These two expressions mean basically the same thing. Paul uses them to emphasize that he is telling the truth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### my conscience bears witness with me in the Holy Spirit

"the Holy Spirit controls my conscience and confirms what I say"

#### that for me there is great sorrow and unceasing pain in my heart

Here "unceasing pain in my heart" is an idiom that Paul uses to share his emotional distress. AT: "I tell you that I grieve very greatly and deeply" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### great sorrow and unceasing pain

These two expressions mean basically the same thing. Paul uses them together to emphasize how great his emotions are. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Romans 09:03

#### For I could wish that I myself would be cursed and set apart from Christ for the sake of my brothers, those of my own race according to the flesh

You can translate this in an active form. AT: "I personally would be willing to let God curse me and, keep me apart from Christ forever if that would help my fellow Israelites, my own people group, to believe in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### brothers

Here this means fellow Christians, including both men and women.

#### They are Israelites

"They, like me, are Israelites. God chose them to be Jacob's descendants"

#### They have adoption

Here Paul uses the metaphor of "adoption" to indicate that the Israelites are like God's children. AT: "They have God as their father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Theirs are the ancestors from whom Christ has come with respect to the flesh

Here "Christ has come with respect to the flesh" means that Christ is a physical descendant of the Israelite ancestors. AT: "Christ has come physically as a descendant from their ancestors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Romans 09:06

#### Connecting Statement:

Paul emphasizes that those who are born in the family of Israel can really only be a true part of Israel through faith.

#### But it is not as though the promises of God have failed

"But God has not failed to keep his promises" or "God has kept his promises"

#### For it is not everyone in Israel who truly belongs to Israel

God did not make his promises to all the physical descendants of Israel (or Jacob), but to his spiritual descendants, that is, those who trust in Jesus.

#### Neither are all Abraham's descendants truly his children

"Nor are they all children of God just because they are Abraham's descendants"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]

### Romans 09:08

#### the children of the flesh are not

Here "children of the flesh" is a metonym that refers to the physical descendants of Abraham. AT: "not all of Abraham's descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### children of God

This is a metaphor that refers to people who are spiritual descendants, those who have faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### children of the promise

This refers to people who will inherit the promises that God gave to Abraham.

#### this is the word of promise

"Word" here is a metonym for "message." AT: "this is the message about God's promises" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a son will be given to Sarah

You can translate this in an active form to express that God will give a son to Sarah. AT: "I will give Sarah a son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sarah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sarah.md)]]

### Romans 09:10

#### our father Isaac ... It is just

In your culture you may need to place 9:11 after 9:12 to make them easier to understand. AT: "our father Isaac, it was said to her, 'The older will serve the younger.' Now the children were not yet born ... because of him who calls. It is just"

#### our father

Paul refers to Isaac as "our father" because Isaac was the ancestor of Paul and of the Jewish believers in Rome. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### conceived

"became pregnant"

#### for the children were not yet born and had not yet done anything good or bad

"before the children were born and before they had done anything, whether good or bad"

#### so that the purpose of God according to choice might stand

"so that what God wants to happen according to His choice will happen"

#### for the children were not yet born

"before the children were born"

#### had not yet done anything good or bad

"not because of anything they had done"

#### because of him

because of God

#### it was said to her, "The older will serve the younger."

"God said to Rebecca, 'The older son will serve the younger son'"

#### Jacob I loved, but Esau I hated

The word "hated" is an exaggeration. God loved Jacob much more than he loved Esau. He did not literally hate Esau. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rebekah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rebekah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]

### Romans 09:14

#### What then will we say?

Paul is using the question to get the attention of his readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### May it never be

"That is not possible!" or "Certainly not!" This expression strongly denies that this could happen. You may have a similar expression in your language that you could use here.

#### For he says to Moses

Paul speaks about God's talking with Moses as if it is being done in the present time. AT: "For God said to Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it is not because of him who wills, nor because of him who runs

"it is not because of what people want or because they try hard"

#### nor because of him who runs

Paul speaks of a person who does good things in order to gain God's favor as if that person were running a race. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]

### Romans 09:17

#### For the scripture says

Here the scripture is personified as if God were talking to Pharaoh. AT: "The scripture records that God said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### I ... my

God is referring to himself.

#### you

singular (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### I raised you up

"Raised" here is an idiom for "established." AT: "I established you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### so that my name might be proclaimed in all the earth

You can translate this in an active form. AT: "that people might proclaim my name in all the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### my name

This metonym refers to God in all of his being. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### whom he wishes, he makes stubborn

God makes stubborn whoever he wishes to make stubborn.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]

### Romans 09:19

#### You will say then to me

Paul is talking to the critics of his teaching as though he were only talking to one person. You may need to use the plural here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Why does he still find fault? For who has ever withstood his will?

These are rhetorical questions that Paul uses to add emphasis. You can translate all of these questions as strong statements. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### he ... his

The words "he" and "his" here refer to God.

#### Will what has been molded say ... daily use?

Paul uses the potter's right to make any kind of container he wants from the clay as a metaphor for the creator's right to do whatever he wants with his creation. Paul asks these questions to emphasize his point. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Why did you make me this way?

The word "you" here refers to God. Paul uses this question to add emphasis. You can translate it as a strong statement. AT: "God, you should not have made me this way!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Romans 09:22

#### he ... his

The words "he" and "his" here refer to God.

#### containers of wrath ... containers of mercy

Paul speaks of people as if they were containers. AT: "people who deserve wrath ... people who deserve mercy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the riches of his glory upon

Paul compares God's wonderful actions here to great "riches." AT: "his glory, which is of great value, upon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### which he had previously prepared for glory

Here "glory" refers to life in heaven with God. AT: "whom he prepared ahead of time in order that they might live with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### also for us

The word "us" here refers to Paul and fellow believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### called

Here "called" means God has appointed or chosen people to be his children, to be his servants and proclaimers of his message of salvation through Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]

### Romans 09:25

#### Connecting Statement:

In this section Paul explains how Israel's unbelief as a nation was told ahead of time by the prophet Hosea.

#### As he says also in Hosea

Here "he" refers to God. AT: "As God says also in the book that Hosea wrote" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Hosea

Hosea was a prophet. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I will call my people who were not my people

"I will choose for my people those who were not my people"

#### her beloved who was not beloved

Here "her" refers to Hosea's wife, Gomer, who represents the nation of Israel. You can translate this in an active form. AT: "I will choose her whom I did not love to be one whom I love" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sons of the living God

The word "living" may refer to the fact that God is the only true God, and not like the false idols. AT: "children of the true God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonsofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonsofgod.md)]]

### Romans 09:27

#### cries out

"calls out"

#### as the sand of the sea

Here Paul compares the number of the people of Israel to the number of grains of sand in the sea. AT: "too many to count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### will be saved

Paul uses the word "saved" in a spiritual sense. If God saves a person, it means that through believing in Jesus' death on the cross, God has forgiven him and rescued him from being punished for his sin. You can translate this in an active form. AT: "God will save" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Lord will carry out his sentence on the earth

Here "sentence" refers to how he has decided to punish people. AT: "the Lord will punish people on the earth according to how he has said"

#### us ... we

Here the words "us" and "we" refer to Isaiah and those to whom he spoke. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### we would be like Sodom, and we would have become like Gomorrah

God killed all of the people of Sodom and Gomorrah because of their sin.  AT: "we all would have been destroyed like the people of Sodom and Gomorrah" or "God would have destroyed all of us, like he destroyed the cities of Sodom and Gommorah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gomorrah.md)]]

### Romans 09:30

#### What will we say then?

Paul uses this question to get the attention of his readers. AT: "This is what we must say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### That the Gentiles

"We will say that the Gentiles"

#### who were not pursuing righteousness

"who were not trying to please God"

#### the righteousness by faith

Here "by faith" refers to placing one's trust in Christ. You can make this explicit in your translation. AT: "because God made them right with him when they trusted in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### did not arrive at it

This means that the Israelites could not please God by trying to keep the law. You can make this explicit in your translation. AT: "were not able to please God by keeping the law because they could not keep it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Romans 09:32

#### Why not?

This is an ellipsis. You can include the implied words in your translation. Paul asks this question to get the attention of his readers. AT: "Why could they not attain righteousness?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### by works

This refers to things that people do to try to please God. You can make this explicit in your translation. AT: "by trying to do things that would please God" or "by keeping the Law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### as it has been written

You can indicate that Isaiah wrote this. You can also translate it in an active form. AT: "as Isaiah the prophet wrote" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in Zion

Here Zion is a metonym that represents Israel. AT: "in Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### stone of stumbling and a rock of offense

Both of these phrases mean basically the same thing and are metaphors that refer to Jesus and his death on the cross. It was as if the people stumbled over a stone because they were disgusted when they considered Jesus' death on the cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### believes in it

Because the stone stands for a person, you may need to translate "believes in him."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Romans 09:intro

#### Romans 09 General Notes ####

####### Structure and formatting #######

This chapter marks a noticeable shift in Paul's argument. His focus in chapters 9-11 is on the nation of Israel.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 9:25-29, 33. All of these lines are quoted from the OT.

####### Special concepts in this chapter #######

######## Flesh ########
Flesh is used in this chapter to exclusively refer to people who are physically related to Paul. This would make them Israelites. There is a differences here between Paul's use of "brother" as both a physical relationship (with fellow Israelites) and a spiritual relationship (with fellow Christians). The term "children of God" is also related to this teaching. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]])

######## Predestination ########
Many scholars believe this chapter gives an extensive teaching on a subject known as "predestination." This is related to the biblical concept of "to predestine," but some take this to indicate that God has chosen some to be eternally saved from before the foundation of the world. Since this is a source of theological diversity, extra care should be taken in translation, especially with regards to elements of causation in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/predestine.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]])

######## Important figures of speech in this chapter ########

######## Stone of Stumbling ########
Paul explains that while the Gentiles accepted Jesus as their savior by faith, the Jews desired to earn their salvation and rejected Jesus. Jesus is described as a stone one stumbles over when walking. This "stone of stumbling" causes them to "fall." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## "It is not everyone in Israel who truly belongs to Israel" ########
Some scholars believe this refers to the physical descendants of Abraham who do not follow the spiritual path of Abraham. Others believe it means that the "true" Israel is now known as the church. This would indicate that the Israelites in some sense should no longer be known as Israelites (at least spiritually). It is necessary to say that at least one of the usages of Israel in this phrase is a spiritual Israel. Context favors the former understanding because ethnic Israel still has a future in this chapter. This is reflected in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]])

##### Links: #####

* __[Romans 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Romans 10

### Romans 10:01

#### Connecting Statement:

Paul continues stating his desire for Israel to believe but emphasizes that both those who are Jews as well as everyone else can only be saved by faith in Jesus.

#### Brothers

Here this means fellow Christians, including both men and women.

#### my heart's desire

"Heart's" here is a metonym for his entire self. AT: "my greatest desire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### is for them, for their salvation

"is that God will save the Jews"

#### I testify about them

"I declare truthfully about them"

#### For they do not know of God's righteousness

Here "righteousness refers to the way God puts people right with himself. You can make this explicit in the translation. AT: "For they do not know how God puts people right with himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They did not submit to the righteousness of God

"They did not accept God's way of putting people right with himself"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Romans 10:04

#### For Christ is the fulfillment of the law

"For Christ completely fulfilled the law"

#### for righteousness for everyone who believes

Here "believes" means "trusts." AT: "in order that he may make everyone who trusts in him right before God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the righteousness that comes from the law

Paul speaks of "righteousness" as if it were alive and able to move. AT: "how the law makes a person right before God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The man who does the righteousness of the law will live by this righteousness

In order to be made right with God through the law, a person would have to keep the law perfectly, which is not possible. AT: "The person who perfectly obeys the law will live because the law will make him right before God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### will live

The words "will live" can refer to 1) eternal life or 2) mortal life in fellowship with God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Romans 10:06

#### But the righteousness that comes from faith says this

Here "righteousness" is described as a person who can speak. AT: "But Moses writes this about how faith makes a person right before God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Do not say in your heart

Moses was addressing the people as if he were speaking to only one person. AT: "Do not say to yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Who will ascend into heaven?

Moses uses a question to teach his audience. His previous instruction of, "Do not say" requires a negative answer to this question. You can translate this question as a statement. AT: "No one is able to go up to heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### that is, to bring Christ down

"in order that they might have Christ come down to earth"

#### Who will descend into the abyss

Moses uses a question to teach his audience. His previous instruction of, "Do not say" requires a negative answer to this question. You can translate this as a statement. AT: "No person can go down and enter the place where the spirits of dead persons are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To be brought up from among them is to become alive again.

#### dead

This word speaks of physical death.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/abyss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/abyss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Romans 10:08

#### But what does it say?

The word "it" refers to "the righteousness" of [Romans 10:6](./06.md). Here Paul describes "righteousness" as a person who can speak. Paul uses a question to emphasize the answer he is about to give. AT: "But this is what Moses says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The word is near you

Paul speaks of God's "message" as if it were a person who can move. AT: "The message is right here" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### in your mouth

The word "mouth" is a synecdoche that refers to what a person says. AT: "it is in what you say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### in your heart

The phrase "in your heart" is an idiom that refers to what a person thinks and believes. AT: "it is in what you think and believe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the word of faith

"Word" here is a metonym for "message." AT: "the message of faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### if with your mouth you acknowledge Jesus as Lord

"if you confess that Jesus is Lord"

#### believe in your heart

"Heart" here is a metonym for one's entire self. AT: "live in obedience to the idea"

#### raised him from the dead

"Raised" here is an idiom for "caused to live again" AT: "caused him to live again"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you will be saved

You can translate this in an active form. AT: "God will save you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For with the heart man believes for righteousness, and with the mouth he acknowledges for salvation

Here "heart" is a metonym that represents the mind or will. AT: "For it is with the mind that a person trusts and is right before God, and it is with the mouth that a person confesses and God saves him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with the mouth

Here "mouth" is a synecdoche that represents a person's capacity to speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Romans 10:11

#### For scripture says

Paul speaks of the Scripture as if it were alive and had a voice. You can make explicit who wrote the Scripture that Paul uses here. AT: "For Isaiah wrote in the Scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Everyone who believes on him will not be put to shame

This is equivalent to: "Everyone who does not believe will be shamed." The negative is used here for emphasis. You can translate this in an active form. AT: "God will honor everyone who believes in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For there is no difference between Jew and Greek

Paul implies that God will treat all people the same. You can make this explicit in your translation. AT: "In this way, God treats the Jews and the non-Jews the same" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he is rich to all who call upon him

Here "he is rich" means that God blesses richly. You can make this explicit in your translation. AT: "he richly blesses all who trust in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### For everyone who calls on the name of the Lord will be saved

Here the word "name" is a metonym for Jesus. You can translate this in an active form. AT: "The Lord will save everyone who trusts in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Romans 10:14

#### How then can they call on him in whom they have not believed?

Paul uses a question to emphasize the importance of taking the good news of Christ to those who have not heard. The word "they" refers to those who do not yet belong to God. AT: "Those who do not believe in God cannot call on him!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### How can they believe in him of whom they have not heard?

Paul uses another question for the same reason. AT: "And they cannot believe in him if they have not heard his message!" or "And they cannot believe in him if they have not heard the message about him!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### believe in

Here this means to acknowledge that what that person has said is true.

#### How can they hear without a preacher?

Paul uses another question for the same reason. AT: "And they cannot hear the message if someone does not tell them!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Then how can they preach, unless they are sent?

Paul uses another question for the same reason. The word "they" refers to those who belong to God. AT: "Then they cannot tell other people the message unless someone sends them!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### How beautiful are the feet of those who proclaim glad tidings of good things

Paul uses "feet" to represent those who travel and bring the message to those who have not heard it. AT: "It is wonderful when messengers come and tell us the good news" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 10:16

#### But they did not all listen

Here "they" refers to the Jews. "But not all Jews listened"

#### Lord, who has believed our message?

Paul is using this question to emphasize that Isaiah prophesied in the Scriptures that many Jews would not believe in Jesus. You can translate this as a statement. AT: "Lord, so many of them do not believe our message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])  * **believe** - to accept or trust that something is true

#### our message

Here, "our" refers to God and Isaiah.

#### faith comes from hearing

Here "faith" refers to "believing in Christ"

#### hearing by the word of Christ

"Word" here is a metonym for "message." AT: "hearing about the message of Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Romans 10:18

#### But I say, "Did they not hear?" Yes, most certainly

Paul uses a question for emphasis. You can translate this as a statement. AT: "But, I say the Jews certainly have heard the message about Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### Their sound has gone out into all the earth, and their words to the ends of the world.

Both of these statements mean basically the same thing and Paul uses them for emphasis. The word "their" refers to the sun, moon, and stars. Here they are described as human messengers that tell people about God. This refers to how their existence shows God's power and glory. You can make explicit that Paul is quoting Scripture here. AT: "As the Scriptures record, 'The sun, moon, and the stars are proof of God's power and glory, and everyone in the world sees them and knows the truth about God.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Romans 10:19

#### Moreover, I say, "Did Israel not know?"

Paul uses a question for emphasis. The word "Israel" is a metonym for the people who lived in the nation of Israel. AT: "Again I tell you the people of Israel did know the message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### First Moses says, "I will provoke you ... I will stir you up

This means that Moses wrote down what God said. "I" refers to God, and "you" refers to the Israelites. AT: "First Moses says that God will provoke you ... God will stir you up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### by what is not a nation

"by those you do not consider to be a real nation" or "by people who do not belong to any nation"

#### By means of a nation without understanding

Here "without understanding" means that the people do not know God. AT: "By a nation with people who do not know me or my commands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will stir you up to anger

"I will make you angry" or "I will cause you to become angry"

#### you

This refers to the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Romans 10:20

#### General Information:

Here the words "I," "me," and "my" refer to God.

#### Then Isaiah was very bold when he says

This means the prophet Isaiah wrote what God had said.

#### I was found by those who did not seek me

Prophets often speak of things in the future as if they have already happened. This emphasizes that the prophecy will certainly come true. You can translate this in an active form. AT: "Even though the Gentile people will not look for me, they will find me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I appeared

"I made myself known"

#### he says

"He" refers to God, who is speaking through Isaiah.

#### All the day long

This phrase is used to emphasize God's continual effort. "continually"

#### I reached out my hands to a disobedient and stubborn people

"I tried to welcome you and to help you, but you refused my help and continued to disobey"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Romans 10:intro

#### Romans 10 General Notes ####

####### Structure and formatting #######

Some translations indent quotations from the Old Testament. The ULB does this with the quoted material in 10:8.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry that is quoted from the Old Testament in 10:18-20.

####### Special concepts in this chapter #######

######## God's righteousness ########

Paul teaches here that while many Jews were earnest in their beliefs, they did not gain righteousness. God's righteousness cannot be earned, it must be given by Christ through faith. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical questions ########
Paul uses many rhetorical questions to convince his reader that, because salvation is not restricted to the Hebrew people, Christians must be ready to go and share the gospel with the whole world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]])

####### Other possible translation difficulties in this chapter #######

######## "I will provoke you to jealousy by what is not a nation" ########

This prophecy explains that one function of the church is to provoke the Hebrew people to jealousy so they would return to worshiping God. This will happen in the future. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Romans 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Romans 11

### Romans 11:01

#### Connecting Statement:

Though Israel as a nation has rejected God, God wants them to understand salvation comes by grace without works.

#### I say then

"I, Paul, say then"

#### did God reject his people?

Paul asks this question so that he can answer the questions of other Jews who are upset that God has included the Gentiles among his people, while the hearts of the Jewish people have been hardened. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### May it never be

"That is not possible!" or "Certainly not!" This expression strongly denies that this could happen. You may have a similar expression in your language that you could use here. See how you translated this in [Romans 9:14](../09/14.md).

#### tribe of Benjamin

This refers to the tribe descended from Benjamin, one of the 12 tribes into which God divided the people of Israel.

#### whom he foreknew

"whom he knew ahead of time"

#### Do you not know what the scripture says about Elijah, how he pleaded with God against Israel?

You can translate this in an active form. AT: "Surely you know what the Scriptures record about when Elijah pleaded with God against Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### what the scripture says

Paul is referring to the Scriptures as if they were able to speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### they have killed

"They" refers to the people of Israel.

#### I alone am left

The pronoun "I" here refers to Elijah.

#### seeking my life

"desiring to kill me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreordain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreordain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Romans 11:04

#### But what does God's answer say to him?

Paul is using this question to bring the reader to his next point. AT: "How does God answer him?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### him

The pronoun "him" refers to Elijah.

#### seven thousand men

"7,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### remnant

Here this means a small part of people whom God chose to receive his grace.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Romans 11:06

#### But if it is by grace

Paul continues to explain how God's mercy works. AT: "But since God's mercy works by grace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### What then?

"What should we conclude?" Paul asks this question to move his reader to his next point. You can translate this as a statement. AT: "This is what we need to remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### God has given them a spirit of dullness, eyes so that they should not see, and ears so that they should not hear

This is a metaphor about the fact that the people are spiritually dull. They are not able to hear or receive spiritual truth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### spirit of

Here this means "having the characteristics of," such as the "spirit of wisdom."

#### eyes so that they should not see

The concept of seeing with one's eyes was considered to be equivalent to gaining understanding.

#### ears so that they should not hear

The concept of hearing with the ears was considered to be equivalent to obedience.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Romans 11:09

#### Let their table become a net and a trap

"Table" here is a metonym that represents feasting, and "net" and "trap" are metaphors that represent punishment. You can translate this in an active form. AT: "Please, God, make their feasts like a trap that catches them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a stumbling block

A "stumbling block" is anything that causes a person to trip so that he falls down. Here it represents something that tempts a person to  sin. AT: "something that tempts them to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a retribution for them

"something that allows you to take revenge on them"

#### bend their backs continually

Here "bend their back" is a metonym for forcing slaves to carry heavy loads on their backs. This is a metaphor for making them suffer. AT: "make them suffer like people carrying heavy loads" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md)]]

### Romans 11:11

#### Connecting Statement:

With Israel as a nation rejecting God, Paul warns the Gentiles to be careful they do not make the same mistake.

#### Did they stumble so as to fall?

Paul uses this question to add emphasis. AT: "Has God rejected them forever because they sinned?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### May it never be

"That is not possible!" or "Certainly not!" This expression strongly denies that this could happen. You may have a similar expression in your language that you could use here. See how you translated this in [Romans 9:14](../09/14.md).

#### provoke ... to jealousy

See how you translated this phrase in [Romans 10:19](../10/19.md).

#### if their failure is the riches of the world, and if their loss is the riches of the Gentiles

Both of these phrases mean basically the same thing. If you need to, you can combine them in your translation. AT: "when the Jews failed spiritually, the result was that God abundantly blessed the non-Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the riches of the world

Because the Jews rejected Christ, God richly blessed the Gentiles by giving them the opportunity to receive Christ.

#### the world

Here the "world" is a metonym that refers to the people who live in the world, especially the Gentiles.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Romans 11:13

#### provoke to jealousy

See how you translated this phrase in [Romans 10:19](../10/19.md).

#### those who are of my own flesh

This refers to "my fellow Jews."

#### Perhaps we will save some of them

God will save those who believe. AT: "Perhaps some will believe and God will save them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/minister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/minister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Romans 11:15

#### For if their rejection means the reconciliation of the world

"For if because God rejected them, he will reconcile the rest of the world to himself"

#### their rejection

The pronoun "their" refers to Jewish unbelievers.

#### the world

Here "the world" is a metonym for the people who live in the world. AT: "the people in the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### what will their acceptance be but life from the dead?

Paul asks this question to emphasize that when God accepts the Jews, it will be a wonderful thing. You can translate it in an active form. AT: "how will it be when God accepts them? It will be like they have come back to life from among the dead!" or "then when God accepts them, it will be like they have died and become alive again!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the dead

These words speak of all dead people together in the underworld.

#### If the firstfruits are reserved, so is the lump of dough

Paul is speaking of Abraham, Isaac, and Jacob, the Israelites' ancestors, as if they were the first grain or "firstfruits" to be harvested. He is also speaking of the Israelites who are descendants of those men as if they were a "lump of dough" that they made from the grain. AT: "If Abraham is counted as the first of what has been offered to God, all of our ancestors who followed should also be counted as God's possession" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### If the root is reserved, so are the branches

Paul is speaking of Abraham, Isaac, and Jacob, the Israelites' ancestors, as if they were the root of a tree, and the Israelites who are descendants of those men, as if they were the tree's "branches." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### reserved

The people always dedicated to God the first crops that they harvested. Here "firstfruits" stands for the first people to believe in Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]

### Romans 11:17

#### if you, a wild olive branch

The pronoun "you," and the phrase "a wild olive branch," refer to the Gentile people who have accepted salvation through Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### But if some of the branches were broken off

Here Paul refers to the Jews who rejected Jesus as "broken branches." You can translate this in an active form. AT: "But if someone broke off some of the branches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### were grafted in among them

Here Paul speaks of the Gentile Christians as if they were "grafted branches." You can translate this in an active form. AT: "God attached you to the tree among the remaining branches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the rich root of the olive tree

Here "the rich root" is a metaphor that refers to the promises of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### do not boast over the branches

Here "the branches" is a metaphor that stands for the Jewish people. AT: "do not say you are better than the Jewish people God has rejected" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it is not you who supports the root, but the root that supports you

Again Paul implies that the Gentile believers are branches. God saves them only because of the covenant promises that he made to the Jews. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]

### Romans 11:19

#### Branches were broken off

Here "branches" refers to the Jews who rejected Jesus and whom God has now rejected. You can translate this in an active form. AT: "God broke branches off" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I might be grafted in

Paul uses this phrase to refer to the Gentile believers whom God has accepted. You can translate this in an active form. AT: "he might attach me in" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### their ... they

The pronouns "their" and "they" refer to the Jewish people who did not believe.

#### but you stand firm because of your faith

Paul speaks of the Gentile believers remaining faithful as if they were standing firm and no one could move them. AT: "but you remain because of your faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For if God did not spare the natural branches, neither will he spare you

Here the "natural branches" refers to the Jewish people who rejected Jesus. AT: "Since God did not spare those unbelieving Jews, who grew up like a tree's natural branches that came from the root, then know, if you do not believe, he will not spare you either (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Romans 11:22

#### the kind actions and the severity of God

Paul is reminding the Gentile believers that although God may act very kindly toward them, he will not hesitate to judge and punish them.

#### severity came on the Jews who fell ... God's kindness comes on you

This can be restated to remove the abstract nouns "severity" and "kindness." AT: "God dealt harshly with the Jews who fell ... but God acts kindly toward you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the Jews who fell

Doing what is wrong is spoken of as if it is falling down. AT: "the Jews who have done wrong" or "the Jews who have refused to trust in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### if you continue in his kindness

This can be restated to remove the abstract noun "kindness." AT: "if you continue doing what is right so that he continues being kind to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Otherwise you also will be cut off

Paul again uses the metaphor of a branch, which God can "cut off" if he needs to. Here "cut off" is a metaphor for rejecting someone. You can translate this in an active form. AT: "Otherwise God will cut you off" or "Otherwise God will reject you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Romans 11:23

#### if they do not continue in their unbelief

The phrase "do not continue in their unbelief" is a double negative. You can translate this in a positive form. AT: "if the Jews start believing in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### will be grafted in

Paul speaks of the Jews as if they were branches that could be grafted back into a tree if they start to believe in Jesus. You can translate this in an active form. AT: "God will graft them back in" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### graft

This is a common process where the end of a live branch of one tree is inserted into another tree so that the new branch will continue to grow in that tree.

#### For if you were cut out of what is by nature a wild olive tree, and contrary to nature were grafted into a good olive tree, how much more will these Jews, who are the natural branches, be grafted back into their own olive tree?

Paul continues speaking of the Gentile believers and Jews as if they were branches of a tree. You can translate this in an active form. AT: "For if God had cut you out of what is by nature a wild olive tree, and contrary to nature had grafted you into a good olive tree, how much more will he graft these Jews, who are the natural branches, into their own olive tree?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### branches

Paul is speaking of the Jews and Gentiles as if they were branches. The "natural branches" represent the Jews, and the "grafted branches" represent the Gentile believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they ... them

All occurrences of "they" or "them" refer to the Jews.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 11:25

#### I do not want you to be uninformed

Here Paul uses a double negative. You can translate this in a positive form. AT: "I very much want you to be aware" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### brothers

Here "brothers" means fellow Christians, including both men and women.

#### I

The pronoun "I" refers to Paul.

#### you ... you ... your

The pronouns "you" and "your" refer to the Gentile believers.

#### in order that you will not be wise in your own thinking

Paul does not want the Gentile believers to think they are wiser than the Jewish unbelievers. AT: "so that you will not think you are wiser than you are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a partial hardening has occurred in Israel

Paul speaks of "hardening" or stubbornness as if it were a hardening of physical organs in the body. Some Jews have refused to accept salvation through Jesus. AT: "many people of Israel continue to be stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### until the completion of the Gentiles come in

The word "until" here implies that some Jews will believe after God has finished bringing the Gentiles into the church.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]

### Romans 11:26

#### Connecting Statement:

Paul says that a deliverer will come out of Israel to the glory of God.

#### Thus all Israel will be saved

This can be stated in active form. AT: "Thus God will save all Israel" (See:  [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### just as it is written

You can translate this in an active form. AT: "just as the scriptures record" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Out of Zion

Here "Zion" is used as a metonym for the place where God dwells. AT: "From where God is among the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Deliverer

"Deliver" here is a metaphor for "bring to safety." AT: "the one who bring his people to safety" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He will remove ungodliness

Paul speaks of ungodliness as if it were an object that someone could remove, perhaps like someone removes a garment. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from Jacob

Here "Jacob" is used as a metonym for Israel. AT: "from the Israelite people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will take away their sins

Here Paul speaks of sins as if they were objects that someone could take away. AT: "I will remove the burden of their sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Romans 11:28

#### As far as the gospel is concerned

You can make explicit why Paul mentions the gospel. AT: "Because the Jews rejected the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they are enemies for your sake

You can make explicit whose enemies they are, and how this was for the Gentiles' sake. AT: "they are God's enemies for your sake" or "God has treated them as enemies in order that you also might hear the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### as far as election is concerned

You can make explicit why Paul mentions election. AT: "because God has elected the Jews" or "because God has chosen the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they are beloved because of their forefathers

You can make explicit who loves the Jews and why Paul mentions their forefathers. You can also translate this in an active form. AT: "God still loves them because of what he promised to do for their ancestors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For the gifts and the call of God are unchangeable

Paul speaks of the spiritual and material blessings that God promised to give his people as if they were gifts. The call of God refers to the fact that God called the Jews to be his people. AT: "For God never changed his mind about what he has promised to give them, and about how he has called them to be his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]

### Romans 11:30

#### you were formerly disobedient

"you did not obey in the past"

#### you have received mercy because of their disobedience

Here mercy means God's undeserved blessings. AT: "because the Jews have rejected Jesus, you have received blessings that you did not deserve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you

This refers to Gentile believers, and is plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### God has shut up all into disobedience

God has treated people who disobey him like prisoners who are unable to escape from prison. AT: "God has made prisoners of those who disobey him. Now they cannot stop disobeying God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### Romans 11:33

#### Oh, the depth of the riches both of the wisdom and the knowledge of God!

Here "wisdom" and "knowledge" mean basically the same thing. AT: "How amazing are the many benefits of both God's wisdom and knowledge!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### How unsearchable are his judgments, and his ways beyond discovering

"We are completely unable to understand the things that he has decided and find out the ways in which he acts toward us"

#### For who has known the mind of the Lord or who has become his advisor?

Paul uses this question to emphasize that no one is as wise as the Lord. You can translate this as a statement. AT: "No one has ever known the mind of the Lord, and no one has become his advisor." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the mind of the Lord

Here "mind" is a metonym for knowing things or thinking about things. AT: "all that the Lord knows" or "what the Lord thinks about" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Romans 11:35

#### Or who has first given anything to God, that God must repay him?"

Paul uses this question to emphasize his point. AT: "No one has ever given anything to God that he did not first receive from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])  * **For from him ... through him ... to him** - Here, all occurrences of "him" refers to God.

#### To him be the glory forever

This expresses Paul's desire for all people to honor God. You can make this explicit in your translation. AT: "May all people honor him forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Romans 11:intro

#### Romans 11 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 11:9-10, 26-27, 34-35. All of these lines are quoted from the OT.

####### Special concepts in this chapter #######

######## Engrafting ########
Paul uses the image of "engrafting" to refer to the place of the Gentiles and Jews in the plans of God. Grafting is the process whereby one plant is permanently made to be a part of another plant. While the Gentiles are grafted into the plans of God as a wild branch and partake of some blessings, the Jews remain the major focus of God's plans in the history of the world.

####### Other possible translation difficulties in this chapter #######

######## "Did God reject his people? May it never be" ########

Whether Israel (the physical descendants of Abraham, Isaac and Jacob) has a future in the plans of God, or if they have been replaced in the plans of God by the church, is a major theological issue in chapters 9-11. This phrase is an important part of this section of Romans. It seems to indicate that Israel remains distinct from the church. Not all scholars arrive at this conclusion. Despite their current rejection of Jesus as their Messiah, Israel has not exhausted the grace and mercy of God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]])

##### Links: #####

* __[Romans 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Romans 12

### Romans 12:01

#### Connecting Statement:

Paul tells what the life of a believer should be and how believers should serve.

#### I urge you therefore, brothers, by the mercies of God

Here "brothers" refers to fellow believers, both male and female. AT: "Fellow believers, because of the great mercy that God has given you I very much want you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to present your bodies a living sacrifice

Here Paul uses the word "bodies" to refer to the whole person. Paul is comparing a believer in Christ who completely obeys God to the animals that the Jews killed and then offered to God. AT: "to offer yourselves completely to God while you are alive as if you were a dead sacrifice on a temple altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### holy, acceptable to God

Possible meanings are 1) "a sacrifice that you give to God alone and that pleases him" or 2) "acceptable to God because it is morally pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### This is your reasonable service

"This is the right way to worship God"

#### Do not be conformed to this world

Possible meanings are 1) "Do not behave as the world behaves" or 2) "Do not think the way the world does." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do not be conformed

Possible meanings are 1) "Do not let the world tell you what to do and think" or 2) "Do not allow yourself to act and do what the world does." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this world

This refers to unbelievers who live in the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but be transformed by the renewal of your mind

You can translate this in an active form. AT: "but let God change the way you think and behave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Romans 12:03

#### because of the grace that was given to me

Here "grace" refers to God's choosing Paul to be an apostle and leader of the church. You can make this explicit in your translation. You can also translate this in an active form. AT: "because God freely chose me to be an apostle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that everyone who is among you should not think more highly of themselves than they ought to think

"that no one among you should think they are better than other people"

#### Instead, they should think in a wise way

"But you should be wise in how you think about yourselves"

#### just as God has given out to each one a certain amount of faith

Paul implies here that believers have different abilities that correspond to their faith in God. AT: "since God has given each of you different abilities because of your trust in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Romans 12:04

#### For

Paul uses this word to show that he will now explain why some Christians should not think they are better than others.

#### we have many members in one body

Paul refers to all the believers in Christ as if they were different parts of the human body. He does this to illustrate that although believers may serve Christ in different ways, each person belongs to Christ and serves in an important way. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### members

These are such things as eyes, stomachs, and hands.

#### are individually members of each other

Paul speaks of the believers as if God had physically joined them together like the parts of the human body. You can translate this in an active form. AT: "God has joined each believer together with all other believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/member.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/member.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Romans 12:06

#### We have different gifts according to the grace that was given to us

Paul speaks of believers' different abilities as being free gifts from God. You can translate this in an active form. AT: "God has freely given each of us the ability to do different things for him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### let it be done according to the proportion of his faith

Possible meanings are 1) "let him speak prophecies that do not go beyond the amount of faith God has given us" or 2) "let him speak prophecies that agree with the teachings of our faith."

#### If one's gift is giving

Here "giving" refers to giving money and other things to people. You can make this meaning explicit in your translation. AT: "If one has the gift of giving money or other goods to people in need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### Romans 12:09

#### Let love be without hypocrisy

You can translate this in an active form. AT: "You must love people sincerely and truly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### love

The word Paul uses here refers to the kind of love that comes from God and focuses on the good of others, even when it does not benefit oneself.

#### Concerning love of the brothers, be affectionate

Here Paul begins a list of nine items, each of the form "Concerning ... be" to tell the believers what kind of people they should be. You may need to translate some of the items as "Concerning ... do." The list continues to [Romans 12:13](./11.md).

#### Concerning love of the brothers

"As for how you love your fellow believers"

#### love

This is another word that means brotherly love or love for a friend or family member. This is natural human love between friends or relatives.

#### be affectionate

You can translate this in an active form. AT: "show affection" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Concerning honor, respect one another

"Honor and respect one another" or "Honor your fellow believers by respecting them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hypocrite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Romans 12:11

#### Concerning diligence, do not be hesitant. Concerning the spirit, be eager. Concerning the Lord, serve him

"Do not be lazy in your duty, but be eager to follow the Spirit and to serve the Lord"

#### be patient in suffering

"Wait patiently whenever you have troubles"

#### Share in the needs of the believers

This is the last item in the list that began in [Romans 12:9](./09.md). "When fellow Christians are in trouble, help them with what they need"

#### Find many ways to show hospitality

"Always welcome them into your home when they need a place to stay"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Romans 12:14

#### Be of the same mind toward one another

This is an idiom that means to live in unity. AT: "Agree with one another" or "Live in unity with each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Do not think in proud ways

"Do not think that you are more important than others"

#### accept lowly people

"welcome people who do not seem important"

#### Do not be wise in your own thoughts

"Do not think of yourselves as having more wisdom than everyone else"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lowly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lowly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Romans 12:17

#### Repay no one evil for evil

"Do not do evil things to someone who has done evil things to you"

#### Do good things in the sight of all people

"Do things that everyone considers to be good"

#### as far as it depends on you, live at peace with all people

"do whatever you can to live in peace with everyone"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Romans 12:19

#### give way to the wrath of God

Here "wrath" is a metonym for God's punishment. AT: "allow God to punish them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### For it is written

You can translate this in an active form. AT: "For someone has written" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Vengeance belongs to me; I will repay

These two phrases mean basically the same thing and emphasize that God will avenge his people. AT: "I will certainly avenge you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### your enemy ... feed him ... give him a drink ... if you do this, you will heap ... Do not be overcome by evil, but overcome evil

All forms of "you" and "your" are addressed as to one person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### But if your enemy is hungry ... his head

In 12:20 Paul quotes another part of Scripture. AT: "But the Scripture also says, 'If your enemy is hungry ... his head'"

#### feed him

"give him some food"

#### heap coals of fire on his head

Paul speaks of the blessings that the enemies will receive as if someone were pouring hot coals on their heads. Possible meanings are 1) "make the person who harmed you feel badly about how he has mistreated you" or 2) "give God a reason to judge your enemy more harshly." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do not be overcome by evil, but overcome evil with good

Paul describes "evil" as though it were a person. You can translate this in an active form. AT: "Do not let those who are evil defeat you, but defeat those who are evil by doing what is good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 12:intro

#### Romans 12 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 12:20, which is quoted from the OT.

Many scholars believe Paul uses the word "therefore" in [Romans 12:1](./01.md) to refer to all of chapters 1-11. Having given such a great explanation of the Christian doctrine, Paul is now going on to say "therefore, in light of these doctrinal truths, go and live this way." The remainder of Romans focuses on living out one's Christian faith. Paul uses many different commands in this section to give these practical instructions. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Special concepts in this chapter #######

######## Christian living ########
Under the law of Moses, people were required to offer sacrifices of animals or grain in the temple; now Christians are required to live their lives as a type of sacrifice to God. Physical sacrifices are no longer required. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Important figures of speech in this chapter #######

######## Body of Christ ########
The body of Christ is an important metaphor or image used in Scripture to refer to the church. Its significance lies in the fact that each member of the church plays a unique and important function. Christians need each other. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])
##### Links: #####

* __[Romans 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Romans 13

### Romans 13:01

#### Connecting Statement:

Paul tells believers how to live under their rulers.

#### Let every soul be obedient to

Here "soul" is a synecdoche for the whole person. "Every Christian should obey" or "Everyone should obey" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### higher authorities

"government officials"

#### for

because

#### there is no authority unless it comes from God

"all authority comes from God"

#### The authorities that exist have been appointed by God

You can translate this in an active form. AT: "And the people who are in authority are there because God put them there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that authority

"that government authority" or "the authority that God placed in power"

#### those who oppose it will receive judgment on themselves

You can translate this in an active form. AT: "God will judge those who oppose government authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Romans 13:03

#### For

Paul uses this word to begin his explanation of [Romans 13:2](./01.md) and to tell about what will result if the government condemns a person.

#### rulers are not a terror

Rulers do not make good people afraid.

#### to good deeds ... to evil deeds

People are identified with their "good deeds" or "evil deeds."

#### Do you desire to be unafraid of the one in authority?

Paul uses this question to get people to think about what they need to do in order not to be afraid of rulers. AT: "Let me tell you how you can be unafraid of the ruler." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### you will receive his approval

The government will say good things about people who do what is good.

#### he does not carry the sword for no reason

You can translate this in a positive form. AT: "he carries the sword for a very good reason" or "he has the power to punish people, and he will punish people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### carry the sword

Roman governors carried a short sword as a symbol of their authority. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### an avenger for wrath

Here "wrath" represents the punishment people receive when they do evil deeds. AT: "a person who punishes people as an expression of the government's anger against evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### not only because of the wrath, but also because of conscience

"not only so the government will not punish you, but also so you will have a clear conscience before God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]

### Romans 13:06

#### Because of this

"Because the government punishes evildoers"

#### you ... Pay to everyone

Paul is addressing the believers here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### For he

"This is why you should pay taxes: he"

#### attend to

"administer" or "work on"

#### Tax to whom tax is due, toll to whom toll is due; fear to whom fear is due, honor to whom honor is due.

The word "Pay" is understood from the previous sentence. AT: "Pay tax to whom tax is due and toll to whom toll is due. Pay fear to whom fear is due and honor to him to whom honor is due" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### fear to whom fear is due, honor to whom honor is due

Here paying fear and honor is a metaphor for fearing and honoring those who deserve to be feared and honored. AT: "Fear those who deserve to be feared, and honor those who deserved to be honored" or "Respect those whom you ought to respect, and honor those whom you ought to honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### toll

This is a kind of tax.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Romans 13:08

#### Connecting Statement:

Paul tells believers how to act toward neighbors.

#### Owe no one anything, except to love one another

This is a double negative. You can translate it in a positive form. AT: "Pay all you owe to everyone, and love one another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### Owe

This verb is plural and applies to all the Roman Christians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### except to love one another

This is the one debt that can remain as shown in the note above.

#### love

This refers to the kind of love that comes from God and focuses on the good of others, even when it does not benefit oneself.

#### covet

to desire to have or possess something that another person possesses.

#### Love does not harm one's neighbor

This phrase portrays love as a person who is being kind to other people. AT: "People who love their neighbors do not harm them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Romans 13:11

#### you know the time, that it is already time for you to awake out of sleep

Paul speaks of the need for the Roman believers to change their behavior as if they needed to wake up from being asleep. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The night has advanced

Paul speaks of the time when people do evil deeds as night. AT: "The sinful time is almost over" or "It is as though the night is almost finished" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the day has come near

Paul speaks of the time when people do what is right as the day. AT: "the time of righteousness will begin soon" or "it is as though it will soon be day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### works of darkness

"Darkness" here is a metonym for wicked deeds, which people prefer to do at night, when it is dark and no one can see them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### let us put on the armor of light

This is a metaphor in which Paul speaks of doing righteous works as a way of defending ourselves.  AT: "we should allow God to protect us by doing only those deeds that are right and pleasing to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the armor of light

Here "light" is a metonym for "righteous deeds"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md)]]

### Romans 13:13

#### Let us

Paul includes his readers and other believers with himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Let us walk appropriately, as in the day

Paul speaks of living as true believers as if one were walking while it is day. AT: "Let us walk in a visible way knowing that everyone can see us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in sexual immorality or in uncontrolled lust

These concepts mean basically the same thing. You can combine them in your translation. AT: "sexually immoral acts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### strife

This refers to plotting against and arguing with other people.

#### jealousy

This refers to negative feelings against another person's success or advantage over others.

#### put on the Lord Jesus Christ

Paul speaks of accepting the moral nature of Christ as if he were our outer clothing that people can see. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### put on

If your language has a plural form for commands, use it here.

#### make no provision for the flesh

Here the "flesh" refers to the self-directed nature of people who oppose God. This is the sinful nature of human beings. AT: "do not allow your old evil heart any opportunity at all for doing wicked things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]

### Romans 13:intro

#### Romans 13 General Notes ####

####### Structure and formatting #######

In Judaism, there was a close and intended connection between the government and the religion of the people of Israel. Christianity does not usually have this same connection and makes no provision for it. Paul felt that it was important to instruct Christians how to live under an ungodly ruler. This is the focus of the first part of this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md)]])

####### Special concepts in this chapter #######

######## Ungodly rulers ########
Some of the concepts about ungodly rulers in this chapter may be difficult to understand, especially in cultures where the church is persecuted by the government. Christians must obey both God and their rulers. Some times rulers can be disobeyed but there are times when a believer must submit to these ruler and suffer at their hands. This is because the Christian understands that this world is temporary and they will ultimately spend eternity with God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]])

####### Other possible translation difficulties in this chapter #######

######## Flesh ########

This is a complex issue and it is possible that "flesh" is a metaphor for a person's sinful nature. It is not the physical part of man that is sinful and it appears Paul is teaching that while man remains alive ("in the flesh"), he will remain sinful regardless of his effort, but his new nature will be fighting against his old nature. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])
##### Links: #####

* __[Romans 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Romans 14

### Romans 14:01

#### Connecting Statement:

Paul encourages believers to remember that they are answerable to God.

#### weak in faith

This refers to those who felt guilty over eating and drinking certain things.

#### without giving judgment about arguments

"and do not condemn them for their opinions"

#### One person has faith to eat anything

Here "faith" refers to doing what a person believes God is telling him to do.

#### another who is weak eats only vegetables

This describes a person who believes God does not want him to eat meat.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Romans 14:03

#### Who are you, you who judge a servant belonging to someone else?

Paul is using a question to scold those who are judging others. You can translate this as a statement. AT: "You are not God, and you are not allowed to judge one of his servants!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### you, you

The form of "you" here is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### It is before his own master that he stands or falls

Paul speaks of God as if he were a master who owned servants. AT: "Only the master can decide if he will accept the servant or not" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### But he will be made to stand, for the Lord is able to make him stand

Paul speaks of the servant who is acceptable to God as if he were being "made to stand" instead of falling. You can translate this in an active form. AT: "But the Lord will accept him because he is able to make the servant acceptable" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Romans 14:05

#### One person values one day above another. Another values every day equally

"One person thinks one day is more important than all the others, but another person thinks that all days are the same"

#### Let each person be convinced in his own mind

You can make the full meaning explicit. You can also translate this in an active form. AT: "Let each person be sure what he is doing is to honor the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He who observes the day, observes it for the Lord

Here "observes" refers to worshiping. AT: "The person who worships on a certain day does it to honor the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he who eats

The word "everything" is understood from [Romans 14:03](../14/03.md). It can be repeatd here. AT: "the person who eats every kind of food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### eats for the Lord

"eats to honor the Lord" or "eats that way in order to honor the Lord"

#### He who does not eat

The word "everything" is understood from [Romans 14:03](../14/03.md). It can be repeatd here. AT: "He who does not eat everything" or "The person who does not eat certain kinds of food"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### refrains from eating for the Lord
"refrains from eating those foods in order to honor the Lord" or "eats that way in order to honor the Lord"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Romans 14:07

#### For none of us lives for himself

Here "lives for himself" means to live only to please oneself. AT: "None of us should live merely to please ourselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### none dies for himself

This means one's death affects other people. AT: "none of us should think that when we die, it affects only us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### us ... we

Paul is including his readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Romans 14:10

#### why do you judge your brother? And you, why do you despise your brother?

By using these questions, Paul is demonstrating how he might need to scold individuals among his readers. AT: "it is wrong for you to judge your brother, and it is wrong for you to despise your brother!" or "stop judging and despising your brother!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### brother

Here this means a fellow Christian, male or female.

#### For we will all stand before the judgment seat of God

The "judgment seat" refers to God's authority to judge. AT: "For God will judge us all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### For it is written, "As

You can translate this in an active form. AT: "For someone has written in the Scriptures: 'As" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### As I live

This phrase is used to start an oath or solemn promise. AT: "You can be certain that this is true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to me every knee will bend, and every tongue will give praise to God

Paul uses the words "knee" and "tongue" to refer to the whole person. Also, the Lord uses the word "God" to refer to himself. AT: "every person will bow and give praise to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Romans 14:12

#### will give an account of himself to God

"will have to explain our actions to God"

#### but instead decide this, that no one will place a stumbling block or a snare for his brother

Here "stumbling block" and "snare" mean basically the same thing. AT: "but instead make it your goal not to do or say anything that might cause a fellow believer to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### brother

Here this means a fellow Christian, male or female.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Romans 14:14

#### I know and am persuaded in the Lord Jesus

Here the words "know" and "am persuaded" mean basically the same thing; Paul uses them to emphasize his certainty. AT: "I am certain because of my relationship with the Lord Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### nothing is unclean by itself

You can translate this in a positive form. AT: "everything by itself is clean" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### by itself

"by its nature" or "because of what it is"

#### Only for him who considers anything to be unclean, for him it is unclean

Paul implies here that a person should stay away from anything that he thinks is unclean. You can make this explicit in your translation. AT: "But if a person thinks something is unclean, then for that person it is unclean and he should stay away from it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If because of food your brother is hurt

"If you hurt your fellow believer's faith over the matter of food." Here the word "your" refers to those who are strong in faith and "brother" refers to those who are weak in faith.

#### brother

Here this means a fellow Christian, male or female.

#### you are no longer walking in love

Paul speaks of the behavior of believers as if it were a walk. AT: "then you are no longer showing love" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Romans 14:16

#### So do not allow what you consider to be good to be spoken of as evil

"If someone thinks that something is evil, do not do it, even if you consider it to be good"

#### For the kingdom of God is not about food and drink, but about righteousness, peace, and joy in the Holy Spirit

Paul argues that God set up his kingdom so he could give us a right relationship with himself, and to provide peace and joy. AT: "For God did not set up his kingdom so that he could rule over what we eat and drink. He set up his kingdom so we could have a right relationship with him, and so he could give us peace and joy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Romans 14:18

#### approved by people

You can translate this in an active form. AT: "people will approve of him" or "people will respect him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### let us pursue the things of peace and the things that build up one another

Here "build up one another" refers to helping each other grow in faith. AT: "let us seek to live peacefully together and help one another grow stronger in faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Romans 14:20

#### Do not destroy the work of God because of food

You can make explicit the full meaning of this sentence. AT: "Do not undo what God has done for a fellow believer just because you want to eat a certain kind of food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but it is evil for that person who eats and causes him to stumble

Here anything that "causes him to stumble" means it causes a weaker brother to do something that is against his conscience. AT: "but it would be a sin for someone to eat food, which another brother thinks is wrong to eat, if by eating this causes the weaker brother to do something that is against his conscience" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It is good not to eat meat, nor to drink wine, nor anything by which your brother takes offense

"It is better not to eat meat or drink wine or do anything else that might cause your brother to sin"

#### brother

Here this means a fellow Christian, male or female.

#### your

This refers to the strong in faith and "brother" refers to the weak in faith.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Romans 14:22

#### The faith you have

This refers back to the beliefs about food and drink.

#### you ... yourself

singular. Because Paul is addressing the believers, you may have to translate this using plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Blessed is the one who does not condemn himself by what he approves

"Blessed are those who do not feel guilty for what they decide to do"

#### He who doubts is condemned if he eats

You can translate this in an active form. AT: "God will say that the person does wrong if he is not sure if it is right to eat a certain food, but he eats it anyway" or "The person who is not sure if it is right to eat a certain food, but then eats it anyway will have a troubled conscience" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### because it is not from faith

Anything that is "not from faith" is something that God does not want you to do. You can make explicit the full meaning here. AT: "God will say that he is wrong because he is eating something he believes God does not want him to eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### whatever is not from faith is sin

Anything that is "not from faith" is something that God does not want you to do. You can make explicit the full meaning here. AT: "you are sinning if you do something that you do not believe God wants you to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Romans 14:intro

#### Romans 14 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 14:11, which is quoted from the OT.

####### Special concepts in this chapter #######

######## Weak in faith ########

Faith is used in Scripture to as something one can definitively possess and at the same time be "weak in" or "lack" in a given situation. In this passage, being weak in faith references Christians who were immature, lacking strength or understanding in their faith. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## Dietary restrictions ########

Dietary restrictions were important in many religions in the ancient Near East. Christians had freedom to eat what they wanted to, but they had to exercise this freedom wisely, and in a way that brought honor to the Lord and did not cause others to sin. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]) 

######## The Judgment Seat of God ########

The Judgment Seat of God or Christ (also known as the "Bema Seat") represents a time when Christians will be held accountable for the way they lived their lives as Christians. 

##### Links: #####

* __[Romans 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## Romans 15

### Romans 15:01

#### Connecting Statement:

Paul concludes this section about believers' living for others with reminding them how Christ lived.

#### Now

Translate this using the words your language uses to introduce a new idea into an argument.

#### we who are strong

Here "strong" refers to the people who are strong in their faith. They believe that God allows them to eat any kind of food. AT: "we who are strong in faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### we

This refers to Paul, his readers, and other believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### the weak

Here "the weak" refers to the people who are weak in their faith. They believe that God does not allow them to eat some kinds of food. AT: "those who are weak in faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to build him up

By this, Paul means to strengthen someone's faith. AT: "to strengthen his faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Romans 15:03

#### it was just as it is written

Here Paul refers to a scripture where Christ (the Messiah) speaks to God. You can translate this in an active form. AT: "the Messiah said to God in the scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The insults of those who insulted you fell on me

The insults of those who insulted God fell on Christ.

#### For whatever was previously written was written for our instruction

You can translate this in an active form. AT: "For in times past, the prophets wrote everything in the Scriptures to teach us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### our ... we

Paul includes his readers and other believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### in order that through patience and through encouragement of the scriptures we would have certain hope

Here "have confidence" means that the believers will know that God will fulfill his promises. You can make explicit the full meaning in your translation. AT: "In this way the scriptures will encourage us to expect that God will do for us everything that he has promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Romans 15:05

#### Connecting Statement:

Paul encourages the believers to remember that both Gentile believers and Jews that believe are made one in Christ.

#### may ... God ... grant

"I pray that ... God ... will grant"

#### to be of the same mind with each other

Here to be of the "same mind" is a metonym that means to be in agreement with each other. AT: "to be in agreement with each other" or "to be united" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### praise with one mouth

This means to be united in praising God. AT: "praise God together in unity as if only one mouth were speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### receive one another

"accept one another""

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]

### Romans 15:08

#### For I say

The word "I" refers to Paul.

#### Christ has been made a servant of the circumcision

Here "the circumcision" is a metonym that refers to the Jews. You can translate this in an active form. AT: "Jesus Christ has become a servant of the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in order to confirm the promises ... and for the Gentiles to glorify God for his mercy

These are the two purposes for which Christ became a servant of the circumcision. AT: "in order to confirm the promises ... and in order that the Gentiles might glorify God for his mercy"

#### the promises given to the fathers

Here "the fathers" refers to the ancestors of the Jewish people. You can translate this in active form. AT: "the promises that God gave to the ancestors of the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### As it is written

You can translate this in an active form. AT: "as someone has written in the Scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sing praise to your name

Here "your name" is a metonym that refers to God. AT: "sing praise to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Romans 15:10

#### Again it says

"Again the scripture says"

#### with his people

This refers to God's people. You can make this explicit in your translation. AT: "with the people of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### praise him

"praise the Lord"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Romans 15:12

#### root of Jesse

Jesse was the physical father of King David. AT: "descendant of Jesse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in him the Gentiles will have hope

Here "him" refers to the descendant of Jesse, the Messiah. Those who are not Jews will also trust him to fulfill his promises. AT: "The people who are not Jews can trust him to do what he has promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jesse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jesse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Romans 15:13

#### fill you with all joy and peace

Paul exaggerates here to emphasize his point. AT: "fill you with great joy and peace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Romans 15:14

#### Connecting Statement:

Paul reminds the believers in Rome that God chose him to reach the Gentiles.

#### I myself am also convinced about you, my brothers

Paul is quite sure that the believers in Rome are honoring each other in their behavior. AT: "I myself am completely sure that you yourselves have acted toward others in a completely good way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### brothers

Here this means fellow Christians, including both men and women.

#### filled with all knowledge

Paul exaggerates here to emphasize his point. AT: "filled with sufficient knowledge to follow God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### also able to exhort one another

Here "exhort" means to teach. AT: "also able to teach each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exhort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exhort.md)]]

### Romans 15:15

#### the gift that was given me by God

This gift is Paul's appointment as an apostle despite his persecution of believers prior to his conversion. Paul speaks of his selection as an apostle as if it were a gift that God gave to him. You can translate this in an active form. AT: "the gift God gave me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] or [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the offering of the Gentiles might become acceptable

Paul speaks of his preaching the gospel as if he, as a priest, were making an offering to God. AT: "the Gentiles might please God when they obey him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Romans 15:17

#### For I will not dare to speak of anything ... These are things done by word and action, by the power of signs and wonders, and by the power of the Holy Spirit

You can translate this double negative in a positive form. Here "these are things" refers to what Christ has accomplished through Paul. AT: "For the sake of the obedience of the Gentiles, I will only speak of what Christ has accomplished through me in my words and actions and by the power of signs and wonders through the power of the Holy Spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### signs and wonders

These two words mean basically the same thing and refer to various kinds of miracles. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### so that from Jerusalem, and round about as far as Illyricum

This is from the city of Jerusalem as far as the province of Illyricum, a region close to Italy.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]

### Romans 15:20

#### In this way, my desire has been to proclaim the gospel, but not where Christ is known by name

Paul only wants to preach to people who have never heard of Christ. AT: "Because of this, I want to preach the good news in places where people have never heard of Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in order that I might not build upon another man's foundation

Paul speaks of his ministry work as if he were building a house on a foundation. AT: "in order that I might not be simply continuing the work that someone else already started. I do not want to be like a man who builds a house on someone else's foundation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It is as it is written

Here Paul refers to what Isaiah wrote in the scriptures. You can translate this in an active form and make the meaning explicit. AT: "What is happening is like what Isaiah wrote in the scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Those to whom no tidings of him came

Here Paul speaks of the "tidings" or message about Christ as if it were alive and able to move by itself. AT: "Those whom no one had told the news about him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]

### Romans 15:22

#### Connecting Statement:

Paul tells the believers in Rome about his personal plans to visit them and asks the believers to pray.

#### I was also hindered

You can translate this in an active form. AT: "they also hindered me" or "people also hindered me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I no longer have any place in these regions

Paul implies that there are no more places in these areas where people live who have not heard about Christ. AT: "there are no more places in these regions where people have not heard about Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

### Romans 15:24

#### Spain

This is a roman province west of Rome that Paul desired to visit. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### in passing

"as I pass through Rome" or "while I am on my way"

#### and to be helped by you along my journey

Here Paul implies that he wants the Roman believers to provide some financial assistance to him for his journey to Spain. AT: "that you will help me on my journey" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### have enjoyed your company

"have enjoyed spending some time with you" or "have enjoyed visiting you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Romans 15:26

#### it was the good pleasure of Macedonia and Achaia

Here the words "Macedonia" and "Achaia" are synecdoches for the people who live in those areas. AT: "the believers in the provinces of Macedonia and Achaia were happy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Yes, it was their good pleasure

"The believers in Macedonia and Achaia were pleased to do it"

#### indeed, they are their debtors

"indeed the people of Macedonia and Achaia are in debt to the believers in Jerusalem"

#### if the Gentiles have shared in their spiritual things, they owe it to them also to serve them

"since the Gentiles have shared in the spiritual things of the Jerusalem believers, the Gentiles owe service to the Jerusalem believers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/macedonia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/macedonia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Romans 15:28

#### made sure that they have received what was collected

Paul speaks of the money he is taking to Jerusalem as if it were a fruit that was collected for them. AT: "and have safely delivered this offering to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I know that when I come to you I will come in the fullness of the blessing of Christ

This phrase means that Christ will bless Paul and the Roman believers. AT: "And I know that when I visit you, Christ will abundantly bless us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Romans 15:30

#### Now

If your language has a way to show that Paul has stopped talking about the good things he is confident of ([Romans 15:29](./28.md)) and is now starting to talk about the dangers he faces, use it here.

#### I urge you

"I encourage you"

#### brothers

Here this means fellow Christians, including both men and women.

#### strive

"work hard" or "struggle"

#### rescued

"saved" or "protected"

#### that my service for Jerusalem may be acceptable to the believers

Here Paul expresses his desire that the believers in Jerusalem will gladly accept the money from the believers in Macedonia and Achaia. AT: "pray that the believers in Jerusalem will be glad to receive the money that I am bringing them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Romans 15:33

#### May the God of peace

The "God of peace" means the God who causes believers to have inner peace. AT: "I pray that God who causes all of us to have inner peace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Romans 15:intro

#### Romans 15 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 15:9-11, 21. All of these lines are quoted from the OT.

Some translations indent prose quotations from the Old Testament. The ULB does this with the quoted material in 15:12.

Romans [Romans 15:14](./14.md) marks a shift in the material of the book overall. Paul begins to speak much more personally. This serves a specific function in the letter overall, marking the end of his instruction and beginning a personal greeting.

####### Important figures of speech in this chapter #######

######## Strong/Weak ########
These terms are used to refer to people who are mature and immature in their faith. There are many different terms that can be used to describe people who have grown more spiritually than others. Paul also explains that spiritual growth occurs through the fellowship and encouragement of other Christians in community with one another. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]) 

##### Links: #####

* __[Romans 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## Romans 16

### Romans 16:01

#### Connecting Statement:

Paul then greets many of the believers in Rome by name.

#### I commend to you Phoebe

"I want you to respect Phoebe"

#### Phoebe

This is a woman's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### our sister

The word "our" refers to Paul and all believers. AT: "our sister in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Cenchrea

This was a seaport city in Greece. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### receive her in the Lord

Paul encourages the Roman believers to welcome Phoebe as a fellow believer. AT: "welcome her because we all belong to the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in a manner worthy of the believers

"in the way that believers should welcome other believers"

#### stand by her

Paul encourages the Roman believers to give to Phoebe anything she needs. AT: "help her by giving her whatever she needs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### has become a helper of many, and of myself as well

"has helped many people, and she has also helped me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Romans 16:03

#### Priscilla and Aquila

Priscilla was the wife of Aquila. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### my fellow workers in Christ Jesus

Paul's "fellow workers" are people who also tell others about Jesus. AT: "who work with me to tell people about Christ Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Greet the church that is in their house

"Greet the believers who meet in their house to worship"

#### Epaenetus

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### firstfruit of Asia to Christ

Paul speaks of Epaenetus as if he were a fruit that he harvested. AT: "first person in Asia to believe in Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asia.md)]]

### Romans 16:06

#### Mary

This is a woman's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Andronicus ... Ampliatus

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Junias

This could be either 1) Junia, a woman's name, or, much less likely, 2) Junias, a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They are prominent among the apostles

You can translate this in an active form. AT: "The apostles know them very well" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my beloved in the Lord

"my dear friend and fellow believer"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]

### Romans 16:09

#### Urbanus ... Stachys ... Apelles ... Aristobulus ... Herodion ... Narcissus

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the approved in Christ

The word "approved" refers to someone who has been tested and proved to be genuine. AT: "whom Christ has approved"

#### who are in the Lord

This refers to those who trust in Jesus. AT: "who are believers" or "who belong to the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]

### Romans 16:12

#### Tryphaena ... Tryphosa ... Persis

These are women's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### Rufus ... Asyncritus ... Phlegon ... Hermes ... Patrobas ... Hermas

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### chosen in the Lord

You can translate this in an active form. AT: "whom the Lord has chosen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his mother and mine

Paul speaks of the mother of Rufus as if she were his own mother. AT: "his mother, whom I also think of as my mother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### brothers

Here this means fellow Christians, including both men and women.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Romans 16:15

#### Philologus ... Nereus ... Olympas

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### Julia

The name of a woman. Julia was probably the wife of Philologus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### a holy kiss

an expression of affection for fellow believers

#### All the churches of Christ greet you

Here Paul speaks in a general manner concerning the churches of Christ. AT: "The believers in all the churches in this area send their greetings to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Romans 16:17

#### Connecting Statement:

Paul gives one last warning to the believers about unity and living for God.

#### brothers

Here this means fellow Christians, including both men and women.

#### to think about

"to watch out for"

#### who are causing the divisions and stumbling

This refers to those who argue and cause others to stop trusting in Jesus. AT: "who are causing believers to argue with one another and to stop having faith in God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They are going beyond the teaching that you have learned

"They teach things that do not agree with the truth you have already learned"

#### Turn away from them

"Turn away" here is an idiom for "move away. AT: "Do not listen to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### but their own stomach

The words "they serve" are understood from the previous phrase. This can be expressed as a separate sentence. AT: "Rather, they serve their own stomach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### but their own stomach

Here "stomach" is a metonym that refers to physical desires. Serving there stomach represents satisfying their desires. AT: "but they only want to satisfy their own selfish desires" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### By their smooth and flattering speech

The words "smooth" and "flattering" mean basically the same thing. Paul is emphasizing how these people are deceiving believers. AT: "By saying things that seem to be good and true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### they deceive the hearts of the innocent

"Hearts" here is a metonym for entire lives. AT: "they deceive the innocent believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### innocent

This refers to those who are simple, inexperienced, and naive. AT: "those who innocently trust them" or "those who do not know these teachers are fooling them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]

### Romans 16:19

#### For your example of obedience reaches everyone

Here Paul speaks of the Roman believers' obedience as if it were a person who could go to people. AT: "For everyone has heard how you obey Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The God of peace will soon crush Satan under your feet

The phrase "crush under your feet" refers to complete victory over an enemy. Here Paul speaks of the victory over Satan as if the Roman believers were trampling an enemy under their feet. AT: "Soon God will give you peace and complete victory over Satan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### innocent to that which is evil

"not involved in doing evil things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Romans 16:21

#### Connecting Statement:

Paul gives greetings from the believers who are with him.

#### Lucius, Jason, and Sosipater ... Tertius

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Tertius, who write this epistle down

Tertius is the man who wrote down what Paul spoke. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### greet you in the Lord

"greet you as a fellow believer"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]

### Romans 16:23

#### Gaius ... Erastus ... Quartus

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the host

This refers to Gaius, the person in whose house Paul and his fellow believers gathered for worship.

#### the treasurer

This is a person who takes care of the money for a group.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Romans 16:25

#### Connecting Statement:

Paul closes with a prayer of blessing.

#### Now

Here the word "now" marks the closing section of the letter. If you have a way of doing this in your language, you can use it here.

#### to make you stand

Paul speaks here of having strong faith as if a person were standing, instead of falling. AT: "to make your faith strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### according to my gospel and the preaching of Jesus Christ

"by the good news that I have preached about Jesus Christ"

#### according to the revelation of the mystery that had been kept secret for long ages

Paul says that God has revealed previously hidden truths to the believers. He speaks of these truths as if they were a secret. You can translate this in an active form. AT: "because God has revealed to us believers the secret that he was keeping for a long time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### but now has been revealed and made known through the prophetic writings to all nations, by the command of the eternal God

The verbs "revealed" and "made known" mean basically the same thing. Paul uses both of them to emphasize his point. You can combine these words and translate this in an active form. AT: "but now the eternal God has made it known to all the nations through the prophetic writings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to bring about the obedience of faith

Here "obedience" and "faith" are abstract nouns. You can use the verbs "obey" and "trust" in your translation. You may need to make explicit who will obey and trust. AT: "so that all nations will obey God because they trust in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/preach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]

### Romans 16:27

#### To the only wise God ... be glory forever. Amen

Here "through Jesus Christ" refers to what Jesus did. To give "glory" means to praise God. AT: "Because of what Jesus Christ has done for us, we will praise forever the one who alone is God and who alone is wise. Amen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Romans 16:intro

#### Romans 16 General Notes ####

####### Structure and formatting #######

This chapter forms a final salutation or greeting for the Christians in Rome. It was common to end a letter in the ancient Near East with this type of personal greeting.

####### Other possible translation difficulties in this chapter #######

Because of the personal nature of this chapter, much of the context has been lost to history. This will make translation difficult. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Romans 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | __


## Romans front

### Romans front:intro

#### Introduction to Romans ####

##### Part 1: General Introduction #####

####### Outline of the Book of Romans #######

1. Introduction (1:1-15)
1. Righteousness by faith in Jesus Christ (1:16-17)
1. All mankind is condemned because of sin (1:18-3:20)
1. Righteousness through Jesus Christ by faith in him (3:21-4:25)
1. The fruits of the Spirit (5:1-11)
1. Adam and Christ compared (5:12-21)
1. Becoming like Christ in this life (6:1-8:39)
1. God's plan for Israel (9:1-11:36)
1. Practical advice for living as Christians (12:1-15:13)
1. Conclusion and greetings (15:14-16:27)

####### Who wrote the Book of Romans? #######

The Apostle Paul wrote the Book of Romans. Paul was from the city of Tarsus. He had been known as Saul in his early life. Before becoming a Christian, Paul was a Pharisee. He persecuted Christians. After he became a Christian, he traveled several times throughout the Roman Empire telling people about Jesus.

Paul probably wrote this letter while he was staying in the city of Corinth during his third trip through the Roman Empire.

####### What is the Book of Romans about? #######

Paul wrote this letter to the Christians in Rome. Paul wanted to get them ready to receive him when he visited them. He said his purpose was to "bring about the obedience of faith" (16:26).

In this letter Paul most fully described the gospel of Jesus Christ. He explained that both Jews and non-Jews have sinned, and God will forgive them and declare them righteous only if they believe in Jesus (chapters 1-11). Then he gave them practical advice for how believers should live (chapters 12-16),
 
####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Romans." Or they may choose a clearer title, such as "Paul's Letter to the Church in Rome," or "A Letter to the Christians in Rome." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### What are the titles used to refer to Jesus? #######

In Romans, Paul described Jesus Christ by many titles and descriptions: Jesus Christ (1:1), the Seed of David (1:3), the Son of God (1:4), the Lord Jesus Christ (1:7), Christ Jesus (3:24), Propitiation (3:25), Jesus (3:26), Jesus our Lord (4:24), Lord of Hosts (9:29), a Stumbling Stone and Rock of Offence (9:33), the End of the Law (10:4), the Deliverer (11:26), Lord of the Dead and the Living (14:9), and the Root of Jesse (15:12).

####### How should theological terms in Romans be translated? #######

Paul uses many theological terms that are not used in the four gospels. As early Christians learned more about the meaning of Jesus Christ and his message, they needed words and expressions for new ideas. Some examples of these words are "justification" (5:1), "works of the law" (3:20), "reconcile" (5:10), "propitiation" (3:25), "sanctification" (6:19), and "the old man" (6:6).

The "key terms" dictionary can help translators understand many of these terms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

Terms such as those given above are difficult to explain. It is often hard or impossible for translators to find equivalent terms in their own languages. It can help to know that word equivalents of these terms are not necessary. Instead, translators can develop short expressions to communicate these ideas. For example, the term "gospel" can be translated as "the good news about Jesus Christ."

Translators should also remember that some of these terms have more than one meaning. The meaning will depend on how the author is using the word in that particular passage. For example, "righteousness" sometimes means that a person obeys God's law. At other times, "righteousness" means that Jesus Christ has perfectly obeyed God's law for us.

####### What did Paul mean by "a remnant" of Israel (11:5)? #######

The idea of a "remnant" is important both in the Old Testament and for Paul. Most of the Israelites were either killed or scattered among other people when the Assyrians and then the Babylonians conquered their land. Only a relatively few Jews survived. They were known as "the remnant."

In 11:1-9, Paul speaks of another remnant. This remnant is the Jews whom God saved because they believed in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]])

##### Part 3: Important Translation Issues #####

####### What did Paul mean by being "in Christ"? #######

The phrase "in Christ" and similar phrases occur in 3:24; 6:11, 23; 8:1,2,39; 9:1; 12:5,17; 15:17; and 16:3,7,9,10. Paul used these kinds of phrases as a metaphor to express that Christian believers belong to Jesus Christ. Belonging to Christ means the believer is saved and is made a friend with God. The believer is also promised to live with God forever. However, this idea can be difficult to represent in many languages.

These phrases also have specific meanings that depend on how Paul used them in a particular passage. For example, in 3:24 ("the redemption that is in Christ Jesus"), Paul referred to our being redeemed "because" of Jesus Christ. In 8:9 ("you are not in the flesh but in the Spirit"), Paul spoke of believers submitting "to" the Holy Spirit. In 9:1 ("I tell the truth in Christ"), Paul meant that he is telling the truth that "is in agreement with" Jesus Christ. 

Nevertheless, the basic idea of our being united with Jesus Christ (and with the Holy Spirit) is seen in these passages as well. Therefore, the translator has a choice in many passages that use "in." He will often decide to represent the more immediate sense of "in," such as, "by means of," "in the manner of," or "in regard to." But, if possible, the translator should choose a word or phrase that reprents the immediate sense and the sense of "in union with." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]])

####### How are the ideas of "holy," "saints" or "holy ones," and "sanctify" represented in Romans in the ULB? #######

The scriptures use such words to indicate any one of various ideas. For this reason, it is often difficult for translators to represent them well in their versions. In translating into English, the ULB uses the following principles:
* Sometimes the meaning in a passage implies moral holiness. Especially important for understanding the gospel is the fact that God considers Christians to be sinless because they are united to Jesus Christ. Another related fact is that God is perfect and faultless. A third fact is that Christians are to conduct themselves in a blameless and faultless manner in life. In these cases, the ULB uses "holy," "holy God," "holy ones" or "holy people." (See: 1:7)
* Sometimes the meaning in a passage indicates a simple reference to Christians without implying any particular role filled by them. In cases where some other English versions have "saints" or "holy ones," the ULB uses "believers." (See: 8:27; 12:13; 15:25, 26, 31; 16:2, 15)
* Sometimes the meaning in a passage indicates the idea of someone or something set apart for God alone. In these cases, the ULB uses "set apart," "dedicated to," "consecrated," or "reserved for." (See: 15:16)

The UDB will often be helpful as translators think about how to represent these ideas in their own versions.

####### What are the major issues in the text of the Book of Romans? #######

The following are the most significant textual issues in the Book of Romans:

* "he [God] works all things together for good" (8:28). Some older versions read, "All things work together for good."
* "But if it is by grace, it is no longer by works. Otherwise grace would no longer be grace" (11:6). The best ancient copies have read this way. However, some versions read: "But if it is by works, then is it no more grace: otherwise work is no more work."
* "May the grace of our Lord Jesus Christ be with you all. Amen" (16:24). The best ancient copies do not have this verse.

Translators are advised not to include this last passage. However, if in the translators' region there are older Bible versions that have the passage, the translators can include it. If it is translated, it should be put inside square brackets ([]) to indicate that it is probably not original to the Book of Romans. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

