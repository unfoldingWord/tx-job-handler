# <a id="mal"/>Malachi

## Malachi 01

### Malachi 01:01

#### The declaration of the word of Yahweh to Israel by the hand of Malachi

This can be expressed as a statement. "This is the declaration of the word of Yahweh to Israel by the hand of Malachi"

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### by the hand of Malachi

The phrase "by the hand of" is an idiom that means that Yahweh used Malachi to deliver his message. AT: "through Malachi" or "spoken to them by Malachi" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### How have you loved us?

This question indicates that the people doubt the truth of what God says. This can be expressed as a statement. AT: "You have not shown that you love us." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Was not Esau Jacob's brother?

This question, a reply of Yahweh reminding the people of their nation's history, may also be expressed as a statement. AT: "You know that Esau was Jacob's brother." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### declares Yahweh

"Yahweh has solemnly said this"

#### I have loved Jacob

Here "loved" implies a relationship of loyalty between Yahweh and Jacob, in which a covenant existed between them. This can be made explicit. AT: "as you know, I obligated myself with a covenant to love Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I have loved Jacob

This name "Jacob" refers here not only to Jacob, but also to all his descendants. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Esau I have hated

Here "hated" implies that there was no covenant between Yahweh and Esau. However, it does not imply that Yahweh was emotionally against Esau.

#### Esau I have hated

This name "Esau" refers here not only to Esau, but also to all his descendants. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### his mountains

This refers to the hill country of Edom.

#### I have made his inheritance a place for the jackals of the wilderness

In the Old Testament, the presence of wild animals such as jackals was a frequent description of land deserted by the people who once lived there.

#### his inheritance

Here "inheritance" stands for the region that Esau's descendants, the nation of Edom, occupied. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/malachi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/malachi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Malachi 01:04

#### If Edom says

Here "Edom" stands for the people of Edom. AT: "If the people of Edom say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will throw down

Here "throw down" stands for "destroy." AT: "I will destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### country of wickedness

Here "wickedness" stands either for wicked people or for wicked actions. AT: "country of wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Your own eyes will see this

Here "your own eyes" stands for the people themselves. AT: "You yourselves will see this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Malachi 01:06

#### General Information:

Yahweh rebukes the priests using an imaginary conversation in which the priests protest that they are doing right and Yahweh tells them what they are doing wrong.

#### despise my name

Here "my name" stands for Yahweh himself. AT: "treat me as though you hate me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### How have we despised your name?

Here the priests are asking a question in order to state that they have not really despised Yahweh. This can be expressed as a statement. AT: "We have not really despised your name." or "Tell us how we have despised your name, because we do not think that we have done so." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### polluted bread

Here "polluted" describes anything that is not suitable to sacrifice to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### How have we polluted you?

Here the priests are asking a question in order to state that they have not really polluted Yahweh. This can be expressed as a statement. AT: "We have not polluted you." or "Tell us how we have polluted you, because we do not think that we have done so." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### polluted you

This expression refers to insulting God by giving him unsuitable sacrifices. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### table

This refers to an altar.

#### By saying that Yahweh's table is contemptible.

This is the answer that Yahweh gives to the priests, but the full answer is only implied. This can be made explicit. AT: "You have polluted me by saying, 'Yahweh's table is contemptible.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### contemptible

regarded as worthless

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Malachi 01:08

#### When you offer blind animals for sacrifice, is that not evil?

Here Yahweh uses a question to rebuke the people. AT: "You know very well that it is evil for you to offer blind animals for sacrifice!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### When you offer the lame and sick, is that not evil?

Here Yahweh uses a question to rebuke the people. AT: "And you know very well that it is evil for you to offer lame and sick animals!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Present that to your governor! Will he accept you or will he lift up your face?

The command in the first sentence functions as a hypothetical condition. AT: "If you present that to your governor, will he accept you or will he lift up your face?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]]

#### Will he accept you or will he lift up your face?

Here Yahweh asks this question in order to remind the people that their governor would never accept defective animals from them. AT: "If you do those things, you know that the governor will not accept you. He will not lift up your face." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### will he lift up your face

Lifting up someone's face refers to accepting him with favor. AT: "will he accept you with favor" or "will he agree to help you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Present

give as a gift to show respect

#### Now you keep asking the face of God, that he may be gracious to us

Malachi is no longer speaking for God. He is talking directly to the Israelites; he is criticizing them for daring to think that God will have mercy on them.

#### keep asking the face of God

Here "face" stands for God and also for his presence. AT: "keep asking God in his presence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### with such an offering in your hand, would he lift up any of your faces?

Here Yahweh is asking a question in order to make a statement of rebuke. AT: "if you offer unacceptable offerings, he will certainly not lift up your faces." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### with such an offering in your hand

This difficult phrase in Hebrew is interpreted in many different ways by modern versions.

#### in your hand

Here "hand" stands for the people bringing the offering. AT: "brought by you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### would he lift up any of your faces

Lifting up someone's face refers to accepting him with favor. AT: "would he accept any of you with favor" or "would he agree to help any of you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Malachi 01:10

#### Oh, if only

This expresses great desire.

#### so that you might not light fires on my altar in vain

Here "light fires on my altar" stands for offering sacrifices on Yahweh's altar. AT: "so that you might not make fires to burn offerings that I will not accept" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from your hand

Here "your hand" stands for "you." AT: "from you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### from the rising of the sun to its setting

This double expression means "everywhere." It is parallel to "among the nations" and "in every place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### my name will be great among the nations

Here "my name" stands for Yahweh's reputation and honor. AT: "I will be honored in other nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in every place incense and pure offerings will be offered in my name

This may be expressed in active form. AT: "in these nations people will offer incense and pure offerings to me in order to worship me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in my name

Here "name" stands for Yahweh. AT: "to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### its fruit, its food

Possible meanings are 1) "the meat sacrificed on the altar from animals whose other parts the priests should eat" or 2) "the meat sacrificed on the altar."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md)]]

### Malachi 01:13

#### snort at it

show great disrespect by making noises through the nose (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Should I accept this from your hand?

Here Yahweh is asking a question in order to make a statement of rebuke. AT: "I should certainly not accept this from you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### from your hand

Here "your hand" stands for "you." AT: "from you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### my name will be honored among the nations

This may be expressed in active form. AT: "people in the other nations honor my name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my name will be honored

Here "my name" stands for Yahweh. AT: "I will be honored" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Malachi 01:intro

#### Malachi 01 General Notes ####

####### Special concepts in this chapter #######

######## Yahweh of hosts ########
This is an important title used in this chapter. It reminds the reader of the great power Yahweh has to punish the nations. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical questions ########
There are many rhetorical questions in this chapter. They all have a rather dramatic effect. They increase the emotional connotations of what is being said. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

##### Links: #####

* __[Malachi 01:01 Notes](./01.md)__
* __[Malachi intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Malachi 02

### Malachi 02:01

#### lay it on your heart

This refers to considering something to be very important. AT: "consider it to be very important" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### give honor to my name

The abstract noun "honor" can be stated as a verb. AT: "honor my name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### my name

Here this expression refers to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will send a curse on you

The abstract noun "curse" can be stated as a verb. AT: "I will curse you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### you are not laying my command on your heart

This refers to considering God's command to be very important. AT: "you are not considering my command to be very important" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Malachi 02:03

#### I will spread dung on your faces

Here "dung on your faces" stands for disgrace. AT: "I will most certainly put you in deep disgrace; it will be as bad as if I had spread dung on your faces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the dung from your festivals

Here "festivals" stands for the animals that the priests offered in sacrifice at the Israelite festivals. "The dung" probably refers both to the dung that was produced by the animals just before they were slaughtered for sacrifice, and to the dung that was found inside the animals when their bodies were cut apart before being sacrificed. Temple workers had to transport this dung to a place outside of the temple, and probably outside of Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he will take you away with it

This difficult expression can be translated as "God will take you away with it," that is, with the dung. This expression continues the same metaphor of slaughtering animals for sacrifice, and it can be put in active form. AT: "they will throw you on the dung pile; God will make sure that they take you away when they remove all the dung" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he will take you away with it

Possible meanings of this expression are 1) God will punish the unfaithful priests by killing them and causing their bodies to be carried away on the piles of animal dung, or 2) God will punish the unfaithful priests in such a horrible way that it will be as if their bodies had been carried away with the animal dung. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Levi

Here Levi represents his descendants, the tribe of Levi. AT: "so that my covenant may be with you, the descendants of Levi" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Malachi 02:05

#### General Information:

Yahweh speaks of the tribe of Levi as though they are Levi. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### My covenant with him was life and peace

Here the intended results of the covenant are spoken of as if they were the covenant itself. AT: "The purpose of my covenant with Levi was for the priests to live in prosperity and peace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fear, and he feared me

This expression continues the same metaphor, but leaves out an idea that is implied in the text. This can begin a new sentence. AT: "My covenant with him was also fear, and he feared me" or "In my covenant with him, I required him to fear me, and he did fear me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### in awe of my name

Here "my name" stands for God himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### nothing false was found

Here finding something stands for that thing existing. AT: "there was no falsehood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### on his lips

Here "lips" stands for a person's ability to speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He walked with me

Here walking stands for living, conducting one's life in a certain way. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in peace and uprightness

Here the idea of location stands for the manner in which Levi lived. AT: "peacefully and uprightly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he turned many away from sin

Here persuading people to stop sinning is spoken of as if it were turning them away from sin. AT: "he persuaded many people to stop sinning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For a priest's lips should keep knowledge

Here knowledge is spoken of as if it were an object that a priest could keep. In this passage, the idea of "keep knowledge" implies communicating true knowledge about God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lips

Here "lips" stands for a person's ability to speak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### seek instruction

Here instruction is spoken of as if it were an object that people could look for. This can be restated to remove the abstract noun "instruction." AT: "want to be instructed" or "want a priest to teach them truly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### from his mouth

Here "mouth" stands for what a person says. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Malachi 02:08

#### you have turned away from the true path

The right way to behave is spoken of as if it were the right path to follow, and abandoning right conduct is spoken of as if it were turning away from that path. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You have caused many to stumble

Disobeying God is spoken of as if it were stumbling. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You have caused many to stumble with respect to the law

The expression "with respect to the law" gives the context for the "stumbling." AT: "You have caused many to disobey the law"

#### before all the people

This spatial idea stands for the people's awareness of the priests' evil behavior. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### kept my ways

Here "ways" stands for "desires" and "behavior." These ways are spoken of as if they were things that could be kept by people. AT: "followed my desires in how you should live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### shown partiality with regard to the instruction

"set easy standards of behavior for people you like and difficult standards of behavior for people you do not like"

#### shown partiality

Here the habit of favoring some people more than others is spoken of as if it were a thing that could be shown to others. AT: "made people aware that you favor some people more than others (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/partial.md)]]

### Malachi 02:10

#### General Information:

Here the prophet Malachi begins to speak to his fellow Israelites.

#### Is there not one father for us all? Has not one God created us?

Malachi asks these questions in order to remind his fellow Israelites about what they already know. AT: "You know that we all have one father, that our God has created a nation out of us." or "You all know that God is the father of all us Israelites, because he is the one who made our nation." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Has not one God created us?

This question is meant to express a statement. AT: "Certainly it is the same God who has created us." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### created us

This probably refers to God forming the Hebrews into a nation.

#### Why are we faithless each man against his brother, profaning the covenant of our fathers?

Malachi asks this question in order to rebuke his fellow Israelites. This question may be expressed as a statement. AT: "We should certainly not mistreat our brothers and disrespect God's covenant by disobeying his commands, as you have been doing." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Judah has been faithless

Here "Judah" stands for the people in the region of Judah, and the fact that they have been faithless to Yahweh is spoken of as if they were one man named "Judah." AT: "The people of Judah have been faithless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### A disgusting thing has been committed in Israel and in Jerusalem

This can be expressed in active form. AT: "People have done disgusting things in Israel and in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For Judah has profaned the holy place of Yahweh

Here "Judah" refers again to the people of Israel. AT: "For the people of Judah have profaned the holy place of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has married the daughter of a foreign god

The people of Judah are again referred to as if they were one man named "Judah." AT: "have married women from other nations, women who worship idols" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### May Yahweh cut off from the tents of Jacob the man who

Destroying something is often spoken of as it were cutting it off from something else. AT: "May Yahweh destroy anyone in the tents of Jacob who" or "May Yahweh kill anyone in the community of Israel who" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the tents of Jacob

Here "tents of Jacob" stands for the community of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Jacob

Here "Jacob" stands for all the Israelites, because Jacob was one of the patriarchs from whom the Israelites were descended. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the one who is awake and the one who answers

This expression seems to mean "absolutely everyone." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]

### Malachi 02:13

#### General Information:

Malachi continues to speak to his fellow Israelites.

#### You cover the altar of Yahweh with tears

This sarcastically exaggerates the amount of tears the people cry to show that Yahweh knows that the people do not really feel sad. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### with weeping and sighing

The words "weeping" and "sighing" share similar meanings and intensify the idea of weeping. AT: "with great weeping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### does not turn toward the offering

Here turning toward a gift stands for receiving it and showing favor to the giver. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### does not turn toward the offering

This implies that those who are weeping at Yahweh's altar have offered sacrifices to him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from your hand

Here "hand" stands for the person giving the offering. AT: "from you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Malachi 02:14

#### Why does he not?

The full thought is "Why does he not turn toward the offering or accept it with favor from our hand?" (See: [Malachi 2:13](./13.md)) Some translators may decide to provide this entire thought in their versions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the wife of your youth

"the woman you married when you were young"

#### Yahweh was a witness between you and the wife of your youth

This statement assumes that this woman is still living. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### a witness between you and the wife of your youth

Here a witness to an agreement between two people is thought of as standing between them in order to testify about what they agreed to, in case a dispute arises between the two people. This sentence also was meant to remind the people that Yahweh would punish any Israelite who broke the covenant of marriage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Did he not make them one, with a portion of his spirit?

This question may be expressed as a statement. AT: "He certainly made husband and wife one, with a portion of his spirit." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### make them one

This expression implies making husband and wife one flesh. AT: "make husband and wife one flesh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### an offspring from God

Children who would honor and obey God.

#### she was your companion and your wife by covenant

This statement implies that many of the Israelites had divorced their wives. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### by covenant

"by the covenant of marriage that you agreed to"

#### I hate divorce

Here "divorce" stands for the act of divorce, when a man sends away his wife, so as to end his marriage to her. AT: "I hate it when a man divorces his wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the one who covers his garment with violence

This phrase probably means any man who is violent toward his wife. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### So guard yourselves in your spirit and do not be faithless

"So be careful to be loyal to your wife"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/offspring.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/offspring.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divorce.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divorce.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/offspring.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/offspring.md)]]

### Malachi 02:17

#### You have wearied Yahweh

Yahweh is spoken of as if human behavior could make him tired, but God cannot grow weary in a physical or emotional sense. This statement probably means that Yahweh has become offended or exasperated. AT: "You have offended Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### How have we wearied him?

This question is meant to deny that the people have done any wrong. This can be expressed as a statement. AT: "We have certainly not wearied him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### By saying

The complete idea here is, "You have wearied him by saying." This is the prophet's answer to the rhetorical question. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in the eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "in the opinion" or "in the judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Where is the God of justice?

The priests ask this question in order to claim either that Yahweh does not care whether people do evil or not, or that he never punishes evildoers. AT: "God certainly does not punish evil people!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the God of justice

the God who punishes evildoers justly

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Malachi 02:intro

#### Malachi 02 General Notes ####

####### Special concepts in this chapter #######

######## Levites ########
The priests are given a strong warning in this chapter. They have not followed the law of Moses and have led the people in the wrong direction. Yahweh has not accepted their sacrifices. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

######## Marital unfaithfulness ########
Because the Jews lived under a covenantal arrangement with Yahweh, their relationship is described using the imagery of a marriage. Marital unfaithfulness indicates a person's unfaithfulness to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unfaithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unfaithful.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) 

##### Links: #####

* __[Malachi 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Malachi 03

### Malachi 03:01

#### General Information:

Yahweh begins speaking again to the people of Israel in verse 1, but the prophet Malachi begins speaking in verse 2.

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you"

#### he will prepare the way before me

Here getting people ready to welcome Yahweh is spoken of as if a road were being cleared for Yahweh to travel on. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Then the Lord, whom you seek ... The messenger of the covenant in whom you delight

Some modern versions translate this in a way that implies that these two expressions refer to the same person. Other modern versions leave this matter ambiguous. We recommend that translations leave this matter ambiguous, as the ULB and UDB do.

#### The messenger of the covenant

Almost all versions leave ambiguous the sense of this expression. But translators may need to make explicit the relationship between "messenger" and "the covenant." The UDB presents "the messenger" as one promised by the covenant that Yahweh had with Israel. Another choice is to present the messenger as a person who will either confirm that covenant or announce a new covenant.

#### But who will be able to endure the day of his coming? Who will be able to stand when he appears?

These rhetorical questions imply that no one will be able to resist Yahweh when he comes. They can be combined into one statement. AT: "However, no one will be able to resist Yahweh when he comes to judge them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the day of his coming

Here "day" stands for "time." AT: "the time when he comes"

#### be able to stand

Here standing represents resisting someone's attack or accusations. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For he will be like a refiner's fire and like laundry soap

This sentence gives the reason why no one will be able to resist God when he comes. God's power to judge the people and to stop them from sinning is spoken of as if it were the power of strong soap to clean clothes, or the power of fire to melt an object. These are ways of saying that God's power to do these things cannot be stopped. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### he will purify the sons of Levi

Forgiving the sons of Levi and persuading them not to sin any longer is spoken of as if it were purifying metal. AT: "he will correct the sons of Levi and forgive them for having sinned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the sons of Levi

Here "sons" refers to descendants. The male descendants of Levi were the priests and workers in the temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He will sit

Here sitting implies the action of a metalworker, who sits down in order to purify small amounts of gold or silver. It also implies the action of a king, who sits down to judge people and give decrees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He will refine them like gold and silver

Here persuading people not to sin any longer is spoken of as if a metalworker were making gold and silver more pure. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they will bring offerings of righteousness to Yahweh

Here "of righteousness" means "motivated by righteous desires to worship God." AT: "they will bring acceptable offerings to Yahweh in order to worship Yahweh"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Malachi 03:04

#### General Information:

Malachi continues speaking in verse 4, but Yahweh begins speaking again in verse 5.

#### the offering of Judah and Jerusalem

Here "Judah" and "Jerusalem" stand for the people in those places. AT: "the offerings brought by the people of Judah and Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### as in the days of old, and as in ancient years

These two phrases mean basically the same thing and emphasize that the offering was once pleasing to Yahweh. AT: "as it was in the distant past" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Then I will approach you for judgment

Here "judgment" refers to the act of judging. AT: "Then I will approach you in order to judge you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### oppress the hired worker in his wages

"cause the hired worker to suffer by not paying him for his work"

#### turn away the foreigner

That is, turning away the foreigner from gaining his rights. Depriving people of their rights is spoken of as if it were physically turning them away from oneself. Perhaps the idea is turning away someone who comes for a wrong to be set right. AT: "deny foreigners living in Israel the rights that they should have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Malachi 03:06

#### General Information:

Yahweh continues to speak to the people of Israel.

#### have not come to an end

"have not perished"

#### From the days of your fathers you have turned aside from my ordinances and have not kept them

Disobeying God's ordinances is spoken of as if it were turning away from them. AT: "You have disobeyed my ordinances ever since the days of your ancestors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Return to me, and I will return to you

Here loving each other and being faithful to each other is spoken of as if it were returning to each other. AT: "Love me and honor me, and I will always help you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### How will we return?

The people ask this question in order to claim that they have never stopped obeying God. This can be expressed as a statement. AT: "We have never gone away from you, so we cannot return to you." or "We have never gone away from you, so it makes no sense to speak of us as returning to you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordinance.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordinance.md)]]

### Malachi 03:08

#### General Information:

Yahweh continues to speak to the people of Israel.

#### Would a person rob God?

This question implies that the idea of robbing God is very wicked. This can be expressed as a statement. God speaks of himself in the third person AT: "A man should certainly not rob God." or "No one should ever rob me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### How have we robbed you?

This question implies that the people do not think they have robbed God. AT: "We have certainly not robbed you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### In tithes and offerings

This reply from Yahweh implies a fuller answer. AT: "You have robbed me by withholding from me your tithes and offerings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You are cursed with a curse

This can be stated in active form. AT: "I have certainly cursed you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you are robbing me, the whole nation

Here "nation" stands for the people to whom Yahweh is speaking. AT: "all of you in the whole nation are robbing me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Malachi 03:10

#### General Information:

Yahweh continues to speak to the people of Israel.

#### the full tithe

"all the tithes"

#### my house

Here "house" stands for the temple. AT: "my temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### and test me now in this ... if I do not open to you the windows of heaven

Here the command "test me" stands for something that the people can do and should do: "if you test me." This can be divided into two sentences also. AT: "And if you test me ... I will open up the windows of heaven" or "And you should test me ... If you do, I will open up the windows of heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### All the nations will call you blessed

Here to be called blessed stands for being blessed. AT: "All the nations will know that you have been blessed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### All the nations

This expression stands for the people in all the nations. AT: "The people in all the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a land of delight

Here "delight" stands for the condition in which the inhabitants of a land take delight in their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Malachi 03:13

#### General Information:

These verses begin a new section in the book. Here Yahweh is speaking to the people of Israel.

#### Your words against me have been strong

Here "strong" stands for "harsh" or "terrible." And "Your words" stands for "What you have said." AT: "What you have said about me is terrible" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### What have we said among ourselves against you?

The people ask this question in order to claim that they have said nothing against God. This can be expressed as a statement. AT: "We have not said anything among ourselves against you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### What profit is it that we have kept his requirements or walked mournfully before Yahweh of hosts?

The people ask this question among themselves in order to make a statement. AT: "It is useless that we have kept his requirements and walked mournfully before Yahweh of hosts." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### walked mournfully before Yahweh of hosts

Here "walk mournfully" stands for "behave in a sorrowful manner," probably in order to indicate sorrow over their sins. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### before Yahweh of hosts

Here this expression refers to God being aware of what the people were doing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### we call the arrogant blessed

Here to be called "blessed" stands for being blessed. AT: "we say that the arrogant are blessed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### we call the arrogant blessed

This may be stated in active form. AT: "we say that the arrogant are well off" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### escape

That is, "they escape God's punishment." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/evildoer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/evildoer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]

### Malachi 03:16

#### General Information:

The event described here may have taken place after the godly people in Israel repented of their sins.

#### a book of remembrance was written before him about those who feared Yahweh

This can mean 1) the Israelites wrote a book so they would remember what they had promised and listed the names of people who feared Yahweh or 2) Yahweh caused someone in heaven to write a book with the names of people who feared him.

#### book of remembrance

This expression refers to any book that helps people remember important things, such as events or people who lived in the past. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### honored his name

Here "his name" stands for God himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Malachi 03:17

#### They will be mine

"They will be my people"

#### my own treasured possession

Here "possession" refers to one's personal property. This idea can be expressed with a verb. AT: "they will belong completely to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### I act

This expression refers to the time when Yahweh will judge and punish the rebellious Israelites, giving victory to the faithful Israelites. (See: [Malachi 4:1-3](../04/01.md))

#### distinguish between

"see a difference between" or "treat differently"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Malachi 03:intro

#### Malachi 03 General Notes ####

####### Special concepts in this chapter #######

######## Messiah ########
There are several prophecies in this chapter concerning the messiah and the one who comes before the messiah. At times, this chapter switches between prophesying about the first coming of the messiah and the second coming of the messiah without formal divisions between them. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical questions ########
Several rhetorical questions are used in this chapter to convince the reader of the truth of what he is saying and of their sin. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Malachi 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Malachi 04

### Malachi 04:01

#### see

"look" or "listen" or "pay attention to what I am about to tell you"

#### the day is coming, burning like a furnace

The disaster occurring at this time is spoken of as if the day itself were burning. God's judgment is often spoken of as if it were a fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### arrogant ... evildoers

See how you translated these wordsd in [Malachi 3:15](../03/13.md).

#### all the arrogant and all the evildoers will become stubble

These people are spoken of as if they will become dried-up plants fit only for being burned. It is common for the Bible to speak of people as if they were plants or trees. AT: "all the arrogant and all the evildoers will burn up like dry plants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The day that is coming will burn them up

Here "the day" stands for the events that will occur on that day. AT: "On that day I will burn them up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### it will leave them neither root nor branch

This expression continues to speak of people as if they were plants or trees. So being deprived of all roots and branches stands for being completely killed off. AT: "nothing will be left" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you who fear my name

Here "my name" stands for Yahweh himself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the sun of righteousness will rise with healing in its wings

This can mean 1) Yahweh, who always acts righteously, will come and heal his people on that day or 2) on that day Yahweh will reveal the people's righteousness and heal them.

#### healing in its wings

Possible meanings are 1) the act of healing someone is spoken of as if it were an object that the sun carried to people by means of its wings or 2) the healing takes place under the wings, that is, in the security God gives his people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wings

It was common in the Ancient Near East to speak of the sun as if it had wings, with which it moved across the sky. Possible meanings are 1) the sun's life-giving rays of light are spoken of as if they were its wings or 2) the wings are said to cover God's people so as to give them peace and safey. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You will go out, and you will leap like calves from the stall

Here the redeemed people of Yahweh are spoken of as if they were young bulls released from their stalls, allowed to go out into their pasture. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### you will trample down the wicked, for they will be ashes under the soles of your feet

Here the victory of God's people is spoken of as if they were walking over the burned bodies of their enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will be ashes

The Israelites' enemies are spoken of as having been burned to ashes. (See: [Malachi 4:01](./01.md))

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Malachi 04:04

#### Remember the teaching of my servant Moses that I gave him

The abstract noun "teaching" can be stated as "taught." AT: "Remember what I taught my servant Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Remember

Here "Remember" stands for "Think about" and, at the same time, "Obey."

#### Horeb

This is another name for Sinai.

#### all Israel

Here "all Israel" is a reference to all the people in the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the statutes

These are the laws that God gave Israel for all time.

#### the rulings

These are legal decisions meant to make clear how the general statutes apply to everyday life.

#### the coming of the great and fearful day of Yahweh

Here the occurrence of this day is spoken of as if it were coming. AT: "before the great and fearful day of Yahweh happens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the great and fearful day of Yahweh

This expression refers to any time in which Yahweh acts decisively.

#### He will turn the heart of the fathers to the children, and the heart of the children to their fathers

Here changing how people think is spoken of as if it were turning their hearts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Malachi 04:intro

#### Malachi 04 General Notes ####

####### Special concepts in this chapter #######

######## Last days ########
Although the Jews may have hoped these prophecies referenced a time in the near future to them, the prophecies of this chapter exclusively relate to the last days. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]])

##### Links: #####

* __[Malachi 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | __


## Malachi front

### Malachi front:intro

#### Introduction to Malachi ####

##### Part 1: General Introduction #####

####### Outline of Malachi #######

1. The authority of the prophecy: The word of Yahweh (1:1)
1. The love of Yahweh for Israel, and his rejection of Esau (Edom) (1:2–5)
1. A message against the priests (1:6–2:9)
1. A message against Judah: they have broken faith, in divorce and intermarriage (2:10–16)
1. A message about the day of judgment (2:17–3:6)
1. A message about the tithe (3:7–12)
1. A message about those who were treated shamefully by others, but who were faithful to Yahweh (3:13–18)
1. Encouragement to remember that Yahweh will punish the wicked and that he will send Elijah before the "great and terrible day of Yahweh" (4:5–6)

####### What is the Book of Malachi about? #######

The Book of Malachi is about the prophecies that Malachi spoke the Jews who had returned from Babylon to Judah. At this time, the Jews were discouraged even though they had completed building a new temple. The wonderful thing that previous prophets had promised for Judah had not yet happened. And the Persian Empire still ruled over them. As a result, they no longer were concerned about the law or worshiping God. Malachi rebuked them for not trusting in Yahweh. But he also promised them that Yahweh would do everything that he promised to do.

####### How should the title of this book be translated? #######

"The Book of Malachi" may also be called the "The Book about Malachi" or "The Sayings of Malachi." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Malachi? #######

The prophet named Malachi wrote these messages from Yahweh to the Jews. However, since "Malachi" means "my messenger," it is possible that this was a title for this prophet. If so, his real name is not known to us.

##### Part 2: Important Religious and Cultural Concepts #####

####### What was meant by the day of Yahweh? #######

Malachi spoke about "the day" several times. This is the same as "the day of Yahweh." In the Book of Malachi this expression referred when Yahweh would Yahweh would judge his people. He would remove those who are wicked and be a blessing to those who trusted in him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])



---

