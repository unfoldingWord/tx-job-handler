# <a id="jon"/>Jonah

## Jonah 01

### Jonah 01:01

#### the word of Yahweh came

This is an idiom that means Yahweh spoke. "Yahweh spoke his message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the word of Yahweh

"the message of Yahweh"

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### Amittai

This is the name of Jonah's father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Get up and go to Nineveh, that great city

"Go to the important city of Nineveh"

#### Get up and go

This is a common expression for traveling to distant places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### speak out against it

God is referring to the people of the city. AT: "warn the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### their wickedness has risen up before me

"I know they have been continually sinning"

#### got up to run away from the presence of Yahweh

"ran away from Yahweh." "got up" is referring to Jonah leaving where he was. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the presence of Yahweh

Here Yahweh is represented by his presence. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### go to Tarshish

"and went to Tarshish." Tarshish was in the opposite direction to Nineveh. This can be made explicit. AT: "went in the opposite direction, toward Tarshish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He went down to Joppa

"Jonah went to Joppa"

#### ship

A "ship" is a very large type of boat that can travel on the sea and carry many passengers or heavy cargo.

#### So he paid the fare

"There Jonah paid for the trip"

#### boarded the ship

"got on the ship"

#### with them

The word "them" refers to the others who were going on the ship.

#### away from the presence of Yahweh

Here Yahweh is represented by his presence. AT: "away from Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tarshish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tarshish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joppa.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joppa.md)]]

### Jonah 01:04

#### Soon it appeared

It can be made explicit who thought the ship would be broken up. AT: "The men thought" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to be broken up

This can be stated in active form. AT: "to break apart" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the sailors

the men who worked on the ship

#### his own god

Here "god" refers to false gods and idols that people worship.

#### They threw the ship's cargo

"The men threw the heavy things off the ship." This was done to keep the ship from sinking.

#### to lighten it

Making the ship lighter would make if float better. AT: "to help the ship float better"

#### But Jonah had gone down into the innermost parts of the ship

Jonah did this before the storm started.

#### down into the innermost parts of the ship

"inside the ship"

#### was lying there deeply asleep

"was lying there fast asleep" or "was lying there and sleeping deeply." For this reason, the storm did not wake him up.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md)]]

### Jonah 01:06

#### So the captain came to him and said to him

"The man in charge of the ship went to Jonah and said"

#### What are you doing sleeping?

"Why are you sleeping?" He used this rhetorical question to scold Jonah. AT: "Stop sleeping!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Get up!

This refers to doing some activity. For Jonah, the Captain is telling him to wake up and pray to his god for safe passage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Call upon your god!

"Pray to your god!" "Call" refers to getting the attention of someone. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Maybe your god will notice us and we will not perish

The implicit information that Jonah's god might save them could be made explicit. AT: "Maybe your god will hear and save us so that we will not die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They all said to each other

"The sailors all said to each other"

#### Come, let us cast lots, so that we may know who is the cause of this evil that is happening to us

"We should cast lots to know who has caused this trouble." The men believed that the gods would control how the lots fell in order to tell them what they wanted to know. This was a form of divination.

#### this evil

This refers to the terrible storm.

#### the lot fell to Jonah

"the lot showed that Jonah was the guilty person"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Jonah 01:08

#### Then they said to Jonah

"Then the men who were working on the ship said to Jonah"

#### Please tell us who is the cause of this evil that is happening to us.

"Who caused this bad thing that is happening to us?"

#### fear Yahweh

The word "fear" refers Jonah having a deep respecting God.

#### What is this that you have done?

The men on the ship used this rhetorical question to show how angry they were at Jonah. AT: "You have done a terrible thing." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### he was running away from the presence of Yahweh

Here Yahweh is represented by his presence. Jonah was seeking to escape Yahweh as if Yahweh was present only in the land of Israel. AT: "Jonah was running away from Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### because he had told them.

What he told them can be stated clearly. AT: "because he had said to them, 'I am trying to get away from Yahweh.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Jonah 01:11

#### they said to Jonah

"the men on the ship said to Jonah" or "the sailors said to Jonah"

#### do to you so that the sea will calm down

"do with you in order to make the sea become calm"

#### the sea became more and more violent

This was the reason that the men asked Jonah what they should do. This reason can also be put at the beginning of verse 11 as in the UDB.

#### for I know that it is because of me that this great storm is happening to you

"because I know this huge storm is my fault"

#### Nevertheless, the men rowed hard to get them back to the land

The men did not want to throw Jonah into the sea, so they rowed hard as if they were digging into the water to get back to land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the sea was becoming more and more violent

"the storm became worse, and the waves became bigger"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md)]]

### Jonah 01:14

#### Therefore

"Because of this" or "Because the sea became more violent"

#### they cried out to Yahweh

"the men prayed to Yahweh"

#### do not let us perish on account of this man's life

"Please do not kill us because we caused this man to die" or "We are going to cause this man to die. But please do not kill us"

#### do not lay upon us the guilt of his death

"please do not blame us for his death" or "do not consider us guilty when this man dies." The author speaks of "guilt" as if it were an object that can be placed on top of a person. It refers to making that person accountable for their actions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the sea stopped raging

"the sea stopped moving violently" or "the sea became calm"

#### feared Yahweh very much

"became greatly awed at Yahweh's power"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]

### Jonah 01:17

#### General Information:

Some versions number this verse as the first verse of chapter 2. You may want to number the verses according to the main version that your language group uses.

#### Now

This word is used in English to introduce a new part of the story.

#### three days and three nights

"three days and nights"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Jonah 01:intro

#### Jonah 01 General Notes ####

####### Structure and formatting #######

The narrative of this chapter starts abruptly. This could cause difficulty for the translator. The translator should not attempt to smooth this introduction unless absolutely necessary.

####### Special concepts in this chapter #######

######## Miracle ########

In verse [Jonah 17](./17.md), there is the mention of "a great fish." It may be difficult to imagine a sea creature big enough to swallow a man whole and who then survives for three days and nights inside. Translators should not try to explain miraculous events in an attempt to make it easier to understand. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]])

####### Important figures of speech in this chapter #######

######## Situational irony ########

There is an ironic situation in this chapter. Jonah is a prophet of God and should endeavor to do God's will. Instead, he is running away from God. Although the Gentile sailors are not Israelites, they act out of faith and fear of Yahweh when sending Jonah to a "certain death" by throwing him overboard. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## Sea ########

People in the ancient Near East also saw the sea as chaotic and did not trust it. Some of the gods they worshiped were gods of the sea. Jonah's people, the Hebrews, feared the sea greatly. However, Jonah's fear of Yahweh was not enough to keep him from going into a ship and sailing to get away from Yahweh. His actions are contrasted by the actions of the Gentiles. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]])

####### Other possible translation difficulties in this chapter #######

######## Implicit information ########

Even though scholars are not sure of the exact location of Tarshish, it was in the exact opposite direction of where God told Jonah to go. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Jonah 01:01 Notes](./01.md)__
* __[Jonah intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Jonah 02

### Jonah 02:01

#### Yahweh his God

This means "Yahweh, the God he worshiped." The word "his" does not mean that Jonah owned God.

#### He said

"Jonah said"

#### I called out to Yahweh about my distress

"I prayed to Yahweh about my great trouble." Even though Jonah was praying to Yahweh, he used Yahweh's name here and not "you." AT: "Yahweh, I called out to you about my distress"

#### he answered me

"Yahweh responded to me" or "he helped me"

#### from the belly of Sheol

"from the center of Sheol" or "from the deep part of Sheol." Possible meanings are 1) Jonah was speaking as being in the belly of the whale was being in Sheol or 2) Jonah believed that he was about to die and go to Sheol or 3) He spoke as if he already had died and gone there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]

### Jonah 02:03

#### General Information:

This is a continuation of Jonah's prayer that started in [Jonah 2:2](./01.md). In verse 4 Jonah spoke of something he had prayed before this prayer.

#### into the depths, into the heart of the seas

This speaks of the vastness of the ocean Jonah was in. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### into the heart of the seas

"to the bottom of the sea"

#### the currents surrounded me

"the sea water closed in around me"

#### waves and billows

These are disturbances on the surface of the ocean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### I am driven out

This can be stated in active form. AT: "You have driven me away" or "You have sent me away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from before your eyes

Here Yahweh is represented by his "eyes." AT: "from you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### yet I will again look toward your holy temple

Jonah has hope that, in spite of all he is going through, he will see the temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### Jonah 02:05

#### General Information:

This is a continuation of Jonah's prayer that started in [Jonah 2:2](./01.md).

#### The waters

"The waters" refers to the sea.

#### my neck

Some versions understand the Hebrew word in this expression to mean "my life." In that interpretation, the waters were about to take away Jonah's life.

#### the deep was all around me

"the deep water was all around me"

#### seaweed

"grass that grows in the sea"

#### the earth with its bars closed upon me forever

Jonah used a metaphor to compare the earth to a prison. AT: "the earth was like a prison that was about to lock me in forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yet you brought up my life from the pit

Jonah speaks of the place of the dead as if it were a pit. AT: "But you saved my life from the place of the dead" or "But you saved me from the place where the dead people are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh, my God!

In some languages, it may be more natural to put this at the beginning of the sentence or next to the word "you."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Jonah 02:07

#### General Information:

This is a continuation of Jonah's prayer that started in [Jonah 2:2](./01.md).

#### I called Yahweh to mind

Since Jonah was praying to Yahweh, it might be more clear in some languages to say "I thought about you, Yahweh" or "Yahweh, I thought about you."

#### then my prayer came to you, to your holy temple

Jonah speaks as if his prayers could travel to God and his temple. AT: "then you in your holy temple heard my prayer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They give attention to useless gods

"People pay attention to useless gods"

#### forsake loving faithfulness

"are rejecting you, who would be faithful to them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Jonah 02:09

#### General Information:

This is a continuation of Jonah's prayer that started in [Jonah 2:2](./01.md).

#### But as for me, I

This expression in English shows that there is a contrast between the people Jonah had just spoken about and himself. They paid attention to useless gods, but he would worship Yahweh. AT: "But I"

#### I will sacrifice to you with a voice of thanksgiving

This means that Jonah would thank God while he offered a sacrifice to him. It is not clear whether Jonah planned to thank God by singing or shouting joyfully.

#### Salvation comes from Yahweh

This can be reworded so that the abstract noun "salvation" is expressed as the verb "save." "Yahweh is the one who saves people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### upon the dry land

"upon the ground" or "onto the shore"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Jonah 02:intro

#### Jonah 02 General Notes ####

####### Structure and formatting #######

This chapter begins with a prayer by Jonah, and many translators have chosen to set it apart by indenting its lines. Translators can follow this practice, but they are not obligated to indent the lines. 

####### Special concepts in this chapter #######

######## Sea ########
This chapter contains many terms from the sea. 

####### Important figures of speech in this chapter #######

######## Poetry ########
Prayers in Scripture often contain a poetic form. Poetry frequently uses metaphors to communicate something with a special meaning. For example, since Jonah was in a fish in the sea, being trapped is compared to a prison. Jonah is overwhelmed by the depth of the sea and expresses this by speaking about the at the "base of the mountains" and in the "belly of Sheol." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) 

####### Other possible translation difficulties in this chapter #######

######## Repentance ########
Scholars are divided over whether Jonah's repentance was genuine or whether he was trying to save his life. In light of his attitude in chapter 4, it is uncertain if he was genuinely repentant. If possible, it is best for translators to avoid making a definitive stance on whether Jonah's repentance was genuine. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]])

##### Links: #####

* __[Jonah 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Jonah 03

### Jonah 03:01

#### The word of Yahweh came

This is an idiom that means Yahweh spoke. See how you translated this in [Jonah 1:1](../01/01.md). AT: "Yahweh spoke his message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the word of Yahweh

Here "word" represents Yahweh's message. AT: "the message of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Get up, go to Nineveh, that great city

"Go to the important city of Nineveh"

#### Get up

This refers to leaving the place one is at. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### proclaim to it the message that I command you to give

"tell the people what I tell you to tell them"

#### So Jonah got up and went to Nineveh in obedience to the word of Yahweh

"This time Jonah obeyed Yahweh and went to Nineveh"

#### So Jonah got up

"So Jonah left the beach." "got up" refers to leaving the place Jonah was at. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Now

This word is used here to mark a change from the story to information about Nineveh.

#### one of three days' journey

"a city of three days' journey." A person had to walk for three days to completely go through it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### Jonah 03:04

#### after a day's journey he called out

Possible meanings are 1) "after Jonah walked a day's journey he called out" or 2) "while Jonah walked on the first day, he called out."

#### after a day's journey

"after a day's walk." A day's journey is the distance that people would normally travel in one day. AT: "after Jonah walked for one day"

#### he called out and said

"he proclaimed" or "he shouted"

#### forty days

"40 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### They all put on sackcloth

Why people put on sackcloth can be stated more clearly. AT: "They also put on coarse cloth to show that they were sorry for having sinned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from the greatest of them down to the least of them

"from the most significant to the least significant people" or "including all the important people and all the unimportant people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]

### Jonah 03:06

#### the news

"Jonah's message"

#### He rose up from his throne

"He got up from his throne" or "He stood up from his throne." The king left his throne to show that he was acting humbly.

#### throne

A throne is a chair that the king sits on. It shows that he is the king.

#### He sent out a proclamation that said

"He sent out an official announcement that said" or "He sent his messengers to announce to the people in Nineveh"

#### nobles

"advisors." These were important men who helped the king rule the city.

#### herd nor flock

This refers to two kinds of animals that people care for. AT: "cattle or sheep"

#### Let them not eat, nor drink water

"They must not eat nor drink anything." The reason they were not to eat or drink anything can be made explicit by adding "in order to show that they are sorry for their sins." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Jonah 03:08

#### General Information:

This is a continuation of what the king told the people of Nineveh.

#### But let both

"Let both"

#### let both man and animal be covered with sackcloth

This can be stated in active form. AT: "let people and animals wear sackcloth" or "let people cover themselves and their animals with sackcloth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### animal

The word "animal" refers to animals that people own.

#### cry out loudly to God

"pray earnestly to God." What they were to pray for can be made explicit. AT: "cry out loudly to God and ask for mercy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the violence that is in his hands

This means "the violent things that he does"

#### Who knows?

The king used this rhetorical question to get the people to think about something that they might not have thought possible, that if they would stop sinning, God might not kill them. It could be translated as a statement: "We do not know." Or it could be stated as a word and be part of the next sentence: "Perhaps." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### God may relent and change his mind

"God may decide to do something different" or "God may not do what he said he will do"

#### we do not perish

"we do not die." Here perish equates to drowning at sea.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Jonah 03:10

#### God saw what they did

"God understood that they stopped doing evil actions"

#### they turned from their evil ways

The author speaks of the people stop sinning as if they turned their back to an object. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### God changed his mind about the punishment that he had said he would do to them

Here God deciding not to do the punishment he had planned is spoken of is if he changed his mind. AT: "God changed his thinking about the punishment that he had said he would do to them" or "God decided not to punish them as he had said he would" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he did not do it

What God was to do can be made explicit. AT: "he did not punish them" or "he did not destroy them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Jonah 03:intro

#### Jonah 03 General Notes ####

####### Structure and formatting #######

This chapter returns to a narrative of Jonah's life.

####### Special concepts in this chapter #######

######## Animals ########
According to the king's proclamation, the animals had to participate in the fast he ordered. This most likely reflects their pagan mindset. There was nothing in the law of Moses that instructed the people to have the animals participate in any religious acts. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Other possible translation difficulties in this chapter #######

######## Size of Nineveh ########
When the author talks about the size of Nineveh, the measurements he gives are confusing. The phrase "three days' journey" is ambiguous in Hebrew, as many scholars have remarked. In Jonah's day, cities were not as big as they are today. So although Nineveh was a big city, it was not as big as most modern cities. 

######## God repenting or relenting ########
The last verse of this chapter says, "So then God changed his mind about the punishment that he had said he would do to them, and he did not do it." This concept of God changing His mind may be troubling for some translators and people may struggle to understand it. God's character is consistent. This whole book is written from a human viewpoint and so it is hard to understand the mind of God. 

Yahweh is just and merciful so even though God did not follow through with a judgment in this instance, God's plan is always to punish evil. Later in history this nation did fall and was destroyed.  (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]] and  [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

##### Links: #####

* __[Jonah 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Jonah 04

### Jonah 04:01

#### Ah, Yahweh

The word "Ah" expresses Jonah's feeling of frustration.

#### is this not just what I said when I was back in my own country?

Jonah used this rhetorical question to show God how angry he was. Also, what Jonah said when he was back in his own country can be stated explicitly. AT: "When I was still in my own country I knew that if I warned the people of Nineveh, they would repent, and you would not destroy them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I acted first and tried to flee to Tarshish

Possible meanings are 1) "I tried to prevent this by fleeing to Tarshish" or 2) "I acted quickly and tried to flee to Tarshish" or 3) "I did all I could to flee to Tarshish."

#### abounding in covenant faithfulness

"very faithful" or "you love people very much"

#### you hold back from sending disaster

This means "you say that you will send disaster on sinners, but then you decide not to." AT: "you decide not to punish people who sin"

#### take my life from me

Jonah's reason for wanting to die can be stated explicitly. AT: "since you will not destroy Nineveh as you said you would, please allow me to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for it is better for me to die than to live

"I would prefer to die than live" or "because I want to die. I do not want to live"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tarshish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tarshish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Jonah 04:04

#### Is it good that you are so angry?

God used this rhetorical question to scold Jonah for being angry about something he should not have been angry about. AT: "Your anger is not good." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### went out of the city

"left the city of Nineveh"

#### what might become of the city

"what would happen to the city." Jonah wanted to see if God would destroy the city or not destroy it.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Jonah 04:06

#### over Jonah so that it might be a shade over his head

"over Jonah's head for shade"

#### to relieve his distress

"to protect Jonah from the heat of the sun"

#### But God prepared a worm

"God sent a worm"

#### It attacked the plant

"The worm chewed the plant"

#### the plant withered

The plant became dry and died. AT: "the plant died"

### Jonah 04:08

#### God prepared a hot east wind

God caused a hot wind from the east to blow on Jonah. If wind can only mean a cool or cold wind then you can try this. AT: "God sent a very hot warmth from the east to Jonah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the sun beat down

"the sun was very hot"

#### on Jonah's head

Jonah may have felt the heat most on his head. AT: "on Jonah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he became faint

"he became very weak" or "he lost his strength"

#### It is better for me to die than to live

"I would prefer to die than live" or "Because I want to die. I do not want to live." See how you translated this in [Jonah 4:3](./01.md).

#### Is it good that you are so angry about the plant?

God challenges Jonah for being angry that the plant died and yet wanted God to kill the people of Nineveh. AT: "Your anger about the plant dying is not good." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is it good that you are so angry about the plant?

implicit information can be made explicit. AT: "You should be more concerned about the people in Nineveh dying than about the plant dying." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It is good that I am angry, even to death.

"It is good that I am angry. Now I am angry enough to die!"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonah.md)]]

### Jonah 04:10

#### Yahweh said

It may be helpful to say that Yahweh was speaking to Jonah. AT: "Yahweh said to Jonah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### should I not have compassion for Nineveh, that great city ... cattle?

God used this question to emphasize his claim that he should have compassion on Nineveh. AT: "I certainly should have compassion for Nineveh, that important city ... cattle." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### in which there are more

This can also be the beginning of a new sentence. AT: "There are more" or "It has more"

#### one hundred and twenty thousand people

120,000 people (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### who do not know the difference between their right hand and their left hand

This may be a way of saying "they cannot tell the difference between right and wrong."

#### also many cattle

The author is pointing out the depth of Nineveh's repentance to the extent that Yahweh takes note of the beasts' participation in the act of repentance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]

### Jonah 04:intro

#### Jonah 04 General Notes ####

####### Structure and formatting #######

Jonah continues the narrative while bringing the book to what seems like an unusual end. This emphasizes that the book is not really about Jonah. It is about God's desire to be merciful on anyone, whether Jew or pagan. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]) 

####### Special concepts in this chapter #######

######## Jonah's anger ########
It is important to see the relationship between a prophet and Yahweh. Aprophet was to prophesy for Yahweh, and his words must come true. According to the law of Moses, if that did not happen, the penalty was death. When Jonah told the city of Nineveh that it was going to be destroyed in forty days, he was certain it was going to happen. When it did not happen, Jonah was angry with God because he hated the people of Nineveh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical questions ########
As in other places, Jonah asks rhetorical questions to show how angry he was at Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

######## Parallel to Mount Sinai ########
In verse 2, Jonah attributes a series of characteristics to God. A Jewish reader of this book would recognize this as a formula Moses used in speaking about God when he was meeting God on Mount Sinai.  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Other possible translation difficulties in this chapter #######

######## God's grace ########
When Jonah went outside the city, he got very hot and God graciously provided some relief through the plant. God was trying to teach Jonah through an object lesson. It is important for the reader to see this clearly. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]])

##### Links: #####

* __[Jonah 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | __


## Jonah front

### Jonah front:intro

#### Introduction to Jonah ####

##### Part 1: General Introduction #####

####### Outline of the Book of Jonah #######

1. Jonah tries to run away from Yahweh
    - Jonah's first call from Yahweh to go to Nineveh and his disobedience (1:1–3)
    - Jonah and the Gentile sailors (1:4–16)
    - Yahweh provides a large fish to swallow Jonah (1:17)
    - Jonah's prayer from inside the large fish and his rescue (2:1–10)
    - Jonah's experience in Nineveh
    - Jonah is called by God a second time to go to Nineveh, and he begins to proclaim God's message (3:1–4)
    - All the people in Nineveh repent (3:5)
    - The proclamation of the king of Nineveh (3:6–9)
    - Yahweh decides not to destroy Nineveh (3:10)
    - Jonah is very angry at Yahweh (4:1–3)
    - Yahweh teaches Jonah about grace and mercy (4:4–11)

####### What is the Book of Jonah about? #######

This book is a narrative about the prophet Jonah. The purpose of this book is to tell how God showed mercy and grace to Gentiles.
It also tells how the Ninevites were willing to repent and to call out to Yahweh for mercy. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]], and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]])

God sent Jonah to warn the people of Nineveh that he was about to punish them. God said that if they would repent he would not harm them. However, Jonah was an Israeite and he did not want God to forgive the Ninevites. So, he tried to sail away in the opposite direction instead of doing what God told him to do. But, God stopped him by sending a large fish to swallow him. 

Eventually, Jonah repented and went to warn the Ninevites. As a result, God taught him a lesson about his love for all human beings, not just the Israelites.

####### How should the title of this book be translated? #######

Translators may decide to translate this traditional title "The Book of Jonah" in a way that is clearer to the readers. They may decide to call it, "The Book about Jonah." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Jonah? #######

The author of the Book of Jonah is unknown. The prophet Jonah lived in the northern kingdom of Israel. He prophesied sometime between 800-750 B.C. during the reign of King Jeroboam II.

##### Part 2: Important Religious and Cultural Concepts #####

####### What was the nation of Assyria? #######

During the time of Jonah, Assyria was the most powerful kingdom in the ancient Near East. It was known for its cruelty to its enemies. Eventually, God punished the Assyrians for the wicked things they did.

####### Did Assyria convert to Judaism? #######

Some scholars think that the Assyrians started worshipping Yahweh alone. However, most scholars think they continued to worship other false gods. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])



---

