# <a id="est"/>Esther

## Esther 01

### Esther 01:01

#### In the days of Ahasuerus

"In the time of Ahasuerus" or "When Ahasuerus was ruling as king"

#### this is Ahasuerus who reigned from India as far as Cush, over 127 provinces

This is background information to help the reader identify Ahasuerus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government.

#### sat on his royal throne

Here "royal throne" may refer to his rule over the kingdom. AT: "ruled the empire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### fortress

This refers to a castle, stronghold or fortified city.

#### Susa

This was a royal city of Persian kings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]

### Esther 01:03

#### In the third year of his reign

"After he had ruled for 2 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### The army

This likely refers to the leaders of the army. AT: "The officers of the army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the wealth of the splendor of his kingdom

These words have similar meaning and emphasize how great his kingdom was. AT: "the great wealth of his kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the honor of the glory of his greatness

These words have similar meaning and emphasize how great he was. AT: "the splendor of his greatness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### 180 days

"one hundred and eighty days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Esther 01:05

#### When these days were completed

"At the end of that feast"

#### a feast lasting seven days

This was a second feast that was only for the officials in Susa. AT: "another feast that lasted seven days"

#### seven

"7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### fortress

This refers to a castle, stronghold or fortified city.See how you translated this in [Esther 1:1](./01.md).

#### Susa

See how you translated the name of this place in [Esther 1:2](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### a mosaic pavement

A "mosaic" consists of colored stones arranged in an attractive pattern.

#### porphyry

This is a kind of red and purple rock that contained pieces of crystal.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Esther 01:07

#### Drinks were served in golden cups

This can be stated in active form. AT: "The guests drank wine from gold cups" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### there was much royal wine that came because of the king's generosity

"the king was very generous with the royal wine"

#### generosity

"great willingness to give"

#### There must be no compulsion

"No one must be forced to drink"

#### The king had given orders to all the staff of his palace to do for them whatever each guest desired

This statement means that the king told his workers to give all the guests as much wine as they wanted.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Esther 01:09

#### On the seventh day

"After 6 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the king's heart was feeling happy because of the wine

Here "heart" refers to the king, and "feeling happy" is an idiom that means he was drunk. AT: "the king was drunk with wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Mehuman, Biztha, Harbona, Bigtha, Abagtha, Zethar, and Karkas

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the seven officials who served before him

This is background information to explain who these men were. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### her features were stunning

"she was very beautiful"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]

### Esther 01:12

#### at the word of the king that had been brought to her by the officials

This can be stated in active form. AT: "when the king's officials told her about his command" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### at the word

"at the command"

#### his rage burned within him

The intensity of the king's anger is spoken of as if it was a fire that burned inside him. AT: "his rage was as intense as a fire inside him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

### Esther 01:13

#### who understood the times

"who understood the things that happened in their lives"

#### for this was the king's procedure toward all who were expert in law and judgment

This background information explains why the king called these men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Karshena, Shethar, Admatha, Tarshish, Meres, Marsena, and Memukan

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### seven

"7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### In compliance with the law ... by the officials?

It may be helpful to state who asked this question. AT: The king said to them, "In compliance with the law ... by the officials?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### In compliance with the law

"In observance of the law" or "In obedience to the law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### Esther 01:16

#### Memukan

Translate his name as in [Esther 1:14](./13.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### all the officials and all the people ... all the provinces ... all women

These are exaggerations to emphasize the damage that the queen's refusal caused. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](./01.md).

#### There will be much contempt and anger

"They will be angry with their husbands and treat them with contempt"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]

### Esther 01:19

#### Connecting Statement:

Meremoth continues to answer the king.

#### If it pleases the king ... from him ... before him ... Let the king ... the king's decree ... his vast kingdom

Meremoth speaks to the king in third person as a form of respect. AT: If it pleases your Majesty ... from you ... before you ... Please ... your decree ... your vast kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### which cannot be repealed

This can be stated in active form. AT: "which no one can change" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### When the king's decree is proclaimed

This can be stated in active form. AT: "When they hear the king's decree" or "When they hear what you have commanded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### vast

"big" or "huge"

#### from the greatest to the least significant

This is a merism that refers to both extremes and everyone in between. This probably refers to the husbands, but it is possible that it refers to the wives. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]

### Esther 01:21

#### Memukan

Translate his name as in [Esther 1:14](./13.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### province

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](./01.md).

#### every man should be master of his own household

"all men should have complete authority over their wives and their children"

#### This decree was given

This can be stated in active form. AT: "They wrote this decree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Esther 01:intro

#### Esther 01 General Notes ####

####### Special concepts in this chapter #######

######## The king's divorce ########

The king's advisers were afraid that husbands would lose their authority when they heard the queen had refused to come to show her beauty to the king's guests; so the advisers told him to divorce her.

##### Links: #####

* __[Esther 01:01 Notes](./01.md)__
* __[Esther intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Esther 02

### Esther 02:01

#### After these things

This introduces a new event that happened a while later. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### the anger of King Ahasuerus subsided

"the king became less angry"

#### the decree

This is refers to the decree in [Esther 1:19-20](../01/19.md).

#### Let a search be made

This can be stated in active form. AT: "Tell your servants to search" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on the king's behalf

The men speak to the king in the third person as a sign of respect. AT: "on your behalf" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]

### Esther 02:03

#### Connecting Statement:

The young servants continue to speak to the king.

#### Let the king ... the king's official ... pleases the king

The servants spoke to the king in third person as a sign of respect. AT: "You should ... your official ... pleases you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### harem

"place where a ruler's wives are kept"

#### the fortress

This refers to a castle, stronghold or fortified city. See how you translated this in [Esther 1:2](../01/01.md).

#### Susa

See how you translated the name of this place in [Esther 1:2](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Let them be put under the care of Hegai, the king's official, who is in charge of the women

This can be stated in active form. AT: "Let Hegai, the king's official, who is in charge of the women, take care of them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Hegai

This is a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### their cosmetics

A "cosmetic" is a substance such as a cream, lotion, or powder that women usually put on their face or body to improve their appearance.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md)]]

### Esther 02:05

#### There was a certain Jew

This introduces Mordecai as a new character in the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### Susa

Translate the name of this city as in [Esther 1:2](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### son of Jair son of Shimei son of Kish

"Jair," "Shimei," and "Kish" are men from whom "Mordecai" is the male descendant. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### a Benjamite

"of the tribe of Benjamin"

#### He had been taken away ... king of Babylonia carried away

This background information explains how Mordecai came to live in Susa. This can be stated in active form. AT: "Nebuchadnezzar king of Babylonia carried him and other exiles away along with Jehoiachin, king of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He had been taken away from Jerusalem

The Hebrew text leaves unclear who is being spoken of here. It is perhaps Kish, who seems to have been the great-grandfather of Mordecai. If it was Mordecai himself, then he would be extremely old at the time of the events concerning Esther. Many modern versions leave this matter unclear. A few versions, including the UDB, choose to assume that it was Mordecai who had been taken away from Jerusalem.

#### Jehoiachin, king of Judah

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoiachin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoiachin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]

### Esther 02:07

#### Connecting Statement:

This continues the background information about Mordecai and explains his relationship to Esther. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Hadassah

This is Esther's Hebrew name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### his uncle's daughter

"his cousin"

#### she had neither father nor mother

"her father and mother had died"

#### took her as his own daughter

"cared for her as if she was his own daughter"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]

### Esther 02:08

#### When the king's order and decree were proclaimed

This can be stated in active form. AT: "After the king commanded that they search for some beautiful women" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### proclaimed

"announced"

#### many young women were brought

This can be stated in active form. AT: "they brought many young women" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They were put under Hegai's care

This can be stated in active form. AT: "Hegai began to take care of them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Esther also was taken into the king's palace and put under the care of Hegai, the overseer of the women

This can be stated in active form. AT: "Hegai, the overseer of the women, also began to take care of Esther when they brought her to the king's palace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### palace

See how you translated this in [Esther 1:5](../01/05.md).

#### The young girl pleased him, and she found favor with him

These two phrases mean the same thing and emphasize how much she pleased him. AT: "The young girl greatly pleased him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### The young girl

"Esther"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Esther 02:10

#### about Esther's welfare

"how Esther was doing" or "about Esther's well-being"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]

### Esther 02:12

#### General Information:

Verses 12-14 are background information about the customs for the women who became the king's wives. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### complying with the regulations for the women

"acting in accordance with the requirements for the women"

#### beauty treatments

Things done to make the girls look more beautiful and smell good.

#### cosmetics

Use the same word or phrase used in [Esther 2:3](./03.md).

#### whatever she desired was given to her

This can be stated in active form. AT: "she could take whatever she desired" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### palace

See how you translated this in [Esther 1:5](../01/05.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]

### Esther 02:14

#### Connecting Statement:

This continues the background information that began in [Esther 2:12](./12.md) about the customs for the women who became the king's wives. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### in the morning

It is implied that this is the following morning. This information can be made clear. AT: "the next morning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### second house

"a different house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### custody

"supervision" or "protection"

#### Shaashgaz

This is a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]

### Esther 02:15

#### Now when the time came

This introduces a new part of the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### daughter of Abihail, the uncle of Mordecai, who had taken her as his own daughter

This background information reminds the reader of Esther's relationship to Mordecai. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### Abihail

Esther's father and Mordecai's uncle (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### she did not ask for anything but what

This can be stated in positive form. AT: "she asked only for what"

#### Hegai

See how you translated this man's name in [Esther 2:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### received the favor of all

This is an idiom. AT: "pleased all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the tenth month, which is the month of Tebeth

"Tebeth" is the name of the tenth month of the Hebrew calendar. It is during the last part December and the first part January on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### seventh year

"year number 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]

### Esther 02:17

#### The king loved

This is the romantic use of the word "love."

#### received acceptance and favor before him

These idioms mean the same thing and emphasize how much the Esther pleased the king. AT: "greatly pleased him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### set the royal crown on her head

The king did this to show that he was making her his queen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### "Esther's feast,"

It may be helpful to state that this is the name of the feast. AT: "he called it, 'Esther's feast,'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### taxation

"the collection of taxes"

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### royal generosity

"generosity that only a king can give"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/vashti.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md)]]

### Esther 02:19

#### when the virgins had been gathered together a second time

It is unclear when this second gathering happened, and why. Therefore some versions have altered the text somewhat. It is probably best to translate it as it is written.

#### a second time

"one more time" or "an additional time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Mordecai was sitting at the king's gate

Possible meanings are 1) Mordecai sat there so he could hear how Esther was doing from the many people who passed through the gate or 2) "sitting at the king's gate" is an idiom that means Mordecai was given a position of authority by the king.

#### the king's gate

"the gate to the king's palace"

#### as Mordecai had instructed her

Mordecai told her not to tell anyone about her family.

#### In those days

This introduces a new event in the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### Bigthana and Teresh

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]

### Esther 02:22

#### When the matter was revealed to Mordecai

This can be stated in active form. AT: "When Mordecai learned about what they were planning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the name of Mordecai

This is an idiom. AT: "on behalf of Mordecai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The report was investigated and confirmed, and both the men were hanged

This can be stated in active form. AT: "The king investigated and confirmed the report, and ordered his servants to hang both men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a gallows

This was a structure used for killing people by tying one end of a rope around the top of the structure and the other end of the rope around their necks and hanging them from it. AT: "a frame for hanging people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### This account was written

This can be stated in active form. AT: "They recorded this account" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Esther 02:intro

#### Esther 02 General Notes ####

####### Special concepts in this chapter #######

######## Esther becomes queen ########

Esther was humble and took the advice of the royal officials about how to dress for her time with the king.  The king chose Esther to be the new queen. 

######## Mordecai warns the king against a plot ########

Esther's cousin, Mordecai, discovered that two men planned to kill the king. He told Esther, who then told the king. She also gave Mordecai credit for telling her.

##### Links: #####

* __[Esther 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Esther 03

### Esther 03:01

#### After these things

This introduces a new event in the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### Haman son of Hammedatha the Agagite

This is the name and description of Haman, one of the king's officials. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### placed his seat of authority above all the officials who were with him

Here "seat of authority" represents his position or status in the government. AT: "promoted him above the other officials" or "gave him more authority than all the other officials" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### knelt ... prostrated

These acts represent submission to the authority of Haman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### prostrated themselves to Haman

"humbled themselves and lay flat on the ground before Haman"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Esther 03:03

#### to see if the matter about Mordecai would remain like that

"to find out what Haman would do about Mordecai's actions"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Esther 03:05

#### did not kneel and bow down

Mordecai showed disrespect for Haman's status in the government by not doing these actions. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### Haman was filled with rage

Here Haman's rage is spoken of as something that could fill him up. AT: "Haman became very angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He had contempt for the idea of killing only Mordecai

"He rejected the idea of killing just Mordecai." This can also be stated in positive form. AT: "He decided to kill more than just Mordecai"

#### exterminate all the Jews

"get rid of all the Jews" or "kill all the Jews"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]

### Esther 03:07

#### In the first month

"In month one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### which is the month of Nisan

"Nisan" is the name of the first month of the Hebrew calendar. It is during the last part of March and the first part of April on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in the twelfth year of King Ahasuerus

"in year number 12 of King Ahasuerus" or "when King Ahasuerus had reigned for about twelve years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the Pur—that is the lot—was thrown

"they cast the Pur—that is the lot—" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the twelfth month

"month twelve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the month of Adar

"Adar" is the name of the twelfth and last month of the Hebrew calendar. It is during the last part of February and the first part of March on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]

### Esther 03:08

#### a certain people

"a group of people" This refers to the Jews as an ethnic group.

#### scattered and distributed

"who live in many different places"

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### the king's ... the king

Haman speaks to the king in the third person as a sign of respect. AT: "your ... you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### it is not suitable for the king to let them stay

"the king should not let them remain." This can also be stated in positive form. AT: "the king should remove them"

#### I will weigh out ... into the hands of those

Here "hands" stands for the men. To "weigh out" is an idiom that means to pay them. AT: "I will pay ... to the men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### ten thousand talents of silver

"330 metric tons of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Esther 03:10

#### signet ring

a special ring that could be used to imprint the king's official seal on a proclamation

#### I will see that the money is given back to you

The meaning of this phrase is not clear. Possible meanings are 1) "I will return the money to you" or 2) "Take the money and give it to the men just as you have said." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Esther 03:12

#### the king's scribes were summoned ... a decree containing all that Haman had commanded was written

This can be stated in active form. AT: "the king summoned his scribes ... they wrote a decree containing all that Haman had commanded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### thirteenth day of the first month

This is the first month of the Hebrew calendar. The thirteenth day is near the beginning of April on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### king's provincial governors

"governors of the provinces." Translate "province" as in [Esther 1:1](../01/01.md).

#### It was written in the name of King Ahasuerus and was sealed with his ring

This can be stated in active form. AT: "They wrote the decree in the name of King Ahasuerus and Haman sealed it with the king's signet ring" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the name of

Here "name" represents the authority of the king. AT: "in the authority of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hand-delivered

This idiom means they personally delivered the letters. AT: "personally delivered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### annihilate, kill, and destroy

These words mean the same thing and emphasize the completeness of the destruction. AT: "completely destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### thirteenth day of the twelfth month

"day thirteen of month twelve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### which is the month of Adar

"Adar" is the name of the twelfth and last month of the Hebrew calendar. The thirteenth day is near the beginning of March on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### plunder

"take away"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Esther 03:14

#### A copy of the letter was made law in every province

This can be stated in active form. AT: "The officials in every province made a copy of the letter become the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### province

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### In every province it was made known to all the people

This can be stated in active form. AT: "They told all the people in every province" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this day

"that day"

#### The decree was also distributed

This can be stated in active form. AT: "They also distributed the decree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the fortress

This refers to a castle, stronghold or fortified city. See how you translated this in [Esther 1:2](../01/01.md).

#### Susa

See how you translated the name of this place in [Esther 1:2](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### was in turmoil

"was in a state of great confusion"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Esther 03:intro

#### Esther 03 General Notes ####

####### Special concepts in this chapter #######

######## Haman plots against the Jews ########

Mordecai considered prostrating himself before Haman. This would be considered to be worship. It was wrong to worship someone other than Yahweh. Because of this, he refused to do it on religious grounds. This made Haman angry  so he decided to kill all the Jews in the Persian Empire.

##### Links: #####

* __[Esther 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Esther 04

### Esther 04:01

#### learned of all that had been done

"found out about those letters"

#### tore his clothes and put on sackcloth and ashes

These acts are signs of severe sadness. AT: "tore his clothes and put on sackcloth and ashes to show his grief" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### province

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### there was great mourning among the Jews

"the Jews mourned greatly"

#### Many of them lay in sackcloth and ashes

"Many of them were on the ground, dressed in sackcloth and sitting in ashes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]

### Esther 04:04

#### young women and her servants

"female servants and male servants"

#### to clothe Mordecai

"for Mordecai to wear"

#### Hathak

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### one of the king's officials who had been assigned to serve her

This can be stated in active form. AT: "one of the officials whom the king had assigned to serve her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Esther 04:06

#### Hathak

See how you translated this man's name in [Esther 4:5](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the city square

"the city plaza"

#### Haman

See how you translated this man's name in [Esther 3:1](../03/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He also gave him

"Mordecai also gave Hathak"

#### to beg for his favor

"to beg for the king's favor"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]

### Esther 04:09

#### if any man or woman goes to the king ... the king holds out the golden scepter

This conditional clause can be expressed as a statement. It may also be helpful to divide it into two sentences. AT: "no man or woman is allowed to go to the king inside the inner courtyard unless the king summons them. The person who breaks this law will be executed unless the king holds out his golden scepter to him"

#### thirty days

"30 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Esther 04:13

#### relief and rescue will rise up for the Jews from another place

Here "relief" and "rescue" are spoken of as if they are living things that can rise up. AT: "someone else will rise up from another place and rescue the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Who knows whether you have come to this royal position for such a time as this?

The purpose of this question is to have Esther think deeply about her role in this situation. AT: "Who knows, perhaps it was for just for a time like this that you were made queen." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]

### Esther 04:15

#### Susa

See how you translated the name of this place in [Esther 1:2](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### fast for me ... will fast

Fasting was a symbolic act that the Jews did when they were praying intensely. This can be made explicit. AT: "fast and pray for me ... will fast and pray" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### three days

"3 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Esther 04:intro

#### Esther 04 General Notes ####

####### Special concepts in this chapter #######

######## Mordecai warns Esther to act ########

Mordecai tells Esther she must beg the king for the Jews' lives, even if she risks her own death. 

####### Other possible translation difficulties in this chapter #######

######## Implicit information ########

There is implicit information translators may not understand. "Who knows whether you have come to this royal position for such a time as this?"  This means "maybe God made you the queen so you could save the Jews." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Esther 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Esther 05

### Esther 05:01

#### facing the entrance to the house

"across the room from the entrance of the house" or "looking toward the entrance to the house"

#### she received approval in his eyes

The word "eyes" refers to his sight and is a metaphor for his evaluation of her. This can be stated in active form. AT: "he was pleased with her" or "he approved of her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He held out to her the golden scepter in his hand

He did this to show that he he was pleased with her.

#### touched the tip of the scepter

She probably did this to to show that she respected his authority and was thankful for his kindness to her.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md)]]

### Esther 05:03

#### Up to half of my kingdom, it will be given to you

This can be stated in active form. AT: "If you ask for up to half of my kingdom, I will give it to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### If it pleases the king, let the king and Haman come ... for him

In order to show respect to a king, people sometimes did not call him "you." This can be translated with the word "you" along with other words that show respect. AT: "O King, if it pleases you, come and bring Haman ... for you" or "If you are willing to do this, Sir, come, and let Haman come with you .. for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Haman

See how you translated this man's name in [Esther 3:1](../03/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Esther 05:05

#### What is your petition

The abstract noun "petition" can be expressed with the verb "ask for" or "want"? AT: "What do you ask for" or "What do you want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### It will be granted you

This can be expressed in active form. AT: "I will give you what you ask for" or "I will do for you what you ask" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### What is your request

The abstract noun "request" can be expressed with the verb "ask for" or "want"? AT: "What do you ask for" or "What do you want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Up to half of the kingdom, it will be granted

This can be stated in active form. AT: "If you ask for up to half of my kingdom, I will give it to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Esther 05:07

#### My petition and my request

The words "petition" and "request" mean the same thing. She probably used these words together as a way of speaking very formally and respectfully to the king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### if I have found favor in the eyes of the king and if it pleases the king

In order to show respect to a king, people sometimes did not call him "you." This can be translated with the word "you" along with other words that show respect. AT: "if you are pleased with me, O King, and if it pleases you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### if I have found favor in the eyes of the king

"Find favor" here is an idiom that means be approved of or that he is pleased with her. "In the eyes of the king" is a metaphor representing his evaluation. AT: "if the king evaluates me and approves" or "if the king is pleased with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### let the king and Haman come

This can be translated with the word "you" along with other words that show respect. AT: "please come and bring Haman" or "please come and let Haman come with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I will answer the king's question

This can be translated with the word "you" along with other words that show respect. AT: "I will answer your question" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Esther 05:09

#### Mordecai neither rose up

Rising was a sign of respect. Mordecai did not give Haman special respect. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### he was filled with rage

Being "filled with rage" represents being very angry. AT: he was extremely angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Nevertheless

This can be translated with a phrase. "Even though he was so angry"

#### Haman restrained himself

Restraining himself represents refusing to do something that he wanted very much to do. Haman wanted to show Mordecai that he was very angry. AT: "Haman refused to show how angry he was" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Zeresh

This is a woman's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Haman recounted to them the splendor of his riches

"Splendor" and "riches" are both abstract nouns. AT: "Haman told them about how great his wealth was" or "Haman told them about the many great things he owned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### all the promotions by which the king honored him

The abstract noun "promotion" can be expressed with the verb "promote." It means that the king gave him more important work. AT: "How the king had promoted him many times and honored him" or "how the king had honored him many times by giving him more important work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### how he had advanced above all the officials and the servants of the king

Advancing above people represents becoming more important than them. AT: "how he had become more important than all the officials and the servants of the king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Esther 05:12

#### no one else but me

This can be expressed positively. AT: "only me"

#### is worth nothing to me

"does not make me happy" or "does not satisfy me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Esther 05:14

#### a gallows

a structure used for killing a person by tying one end of a a rope around the top of the structure and the other end of the rope around the person's neck and hanging him from it. See how you translated this in [Esther 2:23](../02/22.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### fifty cubits high

"50 cubits high." You may convert this to a modern measure. AT: "twenty-three meters high" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### he had the gallows constructed

"he told people to construct the gallows"

#### This pleased Haman

"Haman liked this idea"

### Esther 05:intro

#### Esther 05 General Notes ####

####### Structure and formatting #######

This chapter begins a section about Haman's fall (Chapters 5-7).

####### Special concepts in this chapter #######

######## Esther's respect ########
Esther approached the king with the utmost of respect. By doing this, her character became respected by the king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Esther 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Esther 06

### Esther 06:01

#### Bigthana and Teresh

These are the names of two men. See how your translated their names in [Esther 2:21](../02/19.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### It was found recorded there

Here "found" is an metaphor for learning. Both "found" and "recorded" can be expressed in active form. AT: "They found that the writers had recorded there" or "They learned that the writers had written" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### What was done to give honor

This can be expressed in active form. AT: "What did I do to give honor" or "What did we do to give honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Nothing was done for him

This can be expressed in active form. However it may be good to find a way that does not give the impression that servants were accusing the king. AT: "No one did anything for Mordecai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Esther 06:04

#### Haman

See how you translated this man's name in [Esther 3:1](../03/01.md)

#### the outer courtyard

"the first courtyard from the outside"

#### hanging Mordecai

It can be made clear what the purpose of hanging him was. AT: "killing Mordecai by hanging him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the gallows he set up for him

The gallows was a structure that was used to kill people by hanging them from it. See how you translated "gallows" in [Esther 5:14](../05/14.md). AT: "the structure Haman set up for hanging Mordecai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### set up

"built"

#### What should be done for the man whom the king takes pleasure in honoring

Here the king speaks of himself in the third person. This can be stated in first person and in active form. AT: "What should I do for the man whom I take pleasure in honoring" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the king takes pleasure in honoring

Taking pleasure in doing something is an idiom for being glad to do something or wanting to do something. AT: "the king is glad to honor" or "the king wants to honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### said in his heart

The heart represents the thoughts and attitudes. AT: "thought" or "said to himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Whom would the king take pleasure in honoring more than me?

This can be expressed as a statement. "Surely there is no one whom the king would take pleasure in honoring more than me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Esther 06:07

#### let royal robes be brought

This can be stated in active form. AT: "let someone bring royal robes" or "tell your servants to bring royal robes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on whose head is the royal crest

The word "whose" refers to the horse. The royal crest is a special symbol that represents the king's family.

#### Then let the robes and the horse be given

This can be stated in active form. AT: "Then let them give the robes and the horse" or "Then tell them to give the robes and the horse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Let them dress ... in honoring, and let them lead him

"Tell them to dress ... in honoring and to lead him"

#### Let them proclaim

"Tell the noble official and servants to proclaim"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]

### Esther 06:10

#### Do not fail in a single matter of what you have said

The phrase "a single matter" emphasizes that he must do absolutely everything he said. It can be stated positively. AT: "Be sure to do absolutely everything you have said"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]

### Esther 06:12

#### with his head covered

People often covered their head to show that they were either extremely sad or ashamed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### Zeresh

See how you translated this woman's name in [Esther 6:13](./12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### before whom you have begun to fall ... you will certainly fall before him

They spoke as if Haman and Mordecai were in a battle, and Haman was beginning to lose the battle. Here "to fall" represents being dishonored and defeated. AT: "who has already humiliated you ... he will certainly defeat you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will not overcome him

"you will not win against him." They spoke as if Haman and Mordecai were in a battle. Here overcoming a person represents having greater honor than that person. AT: "you will not have greater honor than he has" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]

### Esther 06:intro

#### Esther 06 General Notes ####

####### Structure and formatting #######

This chapter continues the story of Haman's fall. 

####### Special concepts in this chapter #######

######## Approaching the king ########
It was not possible for a person to easily approach the king. Normally, access to him was very limited. There are several events in this chapter which show the layers of protection surrounding the king. 

##### Links: #####

* __[Esther 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Esther 07

### Esther 07:01

#### Haman

See how you translated this man's name in [Esther 3:1](../03/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### On this second day

"on this second day of feasting"

#### while they were serving wine

"while the servants were pouring the wine and giving it to them"

#### What is your petition

The abstract noun "petition" can be expressed with the verb "ask for" or "want." AT: "What do you ask for" or "What do you want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### It will be granted to you

This can be stated in active form. AT: "I will give you what you ask for" or "I will do for you what you ask" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Up to half of the kingdom, and it will be granted

This can be stated in active form. AT: "If you ask for up to half of my kingdom, I will give it to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Esther 07:03

#### If I have found favor in your eyes, king

"Find favor" here is an idiom that means to be approved of or that he is pleased with her. "In your eyes" is a metaphor representing his evaluation. AT: "If you evaluate me and approve" or "If you are pleased with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### let my life be given to me

The metaphor "giving life" represents rescuing a person from being killed. This statement can be expressed in active form. AT: "save my life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this is my petition

The abstract noun "petition" can be expressed with the verb "ask for." AT: "this is what I ask for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### For we have been sold

The metaphor "being sold" represents being betrayed. This can be stated in active form. AT: "For someone has betrayed us" or "For someone has put us in danger of our enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to be destroyed, killed, and annihilated

Here all three words have the same meaning and are used for emphasis. This can be stated in active form. AT: "for our enemies to destroy, kill, and annihilate us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Where is this person to be found who has filled his heart to do such a thing

To fill one's heart to do something is an idiom meaning to dare to do something. This can be stated in active form. AT: "Where is the one who has dared to so such a thing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]

### Esther 07:06

#### terrified

"extremely afraid"

#### The king got up in a rage

Being in a rage is an idiom for being extremely angry. AT: "The king was extremely angry and got up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### to beg for his life from Queen Esther

"to beg Queen Esther to save his life"

#### He saw that disaster was being decided

Here seeing represents realizing or understanding. AT: "He realized that disaster was being decided" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### disaster was being decided against him by the king

This can be stated in active form. The abstract noun "disaster" can be expressed with the more concrete verbs "destroy" or "kill." AT: "the king was deciding to cause a disaster against him" or "the king was deciding to destroy him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]

### Esther 07:08

#### where the wine had been served

This can be stated in active form. AT: "where servants had served the wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### couch

a long piece of furniture where a person can sit or lie down

#### Will he assault the queen in my presence in my own house?

The king uses this question to show his shock and anger at what Haman was doing. This question can be translated as a statement. AT: "He even dares to attack the queen in my presence and in my own house!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### assault the queen

"attack the queen." This phrase is a polite way to refer to rape. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### As soon as this sentence came out of the king's mouth

Speech coming out of the mouth is a metonym that represents speaking. AT: "As soon as the king said this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the servants covered Haman's face

Apparently they did this because they understood that the king wanted Haman to be killed. AT: "the servants covered Haman's face as a sign that he would be killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Esther 07:09

#### Harbona

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### A gallows fifty cubits tall

You may convert "fifty cubits" to a modern measure. See how you translated a similar phrase in [Esther 5:14](../05/14.md). AT: "A gallows twenty-three meters high" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### Then the king's rage died down

The king's rage is a spoken of as if it were a large fire that became smaller. AT: "Then the king's rage lessened" or "Then the king was not so angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hang.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hang.md)]]

### Esther 07:intro

#### Esther 07 General Notes ####

####### Structure and formatting #######

The story of Haman's fall concludes in this chapter.

####### Other possible translation difficulties in this chapter #######

######## Covering Haman's face ########

When "the servants covered Haman's face," they were showing that he had been condemned to be executed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]])

##### Links: #####

* __[Esther 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Esther 08

### Esther 08:01

#### Haman

See how you translated this man's name in [Esther 3:1](../03/01.md).

#### signet ring

This ring had the king's name or mark on it. When he put a wax seal on important papers, he would press the mark onto the seal. If a paper had this mark on its seal, people would know that what was written on the paper was written with the king's authority and had to be obeyed. See how you translated this in [Esther 3:10](../03/10.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### gave it to Mordecai

By giving his signet ring to Mordecai, the king gave Mordecai the authority to write important papers that people would have to obey.

#### Haman's estate

This refers to the things that had belonged to Haman and that the king had given to Esther.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Esther 08:03

#### pleaded

"begged"

#### to put an end to the evil plan of Haman the Agagite

"Put an end to" here is an idiom meaning to stop something. AT: "to stop the evil plan of Haman the Agagite" or "to prevent the evil things from happening that Haman the Agagite had planned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Agagite

See how you translated this in [Esther 3:1](../03/01.md)

#### scheme that he had devised

"the plot that he had invented" or "the plot that Haman invented"

#### the king held out the golden scepter to Esther

He did this to show that he was pleased with her. See how you translated a similar phrase in [Esther 5:2](../05/01.md)

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md)]]

### Esther 08:05

#### If it pleases the king

"If what I ask for pleases the king"

#### if I have found favor in your eyes

Here "found favor" is an idiom that means be approved of or that he is pleased with her. Here "eyes" are a metonym for sight, and  sight is a metaphor representing his evaluation. AT: "if you have evaluated me and approve" or "if you are pleased with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### if the thing seems right before the king

"Before the king" here is a metaphor representing his evaluation. AT: "if what I ask for seems right in the king's evaluation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I am pleasing in your eyes

Here "your eyes" is a metonym for sight, and sight is a metaphor representing his evaluation. AT: "if you evaluate me and I please you" or "if you are pleased with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### revoke

"officially cancel"

#### Hammedatha

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### For how could I bear to see disaster fall on my people? How could I endure watching the destruction of my relatives?

Esther used these questions to show that that she would be extremely sad if her people were to be destroyed. AT: "I cannot bear to see disaster fall on the Jews. I cannot endure watching my relatives be killed." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Esther 08:07

#### the house of Haman

This represents all that Haman had owned. AT: "all that had belonged to Haman" or "all of Haman's property" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### gallows

See how you translated this in [Esther 6:4](../06/04.md)

#### Write ... in the name of the king

Writing something in the king's name represents writing it with his authority, or writing it as his representative. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### For the decree ... ring cannot be revoked

This can be stated in active form. AT: "For no one can revoke the decree ... ring" or "For no one can cancel the decree ... ring" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For the decree ... ring cannot be revoked

The information given between the words "decree" and "cannot" is the reason that the king cannot revoke Haman's decree. It can be shown clearly that it was the reason with the word "because." AT: "For I cannot revoke the decree that has already been written, because it was written in the king's name and sealed with the king's ring" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### decree that has already been written in the king's name

Writing something in the king's name represents writing it with his authority, or writing it as his representative. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]

### Esther 08:09

#### called

"summoned"

#### the third month, which is the month of Sivan, on the twenty-third day of the month

"Sivan" is the name of the third month of the Hebrew calendar. The twenty-third day is near the middle of June on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### A decree was written

This can be stated in active form. AT: "They wrote a decree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### 127 provinces

"one hundred and twenty-seven provinces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in in [Esther 1:1](../01/01.md).

#### written in their own writing

"written in their own script." There are different writing systems around the world.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimemonth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimemonth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Esther 08:10

#### wrote in the name of King Ahasuerus

Writing something in the king's name represents writing it with his authority, or writing it as his representative. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### signet ring

See how you translated this phrase in [Esther 8:2](./01.md)

#### couriers

"people to carry the message"

#### bred from the royal stud

The royal stud was the king's best male horse. The horses that were used in the king's service were its offspring. AT: "the offspring of the king's best horse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### permission

"right"

#### make a stand

This is a metaphor for fighting back and not running away. AT: "fight back" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the thirteenth day of the twelfth month, which is the month of Adar

See how you translated this in [Esther 3:13](../03/12.md)

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]

### Esther 08:13

#### to take vengeance on their enemies

"To take vengeance on people" here is an idiom meaning to hurt people who have hurt you. AT: "to fight back against their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### They went without delay

"Without delay" here is an idiom meaning that they did not delay or wait. AT: "They went immediately" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Susa

This is the city where the king's palace was. See how you translated it in [Esther 1:2](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Esther 08:15

#### the city of Susa shouted and rejoiced

The "city" represents the people living in it. AT: "the people of the city of Susa shouted and rejoiced" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### shouted and rejoiced

The word "rejoiced" tells how they shouted. AT: "shouted joyfully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md)]])

#### had light and gladness

Possible meanings are that 1) having light is a metaphor for being happy. AT: "were happy and glad" or 2) having light is metaphor for feeling prosperous and safe. AT: "felt safe and were glad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### honor

Possible meanings are that 1) other people honored the Jews. AT: "other people honored them" or 2) the Jews felt honored. AT: "they felt honored" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### province

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### wherever the king's decree reached

Reaching places represents going to places. AT: "wherever the king's men took his decree" or "wherever the king's decree was read" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### holiday

"celebration"

#### the fear of the Jews had fallen on them

Fear falling on people represents people becoming very afraid. AT: "they had become very afraid of the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/royal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Esther 08:intro

#### Esther 08 General Notes ####

####### Special concepts in this chapter #######

######## God's protection ########
Yahweh is at work in this chapter preventing the Jews from possible destruction. God used Esther and Mordecai to protect their people.

##### Links: #####

* __[Esther 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Esther 09

### Esther 09:01

#### the twelfth month, which is the month of Adar, on the thirteenth day

See how you translated a similar phrase in [Esther 3:13](../03/12.md).

#### when the king's law and decree were about to be carried out

"Carry out" here is an idiom meaning to do something that was commanded or planned. This can be stated in active form. AT: "when the people were about to obey the king's law and decree" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to gain power over them

Gaining power over people is an idiom for defeating them. AT: "to defeat the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### it was reversed

"the situation was reversed." The situation being reversed is a metaphor meaning that the opposite of what was expected happened. AT: "the opposite happened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### provinces

A "province" is a large area into which some countries are divided for the purposes of government. See how you translated this in [Esther 1:1](../01/01.md).

#### to lay hands on those who tried to bring disaster on them

Laying hands on people is a metonym for fighting against them. AT: "to fight their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### who tried to bring disaster on them

To bring disaster on people is an idiom meaning to cause a disaster to happen to them. In this case it refers to destroying them. AT: "who tried to destroy them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### No one could stand against them

Standing against people represents resisting their attack. AT: "No one could resist the attack of the Jews" or "No one could successfully fight against the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the fear of them had fallen on all the peoples

Fear falling on people represents people becoming very afraid. AT: "all the peoples had become very afraid of the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]

### Esther 09:03

#### provincial governors

"governors of the provinces"

#### the fear of Mordecai had fallen on them

Fear falling on people represents people becoming afraid. AT: "they had become afraid of Mordecai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### was great in the king's house

"was very important in the king's palace"

#### his fame spread throughout all the provinces

Fame spreading through places represents people in those places learning about how great he was. AT: "throughout the provinces people learned about how great he was" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/administration.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Esther 09:06

#### the fortress

This refers to a castle, stronghold or fortified city. See how you translated this in [Esther 1:2](../01/01.md).

#### Susa

This was a royal city of Persian kings. See how you translated this in [Esther 1:2](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### five hundred men

"500 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Parshandatha, Dalphon, Aspatha, Poratha, Adalia, Aridatha, Parmashta, Arisai, Aridai, Vaizatha

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### ten sons

"10 sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Haman

This is the name and description of Haman, one of the king's officials. See how you translated this in [Esther 3:1](../03/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hammedatha

See how you translated this man's name in [Esther 3:1](../03/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the enemy of the Jews

This phrase tells us about Haman.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Esther 09:11

#### five hundred men

"500 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### ten sons

"10 sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### What then have they done in the rest of the king's provinces?

The king uses this question to show that he believes that the Jews must have also killed many people in the other provinces. AT: "What they must have done in the rest of the king's provinces!" or "They must have killed many more in the rest of the king's provinces!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### what is your petition?

The abstract noun "petition" can be expressed with the verb "ask for" or "want." AT: "what do you ask for?" or "what do you want?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### It will be granted you

This can be expressed in active form. AT: "I will give you what you ask for" or "I will do for you what you ask" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### What is your request?

The abstract noun "request" can be expressed with the verb "ask for" or "want." AT: "What do you ask for?" or "What do you want?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

### Esther 09:13

#### to carry out this day's decree tomorrow also

"Carry out" here is an idiom meaning to do something that was commanded or planned. AT: "to obey today's decree tomorrow also" or "to do tomorrow also what was decreed that they should do today" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### ten sons

"10 sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### gallows

This was a structure used for killing people by tying one end of a rope around the top of the structure and the other end of the rope around their necks and hanging them from it. See how you translated this in [Esther 2:23](../02/22.md). AT: "a frame for hanging people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Esther 09:15

#### the fourteenth day of the month of Adar

See how you translated a similar phrase in [Esther 3:13](../03/12.md).

#### laid no hands on the plunder

Laying their hands on things represents taking them. AT: "took none of the plunder" or "did not take any of the plunder" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### seventy-five thousand

"75,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### they did not lay their hands on the valuables of those they killed

Laying their hands on things represents taking them. AT: "they did not take any of the valuables of the people they killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### valuables

"valuable things" or "possessions"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]

### Esther 09:17

#### the thirteenth day of the month of Adar

See how you translated a similar phrase in [Esther 3:13](../03/12.md).

#### On the fourteenth day they rested

"On the fourteenth day of Adar the Jews who were in the provinces rested"

#### the Jews who were in Susa assembled together

Why they assembled together can be stated clearly. AT: "the Jews who were in Susa assembled together to fight against their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]

### Esther 09:20

#### to keep the fourteenth and the fifteenth day of Adar every year

To keep a day is an idiom that means to celebrate it. AT: "to celebrate the fourteenth and fifteenth days of Adar every year" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### their sorrow turned to joy

Turning represents changing. The abstract nouns sorrow and joy can be expressed with "sad" and "joyful." AT: "they changed from being very sad to being joyful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]

### Esther 09:23

#### General Information:

This passage summarizes much of the story of Esther in order to explain the reason for the festival of Purim.

#### Haman son of Hammedatha the Agagite

This is the name and description of Haman, one of the king's officials. See how you translated this in [Esther 3:1](../03/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### he threw Pur (that is, he threw lots)

"Pur" was the Persian word for "lot." The phrase "he threw lots" explains what "he threw Pur" means.

#### he threw Pur (that is, he threw lots)

Why he threw Pur, or lots, can be stated clearly. AT: "he threw Pur (that is, he threw lots) to find out what would be the best day to attack the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### But when the matter came before the king

The Hebrew text can also be interpreted to mean, "But when Esther came before the king." Some modern versions choose this interpretation.

#### the wicked plan Haman developed against the Jews should come back on his own head

"Come back on his own head" means that it should be done to Haman. AT: "the wicked plan Haman developed against the Jews should be done to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Esther 09:26

#### they called these days Purim, after the name of Pur

To call something after something else is an idiom that means to give it the same name or a similar name. AT: "They called these days Purim, like the word Pur" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Purim

This is the name of the festival that commemorates the salvation of the Jewish people in ancient Persia from Haman's plot to destroy and kill all the Jews in a single day. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the name of Pur.

It can be stated clearly what "Pur" means. AT: "the word Pur, which means 'lot.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### These days were to be celebrated and observed

This can be stated in active form. AT: "The Jews were to celebrate and observe these days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### would never cease to faithfully observe

This can be stated positively. AT: "would always faithfully observe"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Esther 09:29

#### Queen Esther daughter of Abihail and Mordecai the Jew wrote ... this second letter

Esther was the daughter of Abihail. Esther and Mordecai wrote the letter.

#### Abihail

Esther's father and Mordecai's uncle. See how you translated this in [Esther 2:15](../02/15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### second letter

"additional letter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esther.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Esther 09:30

#### Letters were sent to all the Jews

This can be stated in active form. AT: "They sent letters to all the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### 127 provinces

"one hundred and twenty-seven provinces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### wishing the Jews safety and truth

The abstract nouns "safety" and "truth" can be expressed with phrases. AT: "wishing that the Jews would be safe and that people would be faithful to the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### The Jews accepted this obligation for themselves and their descendants

Accepting an obligation is a metaphor for agreeing with the obligation. The abstract noun "obligation" can be expressed with the verb "obligate." AT: "The Jews agreed and said that they and their descendants were obligated to celebrate the days of Purim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### they accepted times of fasting and lamenting

Accepting times of fasting and lamenting is a metaphor for agreeing to fast and lament at certain times. AT: "they agreed to fast and lament at certain times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Esther 09:intro

#### Esther 09 General Notes ####

####### Special concepts in this chapter #######

######## Purim ########
The events of this chapter were so significant, the Jews celebrated these events every year after this. It is known as "Purim."

####### Important figures of speech in this chapter #######

######## Ironic Situation ########
The day that was supposed to bring great victory to the enemies of the Jews became a day of great victory for the Jews. This is a type of irony. 

##### Links: #####

* __[Esther 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Esther 10

### Esther 10:01

#### imposed a tax on the land and on the coastlands along the sea

To impose a tax means to make people pay a tax. The land and coastlands represent the people living there. AT: "made the people living in the land and on the coastlands along the sea pay a tax" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### All the achievements of his power and might

The abstract noun "achievements" can be expressed with the verb "achieve" or the phrase "do great things. The abstract nouns "power" and "might" can be translated with adjectives. AT: "All that he achieved because of how powerful and mighty he was" or "All the great things that he did because of his power and might" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the full account of the greatness of Mordecai to which the king had raised him

The king honoring Mordecai is spoken of as if the king physically raised him up. AT: "the full account of how the King had made it known that Mordecai was great" or "the full account of how the king had honored Mordecai for the great things he had done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahasuerus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mordecai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chronicles.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chronicles.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]

### Esther 10:03

#### second in rank to King Ahasuerus

"the most important person after King Ahasuerus"

#### Jewish brothers

The word brothers represents people who were like him. AT: "fellow Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he sought the welfare of his people

Seeking something is a metaphor for working hard for something. The abstract noun "welfare" can be translated as a phrase with the verb "prosper" or the adjective "secure." AT: "He worked hard so his people would prosper" or "He worked hard so his people would be secure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### he spoke for the peace of all his people

"he represented his people so that they might have peace"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Esther 10:intro

#### Esther 10 General Notes ####

####### Special concepts in this chapter #######

######## Mordecai's new position ########

Through the power of Yahweh, Mordecai was given a new position in the Persian Empire. Mordecai was now the second in command in the kingdom of Persia and he used his position to help other Jews.  

##### Links: #####

* __[Esther 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | __


## Esther front

### Esther front:intro

#### Introduction to Esther ####

##### Part 1: General Introduction #####

####### Outline of Esther #######

1. King Ahasuerus sends away his wife, the queen (1:1–22)
1. Ahasuerus chooses Esther as the new queen (2:1–23)
1. Haman plots to destroy the Jews (3:1–15)
1. Mordecai asks Esther to help her people (4:1–17)
1. Esther pleads with the King for the Jews (5:1–7:10)
1. The result of Haman's plot to destroy the Jews (8:1–9:16)
1. The Feast of Purim (9:17–32)
1. Conclusion (10:1–3)
 
####### What is the Book of Esther about? #######

This book tells how a young Jewish woman named Esther became the queen of Persia. As queen she worked to save the Jews from being destroyed throughout the Persian Empire. 

The Book of Esther ends by explaining why the Jews started celebrating the festival of Purim. The name "Purim" comes from the word "pur." It means "lots" or "dice." Haman, the enemy of Jews, threw dice to determine when to attack and destroy the Jews. The Jews celebrated Purim to remember how God rescued the people from being destroyed.

####### How should the title of this book be translated? #######

The traditional title of this book is "The Book of Esther." However, it is possible to make the title clearer in other languages. We recommend, "The Book About Esther" or "The History About Esther."

##### Part 2: Important Religious and Cultural Concepts #####

####### What was the Persian Empire? #######

The Persian Empire consisted of many kingdoms and regions that King Cyrus the Great conquered and ruled over. When he conquered Babylonia in 539 B.C., he came into control of the Jews whom the Babylonians had exiled. 

####### Why were there Jews in Babylonia when the Persians conquered it? #######

The people of Judah had been conquered and taken into exile by the Babylonians in 586 B.C. These Jews and their descendants were still in Babylon when the Persians conquered it. 

####### What was meant by "the laws of the Medes and Persians"? #######

The phrase "the laws of the Medes and Persians" is found in Esther 1:19 and Daniel 6:12. It referred to laws and decrees that could not be changed or removed once they were issued.  In the book of Esther, the king made a decree that the people could attack the Jews. Later he regretted that decision but he was not able to reverse the decree. 

The term "Medes" refers to an ethnic group who had formed their own nation, but who were taken over by the Persians.

##### Part 3: Important Translation Issues #####

####### What different levels of language are in the Book of Esther? #######

The Book of Esther presents people talking to each other in many different situations. There is the polite and stately language of the Persian court and the language of royal decrees. There is also the language of friends and close relatives who are talking to each other. There is even the language that one uses in speaking to oneself. Translators should use all the ways provided by their own languages in order to represent these different kinds of situations in a way that their readers will identify and understand.



---

