# <a id="mic"/>Micah

## Micah 01

### Micah 01:01

#### General Information:

God speaks through Micah to the people of Israel using poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the word of Yahweh that came

This idiom is used to explain that a God gave a message to someone. AT: "the message that Yahweh spoke" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### the Morashtite

This means he is from Moresheth which is a town in Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in the days of Jotham, Ahaz, and Hezekiah, kings of Judah

"when Jotham, Ahaz, and Hezekiah were kings of Judah"

#### which he saw

"which he heard in a vision"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/micah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/micah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahaz.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahaz.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Micah 01:02

#### General Information:

Micah 1:2-7 is about God's judgment on Samaria.

#### Listen, all you peoples. Listen, earth, and all that is in you

This begins Micah's prophecy. Micah speaks to the people of Samaria as if all the people of the earth and even the earth itself were able to hear him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### he will come down and tread on the high places of the earth

Micah speaks as if Yahweh were a mighty soldier coming down from heaven and beginning to march on top of the mountains. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will ... tread

"he will ... march"

#### the high places of the earth

"the high mountains"

#### The mountains will melt under him; the valleys will break apart, like wax before fire, like waters that are poured down a steep place

Micah speaks as if Yahweh were a hot, solid object that melted the earth as it moved. AT: "He will crush the mountains and the valleys as he marches over them; he will destroy them, and they will completely disappear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Micah 01:05

#### because of the sins of the house of Israel

The word "house" is a metonym for the family that lives in the house, in this case the people of Israel. AT: "because the people of Israel have sinned against me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### All this is

"The Lord will come and judge"

#### What is Jacob's transgression?

The name "Jacob" is a metonym for those of his descendants who live in the northern kingdom of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Is it not Samaria?

Here "Samaria" is a metonym for the evil activities that take place there. Micah uses a question to emphasize that the people know what the truth is. This can be translated as a statement. AT: "You know that it is Samaria." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### What is Judah's high place?

Here "high place" is a synecdoche for the entire system of idol worship. "Judah" is a metonym for the people who live there. AT: "Where do the people of Judah go to worship idols?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Is it not Jerusalem?

Here "Jerusalem" is a metonym for the evil activities that take place there. Micah uses a question to emphasize that the people know what the truth is. This question can be translated as a statement. AT: "You know that it is Jerusalem." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/highplaces.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Micah 01:06

#### I will make

Here "I" refers to Yahweh.

#### Samaria ... her stones ... her foundations ... her carved figures ... her gifts that she received ... her idols ... she gathered her gifts ... they will become

Yahweh speaks of Samaria as if the city were a woman. AT: "Samaria ... its stones ... the foundations of the buildings in the city ... the carved figures in the city ... the gifts that people gave to the temple in the city ... the idols in the city ... the people of the city became rich ... the gifts will become" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will pour her stones

Here "her" refers to the city of Samaria.

#### All her carved figures will be broken to pieces

This can be translated in active form. AT: "I will break all her carved figures to pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### all her gifts ... will be burned with fire

This can be translated in active form. AT: "I will burn with fire all the gifts that she received" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### she received

"people gave her"

#### Since she gathered her gifts from the wages of prostitutes, they will become the wages of prostitutes again

Yahweh speaks of the people giving gifts to idols as if the people were hiring prostitutes. When the Assyrians destroy Samaria, they will take to Assyria the gifts the people of Samaria gave to their idols and give them as gifts to their own idols. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]

### Micah 01:08

#### General Information:

Micah 1:8-16 is about God's judgment on Judah.

#### I will lament

Here "I" refers to Micah.

#### I will lament and wail

"Lament" refers to the inner feeling of sadness, and "wail" refers to the activity of making a loud, sad sound.

#### I will go barefoot and naked

This is a sign of extreme mourning and distress. Another possible meaning is "I will look like someone has taken off my clothes; I will be naked"

#### naked

probably wearing only a loincloth

#### like the jackals ... like owls

Jackals and owls live in wastelands, and their loud cries sound like people wailing or weeping. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### For her wound is incurable

Here "her" refers to the city of Samaria. This means nothing can stop the enemy army from destroying the people who live there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for it has come to Judah

Micah uses contagious disease as a metaphor for the army that Yahweh has sent to judge Samaria. Here "it" refers to the "wound," that is, to the army that God will use to punish Samaria. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Beth Leaphrah

You may want to make a footnote saying, "The name of this city means 'house of dust.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I roll myself in the dust

People under God's judgment are expressing their grief in a strong way. AT: "I roll myself on the ground" or "I roll myself in the mud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md)]]

### Micah 01:11

#### General Information:

The meanings of the names of the villages is important to Micah here. You may want to include the meanings of the names of the places in a footnote.

#### Shaphir

The name of this city sounds like one meaning "beautiful." It contrasts with "nakedness and shame." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in nakedness and shame

This idiom makes explicit that the people will be totally naked. AT: "totally naked and ashamed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Zaanan

The name of this city means "go out." They are too afraid to go out and help.

#### Beth Ezel

The name of this city means "house of taking away."

#### for their protection is taken away

This can be translated in active form. AT: "for I have taken away everything that might protect them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Maroth

The name of this city means "bitterness."

#### disaster has come down from Yahweh

The abstract noun "disaster" is spoken of here as a solid object rolling down a hill. It can be translated as a verb. AT: "Yahweh has caused bad things to happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Micah 01:13

#### Lachish

The name "Lachish" sounds like "to the chariots" in Hebrew. The people are hitching their chariots to flee, not fight. Lachish was the most important city after Jerusalem in Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### the daughter of Zion

The word "daughter" is a metonym for the people of the city. AT: "the people of Zion" or "the people who live in Zion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for the transgressions of Israel were found in you

This idiom can be translated in active form. AT: "for you disobeyed like the people of Israel did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Moresheth Gath

You may want to add a footnote saying "The name 'Moresheth' means 'to depart.' It is also similar in sound to the word for 'fiancée.'" In this metaphor, Moresheth is the bride that Assyria takes, and the "parting gift" is the dowry, the gift her family gives for her to take into the marriage. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Akzib

You may want to add a footnote saying "The name of this town sounds almost the same as the Hebrew expression for 'deceitful thing.'"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Micah 01:15

#### I will again bring

Here "I" refers to Yahweh.

#### Mareshah

You may want to make a footnote saying, "The name of this village sounds like the Hebrew word for 'conqueror.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Adullam

This is the name of a royal city in Philistia. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shave your head and cut off your hair

Israelites who were mourning would shave bald spots on their heads. Possible meanings are 1) "Shave larger spots than usual on your heads" or 2) "Cut off all your hair and shave your heads," stating the events in the order in which they were to occur. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### eagles

This word can also be translated "vultures."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]

### Micah 01:intro

#### Micah 01 General Notes ####

####### Structure and formatting #######

Micah is written mainly in a poetic form. Most of the prophets wrote to either the Northern Kingdom or the Southern Kingdom. Micah wrote to both of them at times without clear distinction, as he did in this chapter.

####### Important figures of speech in this chapter #######

######## City Names ########

This passage sounds unusual in English because of its construction in Hebrew. It contains several "puns" or "plays on words." The names of the cities are used to describe their destruction. "Lachish will be lashed" is an example of this type of construction. This poetic element might metaphors describing the actual way they will be punished. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Micah 01:01 Notes](./01.md)__
* __[Micah intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Micah 02

### Micah 02:01

#### General Information:

Micah speaks against the leaders in Israel who are taking advantage of the poor and not following God's commands.

#### They oppress a man

"They oppress any man they choose to oppress." This is a generalization. Micah is not speaking of one individual man here.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Micah 02:03

#### Look

"Listen carefully" or "Pay attention"

#### disaster

See how you translated this in [Micah 1:12](../01/11.md).

#### this clan

This "clan" refers to the entire community of Israel, whose rich people are oppressing the poor. The sins of the leaders are coming back on the whole nation.

#### from which you will not remove your necks

Yahweh speaks of punishing the people as if he were putting a yoke around their necks. AT: "from which you will not be able to escape" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sing a song about you

"sing a song to make fun of you"

#### lament with a wailing lamentation

"they will cry loudly." They are pretending to mourn, as if those they love have died. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### We Israelites ... to traitors

This is the song that the enemies will sing to make fun of the Israelites and laugh as the Israelites suffer. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### How can he remove it from me?

The enemy mocks the surprise the rich leaders of Israel feel because God has taken their land and given it to someone else just as they had taken the land from the poor. This question can be translated as a statement. AT: "How wrong he is to take it from me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### Therefore, you rich people will have no descendants to divide up the territory by lot in the assembly of Yahweh

Possible meanings are 1) Micah looks forward to a time after the exile when those who return will divide up the land or 2) he is speaking of a custom of his time when the tribe or clan would divide up their land and give it to individuals.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/arrogant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Micah 02:06

#### General Information:

Micah speaks to false prophets, as well as to the rich who have abused their power.

#### Do not prophesy

The speakers are speaking to Micah and to others, so this is plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### they say

"the people of Israel say"

#### They must not prophesy

"The prophets must not prophesy"

#### reproaches must not come

Reproach is spoken of as if it were a robber chasing a person. It can be translated as a verb. AT: "we will not allow you to reproach us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Should it really be said ... "Is the Spirit ... his deeds?"

Micah is scolding the Israelites by using this question. This can be translated as a statement. AT: "You know that you do not need to ask ... 'Is the Spirit ... his deeds?'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### house of Jacob

The word "house" is a metonym for the family that lives in the house. In this case it refers to Jacob's descendants. AT: "descendants of Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### said ... "Is the Spirit of Yahweh angry? Are these really his deeds?"

Possible meanings are 1) the people really do not know if they are seeing Yahweh act. AT: "asked ... 'Is the Spirit of Yahweh angry? Are these really his deeds?'" or 2) the people do not believe that Yahweh is really punishing them. These rhetorical questions can be translated as statements. AT: "said ... 'The Spirit of Yahweh is not really angry. These are not really his deeds.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Do not my words do good to anyone who walks uprightly?

Micah uses a question to teach the people. It can bee translated as a statement. AT: "My message does good to those who walk uprightly." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my people

This refers to either 1) Micah's people or 2) Yahweh's people.

#### You strip the robe, the garment, from those who pass by unsuspectingly

Possible meanings are 1) the wicked rich people are literally stealing robes from the poor or 2) creditors are keeping the outer garments of the poor who come to borrow money and give the garment as assurance they will repay. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reproach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reproach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]

### Micah 02:09

#### General Information:

Yahweh continues speaking to the wicked rich people in Israel.

#### you take my blessing from their young children forever

This refers, in general, to blessings God has given to his people. It might refer to 1) being landowners in Israel, 2) a promising future or 3) to the children's fathers, farmers who worked hard to establish the nation.

#### my blessing

Micah speaks as if he were Yahweh.

#### it is destroyed with complete destruction

This can be translated in active form. AT: "I will completely destroy it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### comes to you ... will prophesy to you

Micah is speaking to the people of Judah, so both instances of "you" are plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### he would be considered

This can be translated in active form. AT: "the people would consider him" or "you would consider him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md)]]

### Micah 02:12

#### General Information:

Yahweh continues speaking. At the end of this chapter, Yahweh shows himself to be a shepherd who protects his people. He may especially be addressing those in Jerusalem who have returned from Assyria.

#### all of you, Jacob

Micah is speaking to some of the descendants of Jacob, so the word "you" is plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Someone who breaks open their way ... Yahweh will be at their head.

This is a picture of a king leading his people out of an enclosed city.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]

### Micah 02:intro

#### Micah 02 General Notes ####

####### Structure and formatting #######

This chapter continues using poetic forms in communicating that people who take advantage of others are guilty of sin and injustice. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]])

####### Special concepts in this chapter #######

####### Other possible translation difficulties in this chapter #######
######## Context ########
Micah does not frequently explain the historical context of his prophecies. This may result in the translator failing to understand implicit information. Additional research may be needed regarding the time period of Micah's ministry. Therefore, translators have a good understanding of the history of the kingdoms of Israel and Judah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Micah 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Micah 03

### Micah 03:01

#### General Information:

Chapter 3 focuses on the corrupt leaders in Israel.

#### I said

Here "I" refers to Micah.

#### Is it not right for you to understand justice?

Micah is scolding the leaders. This rhetorical question can be translated as a statement. AT: "You act as though you think it is wrong for you to understand justice." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### hate good and love evil

These nominal adjectives can be translated as adjectives. AT: "hate everything that is good and love everything that is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### you who tear off their skin, their flesh from their bones ... just like meat in a cauldron

A butcher cutting up animals into meat is a metaphor for the leaders being cruel to the poor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Micah 03:04

#### General Information:

Micah continues speaking.

#### cry out to Yahweh

"shout to Yahweh for help"

#### he will not answer you

"he will not do what you ask him to do"

#### He will hide his face from you

Hiding the face is a metaphor for refusing to listen. AT: "He will turn his face away from you and cover it" or "You will see that he has no desire to help you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Micah 03:05

#### General Information:

Micah continues to speak judgment against false prophets.

#### who lead my people astray

Walking on a good path is a metaphor for obeying God. Going astray from the path is a metaphor for disobeying God, in this case perhaps without knowing it. AT: "who lead my people to disobey me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### if one gives them something to eat, they proclaim, 'Peace.'

Micah is using a metaphor to describe a situation that actually happens. The phrase "something to eat" is an ironic way of speaking of a small payment. AT: "they tell people who pay them even a small amount that things will go well for those people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### if he puts nothing in their mouths, they dedicate themselves to wage war on him

Micah is using a metaphor to describe a situation that actually happens. The phrase "puts nothing in their mouths" is an ironic exaggeration for not giving what they want. AT: "they do all they can to destroy people who pay them too little" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### it will be night for you ... the day will be dark on them

Darkness is a metaphor for Yahweh not speaking to the prophets. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### no vision for you

"you will no longer see visions"

#### The seers will be put to shame, and the diviners will be confused

This can be translated in active form. AT: "I will cause the seers to be ashamed, and I will confuse the diviners" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### All of them will cover their lips

Here "lips" represents speaking. AT: "They shall no longer speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### there is no answer from me

"I will be silent"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Micah 03:08

#### But as for me

Here "me" refers to Micah, a true prophet, setting himself apart from the false prophets.

#### I am full of power by the Spirit of Yahweh, and am full of justice and might

Micah speaks of himself as if he were a container into which Yahweh were pouring a liquid. AT: "the Spirit of Yahweh has given me power, justice, and might" or "the Spirit of Yahweh has enabled me to be strong, to declare what justice is, and to be mighty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to declare to Jacob his transgression, and to Israel his sin

Here "Jacob" and "Israel" are metonyms for Jacob's descendants. Micah uses both names to emphasize that all of his descendants are guilty of sin. The abstract nouns "transgression" and "sin" can be translated using verbs. AT: "to declare to Jacob's descendants that they have broken Yahweh's law; I am telling the people of Israel that they have all sinned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Micah 03:09

#### house of Jacob

The word "house" is a metonym for the family that lives in the house. In this case it refers to Jacob's descendants. AT: "descendants of Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the house of Israel

The word "house" is a metonym for the family that lives in the house. In this case it refers to Israel's descendants, who had become the nation of Israel. AT: "descendants of Israel" or "you Israelites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### detest

strongly dislike

#### You build Zion with blood and Jerusalem with iniquity

"Blood" here is a metonym for murder, and "Zion" and "Jerusalem" are spoken of as if they were buildings. Micah speaks of the rich murdering people and sinning in other ways as if those activities were the bricks and wood with which people use to build houses. AT: "You commit murder and other horrible sins as you work to make Zion and Jerusalem great" or "You commit murder as you worship in Zion, and you commit other sins as you get rich in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Is not Yahweh with us?

The leaders strongly believe that Yahweh is with them. This can be translated as a statement. AT: "We know that Yahweh is with us!" or "We know that Yahweh will help us do what we want to do!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### evil

See how you translated "disaster" in [Micah 1:12](../01/11.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Micah 03:12

#### because of you

Here "you" refers to the priests, prophets, and leaders ([Micah 3:11](./09.md)).

#### Zion will become a plowed field ... and the hill of the temple will become a thicket

"Zion" and "the hill of the temple" refer to the same place. When a farmer plows a field, he turns over all the dirt and uproots all the plants that are growing there. A thicket is so full of bushes that no one can use it for anything. These two metaphors cannot be literally true at the same time, but they emphasize that Yahweh will allow the invaders to completely destroy the temple area. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a plowed field

"a field that a farmer has plowed"

#### a thicket

a place where many small woody plants grow

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### Micah 03:intro

#### Micah 03 General Notes ####

####### Special concepts in this chapter #######
######## Justice ########
An unjust society was considered sinful. It was considered to be against the law of Moses. If these kingdoms did not have justice, they were not obedient to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]])

####### Important figures of speech in this chapter #######

######## Metaphors ########
There are vivid pictures used in this chapter which show how the leaders of the people were treating the Israelites. These situations are absurd unless taken as a metaphor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Micah 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Micah 04

### Micah 04:01

#### the mountain ... other mountains

Yahweh making the temple mount higher than all other mountains and hills is a metaphor for making his temple the most important place on earth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the mountain of Yahweh's house will be established

This can be translated in active form. AT: "Yahweh will establish the mountain on which his temple is built" or "Yahweh will make the mountain on which his temple is built great" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### over the other mountains

Mount Zion will be the most important of all the mountains. It might also mean that this mountain will become the highest in the world, and not only in the region where it is located.

#### It will be exalted above the hills

This can be translated in active form. AT: "Yahweh will exalt it above the hills" or "Yahweh will make it higher than the hills" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### peoples will stream to it

A stream flows continually to one place from many directions. Many people come to the temple mount from different directions. AT: "the people of the nations will flow like a stream to it" or "the people of the nations will go to it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Micah 04:02

#### Many nations

The word "nations" is a metonym for the people of the nations. AT: "The people from many nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Come

This is plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### He will teach us his ways, and we will walk in his paths

Here "his ways" and "his paths" refer to what God wants the people to do. "Walk" means they will obey what he says. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from Zion the law will go out, and the word of Yahweh from Jerusalem

The law and the word going out is a metaphor for people hearing it and then being messengers to tell other people about it in other places. AT: "people will listen to the law in Zion and go out and tell others; they will listen to the word of Yahweh in Jerusalem and go out and tell others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### and the word of Yahweh from Jerusalem

The words "will go out" are understood from the previous phrase. They can be repeated here. AT: "and the word of Yahweh will go out from Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### plowshares

a blade that people use to dig into soil so they can plant seeds

#### pruning hooks

a metal tool that people use to cut off branches or stems from plants

#### will not lift up sword

will not threaten to start a war

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]

### Micah 04:04

#### General Information:

Micah continues describing the "last days" when people learn and obey Yahweh's law.

#### they will sit every person under his vine and under his fig tree

Both the "vine" and the "fig tree" are symbols of prosperity. This phrase describes actions in which people live prosperously and in peace. If grapevines or fig trees are unknown you can translate this more generally. AT: "they will sit peacefully in their own gardens and fields" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for the mouth of Yahweh of hosts has spoken

The mouth is a synecdoche for the person. AT: "for Yahweh of hosts has spoken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the peoples walk ... in the name of their god ... we will walk in the name of Yahweh

Walking on a path is a metaphor for living one's life. Walking in the name of someone is a metaphor for worshiping and obeying. AT: "the peoples ... worship and obey their god ... we will worship and obey Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Micah 04:06

#### On that day

"at that time" or "when I do those things." These words refer to "the last days" ([Micah 4:1](./01.md)). The word "day" can refer to a period of days or even years.

#### the lame

This refers to those who cannot walk well. Being lame is a synecdoche for having any form of disability. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### gather the outcast

"gather those whom I drove out of Jerusalem"

#### the ones driven away into a strong nation

The words "I will turn" are understood from the previous phrase. They can be repeated. The phrase "the ones driven away" can be translated with an active verb. AT: "I will turn the ones I drove away into a strong nation" or "I will make the ones I forcefully sent away into a strong nation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### As for you, watchtower for the flock, hill of the daughter of Zion—to you it will come, your former dominion

Micah speaks to the people of Jerusalem by speaking to the temple mount as if it could hear him. You may need to make explicit that Micah is giving his message to the people. AT: "As for the temple mount, the place from which Yahweh watches over you, his sheep, the place that Jerusalem's people are most proud of—its former dominion will return" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### watchtower for the flock

The people of Jerusalem protecting the other people in surrounding areas is spoken of as if they were a shepherd in a watchtower watching over his flock. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### daughter of Zion ... daughter of Jerusalem

The people who live in a place are spoken of as if the place is a mother and they are the daughter. AT: "people who live in Zion ... people who live in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### hill

Some modern versions understand this Hebrew word to mean "fortress" or "stronghold" here.

#### to you it will come, your former dominion

The abstract noun "dominion" can be translated as a verb. AT: "you will rule over the nations as you did before" or "I will make you rule over the nations as you did before" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Micah 04:09

#### Now, why do you shout so loudly?

Micah is mocking the people, trying to make them think about why God is dealing with them in this way. This question can be translated as a statement. AT: "Look at how you are shouting loudly." or "Think carefully about why you are shouting loudly." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is there no king among you? Has your counselor died? Is this why pain grips you like that of a woman in labor?

Micah continues to mock the people. These questions can be translated as statements. AT: "You have a king, but he is useless to you. All your wise people are still alive, but they have nothing wise to say to you. This is why you are weeping loudly like a woman who is giving birth to a baby." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Be in pain ... like a woman in labor

Micah compares the suffering the people will experience when enemies force them away from their cities to the pain a woman experiences when giving birth to a baby. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### There you will be rescued. There Yahweh will rescue you

Yahweh says the same thing in both active and passive forms to emphasize that he will do what he has said he will do. This can be translated in active form. AT: "There Yahweh will rescue you. There he will rescue you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the hand of your enemies

Possible meanings for the word "hand" are 1) it could be a metonym for the power that the hand exercises, AT: "the power of your enemies" or 2) it could be a synecdoche for the person. AT: "your enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Micah 04:11

#### General Information:

Jerusalem will defeat her enemies.

#### Let her be defiled

This can be translated in active form. AT: "Let us defile her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### let our eyes gloat over Zion

The eye is a synecdoche for the whole person. AT: "let us gloat over Zion" or "let us enjoy watching the invaders destroy Zion" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### for he has gathered them like sheaves for the threshing floor

The farmer puts his sheaves on his threshing floor just before he threshes them. In a similar way, Yahweh will soon destroy the nations. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]

### Micah 04:13

#### General Information:

Yahweh presents the imagery of the threshing floor. (See: [Micah 4:12](./11.md))

#### Arise and thresh, daughter of Zion ... your horn ... your hooves ... You will crush

All instances of "your" and "you," as well as the commands, refer to the "daughter of Zion" and so are singular and feminine. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Arise and thresh, daughter of Zion, for I will make your horn to be iron, and I will make your hooves to be bronze

Yahweh speaks of the people of Zion as if they were strong oxen about to thresh wheat and their enemies were the wheat. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### I will make your horn to be iron, and I will make your hooves to be bronze

If your reader is not familiar with oxen or iron or bronze, you can remove the metaphor. AT: "for I will make you able to defeat and destroy every enemy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### their unjust wealth

"the wealth they got by acting unjustly" or "the things they stole from other people"

#### their wealth

The abstract noun "wealth" can be translated as a verb. AT: "the things that they own" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Micah 04:intro

#### Micah 04 General Notes ####

####### Structure and formatting #######

This chapter continues the poetic form to communicate that God will one day restore Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]])

####### Special concepts in this chapter #######

######## Remanant ########
Micah speaks about a future hope and a remnant who will return to their homeland. Verses 1-8 are a vision of the future when God will restore Israel to its former glory. These verses will give hope to those about to be removed from their homeland. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]])

##### Links: #####

* __[Micah 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Micah 05

### Micah 05:01

#### daughter of soldiers

The people of a city are spoken of as if they were a woman. The soldiers are attacking the city. AT: "people of the city, whom soldiers are attacking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### with a rod they will strike the judge of Israel on the cheek

The rod is a metonym for a greater man punishing a lesser man with a rod. To strike a man on the cheek was to insult him more than to harm him. AT: "Yahweh will punish the judge of Israel by having the invaders insult the judge of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the judge of Israel

This irony describes the king as having lost so much of his power and authority that he is really only a judge. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]

### Micah 05:02

#### But you, Bethlehem Ephrathah

Yahweh speaks to the people of Judah, and especially to the people of Bethlehem, as if he were speaking to the town of Bethlehem itself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### Ephrathah

This is either the name of the area in which Bethlehem was situated or it is just another name for Bethlehem or it distinguishes this Bethlehem from another. Bethlehem is about six miles south of Jerusalem. It was the hometown of King David. Translators may add this footnote: "The name 'Ephrathah' means 'to be fruitful.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### even though you are small among the clans of Judah, out of you one will come

"even though other clans in Judah have more people in them, it is one of your people who will come"

#### will come to me

Here "me" refers to Yahweh.

#### whose beginning is from ancient times, from everlasting

This refers to the ruler descending from the ancient family of King David. The phrases "from ancient times" and "from everlasting" mean basically the same thing and emphasize how old this family line is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Therefore

"Because what I have just said is true" or "Because this ruler will come later"

#### will give them up

will abandon the people of Israel

#### until the time when she who is in labor bears a child

This refers to the time when the ruler is born, a limited time.

#### the rest of his brothers

"the rest of the ruler's fellow Israelites," who are in exile

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Micah 05:04

#### General Information:

These verses continue describing the ruler from Bethlehem.

#### He will stand and shepherd his flock in the strength of Yahweh

A shepherd, who feeds and protects his sheep, is a metaphor for the ruler, who will provide for and protect the people of Israel. AT: "Yahweh will give him the strength to lead his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the majesty of the name of Yahweh his God

The person's name is a metonym for person's authority. AT: "and people will honor him because Yahweh his God has given him the authority to rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They will remain

the people of Israel will remain

#### remain

"live in safety"

#### he will be great to the ends of the earth

All people from every nation will give honor to Israel's ruler.

#### seven shepherds and eight leaders over men

Here "shepherds" is a metonym for "rulers," another way of saying "leaders over men." The phrase "seven ... and eight" is an idiom for "more than enough." AT: "enough, even more than enough, rulers" or "more than enough shepherds and leaders over men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Micah 05:06

#### They will shepherd the land of Assyria with the sword, and the land of Nimrod in its entrances

The sword is a metonym for killing in war. Here the Israelites ruling over the Assyrians is spoken of ironically as if they were killing sheep instead of herding them. The land of Assyria is a metonym for the people who live there. The entrances to cities were where official business took place. AT: "They will make war against the people of Assyria, and they will rule the cities of the land of Nimrod" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### and the land of Nimrod

The words "they will shepherd" are understood from the beginning of the sentence. They can be repeated. AT: "and they will shepherd the land of Nimrod" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### land of Nimrod

This is another name for the land of Assyria. Nimrod was a hunter and early ruler. Translators may add this footnote: "The name 'Nimrod' means 'rebellion.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He will rescue

The ruler will rescue

#### like dew from Yahweh, like showers on the grass

Dew and rain showers refresh the land and cause things to grow. The Israelites will cause the people among whom they live to live will. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### grass, that do not wait for a man, and they do not wait for the children

"grass. It is not for a man that they wait, nor is it for the children." It is Yahweh alone who causes dew and rain showers.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Micah 05:08

#### General Information:

Yahweh promises that the Israelites who are alive after Yahweh has punished his people with war will completely defeat and rule over their enemies.

#### remnant of Jacob

descendants of Jacob who survive the war

#### among the nations, among many peoples

These two phrases mean basically the same thing and emphasize that the "remnant of Jacob" will live in many different nations. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### like a lion among the animals of the forest, like a young lion among the flocks of sheep

Lions are able to kill and eat any wild animal of the forest, and they easily kill sheep. AT: "like the fiercest of wild animals, like a wild animal that kills helpless livestock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### When he goes through them

when the young lion goes through the flocks of sheep

#### will trample over them and tear

"will jump on them so they fall down, and then he will tear"

#### Your hand ... your enemies

The writer is speaking to Yahweh, so both instances of "your" are masculine singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Your hand will be lifted against your enemies

The hand is a metonym for the power that the hand exercises or a synecdoche for the whole person. To lift the hand is to exercise power. AT: "You will completely defeat your enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### it will destroy them

The hand is a synecdoche for the whole person. AT: "you will destroy them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Micah 05:10

#### in that day

- "at that time" or "when I do those things." These words refer to "the last days" ([Micah 4:1](../04/01.md)). The word "day" can refer to a period of days or even years.

#### I will destroy your horses from among you and will demolish your chariots

The people of Israel used horses and chariots only in battle, and they may have traded for them with the godless nations around them. God did not want the people to trust in their weapons of war to protect them more than they trusted in him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### your horses ... among you ... your chariots ... your land ... your strongholds

Yahweh is speaking to the people of Israel as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]

### Micah 05:12

#### General Information:

Yahweh continues speaking to the people of Israel.

#### the witchcraft in your hand

Being in the "hand" represents the actions that the person does. AT: "the witchcraft that you do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your hand ... you will ... your carved ... your stone ... among you. You will ... your hands ... your Asherah ... among you ... your cities

Yahweh continues to speak to the people of Israel as if they were one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the workmanship of your hands

The abstract noun "workmanship" can be translated using the verb "make." AT: "what your hands have made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### will uproot your Asherah poles

Yahweh speaks of Asherah poles as if they were trees that he would pull out of the ground. AT: "will pull your Asherah poles out of the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Micah 05:intro

#### Micah 05 General Notes ####

####### Special concepts in this chapter #######

######## Messiah ########
This chapter contains a prophecy explaining that the messiah was to be born in Bethlehem. This meaning is made clear in the New Testament. (See: [Micah 5:2](./02.md), [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]) 

####### Other possible translation difficulties in this chapter #######

######## Change in Personal Pronouns ########
Extra care must be taken in translating pronouns in this chapter. Sometimes "I" is a reference to the author and other times it is a reference to Yahweh. There is also a noticable shift where the author stops speaking about the people as "you" and begins speaking about them as "we" or "us."

##### Links: #####

* __[Micah 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Micah 06

### Micah 06:01

#### Now listen ... Listen to Yahweh's lawsuit

Micah speaks to the people of Israel as if he were speaking to mountains that can hear him, so both instances of "listen" are plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### Arise ... state ... let ... your voice

Micah speaks to the people of Israel as if they were one man, so the commands and the word "your" are singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Arise and state your case before the mountains; let the hills hear your voice

Yahweh speaks as if he is in court and the mountains and hills are the judges. He commands the people of Israel to tell the judges why they have done what they did. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the mountains ... the hills ... enduring foundations of the earth

Micah is speaking to these things as if they are humans. Micah is using the mountains, hills, and foundations of the earth as an eternal witness against his people's idolatry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/micah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/micah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Micah 06:03

#### General Information:

This continues Yahweh's lawsuit against the people of Israel. (See: [Micah 6:1-2](./01.md))

#### My people, what have I done to you? How have I wearied you? Testify against me!

God uses questions to emphasize that he is a good God, and he has done nothing to cause the people to stop worshiping him. AT: "My people, I have been good to you. I have done nothing to make you tired of me. If you think I have, testify against me, now." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to you ... wearied you? Testify ... brought you ... rescued you ... Miriam to you ... remember ... you went ... you may know

Yahweh speaks to the people as if they were one man, so all instances of "you" and all the commands are masculine singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### house of bondage

A house is a metaphor for a place in which one lives for a long time. The abstract noun "bondage" can be translated as "to be slaves." AT: "the place where you were slaves for a long time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### what Balak ... devised

"the plans Balak ... made to harm you

#### how Balaam ... answered him

Possible meanings are 1) Balaam obeyed Balak by coming when Balak called him, AT: "how Balaam ... did what Balak asked him to do" or 2) Balaam explained to Balak why Balaam had blessed the Israelites instead of cursing them as Balak had commanded. AT: "what Balaam told Balak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Beor

This is the name of Balaam's father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shittim

This is the name of a place in Moab.

#### so you may know the righteous acts of Yahweh

Yahweh refers to himself by his own name. AT: "so that you may remember the righteous things that I, Yahweh, have done for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/miriam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/miriam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Micah 06:06

#### What should I bring to Yahweh ... God? Should I come ... old? Will Yahweh be pleased ... oil? Should I give ... sin?

Micah speaks as if he were a person who truly wanted to know what God expects him to do. Possible meanings are 1) he asks questions and then in verse 8 answers the questions he has asked or 2) he is using questions to teach the people. AT: "I know that I do no need to bring to Yahweh ... God, or come ... old, and that Yahweh will not be pleased ... oil or if I give ... sin." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### thousands of rams ... ten thousand rivers of oil

"rams in groups of 1,000 ... 10,000 rivers of oil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### He has told you

"Yahweh has told you"

#### good, and what Yahweh requires from you: Act ... God

Many versions read, "good. And what does Yahweh require from you? He wants you to act ... God." or "good. And what does Yahweh require from you but to act ... God?"

#### love kindness

The abstract noun "kindness" can be translated using the adjective "kind." AT: "love being kind to people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]

### Micah 06:09

#### The voice of Yahweh is making a proclamation to the city

The voice represents the person and the city represents the people who live in it. AT: "Yahweh is making an announcement to the people of Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### even now wisdom acknowledges your name

Wisdom is spoken of as a person and is a metonym for the wise person. The word "name" here is a metonym for the person himself, what people think of him, and his authority. AT: "and the wise person will fear you" or "and the wise person will acknowledge that you are good and will obey you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Pay attention to the rod, and to the one who has put it in place

Here "rod" refers to the enemy army with which Yahweh, who "has put it in place," will discipline his people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### There is wealth in the houses of the wicked that is dishonest

Dishonest wealth is a metonym for wealth that people have gained by acting dishonestly. The words "the wicked" refer to wicked people. Houses are a synecdoche for everything a person possesses. AT: "Wicked people have acted dishonestly to gain wealth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### false measures

incorrect weights that people use with scales to increase their wealth by deceiving those with whom they trade

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/abomination.md)]]

### Micah 06:11

#### Should I consider a person to be innocent ... weights?

This can be translated as a statement. AT: "I certainly will not consider a person innocent ... weights." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### deceptive weights

weights with which sellers deceive buyers

#### The rich men are full of violence

Rich men are spoken of as if they were containers, and people treating each other violently is spoken of as if it were a liquid that could be put into a container. AT: "The rich men act violently toward everyone" or "The rich men act violently all the time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their tongue in their mouth is deceitful

The tongue is a synecdoche for the person. AT: "Everything they say is a lie" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tongue.md)]]

### Micah 06:13

#### I will strike you with a terrible blow

Yahweh striking his people with blows is a metaphor for him punishing them. AT: "I have punished you severely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your emptiness will remain inside you

A person or thing being hungry is spoken of as if it were something that could be put in a container, and the people are spoken of as if they were containers. AT: "You will be hungry, and you will not be able to eat enough to satisfy yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Micah 06:16

#### General Information:

Yahweh continues speaking to the people of Israel.

#### The regulations made by Omri have been kept, and all the deeds of the house of Ahab

This can be translated in active form, and you may need to supply the words that the ellipsis omitted. AT: "You have done what Omri commanded, and you have done the same things the house of Ahab did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Omri ... Ahab

Both of these men were kings over the northern kingdom of Israel. God considered both of them to be very wicked. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### house of Ahab

The word "house" is a metonym for the family that lives in the house. AT: "the descendants of Ahab"

#### You walk by their advice

Walking on a path is a metaphor for how a person lives his life. AT: "You do what Omri and Ahab told the people to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will make you, city, a ruin, and you inhabitants an object of hissing

Micah speaks to the people of the city, who can hear him, as if he were speaking to the city itself, which cannot hear him. You may need to make explicit the words that the ellipsis omits. AT: "I will make your city a ruin, and I will make you inhabitants an object of hissing" or "I will make you, city, a ruin, and I will cause everyone who sees you, inhabitants of the city, to hiss at you" or "I will make the city a ruin, and I will make people hiss at the inhabitants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### you will bear the reproach of my people

"you will suffer because my people will reproach you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ahab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Micah 06:intro

#### Micah 06 General Notes ####

####### Structure and formatting #######

This chapter is written as a court case or lawsuit by Yahweh against His people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]])

####### Other possible translation difficulties in this chapter #######

######## Names in Lawsuit ########
Moses, Aaron and Miriam are mentioned as witnesses for Yahweh and against Israel. 
Ahab and Omri are mentioned as kings who were evil and did not follow Yahweh. Obedience to the law of Moses is contrasted with disobedience to the law. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/witness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/witness.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

##### Links: #####

* __[Micah 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Micah 07

### Micah 07:01

#### I have become like the gathering of summer fruit, and like the grapes that have been gleaned

Micah speaks of looking for faithful people but being unable to find any as if he were a person looking for food after the harvesters have taken it all. The idea of a person wanting to gather fruit can be stated clearly. AT: "I have become like someone looking for fruit after the gathering of summer fruit, like a gleaner after the grapes have been gleaned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### no grape cluster ... no ripe early fig

Micah speaks of faithful, upright people as if they were fruit that is good to eat. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Faithful people have disappeared ... land; there is no upright person ... They all lie in wait ... blood; each one hunts

These are exaggerations. AT: "I feel as though faithful people have disappeared ... land and there is no upright person ... I feel as though they all lie in wait ... blood, and each one hunts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### to shed blood

Blood is a metaphor for the death of innocent people. AT: "to kill innocent people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Micah 07:03

#### General Information:

Micah continues speaking about the people of Israel.

#### Their hands are very good

The hand is a synecdoche for the person. AT: "The people are very good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### The best of them is like a brier, the most upright is worse than a thorn hedge

Briers and thorns are good for nothing and harm those who touch them. The Israelite rulers and judges did nothing good and harmed people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the most upright

"those of them who try hardest to do what is good"

#### It is the day foretold by your watchmen, the day of your punishment

Micah speaks to the people of Israel, so both instances of "your" are plural. The word "watchmen" is a metaphor for prophets. AT: "Their prophets have told them that Yahweh would punish them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Now is the time of their confusion

The abstract noun "confusion" can be translated as a verb. AT: "Now is when they do not understand what is happening" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Micah 07:05

#### General Information:

Micah continues speaking to the people of Israel.

#### Do not trust any neighbor ... people of his own house

Micah continues to show that there is no longer anyone good, honest, and loyal to God among God's people. Here he emphasizes that they cannot even trust friends or family.

#### a daughter-in-law against her mother-in-law

The words "rises up" are understood from the previous phrase. They can be repeated here. AT: "a daughter-in-law rises up against her mother-in-law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### his own house

The word "house" is a metonym for the family that lives in the house. AT: "his own family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Micah 07:07

#### General Information:

In verse 8 Micah begins speaking as if he were one woman speaking to her enemy, another woman. This is perhaps the daughter of Zion ([Micah 1:13](../01/13.md)), who represents the people of Israel, speaking to the "daughter of soldiers" ([Micah 5:1](../05/01.md)), who represents the nations which attacked Israel. All commands and instances of "you" are feminine singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### But as for me

Here "me" refers to Micah.

#### I will wait for the God of my salvation

The abstract noun "salvation" can be translated as a verb. AT: "I will wait for the God who saves me" or "I will wait for God, who saves me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### will hear me

The word "hear" represents hearing and acting. AT: "will act to help me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### fall ... rise

These words are metaphors for suffering from disaster and then recovering. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sit in darkness

These words are a metaphor for suffering from disaster. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]

### Micah 07:09

#### General Information:

Micah continues the poem that began in [Micah 7:8](./07.md), speaking as if he were one woman speaking to her enemy, another woman. This is perhaps the daughter of Zion ([Micah 1:13](../01/13.md)), who represents the people of Israel, speaking to the "daughter of soldiers" ([Micah 5:1](../05/01.md)), who represents the nations which attacked Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will bear his rage

Rage is spoken of as if it were a solid object that Yahweh was forcing Micah to carry. AT: "I will suffer because he is angry with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### until he pleads my cause, and executes judgment for me

Yahweh will punish the people of the other nations who harmed the people of Israel.

#### he pleads my cause

Yahweh is spoken of as if he were defending Micah in court. AT: "he defends me against those who harm me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### executes judgment for me

"brings about justice for me"

#### He will bring me to the light

Bringing Micah from darkness ([Micah 7:8](./07.md)) to light is a metaphor for ending the suffering from disaster and enabling him to live well. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### rescue me in his justice

"bring justice to me and rescue me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]

### Micah 07:10

#### General Information:

Micah continues and ends the poem that began in [Micah 7:8](./07.md), speaking as if he were one woman speaking to her enemy, another woman. This is perhaps the daughter of Zion ([Micah 1:13](../01/13.md)), who represents the people of Israel, speaking to the "daughter of soldiers" ([Micah 5:1](../05/01.md)), who represents the nations which attacked Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my enemy ... the one who said ... your God ... My eyes

The words "enemy," "one," "your," and "my" here refer to the women in the poem and so are feminine singular.

#### Where is Yahweh your God?

The enemy uses a question to mock the people of Israel. It can be translated as a statement. AT: "Yahweh your God cannot help you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### My eyes

This phrase here refers to the whole person. AT: "I" or "We" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### she will be trampled down

This can be stated in active form. AT: "her enemies will trample her down" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### like the mud in the streets

People who walk on mud without thinking they are doing anything bad are compared with those who will destroy Israel's enemies without thinking they are doing anything evil. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Micah 07:11

#### General Information:

Micah speaks to the people of Israel as if he were speaking to one man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### A day to build your walls will come

Here "walls" refers to the walls around their cities, which provided safety and security from their enemies.

#### the boundaries will be extended very far

This can be translated in active form. AT: "Yahweh will greatly extend the boundaries of your land" or "Yahweh will greatly increase the size of your kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the River

You may need to make explicit the name of river. AT: "the Euphrates River" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from sea to sea

You may need to make explicit the names of the seas. "from the Mediterranean Sea in the west to the Dead Sea in the east" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from mountain to mountain

"from one mountain to another." Micah does not speak of any particular mountain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the land will be desolate

"the land will be empty" or "no one will live in the land"

#### because of the fruit of their actions

Fruit is a metaphor for the results of an earlier action. AT: "because of the results of what they have done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Micah 07:14

#### Shepherd your people with your rod, the flock of your inheritance

Micah is praying to Yahweh, asking him to protect his people of Israel again. Here "rod" refers to God's leadership and guidance, as a shepherd uses a stick to guide and protect his sheep. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They live alone in a thicket, in the midst of a pastureland

Micah speaks of his people as if they were wild animals hiding in bushes instead of livestock grazing in fields with much grass to eat. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a thicket

a place where many small woody plants grow

#### Bashan and Gilead

These regions are known as rich land for growing food.

#### as in the old days

Bashan and Gilead had been part of Israel long ago, when David was king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### As in the days ... them wonders

Yahweh speaks to the people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]

### Micah 07:16

#### The nations

The word "nations" is a metonym for the people who live in many nations. AT: "The people of the nations nearby" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They will put their hands on their mouths

They do this to show that they are ashamed of what they have done. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### their ears will be deaf

This is an idiom. Nothing anyone says will have any effect on them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### They will lick the dust like a snake

Snakes slither on the ground where dust gets on them, and here the people are being compared to snakes, though it is probably an exaggeration that they will lick the dust. Possible meanings are that these people 1) will literally lie on the ground in shame or 2) will be so ashamed and humbled that it will be as if they were lying on the ground. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### their dens

The people are spoken of as if they were animals, because animals live in "dens." AT: "their homes" or "their hiding places" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Micah 07:18

#### Who is a God like you—who takes ... inheritance?

Micah is emphasizing that there is no God like Yahweh. This can be translated as a statement. AT: "I know that there is no God like you, who takes ... inheritance." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the remnant of his inheritance

"those of his chosen people who have survived his punishment"

#### you ... of the remnant of his inheritance? He does not keep his anger forever, because he delights in his covenant faithfulness.

Here the words "his" and "he" can be stated in second person. AT: "you ... of the remnant of your inheritance, who do not keep your anger forever, because you delight in your covenant faithfulness?" or "you ... of the remnant of your inheritance? You do not keep your anger forever, because you delights in your covenant faithfulness." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### he delights in his covenant faithfulness

The abstract noun "faithfulness" can be stated as "faithful." AT: "he delights in being faithful to his covenant" or "he delights in being faithful to his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### passes over

ignores

#### does not keep his anger

"does not stay angry"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]

### Micah 07:19

#### You will

Here "you" refers to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### on us

Here "us" refers to Micah and the people, but not to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### you will trample our iniquities under your feet. You will throw all our sins into the depths of the sea

Iniquity and sin are spoken of as if they were solid objects. AT: "You will treat our iniquities and sins as if they were not important" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You will give truth to Jacob and covenant faithfulness to Abraham

Here the names of Jacob and Abraham are metonyms for their descendants, the people of Israel to whom Micah was speaking. The abstract nouns "truth" and "faithfulness" can be stated as "trustworthy" and "faithful." AT: "You will show the descendants of Jacob and Abraham that your are trustworthy and faithful to your covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]

### Micah 07:intro

#### Micah 07 General Notes ####

####### Special concepts in this chapter #######

######## Last days ########
This chapter looks forward to the hope of the coming savior for the faithful remnant. This is the future restoration of Israel when true peace will come. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]])

== Prophet==
The prophet was able to speak to God on behalf of the people. Often in this chapter, the prophet speaks in Israel's place and offers repentance to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]])

##### Links: #####

* __[Micah 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | __


## Micah front

### Micah front:intro

#### Introduction to Micah ####

##### Part 1: General Introduction #####

####### Outline of the Book of Micah #######

1. God promises to punish the northern and the southern kingdoms (1:1–16)
1. The guilt of those who take advantage of others 
    - The guilt of the rich who oppress the poor (2:1–11)
    - Promise of deliverance and restoration (2:12–13)
    - Condemnation of rulers, priests and prophets (3:1–12)
  -Yahweh's victory for all Israel 
    - Yahweh's kingdom will rule over all the nations (4:1–10)
    - Israel will first be destroyed, and then will be victorious over its enemies (4:11–13)
    - Messiah will come and shepherd his flock and devastate the nations who fought against him (5:1–6)
    - Messiah will destroy everything that harmed his people (5:7–15)
1. Yahweh's case against Israel 
    - Yahweh reminds Israel when he led them out of slavery in Egypt (6:1–5)
    - Israel's punishment, and true repentance (6:6–16)
1. The misery of Israel and their restoration 
    - The brokenness and misery of Israel (7:1–7)
    - The coming together of nations in Israel (7:8–13)
    - The incomparable view of Yahweh who restores and gives grace (7:14–20)

####### What is the Book of Micah about? #######

This book contains many of Micah's prophecies. Micah repeated many similar prophecies as found in Isaiah.  Micah warned the kingdom of Israel and the kingdom of Judah that the Assyrians would soon attack them. Micah condemned those who were unjust and immoral. He spoke against those who did not work for a living. He also spoke against the false prophets in Israel and Judah. These false prophets were telling the people that Yahweh would never let a foreign kingdom harm or conquer them.
 
Micah called the people to please Yahweh by living righteous and holy lives. However, the sinful way they lived and the unjust way they treated their fellow countrymen proved that they no longer wanted to obey and honor Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### How should the title of this book be translated? #######

Translators may decide to translate the traditional title "The Book of Micah" in a way that is clearer to the readers. They may decide to call it, "The Sayings of Micah." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote Micah? #######

Micah probably wrote this book. Micah lived at the same time as Isiah and Hosea. This was sometime between 750 B.C. - 700 B.C., during the reigns of Jotham, Ahaz, and Hezekiah, kings of Judah. He began prophesying when he lived in the northern kingdom of Israel. Then he moved to the kingdom of Judah. 

##### Part 2: Important Religious and Cultural Concepts #####

####### Who is the deliverer Micah mentions? #######

Micah frequently mentioned a king who would deliver the people. It is clear that Micah meant the Messiah, the descendant of David who would rule forever, though he never referred to him as the Messiah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]])

####### Were the Israelites required to offer sacrifices or live holy lives to please Yahweh? #######

Many of the Old Testament writers were concerned with offering sacrifices according to the law of Moses. However, Micah explained to the people that Yahweh was pleased only when they offered these sacrifices in faith. Without faith, the sacrifices had no meaning. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]) 

##### Part 3: Important Translation Issues #####

####### Why does Micah 1:10-16 sound unusual? #######

This passage sounds unusual because of its construction in Hebrew. It includes what is called a play on words. The names of the cities were used to describe their destruction. "Lachish will be lashed" is an example of this type of construction. This is a poetic element that might not correspond to the actual way they will be punished.

####### What does a translator need to know before translating Micah? #######

Micah did not often explain the historical situation of his prophecies. This may result in the translator's failure to understand implicit information unless they have a good understanding of Micha's time. It is therefore suggested that translators have a good understanding of the history of the kingdoms of Israel and Judah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

####### How do I translate passages where the speaker or addressee is not mentioned explicitly? #######
 
Micah often did not mention who was speaking or who was being addressed. Reading the verses before and after the quote will often help the reader to understand who is speaking or being addressed. It is acceptable to make this information explicit so the reader can more easily understand it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### How should the text of Micah be formatted? #######

The ULB tries to use the same poetic language style as the Hebrew text. Many languages will be capable of doing this but some languages will not be capable of doing this. The ULB also sets apart the poetic portions of the text by indenting the poetic lines. With the exception of the first verse, the entire book is indented because the prophecies were written as a series of poems.



---

