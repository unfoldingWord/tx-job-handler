# <a id="nam"/>Nahum

## Nahum 01

### Nahum 01:01

#### General Information:

Nahum describes the destruction of Nineveh in poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### The declaration about Nineveh. The book of the vision of Nahum, the Elkoshite

These words are an introduction to the entire book. This can be stated as a complete sentence. AT: "This is the book of the vision of Nahum, the Elkoshite, which gives a declaration about Nineveh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Elkoshite

A person from the village of Elkosh (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nahum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nahum.md)]]

### Nahum 01:02

#### General Information:

Nahum begins to describe Yahweh coming to judge his enemies and to save his people. The vision is full of metaphorical language and uses different kinds of parallelism. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### full of wrath

"very angry"

#### he continues his anger for

"continues to be angry with"

#### slow to anger

"slow to become angry"

#### he will not allow the wicked to go unpunished

This emphatic negative statement can be translated positively. AT: "he will always be sure to punish the wicked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### Yahweh makes his way in the whirlwind and the storm, and the clouds are the dust of his feet

The biblical writers often associated Yahweh's presence with powerful storms. Here Yahweh rides in strong storm winds and his feet are creating clouds by kicking up dust as he is coming to judge the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the dust of his feet

"the dust that his feet kick up"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]

### Nahum 01:04

#### General Information:

Nahum continues to describe Yahweh coming to judge his enemies and to save his people.

#### Bashan is weak, and Carmel also; the flowers of Lebanon are weak

The word translated as "weak" can also mean "wither" or "dry out." Bashan was known for its good pastureland where people tended sheep and cattle, "Carmel" refers to Mount Carmel, which was known for its tree orchards, and the snow from the mountains in Lebanon kept that place fertile. Since Yahweh dries up all the rivers and causes drought, these fertile places will no longer be fertile. AT: "The fields of Bashan wither, the trees of Mount Carmel die, and the flowers of Lebanon fade" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the hills melt

Possible meanings are 1) the earthquake causing the hills to crumble to pieces is spoken of as if the hills were melting or 2) the water from the storms coursing down the hills and causing them to erode is spoken of as if the hills were melting. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the earth collapses

Possible meanings are 1) the mountains and hills collapse or 2) the entire ground begins to move with violent motions.

#### the world and all people who live in it

Here the word "world" refers to the inhabited places on the earth. The verb for this phrase is understood from the previous phrase. AT: "the world shakes and all the people who live in it collapse" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/carmel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]

### Nahum 01:06

#### General Information:

Nahum continues to describe Yahweh coming to judge his enemies and to save his people.

#### Who can stand before his wrath? Who can resist the fierceness of his anger?

These two rhetorical questions mean basically the same thing. They can be translated with statements. AT: "No one can stand before his wrath! No one can resist the fierceness of his anger!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### fierceness of his anger

"intensity of his anger" or "amount of his anger"

#### His wrath is poured out like fire

Nahum speaks of Yahweh's anger as if it were a liquid that he pours out and which burns like fire. This can be stated in active form. AT: "He pours out his wrath like fire" or "He expresses his fierce anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the rocks are broken apart by him

This can be stated in active form. AT: "he breaks apart the rocks" or "he causes the rocks to break apart" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Nahum 01:07

#### a stronghold ... those who take refuge in him

Nahum speaks of Yahweh as if he were a place where people can be safe from those who wish to harm them, and of those who trust Yahweh to protect them as if they were taking refuge inside that safe place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the day of trouble

"in times of trouble" or "when troubles happen." The word "day" here refers to a general period of time.

#### he will make a full end to his enemies

The idiom "make a full end" refers to causing his enemies to die. AT: "he will completely destroy his enemies" or "he will kill all his enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### with an overwhelming flood

Nahum speaks of Yahweh destroying his enemies in such a way that they will be powerless to avoid death as if Yahweh caused them to drown in a great flood of water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will pursue them into darkness

Here the word "darkness" represents the place of the dead, which is characterized as a dark place. Nahum speaks of Yahweh killing his enemies as if he were chasing them into this dark place. AT: "he will cause all his enemies to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]

### Nahum 01:09

#### General Information:

Nahum tells the people of Nineveh how Yahweh will deal with them.

#### What are you people plotting against Yahweh?

This rhetorical question emphasizes the futility of making evil plans against Yahweh. AT: "It is futile for you people to plot against Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### He will make a full end to it

The idiom "make a full end" refers to causing something to exist no longer. AT: "He will completely stop what you do" or "He will cause your plotting to fail" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### trouble will not rise up a second time

Possible meanings are 1) "trouble" is a metonym for the punishment that Yahweh will inflict upon the people. AT: "Yahweh will not have to punish you a second time" or 2) "trouble" refers to the trouble that the people cause by plotting against Yahweh. AT: "you will not cause trouble a second time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they will become tangled up like thornbushes

Possible meanings for this metaphor are 1) the people who plot against Yahweh will not be able to free themselves from the trouble that Yahweh will bring upon them, like a person who is tangled up in thornbushes cannot easily free himself or 2) just as thornbushes burn more quickly when they are tangled together, Yahweh will quickly destroy those who plot against him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will be saturated in their own drink

Nahum speaks of those who plot against Yahweh suffering the consequences of their plans as if they were completely drunk with alcohol. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will be completely devoured by fire like dry stubble

Nahum speaks of Yahweh completely destroying those who plot against him as if fire would burn them up like fire burns up dry stubble. This can be stated in active form. AT: "fire will completely devour them like it devours dry stubble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### devoured by fire

Nahum speaks of fire burning something completely as if the fire were devouring that thing. AT: "burned up by fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### promoted wickedness

encouraged people to do wicked things

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Nahum 01:12

#### General Information:

Yahweh speaks to the Israelites about Nineveh.

#### Even if they are at their full strength and full numbers

This refers to the Assyrians or to the people of Nineveh.

#### they will nevertheless be sheared

Yahweh speaks of destroying the people of Nineveh as if the were sheep that he will shear. This can be stated in active form. AT: "I will nevertheless shear them" or "I will nevertheless destroy them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Now will I break that people's yoke from off you; I will break your chains

Yahweh speaks of freeing Judah from Assyrian oppression as if he were breaking the yoke and chains that the Assyrians had placed on them. AT: "Now I will free you from that people and they will no longer oppress you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yoke.md)]]

### Nahum 01:14

#### I will cut off the carved figures and the cast metal figures from the houses of your gods

Yahweh speaks of destroying the Assyrian idols as if he were cutting them off, like a person would cut a branch from a tree. The word "house" is a metonym for the temples in which the people worshiped these idols. AT: "I will destroy the carved figures and the cast metal figures that are in the temples of your gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will dig your graves

It is implied that Yahweh will also bury them in the graves that he digs for them. AT: "I will dig your graves and bury you in them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### Nahum 01:15

#### on the mountains there are the feet of someone who is bringing good news

Here the word "feet" represent the person who is running in order to declare a message. AT: "on the mountains there is someone who is bringing good news" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### wicked one ... he

Nahum refers to the people of Nineveh as though they were one person.

#### he is completely cut off

Nahum speaks of the people of Nineveh being completely destroyed as if they had been cut off, like a person would cut a branch from a tree. This can be stated in active form. AT: "he is completely destroyed" or "Yahweh has completely destroyed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]

### Nahum 01:intro

#### Nahum 01 General Notes ####

####### Structure and formatting #######

Some translations prefer to set apart extended quotations, prayers and songs. The ULB and many other English translations indent the lines of the entire book (except for verse 1 of this chapter) because they are poetic prophecy. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

Despite being divided into three chapters, this book consists of one long prophecy. 

####### Special concepts in this chapter #######

######## Yahweh's anger against Nineveh ########
This prophecy should be read in reference to the book of Jonah. That book described how the people of Niniveh, Assyria's capital city, repented when Jonah warned them that Yahweh was angry at them. The book of Nahum, written a little over one hundred years later than when Jonah was set, indicates that the Ninevites would be punished by God, but only after he had used them for his own purposes. These actions of Yahweh, although described as vengeance or anger, do not have the same sinful quality as they usually do with humans. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

######## Complete destruction ########
At that time, Assyria controlled almost the entire Near East. Nahum prophesied that the Assyrians would be so completely destroyed as a nation that they would no longer even be a people group. This prophecy came true very suddenly. 

##### Links: #####

* __[Nahum 01:01 Notes](./01.md)__
* __[Nahum intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Nahum 02

### Nahum 02:01

#### General Information:

Nahum often wrote prophecy in the form of poetry. Hebrew poetry uses different kinds of parallelism. Here he begins to describe the destruction of Nineveh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### The one who will dash you to pieces

The word "you" refers to Nineveh. Nahum speaks of an army or military leader destroying Nineveh as if he were to shatter Nineveh like one would shatter a clay pot. AT: "The one who will destroy you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The one who will dash you

The person who is "the one" is not clear, so translate using a general term. AT: "Someone who will break you"

#### is coming up against you

The idiom to "come against" means to attack. AT: "is preparing to attack you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Man the city walls, guard the roads, make yourselves strong, assemble your armies

Nahum speaks to the people of Nineveh. He tells them to prepare for battle, although he knows that the enemy will destroy the city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### Man the city walls

Nineveh had a large, thick wall surrounding it. This refers to placing soldiers on the top of the wall in order to fight off attackers. This can be translated with a more general phrase if necessary. AT: "Man the fortifications" or "Prepare the defenses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### guard the roads

This refers to having soldiers watch the roads leading to the city so that they can keep track of the enemy's approach.

#### make yourselves strong

This is an idiom that means to prepare oneself for action. Here it applies to military action. AT: "prepare yourselves for battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### For Yahweh is restoring the majesty of Jacob, like the majesty of Israel

The words "Jacob" and "Israel" are metonyms for the people who are descended from Jacob. Possible meanings are 1) the word "Jacob" refers to the southern kingdom and the word "Israel" refers to the northern kingdom. AT: "For Yahweh is restoring the majesty of Judah, as he promised to restore the majesty of Israel" or 2) both "Jacob" and "Israel" refer to the nation as a whole, included both northern and southern kingdoms and the two lines are parallel. AT: "For Yahweh is restoring the majesty of all Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the plunderers

people who steal things by force, usually in war

#### destroyed their vine branches

Possible meanings are 1) this is a metaphor in which the Assyrians taking away Israel's possessions by force is spoken of as if Israel were a vine whose branches the Assyrians had stripped bare. AT: "robbed them of all of their possession, like one would strip bare vine branches" or 2) the words "vine branches" are a synecdoche for the agricultural fields throughout the nation. AT: "destroyed their fields of crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]

### Nahum 02:03

#### The shields of his mighty men are red

Possible meanings are 1) the shields appear red as the light from the sun reflects upon their metal surfaces or 2) the shields are covered with leather that has been dyed red.

#### his mighty men

the soldiers of the one "who will dash" Nineveh "to pieces" ([Nahum 2:1](./01.md)).

#### the chariots flash with their metal

This likely refers to the light from the sun reflecting upon the metal chariots.

#### on the day that they are made ready

This can be stated in active form. AT: "when the soldiers have made them ready" or "when the soldiers have prepared them to attack" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the cypress spears are waved in the air

This can be stated in active form. AT: "the soldiers wave their cypress spears in the air" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### cypress

a type of tree whose wood is good for weapons (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### The chariots speed through the streets

"The soldiers drive the chariots wildly through the streets"

#### They look like torches

Nahum compares the way that the light from the sun reflects upon the chariots with torches whose fire gives light. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they run like lightning

Nahum compares the way that the light from the sun reflects upon the chariots, and the quickness with which the chariots move, with lightning that flashes quickly in the sky. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]

### Nahum 02:05

#### The one who will dash you to pieces

The word "you" refers to Nineveh. Nahum speaks of an army or military leader destroying Nineveh as if he were to shatter Nineveh like one would shatter a clay pot. See how you translated this in [Nahum 2:1](./01.md). AT: "The one who will destroy you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in their march

The word "march" can be translated as a verb. AT: "as they march" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### The large shield is made ready to protect these attackers

This can be stated in active form. AT: "The attackers make ready the large shield to protect themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The large shield

This refers to a large cover that those who besieged a city would set up over themselves and their battering rams to protect themselves against the arrows and other projectiles with which the people in the city would attack them.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]

### Nahum 02:06

#### The gates at the rivers are forced open

This can be stated in active form. AT: "The enemy forces open the gates at the rivers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The gates at the rivers

This refers to the gates that controlled the flow and direction of the river.

#### Huzzab is stripped of her clothes and is taken away

This can be stated in active form. AT: "The enemy strips Huzzab of her clothes and takes her away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Huzzab is stripped of her clothes and is taken away

The exact meaning of the word "Huzzab" is uncertain. Two possible meanings are 1) it is the name of a queen in Nineveh and the sentence means that the attacking soldiers have stripped her of her clothes in order to humiliate her and then have carried her off into captivity or 2) it is the name of an idol and the sentence means that the attackers have stripped the gold and silver off the idol and have carried it away. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### her female servants moan like doves

The moaning sounds that the female servants make sound like the sounds that doves make.

#### her female servants

If the word "Huzzab" refers to a queen, then this phrase refers to the young women who attended her. If the word "Huzzab" refers to an idol, then this phrase refers to the young women who worked as temple prostitutes.

#### beating on their breasts

Beating one's breast was a gesture used to express great mourning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]

### Nahum 02:08

#### Nineveh is like a leaking pool of water, with its people fleeing away like rushing water

Nahum compares the way that the people flee from the city of Nineveh with the way that water gushes from a reservoir of water when the dam has been broken. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Take the silver plunder ... Nineveh's beautiful things

It is not clear who is speaking here. This may be an apostrophe in which Nahum gives directions to the attackers, or the attackers may be speaking and giving directions to one another. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### Take the silver plunder, take the gold plunder

The word "plunder" means things stolen by force, usually in war. AT: "Take the silver as plunder, take the gold as plunder" or "Take the silver, take the gold"

#### there is no end to it

The words "no end" are an exaggeration to express that there is a great amount of something. AT: "there is so much of it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### to the splendor of all Nineveh's beautiful things

This phrase refers to the silver, gold, and other treasures in Nineveh. The verb may be supplied from the previous phrase. AT: "there is no end to the splendor of all Nineveh's beautiful treasures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Everyone's heart melts

Nahum speaks of the people losing courage as if their hearts melt like wax. AT: "Everyone loses courage" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### everyone's knees strike together

This describes a physical response to great fear. The people's legs shake so badly that their knees knock together and they are unable to walk or run.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Nahum 02:11

#### General Information:

In these verses, Nahum speaks of the people of Nineveh as if they were a group of lions, and of the city Nineveh as if it were their den. The metaphor speaks of the way in which the Assyrians would conquer other people and take their possessions as their own as if they were lions hunting prey and bringing the dead animals back to their den. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Where now is the lions' den ... afraid of nothing?

Nahum uses this rhetorical question to mock Nineveh, which has been destroyed. AT: "The lions' den is nowhere to be found ... afraid of nothing." or "Look at what has become of the lions' den ... afraid of nothing!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### he strangled victims

"he choked victims." This is probably a reference to the way that lions usually kill their prey, by biting its throat. AT: "he killed his victims" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### filled his cave with victims, his dens with torn carcasses

These two phrases are saying the same thing in different ways. The verb may be supplied for the second phrase. AT: "filled his cave with victims, and filled his dens with torn carcasses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Nahum 02:13

#### See, I am against you

Here Yahweh begins to speak.

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you."

#### the sword will devour your young lions

Here the word "sword" is a metonym for soldiers who attack with swords and is spoken of as if it were a person who eats its victims. Nahum also continues to speak to the people of Nineveh as if they were lions. AT: "attackers will kill your people with swords" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will cut off your prey from your land

Yahweh speaks of the people of Nineveh as if they were lions who preyed upon the nations. Possible meanings are 1) the word "prey" is a metonym for the things that they have taken from those upon whom they preyed, and Yahweh speaks of taking those things away from them as if it were cutting off their prey. AT: "I will take away from your land all the things that you took from others" or 2) Yahweh speaks of the nations whom the people of Nineveh had plundered as if they were Nineveh's prey, and preventing Nineveh from plundering any more nations as if he were cutting off their prey. AT: "I will stop you from preying upon any other nation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the voices of your messengers will be heard no more

This likely refers to the messengers that the Assyrians sent out to other nations to demand surrender or payment of tribute. This can be stated in active form. AT: "no one will ever hear the voices of your messengers again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Nahum 02:intro

#### Nahum 02 General Notes ####

####### Structure and formatting #######

Some translations prefer to set apart extended quotations, prayers and songs. The ULB and many other English translations indent the lines of the entire book (except for verse 1 of chapter 1) because they are poetic prophecy. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

Despite being divided into three chapters, this book contains one long prophecy. 

####### Special concepts in this chapter #######

######## Complete destruction ########
At that time, Assyria controlled almost the entire Near East. Nahum prophesied that the Assyrians would be so completely destroyed as a nation that they would no longer even be a people group. This prophecy came true and did so very suddenly. At times, this chapter is very violent in describing the destruction of Assyria, and this violence should not be toned down through the use of euphemism.

##### Links: #####

* __[Nahum 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Nahum 03

### Nahum 03:01

#### General Information:

Nahum often wrote prophecy in the form of poetry. Hebrew poetry uses different kinds of parallelism. Here he continues to describe the destruction of Nineveh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the city full of blood

Here the word "blood" represents bloodshed and refers to the people who have committed murder. AT: "the city full of murderers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### It is all full of lies

Here the word "lies" is a metonym for those who tell lies. AT: "It is full of liars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the noise of whips and the sound of rattling wheels, prancing horses, and bounding chariots

These phrases describe the sound of chariots rushing through the streets as their drivers use their whips on the horses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]

### Nahum 03:03

#### heaps of corpses, great piles of bodies

These two phrases mean basically the same thing and indicate that there were so many dead bodies that the attackers piled them in heaps. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### corpses

bodies of people who have died

#### There is no end to the bodies

The words "no end" are an exaggeration for the great number of bodies that the attackers piled into heaps. AT: "There are too many bodies to count" or "There are a great number of bodies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the lustful actions of the beautiful prostitute

Nahum speaks of Nineveh causing other nations to be subject to her as if the city were a prostitute who seduces men with her beauty. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the expert in witchcraft

Nahum speaks of Nineveh causing other nations to be subject to her as if the city were a witch who casts a spells on others. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who sells nations through her prostitution, and peoples through her acts of witchcraft

Here the word "sells" implies that the people of Nineveh cause other nations and peoples to become slaves. Nineveh uses her beauty, power, and influence to make others her slaves. AT: "who by her prostitution and witchcraft causes the people of other nations to become her slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]

### Nahum 03:05

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you"

#### I will raise up your skirt over your face and show your private parts to the nations

This refers to the practice of publicly humiliating prostitutes by stripping them naked in front of the community. This continues the metaphor of Yahweh speaking of the city of Nineveh as if it were a prostitute. AT: "I will publicly humiliate you, as one would humiliate a prostitute by raising up her skirt over her face and showing her private parts to all the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your shame to the kingdoms

This phrase explains the purpose of lifting up Nineveh's skirt. The verb may be supplied from the previous phrase. AT: "I will show your shame to the kingdoms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### I will throw disgusting filth on you

The words "disgusting filth" refer to all kinds of garbage. Throwing garbage at a person was a sign of strong contempt. AT: "I will show my contempt for you, like a person would throw disgusting filth at another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### who will weep for her?

The people ask this rhetorical question to emphasize the negative answer. AT: "no one will weep for her." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Where can I find anyone to comfort you?

Yahweh uses this rhetorical question to emphasize that there will be no one who will be able to comfort Nineveh. AT: "There will be no one to comfort you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahwehofhosts.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]

### Nahum 03:08

#### General Information:

Nahum speaks to the people of Nineveh as though they were the city itself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### are you better than Thebes ... itself?

Nahum asks this rhetorical question to emphasize the negative answer that it anticipates. AT: "you are not better than Thebes ... itself." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Thebes

This was the former capital of Egypt, which the Assyrians had conquered. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### that was built on the Nile River

"that was situated by the Nile River"

#### whose defense was the ocean, whose wall was the sea itself

These two phrases share similar meanings. The words "ocean" and "sea" both refer to the Nile River, which ran near the city. Nahum speaks of the Nile as if it were the wall that protected the city. AT: "which had the Nile river as its defenses, as some cities have a wall for theirs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Cush and Egypt were her strength

"Ethiopia and Egypt strengthened her" or "Cush and Egypt were her allies"

#### there was no end to it

The word "it" refers to the "strength" that Cush and Egypt gave to Thebes. That there was no end to it is a hyperbole that expresses the great amount of strength. AT: "their strength was very great" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Put and Libya

These are the names of places in northern Africa that were close to Thebes. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nineveh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ethiopia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Nahum 03:10

#### General Information:

Nahum continues to speak to the people of Nineveh as though they were the city itself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yet Thebes was carried away

The word "Thebes" represents the people who lived in Thebes. This can be stated in active form. AT: "Yet those who attacked Thebes carried the people away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### she went into captivity

The word "she" refers to Thebes and represents the people who lived there. AT: "they went into captivity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### her young children were dashed in pieces

This is a brutal description of the soldiers killing children. This can be stated in active form. AT: "enemy soldiers dashed her young children to pieces" or "enemy soldiers beat her young children to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### at the head of every street

The beginning of a street is spoken of as if it were the head. Also, "every" is a generalization that means many places all over the city. AT: "on every street corner" or "in the streets all over the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### all her great men were bound in chains

This can be stated in active form. AT: "they bound all her great men in chains" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You also will become drunk

Here the word "You" refers to Nineveh. Nahum speaks of the people of Nineveh suffering and dying in battle as if they had become drunk from drinking too much wine. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Nahum 03:12

#### General Information:

Nahum continues to speak to the people of Nineveh as though they were the city itself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### All your fortresses

Possible meanings for the word "fortresses" are 1) it refers to Nineveh's fortifications, such as the wall that surrounded the city AT: "All of your fortifications" or "All of your defenses" or 2) it refers to the fortified cities that were situated along Assyria's borders and prevented enemy armies from attacking Nineveh. AT: "All of your fortified cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### All your fortresses will be like fig trees with the earliest ripe figs: if they are shaken, they fall into the mouth of the eater

Nahum compares the ease with which the attackers will conquer Nineveh with the ease with which a person can cause ripe figs to fall from a tree. AT: "Your enemies will destroy your fortresses as easily as a person can shake a fig tree and eat the first ripe figs that fall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the earliest ripe figs

This refers to the figs that would ripen first on the tree. These figs fell from the tree easily, so that a person only had to shake the tree to make them fall. Figs that ripened later would require a person to climb the tree and pick them by hand. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### if they are shaken

"if the trees are shaken." This can be stated in active form. AT: "if a person shakes the trees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they fall into the mouth of the eater

"the figs fall into the mouth of the eater." This is an exaggeration. By saying that the figs fall from the tree into the mouth of the one who eats it, Nahum emphasizes that the figs are ready to eat immediately. AT: "a person can eat the fig immediately" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the people among you are women

In this ancient culture, women were not warriors for a number of reasons, including their being generally weaker physically than men. Here Nahum speaks of Nineveh's warriors losing their strength and courage to fight as if the people in the city were all women. AT: "your people are all like women who are weak and cannot defend themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the gates of your land have been opened wide to your enemies

This can be stated in active form. AT: "the gates of your land are wide open to your enemies" or "someone has opened wide to your enemies the gates of your land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the gates of your land have been opened wide to your enemies

Possible meanings are 1) if "fortresses" in v. 12 refers to the Nineveh's defenses, then "the gates of your land" refers to the gates in the walls around Nineveh. AT: "the gates of your city are wide open for your enemies to attack" or 2) if "fortresses" in v. 12 refers to the fortified cities that were situated along Assyria's borders, then "the gates of your land" is a metaphor in which those cities are spoken of as if they were gates that prevented enemy armies from entering the land. AT: "your land is defenseless before your enemies because they have destroyed the cities that protected your borders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fire has devoured their bars

Possible meanings are 1) if "fortresses" in v. 12 refers to the Nineveh's defenses, then "their bars" refers to the bars that locked the gates in the walls around Nineveh. AT: "fire has destroyed the bars that lock your city gates" or 2) if "fortresses" in v. 12 refers to the fortified cities that were situated along Assyria's borders, then "their bars" is a metaphor in which those cities are spoken of as if they were locked gates that prevented enemy armies from entering the land. AT: "the cities on your borders can no longer protect you, just as gates can no longer protect a city when fire has destroyed their bars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fire has devoured

Nahum speaks of fire burning up and destroying as if fire were eating. AT: "fire has destroyed" or "fire has burned up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Nahum 03:14

#### General Information:

Nahum continues to speak to the people of Nineveh as though they were the city itself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Go draw water for the siege ... pick up the molds for the bricks

Nahum speaks to the people of Nineveh. He tells them to prepare for battle and to repair the walls, although he knows that the enemy will destroy the city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### strengthen your fortresses

"repair the fortifications"

#### go into the clay and tread the mortar; pick up the molds for the bricks

These phrases refer to making mud bricks that they will use to repair the city's wall.

#### Fire will devour you there

Nahum speaks of fire burning and destroying as if it were eating. AT: "Fire will destroy you there" or "Your enemies will burn you with fire there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the sword will destroy you

Here the word "sword" is a metonym for the enemies who will attack with swords. AT: "your enemies will kill you with their swords" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### It will devour you as young locusts devour everything

The word "It" refers to the "sword," which is personified as eating those whom it kills. The soldiers using their swords to kill everyone in Nineveh is compared with the way that a swarm of locusts eats every plant in its path. AT: "Your enemies' swords will kill all of you, just as easily as a swarm of locusts devours everything in its path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Make yourselves as many as the young locusts, as many as the full-grown locusts

These words begin a new paragraph where Nahum compares the number of people in Nineveh with the large number of locusts in a swarm.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Nahum 03:16

#### General Information:

Nahum speaks to the people of Nineveh as though they were the city itself. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You have multiplied your merchants more than the stars in the heavens

This exaggeration emphasizes the great number of merchants who lived and worked in Nineveh. AT: "It is as if you have more merchants than there are stars in the sky" or "You have more merchants than anyone could count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### they are like young locusts: they plunder the land and then fly away

Nahum compares the way that these merchants, who have made their profit by selling their goods in Nineveh, will flee from the city when the battle begins with the way that locusts fly away after they have eaten all of the plants in their path. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### your generals are like swarms of them that camp in the walls on a cold day. But when the sun rises they fly away

Nahum compares the way that the officials in Nineveh will flee when the battle starts with the way that locusts will remain still while it is cold, but will fly away when the sun rises and the air becomes warm. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### to no one knows where

"and no one knows where they have gone"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Nahum 03:18

#### your shepherds are asleep; your rulers are lying down resting

These two lines share similar meanings. Nahum speaks of the leaders of Assyria as if they were shepherd who are to care for their sheep. He speaks of the shepherds and rulers dying as if they had fallen asleep. AT: "your leaders who are like shepherds are dead; your rulers are all dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Your people are scattered on the mountains

Nahum speaks of the people of Nineveh as if they were sheep that scatter after the shepherds have died. AT: "Your people are scattered like sheep on the mountains" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### No healing is possible for your wounds. Your wounds are severe

Nahum speaks of the certainty of the destruction of Nineveh and the defeat of its king as if the king had suffered an incurable wound. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### No healing is possible for your wounds

The word "healing" can be translated with a verbal phrase. AT: "No one is able to heal your wounds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Who has escaped your constant wickedness?

This rhetorical question emphasizes the negative answer that it anticipates. All of the nations that were near Assyria had suffered because of Assyria's constant wickedness. AT: "No one has escaped your constant wickedness." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Nahum 03:intro

#### Nahum 03 General Notes ####

####### Structure and formatting #######

Some translations prefer to set apart extended quotations, prayers and songs. The ULB and many other English translations indent the lines of the entire book (except for verse 1 of chapter 1) because they are poetic prophecy. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

Despite being divided into three chapters, the book contains one long prophecy. 

####### Special concepts in this chapter #######

######## Euphemism ########
This chapter speaks about the evils of the Assyrians in violent ways. It is important to avoiding toning down this language through the use of euphemism, if at all possible. Although there is some hyperbole, the reader should not assume that the author intends this writing to be taken as completely hyperbolic. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

##### Links: #####

* __[Nahum 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | __


## Nahum front

### Nahum front:intro

#### Introduction to Nahum ####

##### Part 1: General Introduction #####

####### Outline of the Book of Nahum #######

1. Introduction to "the book of the vision of Nahum" (1:1)
1. The coming destruction of Nineveh 
    - The power and goodness of Yahweh to conquer his enemies (1:2–8)
    - The destruction of Nineveh because of its people's evil (1:9–15)
1. The fierceness of the coming attack on Nineveh (2:1–13)
1. The doom of Nineveh and the mockery of it by its enemies (3:1–19)

####### What was the Book of Nahum about? #######

The Book of Nahum contains prophecies about how God would judge and punish Nineveh, the capital city of the Assyrian Empire. The Assyrians had already conquered the northern kingdom of Israel, and they were threatening the southern kingdom of Judah. The book's purpose was to give hope to Judah that the Assyrians would be defeated.

####### How should the title of this book be translated? #######

Translators may decide to translate this traditional title, "The Book of Nahum," in a way that is clearer to the readers. They may decide to call it "The Sayings of Nahum." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Nahum? #######

It is probable that Nahum wrote this book. He was a prophet from Elkosh, an unknown city which was probably in Judah. The book was written before the fall of Nineveh in about 612 B.C. The prophet also mentioned the destruction of Thebes, a city in Egypt, which occurred about 663 B.C. Therefore, the book was written sometime between these two dates. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### What is the importance of the descriptions of locusts in 3:15–17? #######

Locust attacks occurred often in the ancient Near East. Certain kinds of grasshoppers would come in countless numbers. There would be so many that they would darken the sky like a black cloud that blocked the sunlight. They often came after a prolonged period without rain. They came down on whatever crops were surviving in the fields and stripped them bare of their leaves. The locusts were unstoppable and caused terrible damage. For this reason locust attacks served as a very powerful image of military attacks in the Old Testament.

There are various names for locusts in the original language of the Old Testament. It is uncertain whether these refer to different kinds of locusts or to the same kind of locust in different stages of growth. For this reason, versions of the Bible differ in how they translate these terms.

##### Part 3: Important Translation Issues #####

####### What emotions were present in the various speakers in the Book of Nahum? #######

In this book Nahum spoke to the people of Israel. When he spoke to the Israelites he wanted to comfort them. Nahum and Yahweh also spoke to the Ninevites. When Nahum and Yahweh spoke against the Ninevites they often mocked them as well. This manner of speech was similar to speech in the ancient Near East when conquerors laughed at their victims. It is important for translators to represent well both the emotions of comfort and of mockery in translation.



---

