# <a id="col"/>Colossians

## Colossians 01

### Colossians 01:01

#### General Information:

Though this letter is from Paul and Timothy to the Colossian believers, later in the letter Paul makes it clear that he is the writer. Most likely Timothy was with him and wrote the words down as Paul spoke.

#### General Information:

Throughout this letter the words "we," "our," and "ours" include the Colossians unless noted otherwise. The words "you," "your," and "yours" refer to the Colossian believers and so are plural unless noted otherwise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### an apostle of Christ Jesus through the will of God

"whom God chose to be an apostle of Christ Jesus"

#### We give ... our Lord ... we always

These words do not include the Colossians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/colossae.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/colossae.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Colossians 01:04

#### We have heard

Paul is excluding his audience. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### your faith in Christ Jesus

"your belief in Christ Jesus"

#### because of the certain hope reserved for you in heaven

Here "certain hope" stands for what the believer can confidently expect, that is, the things that God has promised to do for all believers. These things are spoken of as if they were physical objects that God was keeping in heaven for the believers to possess later. AT: "because you are certain that God, who is in heaven, will do the many good things that he has promised you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the word of truth, the gospel

"Word of truth" here is a synecdoche for the "message of the gospel." AT: "the message from God, the gospel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### This gospel is bearing fruit and is growing

"Fruit" here is a metaphor for "result" or "outcome." AT: "This gospel is having good results, more and more"  or "This gospel is having increasing results" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in all the world

This is a generalization referring to the part of the world that they knew about. AT: "throughout the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the grace of God in truth

"the true grace of God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Colossians 01:07

#### our beloved ... our behalf ... to us

The words "our" and "us" do not include the Colossians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### gospel as you learned it from Epaphras, our beloved fellow servant, who

"gospel. It is exactly what you learned from Epaphras, who is our beloved fellow servant and who" or "gospel. It is exactly what Epaphras, our beloved fellow servant, taught you. He"

#### Epaphras, our beloved fellow servant, who is a faithful servant of Christ on our behalf

Here "on our behalf" means that Epaphras was doing work for Christ that Paul himself would have done if he were not in prison.

#### Epaphras

the man who preached the gospel to the people in Colossae (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### your love in the Spirit

Paul speaks of the Holy Spirit as if he were a place in which the believers were located. AT: "how the Holy Spirit has enabled you to love believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Colossians 01:09

#### Connecting Statement:

Because the Spirit has enabled them to love others, Paul prays for them and tells them here how he prays for them.

#### Because of this love

"Because the Holy Spirit has enabled you to love other believers"

#### we heard ... we have not stopped ... We have been asking ... We have been praying

These words do not include the Colossians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### from the day we heard this

"from the day Epaphras told us these things"

#### that you will be filled with the knowledge of his will

Paul speaks of the Colossian believers as though they were containers. AT: "that God will fill you with what you need to know so that you can do his will" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in all wisdom and spiritual understanding

", so that the Holy Spirit will make you wise and able to understand what God wants you to do"

#### that you will walk worthily of the Lord

Walking here signifies behavior in life. AT: "that you will live the way God expects you to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in pleasing ways

"in ways that will please the Lord"

#### will bear fruit

Paul is speaking of the Colossian believers as if they were trees or plants. As a plant grows and bears fruit, so also believers are to keep getting to know God better and doing good deeds. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Colossians 01:11

#### We pray

The word "we" refers to Paul and Timothy but not to the Colossians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### into all perseverance and patience

Paul speaks of the Colossian believers as if God would move them into a location of perseverance and patience. In reality, he is praying that they will never stop trusting in God and that they will be completely patient as they honor him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### has made you able to have a share

"has allowed you to share"

#### has made you able

Here Paul is focusing on his readers as receivers of God's blessings. But he does not mean that he himself has no share in those blessings.

#### inheritance

Receiving what God has promised believers is spoken of as if it were inheriting property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in light

This idea is opposite to the idea of the dominion of darkness in the next verse. AT: "in the glory of his presence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perseverance.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perseverance.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Colossians 01:13

#### Connecting Statement:

Paul talks about the ways in which Christ is excellent.

#### He has rescued

"God the Father has rescued"

#### the dominion of darkness

"Darkness" here is a metonym for evil. AT: "the area controlled by evil forces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his beloved Son

"God the Father's beloved Son, Jesus Christ"

#### In his Son we have redemption

Paul often speaks as if the believers were "in" Jesus Christ or "in" God. AT: "By means of his Son we have redemption" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### redemption, the forgiveness of sins

"redemption; his Son forgives our sins" or "redemption; the Father forgives us through his Son"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Colossians 01:15

#### The Son is the image of the invisible God

Here "image" does not mean a representation of something that is visible. Instead, "image" here means that by knowing the Son, we learn what God the Father is like. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### He is the firstborn

"The Son is the firstborn." The expression "firstborn Son" does not refer to Jesus' birth in Bethlehem. Instead, it refers to the Son's position as the eternal Son of God the Father. In this sense, "firstborn" is a metaphor meaning "most important." Jesus is the most important and the unique "Son" of God. He is God. The word "Son" shows Jesus' intimate relationship with the Father. That relationship cannot be understood until and unless you use your language's words for "son" and "father." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For by him all things were created

This can be stated in active form. AT: "For by him God created all things" or "God caused the Son to create all things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### all things were created by him and for him

This can be stated in active form. God caused the Son to create all things for the Son's glory. AT: "For by him and for him God created all things" or "God caused him to create all things for himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He himself is before all things

"It is he who existed before all things"

#### in him all things hold together

Paul is speaking here of the Son controlling all things as if he were physically holding them together. "he holds everything together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dominion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Colossians 01:18

#### He is the head

"Jesus Christ, the Son of God, is the head"

#### He is the head of the body, the church

Paul speaks of Jesus' position over the church as if he were the head on the human body. As the head rules the body, so does Jesus rule the church. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the beginning

"the originating authority." He is the first chief or founder.

#### firstborn from among the dead

Jesus is the first person to die and come back to life, never to die again.

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### through the blood of his cross

"by means of the blood Jesus shed on the cross"

#### the blood of his cross

Here "blood" stands for the death of Christ on the cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Colossians 01:21

#### Connecting Statement:

Paul makes it clear that God has now revealed that Christ exchanges the sin of Gentile believers for his holiness.

#### At one time, you also

"There was a time when you Colossian believers also"

#### were strangers to God

"were like people whom God did not know" or "had pushed God away"

#### to present you holy, blameless, and above reproach before him

Paul is describing the Colossians as though Jesus had physically cleaned them, put them in clean clothes, and brought them to stand before God the Father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### blameless, and above reproach

Paul uses two words that mean almost the same thing to emphasize the idea of perfection. AT: "perfect" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### before him

This expression of location stands for "in God's view" or "in God's mind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that was proclaimed

that believers proclaimed (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to every person created under heaven

"to every person in the world"

#### the gospel of which I, Paul, became a servant

Paul was actually a servant of God. AT: "the gospel that I, Paul, serve God by proclaiming" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reconcile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Colossians 01:24

#### I fill up in my flesh what is lacking of the afflictions of Christ

Paul speaks about the suffering that he continues to experience. He may be acknowledging here that there is much suffering that he and all other Christians must endure before Christ comes again, and that Christ in a spiritual sense joins with them in experiencing these hardships. Paul certainly does not mean that Christ's sufferings alone were not enough to provide salvation for the believers.

#### I fill up in my flesh

Paul speaks of his body as if it were a container that could hold suffering. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for the sake of his body, which is the church

Paul often speaks of the church, the group of all Christian believers, as if it were Christ's body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to fulfill the word of God

This means to bring about the purpose of God's gospel message, which is that it be preached and believed. "Word of God" here is a metonym for the message from God. AT: "to be obedient to what God has instructed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### This is the secret truth that was hidden

This can be stated in active form. AT: "This is the secret truth that God had hidden" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for ages and for generations

The words "ages" and "generations" refer to the time period from the creation of the world until the time when the gospel was preached.

#### now it has been revealed

This can be stated in active form. AT: "now God has revealed it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the riches of the glory of this secret truth

Paul speaks of the value of this secret truth about God as if it were a treasure of material wealth. "riches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Christ in you

Paul speaks of the believers as if they were actual containers in which Christ is present. This is one of his ways of expressing the union of the believers with Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the hope of glory

"so you can confidently expect to share in God's glory"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]

### Colossians 01:28

#### we proclaim ... We admonish ... we teach ... we may present

These words do not include the Colossians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### We admonish every person

"We warn everyone"

#### so that we may present every person

You may need to make explicit to whom they will present every person. AT: "so that we may present to God every person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### complete

Being complete is a metaphor for being spiritually mature. AT: "spiritually mature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Colossians 01:intro

#### Colossians 01 General Notes ####

####### Structure and formatting #######

As in a typical letter, this chapter begins (1:1-3) with a formal introduction to the Christians in Colossae. 

A large part of this chapter revolves around two basic ideas: who Christ is, and what Christ has accomplished for the Christian.

####### Special concepts in this chapter #######

######## Mystery ########

Paul refers to the church as a "mystery." The role of the church in the plans of God was once unknown, but has now been revealed by God. Part of this mystery involves the Gentiles' equal standing with the Jews in the current plans of God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

####### Important figures of speech in this chapter #######

######## Images for christian living ########
There are many different images used to describe christian living. In this chapter, two popular images are used by Paul. These are "walking" and "bearing fruit." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]])

####### Other possible translation difficulties in this chapter #######

######## The use of paradox ########

A paradox is a seemingly absurd statement, which appears to contradict itself, but it is not absurd. A paradox occurs in 1:24: "Now I rejoice in my sufferings for you." Most people do not think that they will rejoice in suffering. But in 1:25-29 Paul explains why his suffering is good. ([Colossians 1:24](./24.md))

##### Links: #####

* __[Colossians 01:01 Notes](./01.md)__
* __[Colossians intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Colossians 02

### Colossians 02:01

#### Connecting Statement:

Paul continues to encourage the believers in Colossae and Laodicea to understand that Christ is God and that he lives in believers, so they should live in the same way they received him.

#### how great a struggle I have had for you

Paul has exerted much effort in developing their purity and understanding of the gospel.

#### those at Laodicea

This was a city very close to Colossae where there was also a church for which Paul was praying.

#### as many as have not seen my face in the flesh

Here "face in the flesh" stands for the person. AT: "all those who have never seen me personally" or "all those whom I have never met face to face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### so that their hearts

Paul includes the Galatians even though he uses a different pronoun. AT: "so that their hearts and yours" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### brought together

This means brought together in a close relationship.

#### all the riches of full assurance of understanding

Paul speaks of a person who is completely sure that the good news is true as though that person were rich in physical things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the secret truth of God

This is knowledge that can be revealed only by God.

#### that is, Christ

Jesus Christ is the secret truth revealed by God.

#### In him all the treasures of wisdom and knowledge are hidden

Only Christ can reveal God's true wisdom and knowledge. This can be stated in active form. AT: "God has hidden all the treasures of wisdom and knowledge in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the treasures of wisdom and knowledge

Paul speaks of God's wisdom and knowledge as if they were material wealth. AT: "the very precious wisdom and knowledge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### wisdom and knowledge

These words mean basically the same thing here. Paul uses them together to emphasize that all spiritual understanding comes from Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Colossians 02:04

#### trick

This means to cause someone to believe something that is not true, so he acts on that belief, and suffers harm as a result.

#### persuasive speech

speech that will make a person think differently

#### not with you in the flesh

The person's flesh, or physical body, is a metonym for the person. AT: "not physically present with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I am with you in spirit

Being with someone in spirit is a metaphor for thinking continually about that person. AT: "I continually think about you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### good order

doing things properly

#### the strength of your faith

"how nothing and no one can cause you to stop believing"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Colossians 02:06

#### Be firmly planted ... be built ... be established ... abound

These words explain what it means to "walk in him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Be firmly planted in him

Paul speaks of a person with true faith in Christ as if that person were a tree growing in solid ground with deep roots. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### be built on him

Paul speaks of a person with true faith in Christ as if that person were a building that has a strong foundation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### be established in faith

"trust in Jesus for everything"

#### just as you were taught

This is best stated without naming or otherwise calling attention to the teacher, who was Epaphras ([Colossians 1:7](../01/07.md)). AT: "just as you learned" or "just as they taught you" or "just as he taught you"

#### abound in thanksgiving

Paul speaks of thanksgiving as if it were objects that a person could obtain more of. AT: "be very thankful to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]

### Colossians 02:08

#### Connecting Statement:

Paul urges the believers to be careful not to turn to the words and rules of others because nothing can add to the fullness of God that believers have in Christ.

#### See that

"Make sure that"

#### captures you

Paul speaks of the way a person can believe false teachings (because they believe false things or love the wrong things) as if someone had physically caught and held that person by force. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### philosophy

religious doctrines and beliefs that are not from God's word but are based on man's thoughts about God and life

#### empty deceit

Paul speaks of false ideas that produce nothing and so are without value as though they are containers with nothing in them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the tradition of men ... the elements of the world

Both Jewish traditions and pagan (Gentile) belief systems are worthless. "The elements of the world" perhaps refers to evil spirits that claimed to rule the world and that were adored by people. But some interpreters view "the elements of the world" as people's basic teachings about the world.

####  in him all the fullness of God lives in bodily form

"God's total nature lives in physical form in Christ"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tradition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Colossians 02:10

#### You have been filled in him

Paul speaks of people as though they were containers into which God has placed Christ. AT: "You are made complete in Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who is the head over every power and authority

Christ is the ruler over every other ruler (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### In him you were also circumcised

Paul is speaking of those who belong to Christ as if they were inside Christ's body. This can also be made active. AT: "When you joined the church in baptism, God circumcised you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a circumcision not done by humans

With this metaphor, Paul says that God has made Christian believers acceptable to himself in a way that reminded him of circumcision, the ceremony through which Hebrew male babies were added to the community of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You were buried with him in baptism

Paul speaks of being baptized and joining the assembly of believers as if it were being buried with Christ. This can be made active. AT: "God buried you with Christ when you joined the church in baptism" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in him you were raised up

"Raised" here is an idiom for "caused to live again." With this metaphor, Paul speaks of the new spiritual life of believers, made possible because God made Christ come alive again. This can be made active. AT: "because you have joined yourself to Christ, God raised you up" or "in him God caused you to live again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Colossians 02:13

#### When you were dead

Paul speaks of unresponsiveness to God as if it were death. AT: "When you Colossian believers were unable to respond to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you were dead ... he made you alive

With this metaphor Paul speaks of coming into new spiritual life as if it were coming back to life physically. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### dead in your trespasses and in the uncircumcision of your flesh

You were dead on two accounts: 1) you were spiritually dead, living a life of sin against Christ and 2) you were not circumcised according to the law of Moses.

#### forgave us all of our trespasses

"he forgave us, both us Jews and you Gentiles, of all our trespasses"

#### He canceled the written record of debts that stood against us

Paul speaks of the way God forgives our sins as if it were the way a person, to whom many people owe money or goods, destroys the record of that debt so they do not have to pay him back. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### made a public spectacle of them

In Roman times, it was common practice for the Roman armies to have a victory parade when they returned home, displaying all the prisoners they had captured and goods they had obtained. God was victorious over the evil powers and authorities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by the cross

Here "the cross" stands for Christ's death on the cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Colossians 02:16

#### in eating or in drinking

The law of Moses included what one can eat and drink. "for what you eat or what you drink"

#### about a feast day or a new moon, or about Sabbath days

The law of Moses specified the days to celebrate, to worship, and to offer sacrifice. "for the way you celebrate feast days or new moons or the Sabbath"

#### a shadow of the things to come

A shadow gives only a vague idea of the shape and nature of an object. In a similar way, religious traditions such as the law of Moses can only partially show the reality of Jesus Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the substance

Here this means "the reality," the thing that casts the "shadow."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Colossians 02:18

#### Let no one ... judge you out of your prize

Here Paul refers to false teachers as if they were corrupt judges at an athletic contest who would unjustly disqualify the believers from winning the prizes they deserve, and he speaks of Christ saving a person as if Christ were giving a prize to the winner of such a contest. AT: "Let no one ... disqualify you from winning a prize" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who wants humility

The word "humility" is a metonym for actions one does to make others think that one is humble. AT: "who wants you to do things to show that you are humble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### enters into the things he has seen

Here Paul speaks about people who claim to have dreams and visions from God and who talk proudly about them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### becomes puffed up by his fleshly thinking

Here Paul says that sinful ways of thinking make a person arrogant. AT: "puffs himself up by means of his fleshly thinking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### puffed up

Here a person who boasts is spoken of as if he were an object into which someone had blown air to make it larger than it should be. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his fleshly thinking

Here the idea of flesh stands for the sinful human nature. "the sinful thoughts he naturally thinks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He does not hold on to the head

A person not trusting in Christ is spoken of has if they do not hold firmly to the head. Christ is spoken of as if he were the head of a body. AT: "He does not firmly grasp Christ, who is like the head of a body" or "He does not cling to Christ, who is like the head of a body" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It is from the head that the whole body throughout its joints and ligaments is supplied and held together

Paul speaks of the church, which is ruled and empowered by Christ, as if it were a human body. AT: "It is from the head that God supplies the whole body throughout its joints and ligaments and holds it together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]

### Colossians 02:20

#### If you died together with Christ to the elements of the world

With this metaphor, Paul speaks of a believer as a person who is spiritually united with Christ: as Christ died, so the believer has spiritually died; as Christ has come back to life, so the believer has come back to spiritual life, that is, to responsiveness to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### why do you live as obligated to the world: "Do ... touch"?

Paul used this question to rebuke the Colossians for following the false beliefs of the world. AT: "stop submitting to the world's beliefs! Stop believing them when they say, 'Do ... touch'!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### live as obligated to the world

"think you must obey the desires of the world"

#### the world

the thoughts, desires, and assumptions of the sinful majority of the world's people (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### These rules have the wisdom of self-made religion and humility and severity of the body

"These rules seem wise to unbelieving people because they allow those who follow them to appear humble because they hurt their own bodies"

#### have no value against the indulgence of the flesh

"do not help you stop following your human desires"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Colossians 02:intro

#### Colossians 02 General Notes ####

####### Special concepts in this chapter #######

######## Worldliness ########
Although believers must live in the world, Paul urges the Christians in Colossae not to live "worldly" lives. By this he means not to live as the non-Christians do.

####### Other possible translation difficulties in this chapter #######

######## Flesh ########

This is a complex issue and it is possible "flesh" is a metaphor for a person's sinful nature. It is not the physical part of man that is sinful. Paul is teaching that, while man remains alive ("in the flesh"), he will remain sinful regardless of his effort, but his new nature will be fighting against his old nature. Flesh is also used in this chapter to refer to the material part of man in general. 

######## Implicit Information ########
There are several issues mentioned in this chapter that share implicit information about the context of the church in Colossae. It is best to allow uncertainty to remain in the text over the specifics of the situations referenced. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Colossians 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Colossians 03

### Colossians 03:01

#### Connecting Statement:

Paul warns the believers that because they are one with Christ, they ought not do certain things.

#### God has raised you with Christ

As God has raised Christ to heaven, so God counts the believers in Colossae as though he has also raised them to heaven. "Raised" here is an idiom for "established." AT: "God has established you with Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### things above

"things in heaven"

#### where Christ is sitting at the right hand of God.
To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "where Christ is sitting in the place of honor and authority beside God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### For you have died

As Christ actually died, so God counts the Colossian believers as having died with Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### your life is hidden with Christ in God

Paul speaks of people's lives as if they were objects that can be hidden in containers and speaks of God as if he were a container. AT: Possible meanings are 1) "it is as though God has taken your life and concealed it with Christ in God's presence" or 2) "only God knows what your true life really is, and he will reveal it when he reveals Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who is your life

Christ is the one who gives spiritual life to the believer. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Colossians 03:05

#### Put to death, then, the members that are on earth

Paul speaks of sinful desires as though they were the body parts people use to satisfy them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### uncleanness

"impure behavior"

#### passion

"strong, lustful desire"

#### greed, which is idolatry

"greed, which is the same thing as idolatry" or "do not be greedy because that is the same as worshiping idols"

#### wrath of God

God's anger against those who do evil as shown by what he does to punish them.

#### the sons of disobedience

This is an idiom that means they were characterized by disobedience. The abstract noun "disobedience" can be stated as a verb. AT: "disobedient people" or "people who disobey him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### It is in these things that you also once walked

Paul speaks of the way a person behaves as if it were a road or path a person walks on. AT: "These are the things you used to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### when you lived in them

Possible meanings are 1) "when you practiced these things" or 2) "when you lived among the people who disobey God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### evil intentions

"desire to do wicked deeds"

#### insults

speech used to hurt others

#### obscene speech

words that do not belong in polite conversation

#### from your mouth

Here "mouth" is a metonym for talk. "in your talk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]

### Colossians 03:09

#### Connecting Statement:

Paul continues to tell the believers how to live and reminds them that Christians should treat everyone according to the same standard.

#### you have taken off the old man with its practices, and you have put on the new man

Here Paul is speaking of a Christian's rejecting his old sinful life as if it were an old garment that he takes off in order to put on a new garment. It was very common for Israelites such as Paul to speak of moral qualities as if they were pieces of clothing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the image

This refers to Jesus Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### there is no Greek and Jew, circumcision and uncircumcision, barbarian, Scythian, slave, freeman

These terms are examples of the categories of people that Paul says do not matter for God. God sees every person alike, not by race, religion, nationality, or social status. AT: "race, religion, culture, and social status do not matter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### barbarian

a foreigner who does not know local customs

#### Scythian

This is someone from the land of Scythia, which was outside the Roman Empire. Greeks and Romans used this word for someone who grew up in a place where everyone did wicked things all the time.

#### Christ is all, and is in all

Nothing is excluded or left out of the rule of Christ. AT: "Christ is all important and lives in all his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/imageofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Colossians 03:12

#### as God's chosen ones, holy and beloved

This can be made active. AT: "as those whom God has chosen for himself, whom he desires to see live for him alone, and whom he loves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### put on a heart of mercy, kindness, humility, gentleness, and patience

The "heart" is a metaphor for feelings and attitudes. Here it is spoken of as if it has certain feelings and attitudes, and as if it were clothing to wear. AT: "have a merciful, kind, humble, gentle, and patient heart" or "be merciful, kind, humble, gentle, and patient" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Bear with one another

"Be patient with one another" or "Accept each other even when you disappoint each other"

#### Be gracious to each other

"Treat each other better than they deserve for you to treat them"

#### has a complaint against

The abstract noun "complaint" can be stated as "complain." AT: "has a reason to complain against" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### have love, which is the bond of perfection

Here "bond of perfection" is a metaphor for something that causes perfect unity among people. AT: "love one another because it will unite you perfectly together. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Colossians 03:15

#### Let the peace of Christ rule in your hearts

Paul speaks of the peace that Christ gives as if it were a ruler. Possible meanings are 1) "Do everything so that you can have peaceful relationships with each other" or 2) "Allow God to give you peace in your heart" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in your hearts

It was normal for Paul to speak of the heart as if it were the place where people feel most intensely certain conditions such as peacefulness. You should use the most natural expression in your language for feeling at peace. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let the word of Christ live in you

Paul speaks of Christ's word as if it were a person capable of living inside other people. "Word of Christ" here is a metonym for the teachings of Christ. AT: "Be obedient to the instructions of Christ" or "Always trust Christ's promises" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### admonish one another

"caution and encourage one another"

#### with psalms and hymns and spiritual songs

"with all sorts of songs to praise God"

#### thankfulness in your hearts

"thankful hearts"

#### in word or in deed

speaking or acting

#### in the name of the Lord Jesus

"Name" here is a metonym for the person of Jesus Christ. AT: "by means of the Lord Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]]) "to honor the Lord Jesus" or "with the authority of the Lord Jesus"

#### through him

Possible meanings are 1) because he has done great deeds or 2) because he has made it possible for people to speak to God and so give him thanks. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/psalm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/psalm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Colossians 03:18

#### Connecting Statement:

Paul then gives some special instructions to wives, husbands, children, fathers, slaves, and masters.

#### Wives, submit to

"Wives, obey"

#### it is appropriate

"it is proper" or "it is right"

#### do not be bitter against

"do not be harsh with" or "do not be angry toward"

#### do not provoke your children

"do not needlessly make your children angry"

### Colossians 03:22

#### obey your masters according to the flesh

"obey your human masters"

#### things, not with eyeservice as people pleasers

"things. Do not obey only when your master is watching, as though you need only to please people"

#### with a sincere heart

"Heart" here is a metonym for one's entire intentions. AT: "with all honest intentions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### as to the Lord

"as you would work for the Lord"

#### the reward of the inheritance

"the inheritance as your reward"

#### inheritance

Receiving what God has promised believers is spoken of as if it were inheriting property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### anyone who does unrighteousness will receive the penalty

The phrase "receive the penalty" means to be punished. AT: "anyone who does unrighteousness will be punished" or "God will punish anyone who does what is unrighteous"

#### who does unrighteousness

who actively does wrong of any kind

#### there is no partiality

The abstract noun "partiality" can be expressed with the adjective "partial." To be partial is to favor some people more than others. AT: "God is not partial" or "God judges everyone by the same standard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Colossians 03:intro

#### Colossians 03 General Notes ####

####### Structure and formatting #######

The second part of this chapter parallels Ephesians 5 and 6. 

####### Special concepts in this chapter #######

######## Old and new self ########
The old and new self are concepts equivalent to the old/new man. The term "old man" probably refers to the sinful nature a person is born with, while the "new man" is the new nature or new life that is given to a person after they come to faith in Christ. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## Character ########
Many of the qualities Paul encourages his readers to pursue (or avoid) are not actions themselves as much as they are character qualities. Because of this, they may present difficulties in translation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

####### Other possible translation difficulties in this chapter #######

######## "That which is above" ########

God is often pictured as being located above. When Paul says here to seek the things above or to think about what is above, he is implying Christians should seek to please God with their actions. 

##### Links: #####

* __[Colossians 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Colossians 04

### Colossians 04:01

#### Connecting Statement:

After speaking to masters, Paul ends his special instructions to the different kinds of believers in the church at Colossae.

#### right and fair

These words mean almost the same thing and are used to emphasize the things that are morally correct. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### you also have a master in heaven

God wants the relationship between an earthly master and his slave to be loving the way God, the heavenly master, loves his earthly servants, including the earthly slaves' masters.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Colossians 04:02

#### Connecting Statement:

Paul continues to give instructions to believers on how to live and speak.

#### General Information:

Here the word "us" refers to Paul and Timothy but not the Colossians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### Continue steadfastly in prayer

"Keep praying faithfully" or "Keep praying consistently"

#### God would open a door

Opening a door for someone is a metaphor for giving that person the opportunity to do something. AT: "God would provide opportunities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### open a door for the word

"Word" here is a metonym for "message." AT: "make an opportunity for us tp preach his message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the secret truth of Christ

This refers to the gospel of Jesus Christ, which was not understood before Christ came.

#### Because of this, I am chained up

Here "chained" is a metonym for being in prison. AT: "It is for proclaiming the message of Jesus Christ that I am now in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Pray that I may make it clear

"Pray that I might be able to speak the message of Jesus Christ clearly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Colossians 04:05

#### Walk in wisdom toward those outside

The idea of walking is often used for the idea of conducting one's life. AT: "Live in such a way that those who are not believers will see that you are wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### redeem the time

To "redeem" something means to restore it to it's rightful owner. Here time is spoken of as something that can be restored and used to serve God. AT: "do the best things you can with your time" or "put the time to its best use" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let your words always be with grace. Let them be seasoned with salt

Food with salt is a metaphor for words that teach others and that others enjoy hearing. AT: "Let your conversation always be gracious and attractive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so that you may know how you should answer

"so that you may know how to answer questions from anyone about Jesus Christ" or "so that you may be able to treat every person well"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Colossians 04:07

#### Connecting Statement:

Paul closes with special instructions about certain people as well as greetings to and from individual believers.

#### General Information:

Onesimus was a slave of Philemon in Colossae. He had stolen money from Philemon and run away to Rome where he became a Christian through the ministry of Paul. Now Tychicus and Onesimus are the ones bringing Paul's letter to Colossae.

#### the things concerning me

"everything that has been happening to me"

#### fellow slave

"fellow servant." Though Paul is a free man, he sees himself as a servant of Christ and sees Tychicus as a fellow servant.

#### about us

These words do not include the Colossians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### may encourage your hearts

The heart was thought to be the center of many emotions. AT: "may encourage you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the faithful and beloved brother

Paul calls Onesimus a fellow Christian and servant of Christ.

#### They will tell

"Tychicus and Onesimus will tell"

#### everything that has happened here

They will tell the Colossian believers all that is taking place where Paul is currently living. Tradition says Paul was in Rome under house arrest or in prison at this time.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tychicus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tychicus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Colossians 04:10

#### Aristarchus

He was in prison with Paul in Ephesus when Paul wrote this letter to the Colossians.

#### if he comes

"if Mark comes"

#### Jesus who is called Justus

This is a man who also worked with Paul.

#### These alone of the circumcision are my fellow workers for the kingdom of God

Paul uses "circumcision" here to refer to Jews because, under the Old Testament law, all male Jews had to be circumcised. AT: "These three men are the only Jewish believers working with me to proclaim God as king through Christ Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### These alone of the circumcision

"These men—Aristarchus, Mark, and Justus—alone of the circumcision"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnmark.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnmark.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barnabas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]

### Colossians 04:12

#### General Information:

Laodicea and Hierapolis were towns close to Colossae.

#### Epaphras

Epaphras was the man who had preached the good news to the people in Colossae. (See: [Colossians 1:7](../01/07.md))

#### one of you

"from your city" or "your fellow townsman"

#### a slave of Christ Jesus

"a committed disciple of Christ Jesus"

#### always strives for you in prayer

"earnestly prays for you"

#### you may stand complete and fully assured

"you may stand mature and confident"

#### I bear witness of him, that he works hard for you

"I have observed that he has worked very hard for you"

#### Demas

This is another co-worker with Paul.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/luke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/luke.md)]]

### Colossians 04:15

#### brothers

Here this means fellow Christians, including both men and women.

#### in Laodicea

a city very close to Colossae where there was also a church

#### Nympha, and the church that is in her house

A woman named Nympha hosted a house church. AT: "Nympha and the group of believers that meets in her house"

#### Say to Archippus, "Look to the ministry that you have received in the Lord, that you should fulfill it

Paul reminds Archippus of the task God had given him and that he, Archippus, was under obligation to the Lord to fulfill it. The words "Look," "you have received," and "you should fulfill" all refer to Archippus and should be singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Colossians 04:18

#### Connecting Statement:

Paul closes his letter with a greeting written in his own handwriting.

#### Remember my chains

Paul speaks of chains when he means his imprisonment. AT: "Remember me and pray for me while I am in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### May grace be with you

Here "grace" stands for God, who shows grace or acts kindly to believers. AT: "I pray that our Lord Jesus Christ would continue to act graciously toward you all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Colossians 04:intro

#### Colossians 04 General Notes ####

####### Structure and formatting #######

It appears [Colossians 4:1](./01.md) belongs with the material of chapter 3 instead of chapter 4. 

####### Special concepts in this chapter #######

######## "In my own hand" ########
It was common in the ancient Near East to have someone physically write a letter while the author spoke. This is a common practice with the letters of the New Testament. Paul thought that this chapter was so important, he physically wrote it himself. 

####### Other possible translation difficulties in this chapter #######

######## Mystery ########

Paul refers to the church as a "mystery." The role of the church in the plans of God was once unknown, but has now been revealed by God. Part of this mystery involves the Gentiles' equal standing with the Jews in the current plans of God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

##### Links: #####

* __[Colossians 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | __


## Colossians front

### Colossians front:intro

#### Introduction to Colossians ####

##### Part 1: General Introduction #####

####### Outline of the Book of Colossians #######

1. Greeting, thanksgiving, and prayer (1:1-12)
1. The person and work of Christ 
    - Deliverance and redemption (1:13-14)
    - Christ: the Image of the invisible God, and the One who is over all creation (1:15-17)
    - Christ is the Head of the Church, and the Church trusts in him (1:18-2:7)
1. Tests of faithfulness
    - Warnings against false teachers (2:8-19)
    - True godliness is not rigid rules and unbending traditions (2:20-23)
1. Teaching and living
    - Life in Christ (3:1-4)
    - Old and new life (3:5-17)
    - Christian family (3:18-4:1)
1. Christian behavior (4:2-6)
1. Closing and greetings
    - Paul thanks Tychicus and Onesimus (4:7-9)
    - Paul sends greetings from his associates (4:10-14)
    - Paul gives directions to Archippus and the Christians in Laodicea (4:15-17)
    - Paul's personal greeting (4:18)

####### Who wrote the Book of Colossians? #######

Paul wrote the Book of Colossians. Paul was from the city of Tarsus. He had been known as Saul in his early life. Before becoming a Christian, Paul was a Pharisee. He persecuted Christians. After he became a Christian, he traveled several times throughout the Roman Empire telling people about Jesus.

Paul wrote this letter while in prison in Rome.

####### What is the Book of Colossians about? #######

Paul wrote this letter to the believers in the Asia Minor city of Colossae. The main purpose of this letter was to defend the gospel against false teachers. He did this by praising Jesus as the image of God, sustainer of all things, and head of the church. Paul wanted them to understand that only Christ is needed for God to accept them.

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Colossians." Or they may choose a clearer title, such as "Paul's Letter to the Church in Colossae," or "A Letter to the Christians in Colossae." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### What were the religious issues that the church in Colossae struggled with? #######

In the church in Colossae, there were false teachers. Their exact teaching is unknown. But they probably taught their followers to worship angels and to obey strict rules about religious ceremonies. They probably also taught that a person must be circumcised and can only eat certain types of food. Paul said these false teachings came from the minds of men and not from God.
 
####### How did Paul use the imagery of heaven and earth? #######

In this letter, Paul frequently spoke of heaven as "above." He distinguished it from the earth, which Scripture speaks of as being "below." The purpose of this imagery was to teach Christians to live in a way that honors God who lives in heaven above. Paul is not teaching that the earth or the physical world is evil. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

##### Part 3: Important Translation Issues #####

####### How are the ideas of "holy" and "sanctify" represented in Colossians in the ULB? #######

The scriptures use such words to indicate any one of various ideas. For this reason, it is often difficult for translators to represent them well in their versions. In Colossians, these words usually indicate a simple reference to Christians without implying any particular role filled by them. So Colossians in the ULB uses "believers" or "those who believe in him." (See: 1:2, 12, 26)

####### Was Jesus created or is he eternal? #######

Jesus was not a created being but has always existed as God. Jesus also became a human being. There is potential for confusion in Colossians 1:15 where it says Jesus "is the firstborn of all creation." This statement means that Jesus is dominant over all of creation. It does not mean that he was the first thing God created. Translators should be careful not to imply that Jesus is a created being.

####### What does Paul mean by the expression "in Christ," "in the Lord," etc.? #######

Paul meant to express the idea of a very close union with Christ and the believers. See the introduction to the book of Romans for more details about this kind of expression.

####### What are the major issues in the text of the Book of Colossians? #######

The following are the most significant textual issues in the Book of Colossians:

* "May grace be to you, and peace from God our Father" (1:2). The ULB, UDB, and many other modern versions read this way. Some older versions have a longer reading: "Grace to you and peace from God our Father and the Lord Jesus Christ."
* "Epaphras, our beloved fellow servant, who is a faithful servant of Christ on our behalf" (1:7). Many versions, including the ULB and UDB, read this way. However, other versions read "for you": "Epaphras, our beloved fellow servant, a faithful servant of Christ for you." If other versions exist in the general region, translators should consider using the reading found in those versions.
* "the Father, who has made you able to have a share in the inheritance of the believers in light" (1:12). The ULB and UDB read this way. However, some other versions read, "the Father, who has qualified us for a share in the inheritance in light." If other versions exist in the general region, translators should consider using the reading found in those versions. 
* "In his Son we have redemption." (1:14) The ULB, UDB, and many other modern versions read this way. Some older versions read, "In his Son we have redemption through his blood." 
* "and forgave us all of our trespasses" (2:13). The ULB, UDB, and many other modern versions have this reading. Some older versions read: "and forgave you all of your trespasses." 
* "When Christ appears, who is your life" (3:4). The ULB, UDB, and many other modern versions read this way. Some older versions read, "When Christ appears, who is our life." 
* "It is for these things that the wrath of God is coming on the sons of disobedience." (3:6) The ULB, UDB, and many other modern versions read this way. However, other modern versions read, "It is for these things that the wrath of God is coming." If other versions exist in the general region, translators should consider using the reading found in those versions. 
* "I sent him to you for this, that you might know the matters about us." (4:8) The ULB, UDB, and most other modern versions read this way. Some older versions read, "I sent him to you for this, that he might know the matters about you."

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

