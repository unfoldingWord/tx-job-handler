# <a id="ecc"/>Ecclesiastes

## Ecclesiastes 01

### Ecclesiastes 01:01

#### Like a vapor of mist, like a breeze in the wind, everything vanishes

This speaks of how everything in life vanishes and has no lasting value as if everything were like a disappearing vapor or breeze. AT: "Like a vapor of mist vanishes and like a breeze in the wind disappears, everything vanishes and has no lasting value" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### What profit does mankind gain ... under the sun?

The author uses this rhetorical question to emphasize that man's work is pointless and has no lasting benefit. This question can be written as a statement. AT: "Mankind gains no profit ... under the sun." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### under the sun

This refers to things that are done on earth. AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Ecclesiastes 01:04

#### General Information:

The writer is presenting the natural order of life as he understands it.

#### hurries back to the place

This speaks of how the sun sets at the end of the day and is soon ready to rise again, as if it were a person that quickly ran from the place where it sets to the place from which it rises. AT: "quickly returns to the place" or "quickly goes to the place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Ecclesiastes 01:07

#### General Information:

The writer continues with observations about the natural order.

#### Everything becomes wearisome

"Everything becomes tiring." Since man is unable to explain these things, it becomes useless to try.

#### The eye is not satisfied by what it sees

Here the "eye" represents the whole person. AT: "A person is not satisfied by what his eyes see" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### nor is the ear fulfilled by what it hears

Here the "ear" represents the whole person. AT: "nor is a person content by what his ears hear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

### Ecclesiastes 01:09

#### General Information:

There is nothing new regarding man and his activities.

#### whatever has been done is what will be done

This can be stated in active form. AT: "whatever has happened before is what will happen again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](./01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Is there anything about which it may be said, 'Look, this is new'?

This rhetorical question is asked to emphasize that man cannot say there is anything new. This can be written as a statement. AT: "There is nothing about which it may be said, 'Look, this is new.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### about which it may be said

This can be stated in active form. AT: "about which someone may say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that will happen in the future

The understood subject may be supplied. AT: "the things that will happen in the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### will not likely be remembered either

This can be stated in active form. AT: "people will not likely remember them either" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md)]]

### Ecclesiastes 01:12

#### I applied my mind

Here the author refers to himself by his "mind" to emphasize his thoughts. AT: "I determined" or "I applied myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### to study and to search out

These two phrases mean the same thing and emphasize how diligently he studied. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### under heaven

This refers to things that are done on earth. AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### children of mankind

"human beings"

#### all the deeds that are done

This can be stated in active form. AT: "everything that people do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](./01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### look

The author uses this word to draw attention to what he says next. AT: "indeed" or "really" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### amount to vapor ... an attempt to shepherd the wind

These two phrases are both metaphors that emphasize the idea of things being useless and futile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### amount to vapor

"are only mist." The author speaks of useless and meaningless things as if they were "vapor." Just as vapor disappears and does not last, things have no lasting value. AT: "are as useless as vapor" or "are meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an attempt to shepherd the wind

The author says that everything that people do is as useless as if they were trying to control the wind. AT: "are as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The twisted cannot be straightened! The missing cannot be counted

This can be stated in active form. AT: "People cannot straighten things that are twisted! They cannot count what is not there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Ecclesiastes 01:16

#### I have spoken to my heart

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I have spoken to myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### My mind has seen

Here the author refers to himself by his "mind" to emphasize what he has learned. AT: "I have gained" or "I have learned"

#### I applied my heart

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I determined" or "I applied myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### madness and folly

The words "madness" and "folly" share similar meanings and refer to foolish thinking and behavior, respectively. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### an attempt to shepherd the wind

The author says learning wisdom and madness and folly is as useless as trying to control the wind. See how you translated this in [Ecclesiastes 1:14](./12.md). AT: "as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Ecclesiastes 01:intro

#### Ecclesiastes 01 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 1:2-11 and 15.

####### Other possible translation difficulties in this chapter #######

######## Tone ########
The tone of this chapter is sad, or depressing. The author believes that everything in life is pointless. The metaphors in this chapter all describe the idea that nothing ever changes. This is also known as "fatalism." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Ecclesiastes 01:01 Notes](./01.md)__
* __[Ecclesiastes intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Ecclesiastes 02

### Ecclesiastes 02:01

#### I said in my heart

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I said to myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### I will test you with happiness

Here the word "you" refers to himself. The word "happiness" can be expressed as an adjective. AT: "I will test myself with things that make me happy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### So enjoy pleasure

The word "pleasure" can be expressed as a verb. AT: "So I will enjoy things that please me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### this also was just a temporary breeze

This speaks of how happiness only lasts for a short time as if it were a temporary breeze. AT: "this also only lasted for a short time, like a temporary breeze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I said about laughter, "It is crazy,"

The direct quotation can be translated as an indirect quotation. AT: "I said that it is crazy to laugh at things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### What use is it?

The author uses a rhetorical question to emphasize that pleasure is useless. AT: "It is useless." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]

### Ecclesiastes 02:03

#### I explored in my heart

This speaks of thinking hard for a long time as if it were exploring. Also, the author speaks of his feelings and his thoughts as if they were his "heart." AT: "I thought hard about" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to gratify my desires with wine

The word "desires" may be expressed as a verbal phrase. AT: "to use wine to make myself happy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### I let my mind guide me with wisdom

Here the author speaks of using the wisdom that he had been taught to guide himself as if this wisdom were a person who guided him. AT: "I thought about the things that wise people had taught me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### under heaven

This refers to things that are done on earth. AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### during the days of their lives

"during the time that they are alive"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Ecclesiastes 02:04

#### I built houses for myself and planted vineyards. I built for myself gardens and parks. I planted ... I created

The writer probably told people to do the work. AT: "I had people build houses and plant vineyards for me. I had them build gardens and parks for me ... I had them plant ... I had them create" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### gardens and parks

These two words share similar meanings and refer to beautiful orchards of fruit trees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### to water a forest

"to provide water for a forest"

#### forest where trees were grown

This can be stated in active form. AT: "forest where trees grew" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]

### Ecclesiastes 02:07

#### I had slaves born in my palace

"I had slaves that were born in my palace" or "My slaves bore children and they also were my slaves"

#### much more than any king

The understood verb may be supplied. AT: "much more than any other king had" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the treasures of kings and provinces

This refers to the gold and other wealth that neighboring countries were forced to pay to the king of Israel. AT: "that I acquired from the treasures of kings and the rulers of provinces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### provinces

Here "provinces" represents the rulers of the provinces. AT: "the rulers of provinces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the delights of the children of humanity—and many concubines

This means that he had many concubines that he enjoyed sleeping with, as any man enjoys sleeping with women. AT: "I greatly enjoyed many concubines, as would delight any man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]

### Ecclesiastes 02:09

#### than all who were before me in Jerusalem

This refers to all the previous rulers of Jerusalem. AT: "than all the kings who had ruled before me in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### my wisdom remained with me

This is an idiom. "I continued to act wisely" or "I continued to be wise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Whatever my eyes desired ... from them

Here the author refers to himself by his "eyes" to emphasize what he sees. AT: "Whatever I saw and desired ... from myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### I did not withhold from them

This can be stated positively. AT: "I got for them"

#### I did not withhold my heart from any pleasure

Here the author refers to himself by his "heart" to emphasize his desires. This can be stated positively and the word "pleasure" can be expressed as a verb. AT: "I did not keep myself from any pleasure" or "I allowed myself to enjoy everything that made me happy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### my heart rejoiced

Here the author refers to himself by his "heart" to emphasize his desires. AT: "I rejoiced" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]

### Ecclesiastes 02:11

#### all the deeds that my hands had accomplished

Here the author refers to himself by his "hands." AT: "all that I had accomplished" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### vapor ... an attempt to shepherd the wind

These two phrases are both metaphors that emphasize the idea of things being useless and futile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### vapor

"mist." The author speaks of useless and meaningless things as if they were "vapor." See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an attempt to shepherd the wind

The author says that everything that people do is as useless as if they were trying to control the wind. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "are as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### There was no profit under the sun in it

"But it had no profit under the sun"

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### madness and folly

The words "madness" and "folly" have similar meanings and refer to foolish thinking and behavior, respectively. See how you translated this in [Ecclesiastes 1:17](../01/16.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### For what can the next king do who comes after the king, which has not already been done?

The author uses this rhetorical question to emphasize his point that the next king will not be able to do anything more valuable that what he had already done. This question can be written as a statement. AT: "For the next king who comes after the king can do nothing that a king before him has not already done." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the next king ... who comes after the king

"the king ... who succeeds the current king" or "the next king ... who comes after me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Ecclesiastes 02:13

#### wisdom has advantages over folly, just as light is better than darkness

This speaks of how wisdom is better than folly by comparing it to how light is better than darkness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### The wise man uses his eyes in his head to see where he is going

This speaks of a wise man making wise decisions as walking and paying attention to where he is going. AT: "The wise man is like a person who uses his eyes to see where he is going" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### uses his eyes in his head to see

This is an idiom. AT: "pays attention and looks to see" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the fool walks in darkness

This compares a fool making bad decisions to someone walking in darkness. AT: "the fool is like a person who walks in the dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the same event

death

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md)]]

### Ecclesiastes 02:15

#### I said in my heart

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I said to myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### So what difference does it make if I am very wise?

The author uses this rhetorical question to emphasize that there is no benefit to being wise. This question can be written as a statement. AT: "So it makes no difference if I am very wise." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I concluded in my heart

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I concluded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### is only vapor

"is only mist." The author speaks of useless and meaningless things as if they were "vapor." See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "is as useless as vapor" or "is meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For the wise man, like the fool, is not remembered for very long

This can be stated in active form. AT: "People do not remember the wise man for very long, just as they do not remember the fool for very long" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### everything will have been long forgotten

This can be stated in active form. AT: "people will have long forgotten everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Ecclesiastes 02:17

#### all the work done

This can be stated in active form. AT: "all the work that people do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### was evil to me

"troubled me"

#### vapor ... an attempt to shepherd the wind

These two phrases are both metaphors that emphasize the idea of things being useless and futile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### vapor

"mist." The author speaks of useless and meaningless things as if they were "vapor." See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an attempt to shepherd the wind

The author says everything that people do is as useless as if they were trying to control the wind. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### to the man who comes after me

"to the man who inherits it after me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Ecclesiastes 02:19

#### For who knows whether he will be a wise man or a fool?

The author uses this rhetorical question to emphasize that no one knows the character the man who will inherit his wealth. AT: "For no one knows whether he will be a wise man or a fool." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### he will be

The word "he" refers to the author's heir.

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### that my work and wisdom have built

Here the author's "work" and "wisdom" represent himself and the things he did in his wisdom. He probably had help with the literal buildings. AT: "that I worked very hard and wisely to build" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### vapor

"mist." The author speaks of useless and meaningless things as if they were "vapor." See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my heart began to despair

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I began to despair" or "I began to lose all hope" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Ecclesiastes 02:21

#### who works with wisdom, with knowledge, and skill

"who works wisely and skillfully, using the things that he has learned"

#### who has not made any of it

"who has not worked for any of it"

#### vapor

"mist." The author speaks of useless and meaningless things as if they were "vapor." See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a great tragedy

"a great disaster"

#### For what profit does the person gain who works so hard and tries in his heart to complete his labors under the sun?

The author uses a rhetorical question to emphasize that the man who works hard gains nothing. Translate "what profit does ... gain" as you did in [Ecclesiastes 1:3](../01/01.md). AT: "For the person who works so hard and tries in his heart to complete his labors under the sun gains nothing." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### works so hard and tries in his heart

These two phrases mean basically the same thing and emphasize how strenuously the person works. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### tries in his heart

This is an idiom. AT: "tries anxiously" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### painful and stressful

These two words mean basically the same thing and emphasize how difficult the person's work is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### his soul does not find rest

Here man's mind is referred to as his "soul" to emphasize his deep thoughts. AT: "his mind does not rest" or "he continues to worry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Ecclesiastes 02:24

#### God's hand

Here God is represented by his "hand" to emphasize how he provides for people. AT: "from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### For who can eat or who can have any kind of pleasure apart from God?

The author uses this rhetorical question to emphasize that no pleasure can be had without God's provision. This question can be written as a statement. AT: "For no one can eat or have any kind of pleasure apart from God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Ecclesiastes 02:26

#### so that he may give it away to someone who pleases God

Possible meanings for the word "he" are 1) God or 2) the sinner. This also can be translated without making it clear who it is that gives the things that the sinner stored. AT: "so that the one who pleases God may have it"

#### vapor ... an attempt to shepherd the wind

These two phrases are both metaphors that emphasize the idea of things being useless and futile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### vapor

"mist." The author speaks of useless and meaningless things as if they were "vapor." See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an attempt to shepherd the wind

The author speaks of everything that people do as being useless as if they were trying to control the wind. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "are as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Ecclesiastes 02:intro

#### Ecclesiastes 02 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 2:10-16.

####### Special concepts in this chapter #######

######## Pleasures ########
When the author thought about the pointlessness of life, he decided to fill it with pointless pleasures. He believed that this type of living would have no effect on the world. Therefore, he indulged in every type of pleasure.

####### Other possible translation difficulties in this chapter #######

######## Assumed knowledge ########
It is assumed that the author is going to reject the way of living in this chapter. He is certainly not encouraging this way of living even though he does not say this explicitly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Ecclesiastes 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Ecclesiastes 03

### Ecclesiastes 03:01

#### General Information:

The writer uses merisms to describe various aspects of life from one extreme to the other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### For everything there is an appointed time, and a season for every purpose

These two phrases mean basically the same thing and are combined for emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### under heaven

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a time to pull up plants

Possible meanings are 1) "a time to harvest" or 2) "a time to uproot."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Ecclesiastes 03:04

#### General Information:

The writer continues with merisms to describe various aspects of life from one extreme to the other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### embrace

to hold someone in your arms to show love or friendship

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]

### Ecclesiastes 03:06

#### General Information:

The writer continues with merisms to describe various aspects of life from one extreme to the other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

### Ecclesiastes 03:08

#### General Information:

The writer concludes using merisms to describe various aspects of life from one extreme to the other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### What profit does the worker gain in his labor?

This is a thought provoking question to focus the reader on the next discussion topic. Translate "what profit does ... gain" as you did in [Ecclesiastes 1:3](../01/01.md). AT: "The worker gains no profit for his labor." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ecclesiastes 03:11

#### God has made everything suitable for its own time

"God has fixed a time that is right for everything to happen" or "God has set a time that is right for each thing to happen:

#### placed eternity in their hearts

Here the word "their" refers to human beings. Here the "hearts" of the people represent their thoughts and desires. AT: "placed eternity in the hearts of human beings" or "caused people to think about eternal things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from their beginning all the way to their end

This refers to the beginning and the end and all that is in between. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Ecclesiastes 03:12

#### should understand how to enjoy

"should learn how to enjoy" or "should enjoy"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]

### Ecclesiastes 03:14

#### Nothing can be added to it or taken away

This can be stated in active form. AT: "No one can add anything to or take anything away from it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Ecclesiastes 03:16

#### I have seen the wickedness ... wickedness was there

These two phrases mean the same thing and emphasize how common wicked behavior is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### in place of righteousness

"where there should be righteousness"

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I said in my heart

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I said to myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the righteous and the wicked

This refers to righteous and wicked people. AT: "those who are righteous and those who are wicked" or "the righteous people and the wicked people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### every matter and every deed

These two phrases mean basically the same thing and refer to every action that people do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Ecclesiastes 03:18

#### I said in my heart

Here the author refers to himself by his "heart" to emphasize his feelings. AT: "I said to myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they are like animals

Here the author says that human beings are like animals. In the next verse the author explains clearly how humans are like animals. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]

### Ecclesiastes 03:19

#### is the same fate for them

"is the same for both of them" or "is the same"

#### The breath is the same for all of them

"All of them breathe same"

#### There is no advantage for mankind over the animals

"Mankind is no better off than the animals"

#### is not everything just a breath?

Here the author speaks of everything being as temporary as if it were a breath of air. The author uses this rhetorical question to emphasize that everything is temporary. This question can be written as a statement. AT: "Everything is just a breath." or "Everything is as temporary as a breath." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Everything is going to the same place

This means that all people and all animals die and decay and become part of the soil. AT: "Everything dies and goes to the same place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### dust

soil

### Ecclesiastes 03:21

#### Who knows whether the spirit ... into the earth?

The author asks this rhetorical question to emphasize that no one truly knows what happens after people and animals die. This question can be written as a statement. AT: "No one knows whether the spirit ... into the earth." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### there is nothing better for anyone than to

See how you translated this phrase in [Ecclesiastes 3:12](./12.md).

#### Who can bring him back to see what happens after him?

The author uses this rhetorical question to emphasize that no one will see what happens after he dies. This question can be written as a statement. AT: "No one of us knows what happens to us after we die." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]

### Ecclesiastes 03:intro

#### Ecclesiastes 03 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 3:1-8 and 3:15.

####### Important figures of speech in this chapter #######

######## Parallelism ########
The chapter uses parallelism with the phrase, "a time to." This gives the quotation a poetic style. Their overall purpose is to show that Yahweh directs the events of the world and therefore, they have purpose. 

##### Links: #####

* __[Ecclesiastes 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Ecclesiastes 04

### Ecclesiastes 04:01

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### behold, the tears

"I looked and I saw"

#### the tears of oppressed people

Here "tears" represent weeping. AT: "the oppressed people were weeping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Power was in the hand of their oppressors

This means that their oppressors were powerful. Here their "hand" represents what thet possess. AT: "Their oppressors were powerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Ecclesiastes 04:02

#### the living, who are still alive

The word "living" is a nominal adjective that refers to people who are living. The phrase "those who are still alive" means the same thing as "the living." AT: "the people who are still alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### more fortunate than both of them is the one who has not yet lived

"the one who has not yet been born is better off than both of them"

#### both of them

This refers to those who are dead and to those who are alive. AT: "both those who are dead and those who are living" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Ecclesiastes 04:04

#### became the envy of one's neighbor

The word "envy" may be expressed as an adjective. AT: "made one's neighbor envious" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the envy of one's neighbor

possible meanings are 1) The neighbor envies the object his neighbor made, or 2) the neighbor envies the skills his neighbor has.

#### vapor ... an attempt to shepherd the wind

These two phrases are both metaphors that emphasize the idea of things being useless and futile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### vapor

"mist." The author speaks of things as being useless and meaningless as if they were vapor. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an attempt to shepherd the wind

The author speaks of everything that people do as being useless as if they were trying to control the wind. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "are as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Ecclesiastes 04:05

#### The fool folds his hands and does not work

To fold the hands is a gesture of laziness and is another way of saying that the person refuses to work. AT: "The fool refuses to work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### so his food is his own flesh

This speaks of a person destroying himself as if he were eating his own body. AT: "as a result, he causes his own ruin" or "and as a result, he destroys himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a handful

"a small amount"

#### two handfuls

"a large amount." It is understood that this refer to profit gained. AT: "two handfuls of profit" or "a large amount of profit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### that tries to shepherd the wind

The author speaks of everything that people do as being useless as if they were trying to control the wind. See how you translated a similar phrase in [Ecclesiastes 1:14](../01/12.md). AT: "that is as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]

### Ecclesiastes 04:07

#### futility

being useless, without profit

#### more vanishing vapor

"more vanishing mist." The author speaks of things as being useless and meaningless as if they were vapor. See how you translated "vapor" in [Ecclesiastes 1:14](../01/12.md). AT: "more things that are as useless as vapor" or "more meaningless things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### no son or brother

This person has no family. AT: "he has no family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### his eyes are not satisfied

Here the whole person is represented by his "eyes" to emphasize his desires. AT: "he is not satisfied" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### For whom am I toiling and depriving myself of pleasure

"Will anyone benefit from me working hard and not enjoying myself"

#### vapor

"mist." The author speaks of things as being useless and meaningless as if they were vapor. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Ecclesiastes 04:09

#### sorrow follows the one who is alone when he falls

Here sorrow is spoken of as if it were a person that could follow someone else. AT: "the one who is alone when he falls is sorrowful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### If two lie down together, they can be warm

The writer speaks of two people keeping each other warm on a cold night. AT: "If two people lie down together at night, they can be warm" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### how can one be warm alone?

This refers to a person lying down. The author use this rhetorical question to emphasize that two people can keep each other warm but one person cannot. This question can be written as a statement. AT: "a person cannot be warm when he is alone." or "a person who lies down alone cannot be warm." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Ecclesiastes 04:12

#### One man alone can be overpowered

This can be written in active form. AT: "Someone can overpower a person who is alone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### but two

"but two people"

#### withstand an attack

"defend themselves against an attack"

#### a three-strand rope

This speaks of three people together being stronger as if they were a three-strand rope. AT: "three people are even stronger, like a three-strand rope that" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a three-strand rope is not quickly broken

This can be stated in active form. AT: "people cannot easily break a rope made with three strands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

### Ecclesiastes 04:13

#### youth

"young man"

#### who no longer knows how

Here knowing represents willingness. AT: "who is no longer willing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from prison

"after being in prison"

#### he was born poor in his kingdom

This means that he had poor parents. AT: "he was born to poor parents who lived in the land that he will someday rule" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]

### Ecclesiastes 04:15

#### General Information:

Instead of choosing the wise youth, the people choose the king's son, who may not be any wiser.

#### alive and walking around

The words "alive" and "walking around" mean basically the same thing and are combined to emphasize living people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### There is no end to all the people

This is an exaggeration used to emphasize a large number of people. AT: "There are very many people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### vapor ... an attempt to shepherd the wind

These two phrases are both metaphors that emphasize the idea of things being useless and futile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### vapor

"mist." The author speaks of things as being useless and meaningless as if they were vapor. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an attempt to shepherd the wind

The author speaks of everything that people do as being useless as if they were trying to control the wind. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "are as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/submit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/submit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Ecclesiastes 04:intro

#### Ecclesiastes 04 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 4:1-3, 4:5-6, and 4:8-12.

####### Important figures of speech in this chapter #######

######## Irony ########
The teacher looks at the oppression in the world and is saddened by it, but he is the king and has the power to change things. He also laments being alone even though he has many wives, children, and concubines. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

##### Links: #####

* __[Ecclesiastes 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Ecclesiastes 05

### Ecclesiastes 05:01

#### Guard your steps

Here "steps" are a metonym for a person's conduct. AT: "Be careful how you conduct yourself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Ecclesiastes 05:02

#### Do not be too quick ... do not let your heart be too quick

These two phrases mean the same thing and emphasize that you should think first before you speak to God about a matter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### to speak with your mouth

Here the phrase "with your mouth" emphasizes and describes a person speaking. AT: "to speak"

#### do not let your heart

Here a person is represented by his "heart" to emphasize his emotions and desires. AT: "do not" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### let your words be few

"do not say too much"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]

### Ecclesiastes 05:04

#### do not delay to do it, for God has no pleasure in fools

It is implied that it is foolish to delay in fulfilling a vow that you have made to God. AT: "do not foolishly delay in doing it, because God is not pleased with foolish people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]

### Ecclesiastes 05:06

#### Do not allow your mouth to cause your flesh to sin

Here a person's "mouth" represents a person's speech, and the person himself is represented by his "flesh." AT: "Do not let what you say cause you to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Why make God angry by vowing falsely, provoking God to destroy the work of your hands?

The author uses this rhetorical question to emphasize that it is foolish to make a vow that you will not keep. This question can be written as a statement. AT: "It would be foolish to make God angry by vowing falsely, provoking God to destroy the work of your hands." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### destroy the work of your hands

Here a person is represented by his "hands." AT: "destroy everything you do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### For in many dreams, as in many words, there is meaningless vapor

The author speaks of things as being useless and futile as if they were vapor. See how you translated "vapor" in [Ecclesiastes 1:14](../01/12.md). AT: "For many dreams and many words are as useless as vapor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Ecclesiastes 05:08

#### the poor being oppressed and robbed

This can be stated in active form. AT: "people oppressing the poor and robbing them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the poor

This refers to poor people. AT: "those who are poor" or "poor people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### just and right treatment

The words "just" and "right" mean basically the same thing and refer to the kind of treatment that people deserve. AT: "fair treatment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### do not be astonished as if no one knows, because there are people

"do not be surprised, for there are people

#### there are people in power

"there are people with authority"

#### even higher ones over them

There are other men who rule over the men in authority. AT: "men who have even more authority than they do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the produce of the land ... produce from the fields

The word "produce" may be expressed as a verb. AT: "the food that the land produces ... crops from the fields" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/province.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Ecclesiastes 05:10

#### vapor

"mist." The author speaks of things as being useless and meaningless as if they were vapor. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### As prosperity increases

The word "prosperity" may be expressed as an adjective. AT: "As a person becomes more prosperous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### so also do the people who consume it

Possible meanings are 1) "so also the person spends more money" or 2) "so also there will be more people who use his wealth."

#### who consume it

This speaks of people spending wealth as if they were "eating" it. AT: "who use it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### What advantage in wealth is there to the owner except to watch it with his eyes?

The author uses this rhetorical question to emphasize that the wealthy do not benefit from their wealth. This question can be written as a statement. AT: "The only benefit that the owner has from wealth is that he can look at it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]

### Ecclesiastes 05:12

#### The sleep of a working man is sweet

This speaks of a person's sleep being fulfilling and peaceful as if it were sweet like something he eats. AT: "The sleep of a working man is peaceful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### whether he eats little or a lot

"whether he eats a little bit of food or a lot of food"

#### but the wealth of a rich person does not allow him to sleep well

"but the wealth of a rich person keeps him awake at night." This speaks of a rich person not being able to sleep because he is worried about his money as if his money were a person that would not allow him to sleep. AT: "but rich people do not sleep well because they worry about their money" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

### Ecclesiastes 05:13

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### riches hoarded by the owner

This can be stated in active form. AT: "an owner hoards riches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### through bad luck

Possible meanings are 1) "through misfortune" or 2) "through a bad business deal."

#### his own son, one whom he has fathered, is left with nothing in his hands

Here the phrase "in his hands" represents ownership. This can be stated in active form. AT: "he leaves no possession for his own son" (See:[[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Ecclesiastes 05:15

#### As a man comes from his mother's womb ... he will leave naked

It is implied that a man is naked when he is born. In addition to being without clothing, here the word "naked" emphasizes that people are born without any possessions. AT: "As a man is naked and owns nothing when he is born ... he will leave this life the same way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### comes from his mother's womb

"is born"

#### he will leave

This refers to dying. AT: "he will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### He can take none of the fruits of his labor in his hand

Here a man's possessions are spoken of as if they are fruit that he grew with his labor. AT: "He can not take any of his possessions with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### as a person comes, so he goes away

This refers to the birth and death of a person and expresses the same idea as the previous verse. This refers to women as well as men. AT: "as people bring nothing into the world when they are born, so they take nothing with them when they die and leave this world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### So what profit is there for him who works for the wind?

The writer uses this rhetorical question to emphasize that there is no benefit in working for the wind. This question can be written as a statement. AT: "No one gets any profit in working for the wind." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### works for the wind

Possible meanings are 1) This speaks of the person receiving no lasting profit as if he were trying to control the wind. AT: "tries to shepherd the wind" or "work that is as useless as trying to shepherd the wind" or 2) This implies that the person only receives the air that he breaths as his profit. AT: "works to receive the air he breathes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### During his days he eats with darkness

This speaks of a person mourning throughout his life as if he always ate in darkness. Here "darkness" represents sadness and mourning. AT: "He spends his life in mourning and sadness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his days

Here a person's "days" represent his life. AT: "his life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### is greatly distressed with sickness and anger

The words "sickness" and "anger" can be expressed as adjectives. AT: "suffers greatly, being sick and angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Ecclesiastes 05:18

#### Look

The author uses this word here to draw his reader's attention to what he says next. AT: "Pay attention" or "Listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### what I have seen to be good and suitable

Here the words "good" and "suitable" mean basically the same thing. The second intensifies the meaning of the first. AT: "what I have seen to be the best thing to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### during the days of this life that God has given us

This is an idiom. AT: "as long as God allows us to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### For this is man's assignment

Possible meanings are 1) "For this is man's reward" or 2) "For these are the things that he allows man to do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ecclesiastes 05:19

#### riches and wealth

These two words mean basically the same thing. They refer to money and the things that a person can buy with money. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### to receive his share

"to accept what he is given"

#### he does not call to mind

Here the word "he" refers to the person to whom God has given a gift. The phrase "call to mind" is an idiom. AT: "he does not remember" or "he does not think about" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the days of his life

This refers to the things that happened during his lifetime. This can be stated clearly. AT: "the things that have happened during his lifetime" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### keep busy

"stay busy"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Ecclesiastes 05:intro

#### Ecclesiastes 05 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 5:2-3, and 5:10-17.

####### Special concepts in this chapter #######

######## Materialism ########
The author describes the pointlessness of pursuing material things. This is known as "materialism." Those who pursue after things will always want more. At the end of their life, they will not be able to use these things. 

##### Links: #####

* __[Ecclesiastes 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Ecclesiastes 06

### Ecclesiastes 06:01

#### it weighs heavy on men

Here evil is spoken of as something that is a heavy load to carry. AT: "it causes hardship for people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### riches, wealth

These two words mean basically the same thing. They refer to money and the things that a person can buy with money. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### he lacks nothing

This is a double negative. AT: "he has everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### God gives him no ability

"does not give him the ability"

#### vapor

"mist." The author speaks of things as being useless and meaningless as if they were vapor. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]

### Ecclesiastes 06:03

#### fathers a hundred children

"fathers 100 children." This is a hypothetical situation. This is also an exaggeration and is applicable to people with fewer than 100 children. AT: "fathers many children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### lives many years, so that the days of his years are many

These two phrases mean basically the same thing and are combined for emphasis. AT: "lives many years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### his heart is not satisfied with good

This refers to a man by his "heart" to emphasize his feelings. AT: "he is not content with good things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he is not buried with honor

This can be stated in active form. Possible meanings are 1) "no one buries him" or 2) "no one buries him properly." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### such a baby is born in futility

"such a baby is born for nothing"

#### passes away in darkness

This speaks of the death of the baby being as unexplainable as "darkness." AT: "dies unexplainably" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### its name remains hidden

This speaks of no one knowing the baby's name as if it were a hidden object. AT: "no one knows its name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]

### Ecclesiastes 06:05

#### Even if a man should live for two thousand years

This is a hypothetical situation. This is also an exaggeration to show that it does not matter how long a person lives if he does not enjoy the good things in life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### two thousand years

"2,000 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### he goes to the same place as everyone else

This means that he dies like all other people. AT: "he dies and go to the same place as everyone else" or "he goes to the grave just like everyone else" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Ecclesiastes 06:07

#### is for his mouth

Here putting food in a man's mouth represents feeding him. AT: "is to put food in his mouth" or "is to feed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### his appetite is not satisfied

This can be stated in active form. AT: "he does not satisfy his appetite" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what advantage has the wise person over the fool?

The author uses this rhetorical question to emphasize that a wise person does not have any more lasting benefits than a fool. This question can be written as a statement. AT: "it seems the wise person has no advantage over the fool." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### What advantage does the poor man have even if he knows how to act in front of other people?

The author uses this rhetorical question to emphasize that a poor man does not have any more lasting benefits than someone else. This question can be written as a statement. AT: "The poor man has no advantage even if he knows how to act in front of other people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### how to act

"how to conduct himself"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Ecclesiastes 06:09

#### what the eyes see

A person can see these things because he already has them. AT: "what a person has" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to desire what a wandering appetite craves

This refers to things that a person wants but does not have. AT: "to want what he does not have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### vapor ... an attempt to shepherd the wind

These two phrases are both metaphors that emphasize the idea of things being useless and futile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### vapor

"mist." The author speaks of things as being useless and meaningless as if they were vapor. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### an attempt to shepherd the wind

The author speaks of everything that people do as being useless as if they were trying to control the wind. See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "are as useless as trying to control the wind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Whatever has existed has already been given its name

This can be stated in active form. AT: "People have already named everything that exists" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what mankind is like has already been known

This can be stated in active form. AT: "people already know what mankind is like" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the one who is the mighty judge

"God, who is the mighty judge"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]

### Ecclesiastes 06:11

#### The more words that are spoken

This can be stated in active form. AT: "The more words that people speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the more futility increases

The more a person speaks, the more likely he will speak about meaningless things. AT: "the more meaningless those words are"

#### futility

being useless, without profit

#### what advantage is that to a man?

The author uses this rhetorical question to emphasize that there is no advantage for a man to talk a lot. This question can be written as a statement. AT: "that is no advantage to a man." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### For who knows what is good for man ... he passes like a shadow?

The author uses this rhetorical question to emphasize that no person truly knows what is good for man. This question can be written as a statement. AT: "No one knows what is good for man ... he passes like a shadow." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### in his life during his futile, numbered days through which he passes like a shadow

This speaks of how life passes quickly by saying that it is like a shadow that quickly disappears. The phrase "numbered days" emphasizes that a person's life is short. AT: "during his futile, short life, which he passes through as quickly as a shadow passes by" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Who can tell a man ... after he passes?

The author uses this rhetorical question to emphasize that no one knows what will happen after a person dies. This question can be written as a statement. AT: "No one can tell a man ... after he passes." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### what will come under the sun

This refers to things that are done on earth. See how you translated "under the sun" in [Ecclesiastes 1:3](../01/01.md). AT: "what will happen on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### after he passes

This is a polite expression for death. AT: "after he dies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md)]]

### Ecclesiastes 06:intro

#### Ecclesiastes 06 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 6:7-11.

####### Special concepts in this chapter #######

######## Satisfaction ########
While a person may be given a great many things, they are worthless and provide no sense of satisfaction or peace. It is assumed that only Yahweh can provide these things to man. Solomon is depressed that he had everything he could have ever wanted in life, but they were not enough to give him satisfaction or peace. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Ecclesiastes 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Ecclesiastes 07

### Ecclesiastes 07:01

#### A good name

Here a person's "name" is used to represent their reputation. AT: "A good reputation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### must take this to heart

This is an idiom. AT: "must think seriously about this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Ecclesiastes 07:03

#### sadness of face

This refers to being sad. AT: "an experience that makes a person sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### gladness of heart

Here the word "heart" refers to a person's thoughts and emotions. "Gladness" describes either 1) the state of the emotions of being happy and peaceful or 2) the ability to understand the truth. AT: "right thinking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The heart of the wise is in the house of mourning

Here wise people are referred to by their "hearts." This speaks of the wise person mourning as being in a house of mourning. AT: "Wise people think deeply about death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but the heart of fools is in the house of feasting

Here foolish people are referred to by their "hearts." This speaks of foolish people thinking only about what makes them happy as being in a house of feasting. AT: "but foolish people think only about enjoying themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the house of mourning ... the house of feasting

These phrases refer to what happens in these places.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Ecclesiastes 07:05

#### to the rebuke of the wise

The word "rebuke" can be expressed as a verb. AT: "when wise people rebuke you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### to listen to the song of fools

"to listen to fools sing"

#### For like the crackling of thorns burning under a pot, so also is the laughter of fools

This speaks of how listening to fools talk and laugh will teach you nothing, as if their speech and laughter were the sound of burning thorns. AT: "For listening to the laughter of fools will not teach a man any more than if he were listening to the crackling of thorns burning under a pot" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### vapor

"mist." The author speaks of things as being useless and meaningless as if they were 'vapor.' See how you translated this in [Ecclesiastes 1:14](../01/12.md). AT: "as useless as vapor" or "meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebuke.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]

### Ecclesiastes 07:07

#### Extortion

This refers to forcing someone to give money or other valuable items to another so that the other person does not harm him. It is considered wrong.

#### makes a wise man foolish

Possible meanings are 1) "turns the wise man into a foolish man" or 2) "makes the advice of the wise man appear to be foolish advice."

#### corrupts the heart

Here the word "heart" refers to the mind. AT: "ruins a person's ability to think and judge rightly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Ecclesiastes 07:08

#### the people patient in spirit are better than the proud in spirit

Here the word "spirit" refers to a person's attitude. AT: "patient people are better than proud people" or "a patient attitude is better than a prideful attitude" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Do not be quick to anger in your spirit

Here the word "spirit" refers to a person's attitude. AT: "Do not become angry quickly" or "Do not have a bad temper" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### anger resides in the hearts of fools

This speaks of a person being full of anger as if the anger lived inside him. This speaks of the anger being in the person's heart because the "heart" is thought to be the source of a person's emotions. AT: "foolish people are full of anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Ecclesiastes 07:10

#### Why were the days of old better than these?

The person asks this rhetorical question in order to complain about the present time. This question can be written as a statement. AT: "Things were better in the past than they are now." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### it is not because of wisdom that you ask this question

Here the author uses irony to rebuke the person's question. AT: "if you were wise you would not ask this question" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Ecclesiastes 07:11

#### those who see the sun

This is an idiom. AT: "those who are alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the advantage of knowledge is that wisdom gives life

Possible meanings are 1) that the writer uses the words "knowledge" and "wisdom" to mean the same thing, or 2) "the advantage of knowing wisdom is that it gives life."

#### gives life to whoever has it

This speaks of how wisdom helps to preserve a person's life as if it gave life to that person. When a person is wise he makes good decisions that help him to live a more prosperous and longer life. AT: "preserves a person's life" or "helps a person to make good decisions and to live a longer life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Ecclesiastes 07:13

#### Who can straighten out anything he has made crooked?

The author uses this rhetorical question to emphasize that no one can change something that God has done. This can be written as a statement. AT: "No one can straighten out anything he has made crooked." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ecclesiastes 07:14

#### When times are good ... when times are bad

The word "times" is an idiom for "things happening." AT: "When good things happen ... when bad things happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### live happily in that good

"be happy about those good things"

#### both to exist side by side

The phrase "side by side" is an idiom that means "this one" and "this one." AT: "both to exist" or "there to be both good and bad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### anything that is coming after him

Possible meanings are 1) "anything that happens in the future" or 2) "anything that happens to him after he dies."

### Ecclesiastes 07:15

#### in my meaningless days

"in my meaningless life"

#### in spite of their righteousness

"even though they are righteous"

#### in spite of their evil

"even though they are evil"

#### self-righteous, wise in your own eyes

These two phrases mean basically the same thing and are combined for emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Do not be self-righteous

"Do not think that you are more righteous than you actually are"

#### wise in your own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "being wise in your own opinion" or "being wise according to your own judgement" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Why should you destroy yourself?

The writer uses this rhetorical question to emphasize that being self-righteous destroys a person. AT: "There is no reason to destroy yourself." or "If you think this way you will destroy yourself." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Ecclesiastes 07:17

#### Why should you die before your time?

The author uses this rhetorical question to emphasize that there is no reason for people to do things that will cause them to die early. This question can be written as a statement. AT: "There is no reason for you to die sooner than you should." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### take hold of this wisdom

This speaks of striving to be wise as if "wisdom" were an object that a person could hold on to. AT: "commit yourself to this wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you should not let go of righteousness

This speaks of striving to be righteous as if "righteousness" were an object that a person could hold on to. AT: "you should not stop trying to be righteous" or "you should keep trying to be righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will meet all his obligations

"will do everything that God expects of him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ecclesiastes 07:19

#### Wisdom is powerful in the wise man, more than ten rulers in a city

"Wisdom makes a man powerful; it makes him more powerful than ten rulers in a city"

#### does good and never sins

"does good things and does not sin"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Ecclesiastes 07:21

#### every word that is spoken

This can be written in active form. AT: "everything that people say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you know yourself

"you yourself know." Here "yourself" is used to emphasize the phrase "you know." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### in your own heart

Here a person's thoughts are represented by their "heart." AT: "in your own thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Ecclesiastes 07:23

#### All this have I proven

here the word "this" refers to all of the things the author has written about. AT: "All this that I have already written about have I proven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### it was more than I could be

"it was beyond my ability to understand" or "but I was not able to do it"

#### far off and very deep

This speaks of wisdom being difficult to understand as if it were something located far away or in a very deep place. AT: "difficult to understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Who can find it?

The writer uses this rhetorical question to emphasize the difficulty in understanding wisdom. This question can be written as a statement. AT: "No one can understand it." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I turned my heart

Here the word "heart" refers to the mind. Also, here the word "turned" is an idiom. AT: "I directed my thoughts" or "I determined" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the explanations of reality

"the reason for things." This word "explanations" can be expressed as a verb. AT: "how to explain various things in life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Ecclesiastes 07:26

#### any woman whose heart is full of snares and nets, and whose hands are chains

The writer says that the seductive woman is like traps that hunters use to catch animals. The author speaks of a woman being seductive as if she traps men like a hunter traps animals. Her "heart" represents her thoughts and emotions. AT: "any woman who traps men by seducing them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### snares and nets

These two words both refer to ways in which people trap animals to emphasize how the woman traps men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### whose hands are chains

Here the word "hands" refers to her power and control. This speaks of her being seductive as if hands were chains that she bound people with. AT: "from whom no one can escape" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the sinner will be taken by her

This can be stated in active form. AT: "she will capture the sinner" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Ecclesiastes 07:27

#### adding one discovery to another

The word "discovery" can be expressed as a verb. The word "adding" here is used as an idiom. AT: "discovering one thing after another" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### in order to find an explanation of reality

This word "explanation" can be expressed as a verb. See how the phrase "explanations of reality" is translated in [Ecclesiastes 7:25](./23.md). AT: "in order to be able to explain things in life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### one righteous man among a thousand

"1 righteous man among 1,000." Only one righteous man was found in a group of 1,000 people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### a woman among all those

There were no righteous women found in a group of 1,000 people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Ecclesiastes 07:29

#### they have gone away looking for many difficulties

Possible meanings are 1) "they have made many sinful plans" or 2) "they have made their own lives difficult."

#### they have gone away

Here the word "they" refers to "humanity." This speaks of humanity changing from being upright to not being upright as if they were going from one place to another. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]

### Ecclesiastes 07:intro

#### Ecclesiastes 07 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 7:1-26.

####### Special concepts in this chapter #######

######## Advice ########
This chapter gives a series of disconnected pieces of advice. Translators should not try to smooth the transitions between these pieces of advice. The advice in these statements do not apply in every situation. Therefore, they should be seen as "good ideas." 

##### Links: #####

* __[Ecclesiastes 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Ecclesiastes 08

### Ecclesiastes 08:01

#### Who is a wise man? Who knows what the events in life mean?

The writer asks these as leading questions to provide the answer in what he says next.

#### causes his face to shine

This means that the person's face will show that he has wisdom. AT: "shows on his face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the hardness of his face

This is an idiom. AT: "his harsh appearance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### is changed

This can be stated in active form. AT: "changes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Ecclesiastes 08:02

#### God's oath to protect him

"the oath you made before God to protect him"

#### Do not hurry out of his presence

Possible meanings are 1) not to be hasty to physically leave the king's presence or 2) This is a metaphor that speaks of being loyal to the king as being in his presence. AT: "Do not abandon the king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The king's word rules

"What the king says is the law"

#### who will say to him

This rhetorical question emphasizes that no one will ask the king the following question. This question can be written as a statement. AT: "no one can say to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### What are you doing?

This rhetorical question is a rebuke. This question can be written as as statement. AT: "You should not be doing what you are doing." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Ecclesiastes 08:05

#### A wise man's heart recognizes

Here a man is represented by his "heart" to emphasize his thoughts. AT: "A wise man recognizes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the proper course and time of action

"the correct time to do things and the right way to do them"

#### Who can tell him what is coming?

This rhetorical question emphasizes that no one knows what will happen in the future. This question can be written as a statement. AT: "No one can tell him what is coming." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Ecclesiastes 08:08

#### No one is ruler over his breath so as to stop the breath ... no one has power over the day of his death

Just as no one has the ability to stop himself from breathing, no one can continue living when it is time to die. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### No one is ruler

The word "ruler" can be expressed as a verb. AT: "No one has control"

#### the day of his death

This is an idiom. AT: "when he will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### discharged

"allowed to leave"

#### wickedness will not rescue those who are its slaves

This speaks of wickedness as if it were a master who had slaves. AT: "evil people will not be saved by doing what is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### I have applied my heart

Here the author refers to himself by his "heart" to emphasize his feelings. See how you translated this in [Ecclesiastes 1:17](../01/16.md). AT: "I applied myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### every kind of work that is done

This can be stated in active form. AT: "every kind of work that people do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### There is a time when a person oppresses another person to that person's hurt

"Sometimes one person will oppress another, causing that person to be hurt"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Ecclesiastes 08:10

#### the wicked buried publicly

This can be stated in active form. Evil people that died were given honorable burials. AT: "people bury the wicked publicly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They were taken from the holy area and buried and were praised by people

This can be stated in active form. AT: "People took them from the holy area and buried them and praised them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### When a sentence against an evil crime is not executed quickly

This can be stated in active form. AT: "When people in authority do not quickly execute a sentence against an evil crime" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### entices the hearts of human beings

Here people are represented by their "hearts" to emphasize their will and desires. AT: "entices human beings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/criminal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/criminal.md)]]

### Ecclesiastes 08:12

#### a hundred times

"100 times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### it will be better for those who respect God

The phrase "it will be better" is an idiom. AT: "life will be better for those who respect God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### who respect God ... who stand before him and show him respect

These two phrases mean basically the same thing and are combined to emphasize people respecting God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### his life will not be prolonged

This can be stated in active form. AT: "God will not prolong his life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### His days are like a fleeting shadow

This speaks of how the wicked man's life passes quickly by saying that it is like a shadow that quickly disappears. AT: "His days will pass as quickly as a shadow disappears" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### His days are

"His life is"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md)]]

### Ecclesiastes 08:14

#### There is another useless vapor

"There is another useless mist." The author speaks of things as being useless and meaningless as if they were "vapor." See how you translated the word "vapor" in [Ecclesiastes 1:14](../01/12.md). AT: "There is something else as useless as vapor" or "There is something else meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### something else that is done on the earth

This can be stated in active form. AT: "something else that people do on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this also is useless vapor

"this also is useless mist." The author speaks of things as being useless and meaningless as if they were 'vapor.' See how you translated the word "vapor" in [Ecclesiastes 1:14](../01/12.md). AT: "this also is as useless as vapor" or "this also is meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### for all the days of his life that God has given him

This is an idiom. AT: "for as long as God allows him to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Ecclesiastes 08:16

#### I applied my heart

Here the author refers to himself by his "heart" to emphasize his feelings. See how you translated this in [Ecclesiastes 1:17](../01/16.md). AT: "I applied myself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the work that is done on the earth

This can be stated in active form. AT: "the work that people do on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### without sleep for the eyes

Here a person is represented by his "eyes." AT: "without sleeping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the work that is done under the sun

Possible meanings are 1) "the work that God does under the sun" or 2) "the work that God allows people to do under the sun." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Ecclesiastes 08:intro

#### Ecclesiastes 08 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 8:1 and 8:5-8.

####### Special concepts in this chapter #######

######## Wisdom ########
Solomon, known for his wisdom, gives a detailed description of wisdom. True wisdom is seeking to honor God. This is the only thing that lasts. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]])

##### Links: #####

* __[Ecclesiastes 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Ecclesiastes 09

### Ecclesiastes 09:01

#### I thought about all this in my mind

"I thought very deeply about all this"

#### They are all in God's hands

Here the word "they" refers to "the righteous and wise people" as well as "their deeds."

#### in God's hands

Here the word "hands" refers to power and authority. AT: "under God's control" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### whether love or hate will come to someone

This speaks of "love" and "hate" as if they are people that may come to visit someone else. AT: "whether someone will experience love or hate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Ecclesiastes 09:02

#### righteous people and wicked

This refers to all people, emphasizing the two opposites of righteous and wicked people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### wicked ... the good ... the clean and the unclean

All of these phrases refer to people. AT: "wicked people ... good people ... clean people and unclean people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the clean and the unclean

This refers to all people, emphasizing the two opposites of clean and unclean people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the clean

A person who is acceptable for God's purposes is spoken of as if the person were physically clean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the unclean

A person who is not acceptable for God's purposes is spoken of as if the person were physically unclean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the one who sacrifices and the one who does not sacrifice

This refers to all people, emphasizing the two opposites of those who sacrifice and those who do not. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### As good people ... so also will the sinner

This refers to all people, emphasizing the two opposites of good people and sinners. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### will the sinner ... will the man who fears to make an oath

It is understood that this refers to people dying. AT: "the sinner will die ... the man who fears to make an oath will die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the one who swears ... so also will the man who fears to make an oath

This refers to all people, emphasizing the two opposites of those who swear oaths and those who do not.(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Ecclesiastes 09:03

#### everything that is done

This can be stated in active form. AT: "everything that happens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the same event

death

#### The hearts of human beings are full of evil, and madness is in their hearts

Here the word "hearts" refers to the thoughts and emotions. AT: "Human beings are full of evil, and their thoughts are of madness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### madness

"folly"

#### they go to the dead

The phrase "the dead" refers to dead people. Here dead people represent the place where people go after they die. AT: "they go to the place where dead people are" or "they die and go to the grave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Ecclesiastes 09:04

#### the living ... the dead

This refers to people who are alive and people who are dead. AT: "who are alive ... those who are dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### just as a living dog is better than a dead lion

A "dog" was considered a lowly animal while a lion was considered a noble animal. This speaks of it being better to be lowly and alive than to be considered noble and dead. AT: "It is better to be lowly like a dog and to be alive than to be noble like a lion and to be dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### their memory is forgotten

This can be stated in active form. AT: "people will forget them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]

### Ecclesiastes 09:06

#### Their love, hatred, and envy

This refers to the love, hatred, and envy that the dead people showed others when they were alive.

#### anything done

This can be stated in active form. AT: "anything that people do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### eat your bread with joy, and drink your wine with a happy heart

These two phrases share similar meanings and emphasize the importance of enjoying the basic activities of life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### your bread

This refers to food in general. AT: "your food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### drink your wine with a happy heart

Here the word "heart" refers to the emotions. AT: "drink your wine joyfully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Let your clothes be always white and your head anointed with oil

Wearing white clothes and anointing one's head with oil were both signs of gladness and celebration. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### your head anointed with oil

This can be stated in active form. AT: "anoint your head with oil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]

### Ecclesiastes 09:09

#### Live happily with the wife whom you love

One should love the wife he has. AT: "Since you have a wife whom you love, live happily with her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### your days

"your lifetime"

#### That is your reward

The word "that" refers to living happily with his wife.

#### Whatever your hand finds to do

Here a person is represented by his "hand" since a person often uses his hands to work. AT: "Whatever you are able to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### there is no work or explanation or knowledge or wisdom

The nouns "work, "explanation," and "knowledge" can be expressed as verbs. AT: "the dead do not work or explain or know or have wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]

### Ecclesiastes 09:11

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The race does not belong to ... The battle does not belong to

"The race is not always won by ... The battle is not always won by"

#### Bread

Here "Bread" refers to food in general. AT: "Food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### time and chance affect them all

This is an idiom. AT: "what happens and when it happens affect them all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### affect them all

"affects all these things." Here the words "them all" refer to race, battle, bread, riches, and favor.

#### when his time will come

This refers to when a person dies. AT: "when he will die" or "when the time of his death will come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### fish are caught ... birds are caught ... the children of human beings are ensnared

This speaks of people dying when they do not expect it, in the same way that people catch animals and kill them when they do not expect it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the children of human beings are ensnared by evil times

This can be stated in active form. Also, this speaks of people experiencing disaster and unfortunate times as if they were being imprisoned or trapped. AT: "evil times are coming upon the children of human beings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that suddenly fall upon them

This is an idiom. AT: "at times when they do not expect them to happen" or "that suddenly happen to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Ecclesiastes 09:13

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a great king came against it

Here the "king" represents himself and his whole army. AT: "a great king and his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### great siege ramps

This refers to dirt ramps the army built up against the city walk so that they could climb up and attack the city.

#### in the city was found a poor, wise man

This can be stated in active form. AT: "in the city, people found a poor, wise man" or "a poor, wise man lived in the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/siege.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Ecclesiastes 09:16

#### the poor man's wisdom is despised

This can be stated in active form. AT: "people despise the poor man's wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his words are not heard

this can be stated in active form. AT: "they do not listen to what he says" or "they do not take his advice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Ecclesiastes 09:17

#### The words of wise people spoken quietly are heard better

Here "heard" represents understanding. This can be stated in active form. AT: "It is easier to understands the words that wise people speak quietly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Ecclesiastes 09:intro

#### Ecclesiastes 09 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 9:2, 5-6, and 11-12.

####### Special concepts in this chapter #######

######## Judgment ########
This chapter explains that there is one thing that awaits all people: judgment. When people die, they will all face Yahweh's judgment. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]])

##### Links: #####

* __[Ecclesiastes 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Ecclesiastes 10

### Ecclesiastes 10:01

#### As dead flies ... so a little folly

Just as flies can ruin perfume, so folly can ruin a person's reputation for wisdom and honor. This speaks of how a little folly can ruin a person's reputation in the same way that a few dead flies ruin perfume. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a little folly can overpower wisdom and honor

This speaks of how a person acting foolishly can ruin his reputation as if his "folly" and "wisdom and honor" were people and that his folly overpowered his wisdom and honor. AT: "committing a little folly can ruin a person's wisdom and honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The heart of a wise person ... the heart of a fool

Here the word "heart" refers to the mind or will. AT: "The way a wise person thinks ... the way a fool thinks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### tends to the right ... tends to the left

Here the words "right" and "left" refer to what is right and wrong. AT: "tends to doing what is right ... tends to doing what is wrong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### his thinking is deficient

This refers to the way that he acts. AT: "he is stupid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Ecclesiastes 10:04

#### If the emotions of a ruler rise up against you

Here a ruler is represented by his "emotions" AT: "If a ruler becomes angry with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Calm can quiet down great outrage

"By remaining calm you may cause an outraged person to become quiet"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Ecclesiastes 10:05

#### under the sun

This refers to things that are done on earth. See how you translated this in [Ecclesiastes 1:3](../01/01.md). AT: "on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Fools are given leadership positions

This can be stated in active form. AT: "Rulers give positions of leadership to fools" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### successful men are given low positions

This can be stated in active form. AT: "they give low positions to successful men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### low positions

This is an idiom. AT" "unimportant positions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### successful men walking like slaves on the ground

This speaks of successful men walking like slaves walk, because slaves were usually forced to walk and were not permitted to ride. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Ecclesiastes 10:08

#### a snake can bite him

This refers to a snake that was hiding inside the wall. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### cuts out stones

This refers working in a quarry and cutting larger stones.

#### can be hurt by them

This can be stated in active form. AT: "those stones can hurt him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### is endangered by it

This can be stated in active form. AT: "the wood may injure him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]

### Ecclesiastes 10:10

#### wisdom provides an advantage for success

A wise person would have sharpened his blade and would not have had to work so hard.

#### before it is charmed

This can be stated in active form. AT: "before the snake charmer charms it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Ecclesiastes 10:12

#### The words of a wise man's mouth are gracious

Here the wise man's speech is represented by his "mouth." AT: "The things that a wise man says are gracious" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the lips of a fool consume him

Here the fool's speech is represented by his "lips." This speaks of the fool destroying himself by his speech as if it were eating him. AT: "The things that a foolish man says destroy him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/foolish.md)]]

### Ecclesiastes 10:13

#### As words begin to flow from a fool's mouth

A fool's speech is represented by his "mouth." AT: "As a fool begins to speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### at the end his mouth flows with wicked madness

A fool's speech is represented by his "mouth." AT: "as he finishes talking, he speaks wicked madness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### multiplies words

This is an idiom. AT: "keeps on talking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### what is coming

"what will happen in the future"

#### Who knows what is coming after him?

The writer asks this question to emphasize that no one knows what will happen in the future after one's death. This question can be written as as statement. AT: "No one knows what is coming after him." or "No one knows what will happen after he dies." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Ecclesiastes 10:15

#### wearies them

This can be stated in active form. AT: "Fools become weary by their toil" or "Fools feel tired by the work that they do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### so that they do not even know the road to town

Possible meanings are 1) "so much that he is unable to find the road to town." That the foolish person becomes so tired from working too hard that he is unable to find his way anywhere, or 2) "because he does not even know the way to town." That the foolish person becomes tired from working too hard because he does not know enough to go home.

### Ecclesiastes 10:16

#### Woe to you, land ... blessed are you, land

In these verse, the writer is speaking to the nation as if it were a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### if your king is a young boy

This means that the king is inexperienced or immature.

#### begin feasting in the morning

This implies that the leaders are more concerned with having a good time than with leading the nation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### king is the son of nobles

This implies that the son has been trained by his elders in the customs of being a good king. AT: "king has trained by nobles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for strength, and not for drunkenness

This explains why the blessed leaders eat.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]

### Ecclesiastes 10:18

#### Because of laziness the roof sinks in

A lazy person does not keep up on the regular house maintenance. AT: "Because a lazy person does not repair his house, the roof sinks in" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### because of idle hands

Here a person is represented by his "hands" AT: "because of an idle person" or "because the person is idle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the house leaks

Here the roof is represented by the whole house. AT: "the roof leaks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### People prepare food for laughter

The word "laughter" can be expressed as a verb. AT: "People prepare food in order to laugh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### wine brings enjoyment to life

The word "enjoyment" can be expressed as a verb. AT: "wine helps people to enjoy life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### money fills the need for everything

Possible meanings are 1) "money provides for every need" or 2) "money provides for both food and wine"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Ecclesiastes 10:20

#### not even in your mind

A person's thoughts are represented by the person's "mind." AT: "not even in your thoughts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### rich people in your bedroom

"rich people when you are in your bedroom." This means that you should not curse rich people even when you are in a private place where no one else will hear.

#### For a bird of the sky ... can spread the matter

These two lines mean basically the same thing and are combined for emphasis. This speaks of people finding out what you have said as if a small bird would hear what you say and tell other people. AT: "For a bird may hear what you say and tell the matter to other people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Ecclesiastes 10:intro

#### Ecclesiastes 10 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in all of chapter 10.

####### Special concepts in this chapter #######

######## Advice ########
This chapter gives a series of disconnected pieces of advice. Translators should not try to smooth the transitions between these pieces of advice. The advice in these statements do not apply in every situation. Therefore, they should be seen as "good ideas."

##### Links: #####

* __[Ecclesiastes 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Ecclesiastes 11

### Ecclesiastes 11:01

#### Send out your bread on the waters, for you will find it again after many days

Possible meanings are 1) this is a metaphor that means a person should be generous with his possessions and will then receive generously from others , or 2) that a person should invest his resources overseas and will make a profit from it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Share it with seven, even eight people

Possible meanings are 1) to share your possessions with many people, or 2) to invest your resources in multiple places.

#### seven, even eight people

"7, even 8 people." This is an idiom that means "numerous" people. AT: "numerous people" or "multiple people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### what disasters are coming on the earth

Disasters happening is spoken of as if disasters were something that come to a place. Here "on the earth" may imply that these disasters happen to the person who is commanded to share. AT: "what disasters may happen in the world" or "what bad things may happen to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the clouds are full of rain

"the clouds are dark with rain"

#### empty themselves on the earth

"empty themselves on the ground"

#### toward the south or toward the north

Here "south" and "north" represent any direction. AT: "in any direction" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Ecclesiastes 11:04

#### Anyone who watches the wind might not plant

Possible meanings are 1) "Any farmer who pays attention to the wind will not plant when the wind is blowing in the wrong direction" or 2) "Any farmer who pays too much attention to the wind will never plant"

#### anyone who watches the clouds might not harvest

Possible meanings are 1) "Any farmer who pays attention to the clouds will not harvest when it is about to rain" or 2) "Any farmer who pays too much attention to the clouds will never harvest"

#### As you do not know the path of the wind

This speaks of wind blowing as if wind traveled on a path. AT: "As you do not know where the wind comes from or where it goes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### how a baby's bones grow

Possible meanings are 1) Here "bones" is a synecdoche representing the baby as a whole. AT: "how a baby grows" or 2) literally, "how the bones of a baby grow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]

### Ecclesiastes 11:06

#### work with your hands

Here "hands" represents the whole person. AT: "keep on working" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### whether morning or evening, or this or that

These two phrases mean basically the same thing and emphasize that the person's work may prosper, no matter what time he has done it. AT: "whether the seed that you planted in the morning or the seed that you planted in the evening" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### light is sweet

Here the word "light" refers to being able to see the sun and therefore being alive. And, this speaks of the joy of being alive as if the light had a sweet taste. AT: "it is a joy to be able to see the sun" or "being alive is delightful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for the eyes to see the sun

The "eyes" represent the whole person. This phrase means basically the same thing as the previous phrase. AT: "for a person to see the sun" or "to be alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### happy in all of them

Here the word "them" refers to the years that a person is alive.

#### the coming days of darkness

Future time is spoken of as if the "days are coming" And, here the word "darkness" refers to death. AT: "how many days that he will be dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### for they will be many

Here the word "they" refers to the "days of darkness" AT: "for he will be dead for many more days than he is alive" or "for he will be dead forever"

#### Everything to come is vanishing vapor

Here "vanishing vapor" is a metaphor. Possible meanings are 1) AT: "No one knows what will happen after he dies" or 2) AT: "Everything to come is meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Everything to come

Possible meanings are 1) "Everything that happens after death" or 2) "Everything that happens in the future"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prosper.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prosper.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]

### Ecclesiastes 11:09

#### Take joy, young man, in your youth, and let your heart be joyful in the days of your youth

These two phrases mean basically the same thing and are combined to emphasize that the man should be happy while he is young. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### let your heart be joyful

Here the word "heart" represents the emotions. AT: "be joyful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Pursue the good desires of your heart

Here the word "heart" may represent the mind or emotions. AT: "Pursue the good things that you desire" or "Pursue the good things that you have determined to pursue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### whatever is within the sight of your eyes

Here "eyes" represent the whole person. AT: "whatever you see that you desire" or "whatever you see to be best" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### God will bring you into judgment for all these things

The abstract noun "judgment" can be stated as "judge" or "make you account" AT: "God will judge you for all these things" or "God will make you account for all of your actions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Drive anger away from your heart

Refusing to be angry is spoken of as if anger were something that can be forced away. Also, "heart" represents a person's emotions. AT: "Refuse to be angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### because youth and its strength are vapor

The authors speaks of things as being useless and meaningless as if they were "vapor" Just as vapor disappears and does not last, the author speaks of things having no lasting value. See how you translated "vapor" in [Ecclesiastes 1:14](../01/12.md). AT: "because youth and its strength will not last forever" or "because you will not be young and strong forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]

### Ecclesiastes 11:intro

#### Ecclesiastes 11 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in all of chapter 11.

####### Special concepts in this chapter #######

######## Advice ########
This chapter gives a series of disconnected pieces of advice. Translators should not try to smooth the transitions between these pieces of advice. The advice in these statements do not apply in every situation. Therefore, they should be seen as "good ideas."

##### Links: #####

* __[Ecclesiastes 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Ecclesiastes 12

### Ecclesiastes 12:01

#### call to mind

This is an idiom. AT: "remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### before the days of difficulty come

Future time is spoken of as if the "days are coming" AT: "before you experience difficult times" or "before bad things happen to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### before the years arrive when you say, "I have no pleasure in them,"

Future time is spoken of as if "years arrive" AT: "before you become old when you say, 'I no longer enjoy being alive,'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### do this before the light of the sun ... after the rain

Growing old and dying is spoken of as if the sun and moon go dark and dark clouds return. AT: "do this before it seems to you that the light of the sun ... after the rain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]

### Ecclesiastes 12:03

#### General Information:

The writer describes a house in which various activities stop. This appears to be a metaphor for the human body as it becomes old. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### strong men are bent over

"strong men become weak"

#### the women who grind cease because they are few

"the women who grind grain stop grinding grain because there are few of them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tremble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tremble.md)]]

### Ecclesiastes 12:04

#### General Information:

The writer continues his metaphor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the doors are shut in the street

This can be stated in active form. AT: "people shut the doors that lead to the street" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### when men are startled at the voice of a bird

It is implied that the voice of the birds startle the men awake. This can be stated in active form. AT: "when the voice of a bird startles men awake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the singing of girls' voices fades away

Here "girls" may be a metaphor for the birds. AT: "the songs of the birds fade away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Ecclesiastes 12:05

#### General Information:

The writer continues his metaphor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### when the almond tree blossoms

The "almond tree" is a tree that blossoms in the winter with white flowers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### when grasshoppers drag themselves along

A grasshopper is a large, straight-winged insect with long, jointed back legs that give it the ability to jump a long way. Here it can only drag itself because it has gotten old and weak. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### when natural desires fail

The abstract noun "desires" can be stated as a verb. AT: "when people no longer desire what they once did naturally" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Then man goes to his eternal home

This refers to death. AT: "Then man goes to the place of the dead forever" or "Then a person dies and never returns to life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### the mourners go down the streets

Possible meanings are 1) that mourners go down the streets to attend a funeral, or 2) that mourners go down the streets to the house of the person who is about to die.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]

### Ecclesiastes 12:06

#### Call to mind

This is an idiom. AT: "Remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### before the silver cord is cut ... or the water wheel is broken at the well

The writer speaks of dying as if it were one of these various broken items. Death will break the body just as suddenly as people accidentally break these items while they are using them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the silver cord is cut

This can be stated in active form. AT: "someone cuts the silver cord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the golden bowl is crushed

This can be stated in active form. AT: "someone crushes the golden bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the pitcher is shattered

This can be stated in active form. AT: "someone shatters the pitcher" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the water wheel is broken

This can be stated in active form. AT: "someone breaks the water wheel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### dust returns to the earth

Here the word "dust" refers to the human body that has decomposed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Ecclesiastes 12:08

#### A mist of vapor ... everything is vanishing vapor

The Teacher speaks of things as being useless and meaningless as if they were "vapor." Just as vapor disappears and does not last, the author speaks of things having no lasting value. See how you translated "vapor" in [Ecclesiastes 1:14](../01/12.md). AT: "Temporary and useless ... everything is temporary and useless" or "Meaningless ... everything is meaningless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the Teacher

See how you translated this in [Ecclesiastes 1:1](../01/01.md).

#### contemplated and set in order

"thought much about and arranged" or "thought much about and wrote down"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]

### Ecclesiastes 12:10

#### using vivid ... words

The Teacher wanted the words to be pleasurable to the listener. They bring pleasure because they are well written, not because they are comforting.

#### The words of wise people ... taught by one shepherd

The writer speaks of the teacher who uses his words to instruct people as if the teacher were a shepherd who uses his tools to lead his flock. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The words of wise people are like goads

This is a simile. AT: "Wise people encourage people to act, like a sharp stick encourages an animal to move" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Like nails driven deeply are the words of the masters in collections of their proverbs

This is a simile. AT: "Like you can depend on a nail that a person drives firmly into a piece of wood, so you can depend on the words of the masters in collections of their proverbs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the words of the masters in collections of their proverbs

"the wise words collected in their proverbs" or "the sayings of the wise"

#### which are taught by one shepherd

This can be stated in active form. AT: "which one shepherd teaches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/upright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proverb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Ecclesiastes 12:12

#### the making of many books, which has no end

The noun phrase "the making" can be stated as a verb. AT: "people will never stop making many books"

#### brings weariness to the body

Here "body" represents the whole person. AT: "makes the person tired" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Ecclesiastes 12:13

#### The end of the matter

"The final conclusion on the matter"

#### after everything has been heard

This can be stated in active form. AT: "after you have heard everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### along with every hidden thing

Things done in secret is spoken of as if they were an object that was hidden. AT: "along with everything that people do in secret" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Ecclesiastes 12:intro

#### Ecclesiastes 12 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 12:1-7 and 12:13-14.

####### Special concepts in this chapter #######

######## Advice ########
This chapter gives a series of disconnected pieces of advice. Translators should not try to smooth the transitions between these pieces of advice. The advice in these statements do not apply in every situation. Therefore, they should be seen as "good ideas."

######## Yahweh ########
At the end of a very impressive life, Solomon looks back and sees that the only real lasting thing in this world is Yahweh. The purpose of his life was to honor Yahweh, something he should have done far more throughout his life. Therefore, he felt that his life was wasted. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Ecclesiastes 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | __


## Ecclesiastes front

### Ecclesiastes front:intro

#### Introduction to Ecclesiastes ####

##### Part 1: General Introduction #####

####### Outline of the Book of Ecclesiastes #######

1. Questions about the emptiness of life and the limits of human wisdom (1:1–6:12)
1. Teaching about making wise choices in how one lives (7:1–12:7)
1. The conclusion and epilogue (12:8–14)

####### What is the Book of Ecclesiastes about? #######

Ecclesiastes is a group of short teachings that try to answer the question, "What is life?" Ecclesiastes is a series of thoughts about a variety of subjects, all of them about the purpose and worth of various actions and events. From the author's viewpoint, any work we perform or any knowledge and skill we gain is useless.

####### How should the title of this book be translated? #######

The traditional title "Ecclesiastes" is another name for "assembly" and carries no meaning as a title. Translators might decide on a better title such as "Thoughts of a Teacher" or "Thoughts of a Wise Man."

####### Who wrote the Book of Ecclesiastes? #######

The author appears to be Solomon, "the Teacher, the descendant of David and king in Jerusalem." Other evidence in the book is consistent with the status and reputation of Solomon: his wisdom (See: [Ecclesiastes 1:16](../01/16.md) and twenty-six other references to wisdom); his vast wealth (See: [Ecclesiastes 2:8](../02/07.md)), and the pain that comes from wealth (See: [Ecclesiastes 5:13-14](../05/13.md); [Ecclesiastes 4:8](../04/07.md); and [Ecclesiastes 9:11](../09/11.md)); the large number of servants (See: [Ecclesiastes 2:7](../02/07.md) and [Ecclesiastes 10:7](../10/05.md)); the limitless opportunities for worldly pleasures (See: [Ecclesiastes 2:1-2](../02/01.md), [Ecclesiastes 10](../02/09.md); [Ecclesiastes 3:13](../03/12.md); [Ecclesiastes 4:8](../04/07.md); [Ecclesiastes 5:4](../05/04.md); and [Ecclesiastes 12:1](../12/01.md)); and the wide range of his many construction projects (See: [Ecclesiastes 2:4-6](../02/04.md)). The book appears to be written near the end of Solomon's reign as he reflects on how he wasted much of his life.

####### Why are there so many contradictions in the Book of Ecclesiastes? #######

Some scholars think the author was a faithful man. Other scholars think that the author made bad decisions and was sorrowful when he wrote this book. The apparent contradictions in the book may indicate Solomon's wavering faith. Or, it is also possible that the teachings in the book differ from each other in order to be relevant to various circumstances in the reader's life.

##### Part 2: Important Religious and Cultural Concepts #####

####### What is the book's teaching about God's retribution? #######

In the Ancient Near East, people were concerned with the reason they were being punished or blessed. They often attributed these acts of justice or retribution to their gods. Ecclesiastes explains that Yahweh will bless the righteous and punish the evil, but this might not happen in this life. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

####### What value did the Israelites place on the Book of Ecclesiastes? #######

The Israelites have often questioned the value of this book. This is due in large part to its unusual wording and teachings. At times, it appears to disagree with the rest of Scripture. While many have questioned its authority, it has ultimately been affirmed to be Scripture. This is because it gives valuable lessons concerning the uselessness of pursuing any goal other than to give Yahweh glory.

##### Part 3: Important Translation Issues #####

####### What is the meaning of "under the sun?" #######

"Under the sun" here is another way of saying "on the earth." When the author says that there is "nothing new under the sun," this means that there is nothing that has not happened before on earth. While the referenced event may not have specifically occurred before, there has been something similar that has happened.

####### How do I translate harsh or shocking passages? #######

There are parts of the book that can be shocking or surprising to read in Scripture. For example, "If a man fathers a hundred children and lives many years, so that the days of his years are many, but if his heart is not satisfied with good and he is not buried with honor, then I say that a baby that is born dead is better off than he is" (6:3). The translator should allow these difficulties to remain and not try to make them less surprising.

####### How is life described in the Book of Ecclesiastes? #######

The author of Ecclesiastes concluded that life without God has no value or purpose. Therefore life has no meaning. There are some subtle differences in the meaning for each of these words. A person's circumstances or character and even all of the things of this world have little or no significance apart from God. That is because God gives meaning to everything. 

At the end of their life, a person commonly sees their life as brief. The author used the metaphor of vapor or breath to describe how life ends while it seems to still be beginning.



---

