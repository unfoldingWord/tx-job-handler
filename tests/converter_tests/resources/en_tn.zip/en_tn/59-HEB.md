# <a id="heb"/>Hebrews

## Hebrews 01

### Hebrews 01:01

#### General Information:

Although this letter does not mention the recipients to whom it was sent, the author wrote particularly to Hebrews (Jews), who would have understood the many Old Testament references.

#### General Information:

This prologue lays the background for the whole book: the unsurpassing greatness of the Son — the Son is greater than all. The book begins with emphasizing that the Son is better than the prophets and the angels.

#### in these last days

"in these final days." This phrase refers to the time when Jesus began his ministry, extending until God establishes his complete rule in his creation.

#### through a Son

"Son" here is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### to be the heir of all things

The author speaks of the Son as if he will inherit wealth and property from his Father. AT: "to possess all things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It is through him that God also made the universe

"It is through the Son that God also made all things"

#### the brightness of God's glory

"the light of his glory." God's glory is associated with a very bright light. The author is saying that the Son embodies that light and fully represents God's glory.

#### glory, the exact representation of his being

"glory, the image of God's being." The "the exact representation of his being" is similar in meaning to "the brightness of God's glory." The Son embodies the character and essence of God and fully represents everything that God is. AT: "glory and is just like God" or "glory, and what is true about God is true about the Son"

#### the word of his power

"his powerful word." Here "word" refers to a message or command. AT: "his powerful command" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### After he had made cleansing for sins

The abstract noun "cleansing" can be expressed as a verb: "making clean." AT: "After he had finished making us clean from sins" or "After he had finished purifying us from our sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### he had made cleansing for sins

The author speaks of forgiving sins as if it were making a person clean. AT: "he had made it possible for God to forgive our sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he sat down at the right hand of the Majesty on high
To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "he sat down at the place of honor and authority beside the Majesty on high" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the Majesty on high

Here "Majesty" refers to God. AT: "God Most High" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]

### Hebrews 01:04

#### General Information:

The first prophetic quotation (You are my son) comes from the Psalms. The prophet Samuel wrote the second one (I will be a father to him). All occurrences of "he" refer to Jesus, the Son. The word "You" refers to Jesus, and the words "I" and "me" refer to God the Father.

#### He has become

"The Son has become"

#### as the name he has inherited is more excellent than their name

Here "name" refers to honor and authority. AT: "as the honor and authority he has inherited is superior to their honor and authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he has inherited

The author speaks of receiving honor and authority as if he were inheriting wealth and property from his father. AT: "he has received" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For to which of the angels did God ever say, "You are my son ... a son to me"?

This question emphasizes that God does not call any angel his son. AT: "For God never said to any of the angels 'You are my son ... a son to me.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You are my son ... I have become your father

These two phrases mean essentially the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Hebrews 01:06

#### General Information:

The first quotation in this section, "All God's angels ... him," comes from one of the books that Moses wrote. The second quotation, "He is the one who makes ... fire," is from the Psalms.

#### the firstborn

This means Jesus. The author refers to him as the "firstborn" to emphasize the Son's importance and authority over everyone else. It does not imply that there was a time before Jesus existed or that God has other sons like Jesus. AT: "his honored Son, his only Son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he says

"God says"

#### He is the one who makes his angels spirits, and his servants flames of fire

Possible meanings are 1) "God has made his angels to be spirits who serve him with power like flames of fire" or 2) God makes the wind and flames of fire his messengers and servants. In the original language the word for "angel" is the same as "messenger," and the word for "spirits" is the same as "wind." With either possible meaning, the point is that the angels serve the Son because he is superior. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Hebrews 01:08

#### General Information:

This scriptual quotation comes from the Psalms.

#### But to the Son he says

"But God says this to the Son"

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Your throne, God, is forever and ever

The Son's throne represents his rule. AT: "You are God, and your reign will last forever and ever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The scepter of your kingdom is the scepter of justice

Here "scepter" refers to the Son's rule. AT: "And you will rule over the people of your kingdom with justice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has anointed you with the oil of joy more than your companions

Here "oil of joy" refers to the joy that the Son felt when God honored him. AT: "has honored you and made you more joyful than anyone else" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scepter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Hebrews 01:10

#### Connecting Statement:

The author continues explaining that Jesus is superior to the angels.

#### General Information:

This quotation comes from another Psalm.

#### In the beginning

"Before anything existed"

#### you laid the earth's foundation

The author speaks of God creating the earth as if he built a building on a foundation. AT: "you created the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The heavens are the work of your hands

Here "hands" refer to God's power and action. AT: "You made the heavens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They will perish

"The heavens and earth will disappear" or "The heavens and earth will no longer exist"

#### wear out like a piece of clothing

The author speaks of the heavens and earth as if they were a piece of clothing that will get old and eventually become useless. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### roll them up like a cloak

The author speaks of the heavens and earth as if they were a robe or another kind of outer garment. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they will be changed like a piece of clothing

The author speaks of the heavens and earth as if they were clothing that could be exchanged for other clothing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### they will be changed

This can be stated in active form. AT: "you will change them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### your years do not end

Periods of time are used to represent God's eternal existence. AT: "your life will never end" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### Hebrews 01:13

#### General Information:

This quotation comes from another Psalm.

#### But to which of the angels has God said at any time ... feet"?

The author uses a question to emphasize that God has never said this to an angel. AT: "But God has never said to an angel at any time ... feet.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Sit at my right hand

To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. AT: "Sit in the place of honor beside me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### until I make your enemies a stool for your feet

Christ's enemies are spoken of as if they will become an object on which a king rests his feet. This image represents defeat and dishonor for his enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Are not all angels spirits ... inherit salvation?

The author uses this question to remind the readers that angels are not as powerful as Christ, but they have a different role. AT: "All angels are spirits who ... inherit salvation." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### for those who will inherit salvation

Receiving what God has promised believers is spoken of as if it were inheriting property and wealth from a family member. AT: "for those whom God will save" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Hebrews 01:intro

#### Hebrews 01 General Notes ####

####### Structure and formatting #######

This chapter is about how Jesus is superior to the angels.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 1:5, 7-13, which is quoted from the OT.

######## "Our ancestors" ########
This letter begins with an assumption of a Jewish audience. This is why it is called "Hebrews." 

####### Important figures of speech in this chapter #######

######## Rhetorical questions ########
The author uses rhetorical questions as a way of proving Jesus is better than the angels. 

######## Poetry ########
The author uses many poetic elements in his letter. This is not typical of a letter and causes his teachings concerning the person of Christ to stand out. 

####### Other possible translation difficulties in this chapter #######

######## Prophecy ########
Jesus literally fulfilled these prophecies about the Messiah even though the prophecies often contained poetic or metaphorical language. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])
##### Links: #####

* __[Hebrews 01:01 Notes](./01.md)__
* __[Hebrews intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Hebrews 02

### Hebrews 02:01

#### Connecting Statement:

This is the first of five urgent warnings the author gives.

#### we must

Here "we" refers to the author and includes his audience. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### so that we do not drift away from it

Possible meanings for this metaphor are 1) people who stop believing in God's word are spoken of as if they were drifting away, like a boat drifts from its position in the water. AT: "so that we do not stop believing it" or 2) people who stop obeying God's words are spoken of as if they were drifting away, like a boat drifts from its position in the water. AT: "so that we do not stop obeying it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

### Hebrews 02:02

#### For if the message that was spoken through the angels

The Jews believed that God spoke his law to Moses through angels. This can be stated in active form. AT: "For if the message that God spoke through the angels" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For if the message

The author is certain that these things are true. AT: "Because the message"

#### every trespass and disobedience receives just punishment

Here "trespass" and "disobedience" stand for the people who are guilty of these sins. AT: "every person who sins and disobeys will receive just punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### trespass and disobedience

These two words mean basically the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### how then can we escape if we ignore so great a salvation?

The author uses a question to emphasize that the people will certainly receive punishment if they refuse God's salvation through Christ. AT: "then God will certainly punish us if we do not pay attention to his message about how God will save us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### ignore

"do not care for" or "consider unimportant"

#### This is salvation that was first announced by the Lord and confirmed to us by those who heard it

This can be stated in active form. The abstract noun "salvation" can be translated with a verbal phrase. AT: "The Lord himself first announced the message about how God will save us and then those who heard the message confirmed it to us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### according to his will

"in just the way he wanted to do it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trespass.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Hebrews 02:05

#### Connecting Statement:

The writer reminds these Hebrew believers that the earth will one day be under the rule of the Lord Jesus.

#### General Information:

The quotation here is from the book of Psalms in the Old Testament. It continues on through the next section.

#### For it was not to the angels that God subjected

"For God did not make the angels rulers over"

#### the world to come

Here "world" refers to the people who live there. And "to come" means that this is the world in the next age after Christ returns. AT: "the people who will live in the new world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### What is man, that you are mindful of him?

This rhetorical question emphasizes the insignificance of humans and expresses surprise that God would pay attention to them. AT: "Humans are insignificant, and yet you are mindful of them!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Or a son of man, that you care for him?

The idiom "son of man" refers to human beings. This rhetorical question means basically the same thing as the first question. It expresses surprise that God would care for humans, who are insignificant. AT: "Human beings are of little importance, and yet you care for them!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Or a son of man

The verb may be supplied from the previous question. AT: "Or what is a son of man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]

### Hebrews 02:07

#### a little lower than the angels

The author speaks of people being less important than angels as if the people are standing in a position that is lower than the angels' position. AT: "less important than the angels" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### made man ... crowned him ... his feet ... to him

Here, these phrases do not refer to a specific person but to humans in general, including both males and females. AT: "made humans ... crowned them ... their feet ... to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### you crowned him with glory and honor

The gifts of glory and honor are spoken of as if they were a wreath of leaves placed on the head of a victorious athlete. AT: "you have given them great glory and honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You put everything in subjection under his feet

The author speaks of humans having control over everything as if they have stepped on everything with their feet. AT: "You have given them control over everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He did not leave anything not subjected to him

This double negative means that all things will be subject to Christ. AT: "God made everything subject to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### we do not yet see everything subjected to him

"we know that humans are not in control of everything yet"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/subject.md)]]

### Hebrews 02:09

#### Connecting Statement:

The writer reminds these Hebrew believers that Christ became lower than the angels when he came to earth to suffer death for forgiveness of sins, and that he became a merciful high priest to believers.

#### we see him

"we know there is one"

#### who was made

This can be stated in active form. AT: "whom God made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### lower than the angels ... crowned with glory and honor

See how you translated these words in [Hebrews 2:7](./07.md).

#### he might taste death

The experience of death is spoken of as if it were food that people can taste. AT: "he might experience death" or "he might die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bring many sons to glory

The gift of glory is spoken of here as if it were a place to which people could be brought. AT: "save many sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### many sons

Here this refers to believers in Christ, including males and females. AT: "many believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### the leader of their salvation

Possible meanings are 1) this is a metaphor in which the writer speaks of salvation as if it were a destination and of Jesus as the person who goes before the people on the road and leads them to salvation. AT: "the one who leads people to salvation" or 2) the word translated here as "leader" can mean "founder" and the author speaks of Jesus as the one who establishes salvation, or makes it possible for God to save people. AT: "the one who makes their salvation possible" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### complete

Becoming mature and completely trained is spoken of as if a person were made complete, perhaps complete in all his body parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Hebrews 02:11

#### General Information:

This prophetic quotation comes from a Psalm of King David.

#### the one who sanctifies

"the one who makes others holy" or "the one who makes others pure from sin"

#### those who are sanctified

This can be stated in active form. AT: "those whom he makes holy" or "those whom he makes pure from sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### have one source

Who that source is can be stated clearly. AT: "have one source, God himself" or "have the same Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he is not ashamed

"Jesus is not ashamed"

#### is not ashamed to call them brothers

This double negative means that he will claim them as his brothers. AT: "is pleased to call them his brothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### brothers

Here this refers to all who have believed in Jesus, including both men and women. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### I will proclaim your name to my brothers

Here "name" refers to the person's reputation and what they have done. AT: "I will proclaim to my brothers the great things you have done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from inside the assembly

"when believers come together to worship God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Hebrews 02:13

#### General Information:

The prophet Isaiah wrote these quotations.

#### And again,

"And a prophet wrote in another scripture passage what Christ said about God:"

#### the children ... the children of God

This speaks about those who believe in Christ as if they were children. AT: "those who are like my children ... those who are like children to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### share flesh and blood

The phrase "flesh and blood" refers to people's human nature. AT: "are all human beings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Jesus also shared the same things with them

"Jesus became human like them"

#### through death

Here "death" can be stated as a verb. AT: "by dying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### had the power of death

Here "death" can be stated as a verb. AT: "had the power to cause people to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### This was so that he would free all those who through fear of death lived all their lives in slavery

The fear of death is spoken of as if it were slavery. Taking away someone's fear is spoken of as it were freeing that person from slavery. AT: "This was so he might free all people. For we lived like slaves because we were afraid of dying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Hebrews 02:16

#### the seed of Abraham

Descendants of Abraham are spoken of as if they were his seed. AT: "the descendants of Abraham" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it was necessary for him

"it was necessary for Jesus"

#### like his brothers

Here "brothers" refers to people in general. AT: "like human beings"

#### he would bring about the pardon of the people's sins

Christ's death on the cross means that God can forgive sins. AT: "he would make it possible for God to forgive people's sins"

#### was tempted

This can be stated in active form. AT: "Satan tempted him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who are tempted

This can be stated in active form. AT: "whom Satan is tempting" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]

### Hebrews 02:intro

#### Hebrews 02 General Notes ####

####### Structure and formatting #######

This chapter is about how Jesus is better than Moses, the great Jew.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 2:6-8, 12-13, which is quoted from the OT.

####### Special concepts in this chapter #######

######## Brothers ########
The author probably uses the term "brothers" to refer to fellow Israelites and fellow Christians. Extra care should be taken to make sure the reference is clear. It may also be necessary to occasionally leave the referent vague. 

####### Other possible translation difficulties in this chapter #######

######## Prophecy ########
Jesus literally fulfilled these prophecies about the Messiah but the prophecies themselves often contain poetic or metaphorical language. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]], and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])
##### Links: #####

* __[Hebrews 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Hebrews 03

### Hebrews 03:01

#### Connecting Statement:

This second warning is longer and more detailed and includes chapters 3 and 4. The writer begins by showing that Christ is better than his servant Moses.

#### holy brothers

Here "brothers" refer to fellow Christians, including both men and women. AT: "holy brothers and sisters" or "my holy fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### you share in a heavenly calling

Here "heavenly" represents God. AT: "God has called us together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the apostle and high priest

Here the word "apostle" means someone who has been sent. In this passage, it does not refer to any of the twelve apostles. AT: "the one whom God sent and is the high priest"

#### of our confession

This can be reworded so that the abstract noun "confession" is expressed as the verb "confess." AT: "whom we confess" or "in whom we believe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### in God's house

The Hebrew people to whom God revealed himself are spoken of as if they were a literal house. AT: "to all of God's people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Jesus has been considered

This can be stated in active form. AT: "God has considered Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the one who built everything

God's acts of creating the world are spoken of as if he had built a house. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### every house is built by someone

This can be stated in active form. AT: "every house has someone who built it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Hebrews 03:05

#### in God's entire house

The Hebrew people to whom God revealed himself are spoken of as if they were a literal house. See how you translated this in [Hebrews 3:2](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bearing witness about the things

This phrase probably refers to all of Moses' work. AT: "Moses' life and work pointed to the things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### were to be spoken of in the future

This can be stated in active form. AT: "Jesus would say in the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### in charge of God's house

This speaks about God's people as if they were a literal house. AT: "who rules over God's people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We are his house

This speaks of God's people as if they are a literal house. AT: "We are God's people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### if we hold fast to our courage and the hope of which we boast

Here "courage" and "hope" are abstract and can be stated as verbs. AT: "if we continue to be courageous and joyfully expect God to do what he has promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Hebrews 03:07

#### Connecting Statement:

The warning here is a reminder that the Israelites' unbelief kept almost all of them from entering into the land that God had promised them. Their unbelief was well illustrated in Exodus [Exodus 17:1-7](../../exo/17/01.md), when they complained against Moses and doubted that God was with them.

#### General Information:

This quotation comes from the Old Testament in the book of Psalms.

#### if you hear his voice

God's "voice" represents him speaking. AT: "when you hear God speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### do not harden your hearts

"Hearts" here is a metonym for "thoughts and intentions." AT: "do not be stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### as in the rebellion, in the time of testing in the wilderness

Here "rebellion" and "testing" can be stated as verbs. AT: "as when your ancestors rebelled against God and tested him in the wilderness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Hebrews 03:09

#### General Information:

This quotation is from the Psalms.

#### your ancestors

Here "your" is plural and refers to the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### by testing me

Here "me" refers to God.

#### forty years

"40 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### I was displeased

"I was angry" or "I was greatly unhappy"

#### They are always being led astray in their hearts

"Led astray" here is a metaphor, as if their hearts are directing them from the correct path onto the wrong path. This can be stated in active form. AT: "They are always deceiving themselves" or "Their hearts are always deceiving" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They are always being led astray in their hearts

People who are unfaithful to God are spoken of as if someone were leading them off the right path to follow. AT: "They always refuse to follow me" or "They will not do what I command" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in their hearts

Here "hearts" refers to their minds or desires. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They have not known my ways

This speaks of a manner of conducting one's life as if it were a way or a path. AT: "They have not understood how I want them to conduct their lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They will never enter my rest

The peace and security provided by God are spoken of as if they were rest that he can give, and as if they were a place to which people could go. AT: "They will never enter the place of rest" or "I will never allow them to experience my blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Hebrews 03:12

#### brothers

Here this refers to fellow Christians including males and females. AT: "brothers and sisters" or "fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### there will not be anyone with an evil heart of unbelief, a heart that turns away from the living God

Here "heart" is a metonym that represents a person's mind or will. Refusing to believe and obey God is spoken of as if the heart did not believe and it physically turned away from God. AT: "there will not be any of you who refuse to believe the truth and who stop obeying the living God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the living God

"the true God who is really alive"

#### as long as it is called "today,"

"while there is still opportunity,"

#### no one among you will be hardened by the deceitfulness of sin

This can be stated in active form. AT: "the deceitfulness of sin will not harden any of you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### no one among you will be hardened by the deceitfulness of sin

Being stubborn is spoken of as being hard or having a hard heart. The hardness is a result of being deceived by sin. This can be reworded so that the abstract noun "deceitfulness" is expressed as the verb "deceive." AT: "no one among you will be deceived by sin and become stubborn" or "you do not sin, deceiving yourselves so that you become stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Hebrews 03:14

#### General Information:

This continues the quotation from the same psalm that was also quoted in [Hebrews 3:7](./07.md).

#### For we have become

Here "we" refers to both the writer and the readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### if we firmly hold to our confidence in him

"if we continue to confidently trust in him"

#### from the beginning

"from when we first begin to believe in him"

#### to the end

This is a polite way of referring to when a person dies. AT: "until we die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### it has been said

This can be stated in active form. AT: "the writer wrote" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### if you hear his voice

God's "voice" represents him speaking. See how you translated this in [Hebrews 3:7](./07.md). AT: "when you hear God speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### as in the rebellion

Here "rebellion" can be stated as a verb. See how you translated this in [Hebrews 3:8](./07.md). AT: "as when your ancestors rebelled against God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]

### Hebrews 03:16

#### General Information:

The word "they" refers to the disobedient Israelites, and "we" refers to the author and readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Who was it who heard God and rebelled? Was it not all those who came out of Egypt through Moses?

The author uses questions to teach his readers. These two questions can be joined as one statement, if needed. AT: "All those who came out of Egypt with Moses heard God, yet they still rebelled." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### With whom was he angry for forty years? Was it not with those who sinned, whose dead bodies fell in the wilderness?

The author uses questions to teach his readers. These two questions can be joined as one statement, if needed. AT: "For forty years, God was angry with those who sinned, and he let them die in the wilderness." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### forty years

"40 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### To whom did he swear that they would not enter his rest, if it was not to those who disobeyed him?

The author uses this question to teach his readers. AT: "And it was to those who disobeyed that he swore they would not enter his rest." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### they would not enter his rest

The peace and security provided by God are spoken of as if they were rest that he can give, and as if they were a place to which people could go. AT: "they would not enter the place of rest" or "they would not experience his blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### because of unbelief

The abstract noun "unbelief" can be translated with a verbal phrase. AT: "because they did not believe him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### Hebrews 03:intro

#### Hebrews 03 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 3:7-11,15, which is quoted from the OT.

####### Special concepts in this chapter #######

######## Brothers ########

The author probably uses the term "brothers" to refer to fellow Israelites and fellow Christians. Extra care should be taken to make sure the reference is clear. It may be necessary to occasionally leave the referent vague.

####### Important figures of speech in this chapter #######

######## Harden your hearts ########
This is a common metaphor used in Scripture. It indicates that a person who rejects Jesus will increasingly lack the spiritual discernment necessary to believe in him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]])

######## Rhetorical questions ########

The author uses rhetorical questions as a way to convince his readers.

####### Other possible translation difficulties in this chapter #######

######## Prophecy ########
Jesus literally fulfilled these prophecies about the Messiah but the prophecies themselves often contain poetic or metaphorical language. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]], and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Hebrews 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Hebrews 04

### Hebrews 04:01

#### Connecting Statement:

Chapter 4 continues the warning to believers starting in [Hebrews 3:7](../03/07.md). God, through the writer, gives believers a rest of which God's rest in the creation of the world is a picture.

#### Therefore

"Because what I have just said is true" or "Since God will certainly punish those who do not obey" ([Hebrews 3:19](../03/16.md))

#### none of you might seem to have failed to reach the promise left behind for you to enter God's rest

God's promise is spoken of as if it were a gift that God left behind when he visited the people. AT: "none of you fail to enter into God's rest, which he promised to us" or "God will allow you all to enter into his rest as he promised us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to enter God's rest

The peace and security provided by God are spoken of as if they were rest that he can give, and as if they were a place to which people could go. AT: "to enter the place of rest" or "to experience God's blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For we were told the good news just as they were

This can be stated in active form. AT: "For we heard the good news just as they did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as they were

Here "they" refers to the Hebrews' ancestors who were alive during the time of Moses.

#### But that message did not benefit those who did not unite in faith with those who obeyed

"But that message did not benefit those who did not join with the people who believed and obeyed." The author is talking about two groups of people, those who received God's covenant with faith, and those who heard it but did not believe. This can be stated in positive form. AT: "But that message benefited only those who believed and obeyed it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]

### Hebrews 04:03

#### General Information:

Here the first quotation, "As I swore ... rest," is from a psalm. The second quotation, "God rested on ... deeds," is from Moses' writings. The third quotation, "They will never enter ... rest," is again from the same psalm.

#### we who have believed

"we who believe"

#### we who have believed enter that rest

The peace and security provided by God are spoken of as if they were rest that he can give, and as if they were a place to which people could go. AT: "we who have believed will enter the place of rest" or "we who have believed will experience God's blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### just as he said

"just as God said"

#### As I swore in my wrath

"As I swore when I was very angry"

#### They will never enter my rest

The peace and security provided by God are spoken of as if they were rest that he can give, and as if they were a place to which people could go. AT: "They will never enter the place of rest" or "They will never experience my blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his works were finished

This can be stated in active form. AT: "he finished creating" or "he finished his works of creation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from the foundation of the world

The author speaks of the world as if it were a building set on a foundation. AT: "at the beginning of the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the seventh day

This is the ordinal number for "seven." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]

### Hebrews 04:06

#### General Information:

Here we find out that this quotation from the Psalms was written by David. (See: [Hebrews 3:7-8](../03/07.md))

#### it is still reserved for some to enter his rest

The peace and security provided by God are spoken of as if they were rest that he can give, and as if they were a place to which people could go. This can be stated in active form. AT: "God still allows some people to enter his place of rest" or "God still allows some people to experience his blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### if you hear his voice

God's commands to Israel are spoken of as if he had given them in an audible voice. See how you translated this in [Hebrews 3:7-8](../03/07.md). AT: "if you hear God speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### do not harden your hearts

"Hearts" here is a metonym for "thoughts and intentions." AT: "do not be stubborn"  See how you translated this in [Hebrews 3:7-8](../03/07.md). AT: "do not be stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]

### Hebrews 04:08

#### Connecting Statement:

Here the writer warns believers not to disobey but to enter into the rest God offers. He reminds them that God's word will convict them and that they can come in prayer with the confidence that God will help them.

#### if Joshua had given them rest

The peace and security provided by God are spoken of as if they were rest that Joshua could give. AT: "if Joshua had brought the Israelites to the place where God would give them rest" or "if the Israelites during the time of Joshua had experienced God's blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### there is still a Sabbath rest reserved for God's people

This can be stated in active form. AT: "there is still a Sabbath rest that God has reserved for his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a Sabbath rest

Eternal peace and security are spoken of as if they were the Sabbath day, the Jewish day of worship and rest from working. AT: "an eternal rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he who enters into God's rest

The peace and security provided by God are spoken of as if they are a place to enter. AT: "the person who enters into God's place of rest" or "the person who experiences God's blessings of rest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### let us be eager to enter that rest

The peace and security provided by God are spoken of as if they were a place to enter. AT: "we should also do everything we can to rest with God where he is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will fall into the kind of disobedience that they did

Disobedience is spoken of as if it were a hole that a person could physically fall into by accident. This passage can be reworded so that the abstract noun "disobedience" is expressed as the verb "disobey." AT: "will disobey in the same way as they did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### that they did

Here "they" refers to the Hebrews' ancestors during the time of Moses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]

### Hebrews 04:12

#### the word of God is living

Here "word of God" refers to anything that God has communicated to humanity whether through speech or through written messages. AT: "the words of God are living" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### living and active

This speaks about God's word as if it were alive. It means when God speaks, it is powerful and effective. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### sharper than any two-edged sword

A two-edged sword can easily cut through a person's flesh. God's word is very effective in showing what is in a person's heart and thoughts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### two-edged sword

a sword with a blade that is sharp on both edges

#### It pierces even to the division of soul from spirit, and joints from marrow

This continues speaking about God's word as if it were a sword. Here the sword is so sharp that it can cut through and divide parts of the human that are very difficult or even impossible to divide. This means that there is nothing inside us that we can hide from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### soul from spirit

These are two different but closely related nonphysical parts of a human. The "soul" is what causes a person to be alive. The "spirit" is the part of a person that causes him to be able to know and believe in God.

#### joints from marrow

The "joint" is what holds two bones together. The "marrow" is the center part of the bone.

#### It is able to know

This speaks about God's word as if it were a person who could know something. AT: "God's word exposes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the heart's thoughts and intentions

"Heart" here is a metonym for "inner self."  AT: "what a person is thinking and intends to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Nothing created is hidden before God

This can be stated in active form. AT: "Nothing that God has created can hide from him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### everything is bare and open

This speaks about all things as if they were a person standing bare, or a box that is open. AT: "everything is completely exposed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bare and open

These two words mean basically the same thing and emphasize that nothing is hidden from God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### to the eyes of the one to whom we must give account

God is spoken of as if he had eyes. AT: "to God, who will judge how we have lived" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pierce.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pierce.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### Hebrews 04:14

#### who has passed through the heavens

"who has entered where God is"

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### let us firmly hold to our beliefs

Belief and trust are spoken of as if they were objects that a person could grasp firmly. AT: "let us continue to believe confidently in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### we do not have a high priest who cannot feel sympathy ... Instead, we have

This double negative means that, in fact, Jesus does feel sympathy with people. AT: "we have a high priest who can feel sympathy ... Indeed, we have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### who has in all ways been tempted as we are

This can be stated in active form. AT: "who has endured temptation in every way that we have" or "whom the devil has tempted in every way that he tempts us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he is without sin

"he did not sin"

#### to the throne of grace

"to God's throne, where there is grace." Here "throne" refers to God ruling as king. AT: "to where our gracious God is sitting on his throne" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### we may receive mercy and find grace to help in time of need

Here "mercy" and "grace" are spoken of as if they were objects that can be given or can be found. AT: "God may be merciful and gracious and help us in time of need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tempt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### Hebrews 04:intro

#### Hebrews 04 General Notes ####

####### Structure and formatting #######

This chapter is about how Jesus is the greatest high priest.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 4:3-4, 7, which is quoted from the OT.

####### Special concepts in this chapter #######

######## God's rest ########
This is probably a reference to a prophesied time when Israel would have peace. This may be physical peace or spiritual peace. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]])

##### Links: #####

* __[Hebrews 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Hebrews 05

### Hebrews 05:01

#### Connecting Statement:

The writer describes the sinfulness of the Old Testament priests, then he shows that Christ has a better kind of priesthood, not based on Aaron's priesthood but on the priesthood of Melchizedek.

#### chosen from among people

This can be stated in active form. AT: "whom God chooses from among the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### is appointed

This can be stated in active form. AT: "God appoints" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to act on the behalf of people

"to represent the people"

#### the ignorant and the wayward

These nominal adjectives can be stated as adjectives. AT: "those who are ignorant and wayward" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### the wayward

people who behave in sinful ways

#### is surrounded with weakness

The high priest's own weakness is spoken of as if it were a force that surrounds him. AT: "is spiritually weak" or "is weak against sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### weakness

Here this refers to the desire to sin.

#### he also is required

This can be stated in active form. AT: "God also requires him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Hebrews 05:04

#### General Information:

This quotation is from the Psalms in the Old Testament.

#### takes this honor

Honor is spoken of as if it were an object that a person could grasp in his hands. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### takes this honor

The "honor" or praise and respect that people gave to the high priest stand for his task. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he is called by God, just as Aaron was

This can be stated in active form. AT: "God called him, just as he called Aaron" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the one speaking to him said

"God said to him"

#### You are my Son; today I have become your Father

These two phrases mean essentially the same thing. See how you translated this in [Hebrews 1:5](../01/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Son ... Father

These are important titles that describe the relationship between Jesus and God the Father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### Hebrews 05:06

#### General Information:

This prophecy is from a Psalm of David.

#### he also says

To whom God is speaking can be stated clearly. AT: "he also says to Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### in another place

"in another place in the scriptures"

#### after the manner of Melchizedek

This means that Christ as a priest has things in common with Melchizedek as a priest. AT: "in the same way that Melchizedek was a priest"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md)]]

### Hebrews 05:07

#### During the days of his flesh

Here "the days" stands for a period of time. And, "flesh" stand for Jesus's earthly life. AT: "While he lived on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### prayers and requests

Both of these words mean basically the same thing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the one able to save him from death

Possible meanings are 1) God was able to save Christ so that he would not die. AT: 'to save him from dying" or 2) God was able to save Christ after Christ's death by making him alive again. If possible, translate this in a way that allows both interpretations. 

#### he was heard

This can be stated in active form. AT: "God heard him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]

### Hebrews 05:09

#### Connecting Statement:

In verse 11 the writer begins his third warning. He warns these believers that they are still not mature and encourages them to learn God's word so they can understand right from wrong.

#### He was made perfect

This can be stated in active form. AT: "God made him perfect" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### made perfect

Here this means being made mature, able to honor God in all aspects of life.

#### became, for everyone who obeys him, the cause of eternal salvation

The abstract noun "salvation" can be stated as a verb. AT: "now he saves all who obey him and causes them to live forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### He was designated by God

This can be stated in active form. AT: "God designated him" or "God appointed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### after the manner of Melchizedek

This means that Christ as a priest has things in common with Melchizedek as a priest. AT: "to be the sort of high priest that Melchizedek was"

#### We have much to say

Even though the author uses the plural pronoun "we," he is most likely referring only to himself. AT: "I have much to say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### you have become dull in hearing

The ability to understand and obey is spoken of as if it were the ability to listen. And the ability to listen is spoken of as if it were a metal tool that becomes dull with use. AT: "you have trouble understanding it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Hebrews 05:12

#### basic principles

Here "principles" means a guideline or standard for making decisions. AT: "basic truths"

#### You need milk

Teaching about God that is easy to understand is spoken of as if it were milk, the only food that infants can take. AT: "You have become like babies and can drink only milk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### milk, not solid food

Teaching about God that is difficult to understand is spoken of as if it were solid food, suitable for adults. AT: "milk instead of solid food that adults can eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### takes milk

Here "takes" stands for "drinks." AT: "drinks milk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### because he is still a little child

Spiritual maturity is compared with the kind of food that a growing child eats. Solid food is not for a tiny baby, and that is a figure describing a young Christian who only learns simple truths; but later, more solid food is given to the little child, just as when a person matures he can learn about matters that are more difficult. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who because of their maturity have their understanding trained for distinguishing good from evil

People trained to understand something are spoken of as if their ability to understand had been trained. AT: "who are mature and can distinguish between good and evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Hebrews 05:intro

#### Hebrews 05 General Notes ####

####### Structure and formatting #######

This chapter is a continuation of the teaching of the previous chapter. 

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 5:5-6.

####### Special concepts in this chapter #######

######## High priest ########
Jesus needed to be a high priest in order to offer his life as a sacrifice for sin. The high priest was normally from the tribe of Levi, but Jesus was from the ruling tribe, Judah. His right to be a priest came from the tradition of Melchizedek, who was a priest before the Levites came into existence. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Important figures of speech in this chapter #######

######## Milk and solid food ########
This is an image used to describe maturity in Christ. It compares immature Christians to babies who are only able to drink milk. They are not mature enough to handle solid foods, which are the more complex teachings about Jesus. Instead, they have chosen not to grow and to remain like babies who drink only milk, the simpler and more basic teachings about Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Hebrews 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Hebrews 06

### Hebrews 06:01

#### Connecting Statement:

The writer continues with what immature Hebrew believers need to do to become mature Christians. He reminds them of the foundational teachings.

#### let us leave the beginning of the message of Christ and move forward to maturity

This speaks about the basic teachings as if they were the beginning of a journey and the mature teachings as if they were the end of a journey. AT: "let us stop only discussing what we first learned and start understanding more mature teachings as well" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let us not lay again the foundation ... of faith in God

Basic teachings are spoken of as if they were a building whose construction begins by laying a foundation. AT: "Let us not repeat the basic teachings ... of faith in God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### dead works

Sinful deeds are spoken of as if they belonged to the world of the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### nor the foundation of teaching ... eternal judgment

Basic teachings are spoken of as if they were a building whose construction begins by laying a foundation. AT: "nor the basic teachings ... eternal judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### laying on of hands

This practice was done to set someone apart for special service or position.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Hebrews 06:04

#### those who were once enlightened

Understanding is spoken of as if it were illumination. AT: "those who once understood the message about Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who tasted the heavenly gift

Experiencing salvation is spoken of as if it were tasting food. AT: "who experienced God's saving power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who were sharers of the Holy Spirit

The Holy Spirit, who comes to believers, is spoken of as if he were an object that people could share. AT: "who received the Holy Spirit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who tasted God's good word

Learning God's message is spoken of as if it were tasting food. AT: "who learned God's good message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the powers of the age to come

This means the power of God when his kingdom is fully present in all the world. In this sense, "the powers" refer to God himself, who holds all power. AT: "learned how God will work powerfully in the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### who then fell away

Losing all faithfulness to God is spoken of as if it were a physical fall. AT: "who then stopped believing in God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it is impossible to restore them again to repentance

"it is impossible to bring them back to repent again"

#### they crucify the Son of God for themselves again

When people turn away from God, it is as though they crucify Jesus again. AT: "it is like they crucify for themselves the very Son of God again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Son of God

This is an important title for Jesus that describes his relationship to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]

### Hebrews 06:07

#### the land that drinks in the rain

Farmland that benefits from much rain is spoken of as if it were a person who drinks in the rainwater. AT: "the land that absorbs the rain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### that gives birth to the plants

Farmland that produces crops is spoken of as if it gives birth to them. AT: "that produces plants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### to those for whom the land was worked

This can be stated in active form. AT: "to those for whom someone prepared the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the land that receives a blessing from God

Rain and crops are seen as proof that God has helped the farmland. The farmland is spoken of as if it were a person who could receive God's blessing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### a blessing from God

Here "blessing" means help from God, not spoken words.

#### is near to a curse

This speaks of "curse" as if it were a place to which a person could draw near. AT: "is in danger of God cursing it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Its end is in burning

The farmer will burn everything in the field.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Hebrews 06:09

#### we are convinced

Even though the author uses the plural pronoun "we," he is most likely referring only to himself. AT: "I am convinced" or "I am certain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### about better things concerning you

This means they are doing better than those who have rejected God, disobeyed him, and now can no longer repent so that God will forgive them (See: [Hebrews 6:4-6](./04.md)). AT: "that you are doing better things than what I have mentioned"

#### things that concern salvation

The abstract noun "salvation" can be stated as a verb. AT: "things that concern God saving you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### For God is not so unjust that he would forget

This double negative can mean that God in his justice will remember what good things his people have done. AT: "For God is just and therefore will certainly remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### for his name

God's "name" is a metonym that stands for God himself. AT: "for him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unjust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Hebrews 06:11

#### We greatly desire

Even though the author uses the plural pronoun "we," he is most likely referring only to himself. AT: "I greatly desire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### diligence

careful, hard work

#### to the end

The implicit meaning can be stated explicitly. AT: "to the end of your lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in order to make your hope certain

"in order to have complete certainty that you will receive what God has promised you"

#### imitators

An "imitator" is someone who copies the behavior of someone else.

#### inherit the promises

Receiving what God has promised believers is spoken of as if it were inheriting property and wealth from a family member. AT: "receive what God promised them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Hebrews 06:13

#### He said

God said

#### I will greatly increase you

Here "increase" stands for give descendants. AT: "I will give you many descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### what was promised

This can be stated in active form. AT: "what God promised him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]

### Hebrews 06:16

#### to the heirs of the promise

The people to whom God has made promises are spoken of as if they were to inherit property and wealth from a family member. AT: "to those who would receive what he promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the unchangeable quality of his purpose

"that his purpose would never change" or "that he would always do what he said he would do"

#### by two unchangeable things

This means God's promise and God's oath. Neither of these can ever change.

#### with which it is impossible for God to lie

This double negative can mean that God will tell the truth about this situation. AT: "about which God always tells the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### we, who have fled for refuge

Believers, who trust in God for him to protect them, are spoken of as if they were running to a safe place. AT: "we, who have trusted him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will have a strong encouragement to hold firmly to the hope set before us

Trust in God is spoken of as if encouragement were an object that could be presented to a person and that person could hold on to it. AT: "will continue to trust in God just has he encouraged us to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### set before us

This can be stated in active form. AT: "that God has placed before us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confirm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]

### Hebrews 06:19

#### Connecting Statement:

Having finished his third warning and encouragement to the believers, the writer of Hebrews continues his comparison of Jesus as priest to Melchizedek as priest.

#### as a secure and reliable anchor for the soul

Just as an anchor keeps a boat from drifting in the water, Jesus keeps us secure in God's presence. AT: "that causes us to live securely in God's presence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a secure and reliable anchor

Here the words "secure" and "reliable" mean basically the same thing and emphasize the complete reliability of the anchor. AT: "a completely reliable anchor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### hope that enters into the inner place behind the curtain

Confidence is spoken of as if it were a person who could go into the most holy place of the temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the inner place

This was the most holy place in the temple. It was thought to be the place where God was most intensely present among his people. In this passage, this place stands for heaven and God's throne room. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### after the order of Melchizedek

This means that Christ as a priest has things in common with Melchizedek as a priest. AT: "in the same way that Melchizedek was a priest"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/curtain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/curtain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md)]]

### Hebrews 06:intro

#### Hebrews 06 General Notes ####

####### Structure and formatting #######

The audience of this chapter is Christians. This will probably affect how one translates some of the difficult verses. 

####### Special concepts in this chapter #######

######## Abrahamic Covenant ########
God made a covenant with Abraham. In it, God promised to make Abraham's descendants into a great nation. He also promised to protect Abraham's descendants and to give them land of their own. These covenant promises are based on the character of God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

##### Links: #####

* __[Hebrews 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Hebrews 07

### Hebrews 07:01

#### Connecting Statement:

The writer of Hebrews continues his comparison of Jesus as priest to Melchizedek as priest.

#### Salem

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Abraham returning from the slaughter of the kings

This is refers to when Abraham and his men went and defeated the armies of four kings in order to rescue his nephew, Lot, and his family. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It was to him

"It was to Melchizedek"

#### king of righteousness ... king of peace

"righteous king ... peaceful king"

#### He is without father, without mother, without ancestors, with neither beginning of days nor end of life

It is possible to think from this passage that Melchizedek was neither born nor did he die. However, it is likely that all the writer means is that the Scriptures provide no information about Melchizedek's ancestry, birth, or death.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mosthigh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### Hebrews 07:04

#### Connecting Statement:

The writer states that the priesthood of Melchizedek is better than Aaron's priesthood and then reminds them that the priesthood of Aaron did not make anything perfect.

#### this man was

"Melchizedek was"

#### The sons of Levi who receive the priesthood

The author says this because not all of Levi's sons became priests. AT: "The descendants of Levi who became priests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]])

#### from the people

"from the people of Israel"

#### from their brothers

Here "brothers" means they are all related to each other through Abraham. AT: "from their relatives"

#### they, too, have come from Abraham's body

This is a way of saying that they were descendants of Abraham. AT: "they, too, are descendants of Abraham" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### whose descent was not traced from them

"who was not a descendant of Levi"

#### the one who had the promises

The things that God promised to do for Abraham are spoken of as if they were objects that he could possess. AT: the one to whom God had spoken his promises" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Hebrews 07:07

#### the lesser person is blessed by the greater person

This can be stated in active form. AT: "the more important person blesses the less important person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### In this case ... in that case

These phrases are used to compare the Levite priests with Melchizedek. Your language may have a way to emphasize that the author is making a comparison.

#### is testified that he lives on

It is never explicitly written in scripture that Melchizedek dies. The author of Hebrews speaks of this absence of information about Melchizedek's death in scripture as if it were a positive statement that he is still alive. This can be stated in active form. AT: "scripture shows that he lives on" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Levi ... was in the body of his ancestor

Since Levi had not been born yet, the author speaks of him as still being in Abraham's body. In this way, the author argues that Levi paid tithes to Melchizedek through Abraham. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]

### Hebrews 07:11

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### what further need would there have been for another priest to arise after the manner of Melchizedek, and not be considered to be after the manner of Aaron?

This question emphasizes that it was unexpected that priests come after the order of Melchizedek. AT: "no one would have needed another priest, one who was like Melchizedek and not like Aaron, to arise." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to arise

"to come" or "to appear"

#### after the manner of Melchizedek

This means that Christ as a priest has things in common with Melchizedek as a priest. AT: "in the same way that Melchizedek was a priest"

#### not be considered to be after the manner of Aaron

This can be stated in active form. AT: "not be after the manner of Aaron" or "who is not a priest like Aaron" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For when the priesthood is changed, the law must also be changed

This can be stated in active form. AT: "For when God changed the priesthood, he also had to change the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Hebrews 07:13

#### For the one

This refers to Jesus.

#### about whom these things are said

This can be stated in active form. AT: "about whom I am speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### it is from Judah that our Lord was born

The words "our Lord" refer to Jesus.

#### from Judah

"from the tribe of Judah"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Hebrews 07:15

#### General Information:

This quote comes from a psalm of King David.

#### What we say is clearer yet

"We can understand even more clearly." Here "we" refers to the author and his audience. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### if another priest arises

"if another priest comes"

#### in the likeness of Melchizedek

This means that Christ as a priest has things in common with Melchizedek as a priest. AT: "in the same way that Melchizedek was a priest"

#### It was not based on the law

"His becoming priest was not based on the law"

#### the law of fleshly descent

The idea of human descent is spoken of as if it had only to do with the flesh of one's body. AT: "the law of human descent" or "the law about priests' descendants becoming priests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### For scripture witnesses about him

This speaks about scripture as if it were a person who could witness about something. AT: "For God witnesses about him through the scriptures" or "For this is what was written about him in the scripture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### after the manner of Melchizedek

This means that Christ as a priest has things in common with Melchizedek as a priest. AT: "in the same way that Melchizedek was a priest"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/melchizedek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Hebrews 07:18

#### the former regulation is set aside

Here "set aside" is a metaphor for making something invalid. This can be stated in active form. AT "God made the commandment invalid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the law made nothing perfect

The law is spoken of as if it were a person who could act. AT: "no one could become perfect by obeying the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### a better hope is introduced

This can be stated in active form. AT: "God has introduced a better hope" or "God has given us reason for a more confident hope (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### through which we come near to God

Worshiping God and having his favor are spoken of coming near to him. AT: "and because of this hope we approach God" or "and because of this hope we worship God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]

### Hebrews 07:20

#### General Information:

This quote comes from the same psalm of David as verse 17. (See: [Hebrews 7:17](./15.md))

#### And it was not without an oath!

The word "it" refers to Jesus becoming the eternal priest. It can be stated clearly who made the oath. AT: "And God did not choose this new priest without swearing an oath!" or "And it was because God swore an oath that the Lord became the new priest!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Hebrews 07:22

#### Connecting Statement:

The writer then assures these Jewish believers that Christ has the better priesthood because he lives forever and the priests that descended from Aaron all died.

#### guarantee

"assurance" or "certainty"

#### he has a permanent priesthood

A priest's work is spoken of as if it were an object that Jesus possesses. This can be worded to avoid the abstract noun. AT: "he is a priest permanently" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Hebrews 07:25

#### Therefore he

You can make explicit what "Therefore" implies. AT: "Because Christ is our high priest who lives forever, he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### those who approach God through him

"those who come to God because of what Jesus has done"

#### has become higher than the heavens

"God has raised him up to the highest heavens." The author speaks of possessing more honor and power than anyone else as if it were position that is up above all things. AT: "God has given him more honor and power than anyone else" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/intercede.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/intercede.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Hebrews 07:27

#### General Information:

Here the words "He," "his," and "himself" refer to Christ.

#### the law appoints as high priests men who have weaknesses

Here "the law" is a metonym for the men who appointed the high priests according to the law of Moses. The focus is not on the men who did this, but on the fact that they did this according to the law. AT: "according to the law, men appoint as high priests men who have weaknesses" or "for according to the law, men who have weaknesses are appointed as high priests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### men who have weaknesses

"men who are spiritually weak" or "men who are weak against sin"

#### the word of the oath, which came after the law, appointed a Son

The "word of the oath" represents God who made the oath. AT: "by his oath, which God made after he gave the law, God appointed a Son" or "after he had given the law, God swore an oath and appointed his Son"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### who has been made perfect

This can be stated in active form. AT: "who has completely obeyed God and become mature" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Hebrews 07:intro

#### Hebrews 07 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 7:17, 21, which is quoted from the OT.

####### Special concepts in this chapter #######

######## High priest ########
Jesus' role as high priest is explained in detail in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

######## Melchizedek ########
The high priest was normally from the tribe of Levi, but Jesus was from the ruling tribe, Judah. His right to be a priest came from the tradition of Melchizedek, who was a priest before the Levites came into existence. This passage will be difficult to understand if Genesis has not been translated first. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## New Covenant ########
The author mentions the New Covenant and discusses Jesus' relationship to it. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/newcovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/newcovenant.md)]])
##### Links: #####

* __[Hebrews 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Hebrews 08

### Hebrews 08:01

#### Connecting Statement:

The writer, having shown that Christ's priesthood is better than the earthly priesthood, shows that the earthly priesthood was a pattern of heavenly things. Christ has a superior ministry, a superior covenant.

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### we are saying

Even though the author uses the plural pronoun "we," he is most likely referring only to himself. AT: "I am saying" or "I am writing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### sat down at the right hand of the throne of the Majesty

To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. See how you translated a similar phrase in [Hebrews 1:3](../01/01.md). AT: "sat down at the place of honor and authority beside the throne of the Majesty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### the true tabernacle that the Lord, not a man, set up

People built the earthly tabernacle out of animal skins fastened to a wooden framework, and they set it up in the manner of a tent. Here "true tabernacle" means the heavenly tabernacle that God created.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Hebrews 08:03

#### For every high priest is appointed

This can be stated in active form. AT: "For God appoints every priest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### according to the law

"as God requires in the law"

#### a copy and shadow

These words have similar meanings to emphasize that the tabernacle was merely an image of the real tabernacle in heaven. AT: "a vague image" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### shadow of the heavenly things

The author speaks of the earthly temple, which is a copy of the heavenly temple, as if it were a shadow. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### It is just as Moses was warned by God when he was

This can be stated in active form. AT: "It is just as God warned Moses when Moses was" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### was about to construct the tabernacle

Moses did not construct the tabernacle himself. He ordered the people to construct it. AT: "was about to command the people to construct the tabernacle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### See that

"Make sure that"

#### to the pattern

"to the design"

#### that was shown to you

This can be stated in active form. AT: "that I showed you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on the mountain

You can make explicit that "mountain" refers to Mount Sinai. AT: "on Mount Sinai" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Hebrews 08:06

#### Connecting Statement:

This section begins to show that the new covenant is better than the old covenant with Israel and Judah.

#### Christ has received

"God has given Christ"

#### mediator of a better covenant

This means Christ caused a better covenant between God and humans to exist.

#### covenant, which is based on better promises

This can be stated in active form. AT: "covenant. It was this covenant that God made based on better promises" or "covenant. God promised better things when he made this covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### first covenant ... second covenant

The words "first" and "second" are ordinal numbers. AT: "old covenant ... new covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### had been faultless

"had been perfect"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/minister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/minister.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Hebrews 08:08

#### General Information:

In this quotation the prophet Jeremiah foretold of a new covenant that God would make.

#### with the people

"with the people of Israel"

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you"

#### the days are coming

The future is spoken of as if it were moving toward the speaker. AT: "there will be a time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the house of Israel and with the house of Judah

The people of Israel and Judah are spoken of as if they were houses. AT: "the people of Israel and with the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I took them by their hand to lead them out of the land of Egypt

This metaphor represents God's great love and concern. AT: "I led them out of Egypt like a father leads his young child" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Hebrews 08:10

#### General Information:

This is a quotation from the prophet Jeremiah.

#### the house of Israel

The people of Israel are spoken of as if they were a house. AT: "the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### after those days

"after that time"

#### I will put my laws into their minds

God's requirements are spoken of as if they were objects that could be placed somewhere. People's ability to think is spoken of as if it were a place. AT: "I will enable them to understand my laws" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will also write them on their hearts

"Hearts" here is a metonym for "inner self" or "thoughts and intentins." AT: "I will also enable them onto their thoughts and intentions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will be their God

"I will be the God they worship"

#### they will be my people

"they will be the people for whom I care"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Hebrews 08:11

#### General Information:

This continues the quotation from the prophet Jeremiah.

#### They will not teach each one his neighbor and each one his brother, saying, 'Know the Lord.'

This direct quotation can be stated as an indirect quotation. AT: "They will not need to teach their neighbors or brothers to know me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### neighbor ... brother

Both of these refer to fellow Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Know the Lord ... will all know me

"Know" here stands for acknowledge. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### toward their evil deeds

This stands for the people who committed these evil deeds. AT: "to those who did evil deeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### their sins I will not remember any longer

Here "remember" stands for "think about." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Hebrews 08:13

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]

### Hebrews 08:intro

#### Hebrews 08 General Notes ####

####### Structure and formatting #######

The author is still speaking about Jesus' role as the ultimate high priest. The author also begins to speak about how the new covenant is superior to the covenant God made with Moses. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/newcovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/newcovenant.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 8:8-12, which is quoted from the OT.

####### Special concepts in this chapter #######

######## New covenant ########
The author mentions the new covenant and discusses Jesus' relationship to it. Israel's relationship to the new covenant is unclear and the subject of much debate.

####### Other possible translation difficulties in this chapter #######

######## We ########
The author begins to speak using the pronoun "we." It is uncertain who else this includes.
##### Links: #####

* __[Hebrews 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Hebrews 09

### Hebrews 09:01

#### Connecting Statement:

The writer makes clear to these Jewish believers that the laws and the tabernacle of the old covenant were only pictures of the better, new covenant.

#### Now

This word marks a new part of the teaching.

#### first covenant

See how you translated this in [Hebrews 8:7](../08/06.md).

#### had regulations

"had detailed instructions" or "had rules"

#### For

The author is continuing the discussion from [Hebrews 8:7](../08/06.md).

#### a tabernacle was prepared

A tabernacle was constructed and made ready for use. This idea can be stated in active form. AT: "the Israelites prepared a tabernacle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the lampstand, the table, and the bread of the presence

These objects are all accompanied by the definite article "the," because the author assumes that his readers already know about these things.

#### bread of the presence

This can be reworded so that the abstract noun "presence" is expressed as the verb "display" or "present." AT: "bread on display before God" or "bread the priests presented to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]

### Hebrews 09:03

#### Behind the second curtain

The first curtain was the outer wall of the tabernacle, so the "second curtain" was the curtain between the "holy place" and the "most holy place."

#### second

This is the ordinal word for number two. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Inside it

"Inside the ark of the covenant"

#### Aaron's rod that budded

This was the rod Aaron had when God proved to the people of Israel that he had chosen Aaron as his priest by making Aaron's rod bud. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### budded

"flowered" or "sprouted" or "grew and developed"

#### tablets of the covenant

Here "tablets" are flat pieces of stone that had writing on them. This refers to the stone tablets on which the ten commandments were written.

#### glorious cherubim overshadowed the atonement lid

When the Israelites were making the ark of the covenant, God commanded them to carve two cherubim facing each other, with their wings touching, over the atonement lid of the ark of the covenant. Here they are spoken of as providing shade for the ark of the covenant. AT: "glorious cherubim covered the atonement lid with their wings"

#### cherubim

Here "cherubim" means figures of two cherubim. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### which we cannot

Even though the author uses the plural pronoun "we," he is most likely referring only to himself. AT: "which I cannot" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]

### Hebrews 09:06

#### After these things were prepared

This can be stated in active form. AT: "After the priests prepared these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### not without blood

This can be stated in positive form. AT: "he always brought blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### blood

This is the blood of the bull and goat that the high priest had to sacrifice on the Day of Atonement.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Hebrews 09:08

#### the most holy place

Possible meanings are 1) the inner room of the tabernacle on earth or 2) God's presence in heaven.

#### the first tabernacle was still standing

Possible meanings are 1) "the outer room of the tabernacle was still standing" or 2) "the earthly tabernacle and the sacrificial system still existed." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### This was an illustration

"This was a picture" or "This was a symbol"

#### for the present time

"for now"

#### that are now being offered

This can be stated in active form. AT: "that the priests now offer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### are not able to perfect the worshiper's conscience

The writer speaks of a person's conscience as if it were an object that could be made better and better until it was without fault. A person's conscience is his knowledge of right and wrong. It is also his awareness of whether or not he has done wrong. If he knows he has done wrong, we say that he feels guilty. AT: "are not able to make the worshiper free from guilt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the worshiper's conscience

The writer appears to refer to only one worshiper, but he means all those who came to worship God at the tabernacle. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### until the time of the new order

"until God created the new order"

#### new order

"new covenant"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Hebrews 09:11

#### Connecting Statement:

Having described the service of the tabernacle under God's law, the writer makes clear that Christ's service under the new covenant is better because it is sealed with his blood. It is better also because Christ has entered the true "tabernacle," that is, God's own presence in heaven, instead of entering, as other high priests, into the earthly tabernacle, which was only an imperfect copy.

#### good things

This does not refer to material things. It means the good things that God promised in his new covenant.

#### the greater and more perfect tabernacle

This refers to the heavenly tent or tabernacle, which is more important and more perfect than the earthly tabernacle.

#### that was not made by human hands

This can be stated in active form. AT: "that humans hands did not make" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### human hands

Here "hands" refers to the whole person. AT: "humans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### most holy place

God's presence in heaven is spoken of as if it were the most holy place, the innermost room in the tabernacle. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]]

### Hebrews 09:13

#### sprinkling of a heifer's ashes on those who have become unclean

The priest would drop small amounts of the ashes on the unclean people.

#### for the cleansing of their flesh

Here "flesh" refers to the entire body. AT: "for the cleansing of their bodies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### how much more will the blood of Christ, who through the eternal Spirit offered himself without blemish to God, cleanse our conscience from dead works to serve the living God?

The author uses this question to emphasize that Christ's sacrifice was the most powerful. AT: "then certainly Christ's blood will cleanse our conscience even more from dead works to serve the living God! Because, through the eternal Spirit, he offered himself without blemish to God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the blood of Christ

The "blood" of Christ stands for his death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### cleanse our conscience

Here "conscience" refers to a person's feeling of guilt. Believers no longer have to feel guilty for the sins they have committed because Jesus sacrificed himself and has forgiven them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### blemish

This is a small sin or moral fault spoken of here as if it were a small, unusual spot or defect on Christ's body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### cleanse

Here "cleanse" stands for the action of relieving our consciences from guilt for the sins we have committed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### dead works

Sinful deeds are spoken of as if they belonged to the world of the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For this reason

"As a result" or "Because of this"

#### he is the mediator of a new covenant

This means Christ caused the new covenant between God and humans to exist.

#### first covenant

See how you translated this in [Hebrews 8:7](../08/06.md).

#### to free those under the first covenant from their sins,

"Free" here is an idiom meaning "to have the ability to live without threat of punishment. AT: "to give to those who were trying to obey the first covenant the ability to live without threat of being punished for their sins

#### those who are called

This can be stated in active form. AT: "those whom God has chosen to be his children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### inheritance

Receiving what God has promised believers is spoken of as if it were inheriting property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//heifer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//heifer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blemish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blemish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Hebrews 09:16

#### will

a legal document in which a person states who should receive his possessions when he himself dies

#### the death of the person who made it must be proven

This can be stated in active form. AT: "someone must prove that the person who made the will has died"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Hebrews 09:18

#### So not even the first covenant was established without blood

This can be stated in active and positive form. AT: "So God established even the first covenant with blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### first covenant

See how you translated this in [Hebrews 8:7](../08/06.md).

#### blood

The death of animals sacrificed to God is spoken of as if it were nothing but blood. AT: "the death of animals sacrificed to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### took the blood ... with water ... and sprinkled ... the scroll ... and all the people

The priest dipped the hyssop in the blood and the water and then shook the hyssop so drops of blood and water would fall on the scroll and on the people. Sprinkling was a symbolic action done by the priests by which they applied the benefits of the covenant to people and to objects. Here the scroll and the people's acceptability to God are renewed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### hyssop

a woody shrub with flowers in summer, used in ceremonial sprinkling

#### the blood of the covenant

Here "blood" refers to the death of the animals sacrificed to carry out the covenant's requirements. AT: "the blood that brings into effect the covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Hebrews 09:21

#### he sprinkled

"Moses sprinkled"

#### sprinkled

Sprinkling was a symbolic action done by the priests by which they applied the benefits of the covenant to people and to objects. See how you translated this in [Hebrews 9:19](./18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### all the containers used in the service

A container is an object that can hold things. Here it may refer to any kind of utensil or tool. AT: "all the utensils used in the service"

#### used in the service

This can be stated in active form. AT: "the priests used in their work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### almost everything is cleansed with blood

Making something acceptable to God is spoken of as if it were cleansing that thing. This idea can be stated in active form. AT: "the priests use blood to cleanse almost everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### blood

Here the animal "blood" is talking about the animal's death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Without the shedding of blood there is no forgiveness

Here "shedding of blood" refers to something dying as a sacrifice to God. This double negative can mean that all forgiveness comes through the shedding of blood. AT: "Forgiveness only comes when something dies as a sacrifice" or "God only forgives when something dies as a sacrifice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### forgiveness

You can state explicitly the implied meaning. AT: "forgiveness of the sins of the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bloodshed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bloodshed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]

### Hebrews 09:23

#### Connecting Statement:

The writer emphasizes that Christ (now in heaven interceding for us) had to die only once for sins and that he will return to earth a second time.

#### the copies of the things in heaven should be cleansed with these animal sacrifices

This can be stated in active form. AT: "the priests should use these animal sacrifices to cleanse what are copies of things that are in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the heavenly things themselves had to be cleansed with much better sacrifices

That is, better than the sacrifices used to cleanse the earthly copies. This can be stated in active form. AT: "as for the heavenly things themselves, God had to cleanse them with much better sacrifices" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the most holy place made with hands, which

Here "with hands" means "by humans." This can be stated in active form. AT: "the most holy place, which humans made, and which" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### of the true one

"of the true most holy place"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Hebrews 09:25

#### He did not go there

"He did not enter heaven"

#### year by year

"every year" or "each year"

#### with the blood of another

This means with the blood of an animal victim, not with his own blood.

#### If that had been the case

"If he had had to offer himself often"

#### since the world's foundation

The creation of the world is spoken of as if the world were a building and the foundation was the first part to be constructed. AT: "since God began to create the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he has been revealed

This can be stated in active form. AT: "God has revealed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to put away sin by the sacrifice of himself

This speaks about sin as if it were an object that a person could put away. Putting sin away represents forgiving it. AT: "to cause God to forgive sins by sacrificing himself" or "to sacrifice himself so that sin can be forgiven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/age.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Hebrews 09:27

#### Christ also, who was offered

This can be stated in active form. AT: "Christ also, who offered himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to take away the sins

The act of making us innocent rather than guilty for our sins is spoken of as if our sins were physical objects that Christ could carry away from us. AT: "so that God would forgive the sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the sins

Here "sins" mean the guilt that people have before God because of the sins they committed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destiny.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]

### Hebrews 09:intro

#### Hebrews 09 General Notes ####

####### Structure and formatting #######

This chapter discusses how Jesus is superior to the temple and its religious system of regulations. This chapter will be difficult to understand if the first five books of the Old Testament have not yet been translated.

####### Special concepts in this chapter #######

######## Will ########
A will is a legal document that declares what will happen to a person's property after they die.

######## Blood ########
Blood played an important role in the Mosaic and New Covenants. In the Mosaic Covenant, it was the blood of the sacrifices which was significant. In the New Covenant, it is the blood of Jesus that is much more important by comparison. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/newcovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/newcovenant.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]) 

######## Return of Christ ########
The purpose of the return of Christ is to ultimately redeem the world. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]])

####### Other possible translation difficulties in this chapter #######

######## First covenant ########
This is a reference to the covenant made with Moses. Although it is not the first covenant recorded in scripture, it was the first covenant that God made with the people of Israel, so it was earlier than the new covenant made through Jesus Christ. The translator may wish to translate "the first covenant" as "the earlier covenant."

##### Links: #####

* __[Hebrews 9:1](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Hebrews 10

### Hebrews 10:01

#### Connecting Statement:

The writer shows the weakness of the law and its sacrifices, why God gave the law, and the perfection of the new priesthood and Christ's sacrifice.

#### the law is only a shadow of the good things to come

This speaks about the law as if it were a shadow. The author means the law is not the good things that God had promised. It only hints at the good things that God is going to do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### not the real forms of those things themselves

"not the real things themselves"

#### year after year

"every year"

#### would the sacrifices not have ceased to be offered?

The author uses a question to state that the sacrifices were limited in their power. This can be stated in active form. AT: "they would have ceased offering those sacrifices." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### ceased

"stopped"

#### the worshipers would have been cleansed

Here being cleansed represents no longer being guilty of sin. This can be stated in active form. AT: "the sacrifices would have taken away their sin" or "God would have made them no longer guilty of sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### would no longer have any consciousness of sin

"would no longer think that they are guilty of sin" or "would know that they are no longer guilty of sin"

#### For it is impossible for the blood of bulls and goats to take away sins

Sins are spoken of as if they were objects that animal blood could sweep away as it flowed. AT: "For it is impossible for the blood of bulls and goats to cause God to forgive sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the blood of bulls and goats

Here "blood" refers to these animals dying as sacrifices to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shadow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### Hebrews 10:05

#### General Information:

Christ's words when he was on earth were foretold in this quotation from a psalm of David.

#### you did not desire

Here "you" is singular and refers to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### prepared

"made ready"

#### Then I said

Here "I" refers to Christ.

#### as it is written about me in the scroll

This can be stated in active form. AT: "as the prophets wrote about me in the scroll" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the scroll

This means the scriptures or the holy writings.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Hebrews 10:08

#### General Information:

Though changing the wording slightly, the author repeats these quotations from a psalm of David for emphasis.

#### sacrifices ... offerings ... whole burnt offerings ... sacrifices for sin

See how you translated these words in [Hebrews 10:5-6](./05.md).

#### that are offered

This can be stated in active form. AT: "that priests offer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you"

#### He takes away the first practice in order to establish the second practice

The abstract noun "practice" here refers to a way of atoning for sins. Stopping doing it is spoken of as if it were an object that could be taken away. Starting the second way of atoning for sins is spoken of as establishing that practice. AT: "He stops people atoning for sins the first way in order to atone for sins the second way" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### first practice ... the second practice

The words "first" and "second" are ordinal numbers. AT: "old practice ... the new practice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### we have been sanctified

This can be stated in active form. AT: "God has sanctified us" or "God has dedicated us to himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### through the offering of the body of Jesus Christ

The abstract noun "offering" can be expressed with the verb "offer" or "sacrifice." AT: "because Jesus Christ offered his body as a sacrifice" or "because Jesus Christ sacrificed his body" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Hebrews 10:11

#### Day after day

"day by day" or "every day"

#### can never take away sins

This speaks of "sins" as if they are an object that a person can take away. AT: "can never cause God to forgive sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he sat down at the right hand of God

To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. See how you translated a similar phrase in [Hebrews 1:3](../01/01.md). AT: "he sat down at the place of honor and authority beside God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### until his enemies are made a stool for his feet

The humiliation of Christ's enemies is spoken of as if they were made a place for him to rest his feet. This can be stated in active form. AT: "until God humiliates Christ's enemies and they become like a stool for his feet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### those who are being sanctified

This can be stated in active form. AT: "those whom God is sanctifying" or "those whom God has dedicated to himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/footstool.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/footstool.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]

### Hebrews 10:15

#### General Information:

This is a quotation from the prophet Jeremiah in the Old Testament.

#### with them

"with my people"

#### after those days

"when the time of the first covenant with my people has finished"

#### I will put my laws in their hearts, and I will write them on their minds

"Hearts" here is a metonym for "thoughts and intentions." AT: "I will cause them to understand my laws and I will cause them to obey them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Hebrews 10:17

#### General Information:

This continues the quotation from the prophet Jeremiah in the Old Testament.

#### Their sins and lawless deeds I will remember no longer." Now

"I will no longer remember their sins and lawless deeds" or "I will no longer think about their sins and lawless deeds." This is the second part of the Holy Spirit's testimony (See: [Hebrews 10:15-16](./15.md)). You can make this explicit in the translation by ending the quotation at the end of verse 16 and starting a new quotation here. AT: "Then next he said, 'Their sins and lawless deeds I will remember no longer.' Now" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Their sins and lawless deeds

The words "sins" and "lawless deeds" mean basically the same thing. Together they emphasize how bad the sin is. AT: "The things they did that were forbidden and how they broke the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### where there is forgiveness for these

This can be reworded so that the abstract noun "forgiveness" is expressed as the verb "forgive." AT: "when God has forgiven these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### there is no longer any sacrifice for sin

This can be reworded so that the abstract noun "sacrifice" is expressed as the verb "make offerings." AT: "people no longer need to make offerings for sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Hebrews 10:19

#### Connecting Statement:

Having made it clear that there is only one sacrifice for sin, the writer continues with the picture of the most holy place in the temple, where only the high priest could enter each year with the blood of the sacrifice for sins. He reminds the believers that they now worship God in his presence as if they were standing in the most holy place.

#### brothers

Here this means all believers in Christ whether male or female. AT: "brothers and sisters" or "fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### the most holy place

This means the presence of God, not the most holy place in the old tabernacle. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by the blood of Jesus

Here "blood of Jesus" refers to the death of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### living way

Possible meanings are 1) this new way to God that Jesus has provided results in believers living forever or 2) Jesus is alive, and he is the way believers enter into the presence of God.

#### through the curtain

The curtain in the earthly temple represents the separation between people and God's true presence. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by means of his flesh

Here "flesh" stands for the body of Jesus, and his body stands for his sacrificial death. AT: "by means of his death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### we have a great priest over the house of God

This must be translated in such a way as to make it clear that Jesus is this "great priest."

#### over the house

"in charge of the house"

#### the house of God

This speaks about God's people as if they were a literal house. AT: "all the people of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### let us approach

Here "approach" stands for worshiping God, as a priest would go up to God's altar to sacrifice animals to him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with true hearts

"with faithful hearts" or "with honest hearts." Here "hearts" stands for the genuine will and motivation of the believers. AT: "with sincerity" or "sincerely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the full assurance of faith

"and with a confident faith" or "and trusting completely in Jesus"

#### having our hearts sprinkled clean

This can be stated in active form. AT: "as if had he made our hearts clean with his blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### hearts sprinkled clean

Here "hearts" stands for the conscience, the awareness of right and wrong. Being made clean stands for being forgiven and being given the status of righteousness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### sprinkled

Sprinkling was a symbolic action done by the priests by which they applied the benefits of the covenant to people and to objects. See how you translated this in [Hebrews 9:19](../09/18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### having our bodies washed with pure water

This can be stated in active form. AT: "as if he had washed our bodies in pure water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### our bodies washed with pure water

If the translator understands this phrase as referring to Christian baptism, then "water" is literal, not figurative. But if water is taken as literal, then "pure" is figurative, standing for the spiritual purity that baptism is said here to accomplish. The "washing" stands for the believer being made acceptable to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/curtain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/curtain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Hebrews 10:23

#### Let us also hold tightly to the confession of our hope

Here "hold tightly" is a metaphor that refers to a person determining to do something and refusing to stop. The abstract nouns "confession" and "expectation" can be translated as verbs. AT: "Let us be determined to continue confessing the things that we confidently expect from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### without wavering

Being uncertain about something is spoken of as if he were wavering or leaning from side to side. AT: "without being unsure" or "without doubting" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let us not stop meeting together

You can make explicit that the people met to worship. AT: "Let us not stop coming together to worship" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### as you see the day coming closer

A future time is spoken of as if it were an object coming closer to the speaker. Here "the day" refers to when Jesus will return. AT: "as you know that Christ will return soon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]

### Hebrews 10:26

#### Connecting Statement:

The writer now gives his fourth warning.

#### deliberately

"intentionally"

#### after we have received the knowledge of the truth

Knowledge of the truth is spoken of as if it were an object that could be given by one person to another. AT: "after we have learned the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the truth

The truth about God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a sacrifice for sins no longer exists

No one is able to give a new sacrifice because Christ's sacrifice is the only one that works. AT: "no one can offer a sacrifice for which God will forgive our sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a sacrifice for sins

Here "sacrifice for sins" stands for "an effective way to sacrifice animals to take away sins"

#### of judgment

Of God's judgment, that is, that God will judge. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a fury of fire that will consume God's enemies

God's fury is spoken of as if it were fire that would burn up his enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Hebrews 10:28

#### of two or three witnesses

It is implied that this means "of at least two or three witness." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### How much worse punishment do you think one deserves ... grace?

The author is emphasizing the greatness of the punishment for those who reject Christ. AT: "This was severe punishment. But the punishment will be even greater for anyone ... grace!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### has trampled underfoot the Son of God

Disregarding Christ and scorning him are spoken of as if someone had walked on him. AT: "has rejected the Son of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### who treated the blood of the covenant as unholy

This shows how the person has trampled the Son of God. AT: "by treating the blood of the covenant as unholy"

#### the blood of the covenant

Here "blood" stands for Christ's death, by which God established the new covenant. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the blood by which he was sanctified

This can be stated in active form. AT: "the blood by which God sanctified him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Spirit of grace

"the Spirit of God, who provides grace"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trample.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trample.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Hebrews 10:30

#### General Information:

The word "we" here refers to the writer and all believers. These two quotations come from the law that Moses gave in the Old Testament. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### Vengeance belongs to me

Vengeance is spoken of as if it were an object that belongs to God, who has the right to do as he wishes with what he owns. God has the right to take vengeance on his enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will pay back

God taking vengeance is spoken of as if he were paying back the harmful things that someone has done to others. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to fall into the hands

Receiving God's full punishment is spoken of as if the person falls into God's hands. Here "hands" refers to God's power to judge. AT: "to receive God's full punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Hebrews 10:32

#### the former days

"the time in the past"

#### after you were enlightened

Learning the truth is spoken of as if God shined a light on the person. This can be stated in active form. AT: "after you learned the truth about Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### how you endured a great struggle in suffering

"how much suffering you had to endure"

#### You were exposed to public ridicule by insults and persecution

This can be stated in active form. AT: "People ridiculed you by insulting and persecuting you in public" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you were sharing with those

"you joined those"

#### a better and everlasting possession

God's eternal blessings are spoken of as a "possession." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Hebrews 10:35

#### General Information:

In 10:37 is a quotation from the prophet Isaiah in the Old Testament.

#### do not throw away your confidence, which has a great reward

A person no longer having confidence is spoken of as if the person were to throw confidence away, like a person would discard something worthless. The abstract noun "confidence" can be translated with the adjective "confident" or the adverb "confidently." AT: "do not stop being confident, because you will receive a great reward for being confident" or "do not stop confidently trusting in God, who will reward you greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### For in a very little while

You can make this explicit. AT: "As God said in the scriptures, 'For in a very little while" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in a very little while

"very soon"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]

### Hebrews 10:38

#### General Information:

In 10:38 the author quotes from the prophet Habakkuk, which directly follows the quotation from the prophet Isaiah in 10:37.

#### My righteous one ... If he shrinks ... with him

These refer to any of God's people in general. AT: "My faithful people ... If any one of them shrinks ... with that person" or "My faithful people ... If they shrink ... with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### My righteous ... I will

Here "My" and "I" refer to God.

####  shrinks back

stops doing the good thing he is doing

#### who turn back to destruction

A person who loses courage and faith are spoken of as if he were stepping back in fear from something. And "destruction" is spoken of as if it were a destination. AT: "who stop trusting God, which will cause him to destroy us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for keeping our soul

Living eternally with God is spoken of as if it were keeping one's soul. Here "soul" refers to the whole person. AT: ", which will result in us living with God forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]

### Hebrews 10:intro

#### Hebrews 10 General Notes ####

####### Structure and formatting #######

This chapter discusses how life as a Christian is superior to life as a Jew under the law of Moses and how the sacrifice of Jesus was superior to the sacrifices offered in the Temple. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 10:5-7, 15-17, 37-38, which is quoted from the OT.

####### Special concepts in this chapter #######

== God's judgment and reward==
Holy living is important for Christians. God will hold people accountable for how they lived their Christian life. Even though there will not be eternal condemnation for Christians, ungodly actions do and will have consequences. In addition, faithful living will be rewarded. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]])

####### Other possible translation difficulties in this chapter #######

######## "For it is impossible for the blood of bulls and goats to take away sins" ########
The sacrifices themselves had no redeeming power. They were effective because they were a display of faith, which was credited to the person offering the sacrifice. It was ultimately the sacrifice of Jesus which then makes these sacrifices "take away sins." In turn, God does not want sacrifices offered devoid of faith. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/redeem.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## "The covenant that I will make" ########
It is unclear whether this prophecy was being fulfilled as the author was writing or whether it was to occur later. The translator should try to avoid making a claim about the time this covenant begins. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

##### Links: #####

* __[Hebrews 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Hebrews 11

### Hebrews 11:01

#### Connecting Statement:

The author tells three things about faith in this brief introduction.

#### Now

This word is used here to mark a break in the main teaching. Here the author starts to explain the meaning of "faith."

#### faith is being sure of the things hoped for

This can be stated in active form. AT: "when we have faith, we are sure of the things we hope for" or "faith is what allows a person to confidently expect certain things"

#### hoped for

Here this refers specifically to the sure promises of God, especially the certainty that all believers in Jesus will live with God forever in heaven.

#### certain of things that are not seen

This can be stated in active form. AT: "that we still have not seen" or "that still have not happened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### For because of this

"Because they were certain about events that had not happened"

#### the ancestors were approved for their faith

This can be stated in active form. AT: "God approved of our ancestors because they had faith" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the ancestors

The author is speaking to the Hebrews about Hebrew ancestors. AT: "our ancestors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the universe was created by God's command

This can be stated in active form. AT: "God created the universe by commanding it to exist" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what is visible was not made out of things that were visible

This can be stated in active form. AT: "God did not create what we see out of things that were visible"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Hebrews 11:04

#### Connecting Statement:

The writer then gives many examples (mostly from Old Testament writings) of people who lived by faith even though they did not receive what God had promised while they lived on the earth.

#### he was attested to be righteous

This can be stated in active form. AT: "God declared him to be righteous" or "God declared that Abel was righteous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Abel still speaks

Reading the scriptures and learning about Abel's faith is spoken of as if Abel himself were still speaking. AT: "we still learn from what Abel did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Hebrews 11:05

#### It was by faith that Enoch was taken up so that he did not see death

This can be stated in active form. AT: "It was by faith that Enoch did not die because God took him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### see death

This speaks of death as if it were an object that people can see. It means to experience death. AT: "die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### before he was taken up

This can be stated in active form. AT: "before God took him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it was testified that he had pleased God

This can be stated in active form. Possible meanings are 1) "God said that Enoch had pleased him" or 2) "people said that Enoch pleased God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Now without faith

Here "Now" does not mean "at this moment," but is used to draw attention to the important point that follows.

#### without faith it is impossible to please him

This can be stated in positive form. AT: "a person can please God only if he has faith in God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### that anyone coming to God

Wanting to worship God and belong to his people is spoken of as if the person is literally coming to God. AT: "that anyone who wants to belong to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he is a rewarder of those

"he rewards those"

#### those who seek him

Those who learn about God and make an effort to obey him are spoken of as if they were seeking to find him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/enoch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/enoch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md)]]

### Hebrews 11:07

#### having been given a divine message

This can be stated in active form and in other terms. AT: "because God told him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### about things not yet seen

This can be stated in active form. AT: "about things no one had ever seen before" or "about events that had not happened yet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the world

Here "world" refers to the world's human population. AT: "the people living in the world at that time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### became an heir of the righteousness

Noah is spoken of as if he were to inherit property and wealth from a family member. AT: "received from God the righteousness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that is according to faith

"that God gives to those who have faith in him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/noah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/noah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/divine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/divine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reverence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reverence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Hebrews 11:08

#### when he was called

This can be stated in active form. AT: "when God called him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### went out to the place

"left his home to go to the place"

#### that he was to receive as an inheritance

The land that God promised to give Abraham's descendants is spoken of as if it were an inheritance that Abraham was to receive. AT: "that God would give him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He went out

"He left his home"

#### he lived in the land of promise as a foreigner

This can be reworded so that the abstract noun "promise" is expressed as the verb "promised." AT: "he lived as a foreigner in the land God had promised to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### fellow heirs

"heirs together." This speaks about Abraham, Isaac, and Jacob as if they were heirs that would receive an inheritance from their father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the city with foundations

"the city that has foundations." Having foundations indicates that the city is permanent. AT: "the eternal city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### whose architect and builder is God

"which is designed and built by God" or "which God would design and build"

#### architect

a person who designs buildings and cities

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heir.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]

### Hebrews 11:11

#### It was by faith

The abstract noun "faith" can be expressed with the verb "believe." Possible meanings are 1) it was by Abraham's faith. AT: "It was because Abraham believed God" or 2) it was by Sarah's faith. AT: "It was because Sarah believed God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### received ability to father a child

"received ability to become a father" or "received ability to have a child"

#### since he considered as faithful the one who had given the promise

"because he believed God, who had give the promise, to be faithful"

#### almost dead

"too old to have children" or "very old"

#### descendants as many as the stars in the sky and as countless as sand by the seashore

This simile means Abraham had very many descendants. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### as countless as sand by the seashore

This means that just as there are so many grains of sand on the seashore that no one can count them all, Abraham had so many descendants that no one can count them all.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sarah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sarah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/conceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/conceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Hebrews 11:13

#### without receiving the promises

This speaks of promises as if they are objects that a person receives. AT: "without receiving what God had promised them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### after seeing and greeting them from far off

Future promised events are spoken of as if they were travelers arriving from far away. AT: "after learning what God will do in the future" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they admitted

"they acknowledged" or "they accepted"

#### they were foreigners and exiles on earth

Here "foreigners" and "exiles" mean basically the same thing. This emphasizes that this earth was not their true home. They were waiting for their true home that God would make for them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### a homeland

"a country for them to belong to"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Hebrews 11:15

#### heavenly one

"heavenly country" or "country in heaven"

#### God is not ashamed to be called their God

This can be expressed in active and positive form. AT: "God is happy to have them call him their God" or "God is proud to have them say that he is their God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Hebrews 11:17

#### when he was tested

This can be stated in active form. AT: "when God tested him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to whom it had been said

This can be stated in active form. AT: "to whom God said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that your descendants will be named

Here "named" means assigned or designated. This sentence can be stated in active form. AT: "that I will designate your descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### God was able to raise up Isaac from the dead

"Raise" here is an idiom for "caused to live again" AT: "God was able to cause Isaac to live again"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### to raise up ... from the dead

In this verse, "to raise up" is to make alive again. The words "from the dead" speak of all dead people together in the underworld.

#### figuratively speaking

"in a manner of speaking." This means that what the author says next is not to be understood literally. God did not bring Isaac back from death literally. But because Abraham was about to sacrifice Isaac when God stopped him, it was as if God brought him back from the dead.

#### it was from them

"it was from the dead"

#### he received him back

"Abraham received Isaac back"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Hebrews 11:20

#### Jacob worshiped

"Jacob worshiped God"

#### when his end was near

Here "his end" is a polite way of referring to death. AT: "when he was about to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### spoke of the departure of the children of Israel from Egypt

"spoke of when the children of Israel would leave Egypt"

#### the children of Israel

"the Israelites" or "the descendants of Israel"

#### instructed them about his bones

Joseph died while in Egypt. He wanted his people to take his bones with them when they left Egypt so they could bury his bones in the land that God promised them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]

### Hebrews 11:23

#### Moses, when he was born, was hidden for three months by his parents

This can be stated in active form. AT: "Moses' parents hid him for three months after he was born" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### had grown up

"had become an adult"

#### refused to be called

This can be stated in active form. AT: "refused to allow people to call him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the disgrace of following Christ

This can be reworded so that the abstract noun "disgrace" is express as the verb "disrespect." AT: "the experience of people disrespecting him because he did what Christ would want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### following Christ

Obeying Christ is spoken of as if it were following him down a path. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### fixing his eyes on his reward

Fully concentrating on achieving a goal is spoken of as if a person were staring at an object and refusing to look away. AT: "doing what he knew would earn him a reward in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimemonth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimemonth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disgrace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]

### Hebrews 11:27

#### he endured as if he were seeing the one who is invisible

Moses is spoken of as if he saw God, who is invisible. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the one who is invisible

"the one no one can see"

#### he kept the Passover and the sprinkling of the blood

This was the first Passover. Moses kept it by obeying God's commands concerning the Passover and by commanding the people to obey them every year. AT: "he commanded the people to obey God's commands concerning the Passover and to sprinkle blood on their doors" or "he established the Passover and the sprinkling of blood"

#### the sprinkling of the blood

This refers to God's command to the Israelites to kill a lamb and spread its blood on the doorposts of every house where Israelites lived. This would prevent the destroyer from harming their firstborn sons. This was one of the Passover commands. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### should not touch

Here "touch" refers to harming or to killing someone. AT: "would not harm" or "would not kill" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destroyer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destroyer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Hebrews 11:29

#### General Information:

Here the first word "they" refers to the Israelites, the second "they" refers to the Egyptians, the third "they" refers to the walls of Jericho.

#### they passed through the Sea of Reeds

"the Israelites passed through the Sea of Reeds"

#### they were swallowed up

This can be stated in active form. AT: "the water swallowed up the Egyptians" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they were swallowed up

The water is spoken of as if it were an animal. AT: "the Egyptians drowned in the water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### they had been circled around for seven days

This can be stated in active form. AT: "the Israelites had marched around them for seven days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### seven days

"7 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### had received the spies in peace

"had peacefully received the spies"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rahab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Hebrews 11:32

#### Connecting Statement:

The writer continues to speak of what God did for the ancestors of the people of Israel.

#### What more can I say?

The author uses a question to emphasize that there are many examples that he could have quoted. This can be expressed as a statement. AT: "And there are many more examples." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the time will fail me

"I will not have enough time"

#### Barak

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### It was through faith that they

Here "they" does not mean that each person listed in 11:32 did all the things the author is about to mention. The author means in general these are the kinds of things that those with faith were able to do. AT: "It was through faith that men like these"

#### they conquered kingdoms

Here "kingdoms" refers to the people who lived there. AT: "they defeated the people of foreign kingdoms"

#### They stopped the mouths of lions, extinguished the power of fire, escaped the edge of the sword

These are some of the ways God saved believers from death. AT: "Lions did not eat them, fire did not burn them, their enemies did not kill them. They" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### were healed of illnesses

This can be stated in active form. AT: "received healing from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### became mighty in battle, and defeated

"and they became mighty in battle and defeated"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samuel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samuel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/quench.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/quench.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]

### Hebrews 11:35

#### Women received back their dead by resurrection

This can be restated to remove the abstract noun "resurrection." The word "dead" is a nominal adjective. It can be stated as a verb. AT: "Women received back alive those who had died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### Others were tortured, not accepting release

It is implied that their enemies would have released them from prison under certain conditions. This can be stated in active form. AT: "Others accepted torture rather than release from prison" or "Others allowed their enemies to torture them rather than doing what their enemies required of them in order to release them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### tortured

made to suffer great mental or physical pain

#### a better resurrection

Possible meanings are 1) these people will experience a better life in heaven than what they experienced in this world or 2) these people will have a better resurrection than those who did not have faith. Those with faith will live forever with God. Those without faith will live forever separated from God.

#### Others had testing in mocking and whippings ... They were stoned. They were sawn in two. They were killed with the sword

These can be stated in active form. AT: "People mocked and whipped others ... People threw stones at others. People sawed others in two. People killed others with the sword" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Others had testing in mocking and whippings, and even chains and imprisonment

This can be reworded so that the abstract nouns are expressed as verbs. AT: "God tested others by allowing their enemies to mock and whip them and even put them in chains and imprison them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### went about

"went from place to place" or "lived all the time"

#### in sheepskins and goatskins

"wearing only the skins of sheep and goats"

#### They were destitute

"They had nothing" or "They were very poor"

#### The world was not worthy

Here "world" refers to the people. AT: "The people of this world were not worthy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### caves, and in the holes in the ground

"and caves, and some lived in holes in the ground"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Hebrews 11:39

#### Although all these people were approved by God because of their faith, they did not receive the promise

This can be stated in active form. AT: "God honored all these because of their faith, but they did not themselves receive what God had promised" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the promise

This expression stands for "what God had promised them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that without us, they would not be made perfect

This can be stated in positive and active form. AT: "in order that God would perfect us and them together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]

### Hebrews 11:intro

#### Hebrews 11 General Notes ####

####### Structure and formatting #######

Many people refer to this chapter as the "Hall of Fame of Faith." This is because it chronicles the people in history with the greatest faith in God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]) 

Having contrasted Christianity with Judaism, the author now begins to show the continuity between the two. In both the old and new covenants, God required faith. 

####### Other possible translation difficulties in this chapter #######

######## Faith ########
This chapter gives a definition of the biblical concept of faith. The translator's language may not have a word that directly corresponds to this definition. It is common for a language to lack a word that directly corresponds to a biblical word or concept. 

##### Links: #####

* __[Hebrews 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Hebrews 12

### Hebrews 12:01

#### Connecting Statement:

Because of this great number of Old Testament believers, the author talks of the life of faith that believers should live with Jesus as their example.

#### General Information:

The words "we" and "us" refer to the author and his readers. The word "you" is plural and here refers to the readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### we are surrounded by such a large cloud of witnesses

The writer speaks about the Old Testament believers as if they were a cloud that surrounded the present-day believers. This can be stated in active form. AT: "such a large cloud of witnesses surrounds us" or "there are so many examples of faithful people about whom we learn in the scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### witnesses

Here "witnesses" refers to the Old Testament believers in chapter 11 who lived before the race of faith that believers now run.

#### let us lay aside every weight and easily entangling sin

Here "weight" and "easily entangling sin" are spoken of as if a person could take them off himself and put them down. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### every weight

Attitudes or habits that keep believers from trusting and obeying God are spoken of as if they were loads that would make it difficult for a person to carry while running. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### easily entangling sin

Sin is spoken of as if it were a net or something else that can trip people up and make them fall. AT: "sin that makes obeying God difficult" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let us patiently run the race that is placed before us

Following Jesus is spoken of as if it were running a race. AT: "Let us continue obeying what God has commanded us, just like a runner keeps going until the race is over" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the founder and perfecter of the faith

Jesus gives us faith and makes our faith perfect by causing us to reach our goal. AT: "creator and finisher of our faith" or "the one who enables us to have faith from beginning to end"

#### For the joy that was placed before him

The joy that Jesus would experience is spoken of as if God the Father had placed it before him as a goal to reach. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### despised its shame

This means he was not concerned about the shame of dying on a cross.

#### sat down at the right hand of the throne of God

To sit at the "right hand of God" is a symbolic action of receiving great honor and authority from God. See how you translated a similar phrase in [Hebrews 1:3](../01/01.md). AT: "sat down at the place of honor and authority beside the throne of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### weary in your hearts

Here "hearts" represents a person's thoughts and emotions. AT: "discouraged" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]

### Hebrews 12:04

#### Connecting Statement:

The author of Hebrews has been comparing the Christian life to a race.

#### You have not yet resisted or struggled against sin

Here "sin" is spoken of as if it were a person whom someone fights in a battle. AT: "You have not yet had to endure attacks of sinners" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### to the point of blood

Resisting opposition so much that one dies for it is spoken of as if one reached a certain place where he would die. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### of blood

Here "blood" refers to death. AT: "of death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the encouragement that instructs you

Old Testament scripture is spoken of as if it were a person who could encourage others. AT: "what God has instructed you in the scriptures to encourage you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### as sons ... My son ... every son

These refer to everyone who belongs to God whether male or female. AT: "as children ... My child ... every child" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### My son ... corrected by him

Here the author is quoting from the book of Proverbs in the Old Testament.

#### do not think lightly of the Lord's discipline, nor grow weary

This can be stated in positive form. AT: "take it very seriously when the Lord disciplines you, and do not grow weary" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### nor grow weary

"and do not become discouraged"

#### you are corrected by him

This can be stated in active form. AT: "he corrects you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### every son whom he receives

"everyone whom he accepts as his child"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Hebrews 12:07

#### Endure suffering as discipline

"Understand that during suffering God teaches us discipline"

#### God deals with you as with sons

This compares God disciplining his people to a father disciplining his sons. You can state clearly the understood information. AT: "God deals with you the same way a father deals with his sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### sons ... son

All occurrences of these words may be stated to include males and females. AT: "children ... child" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### what son is there whom his father does not discipline?

The author makes the point throught this question that every good father disciplines his children. This can be expressed as a statement. AT: "every father disciplines his children!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### But if you are without discipline, which all people share in

You can restate the abstract noun "discipline" as the verb "disciplining." AT: "So if you have not experienced God disciplining you like he disciplines all his children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### then you are illegitimate and not his sons

Those whom God does not discipline are spoken of as if they are sons born to a man and a woman who are not married each other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Hebrews 12:09

#### How much more should we submit to the Father of spirits and live!

The author uses an exclamation to emphasize that we should obey God the Father. This can be expressed as a statement. AT: "Therefore even more so, we should obey the Father of spirits and live." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### the Father of spirits

This idiom contrasts with "fathers in the flesh." AT: "our spiritual Father" or "our Father in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### and live

"so that we will live"

#### so that we can share in his holiness

This metaphor speaks of "holiness" as if it were an object that can be shared among people. AT: "so that we may become holy as God is holy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### peaceful fruit

"Fruit" here is a metaphor for "result" or "outcome." AT: "peace is the result" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) 

#### fruit of righteousness

The word "fruit" here is a metaphor for the result of something. AT: "the result of right standing" or "the outcome of right behavior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who have been trained by it

"who have been trained by discipline." The discipline or correction done by the Lord is spoken of as if it were the Lord himself. This can be stated in active form. AT: "whom God has trained by disciplining them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Hebrews 12:12

#### strengthen your hands that hang down and your weak knees. Make straight paths for your feet

Possibly this continues the metaphor about the race in [Hebrews 12:1](./01.md). It is in this way that the author speaks about living as Christians and helping others. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### straight paths

Living so as to honor and please God is spoken of as if it were a straight path to follow. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### what is lame will not be sprained

In this metaphor of running a race, "lame" represents another person in the race who is hurt and wants to quit. This, in turn, represent the Christians themselves. AT: "whoever is weak and wants to quit will not sprain his ankle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will not be sprained

Someone who stops obeying God is spoken of as if he injured his foot or ankle on a path. This can be stated in active form. AT: "will not sprain his ankle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### rather be healed

This can be stated in active form. AT: "instead become strong" or "instead God will heal him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Hebrews 12:14

#### General Information:

The man Esau, who was told about in the writings of Moses, refers to Isaac's first son and Jacob's brother.

#### Pursue peace with everyone

Here the abstract noun "peace" is spoken of as if it were something that a person must chase after and can be translated with an adverb. AT: "Try to live peacefully with everyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### also the holiness without which no one will see the Lord

This can be expressed as a positive encouragement. AT: "also work hard to be holy, because only holy people will see the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### also the holiness

You can state clearly the understood information. AT: "also pursue the holiness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### no one lacks God's grace

"no one receives God's grace and then lets go of it" or "no one rejects God's grace after first trusting in him"

#### that no root of bitterness grows up to cause trouble, so that many do not become polluted by it

Hateful or resentful attitudes are spoken of as if they were a plant bitter to the taste. AT: "that no one becomes like a bitter root, which when it grows causes trouble and harms many people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he was rejected

This can be stated in active form. AT: "his father, Isaac, refused to bless him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### because he found no opportunity for repentance

The abstract noun "repentance" can be translated with a verbal phrase. AT: "because it was not possible for him to repent" or "because it was not possible for him to change his decision" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### even though he sought it with tears

Here "he" refers to Esau.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/esau.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/birthright.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/birthright.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]

### Hebrews 12:18

#### Connecting Statement:

The author gives a contrast between what believers in Moses' time had while living under the law and what present day believers have after coming to Jesus under the new covenant. He illustrates the experience of the Israelites by describing how God appeared to them at Mount Sinai.

#### General Information:

The words "you" and "You" refer to the Hebrew believers to whom the author wrote. The word "they" refers to people of Israel after Moses led them out of Egypt. The first quotation comes from the writings of Moses. God reveals in this passage in Hebrews that Moses said he shook at seeing the mountain.

#### For you have not come to a mountain that can be touched

The implicit information can be stated explicitly. AT: "For you have not come, as the people of Israel came, to a mountain that can be touched" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### that can be touched

This means that believers in Christ have not come to a physical mountain like Mount Sinai that a person can touch or see. This can be stated in active form. AT: "that a person can touch" or "that people can perceive with their senses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You have not come to a trumpet blast

"You have not come to a place where there is the loud sound of a trumpet"

#### nor to a voice that speaks words whose hearers begged that not another word be spoken to them

Here "voice" refers to someone speaking. The phrase "be spoken" can be stated in active form. AT: "or where God was speaking in such a way that those who heard him begged him not to speak another word to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### what was commanded

This can be stated in active form. AT: "what God commanded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it must be stoned

This can be stated in active form. AT: "you must stone it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tremble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tremble.md)]]

### Hebrews 12:22

#### General Information:

The man Abel was the son of the first man and woman, Adam and Eve. Cain, also their son, murdered Abel.

#### Mount Zion

The writer speaks of Mount Zion, the temple mount in Jerusalem, as if it were heaven itself, the residence of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### tens of thousands of angels

"an uncountable number of angels"

#### the firstborn

This speaks of believers in Christ as if they were firstborn sons. This emphasizes their special place and privilege as God's people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### registered in heaven

"whose names are written in heaven." This can be stated in active form. AT: "whose names God has written in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the mediator of a new covenant

This means Jesus caused the new covenant between God and humans to exist. See how you translated this phrase in [Hebrews 9:15](../09/13.md).

#### who have been made perfect

This can be stated in active form. AT: "whom God has made perfect" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the sprinkled blood that speaks better than Abel's blood

The blood of Jesus and the blood of Abel are spoken of as if they were people calling out. AT: "the sprinkled blood of Jesus that says better things than the blood of Abel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### blood

Here "blood" stands for Jesus' death, as Abel's blood stands for his death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perfect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mediator.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abel.md)]]

### Hebrews 12:25

#### Connecting Statement:

Having contrasted the Israelites' experience at Mount Sinai with the believers' experience after Christ died, the writer reminds believers that they have the same God who warns them today. This is the fifth main warning given to believers.

#### General Information:

This quotation is from the prophet Haggai in the Old Testament. The word "you" continues to refer to believers. The word "we" continues to refer to the writer and the readers who are believers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### you do not refuse the one who is speaking

This can be stated in positive form. AT: "you pay attention to the one who is speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### if they did not escape

The implicit information can be stated explicitly. AT: "if the people of Israel did not escape judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the one who warned them on earth

Possible meanings are 1) "Moses, who warned them here on earth" or 2) "God, who warned them at Mount Sinai"

#### if we turn away from the one who is warning

Disobeying God is spoken of as if a person were changing direction and walking away from him. AT: "if we disobey the one who is warning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his voice shook the earth

"when God spoke, the sound of his voice caused the earth to shake"

#### shook ... shake

Use the word for what an earthquake does in moving the ground. This refers back to [Hebrews 12:18-21](./18.md) and what happened when the people saw the mountain where Moses received the law from God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Hebrews 12:27

#### General Information:

Here the quotation from the prophet Haggai is repeated from the previous verse.

#### mean the removal of those things that can be shaken, that is, of the things

The abstract noun "removal" can be translated with the verb "remove." This can be stated in active form. AT: "mean that God will remove the things that he can shake, that is, the things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### shaken

Use the word for what an earthquake does in moving the ground. This refers back to [Hebrews 12:18-21](./18.md) and what happened when the people saw the mountain where Moses received the law from God. See how you translated "shook" and "shake" in [Hebrews 12:26](./25.md).

#### that have been created

This can be stated in active form. AT: "that God has created" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the things that cannot be shaken

This can be stated in active form. AT: "the things that do not shake" or "the things that cannot shake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### receiving a kingdom

You can add the words "because we are" to make clear the logical connection between this statement and the next statement. AT: "because we are receiving a kingdom" or "because God is making us members of his kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-connectingwords.md)]])

#### that cannot be shaken

This can be stated in active form. AT: "that does not shake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### let us be grateful

"let us give thanks"

#### with reverence and awe

The words "reverence" and "awe" share similar meanings and emphasize the greatness of reverence due to God. AT: "with great respect and dread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### our God is a consuming fire

God is spoken of here as if he were a fire that can burn up anything. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reverence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reverence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Hebrews 12:intro

#### Hebrews 12 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 12:5-6, which is quoted from the OT.

####### Special concepts in this chapter #######

######## Discipline ########
God disciplines his children in the same way parents discipline or correct their children. This imagery is used because discipline is out of love. Different cultures may have different standards of parental discipline, some of which may be unbiblical. God's discipline is the way he uses different circumstances to correct his children and to bring them to repentance. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/discipline.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Important figures of speech in this chapter #######

Many different figures of speech are used. They are usually more common in poetic writings than in narrative, but the author uses them as a way to teach people. 

##### Links: #####

* __[Hebrews 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Hebrews 13

### Hebrews 13:01

#### Connecting Statement:

In this closing section, the author gives specific instructions to believers on how they are supposed to live.

#### Let brotherly love continue

"Continue to show your love for other believers as you would for a member of your family"

#### Do not forget

This can be stated in positive form. AT: "Be sure to remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### hospitality for strangers

"to welcome and show kindness to strangers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Hebrews 13:03

#### as if you were bound with them

This can be stated in active form. AT: "as if you were tied up along with them" or "as if you were in prison with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who are mistreated

This can be stated in active form. AT: "whom others are mistreating" or "who are suffering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as if you also were them in the body

This phrase encourages believers to think about other people's suffering as they would think about their own suffering. AT: "as if you were the one suffering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Let marriage be respected by everyone

This can be stated in active form. AT: "Men and women who are married to each other must respect each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Let the marriage bed be pure

This refers to the act of sexual union as if it were only the bed of a married couple. AT: "Let husbands and wives honor their marriage relationship to one another and not sleep with other people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]

### Hebrews 13:05

#### Let your conduct be free from the love of money

"Free from" here is an idiom for the ability to live without being controlled by something. AT: "Live in such a way that you are not controlled by a desire for money"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Be content

"Be satisfied"

#### The Lord is my helper ... do to me

This is a quotation from the book of Psalms in the Old Testament. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will not be afraid. What can a man do to me?

The author uses a question to emphasize that he does not fear people because God is helping him. Here "man" means any person in general. AT: "I will not fear what any person can do to me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Hebrews 13:07

#### those who spoke God's word to you

"God's word" here is a metonym for the message from God. AT: "those who instructed you in what God has said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the result of their conduct

"the outcome of the way they behave"

#### Imitate their faith

Here the trust in God and the way of life led by these leaders are spoken of as "their faith." AT: "Trust and obey God in the same way they do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### is the same yesterday, today, and forever

Here "yesterday" means all times in the past. AT: "is the same in the past, the present, and in the future forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/imitate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/imitate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Hebrews 13:09

#### General Information:

This section refers to animal sacrifices made by believers in God in Old Testament times, which covered their sins temporarily until the death of Christ came about.

#### Do not be carried away by various strange teachings

Being persuaded by various teachings is spoken of as if a person were being carried away by a force. This can be stated in active form. AT: "Do not let others persuade you to believe their various strange teachings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### various strange teachings

"many, different teachings that are not the good news we told you"

#### it is good that the heart should be strengthened by grace, not by foods that do not help those who walk by them

This can be stated in active form. AT: "we become stronger when we think of how God has been kind to us, but we do not become stronger by obeying rules about food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the heart should be strengthened

"Heart" here is a metonym for "thoughts and intentions." AT: "our thoughts and intentions should be strengthened by grace, not by foods that do not help those who walk by them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### foods

Here "foods" stands for rules about food. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### those who walk by them

Living is spoken of as if it were walking. AT: "those who live by them" or "those who regulate their lives by them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### We have an altar

Here "altar" stands for "place of worship." It also stands for the animals that the priests in the old covenant sacrificed, from which they took meat for themselves and their families. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the blood of the animals killed for sins is brought by the high priest into the holy place

This can be stated in active form. AT: "the high priest brings into the holy place the blood of the animals that the priests killed for sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### while their bodies are burned

This can be stated in active form. AT: "while the priests burn the animals' bodies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### outside the camp

"away from where the people lived"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]

### Hebrews 13:12

#### Connecting Statement:

There is a comparison here between Jesus' sacrifice and the tabernacle sacrifices of the Old Testament.

#### So

"In the same way" or "Because the bodies of the sacrifices were burned outside the camp" ([Hebrews 13:11](./09.md))

#### outside the city gate

This stands for "outside the city." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Let us therefore go to him outside the camp

Obeying Jesus is spoken of as if a person were leaving the camp to go out where Jesus is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bearing his shame

Disgrace is spoken of as if it were an object that had to be carried in one's hands or on one's back. AT: "while allowing others to insult us just like people insulted him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### looking for

"waiting for"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]

### Hebrews 13:15

#### sacrifices of praise

Praise is spoken of as if it were a sacrifice of animals or incense. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### praise that is the fruit of lips that acknowledge his name

"Fruit" here is an idiom for "result" or "outcome." AT: "praise that is the result of people who acknowledge his name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### lips that acknowledge his name

Here “lips” represents people who speak.  AT: “the lips of those who acknowledge his name” or “those who acknowledge his name” (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### his name

A person's name represents that person. AT: "him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Let us not forget doing good and helping one another

This can be stated in positive form. AT: "Let us always remember to do good and help others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### with such sacrifices

Doing good and helping others is spoken of as if they were sacrifices on an altar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### keep watch over your souls

The believers' souls, that is, the believers' spiritual well-being, are spoken of as if they were objects or animals that guards could keep watch over. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### not with groaning

Here "groaning" stands for sadness or grief. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acknowledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/submit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/submit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/groan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/groan.md)]]

### Hebrews 13:18

#### Connecting Statement:

The author closes with a blessing and greetings.

#### Pray for us

Here "us" refers to the author and his companions, but not to the readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### we are persuaded that we have a clean conscience

Here "clean" stands for being free from guilt. AT: "we are certain that we have no guilt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that I will be returned to you sooner

This can be stated in active form. AT: "that God will quickly remove the things that stop my coming to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md)]]

### Hebrews 13:20

#### Now

This marks a new section of the letter. Here the author praises God and gives a final prayer for his readers.

#### brought back from the dead the great shepherd of the sheep, our Lord Jesus

"raised the great shepherd of the sheep, our Lord Jesus, to life"

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To raise someone from among them speaks of causing that person to become alive again.

#### the great shepherd of the sheep

Christ in his role of leader and protector of those who believe in him is spoken of as if he were a shepherd of sheep. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### by the blood of the eternal covenant

Here "blood" stands for the death of Jesus, which is the basis for the covenant that will last forever between God and all believers in Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### equip you with everything good to do his will

"give you every good thing you need in order to do his will "make you capable of doing every good thing according to his will"

#### working in us

The word "us" refers to the author and the readers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### to whom be the glory forever

"whom all people will praise forever"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Hebrews 13:22

#### Now

This marks a new section of the letter. Here the author gives his final comments to his audience.

#### brothers

This refers to all the believers to whom he is writing whether male or female. AT: "fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### bear with the word of encouragement

"patiently consider what I have just written to encourage you"

#### the word of encouragement

Here "word" stands for a message. AT: "the encouraging message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has been set free

This can be stated in active form. AT: "is no longer in prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//encourage.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/timothy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]

### Hebrews 13:24

#### Those from Italy greet you

Possible meanings are 1) the author is not in Italy, but there is a group of believers with him who have come from Italy or 2) the author is in Italy while writing this letter.

#### Italy

This is the name of a region at that time. Rome was the then-capital city of Italy. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Hebrews 13:intro

#### Hebrews 13 General Notes ####

####### Structure and formatting #######

This chapter continues a series of exhortations to Christians that began in chapter 12. These commands are not always connected to each other, so the translator should not feel obliged to make smooth transitions between subjects.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 13:6, which is quoted from the OT.

####### Special concepts in this chapter #######

######## "Welcome angels" ########
The exact meaning of this phrase is unknown. It is possibly a reference to Abraham entertaining angels (Genesis 18). The Greek word for "angels" can also be translated as "messengers." This would give the phrase the meaning that any stranger may be a messenger or servant of God, so hospitality should be shown to them.   

##### Links: #####

* __[Hebrews 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | __


## Hebrews front

### Hebrews front:intro

#### Introduction to Hebrews ####

##### Part 1: General Introduction #####

####### Outline of the Book of Hebrews #######

1. Jesus is superior to God's prophets and angels (1:1-4:13)
1. Jesus is superior to the priests who serve in the temple in Jerusalem (4:14-7:28)
1. Jesus' ministry is superior to the old covenant that God made with his people (8:1-10:39)
1. What faith is like (11:1-40)
1. Encouragement to be faithful to God (12:1-29)
1. Concluding encouragements and greetings (13:1-25)

####### Who wrote the Book of Hebrews? #######

No one knows who wrote Hebrews. Scholars have suggested several different people who could possibly be the author. Possible authors are Paul, Luke, and Barnabas. The date of writing is also not known. Most scholars think it was written before A.D. 70. Jerusalem was destroyed in A.D. 70, but the writer of this letter spoke about Jerusalem as if it had not yet been destroyed. 

####### What is the Book of Hebrews about? #######

In the Book of Hebrews, the author shows that Jesus fulfilled Old Testament prophecies. The author did this in order to encourage the Jewish Christians and to explain that Jesus is better than anything that the old covenant had to offer. Jesus is the perfect High Priest. Jesus was also the perfect sacrifice. Animal sacrifices became useless because Jesus' sacrifice was once and for all time. Therefore, Jesus is the one and only way for people to be accepted by God.

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Hebrews." Or they may choose a clearer title, such as "The Letter to the Hebrews" or "A Letter to the Jewish Christians." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### Can readers understand this book without knowing about the sacrifices and the work of the priests required in the Old Testament? #######

It would be very difficult for readers to understand this book without understanding these matters. Translators might consider explaining some of these Old Testament concepts in notes or in an introduction to this book.

####### How is the idea of blood used in the Book of Hebrews? #######

Beginning in [Hebrews 9:7](../09/06.md), the idea of blood is often used as metonymy to represent the death of any animal that was sacrificed according to God's covenant with Israel. The author also used blood to represent the death of Jesus Christ. Jesus became the perfect sacrifice so that God would forgive people for sinning against him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

Beginning in [Hebrews 9:19](../09/06.md), the author used the idea of sprinkling as a symbolic action. Old Testament priests sprinkled the blood of the animals sacrificed. This was a symbol of the benefits of the animal's death being applied to the people or to an object. This showed that the people or the object was acceptable to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]]) 

##### Part 3: Important Translation Issues #####

####### How are the ideas of "holy" and "sanctify" represented in Hebrews in the ULB? #######

The scriptures use such words to indicate any one of various ideas. For this reason, it is often difficult for translators to represent them well in their versions. In translating into English, the ULB uses the following principles:

* Sometimes the meaning in a passage implies moral holiness. Especially important for understanding the gospel is the fact that God views Christians as sinless because they are united to Jesus Christ. Another related fact is that God is perfect and faultless. A third fact that Christians are to conduct themselves in a blameless, faultless manner in life. In these cases, the ULB uses "holy," "holy God," "holy ones," or "holy people."
* Sometimes the meaning indicates a simple reference to Christians without implying any particular role filled by them. In these cases, the ULB uses "believer" or "believers." (See: 6:10; 13:24)
* Sometimes the meaning implies the idea of someone or something set apart for God alone. In these cases, the ULB uses "sanctify," "set apart," "dedicated to," or "reserved for." (See: 2:11: 9:13; 10:10, 14, 29; 13:12)

The UDB will often be helpful as translators think about how to represent these ideas in their own versions.

####### What are the major issues in the text of the Book of Hebrews? #######

The following are the most significant textual issues in the Book of Hebrews:

* "and you have put him over the works of your hands." (2:7) The ULB, UDB, and most modern versions do not read this way. Some older versions do.
* "those who did not unite in faith with those who obeyed" (4:2). The ULB, UDB, and some other versions read this way. Other versions read, "those who heard it without joining faith to it." If there are other versions in the region, translators might consider following their reading.
* "Christ came as a high priest of the good things that have come." (9:11) The ULB, UDB, and most other modern versions read this way. Some other versions read, "Christ came as a high priest of the good things that are to come." If there are other versions in the region, translators might consider following their reading.
* "on those who were prisoners" (10:34). The ULB, UDB, and most other modern versions read this way. Some older versions read, "of me in my chains."
* "They were stoned. They were sawn in two. They were killed with the sword." (11:37) The ULB, UDB, and most other modern versions read this way. Some older versions read, "They were stoned. They were sawn in two. They were tempted. They were killed with the sword."
* "If even an animal touches the mountain, it must be stoned." (12:20) The ULB, UDB, and most other modern versions read this way. Some older versions read, "If even an animal touches the mountain, it must be stoned or shot with an arrow."

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

