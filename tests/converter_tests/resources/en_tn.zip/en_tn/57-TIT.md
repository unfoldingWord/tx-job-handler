# <a id="tit"/>Titus

## Titus 01

### Titus 01:01

#### for the faith of

to strengthen the faith of

#### that agrees with godliness

"that is suitable for honoring God"

#### before all the ages of time

"before time began"

#### At the right time

"At the proper time"

#### he revealed his word

Paul speaks of God's message as if it were an object that could be visibly shown to people. AT: "He caused me to understand his message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he trusted me to deliver

"Deliver" here is a metaphor for "bring." TA: "He trusted me to bring" or "he gave me the responsibility to preach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### God our savior

"God, who saves us"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/paul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]

### Titus 01:04

#### a true son

Though Titus was not Paul's biological son, they share a common faith in Christ. Thus, in Christ, Paul considers Titus as his own son. AT: "you are like a son to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### our common faith

Paul expresses the same faith in Christ that they both share. AT: "the teachings that we both believe"

#### Grace and peace

This was a common greeting Paul used. You can state clearly the understood information. AT: "May you experience kindness and peace within" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Christ Jesus our savior

"Christ Jesus who is our savior"

#### For this purpose

"This is the reason"

#### I left you in Crete

"I told you to stay in Crete"

#### that you might set in order things not yet complete

"so that you would finish arranging things that needed to be done"

#### ordain elders

"appoint elders" or "designate elders"

#### elders

In the early Christian churches, Christian elders gave spiritual leadership to the assemblies of believers.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/titus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/titus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/crete.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/crete.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Titus 01:06

#### Connecting Statement:

Having told Titus to ordain elders in every city on the island of Crete, Paul gives the requirements for elders.

#### An elder must be without blame, the husband

To be "without blame" is to be known as a person who does not do bad things. AT: "An elder must not have a bad reputation and must be the husband"

#### the husband of one wife

This means that he has only one wife, that is, he does not have any other wives or concubines. It may also imply that he does not commit adultery and that he has not divorced a previous wife. AT: "a man who has only one woman" or "a man who is faithful to his wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### faithful children

Possible meanings are 1) children who believe in Jesus or 2) children who are trustworthy.

#### undisciplined

"rebellious" or "failing to follow rules"

#### overseer

This is another name for the same position of spiritual leadership that Paul referred to as "elder" in 1:6.

#### God's household manager

Paul speaks of the church as if it were God's household and the overseer as if he were a servant in charge of managing the household. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### not addicted to wine

"not an alcoholic" or "not one who drinks much wine"

#### not a brawler

"not one who is violent" or "not one who likes to fight"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/manager.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/manager.md)]]

### Titus 01:08

#### Instead

Paul is changing his argument from what an elder is not to be to what an elder is to be.

#### a friend of what is good

"a person who loves what is good"

#### hold tightly to

Paul speaks of devotion to the Christian faith as if it were grasping the faith with one's hands. AT: "be devoted to" or "know well" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### good teaching

He must teach what is true about God and other spiritual matters.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]

### Titus 01:10

#### Connecting Statement:

Because of those that would oppose God's word, Paul gives Titus reasons to preach God's word and warns him about false teachers.

#### rebellious people

These are rebellious people who oppose Paul's gospel message.

#### empty talkers and deceivers

This phrase describes the rebellious people mentioned in the previous phrase. Here "empty" is a metaphor for useless, and "empty talkers" are people who say useless or foolish things. AT: "people who say useless things and deceive others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### those of the circumcision

This refers to the Christian Jews who taught that men must be circumcised in order to follow Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### It is necessary to stop them

"They must be prevented from spreading their teachings" or "They must be stopped from influencing others by their words"

#### what they should not teach

These are things that are not proper to teach regarding Christ and the Law because they are not true.

#### for shameful profit

This refers to profit that people make by doing things that are not honorable.

#### are upsetting whole families

"are ruining whole families." The issue was that they were upsetting families by destroying their faith. This may have caused the members of the families to argue with one another.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Titus 01:12

#### One of their own prophets

"A prophet from Crete itself" or "A Cretan that they themselves consider to be a prophet"

#### Cretans are always liars

"Cretans lie all the time." This is an exaggeration that means many Cretans lie a lot. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### evil beasts

This metaphor compares the Cretans to dangerous wild animals. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Therefore, correct them severely

"You must use strong language that the Cretans will understand when you correct them"

#### so that they may be sound in the faith

"so they will have a healthy faith" or "so their faith may be true"

#### Jewish myths

This refers to the false teaching of the Jews.

#### turn away from the truth

Paul speaks of the truth as if it were an object that one could turn away from or avoid. AT: "reject the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/crete.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/crete.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Titus 01:15

#### To those who are pure, all things are pure

"If people are pure on the inside, everything they do will be pure"

#### To those who are pure

"To those who are acceptable to God"

#### to those who are corrupt and unbelieving, nothing is pure

Paul speaks of sinners as if they were physically dirty. AT: "if people are morally defiled and do not believe, they cannot do anything pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they deny him by their actions

"how they live proves that they do not know him"

#### detestable

"disgusting"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/conscience.md)]]

### Titus 01:intro

#### Titus 01 General Notes ####

####### Structure and formatting #######

Titus [Titus 1:1-5](./01.md) forms a formal introduction to this letter. It was a common type of introduction for a letter in the ancient Near East.

Titus [Titus 1:6-9](./06.md) gives the qualifications for the office of elder. 1 Timothy 3 also gives these qualifications. 

####### Special concepts in this chapter #######

######## Overseer and Deacons ########

There is some disagreement over the titles used for church leaders. Some titles include overseer, elder, pastor, and bishop.

####### Other possible translation difficulties in this chapter #######

######## How things ought to be ########
There are several words in this chapter (should, may, must) that indicate that there is some kind of requirement or obligation. These verbs have different levels of force attached to them. The subtle differences may be difficult to translate. The UDB has chosen to translate these verbs more generically. 

##### Links: #####

* __[Titus 01:01 Notes](./01.md)__
* __[Titus intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Titus 02

### Titus 02:01

#### Connecting Statement:

Paul continues giving Titus reasons to preach God's word, and explains how the older men, older women, young men, and slaves or servants should live as believers.

#### But you, speak what fits

Paul implies what is in contrast. AT: "But you, Titus, in contrast with the false teachers, be sure to say those things that fit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### with faithful instruction

"with sound doctrine" or "with correct teachings"

#### temperate

"sober-minded" or "self-controlled"

#### sensible

"in control of their desires"

#### sound in faith, in love, and in perseverance

Here the word "sound" means to be firm and unwavering. The abstract nouns "faith," "love," and "perseverance" can be stated as verbs. AT: "and they must firmly believe the true teachings about God, truly love others, and continually serve God even when things are difficult" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perseverance.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/perseverance.md)]]

### Titus 02:03

#### likewise

"in the same way" or "also"

#### slanderers

This word refers to people who say bad things about other people whether they are true or not.

#### or being slaves to much wine

A person who cannot control themselves and drinks too much wine is spoken of as if the person were a slave to the wine. This can be stated in active form. AT: "and not drinking too much wine" or "and not addicted to wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### so that God's word may not be insulted

"Word" here is a metonym for "message," which in turn is a metonym for God himself. This can be stated in active form. AT: "so that no one insults God's word" or "so that no one insults God by saying bad things about his message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]

### Titus 02:06

#### In the same way

Titus was to train the younger men like he was to train the older people.

#### present yourself as

"show yourself to be"

#### an example of good works

"an example of one who does right and proper things"

#### so that anyone who opposes you may be ashamed

This presents an imaginary situation where someone opposes Titus and then becomes ashamed for having done so. AT: "so that if anyone opposes you, he may be ashamed" or "so that if people oppose you, they may be ashamed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

### Titus 02:09

#### their masters

"their own masters"

#### in everything

"in every situation" or "always"

#### please them

"make their masters happy" or "satisfy their masters"

#### demonstrate all good faith

"show that they are worthy of their masters' trust"

#### in every way

"in everything they do"

#### they may bring credit to the teaching about God our Savior

"they may make the teaching about God our Savior attractive" or "they may cause people to understand that the teaching about God our Savior is good"

#### God our Savior

"our God who saves us"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]

### Titus 02:11

#### Connecting Statement:

Paul encourages Titus to look for Jesus' coming and remember his authority through Jesus.

#### the grace of God has appeared ... trains us

Paul speaks of the grace of God as if it were a person who goes to other people and trains them to live holy lives. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### trains us to reject godlessness

"teaches us not to dishonor God"

#### worldly passions

"strong desires for the things of this world" or "strong desires for sinful pleasures"

#### in this age

"while we live in this world" or "during this time"

#### we look forward to receiving

"we wait to welcome"

#### our blessed hope, the appearance of the glory of our great God and Savior Jesus Christ

Here "glory" represents Jesus himself who will appear gloriously. AT: "the good thing for which we hope, that is, the glorious appearance of our great God and Savior Jesus Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goldy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Titus 02:14

#### gave himself for us

This refers to Jesus dying willingly. AT: "gave himself to die for us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to redeem us from all lawlessness

Paul speaks of Jesus as if he were setting slaves free from their evil master. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a special people

A group of people that he treasures.

#### are eager

"have a strong desire"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Titus 02:15

#### give correction with all authority

This statement can be made explicit. AT: "Correct with all authority those people who do not do these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Let no one

"Do not allow anyone to"

#### disregard you

This statement can be made explicit. AT: "refuse to listen to your words" or "refuse to respect you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Titus 02:intro

#### Titus 02 General Notes ####

####### Special concepts in this chapter #######

######## Gender roles ########

Scholars are divided over how to understand this passage in light of its historical and cultural context. Some scholars believe men and women are perfectly equal in all things (this belief is known as egalitarianism). Other scholars believe men and women were created to be distinct and to serve in different roles in marriage and the church (this belief is known as complementarianism). How one understands this issue may affect how this passage is translated.

######## Slavery ########

This passage does not condone slavery as an acceptable practice. Paul's teaching on slavery was rather radical during his time because masters were not expected to treat their slaves in such a pleasant way. Overall, Paul's focus is on living in a way pleasing to God despite the circumstances of one's life. The translator should remember that Paul is in prison when he writes these words.

##### Links: #####

* __[Titus 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Titus 03

### Titus 03:01

#### Connecting Statement:

Paul continues giving Titus instructions on how to teach the elders and people under his care in Crete.

#### Remind them to submit

"Tell our people again what they already know, to submit" or "Keep reminding them to submit"

#### submit to rulers and authorities, to obey them

"do as the political rulers and government authorities say by obeying them"

#### rulers and authorities

These words have similar meanings and are used together to include everyone who holds authority in the government.

#### be ready for every good work

"be ready to do good whenever there is opportunity"

#### revile

"speak evil of"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]

### Titus 03:03

#### For once we ourselves

"This is because we ourselves were once"

#### once

"formerly" or "at some time" or "previously"

#### we ourselves

"even we" or "we also"

#### thoughtless

"foolish" or "unwise"

#### We were led astray and enslaved by various passions and pleasures
Paul speaks of "passions and pleasures" as if they were people that could lead others astray and enslave them. Here "led astray" is a metaphor that means to cause someone to believe what is not true. Here "enslaved by various passions and pleasures" is a metaphor for not being able to control one's self. This can be stated in active form. AT: "We deceived ourselves and only did what was pleasing to us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### passions

"lusts" or "desires"

#### We lived in evil and envy

Here "evil" and "envy" are similar words for sin. AT: "We were always doing evil things and wanting what others have" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md)]])

#### We were detestable

"We caused others to hate us"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Titus 03:04

#### when the kindness of God our savior and his love for mankind appeared

Paul speaks of God's kindness and love as if they were people that came into our sight. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### by his mercy

"because he had mercy on us"

#### washing of new birth

Paul is probably speaking of God's forgiveness for sinners as if he were physically washing them. He is also speaking of sinners who become responsive to God as if they had been born again. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Titus 03:06

#### richly

"abundantly" or "generously"

#### poured the Holy Spirit on us

It is common for New Testament writers to speak of the Holy Spirit as a liquid that could be poured. AT: "gave the Holy Spirit to us generously" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### through our Savior Jesus Christ

"when Jesus saved us"

#### having been justified

This can be stated in active form. AT: "since God has declared us to be without sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### we might become heirs with the certain hope of eternal life

The people to whom God has made promises are spoken of as if they were to inherit property and wealth from a family member. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Titus 03:08

#### This message

This refers to God giving the believers the Holy Spirit through Jesus in [Titus 3:7](./06.md).

#### may be careful to engage themselves in good works

"may seek to do good works"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Titus 03:09

#### Connecting Statement:

Paul explains what Titus should avoid and how to treat those who cause contention among the believers.

#### But avoid

"So avoid" or "Therefore, avoid"

#### foolish debates

"arguments concerning unimportant matters"

#### genealogies

This is the study of family kinship relationships.

#### strife

"quarreling"

#### the law

"the law of Moses"

#### Reject anyone

"Stay away from anyone"

#### after one or two warnings

"after you have warned that person once or twice"

#### such a person

"a person like that"

#### has turned from the right way

Paul speaks of someone who makes errors as if he were leaving the path on which he had been walking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### condemns himself

"brings judgment on himself"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]

### Titus 03:12

#### Connecting Statement:

Paul closes the letter by telling Titus what to do after he appoints elders in Crete and by giving greetings from those with him.

#### When I send

"After I send"

#### Artemas ... Tychicus ... Zenas

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### hurry and come

"come quickly"

#### spend the winter

"stay for the winter"

#### Do everything you can to send

"Do not delay in sending"

#### and Apollos

"and also send Apollos"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tychicus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tychicus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/apollos.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/apollos.md)]]

### Titus 03:14

#### Connecting Statement:

Paul explains why it is important to provide for Zenas and Apollos.

#### Our people

Paul is referring to the believers in Crete.

#### that provide for urgent needs

"that enable them to help people who need important things immediately"

#### needs, and so not be unfruitful

Paul speaks of people doing good work as if they were trees bearing good fruit. This double negative means they should be fruitful or productive. AT: "needs; in this way they will be fruitful" or "needs, and so they will do good works" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Titus 03:15

#### General Information:

Paul ends his letter to Titus.

#### All those

"All the people"

#### those who love us in faith

Possible meanings are 1) "the believers who love us" or 2) "the believers who love us because we share the same belief."

#### Grace be with all of you

This was a common Christian greeting. AT: "May God's grace be with you" or "I ask that God will be gracious to all of you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Titus 03:intro

#### Titus 03 General Notes ####

####### Structure and formatting #######

This chapter appears to shift the letter's focus and gives Titus personal instructions.

[Titus 3:12-15](./12.md) forms a formal conclusion to this letter. This is a common type of conclusion for a letter in the ancient Near East.

####### Special concepts in this chapter #######

######## Genealogies ########

This is probably a reference to some group's speculation over the identification of the Messiah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]) 

##### Links: #####

* __[Titus 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | __


## Titus front

### Titus front:intro

#### Introduction to Titus ####

##### Part 1: General Introduction #####

####### Outline of the Book of Titus #######

1. Paul instructs Titus to appoint godly leaders (1:1-16)
1. Paul instructs Titus to train people to live godly lives (2:1-3:11)
1. Paul ends by sharing some of his plans and sending greetings to various believers (3:12-15)

####### Who wrote the Book of Titus? #######

Paul wrote the Book of Titus. Paul was from the city of Tarsus. He had been known as Saul in his early life. Before becoming a Christian, Paul was a Pharisee. He persecuted Christians. After he became a Christian, he traveled several times throughout the Roman Empire telling people about Jesus.

####### What is the Book of Titus about? #######

Paul wrote this letter to Titus, his fellow worker, who was leading the churches on the island of Crete. Paul instructed him about selecting church leaders. Paul also described how the believers should behave towards each other. And he encouraged them all to live in a way that pleases God. 

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "Titus." Or they may choose a clearer title, such as "Paul's Letter to Titus" or "A Letter to Titus." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### In what roles can people serve within the church? #######

There are some teachings in the Book of Titus about whether a woman or divorced man can serve in positions of leadership within the church. Scholars disagree about the meaning of these teachings. Further study on these issues may be necessary before translating this book.  

##### Part 3: Important Translation Issues #####

######## Singular and plural "you" ########
In this book, the word "I" refers to Paul. Also, the word "you" is almost always singular and refers to Titus. The exception to this is 3:15. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

####### What is the meaning of "God our Savior?" #######

This is a common phrase in this letter. Paul meant to make the readers think about how God forgave them in Christ for sinning against him. And by forgiving them he saved them from being punished when he judges all people. A similar phrase in this letter is "our great God and Savior Jesus Christ."




---

