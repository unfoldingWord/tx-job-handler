# <a id="jhn"/>John

## John 01

### John 01:01

#### In the beginning

This refers to the very earliest time before God created the heavens and the earth.

#### the Word

"Word" here is a metonym for "Jesus." Translate as "the Word" if possible. If "Word" is feminine in your language, it could be translated as "the one who is called the Word." AT: "God's Message to mankind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### All things were made through him

This can be translated with an active verb. AT: "God made all things through him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### without him there was not one thing made that has been made

This can be translated with an active verb. If your language does not permit double negatives, these words should communicate that the opposite of "all things were made through him" is false. AT: "God did not make anything without him" or "with him there was every thing made that has been made" or "God made with him every thing that God has made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 01:04

#### In him was life

Here "life" is a metaphor for causing everything to live. AT: "The one who is called the Word is the one who caused everything to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### life

Here use a general term for "life." If you must be more specific, translate as "spiritual life."

#### the life was the light of men

"Light" here is a metaphor that means God's revelation. AT: "he revealed to us the truth about God as a light reveals what is in the darkness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The light shines in the darkness, and the darkness did not overcome it

Just as darkness cannot put out light, evil people have never prevented the one who is like a light from revealing God's truth. AT: "God's revelation shows the truth even in the midst of evil people, and evil people have not been able to stop it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]]) 

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 01:06

#### testify about the light

Here "light" is a metaphor for the revelation of God in Jesus. AT: "show how Jesus is like the true light of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 01:09

#### The true light

Here light is a metaphor that represents Jesus as the one who both reveals the truth about God and is himself that truth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 01:10

#### He was in the world, and the world was made through him, and the world did not know him

"Even though he was in this world, and God created everything through him, people still did not recognize him"

#### the world did not know him

The "world" is a metonym that stands for all the people who live in the world. AT: "the people did not know who he really was" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He came to his own, and his own did not receive him

"He came to his own fellow countrymen, and his own fellow countrymen did not accept him either"

#### receive him

"accept him." To receive someone is to welcome him and treat him with honor in hopes of building a relationship with him.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]

### John 01:12

#### believed in his name

The word "name" is a metonym that stands for Jesus' identity and everything about him. AT: "believed in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he gave the right

"he gave them the authority" or "he made it possible for them"

#### children of God

The word "children" is a metaphor that represents our relationship to God, which is like children to a father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### John 01:14

#### The Word

"The Word" here is a metonym for "Jesus." AT: "God's Message to mankind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### became flesh

Here "flesh" represents "a person" or "a human being." AT: "became human" or "became a human being" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the one and only who came from the Father
The phrase "the one an only" means that he is unique, that no one else is like him. The phrase "who came from the Father" means that he is the Father's child. AT: "the unique Son of the Father" or "the only Son of the Father"

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### full of grace

"full of kind acts towards us, acts we do not deserve"

#### He who comes after me

John is speaking about Jesus. The phrase "comes after me" means that John's ministry has already started and Jesus' ministry will start later.

#### is greater than I am

"is more important than I am" or "has more authority than I have"

#### for he was before me

Be careful not to translate this in a way that suggests that Jesus is more important because he is older than John in human years. Jesus is greater and more important than John because he is God the Son, who has always been alive.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### John 01:16

#### fullness

This word refers to God's grace that has no end.

#### grace after grace

"blessing after blessing"

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 01:19

#### the Jews sent ... to him from Jerusalem

The word "Jews" here represents the "Jewish leaders." AT: "the Jewish leaders sent ... to him from Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### He confessed—he did not deny, but confessed

The second phrase says in negative terms the same thing that the first phrase says in positive terms to emphasize that John was telling the truth and strongly stating that he was not the Christ. Your language may have a different way of doing this.

#### What are you then?

"What then is the case, if you are not the Messiah?" or "What then is going on?" or "What then are you doing?"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### John 01:22

#### Connecting Statement:

John continues to speak with the priests and Levites.

#### they said to him

"the priests and Levites said to John"

#### we ... us

the priests and Levites, not John (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### He said

"John said"

#### I am a voice, crying in the wilderness

John is saying that Isaiah's prophecy is about himself. The word "voice" here refers to the person who is crying out in the wilderness. AT: "I am the one calling out in the wilderness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Make the way of the Lord straight

Here the word "way" is used as a metaphor. AT: "Prepare yourselves for the Lord's arrival the same way that people prepare the road for an important person to use" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]

### John 01:24

#### Now some from the Pharisees

This is background information about the people who questioned John. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elijah.md)]]

### John 01:26

#### General Information:

Verse 28 tells us background information about the setting of the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### who comes after me

You may need to make explicit what he will do when he has come. AT: "who will preach to you after I am gone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### me, the strap of whose sandal I am not worthy to untie

Untying sandals was the work of a slave or servant. These words are a metaphor for the most unpleasant work of a servant. AT: "me, whom I am not worthy to serve in even the most unpleasant way" or "me. I am not even worthy to untie the strap of his sandal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sandal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### John 01:29

#### Lamb of God

This is a metaphor that represents God's perfect sacrifice. Jesus is called the "Lamb of God" because he was sacrificed to pay for people's sins. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### world

The word "world" is a metonym and refers to all the people in the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The one who comes after me is more than me, for he was before me

See how you translated this in [John 1:15](./14.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### John 01:32

#### descending

"coming down"

#### like a dove

This phrase is a simile. The "Spirit" comes down just like a dove lands on a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### heaven

The word "heaven" refers to the "sky."

#### the Son of God

Some copies of this text say "Son of God"; others say "chosen one of God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])

#### Son of God

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### John 01:35

#### Again, the next day

This is another day. It is the second day that John sees Jesus.

#### Lamb of God

This is a metaphor that represents God's perfect sacrifice. Jesus is called the "Lamb of God" because he was sacrificed to pay for people's sins. See how you translated this same phrase in [John 1:29](./29.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]

### John 01:37

#### tenth hour

"hour 10." This phrase indicates a time in the afternoon, before dark, at which it would be too late to start traveling to another town, possibly around 4 p.m.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]

### John 01:40

#### General Information:

These verses give us information about Andrew and how he brought his brother Peter to Jesus. This happened before they went and saw where Jesus was staying in [John 1:39](./37.md).

#### son of John

This is not John the Baptist. "John" was a very common name.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### John 01:43

#### Now Philip was from Bethsaida, the city of Andrew and Peter

This is background information about Philip. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephnt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephnt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]

### John 01:46

#### Nathaniel said to him

"Nathaniel said to Philip"

#### Can any good thing come out of Nazareth?

This remark appears in the form of a question in order to add emphasis. AT: "No good thing can come out of Nazareth!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### in whom is no deceit

This can be stated in a positive way. AT: "a completely truthful man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]

### John 01:49

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Because I said to you ... do you believe?

This remark appears in the form of a question to provide emphasis. AT: "You believe because I said, 'I saw you underneath the fig tree'! (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Truly, truly

Translate this the way your language emphasizes that what follows is important and true.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]

### John 01:intro

#### John 01 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 1:23, which is quoted from the OT.

####### Special concepts in this chapter #######

######## "The Word" ########
This is a unique construction used to reference Jesus. He is the "Word of God" embodied in flesh and the final revelation of God himself on earth. Although this can appear to be a complex teaching, it is rather simple: Jesus is God, the creator of the heavens and the earth. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wordofgod.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]], and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

######## Light and Darkness ########
These are common images in the New Testament. Light is used here to indicate the revelation of God and his righteousness. Darkness describes sin and sin seeks to remain hidden from God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]) 

######## "Children of God" ########
When people believes in Jesus, they go from being "children of wrath" to "children of God." They are adopted into the "family of God."They are adopted into the "family of God." This is an important image that will be unfolded in the New Testament. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adoption.md)]])

####### Important figures of speech in this chapter #######

######## Metaphors ########
Although the other gospel accounts frequently contain metaphors in the teachings of Jesus and in prophecy, the first chapter of this gospel uses metaphors in interpreting the meaning of the life of Jesus. Because of these metaphors, the reader can see that this gospel is going to be a more in-depth theological understanding of the life of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## "In the beginning was the word" ########
The first part of this chapter follows a logical and almost poetic pattern, which will be difficult to duplicate in translation.

######## "Son of Man" ########
Jesus refers to himself as the "Son of Man." Some languages may not allow a person to refer to himself in the third person. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]])

##### Links: #####

* __[John 01:01 Notes](./01.md)__
* __[John intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## John 02

### John 02:01

#### General Information:

Jesus and his disciples are invited to a wedding. These verse give background information about the setting of the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Three days later

Most interpreters read this as on the third day after Jesus called Philip and Nathaniel to follow him. The first day occurs in John 1:35 and the second in John 1:43.

#### Jesus and his disciples were invited to the wedding

This can be stated in an active form. AT: "Someone invited Jesus and his disciples to the wedding" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cana.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cana.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 02:03

#### Woman

This refers to Mary. If it is impolite for a son to call his mother "woman" in your language, use another word that is polite, or leave it out.

#### why do you come to me?

This question is asked to provide emphasis. AT: "this has nothing to do with me." or "you should not tell me what to do." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### My time has not yet come

The word "time" is a metonym that represents the right occasion for Jesus to show that he is the Messiah by working miracles. AT: "It is not yet the right time for me to perform a mighty act" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### John 02:06

#### two to three metretes

You may convert this to a modern measure. AT: "75 to 115 liters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### to the brim

This means "to the very top" or "completely full."

#### the head waiter

This refers to the person in charge of the food and drink.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### John 02:09

#### but the servants who had drawn the water knew

This is background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### drunk

unable to tell the difference between cheap wine and expensive wine because of drinking too much alcohol

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md)]]

### John 02:11

#### Connecting Statement:

This verse is not part of the main story line, but rather it gives a comment about the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### Cana

This is a place name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### revealed his glory

Here "his glory" refers to the mighty power of Jesus. AT: "showed his power"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 02:12

#### went down

This indicates that they went from a higher place to a lower place. Capernaum is northeast of Cana and is at a lower elevation.

#### his brothers

The word "brothers" includes both brothers and sisters. All Jesus' brothers and sisters were younger than he was.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]

### John 02:13

#### General Information:

Jesus and his disciples go up to Jerusalem to the temple.

#### went up to Jerusalem

This indicates that he went from a lower place to a higher place. Jerusalem is built on a hill.

#### were sitting there

The next verse makes it clear that these people are in the temple courtyard. That area was intended for worship and not for commerce.

#### sellers of oxen and sheep and pigeons

People are buying animals in the temple courtyard to sacrifice them to God.

#### money changers

Jewish authorities required people who wanted to buy animals for sacrifices to exchange their money for special money from the "money changers."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]

### John 02:15

#### So

This word marks an event that happens because of something else that has happened first. In this case, Jesus has seen the money changers sitting in the temple.

#### Stop making the house of my Father a marketplace

"Stop buying and selling things in my Father's house"

#### the house of my Father

This is a phrase Jesus uses to refer to the temple.

#### my Father

This is an important title that Jesus uses for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dove.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 02:17

#### it was written

This can be stated in an active form. AT: "someone had written" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### your house

This term refers to the temple, God's house.

#### consume

The word "consume" points to the metaphor of "fire." Jesus' love for the temple is like a fire that burns within him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sign

This refers to an event that proves something is true.

#### these things

This refers to Jesus' actions against the money changers in the temple.

#### Destroy this temple, and in three days I will raise it up

Jesus is referring to his own body as the temple that will die and come back to life three days later. Translate this in a way that describes tearing down and rebuilding a building. Jesus is not commanding his disciples to tear down the actual temple building. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### raise it up

"Raised" here is an idiom for "build" or "establish" or even "cause to stand." AT: "cause it to stand"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]


### John 02:20

#### General Information:

Verses 21 and 22 are not part of the main story line, but instead they comment on the story and tell about something that happens later. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md)]])

#### forty-six years ... three days

"46 years ... 3 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### you will raise it up in three days?

This remark appears in the form of a question to show that the Jewish authorities understand that Jesus wants to tear down the temple and build it again in three days. "Raise" is an idiom for "establish." AT: "you will establish it in three days?" or "you cannot possibly rebuild it in three days!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### believed

Here "believe" means to accept something or trust that it is true.

#### this statement

This refers back to Jesus' statement in [John 2:19](./17.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]

### John 02:23

#### Now when he was in Jerusalem

The word "now" introduces us to a new event in the story.

#### believed in his name

Here "name" is a metonym that represents the person of Jesus. AT: "believed in him" or "trusted in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the signs that he did

Miracles can also be called "signs" because they are used as evidence that God is the all-powerful one who has complete authority over the universe.

#### about man, for he knew what was in man

Here the word "man" represents people in general. AT: "about people, for he knew what was in people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-gendernotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### John 02:intro

#### John 02 General Notes ####

####### Special concepts in this chapter #######

######## Wine ########
It was customary for wine to be used during times of celebration. It was not considered immoral to drink wine.

######## Driving out the money changers ########
This is the first account of Jesus driving the money changers out of the temple. This event showed the authority Jesus had over the temple and over all of Israel. 

######## "He knew what was in them" ########
John knows that it is possible for Jesus to have this type of knowledge only because Jesus is God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Other possible translation difficulties in this chapter #######

######## "His disciples remembered" ########
This phrase is used as a commentary on the events that occur in this chapter. These comments are not known at the time when the events occur, but are already known when the book was written. Translators may choose to use parentheses to set apart the author's explanation or commentary on past events.

##### Links: #####

* __[John 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## John 03

### John 03:01

#### General Information:

Nicodemus comes to see Jesus.

#### Now

This word is used here to mark a new part of the story and to introduce Nicodemus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### we know

Here "we" is exclusive, referring only to Nicodemus and the other members of the Jewish council.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 03:03

#### Connecting Statement:

Jesus and Nicodemus continue talking.

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### born again

"born from above" or "born of God"

#### kingdom of God

The word "kingdom" is a metaphor for the rule of God. AT: "place where God rules" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### How can a man be born when he is old?

Nicodemus uses this question to emphasize that this cannot happen. AT: "A man certainly cannot be born again when he is old!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### He cannot enter a second time into his mother's womb and be born, can he?

Nicodemus also uses this question to emphasize his belief that a second birth is impossible. "Certainly, he cannot enter a second time into his mother's womb! (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### a second time

"again" or "twice"

#### womb

the part of a woman's body where a baby grows

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md)]]

### John 03:05

#### Truly, truly

You can translate this in the same way you did in [John 3:3](./03.md).

#### born of water and the Spirit

There are two possible meanings: 1) "baptized in water and in the Spirit" or 2) "born physically and spiritually" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### enter into the kingdom of God

The word "kingdom" is a metaphor for the rule of God in one's life. AT: "experience the rule of God in his life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingdomofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### John 03:07

#### Connecting Statement:

Jesus continues speaking to Nicodemus.

#### You must be born again

"You must be born from above"

#### The wind blows wherever it wishes

In the source language, wind and Spirit are the same word. The speaker here refers to the wind as if it were a person. AT: "The Holy Spirit is like a wind that blows wherever it wants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bornagain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### John 03:09

#### How can these things be?

This question adds emphasis to the statement. AT: "This cannot be!" or "This is not able to happen!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Are you a teacher of Israel, and yet you do not understand these things?

This question adds emphasis to the statement. AT: "You are a teacher of Israel, so I am surprised you do not understand these things!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### we speak

When Jesus said "we," he was not including Nicodemus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### John 03:12

#### Connecting Statement:

Jesus continues responding to Nicodemus.

#### how will you believe if I tell you about heavenly things?

This question emphasizes the disbelief of Nicodemus. AT: "you certainly will not believe if I tell you about heavenly things!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### how will you believe if I tell you

In both places "you" is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### heavenly things

spiritual things

#### heaven

This means the place where God lives.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]

### John 03:14

#### Just as Moses lifted up the serpent in the wilderness, so must the Son of Man be lifted up

This figure of speech is called a simile. Some people will "lift up" Jesus just as Moses "lifted up" the bronze serpent in the wilderness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### in the wilderness

The wilderness is a dry, desert place, but here it refers specifically to the place where Moses and the Israelites walked around for forty years.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### John 03:16

#### God so loved the world

Here "world" is a metonym that refers to everyone in the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### loved

This is the kind of love that comes from God and is focused on the good of others, even when it does not benefit oneself. God himself is love and is the source of true love.

#### For God did not send the Son into the world in order to condemn the world, but in order to save the world through him

These two clauses mean nearly the same thing, said twice for emphasis, first in the negative and then in the positive. Some languages may indicate emphasis in a different way. AT: God's real reason for sending his Son into the world was to save it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### condemn

"punish"

#### not condemned

These two negative ideas can be stated in positive form. AT: "judged to be innocent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### John 03:19

#### Connecting Statement:

Jesus finishes responding to Nicodemus.

#### The light has come into the world

The word "light" is a metaphor for God's truth that is revealed in Jesus. Jesus speaks of himself in the third person. If your language does not allow people to speak of themselves in the third person, you may need to specify who the light is. The "world" is a metonym for all of the people who live in the world. AT: "The one who is like a light has revealed God's truth to all people" or "I, who am like a light, have come into the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### men loved the darkness

Here "darkness" is a metaphor for evil. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so that his deeds will not be exposed

This can be stated in an active form. AT: "so that the light will not show the things he does" or "so that the light does not make clear his deeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### plainly seen that his deeds

This can be stated in an active form. AT: "people may clearly see his deeds" or "everyone may clearly see the things he does" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### John 03:22

#### After this

This refers to after Jesus had spoken with Nicodemus. See how you translated this in [John 2:12](../02/12.md).

#### Aenon

This word means "springs," as of water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Salim

a village or town next to the Jordan River (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### because there was much water there

"because there were many springs in that place"

#### were being baptized

You can translate this in an active form. AT: "John was baptizing them" or "he was baptizing them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]

### John 03:25

#### Then there arose a dispute between some of John's disciples and a Jew

This can be stated in an active form for clarity. AT: "Then John's disciples and a Jew began to argue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a dispute

a fight using words

#### you have testified, look, he is baptizing,

In this phrase, "look" is a command meaning "pay attention!" AT: "you have testified, 'Look! He is baptizing,'" or "you have testified. 'Look at that! He is baptizing,'" (See: [https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md))

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### John 03:27

#### A man cannot receive anything unless

"Nobody has any power unless"

#### it has been given to him from heaven

Here "heaven" is used as a metonym to refer to God. This can be stated in an active form. AT: "God has given it to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You yourselves

This "You" is plural and refers to all the people John is talking to. AT: "You all" or "All of you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### I have been sent before him

This can be stated in an active form. AT: "God sent me to arrive before him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### John 03:29

#### Connecting Statement:

John the Baptist continues speaking.

#### The bride belongs to the bridegroom

Here the "bride" and "bridegroom" are metaphors. Jesus is like the "bridegroom" and John is like the friend of the "bridegroom." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### This, then, is my joy made complete

This can be stated in active form. AT: "So then I rejoice greatly" or "So I rejoice much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my joy

The word "my" refers to John the Baptist, the one who is speaking.

#### He must increase

"He" refers to the bridegroom, Jesus, who will continue to grow in importance.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### John 03:31

#### He who comes from above is above all

"He who comes from heaven is more important than anyone else"

#### He who is from the earth is from the earth and speaks about the earth

John means that Jesus is greater than he is since Jesus is from heaven, and John was born on the earth. AT: "He who is born in this world is like everyone else who lives in the world and he speaks about what happens in this world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He who comes from heaven is above all

This means the same thing as the first sentence. John repeats this for emphasis.

#### He testifies about what he has seen and heard

John is speaking about Jesus. AT: "The one from heaven tells about what he has seen and heard in heaven"

#### no one accepts his testimony

Here John exaggerates to emphasize that only a few people believe Jesus. AT: "very few people believe him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### He who has received his testimony

"Anyone who believes what Jesus says"

#### has confirmed

"proves" or "agrees"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 03:34

#### Connecting Statement:

John the Baptist finishes speaking.

#### For the one whom God has sent

"This Jesus, whom God has sent to represent him"

#### For he does not give the Spirit by measure

"For he is the one to whom God gave all the power of his Spirit"

#### Father ... Son

These are important titles that describe the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### given ... into his hand

This means to be put in his power or control. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### He who believes

"A person who believes" or "Anyone who believes"

#### the wrath of God stays on him

The abstract noun "wrath" can be translated with the verb "punish." AT: "God will continue to punish him" (See: [https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md))

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### John 03:intro

#### John 03 General Notes ####

####### Special concepts in this chapter #######

######## Light and darkness ########
These are common images in the New Testament. Light is used here to indicate the revelation of God and his righteousness. Darkness describes sin, and sin seeks to remain hidden from God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]) 

####### Other possible translation difficulties in this chapter #######

######## "We know that you are a teacher come from God" ########
Although this appears to be a display of faith, it is not. This is because believing Jesus is "only a teacher" shows a lack of awareness of who he truly is. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## "Son of Man" ########

Jesus refers to himself as the "Son of Man" in this passage. Some languages may not allow a person to refer to himself in the third person. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]])

##### Links: #####

* __[John 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## John 04

### John 04:01

#### General Information:

John 4:1-6 gives the background to the next event, Jesus' conversation with a Samaritan woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Now when Jesus knew that the Pharisees had heard that he was making ... John (although ... were), he left ... Galilee

"Now Jesus was making ... John (although ... were), and the Pharisees had heard about the success he was having. He learned that the Pharisees had heard, so he left ... Galilee"

#### Now when Jesus knew

The word "now" is used here to mark a break in the main events. Here John starts to tell a new part of the narrative.

#### Jesus himself was not baptizing

The reflexive pronoun "himself" adds emphasis that it was not Jesus who was baptizing, but his disciples. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]

### John 04:04

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]

### John 04:06

#### Give me some water

This is a polite request, not a command.

#### For his disciples had gone

He did not ask his disciples to draw water for him because they had gone.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 04:09

#### Then the Samaritan woman said to him

The word "him" refers to Jesus.

#### How is it that you, being a Jew, are asking ... for something to drink?

This remark appears in the form of a question to express the Samaritan woman's surprise that Jesus asked her for a drink. AT: "I cannot believe that you, being a Jew, are asking a Samaritan for a drink!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### have no dealings with

"do not associate with"

#### living water

Jesus uses the metaphor "living water" to refer to the Holy Spirit who works in a person to transform and bring new life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### John 04:11

#### You are not greater, are you, than our father Jacob ... cattle?

This remark occurs in the form of a question to add emphasis. AT: "You are not greater than our father Jacob ... cattle!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### our father Jacob

"our ancestor Jacob"

#### drank from it

"drank water that came from it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]

### John 04:13

#### will be thirsty again

"will need to drink water again"

#### the water that I will give him will become a fountain of water in him

Here the word "fountain" is a metaphor for life-giving water. AT: "the water that I will give him will become like a spring of water in him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### eternal life

Here "life" refers to the "spiritual life" that only God can give.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 04:15

#### Sir

In this context, the Samaritan woman is addressing Jesus as "Sir," which is a term of respect or politeness.

#### draw water

"get water" or "pull water up from the well" using a container and rope

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### John 04:17

#### You are right in saying ... What you have said is true

Jesus repeats this statement to emphasize that he knows the woman is telling the truth.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 04:19

#### Sir

In this context the Samaritan woman is addressesing Jesus as "sir," which is a term of respect or politeness.

#### I see that you are a prophet

"I can understand that you are a prophet"

#### Our fathers

"Our forefathers" or "Our ancestors"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### John 04:21

#### Believe me

To believe someone is to acknowledge what the person has said is true.

#### You worship what you do not know. We worship what we know

Jesus means that God revealed himself and his commands to the Jewish people, not to the Samaritans. Through the Scriptures the Jewish people know who God is better than the Samaritans.

#### you will worship the Father ... for salvation is from the Jews

Eternal salvation from sin comes from God the Father, who is Yahweh, the God of the Jews.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### for salvation is from the Jews

This does not mean the Jewish people will save others from their sins. It means God has chosen the Jews as his special people who will tell all other people about his salvation. AT: "for all people will know about God's salvation because of the Jews"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### John 04:23

#### Connecting Statement:

Jesus continues speaking to the Samaritan woman.

#### However, the hour is coming, and is now here, when true worshipers will

"However, it is now the right time for true worshipers to"

#### the Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### worship in spirit and truth

"worship him in the right way"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### John 04:25

#### I know that the Messiah ... Christ

Both of these words mean "God's promised king."

#### he will explain everything to us

The words "explain everything" imply all that the people need to know. AT: "he will tell us everything we need to know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### John 04:27

#### At that moment his disciples returned

"Just as Jesus was saying this, his disciples returned from town"

#### Now they were wondering why he was speaking with a woman

It was very unusual for a Jew to speak with a woman he did not know, especially if that woman was a Samaritan.

#### no one said, "What ... want?" or "Why ... her?"

Possible meanings are 1) the disciples asked both questions to Jesus or 2) "no one asked the woman, 'What ... want?' or asked Jesus, 'Why ... her?'"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 04:28

#### Come, see a man who told me everything that I have ever done

The Samaritan woman exaggerates to show that she is impressed by how much Jesus knows about her. AT: "Come see a man who knows very much about me, even though I have never met him before" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### This could not be the Christ, could it?

The woman is not sure that Jesus is the Christ, so she asks a question that expects "no" for an answer, but she also asks a question instead of making a statement because she wants the people to decide for themselves.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### John 04:31

#### In the meantime

"While the woman was going into town"

#### the disciples were urging him

"the disciples were telling Jesus" or "the disciples were encouraging Jesus"

#### I have food to eat that you do not know about

Here Jesus is not talking about literal "food," but is preparing his disciples for a spiritual lesson in [John 4:34](./34.md).

#### No one has brought him anything to eat, have they?

The disciples think Jesus is talking about literal "food." They begin asking each other this question, expecting a "no" response. AT: "Surely no one brought him any food while we were in town!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]

### John 04:34

#### My food is to do the will of him who sent me and to complete his work

Here "food" is a metaphor that represents "obeying God's will." AT: "Just as food satisfies a hungry person, obeying God's will is what satisfies me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do you not say

"Is this not one of your popular sayings"

#### look up and see the fields, for they are already ripe for harvest

The words "fields" and "ripe for harvest" are metaphors. The "fields" represent the non-Jewish people or Gentiles. The words "ripe for harvest" mean that the Gentiles are ready to receive the message of Jesus, just as fields are ready to be harvested. AT: "look up and see these non-Jewish people! They are ready to accept my message, just like crops in the fields are ready for people to harvest them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He who is harvesting receives wages and gathers fruit for everlasting life

Jesus indicates that there is a reward for those "work in his fields" and share his message. The ones who receive his message will also receive the eternal life that God offers.

"gathers fruit for everlasting life" is a metaphor, representing people who receive his message and who have eternal life. AT: "helps people believe the message and receive eternal life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### John 04:37

#### Connecting Statement:

Jesus continues speaking to his disciples.

#### One sows, and another harvests

The words "sows" and "harvests" are metaphors. The one who "sows" shares the message of Jesus. The one who "harvests" helps the people to receive the message of Jesus. AT: "One person plants the seeds, and another person harvests the crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you have entered into their labor

"you are now joining in their work"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### John 04:39

#### believed in him

To "believe in" someone means to "trust in" that person. Here this also means that they believed he was the Son of God.

#### He told me everything that I have done

This is an exaggeration. The woman was impressed by how much Jesus knew about her. AT: "He told me many things about my life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### John 04:41

#### his word

Here "word" is a metonym that stands for the message that Jesus proclaimed. AT: "his message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### world

The "world" is a metonym for all the believers throughout the world. AT: "all the believers in the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/savior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 04:43

#### General Information:

Jesus goes down to Galilee and heals a boy. Verse 44 gives us background information about something Jesus had said previously. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### from there

from Judea

#### For Jesus himself declared

The reflexive pronoun "himself" is added to emphasize that Jesus had "declared" or said this.. You can translate this in your language in a way that will give emphasis to a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### a prophet has no honor in his own country

"people do not show respect or honor to a prophet of their own country" or "a prophet is not respected by the people in his own community"

#### at the festival

Here the festival is the Passover.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]

### John 04:46

#### Now

This word is used here to mark a break in the main story line and to move to a new part of the story. If you have a way of doing this in your language, you may consider using it.

#### royal official

someone who is in the service of the king

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cana.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cana.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]

### John 04:48

#### Unless you see signs and wonders, you will not believe

"Unless ... not believe" here is a double negative. In some languages it is more natural to translate this statement in a positive form. AT: "Only if you see a miracle will you believe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### believed the word

Here "word" is a metonym that refers to the message that Jesus spoke. AT: "believed the message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### John 04:51

#### While

This word is used to mark two events that are happening at the same time. As the official was going home, his servants were coming to meet him on the road.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimehour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimehour.md)]]

### John 04:53

#### So he himself and his whole household believed

The reflexive pronoun "himself" is used here to emphasize the word "he." If you have a way of doing this in your language, you may consider using it.

#### sign

Miracles can also be called "signs" because they are used as indicators or evidence that God is the all-powerful one who has complete authority over the universe.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]

### John 04:intro

#### John 04 General Notes ####

####### Structure and formatting #######

John 4:4-38 forms one story centered on the teaching of Jesus as the "living water," providing eternal life to all who believe in him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]])

####### Special concepts in this chapter #######

######## "It was necessary for him to pass through Samaria" ########
Normally, the Jews would have avoided traveling through the region of Samaria. The Samaritans were viewed as ungodly people because they were descendants of the northern kingdom of Israel who intermarried with pagan peoples. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdomofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdomofisrael.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## The proper place of worship ########
One of the greatest sins committed by the Samaritan people in history was that they set up a false temple in their territory to rival the temple in Jerusalem. This is the mountain the woman refers to in [John 4:20](./19.md). The Jews rightly demanded that all Israelites worship in Jerusalem because that was where Yahweh lived. Jesus explains that the location of the temple does not matter anymore. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

######## Harvest ########
The imagery of harvesting is used in this chapter. This is a metaphor that represents bringing people to faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

######## "The Samaritan woman" ########
The Samaritan woman is probably intended to contrast with the Jewish reaction towards Jesus. "Jesus himself declared that a prophet has no honor in his own country" ([John 4:44](./43.md)). There were many reasons the Jews would have seen this woman as untrustworthy. She was a Samaritan, an adulterer, and a woman. Despite this, she did what God required of her. She believed in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]])

####### Other possible translation difficulties in this chapter #######

######## "In spirit and truth" ########
True worship is no longer directed to a place, but is now directed towards the person of Jesus. In addition to this, worship is no longer done through priests. Everyone can directly worship God. This phrase implies that the proper worship of God can now be done without physically offering sacrifices and can be done more completely because of greater revelation given to man. There are many additional understandings of this passage. It may be best to leave this phrase as generic as possible in translation so as to not exclude other possible meanings. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

##### Links: #####

* __[John 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## John 05

### John 05:01

#### General Information:

This is the next event in the story, in which Jesus goes up to Jerusalem and heals a man. These verses give background information about the setting of the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### After this

This refers to after Jesus healed the official's son. See how you translated this in [John 3:22](../03/22.md).

#### there was a Jewish festival

"the Jews were celebrating a festival"

#### went up to Jerusalem

Jerusalem is located on the top of a hill. Roads to Jerusalem went up and down smaller hills. If your language has a different word for going up a hill than for walking on level ground, you may use it here.

#### pool

This was a hole in the ground that people filled with water. Sometimes they lined the pools with tiles or other stonework.

#### Bethesda

a place name (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### roofed porches

roofed structures with at least one wall missing and attached to buildings

#### A large number of people

"Many people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]

### John 05:05

#### General Information:

Verse 5 introduces the man lying beside the pool to the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### was there

"was at the Bethesda pool" ([John 5:1](./01.md))

#### thirty-eight years

"38 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### he realized

"he understood" or "he found out"

#### he said to him

"Jesus said to the paralyzed man"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 05:07

#### Sir, I do not have

Here the word "sir" is a polite form of address.

#### when the water is stirred up

This can be translated in an active form. AT: "when the angel moves the water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### into the pool

This was a hole in the ground that people filled with water. Sometimes they lined the pools with tiles or other stonework. See how you translated "pool" in [John 5:2](./01.md).

#### another steps down before me

"someone else always goes down the steps into the water before me"

#### Get up

"Stand up!"

#### take up your bed, and walk

"Pick up your sleeping mat, and walk!"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 05:09

#### the man was healed

"the man became healthy again"

#### Now that day

The writer uses the word "now" to show that the words that follow are background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]

### John 05:10

#### So the Jews said to him

The Jews (especially the leaders of the Jews) became angry when they saw the man carrying his mat on the Sabbath.

#### It is the Sabbath

"It is God's Day of Rest"

#### He who made me healthy

"The man who made me well"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]

### John 05:12

#### They asked him

"The Jewish leaders asked the man who was healed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 05:14

#### Jesus found him

"Jesus found the man he had healed"

#### See

The word "See" is used here to draw attention to the words that follow.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md)]]

### John 05:16

#### Now

The writer uses the word "now" to show that the words that follow are background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### is working

This refers to doing labor, including anything that is done to serve other people.

#### the Jews

Here "the Jews" is a synecdoche which represent the "Jewish leaders." AT: "the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### making himself equal to God

"saying that he was like God" or "saying that he had as much authority as God"

#### My Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 05:19

#### Connecting Statement:

Jesus continues speaking to the Jewish leaders.

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### you will be amazed

"you will be surprised" or "you will be shocked"

#### whatever the Father is doing, the Son does these things also. For the Father loves the Son

Jesus, as the Son of God, followed and obeyed his Father's leadership on earth, because Jesus knew the Father loved him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Son ... Father

These are important titles that describe the relationship between Jesus and God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### loves

The kind of love that comes from God is focused on the good of others, even when it does not benefit oneself. God himself is love and is the source of true love.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### John 05:21

#### Father ... Son

These are important titles that describe the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### life

This refers to "spiritual life."

#### For the Father judges no one, but he has given all judgment to the Son

The word "for" marks a comparison. The Son of God carries out judgment for God the Father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### honor the Son just as ... the Father. The one who does not honor the Son does not honor the Father

God the Son must be honored and worshiped just like God the Father. If we fail to honor God the Son, then we also fail to honor God the Father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### John 05:24

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### he who hears my word

Here "word" is a metonym that represents the message of Jesus. AT: "anyone who hears my message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will not be condemned

This can be stated positively. AT: "will be judged to be innocent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 05:25

#### Truly, truly

Translate this the way your language emphasizes that what follows is important and true. See how you translated this in [John 1:51](../01/49.md).

#### the dead will hear the voice of the Son of God, and those who hear will live

The voice of Jesus, the Son of God, will raise dead people from the grave. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 05:26

#### For just as the Father has life in himself, so he has also given to the Son so that he has life in himself

The word "For" marks a comparison. The Son of God has the power to give life, just as the Father does. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Father ... Son of Man

These are important titles that describe the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### life

This means spiritual life.

#### the Father has given the Son authority to carry out judgment

The Son of God has the authority of God the Father to judge.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]

### John 05:28

#### Do not be amazed at this

"This" refers to the fact that Jesus, as the Son of Man, has the power to give eternal life and to carry out judgment.

#### hear his voice

"hear my voice"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### John 05:30

#### the will of him who sent me

The word "him" refers to God the Father.

#### There is another who testifies about me

"There is someone else who tells people about me"

#### another

This refers to God.

#### the testimony that he gives about me is true

"what he tells people about me is true"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 05:33

#### the testimony that I receive is not from man

"I do not need people's testimony"

#### that you might be saved

You can translate this in an active form. AT: "so God can save you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### John was a lamp that was burning and shining

Here "lamp" is a metaphor. John displayed God's holiness in the same way a lamp gives light. AT: "John was like a lamp that was burning and shining" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### willing to rejoice in his light

"Light" here is a metonym for "life" or "influence" or "teaching." AT: "willing to rejoice in his influence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### John 05:36

#### the works that the Father has given me to accomplish ... that the Father has sent me

God the Father has sent God the Son, Jesus, to earth. Jesus completes what the Father gives him to do.

#### The Father who sent me has himself testified

The reflexive pronoun "himself" emphasizes that it is the Father, not someone less important, who has testified. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### the very works that I do, testify about me

Here Jesus says that the miracles "testify" or "tell the people" about him. AT: "What I do shows the people that God has sent me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### You do not have his word ... in you, for you are not believing in the one whom he has sent

"Word" here is a metonym for "message." AT: "You do not believe in the one he has sent. That is how I know that you do not have his message remaining in you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### remaining in you

"living in you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 05:39

#### in them you have eternal life

"you will find eternal life if you read them" or "the scriptures will tell you how you can have eternal life"

#### you are not willing to come to me

"you refuse to believe my message"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### John 05:41

#### receive

"accept"

#### you do not have the love of God in yourselves

This can mean 1) "you really do not love God" or 2) "you have really not received God's love."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 05:43

#### in my Father's name

Here the word "name" is a metonym that symbolizes God's power and authority. AT: "I have come with my Father's authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### receive

"accept"

#### If another should come in his own name

The word "name" is a metonym that represents authority. AT: "If another should come in his own authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### How can you believe, you who accept praise ... God?

This remark appears in the form of a question in order to add emphasis. AT: "There is no way you can believe because you accept praise ... God!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### believe

This means to trust in Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### John 05:45

#### The one who accuses you is Moses, in whom you have put your hope

"Moses" here is a metonym here that stands for the law itself. AT: "Moses accuses you in the Law, the very Law in which you have put your hopes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your hope

"your confidence" or "your trust"

#### If you do not believe his writings, how are you going to believe my words?

This remark appears in the form of a question to provide emphasis. AT: "You do not believe his writings, so you will never believe my words!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my words

"what I say"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hope.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 05:intro

#### John 05 General Notes ####

####### Special concepts in this chapter #######

######## Porticos ########
Many of the Jews believed these porticos had healing properties. This happened when the waters were "stirred up." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## "The resurrection of judgment" ########
This is a reference to a time after death when all of mankind will be judged. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]])

####### Other possible translation difficulties in this chapter #######

######## Son, Son of God ########

Jesus refers to himself as "the Son," the "Son of Man" and the "Son of God."Some languages may not allow a person to refer to himself in the third person. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]])

######## "He has testified concerning me" ########
Jesus speaks about the Old Testament testifying concerning himself. The Old Testament gives many prophecies concerning the Messiah which described Jesus before he came to earth. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]])

##### Links: #####

* __[John 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## John 06

### John 06:01

#### General Information:

Jesus has traveled from Jerusalem to Galilee. A crowd has followed him up a mountainside. These verses tell the setting of this part of the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### After these things

The phrase "these things" refers to the events in [John 5:1-46](../05/01.md) and introduces the event that follows.

#### Jesus went away

It is implied in the text that Jesus traveled by boat and took his disciples with him. AT: "Jesus traveled by boat with his disciples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### A great crowd

"A large number of people"

#### signs

This refers to the miracles that are used as evidence that God is the all-powerful one who has complete authority over everything.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 06:04

#### General Information:

The action in the story begins in verse 5.

#### Now the Passover, the Jewish festival, was near

John briefly stops telling about the events in the story in order to give background information about when the events happened. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### But Jesus said this to test Philip, for he himself knew what he was going to do

John briefly stops telling about the events in the story in order to explain why Jesus asked Philip where to buy bread. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### for he himself knew

The reflexive pronoun "himself" makes it clear that the word "he" refers to Jesus. Jesus knew what he would do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### John 06:07

#### Two hundred denarii worth of bread

The word "denarii" is the plural of "denarius. "AT: "The amount of bread that cost two hundred days' wages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### five bread loaves of barley

"Five loaves of barley bread." Barley was a common grain.

#### loaves

A loaf of bread is a lump of dough that is shaped and baked. These were probably small dense, round loaves.

#### what are these among so many?

This remark appears in the form of a question to emphasize that they do not have enough food to feed everyone. AT: "these few loaves and fishes are not enough to feed so many people!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]

### John 06:10

#### sit down

"lie down"

#### Now there was a lot of grass in the place

John briefly stops telling about the events in the story in order to give background information about the place where this event happens. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### So the men sat down, about five thousand in number

While the crowd probably included women and children ([John 6:4-5](./04.md)), here John is counting only the men.

#### giving thanks

Jesus prayed to God the Father and thanked him for the fish and the loaves.

#### he gave it

"he" here represents "Jesus and his disciples." AT: "Jesus and his disciples gave it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 06:13

#### General Information:

Jesus withdraws from the crowd. This is the end of the part of the story about Jesus feeding the crowd on the mountain.

#### they gathered

"the disciples gathered"

#### left over

the food that no one had eaten

#### this sign

Jesus feeding the 5,000 people with five barley loaves and two fish

#### the prophet

the special prophet who Moses said would come into the world

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### John 06:16

#### Connecting Statement:

This is the next event in the story. Jesus' disciples go out onto the lake in a boat.

#### It was dark by this time, and Jesus had not yet come to them

Use your language's way of showing that this is background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]

### John 06:19

#### they had rowed

Boats usually had two, four, or six people rowing with rowers on each side working together. Your culture may have different ways of making a boat go across a large body of water.

#### about twenty-five or thirty stadia

A "stadium" is 185 meters. AT: "about five or six kilometers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### Do not be afraid

"Stop being afraid!"

#### they were willing to receive him into the boat

It is implied that Jesus gets into the boat. AT: "they gladly received him into the boat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]

### John 06:22

#### the sea

"the Sea of Galilee"

#### However, there were ... the Lord had given thanks

Use your language's way of showing that this is background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### boats that came from Tiberias

Here, John provides more background information. The next day, after Jesus fed the people, some boats with people from Tiberius came to see Jesus. However, Jesus and his disciples had left the night before. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 06:24

#### General Information:

The people go to Capernaum to find Jesus. When they see him, they start asking him questions.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]

### John 06:26

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### eternal life which the Son of Man will give you, for God the Father has set his seal on him

God the Father has given his approval to Jesus, the Son of Man, to give eternal life to those who believe in him.

#### Son of Man ... God the Father

These are important titles that describe the relationship between Jesus and God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### has set his seal on him

To "set a seal" on something means to place a mark on it to show to whom it belongs. This means that the Son belongs to the Father and that the Father approves of him in every way. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]

### John 06:28

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### John 06:30

#### Our fathers

"Our forefathers" or "Our ancestors"

#### heaven

This refers to the place where God lives.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### John 06:32

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### it is my Father who is giving you the true bread from heaven

The "true bread" is a metaphor for Jesus. AT: "The Father gives to you the Son as the true bread from heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### my Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### gives life to the world

"gives spiritual life to the world"

#### the world

Here the "world" is a metonym for all of the people in the world who trust in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 06:35

#### I am the bread of life

Through metaphor, Jesus compares himself with bread. Just as bread is necessary for our physical life, Jesus is necessary for our spiritual life. AT: "Just as food keeps you alive physically, I can give you spiritual life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### believes in

This means to believe that Jesus is the Son of God, to trust him as Savior, and to live in a way that honors him.

#### Everyone whom the Father gives me will come to me

God the Father and God the Son will save forever those who believe in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### he who comes to me I will certainly not throw out

This sentence states the opposite of what it means for emphasis. AT: "I will keep everyone who comes to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 06:38

#### Connecting Statement:

Jesus continues speaking to the crowd.

#### him who sent me

"my Father, who sent me"

#### I would lose not one of all those

Here litotes is used to emphasize that Jesus will keep everyone that God gives to him. AT: "I should keep all of them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### will raise them up

"Raise" here is an idiom for "cause to live again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/willofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### John 06:41

#### Connecting Statement:

The Jewish leaders interrupt Jesus as he is speaking to the crowd.

#### grumbled

talked unhappily

#### I am the bread

Just as bread is necessary for our physical life, Jesus is necessary for our spiritual life. See how you translated this in [John 6:35](./35.md). AT: "I am the one who is like true bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Is not this Jesus ... whose father and mother we know?

This remark appears in the form of a question to emphasize that the Jewish leaders believe that Jesus is no one special. AT: "This is just Jesus, the son of Joseph, whose father and mother we know! (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### How then does he now say, 'I have come down from heaven'?

This remark appears in the form of a question to emphasize that the Jewish leaders do not believe that Jesus came from heaven. AT: "He is lying when he says that he came from heaven!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephnt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephnt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### John 06:43

#### Connecting Statement:

Jesus continues speaking to the crowd and now also to the Jewish leaders.

#### raise him up

"Raise" here is an idiom for "cause to live again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### draws

This can mean 1) "pulls" or 2) "attracts."

#### It is written in the prophets

This is a passive statement that can be translated in an active form. AT: "The prophets wrote" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Everyone who has heard and learned from the Father comes to me

The Jews thought Jesus was the "son of Joseph" (See: [John 6:42](./41.md)), but he is the Son of God because his Father is God, not Joseph. Those who truly learn from God the Father believe in Jesus, who is God the Son.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### John 06:46

#### Connecting Statement:

Jesus now continues speaking to the crowd and the Jewish leaders.

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### Not that anyone has seen the Father, except he who is from God

Although no human who is alive on earth has seen God the Father, Jesus, the Son of God, has seen the Father.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### he who believes has eternal life

God gives "eternal life" to those who trust in Jesus, the Son of God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### John 06:48

#### I am the bread of life

Just as bread is necessary for our physical life, Jesus is necessary for our spiritual life. See how you translated this in [John 6:35](./35.md). AT: "Just like food that keeps you alive physically, I can give you spiritual life that lasts forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Your fathers

"Your forefathers" or "Your ancestors"

#### died

This refers to physical death.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 06:50

#### This is the bread

Here "bread" is a metaphor that points to Jesus who is the one who gives spiritual life just as bread sustains physical life. AT: "I am like the true bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### not die

"live forever." Here the word "die" refers to spiritual death.

#### living bread

This means "the bread that causes people to live" ([John 6:35](./35.md)).

#### for the life of the world

Here "the world" is a metonym that represents the lives of all the people in the world. AT: "that will give life to all the people in the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 06:52

#### Connecting Statement:

Some Jews who are present begin to argue among themselves and Jesus responds to their question.

#### How can this man give us his flesh to eat?

This remark appears in the form of a question to emphasize that the Jewish leaders are reacting negatively to what Jesus has said about "his flesh." AT: "There is no way that this man can give us his flesh to eat!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### eat the flesh of the Son of Man and drink his blood

Here the phrases "eat the flesh" and "drink his blood" are metaphors that show how trusting in Jesus, the Son of Man, is like receiving spiritual food and drink. AT: "receive the Son of Man just like you receive food and drink" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will not have life in yourselves

"you will not receive eternal life"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### John 06:54

#### Connecting Statement:

Jesus continues speaking to all those listening to him.

#### Whoever eats my flesh and drinks my blood has everlasting life

The phrases "eats my flesh" and "drinks my blood" are metaphors. Just as one requires food and drink in order to have physical life, those who trust in Jesus will have spiritual life. AT: "whoever trusts me for their spiritual food and drink will have eternal life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### raise him up

"Raise" here is an idiom for "cause to live again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### at the last day

"on the day when God judges everyone"

#### my flesh is true food ... my blood is true drink

The words "true food" and "true drink" are metaphors that mean Jesus provides spiritual food and drink to those who trust in him. Receiving Jesus in faith provides everlasting life the same way food and drink nourish the physical body. AT: "I am truly spiritual food and drink" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### remains in me, and I in him

"has a close relationship with me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]]

### John 06:57

#### so he who eats me

"the one who trusts in me"

#### living Father

Possible meanings are 1) "the Father who gives life" or 2) "the Father who is alive."

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### This is the bread that has come down from heaven

The "bread" is a metaphor for Jesus, who has come from heaven. AT: "I am like bread that has come from heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He who eats this bread

This is a metaphor. Those who trust in Jesus for their spiritual life are like those who rely on physical bread or food for their physical lives. AT: "Whoever trusts in me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the fathers

"the forefathers" or "the ancestors"

#### Jesus said these things in the synagogue ... in Capernaum

Here John gives background information about when this event happened. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/capernaum.md)]]

### John 06:60

#### Connecting Statement:

Some of the disciples ask a question and Jesus responds, as he continues speaking to the crowd.

#### who can accept it?

This remark appears in the form of a question to emphasize that the disciples have difficulty understanding what Jesus has said. AT: "no one can accept it!" or "it is too hard to understand!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Does this offend you?

"Does this shock you?" or "Does this upset you?"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 06:62

#### Then what if you should see the Son of Man going up to where he was before?

Jesus offers this remark in the form of a question to emphasize that his disciples will see other things that are also hard to understand. AT: "Then you will not know what to think when you see me, the Son of Man, going up into heaven!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### profits

The word "profit" means to cause good things to happen.

#### words

"Words" here is a metonym that could possibly mean: 1) Jesus' words in [John 6:32-58](./32.md) or 2) everything Jesus teaches. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The words that I have spoken to you

"What I have told you"

#### are spirit, and they are life

Possible meanings are 1) "are about the Spirit and eternal life" or 2) "are from the Spirit and give eternal life" or 3) "are about spiritual things and life."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 06:64

#### Connecting Statement:

Jesus finishes speaking to the crowd.

#### For Jesus knew from the beginning who were the ones ... who it was who would betray him

Here John gives background information about what Jesus knew would happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### no one can come to me unless it is granted to him by the Father

Whoever wants to believe must come to God through the Son. Only God the Father allows people to come to Jesus.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### come to me

"follow me and receive eternal life"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### John 06:66


#### no longer walked with him

"walked" here is an idiom for "followed" or "obeyed." AT: "no longer followed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Lord, to whom shall we go?

Simon Peter gives this remark in the form of a question to emphasize that he desires to follow only Jesus. AT: "Lord, we could never follow anyone but you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### his disciples

Here "his disciples" refers to the general group of people who followed Jesus.

#### the twelve

This is an ellipsis for "the twelve disciples," a specific group of twelve men who followed Jesus for his entire ministry. AT: "the twelve disciples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md)]]

### John 06:70

#### General Information:

Verse 71 is not part of the main story line as John comments on what Jesus said. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Did not I choose you, the twelve, and one of you is a devil?

Jesus gives this remark in the form of a question to draw attention to the fact that one of the disciples will betray him. AT: "I chose you all myself, yet one of you is a servant of Satan!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### John 06:intro

#### John 06 General Notes ####

####### Special concepts in this chapter #######

######## "Make him king" ########
While not all scholars agree on the exact reason Jesus did not want to be made king, it is generally agreed that the people did not have the right motivation for making him king. They wanted him to be king because he gave them food. They failed to recognize the truth that he already is the king of kings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Bread ########
Jesus uses the imagery of bread in this chapter. Bread's significance can be traced back to the daily provision God provided to Israel in the desert for 40 years and the events of the Passover. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]])

######## "I am ... " ########
John uses this phrase seven times in his gospel. It is the same words used by God, when he revealed himself and his name Yahweh at the burning bush. The name "Yahweh" can be translated as "I am."

####### Important figures of speech in this chapter #######

######## "Gives to me ... comes to me" ########
These phrases are used to mean that many will "come to believe in Jesus." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## "Eat my flesh and drink my blood" ########
This should clearly be seen as a metaphor. It is a reference to the practice instituted during Jesus' last meal when Jesus used bread and wine to represent his flesh and blood. This is a reference to Jesus' death for sin. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Other possible translation difficulties in this chapter #######

######## Parenthetical Ideas ########
Several times in this passage, John explains something or gives the reader some context to better understand the story. These explanation are intended to give the reader some additional knowledge without interrupting the flow of the narrative. The information is placed inside parentheses.

######## "Son of Man, Son" ########

Jesus refers to himself as the "Son of Man" in this passage. Some languages may not allow a person to refer to himself in the third person.

##### Links: #####

* __[John 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## John 07

### John 07:01

#### General Information:

Jesus is in Galilee speaking to his brothers. These verses tell about when this event occurred. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### After these things

These words tell the reader that the writer will begin talking about a new event. "After he finished speaking with the disciples" (See: [John 6:66-71](../06/66.md)) or "Some time later"

#### traveled

"walked"

#### the Jews were seeking to kill him

Here "the Jews" is a synecdoche for "the Jewish leaders." AT: "the Jewish leaders were making plans to kill him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Now the Jewish Festival of Shelters was near

"Now the time for the festival of the Jews was near" or "Now it was almost time for the Jewish festival of Shelters"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]

### John 07:03

#### brothers

This refers to the actual younger brothers of Jesus, the sons of Mary and Joseph.

#### the works that you do

The word "works" refers to the miracles that Jesus had performed.

#### he himself

The word "himself" is a reflexive pronoun that emphasizes the word "he." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### the world

Here "the world" is a metonym for all of the people in the world. AT: "all people" or "everyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 07:05

#### For even his brothers did not believe in him

This sentence is a break from the main story line as John tells us some background information about the brothers of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### his brothers

"his younger brothers"

#### My time has not yet come

The word "time" is a metonym. Jesus is implying that it is not the right time for him to bring his ministry to a close. AT: "It is not the right time for me to end my work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### your time is always ready

"any time is good for you"

#### The world cannot hate you

Here the "world" is a metonym for the people who live in the world. AT: "All the people in the world cannot hate you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I testify about it that its works are evil

"I tell them that what they are doing is evil"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### John 07:08

#### Connecting Statement:

Jesus continues speaking to his brothers.

#### my time has not yet been fulfilled

Here Jesus is implying that if he goes to Jerusalem, he will bring his work to an end. AT: "It is not the right time for me to go to Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]

### John 07:10

#### General Information:

The setting of the story has changed, Jesus and his brothers are now at the festival.

#### when his brothers had gone up to the festival

These "brothers" were the younger brothers of Jesus.

#### he also went up

Jerusalem is at a higher elevation than Galilee where Jesus and his brothers were previously.

#### not publicly but in secret

These two phrases mean the same thing. The idea is repeated for emphasis. AT: "very secretly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### The Jews were looking for him

Here the word "Jews"is a synecdoche for "the Jewish leaders." The word "him" refers to Jesus. AT: "The Jewish leaders were looking for Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### John 07:12

#### fear

This refers to the unpleasant feeling a person has when there is a threat of harm to himself or others.

#### the Jews

The word "Jews" is a synecdoche for the leaders of the Jews who opposed Jesus. AT: "the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he leads the crowds astray

Here "leads ... astray" is a metaphor for persuading someone to believe something that is not true. AT: "he deceives the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### John 07:14

#### General Information:

Jesus is now teaching the Jews in the temple.

#### How does this man know so much?

The remark appears in the form of a question to emphasize the Jewish leaders' surprise that Jesus has so much knowledge. AT: "He cannot possibly know so much about the scriptures!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### but is of him who sent me

"but comes from God, the one who sent me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]

### John 07:17

#### Connecting Statement:

Jesus continues speaking to the Jews.

#### but whoever seeks the glory of him who sent him, that person is true, and there is no unrighteousness in him

"when a person only seeks to honor the one who sent him, that person is speaking the truth. He does not lie"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### John 07:19

#### Connecting Statement:

Jesus continues speaking to the Jews.

#### Did not Moses give you the law?

This remark appears in the form of a question to add emphasis. AT: "It was Moses who gave you the law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### keeps the law

"obeys the law"

#### Why do you seek to kill me?

Jesus questions the motives of the Jewish leaders who want to kill him for breaking the law of Moses. He implies that the leaders themselves do not keep that same Law. AT: "You break the Law yourselves and yet you want to kill me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You have a demon

"This shows that you are crazy, or maybe a demon is controlling you!"

#### Who seeks to kill you?

This remark appears in the form of a question to add emphasis. AT: "No one is trying to kill you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]

### John 07:21

#### one work

"one miracle" or "one sign"

#### you all marvel

"you all are shocked"

#### not that it is from Moses, but from the ancestors

Here John provides additional information about circumcision. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### on the Sabbath you circumcise a man

Jesus implies that the act of circumcision also involves work. AT: "you circumcise a male baby on the Sabbath. That is working too" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### on the Sabbath

"on the Jewish Day of Rest"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]

### John 07:23

#### If a man receives circumcision on the Sabbath so that the law of Moses is not broken

"If you circumcise a male baby on the Sabbath so that you do not break the law of Moses"

#### why are you angry with me because I made a man completely healthy on the Sabbath?

This remark appears in the form of a question to add emphasis. AT: "you should not be angry with me because I made a man completely well on the Sabbath!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### on the Sabbath

"on the Jewish Day of Rest?"

#### Do not judge according to appearance, but judge righteously

Jesus implies that the people should not decide what is right, based only on what they can see. Behind the action is a motive that cannot be seen. AT: "Stop judging people according to what you see! Be more concerned with what is right according to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### John 07:25

#### Is not this the one they seek to kill?

This remark appears in the form of a question to add emphasis. AT: "This is Jesus whom they are seeking to kill!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### they say nothing to him

This implies that the Jewish leaders are not opposing Jesus. AT: "they say nothing to oppose him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It cannot be that the rulers indeed know that this is the Christ, can it?

This remark appears in the form of a question to add emphasis. AT: "Maybe they have decided that he is truly the Messiah!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### John 07:28

#### cried out

"spoke in a loud voice"

#### in the temple

Jesus and the people were actually in the courtyard of the temple. AT: "in the temple courtyard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You both know me and know where I come from

John uses irony in this statement. The people believe that Jesus is from Nazareth. They do not know that God sent him from heaven and that he was born in Bethlehem. AT: "You all know me and you think you know where I come from" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### of myself

"on my own authority." See how you translated "of himself" in [John 5:19](../05/19.md).

#### he who sent me is true

"God is the one who sent me and he is true"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 07:30

#### his hour had not yet come

The word "hour" is a metonym that represents the right time for Jesus to be arrested, according to God's plan. AT: "it was not the right time to arrest him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### When the Christ comes, will he do more signs than what this one has done?

This remark appears in the form of a question to add emphasis. AT: "When the Christ comes, surely he will not be able to do more signs than this man has done!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### signs

This refers to the miracles that prove that Jesus is the Christ.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]

### John 07:33

#### I am still with you for a short amount of time

"I will remain with you for only a short period of time"

#### then I go to him who sent me

Here Jesus refers to God the Father, who sent him.

#### where I go, you will not be able to come

"you will not be able to come to the place where I am"

### John 07:35

#### The Jews therefore said among themselves

The "Jews" is a synecdoche that represents the leaders of the Jews who opposed Jesus. AT: "The Jewish leaders said among themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the dispersion

This refers to the Jews that were spread all across the Greek world, outside of Palestine.

#### What is this word that he said

This "word" is a metonym which stands for the meaning of the message that Jesus had shared, which the Jewish leaders had failed to understand. AT: "What is he talking about when he said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]

### John 07:37

#### General Information:

Some time has passed. It is now the last day of the festival and Jesus speaks to the crowd.

#### great day

It is "great" because it is the last, or most important, day of the festival.

#### If anyone is thirsty

Here the word "thirsty" is a metaphor that means one's great desire for the things of God, just as one "thirsts" for water. AT: "Those who desire the things of God like a thirty man desires water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### let him come to me and drink

The word "drink" is a metaphor that means to receive the spiritual life that Jesus provides. AT: "let him come to me and quench his spiritual thirst" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He who believes in me, just as the scripture says

"As the scripture says about anyone who believes in me"

#### rivers of living water will flow

The "rivers of living water" is a metaphor that represents the life that Jesus provides for those who are spiritually "thirsty." AT: "spiritual life will flow like rivers of water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### living water

Possible meanings are 1) "water that gives life" or 2) "water that causes people to live." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from his stomach

Here the stomach represents the inside of a person, specifically the non-physical part of a person. AT: "from inside of him" or "from his heart" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]

### John 07:39

#### General Information:

In this verse the author gives information to clarify what Jesus is talking about. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### But he

Here "he" refers to Jesus.

#### the Spirit had not yet been given

John implies that the Spirit would later come to live in those who trusted Jesus. AT: "the Spirit had not yet come to live in the believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### because Jesus was not yet glorified

Here the word "glorified" refers to the time when God would honor the Son after his death and resurrection.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### John 07:40

#### This is indeed the prophet

By saying this, the people are indicating that they believe Jesus is the prophet like Moses that God had promised to send. AT: "This is indeed the prophet who is like Moses that we have been waiting for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Does the Christ come from Galilee?

This remark appears in the form of a question to add emphasis. AT: "The Christ cannot come from Galilee!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Have the scriptures not said that the Christ will come from the descendants of David and from Bethlehem, the village where David was?

This remark appears in the form of a question to add emphasis. AT: "The scriptures teach that Christ will come from the line of David and from Bethlehem, the village where David was!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Have the scriptures not said

The scriptures are referred to as if they were actually speaking as a person speaks. AT: "The prophets wrote in the scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### where David was

"where David lived"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]

### John 07:43

#### So there arose a division in the crowds because of him

The crowds could not agree about who or what Jesus was.

#### but no one laid hands on him

To lay hands on someone is an idiom which means to grab him or to hold onto him. AT: "but no one grabbed him to arrest him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

### John 07:45

#### officers

"temple guards"

#### Never has anyone spoken like this

The officers exaggerate to show how impressed they are by what Jesus said. You may need to make explicit that the officer were not claiming to know everything that every person in all times and places had ever said. "We have never heard anyone say such amazing things as this man!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]

### John 07:47

#### So the Pharisees

"Because they said that, the Pharisees"

#### answered them

"answered the officers"

#### Have you also been deceived?

The remark appears in the form of a question to add emphasis. The Pharisees are shocked at the response of the officers. AT: "You have been deceived too!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Have any of the rulers believed in him, or any of the Pharisees?

This remark appears in the form of a question to add emphasis. AT: "None of the rulers or Pharisees have believed in him!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the law

This is a reference to the law of the Pharisees and not the law of Moses.

#### But this crowd that does not know the law, they are cursed

"As for this crowd that does not know the law, God will cause them to perish!"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### John 07:50

#### one of the Pharisees, who came to him earlier

John provides this information to remind us of who Nicodemus is. Your language may have a special way to mark background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Does our law judge a man ... what he does?

This remark appears in the form of a question to add emphasis. This can be translated as a statement. AT: "Our Jewish law does not allow us to judge a man ... what he does!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Does our law judge a man

Here Nicodemus speaks of the law as if it were a person. If this is not natural in your language, you may translate it with a personal subject. AT: "Do we judge a man" or "we do not judge a man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Are you also from Galilee?

The Jewish leaders know that Nicodemus is not from Galilee. They ask this question as a way of scoffing at him. AT: "You must also be one of those inferior persons from Galilee!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Search and see

This is an ellipsis. You may wish to include the information that does not appear. AT: "Search carefully and read what is written in the Scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### no prophet comes from Galilee

This probably refers to the belief that Jesus was born in Galilee.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### John 07:53

#### General Information:

The best early texts do not have 7:53 - 8:11. The ULB has set them apart in square brackets ([ ]) to show that John probably did not include them in his original text. Translators are encouraged to translate them, to set them apart with square brackets, and to include a footnote like the one written on [John 7:53](../07/53.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])

### John 07:intro

#### John 07 General Notes ####

####### Structure and formatting #######

This whole chapter revolves around the concept of believing Jesus to be the Messiah. Some people believed this to be true while others rejected it. Some were willing to recognize his power and even the possibility that he was a prophet, but most were unwilling to believe that he was the Messiah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

Translators may wish to include a note at verse 53 to explain to the reader why they have chosen or chosen not to translate verses 7:53-8:11.

####### Special concepts in this chapter #######

######## "My time has not yet come" ########
This phrase and "his hour had not yet come" are used in this chapter to indicate that Jesus is in control of the events unfolding in his life. 

######## "Living water" ########
This is an important image used in the New Testament. It is a metaphor. Because this metaphor is given in a desert environment, it probably emphasizes that Jesus is able to give life sustaining nourishment. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]) 

####### Important figures of speech in this chapter #######

######## Prophecy ########
Jesus gives a prophecy about his life without an explicit statement in John [John 7:33-34](./33.md). 

######## Irony ########
Nicodemus explains to the other Pharisees that the Law requires him to hear directly from a person before making a judgment about them. The Pharisees in turn made a judgment about Jesus without speaking to Jesus. 

####### Other possible translation difficulties in this chapter #######

######## "Did not believe in him" ########
Jesus' brothers did not believe Jesus was the Messiah. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]])

######## "The Jews" ########
This term is used in two different ways in this passage. It is used specifically in reference to the opposition of the Jewish leaders who were trying to kill him ([John 7:1](./01.md)). It is also used in reference to the people of Judea in general who had a positive opinion of Jesus ([John 7:13](./12.md)). The translator may wish to use the terms "Jewish leaders" and "Jewish people" or "Jews (leaders)" and "Jews (in general)."

##### Links: #####

* __[John 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## John 08

### John 08:01

#### Connecting Statement:

Verse 1 tells us where Jesus went at the end of the previous chapter.

#### General Information:

While some texts have 7:53 - 8:11, the best and earliest texts do not include them.

#### General Information:

The next part of the story begins in verse 2 as Jesus has returned to the temple.

#### all the people

This is a general way of speaking. It means "many people."

#### The scribes and the Pharisees brought

Here the phrase "the scribes and the Pharisees" is a synecdoche that represents some of the members of these two groups. AT: "Some scribes and Pharisees brought" or "Some men who taught the Jewish laws and some who were Pharisees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### a woman caught in the act of adultery

This is a passive statement. You may translate it in an active form. AT: "a woman whom they had found committing adultery" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mountofolives.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]

### John 08:04

#### General Information:

While some texts have 7:53 - 8:11, the best and earliest texts do not include them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])

#### such people

"people like that" or "people who do that"

#### what do you say about her?

"So you tell us. What should we do about her?"

#### to trap him

This means to use a trick question.

#### so that they might have something to accuse him about

What they would accuse him of can be made explicit. AT: "so that they could accuse him of saying something wrong" or "so that they could accuse him of not obeying the law of Moses or the Roman law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### John 08:07

#### General Information:

While some texts have 7:53 - 8:11, the best and earliest texts do not include them.

#### When they continued

The word "they" refers to the scribes and Pharisees.

#### The one among you who has no sin

The abstract noun "sin" can be expressed with the verb sin. AT: "The one among you is has never sinned" or "If any one of you has never sinned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### let him

"let that person"

#### he stooped down

"he bent down"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### John 08:09

#### General Information:

While some texts have 7:53 - 8:11, the best and earliest texts do not include them.

#### one by one

"one after another"

#### Woman, where are your accusers

When Jesus called her "woman," he was not trying to make her feel insignificant. If people in your language group would think that he was doing that, this can be translated without the word "Woman."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 08:12

#### General Information:

Jesus is speaking to a crowd near the treasury in the temple after either the events of [John 7:1-52](../07/50.md) or the events of [John 7:53-8:11](../07/53.md). The author neither gives background to this event nor marks the beginning of a new event. See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### I am the light of the world

Here the "light" is a metaphor for the revelation that comes from God. AT: "I am the one who gives light to the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the world

This is a metonym for the people. AT: "the people of the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he who follows me

This is an idiom that means "everyone who does what I teach" or "everyone who obeys me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will not walk in the darkness

To "walk in darkness" is a metaphor for living a sinful life. AT: "will not live as if he were in the darkness of sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### light of life

The "light of life" is a metaphor for the truth from God that gives spiritual life. AT: "truth that brings eternal life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You bear witness about yourself

"You are just saying these things about yourself"

#### your witness is not true

The Pharisees are implying that the witness of only one person is not true because it cannot be verified. AT: "you cannot be your own witness" or "what you say about yourself may not be true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 08:14

#### Even if I bear witness about myself

"Even if I say these things about myself"

#### the flesh

"human standards and the laws of men"

#### I judge no one

Possible meanings are 1) "I do not judge anyone yet" or 2) "I am not judging anyone now."

#### if I judge

Possible meanings are 1) "if I judge people" or 2) "whenever I judge people"

#### my judgment is true

Possible meanings are 1) "my judgment will be right" or 2) "my judgment is right."

#### I am not alone, but I am with the Father who sent me

Jesus, the Son of God, has authority because of his special relationship with his Father. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I am not alone

The implied information is that Jesus is not alone in his judgment. AT: "I am not alone in how I judge" or "I do not judge alone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I am with the Father

The Father and the Son judge together. AT: "the Father also judges with me" or "the Father judges as I do"

#### the Father

This is an important title for God. If your language must state whose Father this is, you could say "my Father" since Jesus switches to that in the following verses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### John 08:17

#### Connecting Statement:

Jesus continues speaking to the Pharisees and other people about himself.

#### Yes, and in your law

The word "Yes" shows that Jesus is adding to what he was saying before.

#### it is written

This is a passive phrase. You may translate it in an active form with a personal subject. AT: "Moses wrote" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the testimony of two men is true

The logic implied here is that one person can verify the words of another. AT: "if two men say the same thing, then people know it is true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I am he who bears witness about myself

Jesus bears witness about himself. AT: "I give evidence to you about myself"

#### the Father who sent me bears witness about me

The Father also bears witness about Jesus. You could make it explicit that this means Jesus' testimony is true. AT: "my Father who sent me also brings evidence about me. So you should believe that what we tell you is true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Father

This is an important title for God. If your language must state whose Father this is, you could say "my Father" since Jesus switches to that in the following verses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 08:19

#### General Information:

In verse 20 there is a break in Jesus' speaking where the author give us background information regarding where Jesus had been teaching. Some languages may require the information about the setting to be placed at the beginning of this part of the story in [John 8:12](./12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### You know neither me nor my Father; if you had known me, you would have known my Father also

Jesus indicates that to know him is to also know the Father. Both Father and Son are God. "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### my Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### his hour had not yet come

The word "hour" is a metonym for the time for Jesus to die. AT: "it was not yet the right time for Jesus to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]

### John 08:21

#### Connecting Statement:

Jesus continues speaking to the crowd.

#### die in your sin

Here the word "die" refers to spiritual death. AT: "die while you are still sinful" or "you will die while you are sinning"

#### you cannot come

"you are not able to come"

#### The Jews said

Here "Jews" is a synecdoche for "the Jewish leaders." AT: "The Jewish leaders said" or "The Jewish authorities said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### John 08:23

#### You are from below

"You were born in this world"

#### I am from above

"I came from heaven"

#### You are of this world

"You belong to this world"

#### I am not of this world

"I do not belong to this world"

#### you will die in your sins

"you will die without God's forgiving your sins"

#### that I AM

Possible meanings are that 1) Jesus was identifying himself as Yahweh, which means "I am" or 2) Jesus expected the people to understand that he was referring to what he already said he was: "I am from above."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 08:25

#### They said

The word "They" refers to the Jewish leaders. (See: [John 8:22](./21.md))

#### these things I say to the world

Here the "world" is a metonym for the people who live in the world. AT: "these things I say to all the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Father

This is a special title for God. Some languages may require the use of a possessive before the noun. AT: "his Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 08:28

#### When you have lifted up

This refers to placing Jesus on the cross to kill him.

#### Son of Man

Jesus used the title "Son of Man" to refer to himself.

#### I AM

As God the Son, Jesus knows God the Father unlike anyone else. Possible meanings are 1) Jesus was identifying himself as Yahweh by saying, "I am God" or 2) Jesus was saying, "I am the one I claim to be."

#### As the Father taught me, I speak these things

"I am only saying what my Father taught me to say." The word "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### He who sent me

The word "He" refers to God.

#### As Jesus was saying these things

"As Jesus spoke these words"

#### many believed in him

"many people trusted him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teach.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 08:31

#### remain in my word

This is an idiom that means "to obey Jesus." AT: "obey what I have said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my disciples

"my followers"

#### the truth will set you free

This is personification. Jesus speaks of "the truth" as if it were a person. AT: "if you obey the truth, God will set you free" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the truth

This refers to what Jesus reveals about God. AT: "what is true about God"

#### how can you say, 'You will be set free'?

This remark appears in the form of a question to express the Jewish leaders' shock at what Jesus has said. AT: "We do not need to be set free!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### free

"Free" here is an idiom for having the ability to do as one wants. AT: "able to do what one wants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### John 08:34

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### is the slave of sin

Here the word "slave" is a metaphor. This implies that "sin" is like a master for the one who sins. AT: "is like a slave to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the house

Here "house" is a metonym for "family." AT: "as a permanent member of a family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the son remains forever

This is an ellipsis. You may translate it by including the implied words. AT: "the son is a member of the family forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### if the Son sets you free, you will be truly free

Jesus speaks of himself in the third person. "Free" here is an idiom for the ability to do as one desires. AT: "if you allow me to set you free, you will truly be free" or "if the Son gives you the ability to do as you desire, you will truly be able to do as you desire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Son

This is an important title for Jesus, the Son of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### John 08:37

#### Connecting Statement:

Jesus continues speaking to the Jews.

#### my word has no place in you

Here "word" is a metonym for the "teachings" or "message" of Jesus, which the Jewish leaders do not accept. AT: "you do not accept my teachings" or "you do not allow my message to change your life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I say what I have seen with my Father

"I am telling you about the things I saw when I was with my Father"

#### you also do what you heard from your father

The Jewish leaders do not understand that by "your father" Jesus is referring to the devil. AT: "you also continue doing what your father has told you to do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### John 08:39

#### father

"forefather"

#### Abraham did not do this

"Abraham never tried to kill anyone who told him the true revelation from God"

#### You do the works of your father

Jesus implies that their father is the devil. AT: "No! You are doing the things that your real father did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### We were not born in sexual immorality

Here the Jewish leaders imply that Jesus does not know who his real father is. AT: "We do not know about you, but we are not illegitimate children" or "We were all born from proper marriages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### we have one Father: God

Here the Jewish leaders claim God as their spiritual Father. This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 08:42

#### love

This is the kind of love that comes from God and is focused on the good of others (including those who are our enemies), even when it does not benefit oneself.

#### Why do you not understand my words?

Jesus is using this question mainly to rebuke the Jewish leaders for not listening to him. AT: "I will tell you why you do not understand what I say!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### It is because you cannot hear my words

Here "words" is a metonym for the "teachings" of Jesus. AT: "It is because you will not accept my teachings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You are of your father, the devil

"You belong to your father, Satan"

#### the father of lies

Here "father" is a metaphor for the one who originates all lies. AT: "he is the one who created all lies in the beginning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 08:45

#### Connecting Statement:

Jesus continues speaking to the Jews.

#### because I speak the truth

"because I tell you true things about God"

#### Which one of you convicts me of sin?

Jesus uses this question to emphasize that he has never sinned. AT: "None of you can show that I have ever sinned!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### If I speak the truth

"If I say things that are true"

#### why do you not believe me?

Jesus uses this question to scold the Jewish leaders for their unbelief. AT: "you have no reason for not believing in me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the words of God

Here "words" is a metonym for the "message" of God. AT: "the message of God" or "the truth that comes from God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 08:48

#### The Jews

The "Jews" is a synecdoche that represents the "Jewish leaders" who opposed Jesus. AT: "The Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Do we not truly say that you are a Samaritan and have a demon?

The Jewish leaders use this question to accuse Jesus and to dishonor him. AT: "We are certainly right in saying that you are a Samaritan and that a demon lives in you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dishonor.md)]]

### John 08:50

#### Connecting Statement:

Jesus continues answering the Jews.

#### there is one seeking and judging

This refers to God.

#### Truly, truly

See how you translated this in [John 01:51](../01/49.md).

#### keeps my word

Here "word" is a metonym for the "teachings" of Jesus. AT: "obeys my teachings" or "does what I say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### see death

This is an idiom that means to experience death. Here Jesus is referring to spiritual death. AT: "die spiritually" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 08:52

#### Jews

Here "Jews" is a metonym for the "Jewish leaders" who opposed Jesus. AT: "Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### If anyone keeps my word

"Word" here is a synecdoche for the entire message of Jesus. AT: "If anyone obeys my teaching" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### taste death

This is an idiom that means to experience death. The Jewish leaders mistakenly assume that Jesus is speaking only about physical death. AT: "die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### You are not greater than our father Abraham who died, are you?

The Jewish leaders use this question to emphasize that Jesus is not greater than Abraham. AT: "You are certainly not greater than our father Abraham who indeed died!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### father

"forefather"

#### Who do you make yourself out to be?

The Jews use this question to rebuke Jesus for thinking that he is more important than Abraham. AT: "You should not think that you are so important!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### John 08:54

#### it is my Father who glorifies me—about whom you say that he is your God

The word "Father" is an important title for God. No one knows God the Father like Jesus, the Son of God. AT: "it is my Father who honors me, and you say that he is your God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### keep his word

Here "word" is a metonym for what God says. AT: "I obey what he says to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### my day

This is a metonym for what Jesus would accomplish during his life. AT: "what I would do during my life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he saw it and was glad

"he foresaw my coming through God's revelation and he rejoiced"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### John 08:57

#### Connecting Statement:

This is the end of the part of the story about Jesus speaking with the Jews in the temple, which began in [John 8:12](./12.md).

#### The Jews said to him

Here the "Jews" is a synecdoche for the "Jewish leaders" who opposed Jesus. AT: "The Jewish leaders said to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### You are not yet fifty years old, and you have seen Abraham?

The Jewish leaders use this question to express their shock that Jesus claims to have seen Abraham. AT: "You are less than fifty years old. You could not have seen Abraham!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### before Abraham was, I AM

As God the Son, Jesus knows God the Father unlike anyone else. Possible meanings are 1) Jesus was identifying himself as Yahweh by saying, "I am God" or 2) Jesus was saying, "before Abraham existed, I existed."

#### Then they picked up stones to throw at him

The Jewish leaders are outraged at what Jesus has said. Here it is implied that they wanted to kill him because he had made himself equal to God. AT: "Then they picked up stones to kill him because he claimed to be equal with God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### John 08:intro

#### John 08 General Notes ####

####### Structure and formatting #######

Translators may wish to include a note at verse 1 to explain to the reader why they have chosen to or chosen not to translate verses 8:1-11. Because this is a controversial passage, it is best not to build theological conclusions from this passage.

####### Special concepts in this chapter #######

######## Light ########
Light is a common image in Scripture used to represent righteousness. Light is also used to show the path of righteousness and to show righteous living. Darkness is often used as images representing sin or unrighteousness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md)]])

######## "I am ... " ########

John uses this phrase seven times in his gospel. It is the same words used by God, when he revealed himself and his name Yahweh at the burning bush. The name "Yahweh" can be translated as "I am."

######## "A woman caught in the act of adultery" ########
If the woman was caught in the act of adultery, there was a man who was also caught in the act of adultery. The man is noticeably absent from this account. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Other possible translation difficulties in this chapter #######

######## "Son of Man" ########

Jesus refers to himself as the "Son of Man" in this passage. Some languages may not allow a person to refer to himself in the third person.

##### Links: #####

* __[John 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## John 09

### John 09:01

#### General Information:

As Jesus and his disciples are walking along, they come across a blind man.

#### Now

This word shows that the author is about to describe a new event. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### as Jesus passed by

Here "Jesus" is a synecdoche for Jesus and the disciples. AT: "as Jesus and his disciples passed by" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### who sinned, this man or his parents ... blind?

This question reflects the ancient Jewish belief that sin caused all illnesses and other deformities. The rabbis also taught that it was possible for a baby to sin while still in the womb. AT: "Teacher, we know that sin causes a person to be blind. Whose sin caused this man to be born blind? did this man himself sin, or was it his parents who sinned?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### John 09:03

#### We

This "We" includes both Jesus and the disciples he is talking to. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### day ... Night

Here "day" and "night" are metaphors. Jesus is comparing the time when people can do God's work to daytime, the time when people normally work, and nighttime to when they cannot do God's work. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the world

Here the "world" is a metonym for the people who live in the world. AT: "living among the people of this world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### light of the world

Here "light" is a metaphor for the true revelation of God. AT: "the one who shows what is true just as light allows people to see what is in the darkness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 09:06

#### made mud with the saliva

Jesus used his fingers to mix the dirt and saliva. AT: "and used his fingers to mix the dirt and saliva to make mud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### which is translated "Sent"

A brief break occurs here in the story line so John can explain to his readers what "Siloam" means. AT: "which means 'Sent'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### washed

"washed his eyes in the pool"

### John 09:08

#### Is not this the man that used to sit and beg?

This remark appears in the form of a question to express the surprise of the people. AT: "This man is the one who used to sit and beg!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]

### John 09:10

#### Connecting Statement:

The neighbors of the man who had been blind continue to speak to him.

#### Then how were your eyes opened?

"Then what caused you to be able to see?" or "How is it that you can see now?"

#### smeared it on my eyes

"used his fingers to cover my eyes with mud." See how you translated a similar phrase in [John 9:6](./06.md).

### John 09:13

#### General Information:

Verse 14 tells background information about when Jesus healed the man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### They brought the man who used to be blind to the Pharisees

The people insisted that the man go with them to the Pharisees. They did not physically force him to go.

#### Sabbath day

"Jewish Day of Rest"

#### Then again the Pharisees asked him

"So the Pharisees also asked him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 09:16

#### General Information:

In verse 18 there is a break from the main story line as John provides background information about the Jews' disbelief. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### he does not keep the Sabbath

This means Jesus does not obey the law about doing no work on the Jewish Day of Rest.

#### How can a man who is a sinner do such signs?

This remark appears in the form of a question to emphasize that Jesus' signs prove he is not a sinner. AT: "A sinner can not do such signs!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### signs

This is another word for miracles. "Signs" give evidence that God is the all-powerful one who has complete authority over the universe.

#### He is a prophet

"I think he is a prophet"

#### Now the Jews still did not believe

Here "Jews" is a synecdoche for the "Jewish leaders" who opposed Jesus. AT: Now the Jewish leaders still did not believe. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### John 09:19

#### They asked the parents

"They" refers to the Jewish leaders.

#### he is an adult

"he is a man" or "he is no longer a child"

### John 09:22

#### General Information:

In verse 22 there is a break from the main story line as John provides background information about the man's parents being afraid of the Jews. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### they were afraid of the Jews

Here "Jews" is a synecdoche for the "Jewish leaders" who opposed Jesus. AT: "they were afraid of what the Jewish leaders might do to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### afraid

This refers to the unpleasant feeling a person has when there is a threat of harm to oneself or others.

#### would confess him to be the Christ

"would say that Jesus is the Christ"

#### he would be thrown out of the synagogue

Here "be thrown out of the synagogue" is a metaphor for no longer being allowed to go into the synagogue and no longer belonging to the group of people who attend services at the synagogue. AT: "he would not be allowed to go into the synagogue" or "he would no longer belong to the synagogue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He is an adult

"he is a man" or "he is no longer a child." See how you translated this in [John 09:21](./19.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]

### John 09:24

#### they called the man

Here, "they" refers to the Jews. ([John 9:18](./16.md))

#### Give glory to God

This is an idiom that people used when taking an oath. AT: "In the presence of God, tell the truth" or "Speak the truth before God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### this man

This refers to Jesus.

#### that man

This refers to the man who had been blind.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### John 09:26

#### Connecting Statement:

The Jews continue to speak to the man who had been blind.

#### Why do you want to hear it again?

This remark appears in the form of a question to express the man's amazement that the Jewish leaders have asked him to tell them again what happened. AT: "I am surprised that you want to hear again what happened to me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You do not want to become his disciples too, do you?

This remark appears in the form of a question to add irony to the man's statement. He knows that the Jewish leaders do not want to follow Jesus. Here he ridicules them. AT: "It sounds like you also want to become his disciples!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 09:28

#### You are his disciple

"You are following Jesus!"

#### but we are disciples of Moses

The pronoun "we" is exclusive. The Jewish leaders are speaking only of themselves. AT: "but we are following Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### We know that God has spoken to Moses

"We are sure that God has spoken to Moses"

#### we do not know where this one is from

Here the Jewish leaders are referring to Jesus. They imply that he has no authority to call disciples. AT: "we do not know where he comes from or where he gets his authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### John 09:30

#### that you do not know where he is from

The man is surprised that the Jewish leaders question Jesus' authority when they know he has the power to heal. AT: "that you do not know where he gets his authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### does not listen to sinners ... listens to him

"does not answer the prayers of sinners ... God answers his prayers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### John 09:32

#### Connecting Statement:

The man who had been blind continues speaking to the Jews.

#### it has never been heard that anyone opened

This is a passive statement. You can translate it in an active form. AT: "no one has ever heard of anyone who healed a man who was blind from birth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### If this man were not from God, he could do nothing

This sentence uses a double negative pattern. "Only a man from God could do something like that!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### You were completely born in sins, and you are teaching us?

This remark appears in the form of a question to add emphasis. It also implies that the man was born blind because of the sins of his parents. AT: "You were born as a result of your parents' sins. You are not qualified to teach us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### they threw him out

"they threw him out of the synagogue"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### John 09:35

#### General Information:

Jesus finds the man whom he healed ([John 9:1-7](../01.md)) and begins to speak to him and the crowd.

#### believe in

This means to "believe in Jesus," to believe that he is the Son of God, to trust him as Savior, and live in a way that honors him.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### John 09:39

#### came into this world

The "world" is a metonym for "the people who live in the world." AT: "came to live among the people of this world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that those who do not see may see and so that those who see may become blind

Here "seeing" and "blindness" are metaphors. Jesus distinguishes between people who are spiritually blind and physically blind. AT: "so that those who are blind spiritually, but who want to see God, can see him, and those who already falsely think they can see God will remain in their blindness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Are we also blind?

"Do you think we are spiritually blind?"

#### If you were blind, you would have no sin

Here "blindness" is a metaphor for not knowing God's truth. AT: "If you wanted to know God's truth, you would be able to receive your sight. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### but now you say, 'We see,' so your sin remains

Here "seeing" is a metaphor for knowing God's truth. AT: "Since you falsely think that you already know God's truth, you will remain blind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### John 09:intro

#### John 09 General Notes ####

####### Special concepts in this chapter #######

######## "Who sinned?" ########
In ancient Israel, it was commonly believed that a child was born with disabilities because of the sin of one of his parents. This was not the teaching of the law of Moses. In this exchange, the Pharisees were sinners because they saw the power of Jesus and did not worship him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

######## "I am ... " ########

John uses this phrase seven times in his gospel. It is the same words used by God, when he revealed himself and his name Yahweh at the burning bush. The name "Yahweh" can be translated as "I am."

######## Light ########
Light is a common image in Scripture used to represent righteousness. Light is also used to show the path of righteousness and to show righteous living. Darkness is often used as images representing sin or unrighteousness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md)]])

######## "He does not keep the Sabbath" ########
The Pharisees considered Jesus making the mud to be "work" and in violation of the laws regarding the Sabbath. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]])

####### Important figures of speech in this chapter #######

######## Sight ########
This chapter records the events of a man who was born without sight. Jesus also uses these events as a metaphor. In [John 9:39-40](./39.md), the Pharisees are called blind because they are unable to see the truth in front of them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## "Son of Man" ########

Jesus refers to himself as the "Son of Man" in this passage. Some languages may not allow a person to refer to himself in the third person. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]])

##### Links: #####

* __[John 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## John 10

### John 10:01

#### Connecting Statement:

Jesus continues to speak to the Pharisees. This is the same part of the story which began in [John 9:35](../09/35.md).

#### General Information:

Jesus begins to speak in parables. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### sheep pen

This is a fenced area where a shepherd keeps his sheep.

#### a thief and a robber

This is the use of two words with similar meanings to add emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### John 10:03

#### The gatekeeper opens for him

"The gatekeeper opens the gate for the shepherd"

#### The gatekeeper

This is a hired man who watches the gate of the sheep pen at night while the shepherd is away.

#### The sheep hear his voice

"The sheep hear the shepherd's voice"

#### he goes ahead of them

"he walks in front of them"

#### for they know his voice

"because they recognize his voice"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### John 10:05

#### they did not understand

Possible meanings: 1) "the disciples did not understand" or 2) "the crowd did not understand."

#### this parable

This is an illustration from the work of shepherds, using metaphors. The "shepherd" is a metaphor for Jesus. The "sheep" represent those who follow Jesus, and the "strangers" are the Jewish leaders, including the Pharisees, who try to deceive the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/parable.md)]]

### John 10:07

#### Connecting Statement:

Jesus begins to explain the meaning of the parables he had spoken.

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### I am the gate of the sheep

Here "gate" is a metaphor that means Jesus provides access into the sheepfold where God's people dwell in his presence. AT: "I am like the gate that the sheep use to enter into the sheepfold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Everyone who came before me

This refers to other teachers who have taught the people, including the Pharisees and other Jewish leaders. AT: "All of the teachers who came without my authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a thief and a robber

These words are metaphors. Jesus calls those teachers "a thief and a robber" because their teachings were false, and they were trying to lead God's people while not understanding the truth. As a result, they deceived the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### John 10:09

#### I am the gate

Here "gate" is a metaphor. By referring to himself as "the gate," Jesus is showing that he offers a true way to enter the kingdom of God. AT: "I myself am like that gate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### pasture

The word "pasture" means a grassy area where sheep eat.

#### does not come if he would not steal

This is a double negative. In some languages it is more natural to use a positive statement. AT: "comes only to steal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### steal and kill and destroy

Here the implied metaphor is "sheep," which represents God's people. AT: "steal and kill and destroy the sheep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so that they will have life

The word "they" refers to the sheep. "Life" refers to eternal life. AT: "so that they will really live, lacking nothing"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 10:11

#### Connecting Statement:

Jesus continues his parable about the good shepherd.

#### I am the good shepherd

Here "good shepherd" is a metaphor that represents Jesus. AT: "I am like a good shepherd" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lays down his life

To lay down something means to give up control of it. It is a mild way to refer to dying. AT: "dies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### The hired servant

The "hired servant" is a metaphor that represents the Jewish leaders and teachers. AT: "The one who is like a hired servant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### abandons the sheep and ... does not care for the sheep

Here the word "sheep" is a metaphor that represents God's people. Like a hired servant who abandons the sheep, Jesus says that the Jewish leaders and teachers do not care for God's people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wolf.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wolf.md)]]

### John 10:14

#### I am the good shepherd

Here the "good shepherd" is a metaphor for Jesus. AT: "I am like a good shepherd" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The Father knows me, and I know the Father

God the Father and God the Son know each other unlike anyone else knows them. "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I lay down my life for the sheep

This is a mild way for Jesus to say that he will die to protect his sheep. AT: "I die for the sheep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### I have other sheep

Here "other sheep" is a metaphor for followers of Jesus who are not Jews. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### one flock and one shepherd

Here "flock" and "shepherd" are metaphors. All of Jesus's followers, Jews and non-Jews, will be like one flock of sheep. He will be like a shepherd who cares for all of them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]

### John 10:17

#### Connecting Statement:

Jesus finishes speaking to the crowd.

#### This is why the Father loves me: I lay down my life

God's eternal plan was for God the Son to give his life to pay for the sins of humanity. Jesus' death on the cross reveals the intense love of the Son for the Father and of the Father for the Son.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### loves

This kind of love comes from God and is focused on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### I lay down my life so that I may take it again

This is a mild way for Jesus to say he will die and then will become alive again. AT: "I allow myself to die in order that I may bring myself back to life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### I lay it down of myself

The reflexive pronoun "myself" is used here to emphasize that Jesus lays down his own life. No one takes it from him. AT: "I myself lay it down" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### I have received this command from my Father

"This is what my Father has commanded me to do." The word "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### John 10:19

#### Connecting Statement:

These verses tell how the Jews responded to what Jesus had said.

#### Why do you listen to him?

This remark appears in the form of a question to emphasize the point that the people should not listen to Jesus. AT: "Do not listen to him!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Can a demon open the eyes of the blind?

This remark appears in the form of a question to add emphasis. AT: "Certainly a demon cannot cause a blind man to see!" or "Certainly a demon cannot give sight to blind people!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demonpossessed.md)]]

### John 10:22

#### General Information:

During the Festival of Dedication, some Jews begin to question Jesus. Verses 22 and 23 give background information about the setting of the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Festival of the Dedication

This is an eight-day, winter holiday Jews use to remember a miracle where God made a small amount of oil remain lit in a lampstand for eight days. They lit the lampstand to dedicate the Jewish temple to God. To dedicate something is to promise to use it for a special purpose.

#### Jesus was walking in the temple

The area where Jesus was walking was actually a courtyard that was outside the temple building. AT: "Jesus was walking in the temple courtyard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### porch

This is a structure attached to the entrance of a building; it has a roof and it may or may not have walls.

#### Then the Jews surrounded him

Here "Jews" is a synecdoche for the Jewish leaders who opposed Jesus. AT: "Then the Jewish leaders surrounded him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### hold us doubting

This is an idiom. AT: "keep us wondering" or "keep us from knowing for sure?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### John 10:25

#### Connecting Statement:

Jesus begins to respond to the Jews.

#### in the name of my Father

Here "name" is a metonym for the power of God. Here "Father" is an important title for God. Jesus performed miracles through his Father's power and authority. AT: "through my Father's power" or "with my Father's power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### these testify concerning me

His miracles offer proof about him like a person who testifies would offer proof in a court of law. AT: "offer proof concerning me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### not my sheep

The word "sheep" is a metaphor for the followers of Jesus. AT: "not my followers" or "not my disciples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### John 10:27

#### My sheep hear my voice

The word "sheep" is a metaphor for the followers of Jesus. The metaphor of Jesus as the "shepherd" is also implied. AT: "Just as sheep obey the voice of their true shepherd, my followers heed my voice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### no one will snatch them out of my hand

Here the word "hand" is a metonym that represents the protective care of Jesus. AT: "no one will steal them away from me" or "they will remain secure forever in my care" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 10:29

#### My Father, who has given them to me

The word "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### the hand of the Father

The word "hand" is a metonym that refers to God's possession and protective care. AT: "No one can steal them from my Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I and the Father are one

Jesus, God the Son, and God the Father are one. The word "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Then the Jews took up stones

The word "Jews" is a synecdoche for the Jewish leaders who opposed Jesus. AT: "Then the Jewish leaders started picking up stones again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]

### John 10:32

#### Jesus answered them, "I have shown you many good works from the Father

Jesus performed the miracles by the power of God. The word "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### For which of those works are you stoning me?

This question uses irony. Jesus knows the Jewish leaders do not want to stone him because he has done good works. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### The Jews answered him

The word "Jews" is a synecdoche that represents the Jewish leaders who opposed Jesus. AT: "The Jewish opponents replied" or "The Jewish leaders answered him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### making yourself God

"claiming to be God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 10:34

#### Is it not written ... gods"'?

This remark appears in the form of a question to add emphasis. AT: "You should already know that it is written in your law that I said, 'you are gods.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You are gods

Here Jesus quotes a scripture where God calls his followers "gods," perhaps because he has chosen them to represent him on earth.

#### the word of God came

This idiom is used to explain that God gave a message to someone. AT: "Yahweh gave his message" or "Yawheh spoke a message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the scripture cannot be broken

Possible meanings are 1) "no one can change the scripture" or 2) "the scripture will always be true."

#### do you say to him whom the Father set apart and sent into the world, 'You are blaspheming,' because I said, 'I am the Son of God'?

Jesus used this question to rebuke his opponents for saying that he was blaspheming when he called himself "the Son of God." AT: "you should not say to the very one whom the Father set apart to send into the world, 'You are blaspheming,' when I say that I am the Son of God!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You are blaspheming

"You are insulting God." Jesus' opponents understood that when said that he is the Son of God, he was implying that he is equal with God.

#### Father ... Son of God

These are important titles that describe the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### John 10:37

#### Connecting Statement:

Jesus finishes responding to the Jews.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### believe me

Here the word "believe" means to accept or trust what Jesus said is true.

#### believe in the works

Here "believe in" is to acknowledge that the works Jesus does are from the Father.

#### the Father is in me and that I am in the Father

These are idioms that express the close personal relationship between God and Jesus. AT: "My Father and I are completely joined together as one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### went away out of their hand

The word "hand" is a metonym that represents the custody or possession of the Jewish leaders. AT: "got away from them again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### John 10:40

#### beyond the Jordan

Jesus had been on the west side of the Jordan River. AT: "to the east side of the Jordan River" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he stayed there

Jesus remained on the east side of Jordan for a short period of time. AT: "Jesus stayed there for several days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### John indeed did no signs, but all the things that John has said about this man are true

"It is true that John did no signs, but he certainly did speak the truth about this man, who does signs."

#### signs

These are miracles that prove that something is true or that give someone credibility.

#### believed in

Here "believed in" means accepted or trusted what Jesus said was true.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johnthebaptist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/baptize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 10:intro

#### John 10 General Notes ####

####### Special concepts in this chapter #######

######## Sheep ########
Sheep is a common image used to refer to people. In this passage, it specifically refers to people who believe in Jesus and follow him. The Pharisees are likewise compared to wolves coming to steal and destroy the sheep.

######## Blasphemy ########
If someone falsely claims to be God, then it is considered blasphemy. In the law of Moses, the punishment for blasphemy was stoning to death. They did not believe Jesus, so they took up stones to kill him. Jesus was not guilty of blasphemy because he is God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

####### Important figures of speech in this chapter #######

######## Sheepfold ########
The illustration used here involves the place where sheep are kept. There would have been a door or gate that the shepherd would have normally entered into the sheepfold. The sheep immediately recognize him. On the other hand, a robber would have entered into the sheepfold through another way where he may not be caught. The sheep would likely run from the thief because they did not recognize him. Jesus uses this as a metaphor for his ministry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## "I lay down my life that I may take it again" ########
Although this is not set apart in any way, it is certainly a prophecy concerning Jesus' coming death. It emphasizes that he willingly died for the sins of man. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[John 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## John 11

### John 11:01

#### General Information:

These verses introduce the story of Lazarus and give background information about him and his sister Mary. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### It was Mary who anointed the Lord ... her hair

As John introduces Mary, the sister of Martha, he also shares information concerning what would later happen in the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]

### John 11:03

#### sent for Jesus

"asked Jesus to come"

#### love

Here "love" refers to brotherly love, a natural, human love between friends or relatives.

#### This sickness is not to death

Jesus implies that he knows what will happen related to Lazarus and his sickness. AT: "Death will not be the final result of this sickness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### death

This refers to physical death.

#### instead it is for the glory of God so that the Son of God may be glorified by it

Jesus implies that he knows what the outcome will be. AT: "but the purpose is that the people might see how great God is because of what his power will allow me to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### John 11:05

#### Now Jesus loved Martha and her sister and Lazarus

This is background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judea.md)]]

### John 11:08

#### Rabbi, right now the Jews are trying to stone you, and you are going back there again?

This remark appears in the form of a question to emphasize that the disciples do not want Jesus to go to Jerusalem. AT: "Teacher, you surely do not want to go back there! The Jews were trying to stone you the last time you were there!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the Jews

This is a synecdoche for the Jewish leaders who opposed Jesus. AT: "the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Are there not twelve hours of light in a day?

This remark appears in the form of a question to add emphasis. AT: "You know that the day has twelve hours of light!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### If someone walks in the daytime, he will not stumble, because he sees by the light of this world

People who walk in the light of the day can see well and do not stumble. "Light" is a metaphor for "truth." Jesus is implying that people who live according to truth will be able to successfully do the things that God wants them to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]

### John 11:10

#### Connecting Statement:

Jesus continues speaking to his disciples.

#### if he walks at night

Here "night" is a metaphor that refers to one's walking without God's light. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the light is not in him

Possible meanings are 1) "he cannot see" or "he does not have God's light."

#### Our friend Lazarus has fallen asleep

Here "fallen asleep" is an idiom that means Lazarus has died. If you have a way of saying this in your language, you may use it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### but I am going so that I may wake him out of sleep

The words "wake him out of sleep" form an idiom. Jesus is revealing his plan to bring Lazurus back to life. If you have an idiom for this in your language, you may use it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md)]]

### John 11:12

#### General Information:

In verse 13 there is a break in the story line as John comments on the disciples' misunderstanding about what Jesus meant when he said Lazarus was asleep. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### if he has fallen asleep

The disciples misunderstand Jesus to mean that Lazarus is resting and will recover.

#### Then Jesus said to them plainly

"So Jesus told them in words that they could understand"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### John 11:15

#### Connecting Statement:

Jesus continues speaking to his disciples.

#### for your sakes

"for your benefit"

#### that I was not there so that you may believe

"that I was not there. Because of this you will learn to trust me more."

#### who was called Didymus

You can translate this in an active form. AT: "whom they called Didymus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Didymus

This is a male name that means "twin." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 11:17

#### General Information:

Jesus is now in Bethany. These verses give background information about the setting and about what has happened before Jesus arrived. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### he found that Lazarus had already been in the tomb for four days

You can translate this in an active form. AT: "he learned that people had put Lazarus in a tomb four days before" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### fifteen stadia away

"about three kilometers away." A "stadium" is 185 meters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### about their brother

Lazarus was their younger brother. AT: "about their younger brother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### John 11:21

#### my brother would not have died

Lazarus was the younger brother. AT: "my younger brother would still be alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Your brother will rise again

Lazarus was the younger brother. AT: "Your younger brother will become alive again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### John 11:24

#### he will rise again

"he will become alive again"

#### even if he dies

Here "dies" refers to physical death.

#### will live

Here "live" refers to spiritual life.

#### whoever lives and believes in me will never die

"those who live and trust in me will never be separated eternally from God" or "those who live and trust in me will be spiritually alive with God forever"

#### will never die

Here "die" refers to spiritual death.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 11:27

#### She said to him

"Martha said to Jesus"

#### Yes, Lord, I believe that you are the Christ, the Son of God ... coming into the world

Martha believes that Jesus is Lord, the Christ (the Messiah), the Son of God.

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### she went away and called her sister Mary

Mary is the younger sister of Martha. AT: "she went away and called her younger sister Mary" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Teacher

This is a title referring to Jesus.

#### is calling for you

"is asking that you come"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]

### John 11:30

#### Now Jesus had not yet come into the village

Here John provides a brief break in the story to give background information regarding the location of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### fell down at his feet

Mary lay down or knelt at the feet of Jesus to show respect.

#### my brother would not have died

Lazarus was Mary's younger brother. See how you translated this in [John 11:21](./21.md). AT: "my younger brother would still be alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 11:33

#### he was deeply moved in his spirit and was troubled

John combines these phrases that have similar meanings to express the intense emotional distress and possible anger that Jesus experienced. AT: "he was greatly upset" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### Where have you laid him

This is a milder way of asking, "Where have you buried him?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### Jesus wept

"Jesus began to cry" or "Jesus started crying"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 11:36

#### loved

This refers to brotherly love or human love for a friend or family member.

#### Could not this man, who opened the eyes of a blind man, also have made this man not die?

This remark appears in the form of a question to express the Jews' surprise that Jesus did not heal Lazarus. AT: "He could heal a man who was blind, so he should have been able to heal this man so he would not have died!" or "Since he did not keep this man from dying, maybe he did not really heal the man who was born blind, as they say he did!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### opened the eyes

This is an idiom. AT: "healed the eyes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]

### John 11:38

#### Now it was a cave, and a stone lay against it

John pauses the story briefly to describe the tomb where the people had buried Lazarus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Martha, the sister of Lazarus

Martha and Mary were older sisters of Lazarus. AT: "Martha, the older sister of Lazarus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### by this time the body will be decaying

"by this time there will be a bad smell" or "the body is already stinking"

#### Did I not say to you that, if you believed, you would see the glory of God?

This remark appears in the form of a question to add emphasis to the point that God is about to do something wonderful. AT: "I told you that if you trusted me, you would see what God can do!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### John 11:41

#### Jesus lifted up his eyes

This is an idiom that means to look up. AT: "Jesus looked up toward heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Father, I thank you that you listened to me

Jesus prays directly to the Father so that others around him will hear his prayer. AT: "Father, I thank you that you have heard me" or "Father, I thank you that you have heard my prayer"

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### so that they may believe that you have sent me

"I want them to believe that you have sent me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 11:43

#### After he had said this

"After Jesus had prayed"

#### he cried out with a loud voice

"he shouted"

#### his feet and hands were bound with cloths, and his face was bound about with a cloth

A burial custom of this time was to wrap the dead body with long strips of linen cloth. This can be stated in active form. AT: "Someone had wrapped strips of cloth around his hands and feet. They had also tied a cloth around his face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Jesus said to them

The word "them" refers to the people who were there and saw the miracle.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 11:45

#### General Information:

These verses tell us what happened after Jesus raised Lazarus from the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]

### John 11:47

#### General Information:

Because so many people have told them that Lazarus is alive again, the chief priests and Pharisees gather the Jewish council for a meeting.

#### Then the chief priests

"Then the leaders among the priests"

#### Then

The author uses this word to tell the reader that the events that begin in verse 47 are a result of the events of [John 11:45-46](../45.md).

#### What will we do?

It is implied here that the council members are talking about Jesus. AT: "What are we going to do about Jesus?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all will believe in him

The Jewish leaders were afraid that the people would try to make Jesus their king. AT: "everyone will trust in him and rebel against Rome" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Romans will come

This is a synecdoche for the Roman army. AT: "the Roman army will come" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### take away both our place and our nation

"destroy both our temple and our nation"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/council.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rome.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rome.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### John 11:49

#### a certain man among them

This is a way to introduce a new character to the story. If you have a way to do this in your language, you can use it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### You know nothing

This is an exaggeration that Caiaphas uses to insult his hearers. AT: "You do not understand what is happening" or "You speak as though you know nothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### than that the whole nation perishes

Caiaphas implies that the Roman army would kill all of the people of the Jewish nation if Jesus is allowed to live and cause a rebellion. The word "nation" here is a synecdoche that represents all of the Jewish people. AT: "than that the Romans kill all the people of our nation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caiaphas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caiaphas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]

### John 11:51

#### General Information:

In verses 51 and 52 John explains that Caiaphus was prophesying even though he did not realize it at the time. This is background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### die for the nation

The word "nation" is a synecdoche and refers to the people of the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### would be gathered together into one

This is an ellipsis. The word "people" is implied by the context. AT: "would be gathered into one people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### children of God

This refers to people who belong to God through faith in Jesus and are spiritually God's children.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 11:54

#### General Information:

Jesus leaves Bethany and goes to Ephraim. In verse 55 the story shifts to telling about what many of the Jews are doing now that Passover is near.

#### walk openly among the Jews

Here "Jews" is a synecdoche for the Jewish leaders and "walk openly" here is an idiom for "lived where everyone could see him." AT: "live where all the Jews could see him" or "walk openly among the Jewish leaders who opposed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the country

the rural area outside cities where fewer people live

#### There he stayed with the disciples

Jesus and his disciples stayed in Ephraim for a while. AT: "There he stayed with his disciples for a short period of time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### went up to Jerusalem

The phrase "went up" is used here because Jerusalem is higher in elevation than the surrounding areas.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]

### John 11:56

#### General Information:

The content of verse 57 occurs before that of verse 56. If this order might confuse your readers, you can combine these verses and put the text of verse 57 before the text of verse 56. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])

#### They were looking for Jesus

The word "they" refers to the Jewish people who had traveled to Jerusalem.

#### What do you think? That he will not come to the festival?

These are rhetorical questions that express a strong element of doubt that Jesus will come to the Passover Festival. The second question is an ellipsis that leaves out the words "do you think." The speakers here were wondering if Jesus would come to the festival since there was the danger of his being arrested. AT: "Jesus will probably not come to the festival. He might be afraid of getting arrested!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Now the chief priests

This is background information that explains why the Jewish worshipers were wondering if Jesus would come to the festival or not. If your language has a way to mark background information, use it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]

### John 11:intro

#### John 11 General Notes ####

####### Special concepts in this chapter #######

######## Light ########
Light is a common image in Scripture used to represent righteousness. Light is also used to show the path of righteousness and to show righteous living. Darkness is often used as images representing sin or unrighteousness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md)]])

######## "I am ... " ########

John uses this phrase seven times in his gospel. It is the same words used by God, when he revealed himself and his name at the burning bush. The name "Yahweh" can be translated as "I am."

######## Passover ########
This chapter records that Jesus no longer walked openly among the Jews. In turn, the Pharisees waited to find him during the Passover. It was the responsibility of the Jews, who were able, to go to Jerusalem during the Passover celebration. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]])

####### Important figures of speech in this chapter #######

######## "One man should die for the people" ########
Caiaphas said, "it is expedient for you that one man should die for the people rather than that the whole nation should perish." It is ironic that Jesus would come to die for the sins of the nation and the whole world. This statement almost functions as a prophecy about Jesus' death for sin. This is something the high priest also gives a prophecy about later in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

####### Other possible translation difficulties in this chapter #######

######## "If you had been here" ########
Mary and Martha had faith in Jesus but they did not understand fully who he was. In this passage, they had not yet come to realize that he had power over death itself and could raise Lazarus from the dead if he desired. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[John 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## John 12

### John 12:01

#### General Information:

Jesus is at dinner in Bethany when Mary anoints his feet with oil.

#### Six days before the Passover

The author uses these words to mark the beginning of a new event. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### raised from the dead

"Raise" here is an idiom for "cause to live again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### a litra of perfume

You may convert this to a modern measure. A "litra" is about one third of a kilogram. Or you may refer to a container that could hold that amount. AT: "a third of a kilogram of perfume" or "a bottle of perfume" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### perfume

This is a good-smelling liquid made by using the oils of pleasant smelling plants and flowers.

#### nard

This is a perfume made from a pink, bell-shaped flower in the mountains of Nepal, China, and India. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### The house was filled with the fragrance of the perfume

This can be translated in an active form. AT: "The scent of her perfume filled the house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethany.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/martha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marysisterofmartha.md)]]

### John 12:04

#### the one who would betray him

"the one who later enabled Jesus' enemies to seize him"

#### Why was this perfume not sold for three hundred denarii and given to the poor?

This is a rhetorical question. You can translate it as a strong statement. AT: "This perfume could have been sold for three hundred denarii and the money could have been given to the poor!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### three hundred denarii

You can translate this as a numeral. AT: "300 denarii" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### denarii

A denarius was the amount of silver that a common laborer could earn in one day of work. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### Now he said this ... would steal from what was put in it

John explains why Judas asked the question about the poor. If your language has a way of indicating background information, you can use it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### he said this, not because he cared about the poor, but because he was a thief

"he said this because he was a thief. He did not care about the poor"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### John 12:07

#### Allow her to keep what she has for the day of my burial

Jesus implies that the woman's actions can be understood as anticipating his death and burial. AT: "Allow her to show how much she appreciates me! In this way she has prepared my body for burial" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You will always have the poor with you

Jesus implies that there will always be opportunities to help the poor people. AT: "There will always be poor people among you, and you can help them whenever you want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### But you will not always have me

In this way, Jesus implies that he will die. AT: "But I will not always be here with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md)]]

### John 12:09

#### Now

This word is used here to mark a break in the main story line. Here John tells about a new group of people that has come to Bethany from Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### because of him

The fact that Lazarus was alive again caused many Jews to believe in Jesus.

#### believed in Jesus

This implies that many of the Jewish people were trusting in Jesus as the Son of God. AT: "were putting their trust in Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 12:12

#### General Information:

Jesus enters Jerusalem and the people honor him as a king.

#### On the next day

The author uses these words to mark the beginning of a new event. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### a great crowd

"a great crowd of people"

#### Hosanna

This means "May God save us now!"

#### Blessed

This expresses a desire for God to cause good things to happen to a person.

#### comes in the name of the Lord

Here the word "name" is a metonym, which means authority and power. AT: "comes as the representative of the Lord" or "comes in the power of the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### John 12:14

#### Jesus found a young donkey and sat on it

Here John gives background information that Jesus secures a donkey. He implies that Jesus will ride the donkey into Jerusalem. AT: "he found a young donkey and sat on it, riding into the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### as it was written

You can translate this in an active form. AT: "as the prophets wrote in the Scripture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### daughter of Zion

"Daughter of Zion" here is a metonym that refers to the people of Jerusalem. AT: "you people of Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/daughterofzion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/daughterofzion.md)]]

### John 12:16

#### General Information:

John, the writer, interrupts here to give the reader some background information about what the disciples later understood. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### His disciples did not understand these things

Here the words "these things" refer to the words that the prophet had written about Jesus.

#### when Jesus was glorified

You can translate this in an active form. AT: "when God glorified Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they had done these things to him

The words "these things" refer to what the people did when Jesus rode into Jerusalem on a donkey (praising him and waving the palm branches).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### John 12:17

#### Now

This word is used here to mark a break in the main narrative. Here John explains that many of the people came to meet Jesus because they heard others say that he had raised Lazarus from the dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### they heard that he had done this sign

"they heard others say that he had done this sign"

#### this sign

A "sign" is an event or occurrence that proves something is true. In this case, the "sign" of raising Lazarus proves that Jesus is the Messiah.

#### Look, you can do nothing

The Pharisees imply here that it might be impossible to stop Jesus. AT: "It seems like we can do nothing to stop him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### see, the world has gone after him

The Pharisees use this exaggeration to express their shock that so many people have come out to meet Jesus. AT: "It looks like everyone is becoming his disciple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the world

Here "the world" is a metonym that represents (in exaggeration) all of the people in the world. You may need to make explicit that the hearers would have understood that the Pharisees were speaking only of the people in Judea. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lazarus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]

### John 12:20

#### Now certain Greeks

The phrase "now certain" marks the introduction of new characters to the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### to worship at the festival

John implies that these "Greeks" were going to worship God during the Passover. AT: "to worship God at the Passover festival" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Bethsaida

This was a town in the province of Galilee.

#### they told Jesus

Philip and Andrew tell Jesus about the Greeks' request to see him. You can translate this by adding the implied words. AT: "they told Jesus what the Greeks had said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/andrew.md)]]

### John 12:23

#### General Information:

Jesus begins to respond to Philip and Andrew.

#### The hour has come for the Son of Man to be glorified

Jesus implies that it is now the right time for God to honor the Son of Man through his upcoming suffering, death and resurrection. AT: "God will soon honor me when I die and rise again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Truly, truly, I say to you

Translate this the way your language emphasizes that what follows is important and true. See how you translated "Truly, truly" in [John 01:51](../01/49.md).

#### unless a grain of wheat falls into the earth and dies ... it will bear much fruit

Here "a grain of wheat" or "seed" is a metaphor for Jesus' death, burial and resurrection. Just as a seed is planted and grows again into a plant that will bear much fruit, so will many people trust in Jesus after he is killed, buried, and raised back to life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### John 12:25

#### He who loves his life will lose it

Here "loves his life" means to consider one's own physical life to be more valuable than the lives of others. AT: "whoever values his own life more than others will not receive eternal life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he who hates his life in this world will keep it for eternal life

Here the one who "hates his life" refers to one who loves his own life less than he loves the lives of others. AT: "whoever considers the lives of others as more important than his own life will live with God forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### where I am, there will my servant also be

Jesus implies that those who serve him will be with him in heaven. AT: "when I am in heaven, my servant will also be there with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Father will honor him

Here "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### John 12:27

#### what should I say? 'Father, save me from this hour'?

This remark appears in the form of a rhetorical question. Although Jesus desires to avoid crucifixion, he chooses to be obedient to God and to be killed. AT: "I will not pray, 'Father, save me from this hour!'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### this hour

Here "this hour" is a metonym that represents when Jesus would suffer and die on the cross. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### glorify your name

Here the word "name" is a metonym that refers to God. AT: "make your glory known" or "reveal your glory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a voice came from heaven

This represents God speaking. Sometimes people avoid referring directly to God because they respect him. AT: "God spoke from the heavens" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### John 12:30

#### General Information:

Jesus explains why the voice spoke from heaven.

#### Now is the judgment of this world

Here "this world" is a metonym that refers to all the people in the world. AT: "Now is the time for God to judge all of the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Now will the ruler of this world be thrown out

Here "ruler" refers to Satan. You can translate this in an active form. AT: "Now is the time when I will destroy the power of Satan who rules this world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### John 12:32

#### General Information:

In verse 33 John tells us background information about what Jesus said about being "lifted up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### When I am lifted up from the earth

Here Jesus refers to his crucifixion. You can translate this in an active form. AT: "When people raise me high on a cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will draw everyone to myself

Through his crucifixion, Jesus will provide a way for everyone to trust in him.

#### He said this to indicate what kind of death he would die

John interprets Jesus' words to mean that people will crucify him. AT: "He said this to let the people know how he would die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 12:34

#### The Son of Man must be lifted up

The phrase "lifted up" means crucified. You may translate this in a way that includes the implied words "on a cross." AT: "The Son of Man must be lifted up on a cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Who is this Son of Man?

Possible meanings are 1) "What is the identity of this Son of Man? or 2) "What kind of Son of Man are you talking about?"

#### The light will still be with you for a short amount of time. Walk while you have the light, so that darkness does not overtake you. He who walks in the darkness does not know where he is going

Here "light" is a metaphor for Jesus' teachings which reveal the truth of God. To "walk in darkness" is a metaphor that means to live without God's truth. AT: "My words are like a light to you, to help you understand how to live as God wants you to. I will not be with you much longer. You need to follow my instructions while I am still with you. If you reject my words, it will be like walking in darkness and you cannot see where you are going" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### While you have the light, believe in the light so that you may be sons of light

The "light" is a metaphor for the teachings of Jesus which reveal the truth of God. "sons of light" is a metaphor for those who accept the message of Jesus and live according to God's truth. AT: "While I am with you, believe what I teach so that God's truth will be in you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overtake.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overtake.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### John 12:37

#### General Information:

This is a break in the main story line as the John begins to explain about the fulfillment of prophesies that had been spoken by the prophet Isaiah.

#### so that the word of Isaiah the prophet would be fulfilled

You can translate this in an active form. AT: "in order to fulfill the message of Isaiah the prophet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Lord, who has believed our report, and to whom has the arm of the Lord been revealed?

This appears in the form of two rhetorical questions to express the prophet's dismay that the people do not believe his message.They may be stated as a single rhetorical question, AT: "Lord, hardly anyone has believed our message, even though they have seen that you are powerfully able to save them!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the arm of the Lord

This is a metonym that refers to the Lord's ability to rescue with power. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]

### John 12:39

#### he has hardened their hearts

This is an idiom that means that God caused them to be stubborn. AT: "he has made them stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### understand with their hearts

The Jews considered the heart to be the organ that caused understanding.  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### and turn

"Turn" here is a metonym for "repent." AT: "and they would repent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### John 12:41

#### so that they would not be banned from the synagogue

You can translate this in an active form. AT: "so people would not stop them from going to the synagogue" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They loved the praise that comes from people more than the praise that comes from God

"They wanted people to praise them more than they wanted God to praise them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 12:44

#### General Information:

Now John returns to the main story line. This is another time when Jesus begins to speak to the crowd.

#### Jesus cried out and said

Here John implies that a crowd of people had gathered to hear Jesus speak. AT: "Jesus shouted out to the crowd that had gathered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the one who sees me sees him who sent me

Here the word "him" refers to God. AT: "the one who sees me sees God, who sent me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### John 12:46

#### Connecting Statement:

Jesus continues speaking to the crowd.

#### I have come as a light

Here the "light" is a metaphor for Jesus' example. AT: "I have come to show the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### may not remain in the darkness

Here "darkness" is a metaphor for living in ignorance of God's truth. AT: "may not continue to be spiritually blind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### If anyone hears my words but does not keep them, I do not judge him; for I have not come to judge the world, but to save the world

Here "to judge the world" implies condemnation. Jesus did not come to condemn people. AT: "If anyone hears my teaching and rejects it, I do not condemn him. I have not come to condemn people. Instead, I have come to save those who trust in me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the world

Here "the world" is a metonym that represents all of the people in the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### John 12:48

#### on the last day

"at the time when God judges people's sins"

#### I know that his command is eternal life

"I know that the words that he commanded me to speak are the words that give life forever"

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reject.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 12:intro

#### John 12 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 12:38 and 40, which is quoted from the OT.

Verse 16 is a commentary on these events. It is possible to put this entire verse in parentheses in order to set it apart from the narrative of the story.

####### Special concepts in this chapter #######

######## Anointing ########
It was customary to anoint a body in preparation for the body's burial. This would normally not have been done until after a person's death. This was not Mary's intention. Jesus uses Mary's actions to prophesy concerning his approaching death. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Donkey ########

The way in which Jesus entered Jerusalem, riding on an animal, was similar to the way a king would have entered a city after a great victory. And for the kings of Israel, it was traditional to ride on a donkey instead of on a horse. Matthew, Mark, Luke, and John all wrote about this event, but they did not all give the same details. Matthew wrote about there being both a donkey and a colt, but it is not clear which one Jesus rode on. It is best to translate each of these passages as it appears in the ULB without trying to make them all say exactly the same thing. (See: [Matthew 21:1-7](../../mat/21/01.md) and [Mark 11:1-7](../../mrk/11/01.md))

######## Light ########
Light is a common image in Scripture used to represent righteousness. Light is also used to show the path of righteousness and to show righteous living. Darkness is often used as images representing sin or unrighteousness. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unrighteous.md)]])

####### Important figures of speech in this chapter #######

######## "To be glorified" ########
Jesus' prophesy about being glorified is a reference to his death. The disciples would not have understood that his death would have brought him glory, but it did. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

####### Other possible translation difficulties in this chapter #######

######## The use of paradox ########

A paradox is a seemingly absurd statement, which appears to contradict itself, but it is not absurd. A paradox occurs in 12:25: "He who loves his life will lose it; but he who hates his life in this world will keep it for eternal life." But in 12:26 Jesus explains what it means to keep one's life for eternal life. ([John 12:25-26](./25.md)).

##### Links: #####

* __[John 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## John 13

### John 13:01

#### General Information:

It is not yet Passover and Jesus is together with his disciples for supper. These verses explain the setting of the story and give background information about Jesus and Judas. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### loved

This is the kind of love that comes from God, which is focused on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### the devil had already put it into the heart of Judas Iscariot son of Simon, to betray Jesus

The phrase "put it into the heart" is an idiom that means to cause someone to think about something. AT: "the devil had already caused Judas Iscariot, the son of Simon, to think about betraying Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### John 13:03

#### Connecting Statement:

Verse 3 continues to tell us background information about what Jesus knew. The action in the story begins in verse 4. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### had given everything over into his hands

Here "his hands" is a metonym for power and authority. AT: "had given him complete power and authority over everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he had come from God and was going back to God

Jesus had always been with the Father, and would return there after his work on earth was finished.

#### He got up from dinner and took off his outer clothing ... began to wash the feet of the disciples

Because the region was very dusty, it was customary for the host of a dinner to provide a servant to wash the feet of the guests.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 13:06

#### Lord, are you going to wash my feet?

Peter's question shows that he is not willing for Jesus to wash his feet. AT: "Lord, it is not right for you to wash the feet of me, a sinner!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### If I do not wash you, you have no share with me

Here Jesus states two negatives to convince Peter to allow him to wash his feet. Jesus implies that Peter must let him wash his feet if he wants to continue being a disciple. AT: "If I wash you, you will always belong with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/understand.md)]]

### John 13:10

#### Connecting Statement:

Jesus continues to speak to Simon Peter.

#### General Information:

Jesus uses the word "you" to refer to all of his disciples.

#### He who is bathed has no need, except to wash his feet

Here "bathed" is a metaphor that means that God has cleansed a person spiritually. AT: "If anyone has already received God's forgiveness, he now only needs to receive cleansing from his daily sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Not all of you are clean

Jesus implies that the one who will betray him, Judas, has not trusted in him. Therefore God has not forgiven him of his sins. AT: "Not all of you have received God's forgiveness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### John 13:12

#### Do you know what I have done for you?

This remark appears in the form of a question so Jesus can emphasize the importance of what he is teaching his disciples. AT: "You need to understand what I have done for you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### You call me 'teacher' and 'Lord,'

Here Jesus implies that his disciples have great respect for him. AT: "You show me great respect when you call me 'teacher' and 'Lord.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you should also do just as I did for you

Jesus implies that his disciples should be willing to follow his example and serve one another. AT: "you should also humbly serve each other" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 13:16

#### Connecting Statement:

Jesus continues to speak to his disciples.

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### greater

"more important"

#### you are blessed

Here "bless" means to cause good, beneficial things to happen to a person. You can translate this in an active form. AT: "God will bless you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### this so that the scripture will be fulfilled

You can translate this in an active form. AT: "this is in order to fulfill the scripture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He who eats my bread lifted up his heel against me

Here the phrase "eats my bread" is an idiom for someone who pretends to be a friend. The phrase "lifted up his heel" is also an idiom, which means someone who has become an enemy. If you have idioms in your language that carry these meanings, you can use them here. AT: "the one who has pretended to be my friend has turned out to be an enemy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### John 13:19

#### I tell you this now before it happens

"I am telling you now what is going to happen before it happens"

#### you may believe that I AM

"you may believe that I am who I said I am" or "you may believe that I am the Messiah"

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### John 13:21

#### troubled

concerned, upset

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### The disciples looked at each other, wondering of whom he was speaking

"The disciples looked at each other and wondered: "Who will betray Jesus?"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 13:23

#### One of his disciples, whom Jesus loved

This refers to John.

#### lying down at the table

During the time of Christ, Jews would often dine together in the Greek style, in which they lay on their sides on low couches. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Jesus' side

Lying with one's head against the side of another diner in the Greek style was considered to be the place of greatest friendship with him.

#### loved

This kind of love comes from God and focuses on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 13:26

#### Iscariot

This indicates that Judas was from the village of Kerioth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Then after the bread

The words "Judas took" are understood from the context. AT: "Then after Judas took the bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Satan entered into him

This is an idiom that means Satan took complete control of Judas. AT: "Satan took control of him" or "Satan started to command him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### so Jesus said to him

Here Jesus is speaking to Judas.

#### What you are doing, do it quickly

"Do quickly what you are planning to do!"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### John 13:28

#### that he should give something to the poor

You can translate this as a direct quote: "Go and give some money to the poor."

#### he went out immediately. It was night

John seems to draw attention here to the fact that Judas will do his evil or "dark" deed in the darkness of the night. AT: "he went out immediately into the dark night" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]

### John 13:31

#### Now the Son of Man is glorified, and God is glorified in him

You can translate this in an active form. AT: "Now people are about to see how the Son of Man will receive honor and how God will receive honor through what the Son of Man is doing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### God will glorify him in himself, and he will glorify him immediately

The word "him" refers to the Son of Man. The word "himself" is a reflexive pronoun that refers to God. AT: "God himself will immediately give honor to the Son of Man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### Little children

Jesus uses the term "Little children" to communicate that he loves the disciples as though they were his children.

#### as I said to the Jews

Here "Jews" is a synecdoche for the Jewish leaders who opposed Jesus. AT: "as I said to the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### John 13:34

#### Connecting Statement:

Jesus continues speaking to his disciples.

#### love

This is the kind of love that comes from God and focuses on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### everyone

You may need to make explicit that this exaggeration refers only to those people who see how the disciples love each other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 13:36

#### lay down my life

"give up my life" or "die"

#### Will you lay down your life for me?

This remark appears in the form of a question to add emphasis to Jesus' statement. AT: "You say that you will die for me, but the truth is that you will not!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the rooster will not crow before you have denied me three times

"you will say that you do not know me three times before the rooster crows"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### John 13:intro

#### John 13 General Notes ####

####### Structure and formatting #######

The events of this chapter are commonly referred to as the last supper or the Lord's supper. This Passover feast in many ways parallels Jesus' sacrifice as the lamb of God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]])

####### Special concepts in this chapter #######

######## "To wash the disciples' feet" ########
Feet were considered very dirty in the ancient Near East. It was normally the servant who was responsible for washing the feet of his master. This act would have been considered humiliating for Jesus, which is why the disciples did not want him to do it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Washing ########
The image of washing is used here on the eve of Jesus' death. It is Jesus who is able to make people clean. This image represents the ability "to make righteous." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]) 

######## "I am ... " ########

John uses this phrase seven times in his gospel. It is the same words used by God, when he revealed himself and his name at the burning bush. The name "Yahweh" can be translated as "I am." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

####### Other possible translation difficulties in this chapter #######

######## Son of Man ########

Jesus refers to himself as the "Son of Man." Some languages may not have the ability to have a person refer to himself in the third person.

##### Links: #####

* __[John 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## John 14

### John 14:01

#### Connecting Statement:

The part of the story from the previous chapter continues. Jesus reclines at the table with his disciples and continues to speak to them.

#### Do not let your heart be troubled

This is an idiom. To have a troubled heart means to be worried or anxious. AT: "Stop being so anxious and worried" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### In the house of my Father are many rooms

"there are many places to live in my Father's house"

#### In the house of my Father

This refers to heaven, where God lives.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### many rooms

The word "room" can refer to a single room, or to a larger dwelling.

#### I am going to prepare a place for you

Jesus will prepare a place in heaven for every person who trusts in him. The "you" is plural and refers to all his disciples. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 14:04

#### how can we know the way?

"how can we know how to get there?"

#### the way

This is a metaphor that has these possible meanings 1) "the way to God" or 2) "the one who takes people to God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the truth

This is a metaphor that has these possible meanings 1) "the true person" or 2) "the one who speaks true words about God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the life

This is a metaphor that means Jesus can give life to people. AT: "the one who can make people alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### no one comes to the Father except through me

People can come to God and live with him only by trusting Jesus. AT: "No one can come to the Father and live with him unless he comes through me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### John 14:08

#### Lord, show us the Father

The "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I have been with you for so long and you still do not know me, Philip?

This remark appears in the form of a question to add emphasis to Jesus' words. AT: "Philip, I have been with you disciples already for a very long time. You should know me by now!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Whoever has seen me has seen the Father

To see Jesus, who is God the Son, is to see God the Father. The "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### How can you say, 'Show us the Father'?

This remark appears in the form of a question to emphasize Jesus' words to Philip. AT: "So you really should not be saying, 'Show us the Father!'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philiptheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 14:10

#### Connecting Statement:

Jesus asks Philip a question and then he continues to speak to all of his disciples.

#### Do you not believe ... in me?

This remark appears in the form of a question to emphasize Jesus' words to Philip. AT: "You really should believe ... in me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### The words that I say to you I do not speak from my own authority

"What I am telling you is not from me" or "The words I tell you are not from me"

#### The words that I say to you

Here "you" is plural. Jesus is now speaking to all of his disciples.

#### I am in the Father, and the Father is in me

This is an idiom that means God the Father and Jesus have a unique relationship. AT: "I am one with the Father, and the Father is one with me" or "my Father and I are just as though we were one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### John 14:12

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### believes in me

This means to believe that Jesus is the Son of God.

#### Whatever you ask in my name

Here "name" is a metonym that represents the authority of Jesus. AT: "Whatever you ask, using my authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that the Father will be glorified in the Son

You can translate this in an active form. AT: "so I can show everyone how great my Father is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Father ... Son

These are important titles that describe the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### If you ask me anything in my name, I will do it

Here "name" is a metonym that represents the authority of Jesus. AT: "If you ask me anything as one of my followers, I will do it" or "Whatever you ask of me, I will do it because you belong to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]

### John 14:15

#### Comforter

This refers to the Holy Spirit.

#### Spirit of truth

This refers to the Holy Spirit who teaches people what is true about God.

#### The world cannot receive him

Here the "world" is a metonym that refers to the people who oppose God. AT: "The unbelieving people in this world will never welcome him" or "Those who oppose God will not accept him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 14:18

#### leave you alone

Here Jesus implies that he will not leave his disciples with no one to care for them. AT: "leave you with no one to care for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the world

Here the "world" is a metonym that represents the people who do not belong to God. AT: "the unbelievers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you will know that I am in my Father

God the Father and Jesus live as one person. AT: "you will know that my Father and I are just like one person"

#### my Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### you are in me, and that I am in you

"you and I are just like one person"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 14:21

#### loves

This kind of love comes from God and focuses on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### he who loves me will be loved by my Father

You can translate this in an active form. AT: "my Father will love anyone who loves me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Judas (not Iscariot)

This refers to another disciple whose name was Judas, not to the disciple who was from the village of Kerioth who betrayed Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### why is it that you will show yourself to us

Here the word "show" refers to revealing how wonderful Jesus is. AT: "Why will you reveal yourself only to us" or "Why will you only let us see how wonderful you are?"

#### not to the world

Here "world" is a metonym that represents the people who oppose God. AT: "not to those who do not belong to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 14:23

#### Connecting Statement:

Jesus responds to Judas (not Iscariot).

#### If anyone loves me, he will keep my word

"The one who loves me will do what I have told him to do"

#### loves

This kind of love comes from God and focuses on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### My Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### we will come to him and we will make our home with him

The Father and the Son will share life with those who obey what Jesus commands. AT: "we will come to live with him, and will have a personal relationship with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The word that you hear is not from me but from the Father who sent me

"The things I have told you are not things that I have decided to say on my own"

#### The word

Here the "word" is a metonym for the message that Jesus brings from God. AT: "The message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### that you hear

Here when Jesus says "you" he is speaking to all of his disciples.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 14:25

#### Comforter

This refers to the Holy Spirit. See how you translated this in [John 14:16](./15.md).

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### in my name

Here the word "name" is a metonym that represents Jesus' power and authority. AT: "because of me" or "for my sake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### world

The "world" is a metonym that represents those people who do not love God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Do not let your heart be troubled, and do not be afraid

"To have a troubled heart" here is an idiom that means to be very anxious or afraid. Here Jesus speaks of the heart as if it were a person. AT: "So stop being anxious, and do not be afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 14:28

#### loved

This kind of love comes from God and desires the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### I am going to the Father

Here Jesus implies that he will return to his Father. AT: "I am going back to the Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the Father is greater than I

Here Jesus implies that the Father has greater authority than the Son while the Son is on the earth. AT: "the Father has greater authority than I have here" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 14:30

#### ruler of this world

Here "ruler" refers to Satan. See how you translated this in [John 12:31](../12/30.md). AT: "Satan who rules this world"

#### ruler ... is coming

Here Jesus implies that Satan is coming to attack him. AT: "Satan is coming to attack me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in order that the world will know

Here the "world" is a metonym for the people who do not belong to God. AT: "in order that the ones who do not belong to God may know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### John 14:intro

#### John 14 General Notes ####

####### Special concepts in this chapter #######

######## "My Father's house" ########
This is not a reference to the temple. Instead, it is a reference to the dwelling place of God in heaven. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]) 

######## Comforter ########
This is another name for the Holy Spirit, along with the "Spirit of Truth." He was already present in the world, but would come in a special way, to dwell in Christians, permanently. Jesus and the Holy Spirit are both God; because of this fact, it can be said that Jesus will live in Christians after his death. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]])

##### Links: #####

* __[John 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## John 15

### John 15:01

#### Connecting Statement:

The part of the story from the previous chapter continues. Jesus reclines at the table with his disciples and continues to speak to them.

#### I am the true vine

Here the "true vine" is a metaphor. Jesus compares himself to a vine or a vine stem. He is the source of life that causes people to live in a way that pleases God. AT: "I am like a vine that produces good fruit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my Father is the gardener

The "gardener" is a metaphor. A "gardener" is a person who takes care of the vine to ensure it is as fruitful as possible. AT: "my Father is like a gardener" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### He takes away every branch in me that does not bear fruit, and he prunes every branch that bears fruit so that it will bear more fruit

"Fruit" here is a metaphor for "result" or "outcome." AT: "He lifts up every part of me that has not yet shown a good outcome, and he trims off every part of me that shows good results so that it will show more good results" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### takes away

"cuts off and takes away"

#### prunes every branch

"trims every branch"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 15:03

#### You are already clean because of the message that I have spoken to you

The implied metaphor here is the "clean branches" that have already been "pruned." AT: "It is as if you have already been pruned and are clean branches because you have obeyed what I have taught you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you

The word "you" throughout this passage is plural and refers to the disciples of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Remain in me, and I in you

"If you remain joined to me, I will remain joined to you" or "Remain joined to me, and I will remain joined to you"

#### unless you remain in me

By remaining in Christ, those who belong to him depend on him for everything. AT: "unless you stay joined to me and depend upon me for everything"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### John 15:05

#### I am the vine, you are the branches

The "vine" is a metaphor that represents Jesus. The "branches" is a metaphor that represent those who trust in Jesus and belong to him. AT: "I am like a vine, and you are like branches that are attached to the vine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He who remains in me and I in him

Here Jesus implies that his followers are joined to him as he is joined to God. AT: "He who stays joined to me, as I stay joined to my Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he bears much fruit

The implied metaphor here is the fruitful branch that represents the believer who pleases God. Just as a branch that is attached to the vine will bear much fruit, those who stay joined to Jesus will do many things that please God. AT: "you will bear much fruit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he is thrown away like a branch and dries up

Here the implied metaphor is the unfruitful branch that represents those who do not stay joined to Jesus. You can translate this in an active form. AT: "the vinedresser throws him away like a branch and it dries up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they are burned up

You can translate this in an active form. AT: "the fire burns them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### ask whatever you wish

Jesus implies that believers must ask God to answer their prayers. AT: "ask God whatever you wish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### it will be done for you

You can translate this in an active form. AT: "he will do it for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### John 15:08

#### My Father is glorified in this

You can translate this in an active form. AT: "It causes people to honor my Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### My Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### that you bear much fruit

Here "fruit" is a metaphor for living to please God. AT: "when you live in a way that pleases him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### are my disciples

"show you are my disciples" or "demonstrate you are my disciples"

#### As the Father has loved me, I have also loved you

Jesus shares the love that God the Father has for him with those who trust in him. Here "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Remain in my love

"Continue to accept my love"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### John 15:10

#### If you keep my commandments, you will remain in my love, as I have kept the commandments of my Father and remain in his love

When Jesus' followers obey him, they show their love for him. AT: "When you do the things I have told you to do, you are living in my love, just as I obey my Father and live in his love" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### my Father

Here "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I have spoken these things to you so that my joy will be in you

"I have told you these things so that you will have the same kind of joy that I have"

#### so that your joy will be complete

You can translate this in an active form. AT: "so that you will be completely joyful" or "so that your joy may have nothing missing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### John 15:12

#### No one has greater love than this

This kind of love comes from God and desires the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do. AT: "You can have no greater love than this"

#### life

This refers to physical life.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 15:14

#### everything that I heard from my Father, I have made known to you

"I have told you everything my Father told me"

#### my Father

Here "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 15:16

#### You did not choose me

Jesus implies that his followers did not decide on their own to become his disciples. AT: "You did not decide to become my disciples" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### go and bear fruit

Here "fruit" is a metaphor that represents a life that is pleasing to God. AT: "live lives that please God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that your fruit should remain

"that the results of what you do should last forever"

#### whatever you ask of the Father in my name, he will give it to you

Here "name" is a metonym that represents the authority of Jesus. AT: "Because you belong to me, whatever you ask of the Father, he will give it to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### John 15:18

#### If the world hates you ... therefore the world hates you

Jesus uses the term "world" in these verses as a metonym to refer to the people who do not belong to God and are opposed to him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### love

This refers to human, brotherly love or love for a friend or family member.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### John 15:20

#### Remember the word that I said to you

Here "word" is a metonym for the message of Jesus. AT: "Remember the message that I spoke to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### because of my name

Here "because of my name" is a metonym that represents Jesus. People will make his followers suffer because they belong to him. AT: "because you belong to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### If I had not come and spoken to them, they would not have sin, but now they have no excuse for their sin

Jesus implies here that he has shared God's message with those who do not trust him. AT: "Because I have come and told them God's message, they have no excuse when God judges them for their sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/persecute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### John 15:23

#### He who hates me also hates my Father ... they have seen and hated both me and my Father

To hate God the Son is to hate God the Father.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### If I had not done the works that no one else did among them, they would have no sin, but

You can translate this double negative in a positive form. AT: "Because I have done among them the works that no one else did, they have had sin, and" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### they would have no sin

"they would not have any sin." See how you translated this in [John 15:22](./20.md).

#### to fulfill the word that is written in their law

You can translate this in an active form. "Word" here is a metonym for the entire message of God. AT: "to fulfill the prophecy in their law" and "to fulfill the prophecy in their law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### law

This refers generally to the entire Old Testament, which contained all of God's instructions for his people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### John 15:26

#### the Comforter

This refers to the Holy Spirit. See how you translated this in [John 14:16](../14/15.md).

#### will send ... from the Father ... the Spirit of truth ... he will testify about me

God the Father sent God the Spirit to show the world that Jesus is God the Son.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### the Spirit of truth

This is a title for the Holy Spirit. AT: "the Spirit who tells the truth about God and me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You are also testifying

Here "testifying" means to tell others about Jesus. AT: "You also must tell everyone what you know about me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the beginning

Here the "beginning" is a metonym that means the first days of Jesus' ministry. AT: "from the very first days when I began teaching the people and doing miracles" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/comfort.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]

### John 15:intro

#### John 15 General Notes ####

####### Structure and formatting #######

######## Vine ########
The vine is an important image in scripture. This chapter forms a complex and extended metaphor. The various aspects of this image and how it is used will cause translation issues in any culture. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Special concepts in this chapter #######

######## "I am ... " ########

John uses this phrase seven times in his gospel. It is the same words used by God, when he revealed himself and his name at the burning bush. The name "Yahweh" can be translated as "I am." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

##### Links: #####

* __[John 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## John 16

### John 16:01

#### Connecting Statement:

The part of the story from the previous chapter continues. Jesus reclines at the table with his disciples and continues to speak to them.

#### you will not fall away

Here the phrase "fall away" implies to stop putting one's trust in Jesus. You can translate this in an active form. AT: "you will not stop trusting in me because of the difficulties you must face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the hour is coming when everyone who kills you will think that he is offering a service to God

"it will someday happen that a person will kill you and think he is doing something good for God."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 16:03

#### They will do these things because they have not known the Father nor me

They will kill some believers because they do not know God the Father or Jesus.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### when their hour comes

Here "hour" is a metonym that refers to the time when people will persecute Jesus' followers. AT: "when they cause you to suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the beginning

This is a metonym that refers to the first days of Jesus' ministry. AT: "when you first started following me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]

### John 16:05

#### sadness has filled your heart

This is an idiom that means the disciples are very sad. AT: "you are now very sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### if I do not go away, the Comforter will not come to you

You can translate this in a positive form. AT: "the Comforter will come to you only if I go away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### Comforter

This is a title for the Holy Spirit who will be with the disciples after Jesus goes away. See how you translated this in [John 14:26](../14/25.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 16:08

#### the Comforter will prove the world to be wrong about sin ... righteousness ... I am going to the Father

When the Holy Spirit came, he began to show people that they are sinners.

#### Comforter

This refers to the Holy Spirit. See how you translated this in [John 14:16](../14/15.md).

#### world

This is a metonym that refers to the people in the world.(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### about sin, because they do not believe in me

"they are guilty of sin because they do not trust in me"

#### about righteousness, because I am going to the Father, and you will no longer see me

"when I return to God, and they see me no more, they will know that I did the right things"

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### about judgment, because the ruler of this world has been judged

"God will hold them accountable and will punish them for their sins, just as he will punish Satan, the one who rules this world"

#### the ruler of this world

Here "ruler" refers to Satan. See how you translated this in [John 12:31](../12/30.md). AT: "Satan who rules this world"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### John 16:12

#### things to say to you

"messages for you" or "words for you"

#### the Spirit of Truth

This is a name for the Holy Spirit who will tell the people the truth about God.

#### he will guide you into all the truth

The "truth" refers to spiritual truth. AT: "he will teach you all the spiritual truth you need to know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he will say whatever he hears

Jesus implies that God the Father will speak to the Spirit. AT: "he will say whatever God tells him to say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he will take from what is mine and he will tell it to you

Here "things of mine" refers to Jesus' teaching and mighty works. AT: "he will reveal to you that what I have said and done are indeed true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### John 16:15

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### the Spirit will take from what is mine and he will tell it to you

The Holy Spirit will tell people that the words and works of Jesus are true. AT: "The Holy Spirit will tell everyone that my words and works are true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### In a short amount of time

"Soon" or "Before much time passes"

#### after another short amount of time

"again, before much time passes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### John 16:17

#### General Information:

There is a break in Jesus' speaking as his disciples ask each other about what Jesus meant.

#### A short amount of time you will no longer see me

The disciples did not understand that this refers to Jesus' death on the cross.

#### after another short amount of time you will see me

Possible meanings are 1) This could refer to Jesus' resurrection or 2) This could refer to Jesus' coming at the end of time.

#### the Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 16:19

#### Connecting Statement:

Jesus continues speaking to his disciples.

#### Is this what you are asking yourselves, what I meant by saying, ... see me'?

Jesus uses this question so his disciples will focus on what he has just told them, so he can explain further. AT: "You are asking yourselves what I meant when I said, ... see me.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Truly, truly, I say to you

Translate this the way your language emphasizes that what follows is important and true. See how you translated this in [John 1:51](../01/49.md).

#### but the world will be glad

Here the "world" is a metonym for the people who oppose God. AT: "but the people who oppose God will be glad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### but your sorrow will be turned into joy

"Turned into" here is an idiom for "changed into." You can translate this in an active form. AT: "but your sadness will turn into joy" or "but your sorrow will be changed into joy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### John 16:22

#### your heart will be glad

This is an idiom that speaks of the heart as if it were a person. AT: "you will be very happy" or "you will be very joyful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Truly, truly, I say to you

Translate this the way your language emphasizes that what follows is important and true. See how you translated this in [John 1:51](../01/49.md).

#### if you ask anything of the Father in my name, he will give it to you

Here the word "name" is a metonym that refers to the person and authority of Jesus. AT: "if you ask anything of the Father, he will give it to you because you belong to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### in my name

Here "name" is a metonym that refers to the person and authority of Jesus. The Father will honor the requests of the believers because of their relationship with Jesus. AT: "because you are my followers" or "on my authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your joy will be fulfilled

You can translate this in an active form. AT: "God will give you great joy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 16:25

#### in figures of speech

"in language that is not clear"

#### the hour is coming

"it will soon happen"

#### tell you plainly about the Father

"tell you about the Father in a way that you will clearly understand."

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 16:26

#### you will ask in my name

Here "name" is a metonym for the person and authority of Jesus. AT: "you will ask because you belong to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Father himself loves you because you have loved me

When a person loves Jesus, the Son, they also love the Father, because the Father and Son are one.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I came from the Father ... I am leaving the world and I am going to the Father

After his death and resurrection, Jesus will return to God the Father.

#### I came from the Father ... going to the Father

Here "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### world

The "world" is a metonym that refers to the people who live in the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 16:29

#### Connecting Statement:

The disciples respond to Jesus.

#### Do you believe now?

This remarks appears in the form of a question to show that Jesus is puzzled that his disciples are only now ready to trust him. AT: "So, now you finally place your trust in me! (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 16:32

#### Connecting Statement:

Jesus continues speaking to his disciples.

#### you will be scattered

You can translate this in an active form. AT: "others will scatter you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Father is with me

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### so that you will have peace in me

Here "peace" refers to inner peace. AT: "so that you may have inner peace because of your relationship with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I have conquered the world

Here "the world" refers to the troubles and persecution that believers will endure from those who oppose God. AT: "I have conquered the troubles of this world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 16:intro

#### John 16 General Notes ####

####### Special concepts in this chapter #######

######## Comforter ########
This is another name for the Holy Spirit, who is also called the "Spirit of truth." He was already present in the world, but would come in a special way, to dwell in Christians, permanently. Jesus and the Holy Spirit are both God; because of this fact, it can be said that Jesus will live in Christians after his death. This is one of the reasons why it is "better for you that I go away." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]])

######## "The hour is coming" ########
This is a phrase that can also be translated as "the time is coming." Jesus refers to the time after his death as this coming hour. When used, it can be seen as a prophecy. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

####### Important figures of speech in this chapter #######

######## Metaphor ########
Jesus compares his death to the pains of a woman giving birth. It is through pain that new life comes. It is doubtful that the audience would have understood the metaphor when it was spoken. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[John 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | [>>](../17/intro.md)__


## John 17

### John 17:01

#### Connecting Statement:

The part of the story from the previous chapter continues. Jesus had been speaking to his disciples, but now he begins to pray to God.

#### he lifted up his eyes to the heavens

This is an idiom that means to look upward. AT: "he looked up to the sky" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### heavens

This refers to the sky.

#### Father ... glorify your Son so that the Son will glorify you

Jesus asks God the Father to honor him so that he can give honor to God.

#### Father ... Son

These are important titles that describe the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### the hour has come

Here the word "hour" is a metonym that refers to the time for Jesus to suffer and die. AT: "it is time for me to suffer and die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### all flesh

This refers to all people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### John 17:03

#### This is eternal life ... know you, the only true God, and ... Jesus Christ

Eternal life is to know the only true God, God the Father and God the Son.

#### the work that you have given me to do

Here "work" is a metonym that refers to Jesus' entire earthly ministry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Father, glorify me ... with the glory that I had with you before the world was made

Jesus had glory with God the Father "before the world was made" because Jesus is God the Son. AT: "Father, give me honor by bringing me into your presence as we were before we made the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### John 17:06

#### Connecting Statement:

Jesus begins to pray for his disciples.

#### I revealed your name

Here "name" is a metonym that refers to the person of God. AT: "I taught them who you really are and what you are like" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### from the world

Here "world" is a metonym that refers to the people of the world that oppose God. This means that God has separated the believers spiritually from the people who do not believe in him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### kept your word

This is an idiom that means to obey. AT: "obeyed your teaching" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 17:09

#### I do not pray for the world

Here the word "world" is a metonym that refers to the people who oppose God. AT: "I am not praying for those who do not belong to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the world

This is a metonym that refers to being on earth and being among the people who oppose God. AT: "among the people who do not belong to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Holy Father, keep them ... that they will be one ... as we are one

Jesus asks the Father to keep those who trust in him so they can have a close relationship with God.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### keep them in your name that you have given me

Here the word "name" is a metonym that refers to God's protection and oversight. AT: "keep them under the protection of your name just as you have protected me" or "protect them by the power of your name that you have given me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 17:12

#### I kept them in your name

Here "name" is a metonym that refers to the power and protection of God. AT: "I kept them with your protection" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### not one of them was destroyed, except for the son of destruction

"the only one among them who was destroyed is the son of destruction"

#### the son of destruction

This refers to Judas, who betrayed Jesus. AT: "the one whom you long ago decided you would destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so that the scriptures would be fulfilled

You can translate this in an active form. AT: "to fulfill the prophecy about him in the scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the world

Here "world" is a metonym for the people who live in the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that they will have my joy fulfilled in themselves

You can translate this in an active form. AT: "so that you might give them great joy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I have given them your word

"Word" here is a metonym for the entire message of God. AT: "I have given them your message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the world ... because they are not of the world ... I am not of the world

Here "the "world" is a metonym that refers to the people who oppose God. AT: "The people who oppose you have hated my followers because they do not belong to those who do not believe, just as I do not belong to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### John 17:15

#### the world

In this passage, "the world" is a metonym for the people who oppose God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### keep them from the evil one

This refers to Satan. AT: "protect them from Satan, the evil one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Set them apart by the truth

The purpose for setting them apart can be stated clearly. The phrase "by the truth" here represents by teaching the truth. AT: "Make them your own people by teaching them the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Your word is truth

"Word" here is a metonym for message. AT: "Your message is true" or "What you say is true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 17:18

#### into the world

Here into "the world" is a metonym that means to the people who live in the world. AT: "to the people of the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that they themselves may also be set apart in truth

You can translate this in an active form. AT: "so that they may also set apart themselves truly to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### John 17:20

#### those who will believe in me through their word
"Word" is a metonym for "message" or "teaching." AT: "those who will believe in me through their teaching" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they will all be one ... just as you, Father, are in me, and I am in you ... they will also be in us

Those who trust in Jesus become united with the Father and the Son when they believe.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### the world

Here the "the world" is a metonym that refers to the people who do not yet know God. AT: "the people who do not know God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### John 17:22

#### The glory that you gave me, I have given to them

"I have honored my followers just as you have honored me"

#### so that they will be one, just as we are one

You can translate this in an active form. AT: "so that you can unite them just as you have united us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that they may be brought to complete unity

"that they may be completely united"

#### that the world will know

Here "the world" is a metonym that refers to the people who do not know God. AT: "that all the people will know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### loved

This kind of love comes from God and focuses on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### John 17:24

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### where I am

Here "where I am" refers to heaven. AT: "with me in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to see my glory

"to see my greatness"

#### before the creation of the world

Here Jesus refers to the time before creation. AT: "before we created the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

### John 17:25

#### Connecting Statement:

Jesus finishes his prayer.

#### Righteous Father

Here "Father" is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### the world did not know you

The "world" is a metonym for the people who do not belong to God. AT: "those who do not belong to you do not know what you are like" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I made your name known to them

The word "name" refers to God. AT: "I have revealed to them what you are like" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### love ... loved

This kind of love comes from God and focuses on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### John 17:intro

#### John 17 General Notes ####

####### Structure and formatting #######

This chapter forms one long prayer.

####### Special concepts in this chapter #######

######## The eternality of Jesus ########
This chapter makes it clear that Jesus existed before the world was created. 

####### Other possible translation difficulties in this chapter #######

######## Prayer ########
Prayer can be a difficult concept to translate in cultures not familiar with this practice. Since Jesus is God, his prayers are not like the prayers of other men. This chapter can be especially difficult to understand because Jesus does not have a real "need" to pray in order to ask for help, and his prayers can also sound like a command. It would be unacceptable for someone else to pray in this manner.

##### Links: #####

* __[John 17:01 Notes](./01.md)__

__[<<](../16/intro.md) | [>>](../18/intro.md)__


## John 18

### John 18:01

#### General Information:

Verses 1-2 give background information for the events that follow. Verse 1 tells where they took place, and verse 2 gives background information about Judas. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### After Jesus spoke these words

The author uses these words to mark the beginning of a new event. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### Kidron Valley

a valley in Jerusalem separating the Temple Mount from the Mount of Olives (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### where there was a garden

This was a grove of olive trees. AT: "where there was a grove of olive trees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kidronvalley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kidronvalley.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pharisee.md)]]

### John 18:04

#### General Information:

Jesus begins to speak with the soldiers, officers, and Pharisees.

#### Then Jesus, who knew all the things that were happening to him

"Then Jesus, who knew everything that was about to happen to him"

#### Jesus of Nazareth

"Jesus, the man from Nazareth"

#### I am

The word "he" is implied in the text. AT: "I am he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who betrayed him

"who handed him over"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judasiscariot.md)]]

### John 18:06

#### I am

Here the word "he" is not present in the original text, but it is implied. AT: "I am he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### fell to the ground

The men fell to the ground because of Jesus' power. AT: "fell down because of Jesus' power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Jesus of Nazareth

"Jesus, the man from Nazareth"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]

### John 18:08

#### General Information:

In verse 9 there is a break from the main story line as John tells us background information about Jesus fulfilling Scripture. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### I am

Here the word "he" is not present in the original text, but it is implied. AT: "I am he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### This was in order to fulfill the word that he said

Here "the word" refers to the words Jesus had prayed. You can translate this in an active form. AT: "This happened in order to fulfill the words that he had said when he was praying to his Father" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]

### John 18:10

#### Malchus

Malchus is a male servant of the high priest. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### sheath

the cover for a sharp knife or sword, so the knife will not cut the owner

#### Should I not drink the cup that the Father has given me?

This remark appears in the form of a question to add emphasis to Jesus' statement. AT: "I must surely drink the cup that the Father has given to me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the cup

Here "cup" is a metaphor that refers to the suffering that Jesus must endure. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]

### John 18:12

#### General Information:

Verse 14 tells us background information about Caiaphas. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### the Jews

Here "the Jews" is a synecdoche for the Jewish leaders who opposed Jesus. AT: "the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### seized Jesus and tied him up

The soldiers tied Jesus' hands to prevent him from escaping. AT: "captured Jesus and tied him up to prevent him from escaping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caiaphas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caiaphas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]

### John 18:15

#### Now that disciple was known to the high priest, and he entered with Jesus

You can translate this in an active form. AT: "Now the high priest knew that disciple so he was able to enter with Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### So the other disciple, who was known to the high priest

You can translate this in an active form. AT: "So the other disciple, whom the high priest knew" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]

### John 18:17

#### Are you not also one of the disciples of this man?

This appears in the form of a question to enable the servant to express her remark somewhat cautiously. AT: "You are also one of the arrested man's disciples! Are you not?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Now the servants and the officers were standing there, and they had made a charcoal fire, for it was cold, and they were warming themselves

These were the high priest's servants and the temple guards. AT: "It was cold, so the high priest's servants and temple guards made a charcoal fire and were standing and warming themselves around it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Now

This word is used here to mark a break in the main story line so John can add the information about the people who were warming themselves around the fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 18:19

#### General Information:

Here the story line shifts back to Jesus.

#### The high priest

This was Caiphas. (See: [John 18:13](./12.md))

#### about his disciples and his teaching

Here "his teaching" refers to what Jesus had been teaching the people. AT: "about his disciples and what he had been teaching the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I have spoken openly to the world

You may need to make explicit that the word "world" is a metonym for those people who had heard Jesus teach. Here the exaggeration "the world" emphasizes that Jesus has spoken openly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### where all the Jews come together

Here "all the Jews" is an exaggeration that emphasizes that Jesus spoke where anyone who wanted to hear him could hear him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Why did you ask me?

This remark appears in the form of a question to add emphasis to what Jesus is saying. AT: "You should not be asking me these questions!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### John 18:22

#### Is that how you answer the high priest?

This remark appears in the form of a question to add emphasis. AT: "That is not how you should answer the high priest!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### testify about the wrong

"tell me what I said that was wrong"

#### if rightly, why do you hit me?

This remark appears in the form of a question to add emphasis to what Jesus is saying. AT: "if I said only what was right, you should not be hitting me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/annas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/annas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caiaphas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caiaphas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]

### John 18:25

#### General Information:

Here the story line shifts back to Peter.

#### Now

This word is used to mark a break in the story line so John can provide information about Peter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Are you not also one of his disciples?

This remark appears in the form of a question to add emphasis. AT: "You are also one of his disciples!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Did I not see you in the garden with him?

This remark appears in the form of a question to add emphasis. Here the word "him" refers to Jesus. AT: "I saw you in the olive tree grove with the man they arrested! Did I not?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Peter then denied again

Here it is implied that Peter denied knowing and being with Jesus. AT: "Peter then denied again that he knew Jesus or that he had been with him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### immediately the rooster crowed

Here it is assumed the reader will remember that Jesus had said Peter would deny him before the rooster crowed. AT: "immediately the rooster crowed, just as Jesus had said would happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]

### John 18:28

#### General Information:

Here the story line shifts back to Jesus. The soldiers and Jesus' accusers bring him to Caiaphas. Verse 28 gives us background information about why they did not enter the Praetorium. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Then they led Jesus from Caiaphas

Here it is implied that they are leading Jesus from Caiaphas' house. AT: "Then they led Jesus from Caiaphas' house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they did not enter the government headquarters so that they would not be defiled

Pilate was not a Jew, so if the Jewish leaders entered his headquarters, they would be defiled. This would have prevented them from celebrating the Passover. You can translate the double negative in a positive form. AT: "they themselves remained outside Pilate's headquarters because Pilate was a Gentile. They did not want to become defiled" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### If this man was not an evildoer, we would not have given him over to you

You can translate this double negative in a positive form. AT: "This man is an evil doer, and we had to bring him to you for punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### given him over

This phrase here means to hand over to an enemy.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]

### John 18:31

#### General Information:

In verse 32 there is a break from the main story line as the author tells us background information about how Jesus' predicted how he would die. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### The Jews said to him

Here "Jews" is a synecdoche for the Jewish leaders who opposed Jesus and arrested him. AT: "The Jewish leaders said to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### It is not lawful for us to put any man to death

According to Roman law, the Jews could not put a man to death. AT: "According to Roman law, we cannot put a person to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so that the word of Jesus would be fulfilled

You can translate this in an active form. AT: "in order to fulfill what Jesus had said earlier" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to indicate by what kind of death he would die

"regarding how he would die"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 18:33

#### I am not a Jew, am I?

This remark appears in the form of a question so Pilate can emphasize his complete lack of interest in the cultural affairs of the Jewish people. AT: "Well I am certainly not a Jew, and I have no interest in these matters!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Your own people

"Your fellow Jews"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]

### John 18:36

#### My kingdom is not of this world

Here "world" is a metonym for the people who oppose Jesus. Possible meanings are 1) "My kingdom is not part of this world" or 2) "I do not need this world's permission to rule as their king" or "It is not from this world that I have authority to be king." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that I would not be given over to the Jews

You can translate this in an active form. AT: "and would prevent the Jewish leaders from arresting me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Jews

Here "Jews" is a synecdoche that refers to the Jewish leaders who opposed Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### I have come into the world

Here "world" is a synecdoche that refers to the people who live in the world. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### bear witness to the truth

Here "the truth" refers to the truth about God. AT: "tell people the truth about God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who belongs to the truth

This is an idiom that refers to anyone who loves the truth about God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my voice

Here "voice" is a synecdoche that refers to words Jesus says. AT: "the things I say" or "me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### John 18:38

#### What is truth?

This remark appears in the form of a question to reflect Pilate's belief that no one really knows what truth is. AT: "No one can know what is true!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the Jews

Here "Jews" is a synecdoche that refers to the Jewish leaders who opposed Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Not this man, but Barabbas

This is an ellipsis. You can add the implied words. AT: "No! Do not release this man! Release Barabbas instead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Now Barabbas was a robber

Here John provides background information about Barabbas. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/barabbas.md)]]

### John 18:intro

#### John 18 General Notes ####

####### Structure and formatting #######

Verses 13 and 14 state, "for he was father-in-law to Caiaphas, who was high priest that year. Now Caiaphas was the one who had given the advice to the Jews that it would be better that one man die for the people." This is a parenthetical statement being made by the author. It is intended to explain important background information. It is possible to put this information in parentheses. 

####### Special concepts in this chapter #######

######## "It is not lawful for us to put any man to death" ########
The Roman Empire did not allow the Jews to enforce a penalty of death upon anyone. Therefore, the Jews had to present their case to the pagan ruler, Pilate. 

==Jesus' kingdom ==
Jesus explains to Pilate that his kingdom is not "of this world." Some scholars take this to mean that Jesus rules a spiritual kingdom, while others claim Jesus meant his kingdom was not in competition with the Roman Empire. It is possible to translate the phrase as Jesus' kingdom "is not from this place" or "comes from another place."

####### Important figures of speech in this chapter #######

######## "King of the Jews" ########
This phrase is used in two different ways in this passage. First, Jesus is said to be the king of the Jews. He is the king of the Jews and the whole world. Second, it is used ironically or sarcastically by Pilate. Pilate does not believe Jesus to be the king of the Jews. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

##### Links: #####

* __[John 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__


## John 19

### John 19:01

#### Connecting Statement:

The part of the story from the previous chapter continues. Jesus is standing before Pilate as he is being accused by the Jews.

#### Then Pilate took Jesus and whipped him

Pilate himself did not whip Jesus. Here "Pilate" is a synecdoche for the soldiers that Pilate ordered to whip Jesus. AT: "Then Pilate ordered his soldiers to whip Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Hail, King of the Jews

The greeting "Hail" with a raised hand was only used to greet Caesar. As the soldiers use the crown of thorns and the purple robe to mock Jesus, it is ironic that they do not recognize that he is indeed a king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]

### John 19:04

#### I find no guilt in him

Pilate states this twice to say he does not believe Jesus is not guilty of any crime. He does not want to punish him. AT: "I see no reason to punish him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### crown of thorns ... purple garment

The crown and the purple robe are things only kings wear. The soldiers dressed Jesus in this manner to mock him. See [John 19:2](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]

### John 19:07

#### The Jews answered him

Here "Jews" is a synecdoche for the Jewish leaders who opposed Jesus. AT: "The Jewish leaders answered Pilate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he has to die because he claimed to be the Son of God

Jesus was condemned to death by crucifixion because he claimed he was "the Son of God."

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### John 19:10

#### Are you not speaking to me?

This remark appears in the form of a question. Here Pilate expresses his surprise that Jesus does not take the opportunity to defend himself. AT: "I cannot believe you are refusing to speak to me!" or "Answer me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Do you not know that I have power to release you, and power to crucify you?

This remark appears in the form of a question to add emphasis. AT: "You should know that I am able to release you or to order my soldiers to crucify you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### power

Here "power" is a metonym that refers to the ability to do something or to cause something to happen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You do not have any power over me except for what has been given to you from above

You can translate this double negative in a positive and active form. AT: "You are able to act against me only because God has made you able" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from above

This is a respectful way of referring to God.

#### gave me over

This phrase here means to hand over to an enemy.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### John 19:12

#### At this answer

Here "this answer" refers to Jesus' answer. AT: "When Pilate heard Jesus' answer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Pilate tried to release him

The form of "tried" in the original indicates that Pilate tried "hard" or "repeatedly" to release Jesus. AT: "he tried hard to release Jesus" or "he tried again and again to release Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but the Jews cried out

Here "Jews" is a synecdoche that refers to the Jewish leaders that opposed Jesus. In the original, the form of "cried out" indicates that they cried out or shouted repeatedly. AT: "but the Jewish leaders kept shouting" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you are not a friend of Caesar

"you are opposing Caesar" or "you are opposing the emperor"

#### makes himself a king

"claims that he is a king"

#### he brought Jesus out

Here "he" refers to Pilate and is a synecdoche for "Pilate ordered the soldiers." AT: "he ordered the soldiers to bring Jesus out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### sat down

Important people like Pilate sat down when they performed an official duty, while people who were not so important stood up.

#### in the judgment seat

This is the special chair that an important person like Pilate sat in when he was making an official judgment. If your language has a special way to describe this action, you can use it here.

#### in a place called "The Pavement," but

This is a special stone platform where only the important people were allowed to go. You can translate this in an active form. AT: "in a place the people called The Pavement, but" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Hebrew

This refers to the language that the people of Israel spoke.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]

### John 19:14

#### Connecting Statement:

Some time has passed and it is now the sixth hour, as Pilate orders his soldiers to crucify Jesus.

#### Now

This word marks a break in the story line so that John can provide information about the upcoming Passover and the time of day. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### the sixth hour

"about noontime"

#### Pilate said to the Jews

Here "Jews" is a synecdoche that refers to the Jewish leaders who opposed Jesus. AT: "Pilate said to the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Should I crucify your King?

Here "I" is a synecdoche that refers to Pilate's soldiers who will actually perform the crucifixion. AT: "Do you really want me to tell my soldiers to nail your king to a cross?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Then Pilate gave Jesus over to them to be crucified

Here Pilate gives the order for his soldiers to crucify Jesus. You can translate this in an active form. AT: "So Pilate ordered his soldiers to crucify Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caesar.md)]]

### John 19:17

#### to the place called "The Place of a Skull,"

You can translate this in an active form. AT: "to the place that the people called 'The Place of a Skull,'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### which in Hebrew is called "Golgotha."

Hebrew is the language of the people of Israel. You can translate this in an active form. AT: "which in Hebrew they call 'Golgotha.'"

#### with him two other men

This is an ellipsis. You can translate this, adding the implied words. AT: "they also nailed two other criminals to their crosses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/skull.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/skull.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/golgotha.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/golgotha.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]

### John 19:19

#### Pilate also wrote a sign and put it on the cross

Here "Pilate" is a synecdoche for the person who wrote on the sign. Here "on the cross" refers to Jesus' cross. AT: "Pilate also commanded someone to write on a sign and to attach it to Jesus' cross" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### There it was written: JESUS OF NAZARETH, THE KING OF THE JEWS

You can translate this in an active form. AT: "So that person wrote the words: Jesus of Nazareth, King of the Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the place where Jesus was crucified

You can translate this in an active form. AT: "the place where the soldiers crucified Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The sign was written in Hebrew, in Latin, and in Greek

You can translate this in an active form. AT: "The one who prepared the sign wrote the words in 3 languages: Hebrew, Latin, and Greek" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Latin

This was the language of the Roman government.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nazareth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]

### John 19:21

#### Then the chief priests of the Jews said to Pilate

The chief priests had to go back to Pilate's headquarters to protest to him about the words on the sign. AT: "The chief priests went back to Pilate and said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### What I have written I have written

Pilate implies that he will not change the words on the sign. AT: "I have written what I wanted to write, and I will not change it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chiefpriests.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/kingofthejews.md)]]

### John 19:23

#### General Information:

At the end of verse 24 there is a break from the main story line as the John tells us how this event fulfills Scriture. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### also the tunic

"and they also took his tunic." The soldiers kept the tunic separate and did not divide it. AT: "they kept his tunic separate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### let us cast lots for it to decide whose it will be

The soldiers will gamble and the winner will receive the shirt. AT: "let us gamble for the tunic and the winner will get to keep it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so that the scripture would be fulfilled which said

You can translate this in an active form. AT: "This fulfilled the scripture that said" or "This happened to make the scripture come true which said"

#### cast lots

This was how the soldiers divided Jesus' clothing among themselves. AT: "they gambled"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]

### John 19:25

#### the disciple whom he loved

This is John, the writer of this Gospel.

#### Woman, see, your son

Here the word "son" is a metaphor. Jesus wants his disciple, John, to be like a son to his mother. AT: "Woman, here is the man who will act like a son to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### See, your mother

Here the word "mother" is a metaphor. Jesus wants his mother to be like a mother to his disciple, John. AT: "Think of this woman as if she were your own mother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### From that hour

"From that very moment"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/cross.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]

### John 19:28

#### knowing that everything was now completed

You can translate this in an active form. AT: "he knew that he had done everything that God had sent him to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### A container full of sour wine was placed there

You can translate this in an active form. AT: "Someone had placed there a full container of sour wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sour wine

"bitter wine"

#### they put

Here "they" refers to the Roman guards.

#### a sponge

a small object that can soak up and hold much liquid

#### on a hyssop staff

"on a branch of a plant called hyssop"

#### He bowed his head and gave up his spirit

John implies here that Jesus gave his spirit back to God. AT: "He bowed his head and gave God his spirit" or "He bowed his head and died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]

### John 19:31

#### the Jews

Here "Jews" is a synecdoche for the Jewish leaders who opposed Jesus. AT: "the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### day of preparation

This is the time before the Passover when people prepared food for the Passover.

#### to break their legs and to remove them

You can translate this in an active form. AT: "to break the legs of the executed men and take their bodies down from the crosses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who had been crucified with Jesus

You can translate this in an active form. AT: "whom they had crucified near Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]

### John 19:34

#### The one who saw this

This sentence gives background information to the story. John is telling readers that he was there and that we can trust what he has written. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### has testified, and his testimony is true

To "testify" means to tell about something that one has seen. AT: "has told the truth about what he has seen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### so that you would also believe

Here "believe" means to put one's trust in Jesus. AT: "so that you will also put your trust in Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 19:36

#### General Information:

In these verses there is a break from the main story line as John tells us about how these events have made Scripture come true. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### in order to fulfill scripture

You can translate this in an active form. AT: "to fulfill the words that someone wrote in the scripture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Not one of his bones will be broken

This is a quotation from Psalm 34. You can translate this in an active form. AT: "No one will break any of his bones" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They will look at him whom they pierced

This is a quotation from Zechariah 12.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pierce.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pierce.md)]]

### John 19:38

#### Joseph of Arimathea

Arimathea was a small town. AT: "Joseph from the town of Arimathea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### for fear of the Jews

Here "Jews" is a synecdoche for the Jewish leaders who opposed Jesus. AT: "for fear of the Jewish leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### if he could take away the body of Jesus

John implies that Joseph of Arimathea wants to bury the body of Jesus. AT: "for permission to take the body of Jesus down from the cross for burial" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Nicodemus

Nicodemus was one of the Pharisees who believed in Jesus. See how you translated this name in [John 3:1](../03/01.md).

#### myrrh and aloes

These are spices that people use to prepare a body for burial.

#### about one hundred litras in weight

You may convert this to a modern measure. A "litra" is about one third of a kilogram. AT: "about 33 kilograms in weight" or "weighing about thirty-three kilograms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### one hundred

"100" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pilate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]

### John 19:40

#### Now in the place where he was crucified there was a garden ... had yet been buried

Here John marks a break in the story line in order to provide background information about the location of the tomb where they would bury Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Now in the place where he was crucified there was a garden

You can translate this in an active form. AT: "Now in the place where they crucified Jesus there was a garden" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in which no person had yet been buried

You can translate this in an active form. AT: "in which people had buried no one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Because it was the day of preparation for the Jews

According to Jewish law, no one could work after sundown on Friday. It was the beginning of the Sabbath and Passover. AT: "The Passover was about to begin that evening" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### John 19:intro

#### John 19 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 19:24, which is quoted from the OT.

####### Special concepts in this chapter #######

######## "Purple garment" ########
The color purple was a sign of royalty in the ancient Near East. Jesus was mockingly dressed to look like a king.

######## "You are not Caesar's friend" ########
Pilate did not want to sentence Jesus to death, but the Jews forced him. They did this to make it seem as if allowing Jesus to live would betray the Roman government.

####### Important figures of speech in this chapter #######

######## Sarcasm ########
The following phrases are intended to be taken sarcastically: "Hail, King of the Jews," "Should I crucify your king?" and "Jesus of Nazareth, King of the Jews." Sarcasm is the use of irony to insult someone. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

####### Other possible translation difficulties in this chapter #######

######## Gabbatha, Golgotha ########
These are two Hebrew words. After translating the meanings of these words ("The Pavement" and "The Place of a Skull"), the author transliterates their sounds by writing them with Greek letters.

##### Links: #####

* __[John 19:01 Notes](./01.md)__

__[<<](../18/intro.md) | [>>](../20/intro.md)__


## John 20

### John 20:01

#### General Information:

This is the third day after Jesus was buried.

#### first day of the week

"Sunday"

#### she saw the stone rolled away

You can translate this in an active form. AT: "she saw that someone had rolled away the stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### disciple whom Jesus loved

This phrase appears to be the way that John refers to himself throughout his book. Here the word "love" refers to brotherly love or love for a friend or family member.

#### They took away the Lord out from the tomb

Mary Magdalene thinks that someone has stolen the Lord's body. AT: "Someone has taken the Lord's body out of the tomb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 20:03

#### the other disciple

John apparently shows his humility by referring to himself here as "the other disciple," rather than including his name.

#### went out

John implies that these disciples were going to the tomb. AT: "rushed out to the tomb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### linen cloths

These were the burial cloths that people had used to wrap the body of Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### John 20:06

#### linen cloths

These were the burial cloths that people had used to wrap the body of Jesus. See how you translated this in [John 20:5](./03.md).

#### cloth that had been on his head

Here "his head" refers to "Jesus' head." You can translate this in an active form. AT: "cloth that someone had used to cover Jesus' face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### but was folded up in a place by itself

This can be stated in active form. AT: "but someone had folded it and put it aside, separate from the linen cloths" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### John 20:08

#### the other disciple

John apparently expresses his humility by referring to himself as "the other disciple," rather than including his name in this book.

#### he saw and believed

When he saw that the tomb was empty, he believed that Jesus had risen from the dead. AT: "he saw these things and began to believe that Jesus had risen from the dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they still did not know the scripture

Here the word "they" refers to the disciples who did not understand the scripture that said Jesus would rise again. AT: "the disciples still did not understand the scripture" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### rise

become alive again

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld.

#### went back home again

The disciples continued to stay in Jerusalem. AT: "went back to where they were staying in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 20:11

#### She saw two angels in white

The angels were wearing white clothing. AT: "She saw two angels dressed in white clothing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They said to her

"They asked her"

#### Because they took away my Lord

"Because they took away the body of my Lord"

#### I do not know where they have put him

"I do not know where they have put it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 20:14

#### Jesus said to her

"Jesus asked her"

#### Sir, if you have taken him away

Here the word "him" refers to Jesus. AT: "If you have taken away the body of Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### tell me where you have put him

"tell me where you have put it"

#### I will take him away

Mary Magdalene wants to get Jesus' body and bury it again. AT: "I will get the body and bury it again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### John 20:16

#### Rabboni

The word "Rabboni" means rabbi or teacher in Aramaic, the language that Jesus and his disciples spoke.

#### brothers

Jesus used the word "brothers" to refer to his disciples.

#### I will go up to my Father and your Father, and my God and your God

Jesus rose from the dead and then predicted he would go up into heaven, back to his Father, who is God. AT: "I am about to return to heaven to be with my Father and your Father, to the one who is my God and your God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### my Father and your Father

These are important titles that describe the relationship between Jesus and God, and between believers and God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Mary Magdalene came and told the disciples

Mary Magdalene went to where the disciples were staying and told them what she had seen and heard. AT: "Mary Magdalene went to where the disciples were and told them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/marymagdalene.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/rabbi.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/teacher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### John 20:19

#### General Information:

It is now evening and Jesus appears to the disciples.

#### that day, the first day of the week

This refers to Sunday.

#### the doors of where the disciples were, were closed

You can translate this in an active form. AT: "the disciples had locked the doors where they were" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for fear of the Jews

Here "Jews" is a synecdoche for the Jewish leaders who might arrest the disciples. AT: "because they were afraid that the Jewish leaders might arrest them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Peace to you

This is a common greeting that means "May God give you peace" .

#### he showed them his hands and his side

Jesus showed the disciples his wounds. AT: "he showed them the wounds in his hands and his side" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### John 20:21

#### Peace to you

This is a common greeting that means "May God give you peace" .

#### As the Father has sent me, so I am sending you ... he ... said to them, "Receive the Holy Spirit

God the Father sent God the Son who now sends the believers in the power of God the Holy Spirit.

#### Father

This is an important title for God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### they are forgiven

You can translate this in an active form. AT: "God will forgive them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### whoever's sins you keep back

"If you do not forgive another's sins"

#### they are kept back

You can translate this in an active form. AT: "God will not forgive them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]

### John 20:24

#### Didymus

This is a male name that means "twin." See how this name is translated in [John 11:15](../11/15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### disciples later said to him

The word "him" refers to Thomas.

#### Unless I see ... his side, I will not believe

You can translate this double negative in a positive form. AT: "I will believe only if I see ... his side" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### in his hands ... into his side

The word "his" refers to Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/thetwelve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 20:26

#### his disciples

The word "his" refers to Jesus.

#### while the doors were closed

You can translate this in an active form. AT: "when they had locked the doors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Peace to you

This is a common greeting that means "May God give you peace" .

#### unbelieving

"without belief" or "without faith"

#### but believe

Here "believe" means to trust in Jesus. AT: "put your trust in me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]

### John 20:28

#### you have believed

Thomas believes that Jesus is alive because he has seen him. AT: "you have believed that I am alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Blessed are those

This means "God gives great happiness to those."

#### who have not seen

This means those who have not seen Jesus. AT: "who have not seen me alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### John 20:30

#### General Information:

As the story is nearing the end, the author comments about the many things Jesus did. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md)]])

#### signs

The word "signs" refers to miracles that show that God is the all-powerful one who has complete authority over the universe.

#### signs that have not been written in this book

You can translate this in an active form. AT: "signs that the author did not write about in this book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### but these have been written

You can translate this in an active form. AT: "but the author wrote about these signs" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### life in his name

Here "life" is a metonym that means Jesus gives life. AT: "you may have life because of Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### life

This refers to spiritual life.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### John 20:intro

#### John 20 General Notes ####

####### Special concepts in this chapter #######

######## "Receive the Holy Spirit" ########
The disciples had special power from the Holy Spirit given to them. He empowered their ministry.

####### Other possible translation difficulties in this chapter #######

######## Rabboni ########
This is a Hebrew word. Mark "transliterate" its sounds by substituting the Hebrew letters with Greek letters. Then he explains that it means "Teacher." The translator should do the same, but transliterate it using letters of the target language.

######## Jesus' resurrection body ########
There is some mystery about Jesus' body at this point. He was physically present with the scars from the crucifixion but he could also enter into rooms without having to use a door. It is best to leave the mystery in place but explanation may be necessary if the translation does not make sense to the reader.

######## Two angels in white ########
Matthew, Mark, Luke, and John all wrote about angels in white clothing with the women at Jesus' tomb. Two of the authors called them men, but that is only because the angels were in human form. Two of the authors wrote about two angels, but the other two authors wrote about only one of them. It is best to translate each of these passages as it appears in the ULB without trying to make the passages all say exactly the same thing. (See: [Matthew 28:1-2](../../mat/28/01.md), [Mark 16:5](../../mrk/16/05.md) and [Luke 24:4](../../luk/24/04.md) and [John 20:12](../../jhn/20/11.md))

##### Links: #####

* __[John 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__


## John 21

### John 21:01

#### General Information:

Jesus shows himself again to the disciples at the Sea of Tiberias. Verses 2 and 3 tell us what happens in the story before Jesus appears. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### After these things

"Some time later"

#### with Thomas called Didymus

You can translate this in an active form. AT: "with Thomas whom we called Didymus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Didymus

This is a male name that means "twin." See how this name is translated in [John 11:15](../11/15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/seaofgalilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/thomas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cana.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cana.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/galilee.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebedee.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebedee.md)]]

### John 21:04

#### Young men

This is a term of endearment that means "My dear friends."

#### you will find some

Here "some" refers to fish. AT: "you will catch some fish in your net" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### draw it in

"pull the net in"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]

### John 21:07

#### loved

This is love that comes from God and is focused on the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### he tied up his outer garment

"he secured his outer garment around him" or "he put on his tunic"

#### for he was undressed

This is background information. Peter had taken off some of his clothes to make it easier to work, but now that he was about to greet the Lord, he wanted to wear more clothing. AT: "for he had taken off some of his clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### threw himself into the sea

Peter jumped into the water and swam to shore. AT: "jumped into the sea and swam to shore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### threw himself

This is a idiom that means Peter jumped into the water very quickly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### for they were not far from the land, about two hundred cubits off

This is background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### two hundred cubits

"90 meters." A cubit was a little less than half a meter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]

### John 21:10

#### Simon Peter then went up

Here "went up" means Simon Peter had to go back to the boat. AT: "So Simon Peter went back to the boat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### drew the net to land

"pulled the net to the shore"

#### the net was not torn

You can translate this as an active form. AT: "the net did not break" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### full of large fish; 153

"full of large fish, one hundred and fifty-three." There were 153 large fish. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

### John 21:12

#### breakfast

the morning meal

#### the third time

You can translate this ordinal term "third" as "time number 3." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### John 21:15

#### General Information:

Jesus begins to have a conversation with Simon Peter.

#### do you love me ... do you love me

Here "love" refers the type of love that comes from God, which focuses on the good of others, even when it does not benefit oneself.

#### you know that I love you

When Peter answers, he uses the word for "love" that refers to brotherly love or love for a friend or family member.

#### Feed my lambs

Here "lambs" is a metaphor for those persons who love Jesus and follow him. AT: "Feed the people I care for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Take care of my sheep

Here "sheep" is a metaphor for those who love and follow Jesus. AT: "Care for the people I care for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### John 21:17

#### He said to him a third time

The pronoun "he" refers to Jesus. Here "a third time" means "time number 3." AT: "Jesus said to him a third time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### do you love me

This time when Jesus asks this question he uses the word for "love" that refers to brotherly love or love for a friend or family member.

#### Feed my sheep

Here "sheep" is a metaphor that represents those who belong to Jesus and follow him. AT: "Care for the people I care for" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Truly, truly

See how you translated this in [John 1:51](../01/49.md).

#### and walk wherever you wanted

"Walk wherever" here is an idiom for "live freely." AT: "and live freely however you wanted" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### John 21:19

#### Now

John uses this word to show he is giving background information before he continues the story. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### to indicate with what kind of death Peter would glorify God

Here John implies that Peter would die on a cross. AT: "to indicate that Peter would die on a cross to honor God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Follow me

Here the word "follow" means "to be a disciple." AT: "Keep on being my disciple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/peter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### John 21:20

#### the disciple whom Jesus loved

John refers to himself in this way throughout the book, rather than mentioning his name.

#### loved

This is the kind of love that comes from God and always desires the good of others, even when it does not benefit oneself. This kind of love cares for others, no matter what they do.

#### at the dinner

This is a reference to the Last Supper. (See: [John Chapter 13](../13/01.md))

#### Peter saw him

Here "him" refers to "the disciple whom Jesus loved."

#### Lord, what will this man do?

Peter wants to know what will happen to John. AT: "Lord, what will happen to this man?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/disciple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]

### John 21:22

#### Jesus said to him

"Jesus said to Peter"

#### If I want him to stay

Here "him" refers to the "disciple whom Jesus loved" in [John 21:20](./20.md).

#### I come

This refers to Jesus' second coming, his return to earth from heaven.

#### what is that to you?

This remark appears in the form of a question to express a mild rebuke. AT: "that is not your concern." or "you should not be concerned about that." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### among the brothers

Here "the brothers" refers to all the followers of Jesus.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### John 21:24

#### General Information:

This is the end of the Gospel of John. Here the author, the Apostle John, gives a closing comment about himself and what he has written in this book. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md)]])

#### the disciple

"the disciple John"

#### who testifies about these things

Here "testifies" means that he personally sees something. AT: "who has seen all these things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### we know

Here "we" refers to those who trust in Jesus. AT: "we who trust in Jesus know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If each one were written down

You can translate this in an active form. AT: "If someone wrote down all of them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### even the world itself could not contain the books

John exaggerates to emphasize that Jesus did many more miracles than what people could write about in many books. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the books that would be written

You can translate this in an active form. AT: "the books that people could write about what he did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]

### John 21:intro

#### John 21 General Notes ####

####### Important figures of speech in this chapter #######

######## Metaphors ########
Jesus uses many shepherding metaphors. For example, "feed my lambs," "tend my sheep" and "feed my sheep." Peter would now be a shepherd of the people of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[John 21:01 Notes](./01.md)__

__[<<](../20/intro.md) | __


## John front

### John front:intro

#### Introduction to the Gospel of John ####

##### Part 1: General Introduction #####

####### Outline of the Gospel of John #######

1. Introduction about who Jesus is (1:1-18) 
1. Jesus is baptized, and he chooses twelve disciples (1:19-51)
1. Jesus preaches, teaches, and heals people (2-11)
1. The seven days before Jesus' death (12-19)
     - Mary anoints the feet of Jesus (12:1-11)
     - Jesus rides a donkey into Jerusalem (12:12-19)
     - Some Greek men want to see Jesus (12:20-36)
     - The Jewish leaders reject Jesus (12:37-50)
     - Jesus teaches his disciples (13-17)
     - Jesus is arrested and undergoes trial (18:1-19:15)
     - Jesus is crucified and buried (19:16-42)
1. Jesus rises from the dead (20:1-29)
1. John says why he wrote his gospel (20:30-31)
1. Jesus meets with the disciples (21)

####### What is the Gospel of John about? #######

The Gospel of John is one of four books in the New Testament that describe some of the life of Jesus Christ. The authors of the gospels wrote about different aspects of who Jesus was and what he did. John said that he wrote his gospel "so that people might believe that Jesus is the Christ, the Son of the living God" (20:31). 

John's Gospel is very different from the other three Gospels. John does not include some of the teachings and events that the other writers included in their gospels. Also, John wrote about some teachings and events that are not in the other gospels.

John wrote much about the signs Jesus did to prove that what Jesus said about himself was true. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]])

####### How should the title of this book be translated? #######

Translators may choose to call this book by its traditional title, "The Gospel of John" or "The Gospel According to John." Or they may choose a title that may be clearer, such as, "The Good News About Jesus That John Wrote." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Gospel of John? #######

This book does not give the name of the author. However, since early Christian times, most Christians have thought that the Apostle John was the author.
##### Part 2: Important Religious and Cultural Concepts #####

####### Why does John write so much about the final week of Jesus' life? #######

John wrote much about Jesus' final week. He wanted his readers to think deeply about Jesus' final week and his death on the cross. He wanted people to understand that Jesus willingly died on the cross so that God could forgive them for sinning against him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Part 3: Important Translation Issues #####

####### What do the words "remain," "reside," and "abide" mean in the Gospel of John? #######

John often used the words "remain," "reside", and "abide" as metaphors. John spoke of a believer becoming more faithful to Jesus and knowing Jesus better as if Jesus' word "remained" in the believer. Also, John spoke of someone being spiritually joined to someone else as if the person "remained" in the other person. Christians are said to "remain" in Christ and in God. The Father is said to "remain" in the Son, and the Son is said to "remain" in the Father. The Son is said to "remain" in believers. The Holy Spirit is also said to "remain" in the believers. 
 
Many translators will find it impossible to represent these ideas in their languages in exactly the same way. For example, Jesus intended to express the idea of the Christian being spiritually together with him when he said, "He who eats my flesh and drinks my blood remains in me, and I in him" (John 6:56). The UDB uses the idea of "will be joined to me, and I will be joined to him." But translators may have to find other ways of expressing the idea.

In the passage, "If my words remain in you" (John 15:7), the UDB expresses this idea as, "If you live by my message." Translators may find it possible to use this translation as a model.  

####### What are the major issues in the text of the Gospel of John? #######

These are the most significant textual issues in the Gospel of John:

* "waiting for the moving of the water. For an angel of the Lord occasionally went down into the pool and stirred the water and whoever went first after the stirring of the water, was made well from the disease they had." (5:3-4)

Translators are advised not to translate this passage. However, if in the translators' region, there are older versions of the Bible that include this passage, the translators can include it. If it is translated, it should be put inside square brackets ([]) to indicate that it was probably not original to John's Gospel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])

* The story of the adulterous woman (7:53–8:11)

This passage is included in most older and modern versions of the Bible. But it is not in the earliest copies of the Bible. Translators are advised to translate this passage. It should be put inside of square brackets ([]) to indicate that it may not have been original to John's Gospel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])

Some old versions also have this passage:

* "going through the midst of them, and so passed by" (8:59)

But it is very certain that this passage was not original to the Gospel of John. It should not be included. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

