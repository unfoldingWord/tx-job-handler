# <a id="exo"/>Exodus

## Exodus 01

### Exodus 01:01

#### household

This refers to all the people who live in a house together, usually a large family with servants. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Joseph was already in Egypt

"Joseph lived in Egypt before his brothers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]

### Exodus 01:06

#### all his brothers

This includes 10 older brothers and 1 younger brother.

#### were fruitful

The birth of children to the Israelites is spoken of as if they were plants that were producing fruit. AT: "had many children" or "gave birth to many children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the land was filled with them

This can be stated in active form. AT: "They filled the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### with them

The word "them" refers to the Israelites.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 01:08

#### arose over Egypt

Here "Egypt" refers to the people of Egypt. AT: "began to rule over the people of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He said to his people

"The king said to his people"

#### his people

These were the people who lived in Egypt, the Egyptians.

#### let us

The word "us" is inclusive and refers to the king and his people, the Egyptians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### war breaks out

Here war is spoken of as a person that is able to act. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### leave the land

"leave Egypt"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]

### Exodus 01:11

#### taskmasters

Egyptians whose job was to force the Israelites to do hard work

#### to oppress them with hard labor

"to force the Israelites to do hard work for the Egyptians"

#### store cities

These were places where the leaders put food and other important things to keep them safe.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 01:13

#### made ... work rigorously

"made ... work very hard" or "harshly made ... work"

#### made their lives bitter

The difficult lives of the Israelites are spoken of as if they were bitter food that was difficult to eat. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### mortar

This was a wet glue or mud put between bricks or stones that held them together when it dried.

#### All their required work was hard

"The Egyptians made them work very hard" or "The Egyptians forced them to work very hard"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Exodus 01:15

#### king of Egypt

The king of Egypt is called Pharaoh.

#### midwives

These were women who helped a woman give birth to a baby.

#### Shiphrah ... Puah

These are Hebrew women's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### on the birthstool

Women sat on this short stool as they gave birth. Therefore, it is associated with birth. AT: "as they give birth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Exodus 01:18

#### midwives

These were women who helped a woman give birth to a baby. See how you translated this in [Exodus 1:16](./15.md).

#### Why have you done this, and let the baby boys live?

Pharaoh asked this question to rebuke the midwives for allowing the male children to live. This rhetorical question can be translated as a statement. AT: "You have disobeyed my order by not killing the male babies!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The Hebrew women are not like the Egyptian women

The midwives answered wisely to appease Pharaoh's anger.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]

### Exodus 01:20

#### God protected these midwives

God kept Pharaoh from killing these midwives.

#### midwives

These were women who helped a woman give birth to a baby. See how you translated this in [Exodus 1:16](./15.md).

#### The people increased in numbers

"The Israelites increased in numbers"

#### feared God

"revered God" or "had reverence for God"

#### he gave them families

"the enabled them to have children"

#### You must throw every son ... into the river

This order was given in order to drown the male children. The full meaning of this may be made explicit. AT: "You must ... into the river so they will drown" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]

### Exodus 01:intro

#### Exodus 01 General Notes ####

####### Structure and formatting #######

This chapter is intended to form a smooth transition with the last chapter of the book of Genesis.

####### Special concepts in this chapter #######

######## Israel's growth ########
Israel grew in number. This was in fulfillment of the covenant God made with Abraham. It also caused the Egyptians great concern that there would be more Israelites than Egyptians because they would be unable to defend themselves against such a large number of people. Pharaoh also tried to kill all of the male babies so they would not become soldiers who fought against him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

######## End of the famine ########
It is obvious that some time has passed since the beginning of the famine which brought the Israelites into Egypt. Yahweh appears to be punishing the Hebrews for not returning back to the Promised Land and instead choosing to stay in Egypt. No return attempt is recorded to have been made. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Other possible translation difficulties in this chapter #######

######## "All of the descendants of Jacob were seventy in number" ########
This number included both Jacob's children and grandchildren. It may cause confusion, but it is important to remember Jacob only had 12 sons. 

##### Links: #####

* __[Exodus 01:01 Notes](./01.md)__
* __[Exodus intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Exodus 02

### Exodus 02:01

#### Now

This word is used here to mark a break in the main event. Here the author starts to tell a new part of the narrative. If you have a way of doing this in your language, consider using it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### three

"3" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Exodus 02:03

#### papyrus basket

This is a basket made from a tall grass that grows by the Nile River in Egypt.

#### sealed it with bitumen and pitch

You could explicitly state that this was to keep out water. AT: "spread tar on it to keep water from getting into it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### sealed

Here "sealed" means that she applied a waterproof coating.

#### bitumen

This is a sticky black paste made from petroleum. It can be used to keep out water. AT: "tar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### pitch

This is a sticky brown or black paste that can be made from tree sap or from petroleum. Therefore, "pitch" would include not only "bitumen" but also plant-based resins. It too can be used to keep out water. AT: "tar" or "resin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### reeds

These "reeds" were a type of tall grass that grew in flat, wet areas.

#### at a distance

This means she stood far enough away so that she would not be noticed, but close enough to see the basket.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]

### Exodus 02:05

#### attendants

"servants"

#### Behold

The word "behold" signals the surprising information that follows.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]

### Exodus 02:07

#### nurse

"breastfeed"

### Exodus 02:09

#### she brought him

"the Hebrew woman brought him"

#### he became her son

"he became the adopted son of Pharaoh's daughter"

#### Because I drew him from the water

Translators may add a footnote that says "The name Moses sounds like the Hebrew word that means 'pull.'"

#### drew him

"pulled him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 02:11

#### striking

"hitting" or "beating"

#### He looked this way and that way

These two opposite directions have the combined meaning of "everywhere." AT: "He looked all around" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]

### Exodus 02:13

#### He went out

"Moses went out"

#### behold

The word "behold" here shows that Moses was surprised by what he saw. You can use a word in your language that will give this meaning.

#### the one who was in the wrong

This was a customary way of saying "the one who started the fight." AT: "the one who was guilty of starting the fight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Who made you a leader and judge over us?

The man used this question to rebuke Moses for intervening in the fight. AT: "You are not our leader and have no right to judge us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Are you planning to kill me as you killed that Egyptian?

The man used a question here to be sarcastic. AT: "We know that you killed an Egyptian yesterday. You had better not kill me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Exodus 02:15

#### Now when Pharaoh heard about it

The word "now" is used here to mark a break in the event. Here the author starts to tell a new part of the incident.

#### Now the priest of Midian had seven daughters

The word "now" is used here to mark a break in the event. Here the author tells about new people in the narrative.

#### drew water

This means that they brought up water from a well.

#### troughs

a long, narrow, open container for animals to eat or drink out of

#### drive them away

"chase them away"

#### helped them

"rescued them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]

### Exodus 02:18

#### Why did you leave the man?

This question is a mild rebuke to the daughters for not inviting Moses into their home according to the normal hospitality of that culture. AT: "You should not have left this man at the well!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]

### Exodus 02:21

#### Moses agreed to stay with the man

"Moses agreed to live with Reuel"

#### Zipporah

This is Reuel's daughter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Gershom

This is Moses's son. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### resident in a foreign land

"stranger in a foreign land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]

### Exodus 02:23

#### groaned

They did this because of their sorrow and misery. AT: "sighed deeply"

#### their pleas went up to God

The cries of the Israelites are spoken of as if they were a person and were able to travel up to where God is. AT: "God heard their pleas" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### God called to mind his covenant

This was a customary way of saying God thought about what He had promised. AT: "God remembered his covenant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]

### Exodus 02:intro

#### Exodus 02 General Notes ####

####### Special concepts in this chapter #######

######## Moses' heritage ########
In the first part of this chapter, Pharaoh's daughter recognizes Moses as being a Hebrew, but in the last part of this chapter, the Midianites believe him to be an Egyptian. 

####### Other possible translation difficulties in this chapter #######

######## Ironic situations ########
While Pharaoh tried to diminish the power of the Israelites by killing all of their baby boys, Yahweh used Pharaoh's own daughter to save Moses. Moses was the one who would ultimately be used by Yahweh to deliver Israel. 

##### Links: #####

* __[Exodus 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Exodus 03

### Exodus 03:01

#### angel of Yahweh

This was Yahweh himself appearing as an angel, and not just an angel that Yahweh sent. "Yahweh appeared as an angel" .

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### behold

The word "behold" here shows that Moses saw something that was very different from what he expected.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/horeb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/horeb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 03:04

#### set apart

"made holy"

#### the God of your father, the God of Abraham, the God of Isaac, and the God of Jacob

All of these men worshiped the same God. AT: "the God of your father, of Abraham, of Isaac, and of Jacob"

#### your father

Possible meanings are 1) "your ancestor" or 2) "your father." If it means "your ancestor," then the phrases following it clarify who "your father" refers to: it refers to Abraham, Isaac, and Jacob. If it means "your father," then it refers to Moses's own father.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]

### Exodus 03:07

#### taskmasters

Egyptians whose job was to force the Israelites to do hard work. See how you translated this in [Exodus 1:11](../01/11.md).

#### a land flowing with milk and honey

"a land where milk and honey flow." God spoke of the land being good for animals and plants as if the milk and honey from those animals and plants were flowing through the land. AT: "a land that is excellent for raising livestock and growing crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### flowing with

"full of" or "with an abundance of"

#### milk

Since milk comes from cows and goats, this represents food produced by livestock. AT: "food from livestock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### honey

Since honey is produced from flowers, this represents food from crops. AT: "food from crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]

### Exodus 03:09

#### the shouts of the people of Israel have come to me

Here the word "shouts" are spoken of as if they were persons who are capable of moving on their own. AT: "I have heard the cries of the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]

### Exodus 03:11

#### Who am I, that I should go to Pharaoh ... Egypt?

Moses uses this question to tell God that Moses is a nobody and no one will listen to him. AT: "I am not important enough to go to Pharaoh ... Egypt!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 03:13

#### God said to Moses, "I AM THAT I AM."

This is God's response to Moses' question about God's name. This can be made explicit. AT: "God said to Moses, 'Tell them that God says his name is, "I AM THAT I AM."'"

#### I AM THAT I AM

Possible meanings are 1) this whole sentence is God's name or 2) God is not telling his name but something about himself. By saying this, God is teaching that he is eternal; he has always lived and always will live.

#### I AM

Languages that do not have an equivalent to the verb "am" may need to render this as "I LIVE" or "I EXIST."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Exodus 03:16

#### General Information:

God continues speaking to Moses.

#### the God of your ancestors, the God of Abraham, of Isaac, and of Jacob

Abraham, Isaac and Jacob were three of Moses's ancestors. They all worshiped the same God.

#### I have indeed observed you

The word "you" refers to the people of Israel.

#### a land flowing with milk and honey

"a land where milk and honey flow." God spoke of the land being good for animals and plants as if the milk and honey from those animals and plants were flowing through the land. See how you translated this in [Exodus 3:8](./07.md). AT: "a land that is excellent for raising livestock and growing crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### flowing with

"full of" or "with an abundance of"

#### milk

Since milk comes from cows and goats, this represents food produced by livestock. AT: "food from livestock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### honey

Since honey is produced from flowers, this represents food from crops. AT: "food from crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They will listen to you

The word "you" refers to Moses. AT: "The elders will listen to you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 03:19

#### General Information:

God continues speaking to Moses.

#### unless his hand is forced

This can be stated in active form. The word "hand" is a metonym for the power of the owner of the hand. Possible meanings are 1) "only if he sees that he has no power to do anything else," where the "hand" belongs to Pharaoh; where the "hand" belongs to Yahweh, 2) "only if I force him to let you go" or 3) "not even if I force him to let you go." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I will reach out with my hand and attack

Here "hand" refers to God's power. AT: "I will powerfully attack" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will not go empty-handed

The word here "empty-handed" is used to emphasize the opposite meaning. AT: "will go with your hands full of good things" or "will go with many valuable things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### any women staying in her neighbors' houses

"any Egyptian woman staying in the houses of her Egyptian neighbors"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 03:intro

#### Exodus 03 General Notes ####

####### Structure and formatting #######

This chapter records one of the most important events in the history of the Israelite people: the revelation of the name Yahweh at the burning bush. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

####### Special concepts in this chapter #######

######## God's holiness ########
God is so holy that people could not look upon him without dying. This is why Moses covered his eyes. It is also why he took off his shoes. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Other possible translation difficulties in this chapter #######

######## Yahweh ########
The name Yahweh is sacred in the Hebrew religion. It is the personal name of God, which he revealed to Moses. It is by this name, he is known. Yahweh means "I am." Some translations use all capitals to set this apart, "I AM." Great care must be taken in translating the phrase "I am that I am." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]])

##### Links: #####

* __[Exodus 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Exodus 04

### Exodus 04:01

#### if they do not believe

"if the Israelites do not believe"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]

### Exodus 04:04

#### take it by the tail

"pick it up by the tail" or "grasp it by the tail"

#### became a staff

"turned into a rod" or "changed into a staff"

#### the God of their ancestors, the God of Abraham, the God of Isaac, and the God of Jacob

Abraham, Isaac and Jacob were three of their ancestors. They all worshiped the same God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]

### Exodus 04:06

#### behold

This word is used to create an exclamation, showing surprise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### as white as snow

The word "as" here is used to compare what Moses' hand looked like. Leprosy causes the skin to look white. You may not have a word for snow in your language. If so, consider an alternative that describes something white. AT: "as white as wool or as white as the sand on the beach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leprosy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leprosy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md)]]

### Exodus 04:08

#### pay attention

"acknowledge" or "accept"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Exodus 04:10

#### eloquent

"an excellent speaker"

#### I am slow of speech and slow of tongue

The phrases "slow of speech" and "slow of tongue" mean basically the same thing. Moses uses them to emphasize that he is not a good speaker. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### slow of tongue

Here "tongue" refers to Moses' ability to speak. AT: "unable to speak well" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Who is it who made man's mouth?

Yahweh uses this question to emphasize that he is the Creator who makes if possible for people to speak. AT: "I Yahweh am the one who created the human mouth and the ability to speak!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Who makes a man mute or deaf or seeing or blind?

Yahweh uses this question to emphasize that he is the one who decides if people can speak and hear, and if they can see. AT: "I Yahweh make people able to speak, or hear, or to see, or to be blind!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is it not I, Yahweh?

Yahweh uses this question to emphasize that he alone makes these decisions. AT: "I, Yahweh, am the one who does this!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I will be with your mouth

Here "mouth" refers to Moses' ability to speak. AT: "I will give you the ability to speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 04:14

#### he will be glad in his heart

Here "heart" refers to inner thoughts and emotions. AT: "he will be very happy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### put the words to say into his mouth

Words here are spoken of as if they were something that can be physically placed in a person's mouth. AT: "give him the message that he is to repeat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will be with your mouth

The word "mouth" here represents Moses choice of words. AT: "I will give you the right words to speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with his mouth

The word "mouth" here represents Aaron's choice of words. AT: "I will give him the right words to speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He will be your mouth

The word "mouth" here represents Aaron repeating what Moses told him. AT: "He will say what you tell him to say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you will be to him like me, God

The word "like" here means Moses would represent the same authority to Aaron as God did to Moses. AT: "you will speak to Aaron with the same authority with which I spoke to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]

### Exodus 04:18

#### father-in-law

This refers to the father of Moses' wife.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Exodus 04:21

#### will harden his heart

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. AT: "will cause Pharaoh to be stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Israel is my son

The word "Israel" here represents all the people of Israel. AT: "The people of Israel are my own children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### is my son, my firstborn

Here the people of Israel are spoken of as if they were a firstborn son who causes joy and pride. AT: "is like my own firstborn son" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you have refused to let him go

The word "him" refers to the people of Israel as God's son. AT: "you have refused to let my son go" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will certainly kill your son, your firstborn

The word "son" here refers to the actual son of Pharaoh.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 04:24

#### Yahweh met Moses and tried to kill him

This may have been because Moses had not circumcised his son.

#### Zipporah

This is the name of Moses's wife. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### flint knife

This was a knife with a sharpened stone blade.

#### to his feet

It is possible that the word "feet" here may have been a more respectful way to refer to the genital area of the body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### you are a bridegroom to me by blood

The meaning of this metaphor is unclear. It was probably a known saying in that culture. AT: "you are related to me by this blood" or "you are my husband because of blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Exodus 04:27

#### Yahweh said to Aaron

You may want to add a word that marks the beginning of a new part of the story, as the UDB does with the word "Meanwhile."

#### at the mountain of God

This may have been the mountain at Sinai, but the text does not include that information.

#### he had sent him to say

The word "he" refers to Yahweh, and "him" refers to Moses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 04:29

#### in the sight of the people

"before the people" or "in the presence of the people"

#### had observed the Israelites

"saw the Israelites" or "was concerned about the Israelites"

#### they bowed their heads

Possible meanings are 1) "they bowed their heads in awe" or 2) "they bowed down low in reverence." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 04:intro

#### Exodus 04 General Notes ####

####### Special concepts in this chapter #######

######## Moses does not understand ########
Although Moses believes in Yahweh, he does not trust in him. This is because Moses lacks understanding. Moses tries to believe the things he is asked to do are done by his own power. Yahweh is trying to get Moses to trust that these are Yahweh's doing. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]])

######## Children of God ########
This chapter really introduces the concept that the people group Israel is the chosen people of God and God's children, possibly God's firstborn children. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]])

####### Other possible translation difficulties in this chapter #######

######## Yahweh hardened Pharaoh's heart ########
Scholars are divided over how to understand this statement. There is debate over whether Pharaoh plays an active or passive role in the hardening of his own heart. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

##### Links: #####

* __[Exodus 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Exodus 05

### Exodus 05:01

#### After these things happened

It is unclear how long Moses and Aaron waited until they went to see Pharoah.

#### festival for me

This is a celebration to worship Yahweh.

#### Who is Yahweh?

Pharaoh uses this question to show that he does not recognize Yahweh as a legitimate god. AT: "I do not know Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Why should I ... let Israel go?

Pharaoh uses this question to state that he has no interest in obeying Yahweh or in letting the Israelites go to worship him. AT: "He is nothing to me and I will not let Israel go!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### listen to his voice

The words "his voice" represent the words God spoke. AT: "listen to what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Exodus 05:03

#### God of the Hebrews

This is a term also used for the Israelites' God or Yahweh.

#### or with the sword

Here "sword" represents war or an attack by enemies. AT: "or cause our enemies to attack us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### why are you taking the people from their work?

Pharaoh uses this question to express his anger towards Moses and Aaron for taking the Israelites away from their work. AT: "stop distracting the people from doing their work!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 05:06

#### taskmasters

Egyptians whose job was to force the Israelites to do hard work. See how you translated this in [Exodus 1:11](../01/11.md).

#### you must no longer give

The word "you" in these verses is plural and refers to the taskmasters and foremen. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Exodus 05:10

#### taskmasters

Egyptians whose job was to force the Israelites to do hard work. See how you translated this in [Exodus 1:11](../01/11.md).

#### I will no longer give you any straw ... get straw wherever you can find it

The word "you" in these verses is plural and refers to the Israelite people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### You yourselves must go

Here "yourselves" emphasizes that the Egyptians will no longer help them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### your workload will not be reduced

This can be stated in positive form. AT: "you must continue to make the same number of bricks as before"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]

### Exodus 05:12

#### throughout all the land of Egypt

This is an generalization used to show the extra effort Israel made to meet Pharaoh's demands. AT: "to many places throughout Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### stubble

the part of a plant that is left over after harvest

#### taskmasters

Egyptians whose job was to force the Israelites to do hard work. See how you translated this in [Exodus 1:11](../01/11.md).

#### Why have you not produced all the bricks required of you ... in the past?

The taskmasters used this question to show they were angry with the lack of bricks. AT: "You are not producing enough bricks, either yesterday or today, as you did in the past!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 05:15

#### cried out

"complained"

#### they are still telling us, 'Make bricks!'

Here "they" refers to the Egyptian taskmasters.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 05:19

#### when they were told

This can be stated in active form. AT: "when Pharaoh told them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### palace

This is a very large house that a king lives in.

#### you have made us offensive

The Egyptians responded to the Israelites the same way they would respond to a foul odor. AT: "you have caused them to hate us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### have put a sword in their hand to kill us

Here "a sword" represents an opportunity to destroy enemies. AT: "have given them a reason to kill us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 05:22

#### Lord, why have you caused trouble for this people?

This question shows how disappointed he was that the Egyptians were treating the Israelites even more harshly now. AT: "Lord, I am sorry that you have caused this trouble for this people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Why did you send me in the first place?

This question shows how disappointed Moses was that God had sent him to Egypt. AT: "I wish you had never sent me here!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to speak to him in your name

The word "name" here represents the message of God. AT: "to give him your message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]

### Exodus 05:intro

#### Exodus 05 General Notes ####

####### Special concepts in this chapter #######

######## A slave's work ########
The Egyptians were known for making their slaves do a lot of work. They were forced to make a specific number of bricks every day. In this chapter, the were required to not only make these bricks, but also to gather the straw in order to make these bricks. 

####### Other possible translation difficulties in this chapter #######

######## "Let my people go" ########
This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people. 

######## Titles ########
The leaders are given different titles in this chapter. The ULB uses "taskmasters" and "foremen." Many cultures will not have these types of titles. Generic expressions like "Egyptian leaders" and "Hebrew leaders" may be necessary.

##### Links: #####

* __[Exodus 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Exodus 06

### Exodus 06:01

#### my strong hand

The word "hand" here represents God's actions or works. AT: "the power I show in my works" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Exodus 06:02

#### I appeared to Abraham, to Isaac, and to Jacob

"I showed myself to Abraham, to Isaac, and to Jacob"

#### I was not known to them

This can be stated in active form. AT: "They did not know me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### groaning

This means making sad sounds because of pain and suffering.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/enslave.md)]]

### Exodus 06:06

#### say to the Israelites

This is a command from Yahweh to Moses. "Yahweh told Moses to say to the Israelites"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Exodus 06:08

#### I swore

"I promised" or "I said I would"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Exodus 06:10

#### If the Israelites have not listened to me, why will Pharaoh listen to me, since I am not good at speaking?

Moses asked this question hoping God would change His mind about using Moses. This rhetorical question can be translated as a statement. AT: "Since the Israelites did not listen to me, neither will Pharaoh, because I am not good at speaking!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 06:14

#### the heads of their fathers' houses

Here "heads" refers to the original ancestors of the clan. AT: "the ancestors of the clans"

#### Hanok ... Shaul

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Exodus 06:16

#### Gershon ... Merari

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 137 years old

"one hundred and thirty-seven years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Amram ... Uzziel

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 133 years old

"one hundred and thirty-three years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Exodus 06:20

#### 137 years

"one hundred and thirty-seven years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Izhar ... Korah ... Zichri

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Uzziel ... Mishael ... Sithri

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Exodus 06:23

#### Nadab ... Ithamar

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Phinehas

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### These were the heads of the fathers' houses

The word "heads" here represents family leaders. AT: "These were the leaders of the families" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

### Exodus 06:26

#### by their groups of fighting men

"one tribe at a time" or "one family group after another"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 06:28

#### I am not good ... why will Pharaoh listen to me?

Moses asks this question hoping to change God's mind. This rhetorical question can be translated as as statement. AT: "I am not good ... Pharaoh will certainly not listen to me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 06:intro

#### Exodus 06 General Notes ####

####### Special concepts in this chapter #######

######## Promised Land ########
According to the covenant Yahweh made with Abraham, Egypt is not the home of the Hebrew people. It is the Promised Land in Canaan. The people are to return home to their land. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

####### Other possible translation difficulties in this chapter #######

######## Let my people go ########

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people.

##### Links: #####

* __[Exodus 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Exodus 07

### Exodus 07:01

#### I have made you like a god

"I will cause Pharaoh to consider you as a god"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 07:03

#### harden Pharaoh's heart

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated this in [Exodus 4:21](../04/21.md). AT: "will cause Pharaoh to be stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### many signs ... many wonders

The words "signs" and "wonders" mean basically the same thing. God uses them to emphasize the greatness of what he will do in Egypt. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### put my hand on ... reach out with my hand on

The words "my hand" represent God's great power. AT: "use my power against ... show my powerful acts against" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 07:06

#### Aaron eighty-three years old

"Aaron was eighty-three years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 07:08

#### When Pharaoh says to you, 'Do a miracle,' then you will say to Aaron, 'Take your staff and throw it down before Pharaoh, so that it may become a snake.'

This could be stated as an indirect quote. AT: "When Pharaoh tells you to do a miracle, then you will tell Aaron to take his staff and throw it down before Pharaoh, so that it may become a snake" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 07:11

#### swallowed up

"ate up" or "devoured"

#### Pharaoh's heart was hardened

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. AT: "Pharaoh became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 07:14

#### Pharaoh's heart is hard

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated this in [Exodus 7:13](./11.md). AT: "Pharaoh is stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### when he goes out to the water

The full meaning of this statement can be made explicit. AT: "when he goes down to the Nile River to bathe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Exodus 07:16

#### Say to him

"Say to Pharaoh"

#### strike the water

"hit the water"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nileriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 07:19

#### throughout all

"in every part of"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 07:20

#### Pharaoh's heart was hardened

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated this in [Exodus 7:13](./11.md). AT: "Pharaoh became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the river

The name of the river may be made explicit. AT: "in the Nile River" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]

### Exodus 07:23

#### All the Egyptians

The word "all" here is a generalization that means "many." AT: "Many of the Egyptians" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 07:intro

#### Exodus 07 General Notes ####

####### Special concepts in this chapter #######

######## Miracles ########
When Yahweh had Moses perform miracles, Pharaoh's men were able to copy these miracles. It is unknown how they were able to do this, but since it was not from Yahweh, they were probably done under some evil power. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

######## Pharaoh's hard heart ########
Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

####### Other possible translation difficulties in this chapter #######

######## Let my people go ########

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people.

##### Links: #####

* __[Exodus 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Exodus 08

### Exodus 08:01

#### The river

"the Nile River" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### kneading bowls

These are bowls in which bread is made.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 08:05

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]

### Exodus 08:08

#### Then Pharaoh called for Moses and Aaron

"Then Pharaoh sent for Moses and Aaron"

#### You can have the privilege of telling me when I should pray for you

"You can choose when I will pray for you" or "You can choose the time I should pray for you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 08:10

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Exodus 08:13

#### he hardened his heart

"Pharaoh hardened his heart." Here "hardened" means that he became stubborn. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### just as Yahweh had said that he would do

"just as Yahweh had said Pharaoh would do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Exodus 08:16

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Exodus 08:18

#### This is the finger of God

The words "finger of God" represent the power of God. AT: "This is the powerful work of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Pharaoh's heart was hardened

Here "heart" refers to Pharaoh. See how you translated this in [Exodus 7:13](../07/11.md). AT: "Pharaoh became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]

### Exodus 08:20

#### stand in front of Pharaoh

"present yourself to Pharaoh"

#### Let my people go

"set my people free"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 08:22

#### General Information:

Yahweh continues to speak to Pharaoh through Moses.

#### the land was ruined because of the swarms of flies

This can be translated in active form. AT: "the swarms of flies devastated the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]

### Exodus 08:25

#### right before their eyes

This was a customary way of saying "in the presence of someone." AT: "in their presence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will they not stone us?

Moses asks this question to show Pharaoh the Egyptians would allow the Israelites to worship Yahweh. AT: "they will certainly stone us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Exodus 08:28

#### you must not deal deceitfully any more by not letting our people go

This can be stated in positive form. AT: "you must begin to deal truthfully with us and let our people go" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### But you must not deal deceitfully

"But you must not deceive us" or "But you must not lie to us"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Exodus 08:30

#### Pharaoh hardened his heart

Here "heart" refers to Pharaoh. See how you translated this in [Exodus 7:13](../07/11.md). AT: "Pharaoh became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Exodus 08:intro

#### Exodus 08 General Notes ####

####### Special concepts in this chapter #######

######## Pharaoh's hard heart ########
Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

####### Other possible translation difficulties in this chapter #######

######## Let my people go ########

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people.

##### Links: #####

* __[Exodus 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Exodus 09

### Exodus 09:01

#### General Information:

Yahweh continues talking with Moses about dealing with Pharaoh and bringing the Hebrew people out of Egypt.

#### if you refuse to let them go, if you still keep them back

These two phrases mean basically the same thing. They will emphasize to Pharaoh what will happen if Pharaoh does this. AT: "if you continue refusing to let them go" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### then Yahweh's hand will be on your cattle

The word "hand" here represents Yahweh's power to afflict their animals with disease. AT: "then the power of Yahweh will afflict your cattle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### on your cattle

The word "your" here refers to all the people of Egypt who owned cattle.

#### Israel's cattle

Here "Israel" refers to the people of Israel. AT: "the cattle belonging to the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Egypt's cattle

Here "Egypt" refers to the people of Egypt. AT: "the cattle belonging to the people of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Exodus 09:05

#### fixed a time

"set a time" or "appointed a time"

#### All the cattle of Egypt died

This is exaggerated to emphasize the seriousness of the event. There were still some animals alive that were afflicted by later plagues. However, it may be best to translate this with the word "All." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### cattle of Egypt

Here "Egypt" refers to the people of Egypt. AT: "the cattle belonging to the people of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Pharaoh investigated

Pharaoh collected facts about the situation.

#### behold

The word "behold" here shows that Pharaoh was surprised by what he saw.

#### his heart was stubborn

Here "heart" refers to Pharaoh. AT: "he refused to change his mind" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 09:08

#### kiln

a furnace

#### fine

"very small"

#### to break out on

"to quickly appear on"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Exodus 09:11

#### Yahweh hardened Pharaoh's heart

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated a similar phrase in [Exodus 7:13](../07/11.md). AT: "Yahweh caused Pharaoh to became more defiant"(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/magic.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Exodus 09:13

#### on you yourself

This means that even Pharaoh will be hurt by the plagues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### I will do this so that you may know

The word "this" refers to the plagues that Moses had just told Pharaoh about.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Exodus 09:15

#### reached out with my hand and attacked you

Here "my hand" refers to God's power. AT: "used my power to strike you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that my name may be proclaimed throughout all the earth

Here "my name" represents Yahweh's reputation. AT: "so that people everywhere will know I am great" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### lifting yourself up against my people

Pharaoh's opposition to letting Israel go to worship Yahweh is spoken of as if he was raising himself up as a barrier to them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Exodus 09:18

#### Listen!

"Pay attention to the important thing I am about to tell you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Exodus 09:20

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 09:22

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Exodus 09:25

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/goshen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 09:27

#### summon

"call"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]

### Exodus 09:29

#### Moses said to him

"Moses said to Pharaoh"

#### spread my hands out to Yahweh

This symbolic gesture accompanies prayer. AT: "lift up my hands and pray to Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### honor Yahweh God

Honoring God involves obeying him and living in a way that shows how great he is.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 09:31

#### flax

This is a plant that produces fibers that can be made into linen cloth.

#### barley

This is a type of grain used for making bread; also used for cattle feed.

#### spelt

This is a kind of wheat.

#### spread out his hands to Yahweh

This symbolic gesture accompanies prayer. See how you translated a similar phrase in [Exodus 9:29](./29.md). AT: "lifted up his hands toward Yahweh and prayed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 09:34

#### hardened his heart

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. AT: "became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Pharaoh's heart was hardened

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated this in [Exodus 7:13](../07/11.md). AT: "Pharaoh became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 09:intro

#### Exodus 09 General Notes ####

####### Special concepts in this chapter #######

######## Pharaoh's hard heart ########

Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

####### Other possible translation difficulties in this chapter #######

######## Let my people go ########

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people.

##### Links: #####

* __[Exodus 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Exodus 10

### Exodus 10:01

#### for I have hardened his heart and the hearts of his servants

Yahweh speaks of making Pharaoh and his servants stubborn as if he were making their hearts hard. See how you translated "Yahweh hardened Pharaoh's heart" in [Exodus 9:12](../09/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### various

"many different"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Exodus 10:03

#### listen

This word adds emphasis to what is said next. AT: "Pay attention to what I am about to tell you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-imperative.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/humble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md)]]

### Exodus 10:05

#### hail

Hail is raindrops that freeze while falling from the clouds.

#### nothing ever seen

This can be stated in active form. AT: "nothing anyone has ever seen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 10:07

#### menace

A "menace" is someone who brings trouble or harm.

#### How long will this man be a menace to us?

Pharaoh's servants ask this question to show Pharaoh the extent of destruction in Egypt. This rhetorical question can be translated as a statement. AT: "We cannot allow this man to continue to bring trouble to us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Do you not yet realize that Egypt is destroyed?

Pharaoh's servants ask this question to bring Pharaoh to recognize what he refuses to see. This rhetorical question can be translated as a statement. AT: "You should realize that Egypt is destroyed!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### that Egypt is destroyed

This can be stated in active form. AT: "that these plagues have destroyed Egypt" or "that their God has destroyed Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 10:09

#### if I ever let you go and your little ones go

Pharaoh says this to emphasize that he would not let Moses take the children with them to worship Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### Then Moses and Aaron were driven out from Pharaoh's presence

This can be stated in active form. AT: "Then Pharaoh drove Moses and Aaron out from his presence" or "Then Pharaoh had his servants drive Moses and Aaron out from his presence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Exodus 10:12

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]

### Exodus 10:14

#### so that it was darkened

There were so many locusts that the land appeared to be dark. This can be stated in active form. AT: "so that they darkened the land" or "so that the land appeared dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md)]]

### Exodus 10:16

#### this time

"once again"

#### take this death away from me

The word "death" here refers to the destruction by the locusts of all plants in Egypt, which would eventually lead to the deaths of people because there were no crops. The full meaning of this statement can be made explicit. AT: "stop this destruction that will lead to our deaths" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Exodus 10:19

#### picked up the locusts

"moved the locusts upwards"

#### Yahweh hardened Pharaoh's heart

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated this phrase in [Exodus 9:12](../09/11.md). AT: "caused Pharaoh to became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Exodus 10:21

#### darkness that may be felt

Yahweh speaks of extreme darkness as if it is so thick that people can grasp it in their hands. This can be stated in active form. AT: "dense darkness that people can grasp with their hands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 10:24

#### not a hoof of them may be left behind

Here the word "hoof" refers to the entire animal. This can be stated in active form. AT: "we cannot leave behind a single animal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]

### Exodus 10:27

#### Yahweh hardened Pharaoh's heart

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated this phrase in [Exodus 9:12](../09/11.md). AT: "caused Pharaoh to became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he would not let them go

"Pharaoh would not let them go"

#### Be careful about one thing

"Make sure of one thing" or "Be certain of one thing"

#### you see my face

Here the word "face" refers to the whole person. AT: "you see me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### You yourself have spoken

With these words, Moses emphasizes that Pharaoh has spoken the truth. AT: "What you have said is true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Exodus 10:intro

#### Exodus 10 General Notes ####

####### Special concepts in this chapter #######

######## Pharaoh's hard heart ########

Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

####### Other possible translation difficulties in this chapter #######

######## Let my people go ########

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people.

##### Links: #####

* __[Exodus 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Exodus 11

### Exodus 11:01

#### he will let you go from here

Each occurrence of the word "you" in this verse is plural and refers to Moses and the rest of the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 11:04

#### midnight

This is the time of 12 am (at night) or 2400 hours.

#### All the firstborn ... the firstborn of Pharaoh ... the firstborn of the slave girl ... the firstborn of the cattle

The "firstborn" always refers to the oldest male offspring.

#### who sits on his throne

This phrase refers to Pharaoh.

#### who is behind the handmill grinding it

"who is grinding at the handmill" or "who is behind the handmill grinding grain"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 11:06

#### After that I will go out

This means that Moses and the people of Israel will leave Egypt. AT: "After that I will leave here" or "After that I will go out from Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Exodus 11:09

#### Yahweh hardened Pharaoh's heart

Here "heart" refers to Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated this phrase in [Exodus 9:12](../09/11.md). AT: "Yahweh caused Pharaoh to became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Exodus 11:intro

#### Exodus 11 General Notes ####

####### Special concepts in this chapter #######

######## Pharaoh's hard heart ########

Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

####### Other possible translation difficulties in this chapter #######

######## Let my people go ########

In the previous chapters, Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he demanded that Pharaoh free the Hebrew people. In this chapter, the same wording is used to refer to Pharaoh "allowing" the Hebrew people to leave Egypt.

##### Links: #####

* __[Exodus 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Exodus 12

### Exodus 12:01

#### For you, this month will be the start of months, the first month of the year to you

These two phrases mean basically the same thing and emphasize that the month in which the events of this chapter take place will be the beginning of their calendar year. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the first month of the year

The first month of the Hebrew calendar includes the last part of March and the first part of April on Western calendars. It marks when Yahweh rescued the Israelites from the Egyptians. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Exodus 12:03

#### If the household is too small for a lamb

This means that there are not enough people in the family to eat an entire lamb. AT: "If there are not enough people in the household to eat an entire lamb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the man and his next door neighbor

Here "the man" refers to the man who is the leader of the household.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Exodus 12:05

#### twilight

This refers to the time of evening after the sun has set but while there is still some light.

#### on the two side doorposts and on the tops of the doorframes of the houses

"on the sides and top of the way into the house"

#### Eat it with bread made without yeast

This can be stated in active form. AT: "Eat it with bread which you have made without yeast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### bitter herbs

These are small plants that have a strong and usually bad taste.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blemish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blemish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doorpost.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doorpost.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]

### Exodus 12:09

#### Do not eat it raw

"Do not eat the lamb or goat uncooked"

#### You must not let any of it be left over until morning

This can be stated in active form. AT: "Do not leave any of it until the morning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### belt

This refers to a strip of leather or fabric for tying around the waist.

#### eat it hurriedly

"eat it quickly"

#### It is Yahweh's Passover

Here the word "it" refers to eating the animal on the tenth day of the month. AT: "This observance is Yahweh's Passover" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]

### Exodus 12:12

#### I will bring punishment on all the gods of Egypt

This can be stated with a verbal form. AT: "I will punish all the gods of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### for my coming to you

This implies that Yahweh will see the blood which indicates an Israelite home. AT: "that I will see when I come to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will pass over you

The words "pass over" were a customary way of saying to not visit or enter. AT: "I will not enter your house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### for you, throughout your people's generations

"for you and all the generations of your descendants"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/memorialoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Exodus 12:15

#### that person must be cut off from Israel

The metaphor "cut off" has at least three possible meanings. They can be expressed in active form: 1) "the people of Israel must send him away" or 2) "I will no longer consider him to be one of the people of Israel" or 3) "the people of Israel must kill him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### an assembly that is set apart to me

This can be stated in active form. AT: "an assembly that you have set apart to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### No work will be done on these days

This can be stated in active form. AT: "You will do no work on these days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### That must be the only work that may be done by you

This can be stated in active form. AT: "That must be the only work that you do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 12:17

#### armed group by armed group

The term used for these groups is a military term referring to a large number of soldiers. AT: "division by division" or "regiment by regiment"

#### twilight

This refers to the time of evening after the sun has set but while there is still some light. See how you translated this in [Exodus 12:6](./05.md).

#### the fourteenth day in the first month

This is the first month of the Hebrew calendar. The fourteenth day is near the beginning of April on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the twenty-first day of the month

"the twenty-first day of the first month." This is near the middle of April on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Exodus 12:19

#### no yeast must be found in your houses

This can be stated in active form. AT: "there must not be any yeast in your houses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### must be cut off from the community of Israel

The metaphor "cut off" has at least three possible meanings. They can be expressed in active form: 1) "the people of Israel must send him away" or 2) "I will no longer consider him to be one of the people of Israel" or 3) "the people of Israel must kill him." See how you translated "must be cut off from Israel" in [Exodus 12:15](./15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]]and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### bread made without yeast

This can be stated in active form. See how you translated this in [Exodus 12:08](./05.md). AT: "bread which you have made without yeast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Exodus 12:21

#### summoned

"officially called"

#### hyssop

This is a plant in the mint family, which is woody and used for thin twigs.

#### the top of the doorframe and the two doorposts

"on the sides and top of the way into the house." See how you translated a similar phrase in [Exodus 12:7](./05.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doorpost.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doorpost.md)]]

### Exodus 12:23

#### pass over your door

Here the word "door" implies the entire house. This means that God will spare the Israelites in houses with blood on the doors. AT: "pass over your house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destroyer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destroyer.md)]]

### Exodus 12:24

#### this event ... this act of worship

These phrases refer to the Passover or Festival of Unleavened Bread. Observing the Passover was an act of worshiping Yahweh.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 12:26

#### He set our households free

This means that Yahweh spared the Israelites' firstborn sons. AT: "He did not kill the firstborn sons in our houses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### as Yahweh had commanded Moses and Aaron

"everything that Yahweh told Moses and Aaron to do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Exodus 12:29

#### at midnight

"in the middle of the night"

#### all the firstborn in the land of Egypt ... all the firstborn of cattle

Here, "firstborn" always refers to the oldest male offspring. See how you translated a similar phrase in [Exodus 11:5](../11/04.md).

#### who sat on his throne

This refers to Pharaoh.

#### the firstborn of the person in prison

"to the firstborn of people in prison." This refers to prisoners, in general, and not to a specific person in prison.

#### There was loud lamenting in Egypt

This can be stated with a verbal form. AT: "All the Egyptians cried loudly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### for there was not a house where there was not someone dead

This double negative emphasizes the positive. AT: "because someone was dead in every house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lament.md)]]

### Exodus 12:31

#### We will all die

The Egyptians were afraid that they would die if the Israelites did not leave Egypt. AT: "We will all die if you do not leave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Exodus 12:34

#### Their kneading bowls were already tied up in their clothes and on their shoulders

This can be stated in active form. AT: "They had already tied up their kneading bowls in their clothes and on their shoulders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 12:37

#### Rameses

Rameses was a major Egyptian city where grain was stored. See how you translated this in [Exodus 1:11](../01/11.md).

#### They numbered about 600,000 men

"They numbered about six hundred thousand men." The total number of men was about 600,000. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### bread without yeast in the dough

"bread with dough that did not contain yeast"

#### they had been driven out of Egypt

This can be stated in active form. AT: "the Egyptians had driven them out of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### 430 years

"four hundred and thirty years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Exodus 12:41

#### 430 years

"four hundred and thirty years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Yahweh's armed groups

This refers to the tribes of Israel. See how you translated "armed group" in [Exodus 12:17](./17.md).

#### to be observed by all the Israelites

This can be stated in active form. AT: "that all the Israelites were to observe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### all the Israelites throughout their people's generations

"all the Israelites and the all the generations of their descendants"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Exodus 12:43

#### No foreigner may share in eating it

The pronoun "it" refers to the Passover meal.

#### every Israelite's slave

"any slave of an Israelite"

#### bought with money

This can be stated in active form. AT: "whom the Israelite has bought with money" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Exodus 12:45

#### The food must be eaten in one house

This can be stated in active form. AT: "Each Israelite family must eat the food in one house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### you must not break any bone of it

"you must not break any of its bones." Here the word "it" refers to the lamb which the Israelite family will eat.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 12:47

#### all his male relatives must be circumcised

This can be stated in active form. AT: "someone must circumcise all his male relatives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the people who were born in the land

Here the word "land" refers to Canaan. The expression "born in the land" means a person who is a native Israelite. AT: "those who are Israelites by birth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### no uncircumcised person may eat

This can be stated in positive terms. AT: "only circumcised people may eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Exodus 12:49

#### as Yahweh had commanded Moses and Aaron

"everything that Yahweh told Moses and Aaron to do"

#### It came about

This phrase is used here to mark an important event in the story. If your language has a way for doing this, you could consider using it here.

#### by their armed groups

The term used for these groups is a military term referring to a large number of soldiers. See how you translated "armed group" in [Exodus 12:17](./17.md). AT: "by their divisions" or "by their regiments"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Exodus 12:intro

#### Exodus 12 General Notes ####

####### Structure and formatting #######

The events of this chapter are known as the Passover. They are remembered in the celebration of Passover. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]])

####### Special concepts in this chapter #######

######## Unleavened bread ########
The concept of unleavened bread is introduced in this chapter. Its significance stems from its connection to the events in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]])

######## Ethnic segregation ########
The Hebrew people were to be separate from the rest of the world. Because of this, they separated themselves from other people groups. At this time, these foreigners were looked upon as unholy. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unholy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unholy.md)]])

##### Links: #####

* __[Exodus 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Exodus 13

### Exodus 13:01

#### Set apart to me ... every firstborn male

God requires that every firstborn male child be set apart for him.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 13:03

#### Call this day to mind

The words "Call ... to mind" were a customary way of telling someone to remember something. AT: "Remember and celebrate this day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the house of slavery

Moses speaks of Egypt as if it were a house where people keep slaves. AT: "the place where you were slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh's strong hand

Here the word "hand" refers to power. See how you translated "strong hand" in [Exodus 6:1](../06/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### No bread with yeast may be eaten

This can be stated in active form. AT: "You must not eat bread with yeast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the month of Aviv

This is the name of the first month of the Hebrew calendar. Aviv is during the last part of March and the first part of April on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### a land flowing with milk and honey

Since milk comes from cows and goats, "milk" represents food produced by livestock. Because honey is produced from flowers, "honey" represents food from crops. See how you translated this in [Exodus 3:8](../03/07.md). AT: "food from livestock and from crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you must observe this act of worship

When the Israelites live in Canaan, they must celebrate the Passover on this day each year. See how you translated this phrase in [Exodus 12:25](../12/24.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 13:06

#### General Information:

Moses continues to speak to the people of Israel.

#### For seven days

"For 7 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Bread without yeast must be eaten

This can be stated in active form. AT: "You must eat bread without yeast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### no bread with yeast may be seen among you

This can be stated in active form. AT: "You may not have any bread with yeast among you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### No yeast may be seen with you

This can be stated in active form. AT: "You may not have any yeast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### within any of your borders

"inside any of the borders of your land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Exodus 13:08

#### On that day you are to say to your children, 'This is because of what Yahweh did for me when I came out of Egypt.'

The quotation can be stated as an indirect quote. AT: "On that day you are to tell your children that this is because of what Yahweh did for you when you came out of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### This will be a reminder for you on your hand, and a reminder on your forehead

These are two different types of physical reminders so people will not forget something important. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### a reminder for you on your hand

Moses speaks of celebrating the festival as if it were tying an object around their hands to remind them of what Yahweh had done. AT: "like something you tie around your hand as a reminder" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a reminder on your forehead

Moses speaks of celebrating the festival as if it were tying an object around their foreheads to remind them of what Yahweh had done. AT: "like something you tie around your head as a reminder" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so the law of Yahweh may be in your mouth

The words "in your mouth" here refers to the words that they speak. AT: "so you may always be speaking of the law of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### strong hand

The word "hand" here represents God's actions or works. See how you translated this in [Exodus 6:1](../06/01.md). AT: "the power I show in my works" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]

### Exodus 13:11

#### when he gives the land to you

"when he gives the land of the Canaanites to you"

#### Every firstborn of a donkey

Israel is given a choice to kill the firstborn donkey or buy it back with a lamb.

#### each of your firstborn males among all your sons

Everyone in Israel who had a firstborn son, must buy him back.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/offspring.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/offspring.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Exodus 13:14

#### When your son asks you later, 'What does this mean?' then you are to tell him

The first quotation can be stated as an indirect quotation. AT: "When your son asks you later what this means, then you are to tell him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### strong hand

The word "hand" here represents God's actions or works. See how you translated this in [Exodus 6:1](../06/01.md). AT: "the power I show in my works" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the house of slavery

Moses speaks of Egypt as if it were a house where people keep slaves. See how you translated this in [Exodus 13:3](./03.md). AT: "the place where you were slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### become a reminder on your hands, and a reminder on your forehead

This expresses two ways to remember the importance of the passover event. See how you translated a similar phrase in [Exodus 13:8-10](./08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 13:17

#### nearby

"close to where they were located"

#### the people will change their minds ... and ... return to Egypt

Since Israelites had lived in slavery all their lives, they were more accustomed to peace than to war and would rather return to slavery than fight.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]

### Exodus 13:19

#### camped at Etham

Etham is located south of the route heading towards the Philistines, at the border of the wilderness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### pillar of cloud ... pillar of fire

"a cloud in the shape of a column ... fire in the shape of a column." God is with them in a cloud by day and in a fire by night.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]

### Exodus 13:intro

#### Exodus 13 General Notes ####

####### Structure and formatting #######

This chapter records the instructions for the celebration of Passover. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]])

####### Special concepts in this chapter #######

######## Law ########
The law mentioned here is not the law of Moses because it has not yet been revealed. Instead, it is a more generic "rule." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

####### Other possible translation difficulties in this chapter #######

######## Let my people go ########

This is a very important statement. Moses does not ask Pharaoh for permission to "let go" of the Hebrew people. Instead, he is demanding that Pharaoh free the Hebrew people. When this chapter states that Pharaoh let the people go, it indicates that he gave them permission to leave.

##### Links: #####

* __[Exodus 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Exodus 14

### Exodus 14:01

#### Pi Hahiroth ... Migdol ... Baal Zephon

These are towns on Egypt's eastern border. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### You are to camp

Here the word "You" is plural and refers to Moses and the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Pharaoh will say about the Israelites, 'They are wandering in the land. The wilderness has closed in on them.'

This can be stated as an indirect quote. AT: "Pharaoh will say the Israelites are wandering in the land and the wilderness has closed in on them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### The wilderness has closed in on them

Pharaoh speaks of the wilderness as a person who has trapped the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Exodus 14:04

#### General Information:

Yahweh continues to instruct Moses on where to go and what Yahweh will do.

#### I will harden Pharaoh's heart

Here "heart" refers to the Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated a similar phrase in [Exodus 9:12](../09/11.md). AT: "I will cause Pharaoh to became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will pursue them

"Pharaoh will pursue the Israelites"

#### I will get honor

"People will honor me"

#### The Egyptians will know that I am Yahweh

"The Egyptians will understand that I am Yahweh, the one true God"

#### So the Israelites camped as they were instructed

This can be stated in active form. AT: "So the Israelites camped as Yahweh had instructed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### When the king of Egypt was told

This can be stated in active form. AT: "When someone told the king of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the king of Egypt

This refers to Pharaoh.

#### had fled

"had run away"

#### the minds of Pharaoh and his servants turned against the people

Here the word "minds" refers to their attitudes towards the Israelites. AT: "Pharaoh and his servants changed their attitudes about the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### What have we done? We have released Israel from serving us.

They asked this question to show they thought they had done a foolish thing. This rhetorical question can be translated as a statement. AT: "We have done a stupid thing by letting Israel go free from working for us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/instruct.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Exodus 14:06

#### He took six hundred chosen chariots

"He took 600 of his best chariots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Yahweh hardened the heart of Pharaoh

Here "heart" refers to the Pharaoh. His stubborn attitude is spoken of as if his heart was hard. See how you translated a similar phrase in [Exodus 9:12](../09/11.md). AT: "Yahweh caused Pharaoh to became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Pi Hahiroth ... Baal Zephon

These are towns on Egypt's eastern border. See how you translated them in [Exodus 14:02](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]

### Exodus 14:10

#### When Pharaoh came close

The word "Pharaoh" here represents the entire Egyptian army. AT: "When Pharaoh and his army came close" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they were terrified

"the Israelites were terrified"

#### Is it because there were no graves in Egypt, that you have taken us away to die in the wilderness?

The Israelites ask this question to express their frustration and fear of dying. This rhetorical question can be translated as a statement. AT: "There were plenty of graveyards in Egypt for us to be buried in. You did not have to take us into the wilderness to die!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Why have you treated us like this, bringing us out of Egypt?

The Israelites ask this question to rebuke Moses for bringing them to the desert to die. This rhetorical question can be translated as a statement. AT: "You should not have treated us like this by bringing us out of Egypt!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is this not what we told you in Egypt?

The Israelites ask this question to emphasize that this is what they had told Moses. This rhetorical question can be translated as a statement. AT: "This is exactly what we told you while we were in Egypt." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### We said to you, 'Leave us alone, so we can work for the Egyptians.'

This can be stated as an indirect quote. AT: "We told you to leave us alone, so we could work for the Egyptians." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Exodus 14:13

#### Moses said to the people

Moses responds to the Israelites' fears.

#### provide for you

The pronoun "you" refers to the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### For you will never see again the Egyptians

Moses used a polite way of saying God was going to destroy the Egyptian army. AT: "For God will kill the Egyptians" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Exodus 14:15

#### Why are you, Moses, continuing to call out to me?

Moses apparently had been praying to God for help so God uses this question to compel Moses to act. This rhetorical question can be translated as a statement. AT: "Do not call out to me any longer, Moses." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### divide it in two

"divide the sea into two parts"

#### Be aware

"Know"

#### I will harden the Egyptians' hearts

Here "hearts" refers to the Egyptians themselves. Their stubborn attitude is spoken of as if their hearts were hard. See how you translated a similar phrase in [Exodus 9:12](../09/11.md). AT: "I will cause the Egyptians to became more defiant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so they will go after them

"so that the Egyptians will go into the sea after the Israelites"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]

### Exodus 14:19

#### the camp of Egypt and the camp of Israel

"the Egyptian army and the Israelite people"

#### so one side did not come near the other

This means that the Egyptians and the Israelites could not approach one another.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]

### Exodus 14:21

#### east wind

An east wind originates in the east and blows towards the west.

#### east

where the sun rises

#### the waters were divided

This can be stated in active form. AT: "Yahweh divided the waters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on their right hand and on their left

"on each side of them" or "on both sides of them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Exodus 14:23

#### He caused panic among the Egyptians

Panic is when someone becomes so afraid that they cannot think normally.

#### Their chariot wheels were clogged

This can be stated in active form. AT: "Mud clogged their chariot wheels" or "Their chariot wheels were getting stuck in the mud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]

### Exodus 14:26

#### Yahweh said to Moses, "Reach out with your hand ... and their horsemen."

This can be stated as an indirect quote. AT: "Yahweh told Moses to reach out with his hand over the sea so that the waters would come back onto the Egyptians, their chariots, and their horsemen."

#### come back onto

"fall on"

#### The Egyptians fled into the sea

Since the sea was closing in on top of the Egyptians, instead of escaping, they were actually running right into the water.

#### Yahweh drove the Egyptians

"Yahweh pushed the Egyptians" or "Yahweh threw the Egyptians"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 14:29

#### Israel

Each of the occurrences of "Israel" refer to the people of Israel. AT: "the people of Israel" or "the Israelites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### out of the hand of the Egyptians

Here the word "hand" refers to power. AT: "from the Egyptians' power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### on the seashore

"on the land along the edge of the sea"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 14:intro

#### Exodus 14 General Notes ####

####### Structure and formatting #######

This is an important event in the history of Israel, known as the "parting of the Sea of Reeds."

####### Special concepts in this chapter #######

######## Pharaoh's hard heart ########

Pharaoh's heart is often described as hard in this chapter. This means that his heart was not open or willing to understand Yahweh's instructions. When his heart was hardened, it became less and less receptive to Yahweh.

######## Pharaoh's chariots ########
These chariots were a fighting force. Pharaoh took an army to kill the Hebrew people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
The Israelites asked a few rhetorical questions of Moses. These questions were not really directed at Moses, but at Yahweh. This showed their lack of faith in Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

##### Links: #####

* __[Exodus 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## Exodus 15

### Exodus 15:01

#### General Information:

This is a song about the events that happened in [Exodus 14:26-28](../14/26.md).

#### he has triumphed gloriously

It can be stated explicitly over whom Yahweh triumphed. AT: "he has achieved a glorious victory over the army of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the horse and its rider he has thrown into the sea

Moses sang about God causing the sea to cover and drown the horse and rider as if God had thrown them into the sea. AT: "he has made the sea cover over the horse and rider" or "he has made the horse and rider drown in the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the horse and its rider

This refers to all or many of the Egyptian horses and riders that were chasing the Israelites. AT: "the horses and their riders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### rider

This is a person who sits on a horse or travels in a chariot that a horse is pulling.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Exodus 15:02

#### Yahweh is my strength

Possible meanings are 1) "Yahweh is the one who gives me strength" or 2) "Yahweh is the strong one who protects me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### song

Moses calls Yahweh his song because Yahweh is the one he sings about. AT: "the one I sing about" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he has become my salvation

Moses calls God his salvation because God saved him. AT: "he has saved me" or "he is the one who saves me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yahweh is a warrior

Moses calls God a warrior because God powerfully fought against the Egyptians and won. AT: "Yahweh is like a warrior" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Exodus 15:04

#### He has thrown Pharaoh's chariots and army into the sea

Moses sings about God causing the sea to cover Pharaohs chariots and army as if God had thrown them into the sea. AT: "he has made the sea cover over Pharaoh's chariots and army" or "He has made Pharaoh's chariot riders and army drown in the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they went down into the depths like a stone

Just as a stone does not float but sinks to the bottom of the sea, the enemy soldiers sank to the bottom of the sea. AT: "they went down into the deep water like a stone sinking to the bottom of the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]

### Exodus 15:06

#### Your right hand, Yahweh, is glorious in power

Moses speaks of God as if God had hands. The right hand refers to God's power or the things God does powerfully. AT: "Yahweh, your power is glorious" or "Yahweh, what you do is glorious in power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your right hand, Yahweh, has shattered the enemy

Moses speaks of God as if God had hands. The right hand refers to God's power. AT: "Yahweh, your power has shattered the enemy" or "Yahweh, by your power you have shattered the enemy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has shattered the enemy

Moses speaks of the enemy as if it were fragile and could be shattered like glass or pottery. AT: "has completely destroyed the enemy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### those who rose up against you

Rebelling against God is spoken of as rising up against him. AT: "those who rebelled against you" or "your enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You sent out your wrath

Moses speaks of God's wrath as if it were a servant that God sent out to do something. AT: "You showed your wrath" or "You acted according to your wrath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### it consumed them like stubble

Moses speaks of God's wrath as if it were fire that could completely burn up things. His enemies were completely destroyed like stubble in a fire. AT: "it completely destroyed your enemies like a fire that burns up straw" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### By the blast of your nostrils

Moses speaks of God as if God had a nose, and he speaks of the wind as if God blew the wind from his nose. AT: "You blew on the sea and" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Exodus 15:09

#### my desire will be satisfied on them

This can be expressed with an active form. AT: "I will satisfy my desire on them" or "I will take all I want from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my hand will destroy them

The enemies speak of destroying the Israelites by the power of their hands as if it were their hands that would destroy them. AT: "I will destroy them with my hand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But you blew with your wind

Moses spoke about God making the wind blow as if God blew the wind through his nose or mouth. AT: "But you made the wind blow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sank like lead in the mighty waters

Lead is a heavy metal that is commonly used to make things sink in water. The word "lead" here is used to show how fast God's enemies were destroyed. AT: "sank as fast as lead in the deep turbulent waters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Who is like you, Yahweh, among the gods?

Moses uses this question to show how great God is. AT: "O Yahweh, no one is like you among the gods!" or "Yahweh, none of the gods is like you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Who is like you, ... doing miracles?

Moses uses this question to show how great God is. AT: No one is like you. No one is majestic in holiness as you are, no one is honored in praises as you are, and no one does miracles as you do!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/majesty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]

### Exodus 15:12

#### with your right hand

The phrase "right hand" represents the strong power of God. AT: "with your strong power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### You reached out with your right hand

Moses speaks about God causing something to happen as if God reached out with his hand. AT: "With your strong power you made it happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the earth swallowed them

Moses personifies the earth as if it could swallow or devour with it's mouth. AT: "the earth devoured them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Exodus 15:14

#### tremble

This means to shake because you are afraid.

#### terror will seize the inhabitants of Philistia

Moses speaks of terror as if it were a person that could forcefully grab hold of someone and make them extremely afraid. AT: "the inhabitants of Philistia will be afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### will melt away

Moses speaks of people becoming weak from their fear as melting away. AT: "will be weak from fear" or "will be afraid and faint" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Exodus 15:16

#### Connecting Statement:

Moses continues to sing about how the people of other nations will feel when they see God's people.

#### Terror and dread will fall on them

These two words mean that fear will come upon them. AT: "Fear will come upon them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### dread

Dread is extreme fear or anxiety about something that is going to happen or might happen.

#### Because of your arm's power

God's arm represents his great strength. AT: "Because of your great strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they will become as still as a stone

Possible meanings are 1) "They will be silent like stone" or 2) "They will be motionless as stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]

### Exodus 15:17

#### You will bring them

Where God would bring them can be stated clearly. Since Moses was not already in Canaan, some languages would use "take" rather than "bring." AT: "You will take your people to Canaan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md)]])

#### plant them on the mountain

Moses speaks about God giving his people the land to live in as if they were a tree that God was planting. AT: "settle them on the mountain" or "let them live on the mountain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the mountain of your inheritance

This refers to Mount Zion in the land of Canaan.

#### of your inheritance

Moses speaks about God promising to give his people the mountain forever as if he were giving it to them as an inheritance. AT: "that you have given them as an inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that your hands have built

The phrase "your hands" refers to God's power. AT: "that you have built by your power" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Exodus 15:19

#### Miriam ... Aaron

Miriam was the older sister of Moses and Aaron. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### tambourine

This is a musical instrument like a small drum that also has pieces of metal around the side that make a sound when shaken. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### he has triumphed gloriously

It can be stated explicitly over whom Yahweh triumphed. See how you translated this in [Exodus 15:1](./01.md). AT: "he has achieved a glorious victory over the army of Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The horse and his rider he has thrown into the sea

Miriam sang about God causing the sea to cover and drown the horse and rider as if God had thrown them into the sea. See how you translated this in [Exodus 15:1](./01.md). AT: "He has made the horse and rider drown in the sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Exodus 15:22

#### Moses led Israel

The word "Israel" represents the people of Israel. AT: "Moses led the Israelite people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### wilderness of Shur ... Marah

We do not know the exact locations of these places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Exodus 15:24

#### complained to Moses and said

"were unhappy and told Moses" or "angrily told Moses"

#### the voice of Yahweh your God

Yahweh is speaking about his own voice. His voice represents what he says. AT: "my voice" or "what I say" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### do what is right in his eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "do what Yahweh considers to be right"(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will put on you none of the diseases

God speaks of causing people to have diseases as putting diseases on them. AT: "I will not cause any of you to have the diseases" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Exodus 15:27

#### Elim

This is an oasis in the desert, a place with water and shade trees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### twelve

"12" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]

### Exodus 15:intro

#### Exodus 15 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetic songs in 15:1-18 and 15:21. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]])

####### Special concepts in this chapter #######

######## Yahweh's laws ########
In this chapter, Moses talks about Yahweh's laws. The law of Moses is about to be introduced. Although it has not yet been formally introduced, this is what is being referenced in this chapter in anticipation of the revelation of the law of Moses. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

##### Links: #####

* __[Exodus 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## Exodus 16

### Exodus 16:01

#### wilderness of Sin

The word "Sin" here is the Hebrew name of the wilderness. It is not the English word "sin." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### on the fifteenth day of the second month

This time coincides with the end of April and the beginning of May on Western calendars. AT: "on day 15 of the second month" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### The whole community of Israelites

"All the Israelites." This is a generalization. Moses and Aaron did not complain. AT: "The Israelites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### complained

"were angry and spoke"

#### If only we had died

This is a way of saying that they wished that they had died. AT: "We wish that we had died"

#### by Yahweh's hand

The phrase "Yahweh's hand" represents Yahweh's action. AT: "by Yahweh's action" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Exodus 16:04

#### I will rain down bread from heaven for you

God speaks of food coming down from heaven as if it were rain. AT: "I will make bread come down from heaven like rain" or "I will make bread fall to you from the sky" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bread

God speaks of the food that he will send as if it were bread. The Israelites would eat this food every day, just as they had eaten bread every day before this. AT: "food" or "food like bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### walk in my law

God speaks of obeying his law as walking in it. AT: "obey my law" or "live according to my law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my law

"my command"

#### It will come about on the sixth day, that they

"It will happen on the sixth day that they" or "On the sixth day they"

#### on the sixth day

"on day 6" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### twice

"two times" or "2 times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]

### Exodus 16:06

#### Who are we for you to complain against us?

Moses and Aaron used this question to show the people that it was foolish to complain against them. AT: "We are not powerful enough for you to complain against us." or "It is foolish to complain against us, because we cannot do what you want." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### bread

Moses speaks of the food that God will send as if it were bread. The Israelites would eat this food every day, just as they had eaten bread every day before this. See how you translated it in [Exodus 16:4](./04.md). AT: "food" or "food like bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Who are Aaron and I?

Moses used this question to show the people that he and Aaron did not have the power to give them what they wanted. AT: "Aaron and I cannot give you what you want." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Your complaints are not against us; they are against Yahweh

The people were complaining against Moses and Aaron, who were Yahweh's servants. So by complaining against them, the people were really complaining against Yahweh. AT: Your complaints are not really against us; they are against Yahweh, because we are his servants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Exodus 16:09

#### It came about

This phrase is used here to mark an important event in the story. The important event here is the people seeing Yahweh's glory. If your language has a way for doing this, you could consider using it here.

#### behold

The word "behold" here shows that the people saw something interesting.

#### bread

God speaks of the food that he will send as if it were bread. The Israelites would eat this food every day, just as they had eaten bread every day before this. See how you translated it in [Exodus 16:4](./04.md). AT: "food" or "food like bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Exodus 16:13

#### It came about ... that

This phrase is used here to mark an important part of the events. If your language has a way for doing this, you could consider using it here.

#### quails

These are small, plump birds. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### like frost

The original readers knew what frost is like, so this phrase would help them understand what the flakes were like. Frost is frozen dew that forms on the ground. It is very fine. AT: "that looked like frost" or "that was fine like frost" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### bread

Moses speaks of the food that God sent as if it were bread. The Israelites would eat this food every day, just as they had eaten bread every day before this. See how you translated it in [Exodus 16:4](./04.md). AT: "food" or "food like bread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Exodus 16:16

#### Connecting Statement:

Moses continues telling the people about the food that God was providing for them.

#### omer

"two liters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]

### Exodus 16:19

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Exodus 16:22

#### It came about that

This phrase is used here to mark the beginning of a new part of the story. Verses 16:22-30 tell about what the people did concerning the manna on the sixth and seventh days of the week. If your language has a way for marking this as a new part of the story, you could consider using it here.

#### on the sixth day

"on day 6" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### twice

"two times" or "2 times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### bread

This refers to the bread that appeared as thin flakes on the ground each morning.

#### solemn

"serious" or "quiet and thoughtful"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/jewishleaders.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]

### Exodus 16:24

#### did not become foul

"did not smell rotten"

#### today is a day reserved as a Sabbath to honor Yahweh

"today is a Sabbath and is to be used only for honoring Yahweh"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Exodus 16:26

#### but the seventh day

"but on day seven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### manna

This was the name the Israelites gave to the bread that Yahweh caused to appear for them each morning.

#### they found none

"they did not find any manna"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]

### Exodus 16:28

#### General Information:

Yahweh speaks to Moses, but the word "you" refers to the people of Israel in general.

#### How long will you refuse to keep my commandments and my laws?

God used this question to scold the people because they did not obey his laws. AT: "You people still do not keep my commandments and laws!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to keep my commandments and my laws

"to obey my commandments and my laws"

#### Yahweh has given you the Sabbath

Yahweh speaks about teaching people to rest on the Sabbath as if the Sabbath were a gift. AT: "I, Yahweh, have taught you to rest on the Sabbath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sixth day ... two days ... seventh day

"day 6 ... 2 days ... day 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### bread

This refers to the bread that appeared as thin flakes on the ground each morning.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Exodus 16:31

#### manna

This was the name the Israelites gave to the bread that Yahweh caused to appear for them each morning. See how you translated this in [Exodus 16:26](./26.md).

#### coriander seed

Coriander is also known as cilantro. People dry the seeds and grind them into a powder and put it in food to give it flavor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### wafers

very thin biscuits or crackers

#### omer

"2 liters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### bread

This refers to the bread that appeared as thin flakes on the ground each morning.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 16:33

#### Now an omer is a tenth of an ephah

An omer and an ephah are both containers for measuring volume. The original readers would have known how much an ephah was. This sentence would help them know how much an omer was. For languages that do not use fractions, this can be reworded. AT: "Now ten omers equal one ephah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### an omer

"two liters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Exodus 16:intro

#### Exodus 16 General Notes ####

####### Special concepts in this chapter #######

######## Complaints ########
The Israelites complained about the amount of food Yahweh gave them, even when he miraculously provided their food for them. This is intended to show their ungratefulness and their sinful view of Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

######## Prohibition against storing food ########
The people were not allowed to store the food, called manna, they were provided with. This is because they were to trust in Yahweh to provide for their needs every day. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]])

######## Sabbath ########
This is the first recorded celebration of the Sabbath rest. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]])

######## Ark of the covenant ########
Although the covenant has not yet been made, it is referenced in [Exodus 16:34](./33.md). This is probably done either in anticipation of the building of the ark or as an editorial comment made by Moses after these events. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

####### Other possible translation difficulties in this chapter #######

######## Wilderness of Sin ########
Sin is the name of a part of the Sinai Wilderness. It is not the description of a place, and it has nothing to do with sinning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Links: #####

* __[Exodus 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | [>>](../17/intro.md)__


## Exodus 17

### Exodus 17:01

#### wilderness of Sin

The word "Sin" here is the Hebrew name of the wilderness. It is not the English word "sin." See how you translated this in [Exodus 16:1](../16/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Rephidim

This means "the resting place," a place to rest on long journeys through the wilderness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Why do you quarrel with me? Why do you test Yahweh?

Moses uses these questions to scold the people. AT: "You should not quarrel with me! You should not test Yahweh!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### To kill us and our children and our cattle with thirst?

The people use this question to accuse Moses of wanting to kill them. AT: "You only brought us out here to kill us and our children and cattle by not letting us have any water to drink!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]

### Exodus 17:04

#### Massah

a place in the desert whose name means "testing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Meribah

a place in the desert whose name means "complaining" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/horeb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/horeb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Exodus 17:08

#### Rephidim

This was the name of a place in the desert. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### So Joshua fought Amalek

Joshua represents himself and the Israelites that he led into battle. AT: "So Joshua and the men he chose fought against the Amalekites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Hur

Hur was a friend of Moses and Aaron. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Exodus 17:11

#### Israel was winning ... Amalek would begin to win

The words "Israel" and "Amalek" represent the fighters from those groups. AT: "the Israelite fighters were winning ... the Amalekite fighters would begin to win" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### hands became heavy

The author writes of Moses' arms becoming tired as if his hands became heavy. AT: "arms became tired" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with the sword

The sword represents battle. AT: "in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Exodus 17:14

#### I will completely blot out the memory of Amalek

God speaks of destroying Amalek as if he were removing people's memory of Amalek. When a group of people is completely destroyed, there is nothing to remind people about them. AT: "I will completely destroy Amalek" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a hand was lifted up

People would raise their hand when they made a promise or pledge, so raising the hand represents making a promise. AT: "a promise was made" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a hand was lifted up

This can be stated in active form. AT: "Yahweh lifted up his hand" or "Yahweh made a solemn promise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Amalek

This refers to the Amalekites. AT: Amalekites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Exodus 17:intro

#### Exodus 17 General Notes ####

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
Moses uses several rhetorical questions in this chapter. The purpose of these questions is to convince people of their sin. Likewise, the people's rhetorical question showed their ignorance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

####### Other possible translation difficulties in this chapter #######

######## Wilderness of Sin ########
Sin is the name of a part of the Sinai Wilderness. It is not the description of a place, and it has nothing to do with sinning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Links: #####

* __[Exodus 17:01 Notes](./01.md)__

__[<<](../16/intro.md) | [>>](../18/intro.md)__


## Exodus 18

### Exodus 18:01

#### Moses' father-in-law

This refers to the father of the wife of Moses.

#### took Zipporah, Moses' wife ... and her two sons

Possible meanings are 1) Jethro took Zipporah and her two sons to Moses, or 2) Jethro had earlier welcomed back Zipporah and her two sons.

#### after he had sent her home

This is something Moses had done earlier. The full meaning of the can be made explicit. AT: "after Moses had sent her home to her parents" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Gershom

This is a son of Moses and Zipporah, whose name means "foreigner." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Eliezer

This is a son of Moses and Zipporah, whose name means "God is the one who helps me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Pharaoh's sword

This represents being killed by Pharaoh or Pharaoh's army. AT: "being killed by Pharaoh" or "being killed by Pharaoh's army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Exodus 18:05

#### where he was camped

This can be stated in active form. AT: "where he camped with the Israelites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jethro.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Exodus 18:07

#### bowed down, and kissed him

These symbolic acts were the normal way that people showed great respect and devotion in that culture. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### for Israel's sake

The word "Israel" represents the Israelite people. AT: "in order to help the Israelite people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### all the hardships that had come to them

Moses writes of hardships happening to them as if hardships had come to them. AT: "all the hardships that had happened to them" or "all the hardships they had experienced" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kiss.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]

### Exodus 18:09

#### the hand of the Egyptians ... the hand of Pharaoh

The hand represents the power of someone to do something. AT: "the power of the Egyptians ... the power of Pharaoh" or "what the Egyptians were doing to you ... what Pharaoh was doing to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 18:12

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Exodus 18:13

#### What is this that you are doing with the people?

Jethro uses this question to show Moses that what he was doing was not good. This rhetorical question can be translated as a statement. AT: "You should not be doing all of this for the people!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Why is it that you sit alone ... from morning until evening?

Jethro used this question to show Moses that he was doing too much. This rhetorical question can be translated as a statement. AT: "You should not sit alone ... from morning till evening!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### you sit alone

The word "sit" here is a metonym for "judge." Judges would sit while they listened to people's complaints. AT: "you judge alone" or "you are the only one who judges the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 18:15

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Exodus 18:17

#### You will surely wear yourselves out

"you will surely make yourselves very tired"

#### This burden is too heavy for you

Jethro speaks of the hard work that Moses is doing as if it were a physical burden that Moses was carrying. AT: "This work is too much for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### advice

"guidance" or "instruction"

#### God will be with you

Jethro speaks of God helping Moses as if God would be with Moses. AT: "God will help you" or "God will give you wisdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you bring their disputes to him

Jethro speaks of Moses telling God about their disputes as if Moses were bringing their disputes to God. AT: "you tell God about their disputes" or "you tell God what they are arguing about" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### You must show them the way to walk

Jethro speaks of living or behaving like walking. AT: "You must show them how to live" or "You must show them how to behave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 18:21

#### Connecting Statement:

Jethro continues speaking to Moses.

#### Furthermore, you must choose

"In addition, you must choose" or "You must also choose"

#### You must put them over people

Jethro speaks of giving them authority over people as putting them over people. AT: You must give them authority over people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### leaders in charge of thousands, hundreds, fifties, and of tens

Possible meanings are 1) these numbers represent the exact amount of people in each group. AT: "leaders in charge of groups of 1,000 people, groups of 100 people, groups of 50 people, and groups of 10 people" or 2) these numbers are not exact, but represent groups of people of various sizes. AT: "leaders in charge of very small groups, small groups, large groups, and very large groups" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### routine cases

"the simple cases"

#### the difficult cases they will bring to you

Jethro speaks of telling Moses about the difficult cases as bringing him the difficult cases. AT: "the difficult cases they will tell you about" or "when there are difficult cases, they will tell you about them so you can judge them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they will carry the burden with you

Jethro speaks of the hard work that they would do as if it were a burden that they would carry. AT: "they will do the hard work with you" or "they will help you do the hard work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### endure

What they will endure can be stated clearly. AT: "endure the stress of the work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]

### Exodus 18:24

#### heads over the people

Moses writes of the leaders of people as if they were the head of a body. AT: "leaders of the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### capable men

What they were capable of doing can be stated clearly. AT: "men who were able to lead" or "men who were able to judge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### leaders in charge of thousands, hundreds, fifties, and tens

Possible meanings are 1) these numbers represent the exact amount of people in each group. AT: "leaders in charge of groups of 1,000 people, groups of 100 people, groups of 50 people, and groups of 10 people" or 2) these numbers are not exact, but represent groups of people of various sizes. AT: "leaders in charge of very small groups, small groups, large groups, and very large groups" See how you translated this in [Exodus 18:21](./21.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### circumstances

"situations"

#### The difficult cases they brought to Moses

The author writes of telling Moses about the difficult cases as bringing him the difficult cases. AT: "the difficult cases they told Moses about" or "when there were difficult cases, they told Moses about them so that he would judge them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the small cases

"the easy cases"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Exodus 18:intro

#### Exodus 18 General Notes ####

####### Special concepts in this chapter #######

######## Leadership lessons ########
Jethro taught Moses an important leadership lesson in this chapter. Many scholars look at this chapter for important leadership lessons. Moses delegated some of his responsibilities to other godly men so that he would not become worn out by all the demands made of him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godly.md)]])

##### Links: #####

* __[Exodus 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__


## Exodus 19

### Exodus 19:01

#### In the third month ... on the same day

This means they arrived at the wilderness on the first day of the month just as they left Egypt on the first day of the month. The first day of the third month on the Hebrew calendar is near the middle of May on Western calendars. AT: "In the third month ... on the first day of the month" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### had gone out from

"had left"

#### Rephidim

This is an area on the edge of the wilderness of Sinai where the people of Israel had been camping. See how you translated this name in [Exodus 17:1](../17/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]

### Exodus 19:03

#### the house of Jacob

The word "house" here represents Jacob's family and descendants. AT: "the descendants of Jacob" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the house of Jacob, the people of Israel

The phrase "the people of Israel" explains what "the house of Jacob" means.

#### You have seen

The word "you" here refers to the Israelites. Yahweh is telling Moses what to tell the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### I carried you on eagles' wings

God speaks of caring for his people while they traveled as if he were an eagle and carried them on his wings. AT: "I helped you travel like an eagle that carries her babies on her wings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### obediently listen to my voice

Obediently can be expressed as a verb. AT: "listen to my voice and obey me"

#### my voice

God's voice represents what he says. AT: "what I say" or "my words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### keep my covenant

"do what my covenant requires you to do"

#### special possession

"treasure"

#### a kingdom of priests

God speaks of his people as if they were priests. AT: "a kingdom of people who are like priests" or "a kingdom of people who do what priests do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Exodus 19:07

#### set before them all these words

The author writes of Moses telling people things as if he were setting the words before them. AT "told them all these words" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### all these words that Yahweh had commanded him

"all that Yahweh had commanded him"

#### Moses came to report

Where Moses went can be stated explicitly. AT: "Moses went back up the mountain to report" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the people's words

The word "words" refers to what the people said. AT: "what the people said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Exodus 19:10

#### you must set them apart to me

This probably means "tell them to dedicate themselves to me" or "tell them to purify themselves for me."

#### garments

"clothes"

#### Be ready

This was a command to the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]

### Exodus 19:12

#### General Information:

Yahweh continues speaking to Moses.

#### set boundaries

"make a boundary." This was either a mark or some kind of barrier.

#### Whoever touches the mountain will surely be put to death

This can be stated with an active form. AT: "You must surely put to death any person who touches the mountain" or "You must surely kill anyone who touches the mountain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Whoever touches

"Any person who touches" or "Anyone who touches"

#### such a person

"a person who does that" or "a person who touches the mountain"

#### he must certainly be stoned or shot

This can be stated in active form. AT: "you must certainly stone or shoot him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### shot

This refers to being killed by someone who shoots arrows from a bow or stones from a slingshot.

#### a long blast

"a long, loud sound"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Exodus 19:14

#### do not go near your wives

This is a polite way of talking about sleeping with their wives. AT: "do not sleep with your wives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]

### Exodus 19:16

#### trembled

"shook with fear"

#### descended

"came down"

#### like the smoke of a furnace

This shows that it was a very large amount of smoke. AT: "like the smoke from a very large fire"

#### furnace

an oven that can be made extremely hot (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]

### Exodus 19:19

#### grew louder and louder

"continued to become louder and louder"

#### in a voice

The word "voice" here refers to a sound that God made. Possible meanings are 1) "by speaking loudly like thunder" or 2) "by speaking" or 3) "by causing thunder to sound" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he summoned Moses

"he commanded Moses to come up"

#### not to break through

God spoke about walking past the boundary as if they might break down a barrier and walk through it. See how you translated "set bounds" in [Exodus 19:12](./12.md). AT: "not to go beyond the boundary" or "not to go through the barrier"(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]

### Exodus 19:23

#### get down

"go down"

#### break through the barrier

God spoke about walking past the boundary as if they might break down a barrier and walk through it. See how you translated a similar phrase in [Exodus 19:21](./19.md). AT: "go beyond the boundary" or "go through the barrier" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Exodus 19:intro

#### Exodus 19 General Notes ####

####### Special concepts in this chapter #######

######## "A kingdom of priests" ########
The function of the priests was to intercede for the people. The Levites were the only priests in Israel; this is a metaphor indicating that the nation was to intercede for the world as a whole. They were also to be holy, or set apart, from the rest of the world. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]], [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

######## Revealing the Law ########
The events of this chapter are concerned with preparing the people to receive the law of Moses. The people go through all of this to prepare themselves for the law, which show the great importance of this event for Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

##### Links: #####

* __[Exodus 19:01 Notes](./01.md)__

__[<<](../18/intro.md) | [>>](../20/intro.md)__


## Exodus 20

### Exodus 20:01

#### house of slavery

"place where you were slaves"

#### You must have no other gods before me

"You must not worship any other gods but me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Exodus 20:04

#### nor the likeness

"and you must not make the likeness"

#### You must not bow down to them or worship them

The word "them" refers to carved figures or idols.

#### jealous

God wants his people to worship only him.

#### punish the ancestors' wickedness by bringing punishment on the descendants

God will punish people for the sin of their parents.

#### to the third and the fourth generation

"to generations 3 and 4." This refers to the grandchildren and great-grandchildren. AT: "even on the grandchildren and great-grandchildren  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### I show covenant faithfulness to thousands of those who love me

The abstract noun "faithfulness" can be stated as "faithfully" or "faithful." AT: "I faithfully love thousands of those who love me" or "I am faithful to the covenant with thousands of those who love me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### to thousands of those who love me

The word "thousands" is a metonym for a number too many to count. AT: "forever to those who love me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 20:07

#### take the name of Yahweh your God

"use the name of Yahweh your God"

#### in vain

"carelessly" or "without proper respect"

#### I will not hold guiltless

This double-negative can be stated as a positive. AT: "I will certainly consider guilty" or "I will certainly punish" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vain.md)]]

### Exodus 20:08

#### do all your work

"do all your usual duties"

#### within your gates

Cities often had walls around them to keep out enemies, and gates for people to go in and out. AT: "within your community" or "inside your city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### on the seventh day

"on day seven." Here "seventh" is the ordinal number for "7." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### blessed the Sabbath day

Possible meanings are that 1) God caused the Sabbath day to produce good results, or 2) God said that the Sabbath day was good.

#### set it apart

"set it apart for a special purpose"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Exodus 20:12

#### You must not commit adultery

"You must not have sex with anyone other than your spouse"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]

### Exodus 20:15

#### must not give false testimony

"must not speak a false report" or "must not tell lies about someone"

#### must not covet

"must not strongly want to have" or "must not want to take"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/envy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Exodus 20:18

#### voice

"sound"

#### the mountain smoking

"smoke coming from the mountain"

#### they trembled

"they shook with fear"

#### stood far off

"stood far away" or "stood at a distance"

#### so that the honor of him may be in you, and so that you do not sin

"so that you will honor him and not sin"

#### approached

"went closer to"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]

### Exodus 20:22

#### This is what you must tell the Israelites

"Tell the Israelites this"

#### You yourselves have seen that I have talked with you from heaven

"You have heard me speak to you from heaven"

#### You will not make for yourselves other gods alongside me

"You must not make idols as other gods instead of me"

#### gods of silver or gods of gold

"gods made out of silver or gold" or "idols made out of silver or gold"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 20:24

#### earthen altar

an altar made of materials from the ground, such as stone, soil, or clay

#### cause my name to be honored

Here "name" is a metonym for God's being. This can be stated in active form. AT: "choose for you to honor me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You must not go up to my altar on steps

"Do not build steps up to the altar and go up to it on those steps"

#### your nakedness

"your private parts"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]

### Exodus 20:intro

#### Exodus 20 General Notes ####

####### Structure and formatting #######

The instructions recorded in this chapter are commonly known as the "ten commandments." 

####### Special concepts in this chapter #######

######## Covenant ########
Yahweh's covenant faithfulness is now based on the covenant he made with Abraham as well as the covenant he is making with Moses. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

##### Links: #####

* __[Exodus 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__


## Exodus 21

### Exodus 21:01

#### General Information:

Yahweh continues speaking to Moses.

#### you must set before them

"you must give them" or "you must tell them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Exodus 21:02

#### General Information:

Yahweh tells Moses his laws for the people of Israel.

#### If he came by himself, he must go free by himself

What "by himself" means can be stated clearly. Some languages require that the additional condition, that he marries while a slave, be stated clearly. AT: "If he became a slave while he had no wife, and if he marries while he is a slave, the master need only free the man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### by himself

"alone" or "without a wife"

#### if he is married

"if he was married when he became a slave" or "if he came as a married man"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Exodus 21:05

#### plainly says

"clearly says"

#### I will not go out free

"I do not want my master to set me free"

#### bore his ear through

"put a hole in his ear"

#### awl

a pointed tool used to make a hole

#### for life

"until the end of his life" or "until he dies"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doorpost.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/doorpost.md)]]

### Exodus 21:07

#### has designated

"has chosen"

#### he must let her be bought back

This can be stated in active form. AT: "he must allow her father to buy her back" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### has no right to sell

"has no authority to sell"

#### he has treated her deceitfully

"he has deceived her"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]

### Exodus 21:09

#### designates

"chooses"

#### he must not diminish her food, clothing, or her marital rights

This can be stated in a positive form. AT: "he must give the first wife the same food, clothing, and marital rights she had before" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### diminish

"take away" or "reduce"

#### or her marital rights

This includes things that a husband must do for his wife, including sleeping with her. AT: "and he must continue to sleep with her as before" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

### Exodus 21:12

#### strikes

"hits" or "attacks"

#### that person must surely be put to death

This can be stated in active form. AT: "you must certainly execute that person" or "you must certainly kill that person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### did not do it with premeditation

"did not plan to do it" or "did not do it on purpose"

#### I will fix a place to where he can flee

The purpose of choosing a place can be stately clearly here. AT: "I will choose a place that he can run away to be safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### according to a cunning plan

"after thinking carefully about it"

#### must take him

The word "him" refers to the one who killed his neighbor.

#### so that he may die

This can be stated in active form. AT: "so that you can kill him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Exodus 21:15

#### Whoever hits his father or mother must surely be put to death

This can be stated in active form. AT: "If anyone hits his father or mother, you must surely put him to death" or "You must surely kill anyone who hits his father or mother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### must surely

"must certainly"

#### in his possession

"with him"

#### that kidnapper must surely be put to death

This can be stated in active form. AT: "you must certainly kill that kidnapper" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Whoever curses his father or his mother must surely be put to death

This can be stated in active form. AT: "you must surely kill anyone who curses his father or his mother" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]

### Exodus 21:18

#### is confined to his bed

This can be stated in active form. AT: "cannot get out of bed" or "has to stay in bed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### recovers

"gets better"

#### staff

This is a stick that can be leaned on for support while walking.

#### the loss of his time

This refers to a situation when someone cannot work to earn money. You can express this clearly in the translation. AT: "the time he could not work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### pay for his complete recovery

"pay his medical costs" or "pay for his costs for healing"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]

### Exodus 21:20

#### as a result of the blow

"because of the injury" or "because his master hit him"

#### that man must surely be punished

This can be stated in active form. AT: "you must certainly punish that man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for he will have suffered the loss of the servant

You can express clearly in the translation that the servant was valuable to his master. AT: "because he has already lost his servant who was valuable to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Exodus 21:22

#### she miscarries

"her baby dies in her womb" or "her baby is born too soon and dies"

#### the guilty man must surely be fined

This can be stated in active form. AT: "you must certainly fine the guilty man" or "the guilty man must pay a fine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as the judges determine

"what the judges decide"

#### you must give a life for a life, an eye for an eye

This means that if she is hurt, the person who hurt her must be hurt in the same way. AT: "he must give his life for her life, his eye for her eye" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]

### Exodus 21:26

#### If a man

Here "man" refers to the owner of a slave.

#### in compensation

"as payment." Compensation is what someone does for another person or gives to another person to make up for what he has caused that person to lose.

### Exodus 21:28

#### gores

"injures with its horns"

#### the ox must surely be stoned

This can be stated in active form. AT: "you must stone the ox to death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### its flesh must not be eaten

This can be stated in active form. AT: "you must not eat its flesh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the ox's owner must be acquitted

This can be stated in active form. AT: "you must acquit the ox's owner" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### its owner also must be put to death

This can be stated in active form. AT: "you must also kill its owner" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### If a payment is required for his life

If the ox's owner can pay a fine to save his own life, then he must pay whatever the judges decide. The full meaning of this can be stated clearly. This can also be stated in active form. AT: "if the owner of the bull can pay a fine to save his own life, he must pay the full amount that the judges say that he must pay" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acquit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acquit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]

### Exodus 21:31

#### has gored

"has injured with its horns"

#### thirty shekels of silver

"330 grams of silver." A shekel weighed eleven grams. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### the ox must be stoned

This can be stated in active form. AT: "you must kill the ox by stoning it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]

### Exodus 21:33

#### opens a pit

"uncovers a hole in the ground" or "takes a cover off a hole in the ground"

#### repay the loss

The owner must be paid for the loss of his animal. AT: "pay the owner for the dead animal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### will become his

The one who paid for the loss of the animal will become the owner of the dead animal and can do what he wants with it. The full meaning of this statement can be made explicit. AT: "will belong to the owner of the pit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Exodus 21:35

#### divide its price

"divide the money" or "divide the money they receive"

#### if it was known

This can be stated in active form. AT: "if people knew" or "if the owner knew" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a habit of goring in time past

"had gored other animals before"

#### its owner has not kept it in

This means that the owner did not keep his ox securely inside a fence. This can be clearly stated in the translation. AT: "its owner did not keep it inside a fence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he must surely pay ox for ox

The owner of the ox that killed must give an ox to the man who lost his ox. This can be stated clearly in the translation. AT: "the owner of the ox that killed must surely give a living ox to the owner of the ox that died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

### Exodus 21:intro

#### Exodus 21 General Notes ####

####### Special concepts in this chapter #######

######## Covenant with Moses ########
Although the covenant Yahweh made with Moses began in the previous chapter, it formally begins with the statement, "Now these are the decrees that you must set before them." The law of Moses was a major part of this covenant. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

######## Slavery ########
This passage does not condone slavery as an acceptable practice. However, it does impose some restrictions on the practice. 

######## Justice in society ########
The rules and law of this chapter are not intended to be followed by every society. Israel was God's chosen nation and was required to live in a special way. These laws concerned creating a just society and a holy nation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

##### Links: #####

* __[Exodus 21:01 Notes](./01.md)__

__[<<](../20/intro.md) | [>>](../22/intro.md)__


## Exodus 22

### Exodus 22:01

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### If a thief is found

This can be stated in active form. AT: "If anyone finds a thief" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### breaking in

"using force to come into a house"

#### if he is struck so that he dies

This can be stated in active form. AT: "if anyone strikes the thief so that he dies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### no guilt for murder will attach to anyone on his account

"no one will be guilty of murdering him"

#### if the sun has risen before he breaks in

"if it is light before he breaks in" or "if he breaks in and it is after sunrise"

#### guilt for murder will attach to the person who kills him

"the person who kills him will be guilty of murder"

#### make restitution

"pay for what he stole"

#### he must be sold for his theft

This can be stated in an active form. AT: "you must sell him as a slave in order to pay for what he stole" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### If the stolen animal is found alive in his possession

This can be stated in active form. AT: "If they find that he still has the live animal that he stole" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### pay back double

pay two animals for every animal that he took

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Exodus 22:05

#### If a man grazes his livestock

"If a man lets his animals eat plants"

#### it grazes

"it eats plants"

#### he must make restitution

"he must pay back the owner of that field"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]

### Exodus 22:06

#### If a fire breaks out and spreads in thorns

"If someone starts a fire and it spreads in thorns"

#### spreads in thorns

"moves along the ground through dry plants"

#### stacked grain

This is grain that has been cut and tied in bundles. "bundled grain" or "harvested grain"

#### standing grain

This is grain that has not been cut, but it is ready to be harvested.

#### a field is consumed

"fire consumes a field" or "fire destroys a field"

#### must surely make restitution

"must certainly pay for the grain that the fire destroyed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]

### Exodus 22:07

#### for safe keeping

"to watch over it" or "to keep it safe"

#### if it is stolen

This can be stated in active form. AT: "if someone steals it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### thief

someone who steals something

#### if the thief is found

This can be stated in active form. AT: "if you find the thief" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### come before the judges to see whether

"come before the judges so that they can find out if"

#### has put his own hand on his neighbor's property

This is an idiom. If you have a way of saying this in your language, you can use it here. AT: "has stolen his neighbor's property" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the claim of both parties must come before the judges

The judges must listen to both people who claim that the item belongs to them and the judges will decide who is guilty.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]

### Exodus 22:10

#### an oath to Yahweh must be taken by them both

Only the man who is accused of stealing the animal must swear the oath. The owner of the lost animal must accept the oath that has been sworn. This can be stated in active form. AT: "the man who was caring for the animal must swear an oath before Yahweh and the owner must accept that oath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### But if it was stolen from him

This can be stated in active form. AT: "But if someone stole the animal from him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### If an animal was torn in pieces

This can be stated in active form. AT: "But if a wild beast tore the animal in pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He will not have to pay for what was torn

This can be stated in active form. AT: "He will not have to pay for the animal that the wild beast destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 22:14

#### must surely make restitution

"must certainly repay with another animal" or "must certainly pay the owner for the animal"

#### if the animal was hired

This can be stated in active form. AT: "if someone rented the animal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it will be paid for by its hiring fee

The one who borrowed the animal will not have to pay the owner anything more than the hiring or rental fee. This fee will pay for the loss of the animal. This can be stated clearly in the translation. AT: "the money that someone paid to rent the animal will cover the loss of the animal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### hiring fee

"rental fee" or "money paid to rent the animal"

### Exodus 22:16

#### seduces

"persuades"

#### not engaged

"not promised to be married"

#### if he sleeps with her

Sleeping with someone is a euphemism for having sex. AT: "if he has sex with her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### bride wealth

"dowry" or "bride price"

#### him, he

These pronouns refer back to the man who seduced the virgin.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]

### Exodus 22:18

#### Whoever sleeps with a beast must surely be put to death

Here "sleeps with a beast" is a euphemism that means someone has sex with an animal. This can be stated in active form. AT: "You must certainly kill anyone who has sex with an animal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]

### Exodus 22:20

#### Yahweh must be completely destroyed

This can be stated in active form. AT: "Yahweh, you must completely destroy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### wrong a foreigner

"mistreat a foreigner" or "cheat a foreigner"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 22:22

#### You must not mistreat any widow or fatherless child

This can be stated in positive form. AT: "You must treat all widows and fatherless children fairly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### widow

"woman whose husband has died"

#### fatherless child

"orphan" or "child with no parents"

#### I will kill you with the sword

To be killed "with the sword" is a metonym that means a person will die violently, or perhaps fighting in a war. AT: "you will die a violent death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Exodus 22:25

#### a moneylender

"one who lends money"

#### charge him interest

"charge him extra money for borrowing" or "charge him extra money for the loan"

#### garment in pledge

"coat as collateral" or "coat as a guarantee to repay the loan"

#### only covering

"only coat" or "only garment to keep him warm"

#### What else can he sleep in?

This question adds emphasis. You can translate it as a strong statement. AT: "He will have nothing to wear while he sleeps!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### compassionate

"merciful" or "gracious"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]

### Exodus 22:28

#### You must not blaspheme me, God

"Do not insult God" or "Do not speak evil about God"

#### nor curse a ruler

"and do not ask God to do bad things to a ruler"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 22:29

#### You must not hold back offerings

This can be stated in a positive form. AT: "You must bring all of your offerings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### give to me the firstborn of your sons

"dedicate your firstborn sons to me"

#### do the same with

"dedicate to me the firstborn of"

#### For seven days

This can be written as a numeral. AT: "For 7 days after they are born" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the eighth day

This can be written as a numeral. AT: "day number 8" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### give them to me

"dedicate them to me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]

### Exodus 22:intro

#### Exodus 22 General Notes ####

####### Special concepts in this chapter #######

######## Justice in society ########
The rules and laws of this chapter are not intended to be followed by every society. Israel was God's chosen nation and was required to live in a special way. These laws concerned creating a just society and a holy nation. In this chapter, the purpose of these laws often focuses on minimizing the people's desire for vengeance. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]])

##### Links: #####

* __[Exodus 22:01 Notes](./01.md)__

__[<<](../21/intro.md) | [>>](../23/intro.md)__


## Exodus 23

### Exodus 23:01

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### dishonest witness

This is the same as a lying or false witness.

#### nor may you bear witness

"and you also must not speak"

#### siding with the crowd

This is a metaphor that describes one's agreeing with a group of people as if he actually walked over and stood with that group. AT: "doing what the crowd wants" or "agreeing with the majority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### pervert justice

do illegal or immoral actions that result in a unjust ruling

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falsewitness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]

### Exodus 23:04

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/astray.md)]]

### Exodus 23:06

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### You must not pervert justice

"You must not do actions that produce an improper legal result" that results in either freedom for a guilty person or punishment of the innocent.

#### it should go

In this phrase, "it" refers to proper justice, a correct decision.

#### lawsuit

"dispute"

#### I will not acquit the wicked

"I will not find the wicked not guilty" or "I will not say of wicked people that they are innocent"

#### bribe blinds ... perverts

Here a "bribe" is described as if it were a person. AT: "bribe discredits ... undermines" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the life of a foreigner

"the kind of life a stranger lives in a foreign land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acquit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acquit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 23:10

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### produce

"food products from plants"

#### unplowed

"uncultivated" or "untilled"

#### fallow

"in its natural state" or "unused for production"

#### so that the poor among your people may eat

The poor can eat any food that grows on its own in a field that is not cultivated. This can be stated clearly in the translation. AT: "so the poor among your people may harvest and eat any food that grows on its own in that field" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]

### Exodus 23:12

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### Pay attention to

"Do" or "Obey"

#### your ox and your donkey

"your work animals"

#### any foreigner may rest and be refreshed

This can be stated in active form. AT: "any foreigner may rest and regain his strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### mention the names of other gods

This represents praying to other gods. AT: "pray to other gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Exodus 23:14

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### Aviv

This is the name of the first month of the Hebrew calendar. Aviv is during the last part of March and the first part of April on Western calendars. See how you translated this in [Exodus 13:4](../13/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### not appear before me empty-handed

Here understatement is used to emphasize that the Israelites must bring a suitable offering to Yahweh. AT: "come to me without a proper offering" or "always bring an offering to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]

### Exodus 23:16

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### You must observe

"You must honor" or "You must celebrate"

#### Festival of Ingathering

This festival celebrated the final harvesting of all the crops for the year.

#### All your males must appear before the Lord Yahweh

Here to "appear" means to gather for worship. AT: "All the men must gather to worship the Lord Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 23:18

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### fat from the sacrifices

The fat was burned as an offering to Yahweh and was never eaten.

#### the choicest firstfruits

"the best and first produce of the harvest"

#### You must not boil a young goat in its mother's milk

This was a magical fertility practice among the Canaanites, which the Israelites were not permitted to participate in.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Exodus 23:20

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### Be attentive to him

"Listen to him"

#### Do not provoke him, for he will not pardon

"If you provoke him, he will not pardon"

#### My name is on him

Here "name" refers to God's authority. AT: "He has my authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### If you indeed obey his voice

Here "voice" represents what the angel says. AT: "If you carefully obey what he says" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### an enemy to your enemies and an adversary to your adversaries

These two phrases mean the same thing and are used for emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Exodus 23:23

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### You must not ... do as they do

The Israelites must not live as the people who worship other gods. AT: "You must not ... live as the people who worship those gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he will bless your bread and water

This is a merism that means food and drink. AT: "he will bless your food and drink" or "he will bless you by giving you food and drink" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### he will bless ... I will remove

Yahweh switched between the first and third pronoun to refer to himself. Here both "he" and "I" refer to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Exodus 23:26

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### No woman will be barren or will miscarry her young in your land

This can be stated in positive form. AT: "Every woman will be able to become pregnant and give birth to healthy babies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### miscarry

to have a pregnancy end early and unexpectedly

#### hornets

a flying insect that can sting people and cause pain

#### or the land would become abandoned

"because no one would be living in the land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barren.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]

### Exodus 23:30

#### General Information:

Yahweh continues telling Moses his laws for the people of Israel.

#### this will surely become a trap for you

This means worshiping other gods will lead the people of Israel to certain destruction as if they were an animal caught in a hunter's trap. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 23:intro

#### Exodus 23 General Notes ####

####### Special concepts in this chapter #######

######## Justice in society ########
The rules and laws of this chapter are not intended to be followed by every society. Israel was God's chosen nation and was required to live in a special way. These laws concerned creating a just society and a holy nation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

######## Celebrations of feasts and festivals ########
The people of Israel were required to celebrate certain feasts and festivals. These were part of the law of Moses and some are described in this chapter. Their purpose was to worship Yahweh and to remember the great things Yahweh has done for them. 

##### Links: #####

* __[Exodus 23:01 Notes](./01.md)__

__[<<](../22/intro.md) | [>>](../24/intro.md)__


## Exodus 24

### Exodus 24:01

#### Nadab ... Abihu

These are men's names. See how you translated these names in [Exodus 6:23](../06/23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### seventy of Israel's elders

"70 of Israel's elders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Exodus 24:03

#### with one voice

This is an idiom that means the people were in complete agreement. AT: "together" or "in agreement" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### foot of the mountain

"base of the mountain" or "bottom of the mountain"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Exodus 24:05

#### Moses took half of the blood and put it into basins

Moses collected half of the blood in basins in order to splash it on the people in [Exodus 24:8](./07.md). This would confirm the people's participation in the covenant between the people of Israel and God.

#### he sprinkled the other half onto the altar

Here the altar represents God. This would confirm God's participation in the covenant between God and the people of Israel.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Exodus 24:07

#### We will be obedient

This can be stated in active form. AT: "We will obey everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Then Moses took the blood

This refers to the blood that Moses had put into the bowls. This can be stated clearly. AT: "Then Moses took the blood that was in the bowls" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Exodus 24:09

#### Nadab ... Abihu

These are men's names. See how you translated these names in [Exodus 6:23](../06/23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Under his feet

This speaks of God as if he had human feet. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### a pavement made of sapphire stone

"a pavement made of blue stones called sapphires"

#### pavement

a hard surface for walking or riding

#### sapphire stone

This is a gemstone that is blue in color. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### as clear as the sky itself

This is a simile. AT: "as clear as the sky is when there are no clouds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### God did not lay a hand on the Israelite leaders

This means that God did not harm the leaders. AT: "God did not harm the Israelite leaders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Exodus 24:12

#### tablets of stone and the law and commandments

God had written the law and commandments on the tablets of stone. This can be stated clearly. AT: "two stone slabs on which I have written all the laws" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### with his assistant Joshua

"with Joshua who assisted him" or "with Joshua who helped him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]

### Exodus 24:14

#### wait for us

"wait for Joshua and me"

#### Hur

Hur was a man who was a friend of Moses and Aaron. See how you translated this name in [Exodus 17:10](../17/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Exodus 24:16

#### Yahweh's glory

This was the brilliant light of God's presence. AT: "The brilliant light showing God's presence" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### like a devouring fire

This means the glory of Yahweh was very large and seemed to burn brightly like a fire. AT: "like a big fire burning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### in the eyes of the Israelites

Their eyes represent seeing, and seeing represents their thoughts or judgment about they saw. AT: "to the Israelites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### forty days and forty nights

"40 days and 40 nights" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Exodus 24:intro

#### Exodus 24 General Notes ####

####### Special concepts in this chapter #######

######## Moses' covenant ########
The people of Israel promise to obey the covenant Yahweh made with Moses. Their continued blessings were contingent upon their obedience to this covenant. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]])

######## God's holiness ########
Because Yahweh is perfectly holy, he can only be approached in a certain way. Because of this, only Moses was allowed near Yahweh. This is also why Yahweh is described as a "devouring fire." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

##### Links: #####

* __[Exodus 24:01 Notes](./01.md)__

__[<<](../23/intro.md) | [>>](../25/intro.md)__


## Exodus 25

### Exodus 25:01

#### who is motivated by a willing heart

This is an idiom that indicates a person's desire to give an offering. AT: "who wants to give an offering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### You must receive

The word "you" refers to Moses and the leaders. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]

### Exodus 25:03

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### blue, purple, and scarlet material

Possible meanings are 1) "material that is dyed blue, purple, and scarlet," probably wool yarn, or 2) "blue, purple and scarlet dye" to dye the linen.

#### scarlet

"red"

#### sea cow

a large animal that lives in the sea and eats plants

#### spices

dried plants that people grind into a powder and put in oil or food to give it a nice smell or flavor (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### onyx

a valuable stone that has layers of white and black, red or brown. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### precious stones to be set

This can be stated in active form. AT: "precious stones for someone to set" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### precious stones

"valuable gems" or "treasured gems"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]

### Exodus 25:08

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### sanctuary ... tabernacle

Here these words mean the same thing.

#### You must make it

Here "you" is plural and refers to Moses and the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### show you in the plans

"show you in the design" or "show you in the pattern." Here "you" is singular and refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 25:10

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### two and a half cubits ... one cubit and a half

A cubit is 46 centimeters. AT: "2.5 cubits ... 1.5 cubits" or "115 centimeters ... almost 69 centimeters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 25:12

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### cast four rings of gold

Casting was a process in which gold was melted, poured into a mold that was in the shape of a ring, and then allowed to harden.

#### in order to carry the ark

"so that you can carry the ark"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]

### Exodus 25:15

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made.

#### two and a half cubits ... a cubit and a half

A cubit is 46 centimeters. AT: "2.5 cubits ... 1.5 cubits" or "115 centimeters ... 69 centimeters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### hammered gold

"beaten gold"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]

### Exodus 25:19

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made. See how you translated this in [Exodus 25:17](./15.md).

#### They must be made

This can be stated in active form. AT: "You must make them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### You must put

Here "you" refers to Moses and the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]

### Exodus 25:22

#### General Information:

Yahweh continues to speak to Moses.

#### It is at the ark that I will meet with you

"I will meet with you at the ark." In 25:22 the word "you" is singular and refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made. See how you translated this in [Exodus 25:17](./15.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 25:23

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### two cubits ... one cubit ... a cubit and a half

A cubit is 46 centimeters. AT: "2 cubits ... 1 cubit ... 1.5 cubits" or "92 centimeters ... 46 centimeters ... 69 centimeters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 25:25

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### one handbreadth wide

a measurement of 7 to 8 centimeters

#### frame for it

"frame for the table"

#### feet were

"legs are"

#### The rings must be attached

This can be stated in active form. AT: "You must attach the rings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in order to carry

"so you can carry"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 25:28

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### so that the table may be carried with them

This can be stated in active form. AT: "so that you may carry the table with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to be used to pour out drink offerings

This can be stated in active form. AT: "so that you may use them to pour out drink offerings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### bread of the presence

This bread represented the presence of God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Exodus 25:31

#### hammered gold

"beaten gold." See how you translated this in [Exodus 25:18](./15.md).

#### The lampstand is to be made

This can be stated in active form. AT: "Make the lampstand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Its cups, its leafy bases, and its flowers are to be all made of one piece with it

This can be stated in active form. AT: "Make its cups, its leafy bases, and its flowers all of one piece with the lampstand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 25:33

#### General Information:

Yahweh continues telling Moses what the people must do. Yahweh is describing the lampstand. (See: [Exodus 25:31-32](./31.md))

#### almond blossoms

white or pink flowers that have five petals

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]

### Exodus 25:35

#### General Information:

Yahweh continues telling Moses what the people must do. Yahweh is describing the lampstand. (See: [Exodus 25:31-32](./31.md))

#### made as one piece with it

This can be stated in active form. AT: "you must make them as one piece with the lampstand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 25:37

#### General Information:

Yahweh continues telling Moses what the people must do.

#### for them to give light from it

"so they shine light from it"

#### The tongs and their trays must be made of pure gold

This can be stated in active form. AT: "Make the tongs and their trays of pure gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### one talent

A talent weighs about thirty-three kilograms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### its accessories

the tongs and the trays

#### you are being shown on the mountain

This can be stated in active form. AT: "I am showing you on the mountain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 25:intro

#### Exodus 25 General Notes ####

####### Special concepts in this chapter #######

######## The tent of meeting ########
This chapter gives specific instructions regarding the building of a tent where Moses would meet Yahweh and the ark would be stored. This would eventually become the tabernacle. It was to be considered a very holy place. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

##### Links: #####

* __[Exodus 25:01 Notes](./01.md)__

__[<<](../24/intro.md) | [>>](../26/intro.md)__


## Exodus 26

### Exodus 26:01

#### General Information:

Yahweh continues telling Moses what the people must do. (See: [Exodus 25:1](../25/01.md))

#### You must make

Yahweh is speaking to Moses, so the word "you" is singular. Yahweh probably expected Moses to tell someone else to do the actual work, but Moses would be the one responsible for seeing that the work was done correctly. "Tell a craftsman to make" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### curtains

These were large, heavy sections of woven cloth that were used to form the covering and dividing walls of the tabernacle.

#### scarlet wool

wool dyed a deep red color

#### craftsman

a person who is skilled in making beautiful objects by hand

#### twenty-eight cubits ... four cubits

"28 cubits ... 4 cubits." A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Five curtains must be joined to each other ... must also be joined to each other

This can be stated in active form. AT: "Sew five curtains together to make one set, and sew the other five curtains together to make another set" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 26:04

#### loops ... clasps

The clasps fit into the loops to hold the curtains together.

#### one set

"one set of five curtains"

#### the second set

"the second set of five curtains"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 26:07

#### General Information:

Yahweh continues telling Moses what the people must do.

#### eleven ... thirty ... four

"11 ... 30 ... 4" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### cubits

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 26:10

#### General Information:

Yahweh continues telling Moses what the people must do.

#### loops ... clasps

The clasps fit into the loops to hold the curtains together. See how you translated these in [Exodus 26:4-6](./04.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 26:12

#### General Information:

Yahweh continues telling Moses what the people must do.

#### cubit

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### dyed

"colored"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Exodus 26:15

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### frames

This refers to frames or panels that they made by joining together smaller pieces of wood.

#### ten cubits ... one and a half cubits

"10 cubits ... 1.5 cubits" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 26:19

#### General Information:

Yahweh continues telling Moses what the people must do.

#### silver bases

These were silver blocks that had a slot in them to keep the board in place.

#### pedestals

The silver bases kept the wooden board off the ground.

#### There must be two bases

This can be stated in active form. AT: "Put two bases" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### and so on

This means that what was said about the first two boards should be done for the rest of the boards. This can be stated clearly in the translation. AT: "and two bases for each of the rest of the boards" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 26:22

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### These frames must be separate at the bottom, but joined at the top

This can be stated in active form. AT: "Separate these frames at the bottom, but join them at the top" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### silver bases

These were silver blocks that had a slot in them to keep the frame in place. See how you translated this in [Exodus 26:19](./19.md).

#### in all

"total"

#### and so on

This means that what was said about the first two frames should be done for the rest of the frames. See how you translated this in [Exodus 26:21](./19.md). AT: "and two bases for each of the rest of the frames" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Exodus 26:26

#### General Information:

Yahweh continue to tell Moses how the tabernacle was to be built.

#### crossbars

These are horizontal support beams that give stability to the structure.

#### the back side of the tabernacle to the west

The front was on the east side of the tabernacle.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 26:29

#### General Information:

Yahweh continues to tell Moses how the tabernacle must be constructed.

#### for them to serve as holders for the crossbars

"which will hold the crossbars" or "because they will hold the crossbars"

#### crossbars

These are horizontal support beams that give stability to the structure. See how you translated this in [Exodus 26:26](./26.md).

#### you were shown on the mountain

This can be stated in active form. AT: "that I have shown you here on this mountain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 26:31

#### General Information:

Yahweh continues to tell Moses how the tabernacle is to be constructed.

#### You must make

Yahweh is speaking to Moses, so the word "you" is singular. Yahweh probably expected Moses to tell someone else to do the actual work, but Moses would be the one responsible for seeing that the work was done correctly. "Tell a craftsman to make." See how you translated this in [Exodus 26:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### clasps

The clasps fit into the loops to hold the curtains together. See how you translated these in [Exodus 26:4-6](./04.md).

#### you must bring in the ark of the testimony

The ark of the testimony is the chest that contains the commandments. This can be stated clearly in the translation. AT: "you must bring in the chest containing the commandments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The curtain is to separate the holy place

This can be stated in active form. AT: "The curtain will separate the holy place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]

### Exodus 26:34

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made. See how you translated this in [Exodus 25:17](../25/15.md).

#### on the ark of the testimony

"on the chest that contains the commandments"

#### The table must be on the north side

This is the table that holds the bread that represents the presence of God. This can be stated in active form. AT: "Place the table for the bread of God's presence on the north side" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 26:36

#### General Information:

Yahweh continues to tell Moses how to construct the tabernacle.

#### a hanging

This was a large curtain made of cloth.

#### blue, purple, and scarlet material

Possible meanings are 1) "yarn that is dyed blue, purple, and scarlet," probably wool yarn, or 2) "blue, purple, and scarlet dye" to dye the linen. See how you translated this in [Exodus 25:4](../25/03.md).

#### fine twined linen

"finely twisted linen." This was cloth made from fine linen threads that someone twisted together to make a stronger thread.

#### an embroiderer

"a person who sews designs into cloth" or "a person who embroiders"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 26:intro

#### Exodus 26 General Notes ####

####### Structure and formatting #######

This chapter is a continuation of the material in the previous chapter.

####### Special concepts in this chapter #######

######## The tent of meeting ########
This chapter gives specific instructions regarding the building of a tent where Moses would meet Yahweh and the ark would be stored. This would eventually become the tabernacle. It was to be considered a very holy place. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

##### Links: #####

* __[Exodus 26:01 Notes](./01.md)__

__[<<](../25/intro.md) | [>>](../27/intro.md)__


## Exodus 27

### Exodus 27:01

#### General Information:

Yahweh continues to tell Moses what the people must do. (See: [Exodus 25:1](../25/01.md))

#### five cubits long and five cubits wide

"2.2 meters long on each side" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### The altar must be square and three cubits high

"The altar must be square and 1.3 meters high" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### cubits

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### You must make extensions of its four corners shaped like ox horns

"You must make projections that look like ox horns on its four corners"

#### The horns will be made

This can be stated in active form. AT: "You must make the horns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### must cover them

"must cover the altar and horns"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 27:03

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### basins

"bowls"

#### firepans

There were pans that held hot coals from the altar.

#### utensils

These were any instrument, vessel, or tool that served a useful purpose.

#### You must make a grate for the altar, a network of bronze

"You must make a bronze grate for the altar"

#### grate

a frame of crossed bars for holding wood when burning

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 27:05

#### General Information:

Yahweh continues to tell Moses what the people need to do.

#### You must put the grate under the ledge of the altar

The grate was placed inside the altar. This can be stated clearly in the translation. AT: "You must put the grate under the rim of the altar, on the inside of the altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### grate

This is a frame of crossed bars for holding wood when burning. See how you translated this in [Exodus 27:4](./03.md).

#### You must make poles for the altar

These poles were used for carrying the altar. This can be stated clearly in the translation. AT: "You must make poles for carrying the altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 27:07

#### General Information:

Yahweh continues to tell Moses what the people should do.

#### The poles must be put into the rings, and the poles must be on the two sides of the altar, to carry it

This can be stated in active form. AT: "You must put the poles into the rings and place them on each side of the altar to carry it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### planks

a long, flat piece of wood that is thicker than a board

#### you were shown on the mountain

This can be stated in active form. AT: "that I have shown to you here on this mountain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Exodus 27:09

#### There must be hangings ... courtyard

This can be stated in active form. AT: "You must place hangings ... courtyard" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### hangings of fine twined linen

A "hanging" was a large curtain made of cloth. See how you translated this in [Exodus 26:36](../26/36.md)

#### fine twined linen

"finely twisted linen." This was cloth made from fine linen threads that someone twisted together to make a stronger thread

#### one hundred cubits

A cubit is 46 centimeters. AT: "44 meters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### There must also be hooks ... posts

This can be stated in active form. AT: "You must also attach hooks ... posts" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### posts

a strong piece of wood set upright and used as a support

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]

### Exodus 27:11

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### Likewise ... silver rods

For 27:11 see how you translated many similar words in [Exodus 27:9-10](./09.md).

#### there must be hangings

This could be stated as a command. AT: "you must make hangings"

#### there must be a curtain

This could be stated as a command. AT: "you must make a curtain"

#### There must be ten posts

This could be stated as a command. AT: "You must make ten posts"

#### The courtyard must also be fifty cubits long

This could be stated as a command. AT: "Make the courtyard fifty cubits long"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]

### Exodus 27:14

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### The hangings

These were large curtains made of cloth. See how you translated this in [Exodus 26:36](../26/36.md).

#### posts

These were strong pieces of wood set upright and used as supports. See how you translated these in [Exodus 27:10](./09.md).

#### bases

These were metal blocks that had a slot in them to keep the board in place. See how you translated this in [Exodus 26:19](../26/19.md).

#### fifteen cubits

about seven meters (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### The courtyard gate must be a curtain twenty cubits long

This could be stated as a command. AT: "You must make a curtain twenty cubits long to be the courtyard gate"

#### The curtain must be made ... fine twined linen, the work of an embroiderer

This can be stated in active form. AT: "They must make the curtain ... fine twined linen, the work of an embroiderer" or "Embroiderers must make the curtain ... fine twined linen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### blue, purple, and scarlet material and fine twined linen

Possible meanings are 1) "yarn that is dyed blue, purple, and scarlet," probably wool yarn, or 2) "blue, purple, and scarlet dye" to dye the linen.

#### an embroiderer

a person who sews designs into cloth

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 27:17

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### one hundred cubits

"100 cubits." A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### fine twined linen hangings

"finely twisted linen." This was cloth made from fine linen threads that someone twisted together to make a stronger thread. See how you translated this in [Exodus 26:36](../26/36.md).

#### all the tent pegs for the tabernacle and courtyard must be made of bronze

This can be stated in active form. AT: "make all the tent pegs for the tabernacle and courtyard out of bronze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### tent pegs

sharp pieces of wood or metal used to secure the corners of a tent to the ground

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]

### Exodus 27:20

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### tent of meeting

This is another name for the tabernacle.

#### ark of testimony

This is the chest that contains the sacred slabs of stone on which Yahweh had written his commandments.

#### This requirement will be a lasting ordinance

"I require that the people do this as a lasting ordinance"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordinance.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordinance.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Exodus 27:intro

#### Exodus 27 General Notes ####

####### Structure and formatting #######

This chapter is a continuation of the material in the previous chapter.

####### Special concepts in this chapter #######

######## The tent of meeting ########
This chapter gives specific instructions regarding the building of a tent where Moses would meet Yahweh and the ark would be stored. This would eventually become the tabernacle. It was to be considered a very holy place. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

##### Links: #####

* __[Exodus 27:01 Notes](./01.md)__

__[<<](../26/intro.md) | [>>](../28/intro.md)__


## Exodus 28

### Exodus 28:01

#### General Information:

Yahweh continues telling Moses what the people must do. (See: [Exodus 25:1](../25/01.md))

#### Call to yourself

Here "yourself" refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Nadab, Abihu, Eleazar, and Ithamar

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### You must make

Here "you" refers to the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### garments that are set apart to me

This can be stated in active form. AT: "garments that you will set apart to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/filled.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/filled.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]

### Exodus 28:04

#### General Information:

Yahweh continues telling Moses what the people must do.

#### a coat of woven work

"a coat with a design woven into it"

#### turban

a tall head covering made from cloth wrapped around the head several times.

#### sash

a piece of cloth that people wear around their waist or across their chest

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Exodus 28:06

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### fine-twined linen

"finely-twisted linen." This was cloth made from fine linen threads that someone twisted together to make a stronger thread. See how you translated this in [Exodus 26:36](../26/36.md).

#### skillful craftsman

a person who can make beautiful objects by hand

#### it must be made of one piece

This can be stated in active form. AT: "they must make it in one piece" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### onyx stones

These are valuable stones that have layers of white and black, red or brown. See how you translated this in [Exodus 25:7](../25/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 28:10

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### With the work of an engraver in stone, like the engraving on a signet

"In the same way a person engraves on a seal"

#### engraver

a person who cuts designs into a hard material such as wood, stone, or metal

#### signet

an engraved stone used to stamp a design into a wax seal

#### settings

pieces of metal that hold the stone onto the ephod

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]

### Exodus 28:13

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### settings

These are pieces of metal that hold each stone onto the ephod. See how you translated this in [Exodus 28:11](./10.md).

#### two braided chains of pure gold like cords

"two chains of pure gold that are braided like cords"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]

### Exodus 28:15

#### General Information:

Yahweh continues telling Moses what the people must do.

#### the work of a skillful workman, fashioned like the ephod

"a skillful workman will make it like the ephod"

#### span

A span is 22 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 28:17

#### General Information:

Twelve kinds of stone are listed here. Scholars are not sure which kinds of stones the Hebrew words refer to. Some translations list different stones.

#### precious stones

"valuable gems" or "treasured gems." See how you translated these in [Exodus 25:7](../25/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### ruby ... jasper

These are precious stones. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### sapphire

This is a gemstone that is blue in color. See how you translated this in [Exodus 24:10](../24/09.md).

#### onyx

This is a valuable stone that has layers of white and black, red or brown. See how you translated these in [Exodus 25:7](../25/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### They must be mounted in gold settings

This can be stated in active form. AT: "You must mount them in gold settings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 28:21

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### The stones must be arranged

This can be stated in active form. AT: "You must arrange the stones" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### signet ring

A signet is an engraved stone used to stamp a design into a wax seal. Here the stone is mounted on a ring. See how you translated "signet" in [Exodus 28:11](./10.md).

#### chains like cords, braided work of pure gold

"chains that are made of pure gold and are braided like cords." See how you translated similar phrases in [Exodus 28:14](./13.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 28:25

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### braided chains

"chains braided like cords." See how you translated this in [Exodus 28:14](./13.md).

#### to the two settings

These are two settings that enclose the stones. This can be clearly stated in the translation. AT: "to the two settings that enclose the stones" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]

### Exodus 28:27

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### finely-woven waistband

This was a cloth belt made from narrow linen threads that someone twisted together to make a stronger thread. See how you translated this in [Exodus 28:8](./06.md).

#### so that it might be attached

This can be stated in active form. AT: "so that they may attach it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the breastpiece might not become unattached from the ephod

This can be stated in positive form. AT: "the breastpiece would stay attached to the ephod" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]

### Exodus 28:29

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### he must carry the names of the people of Israel over his heart in the breastpiece

This refers to the names of the tribes engraved on the twelve stones the breastplate as described in [Exodus 28:17-21](./17.md).

#### over his heart

"over Aaron's heart" or "on his chest"

#### the Urim and the Thummim ... the means for making decisions

The second phrase appears to refer to the Urim and Thummim and explain their purpose.

#### the Urim and the Thummim

It not clear what these are. They were objects, possibly stones, that the priest used to determine somehow the will of God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 28:31

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### This must be the work of a weaver

This can be stated as a command. AT: "A weaver must make this robe"

#### a weaver

"a person who weaves" or "a person who creates cloth using thread"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]

### Exodus 28:33

#### General Information:

Yahweh continues to tell Moses what the people do.

#### pomegranates

A pomegranate is a round fruit with a red outer skin. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### a golden bell and a pomegranate

This phrase is repeated to show the pattern of the design on the robe.

#### The robe is to be on Aaron when he serves

This can be stated in active form. AT: "Aaron must wear the robe when he serves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### so that its sound can be heard

This can be stated in active form. AT: "so that the bells make a sound" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### This is so that he does not die

It is implied that he would die because he did not obey Yahweh. This can be stated. AT: "As a result, he will not die because of disobeying my instructions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 28:36

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### engrave on it, like the engraving on a signet

"write on it in the same way a person engraves on a seal." See how you translated similar words in [Exodus 28:11](./10.md)

#### turban

This was a tall head covering made from cloth wrapped around the head several times. See how you translated this in [Exodus 28:4](./04.md).

#### It must be on Aaron's forehead

This can be stated in active form. AT: "Aaron must wear it on his forehead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The turban must be always on his forehead

This can be stated in active form. AT: "Aaron must always wear the turban on his forehead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 28:39

#### General Information:

God continues to tell Moses what the people must do.

#### turban

This was a tall head covering made from cloth wrapped around the head several times. See how you translated this in [Exodus 28:4](./04.md).

#### sash

A sash is a decorative piece of cloth that a person wears around his waist or across his chest. See how you translated this in [Exodus 28:4](./04.md).

#### the work of an embroiderer

An embroiderer is a person who sews designs into cloth. See how you translated this in [Exodus 26:36](../26/36.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 28:40

#### General Information:

God continues to tell Moses what the people must do.

#### sashes

A sash is a decorative piece of cloth that a person wears around his waist or across his chest. See how you translated this in [Exodus 28:4](./04.md).

#### headbands

A headband is a narrow, decorative strip of cloth that is worn around the head above the eyes.

#### You must clothe Aaron your brother

Aaron was the older brother of Moses. You can state this clearly in the translation. AT: "Put these clothes on your older brother Aaron" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Exodus 28:42

#### General Information:

God continues to tell Moses what the people must do.

#### undergarments

These are underwear, clothing worn under the outer clothes, next to the skin.

#### tent of meeting

This is another name for the tabernacle. See how you translated this in [Exodus 27:21](../27/20.md).

#### a permanent law

"a law the will not end"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Exodus 28:intro

#### Exodus 28 General Notes ####

####### Special concepts in this chapter #######

######## Holy garments ########
Because Yahweh is holy, only the priests could approach him, and when they did they must be wearing specially made clothing. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

##### Links: #####

* __[Exodus 28:01 Notes](./01.md)__

__[<<](../27/intro.md) | [>>](../29/intro.md)__


## Exodus 29

### Exodus 29:01

#### Now

The word "now" marks a change in topic from garments for priests to consecrating priests.

#### you must do

Here "you" refers to Moses.

#### to set them apart

"to set apart Aaron and his sons"

#### serve me

Here "me" refers to Yahweh.

#### one young bull

a male cow

#### Also take wafers without yeast rubbed with oil

This can be stated in active form. AT: "Also take wafers without yeast and rub them with oil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### bread ... cakes ... wafers

These are different kinds of food made from flour.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]

### Exodus 29:03

#### General Information:

Yahweh continues to speak to Moses

#### You must put them

"You must put the bread, cake, and wafer"

#### present them with the bull and the two rams

Here "present" means to offer as a sacrifice. The full meaning of this can be translated clearly. AT: "offer them to me when you sacrifice the bull and the two rams" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### tent of meeting

This is another name for the tabernacle. See how you translated this in [Exodus 27:21](../27/20.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]

### Exodus 29:05

#### General Information:

Yahweh continues speaking to Moses.

#### coat

This was a coat with a design woven into it. See how you translated this in [Exodus 28:4](../28/04.md).

#### finely-woven waistband

This was a cloth belt made from narrow linen threads that someone twisted together to make a stronger thread. See how you translated this in [Exodus 28:8](../28/06.md).

#### turban

This was a tall head covering made from cloth wrapped around the head several times. See how you translated this in [Exodus 28:4](../28/04.md).

#### holy crown

This crown is described in [Exodus 29:6](./05.md) as being engraved with the words "dedicated to Yahweh" and made of pure gold.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]

### Exodus 29:08

#### General Information:

Yahweh continues speaking to Moses.

#### bring his sons

"bring Aaron's sons"

#### coats

These were coats with a design woven into them. See how you translated this in [Exodus 28:4](../28/04.md).

#### sashes

A sash is a decorative piece of cloth that people wear around their waist or across their chest. See how you translated this word in [Exodus 28:4](../28/04.md).

#### headbands

A headband is a narrow, decorative strip of cloth that is worn around the head above the eyes. See how you translated this in [Exodus 28:40](../28/40.md).

#### The work of the priesthood

"the duty of being priests"

#### will belong to them

The duty of being priests will also belong to the descendants of Aaron's sons. You can state this clearly in the translation. AT: "will belong to them and their descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### permanent law

"a law the will not end." See how you translated this in [Exodus 28:43](../28/42.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Exodus 29:10

#### General Information:

Yahweh continues speaking to Moses.

#### tent of meeting

This is another name for the tabernacle. See how you translated this in [Exodus 27:21](../27/20.md).

#### You must kill the bull

The bull offering was to be killed by Moses, not the priests, at the doorway, not inside the tent of meeting.

#### kill the bull

Since the following verses will tell what to do with the blood from the bull, use a term for "kill" that will imply a method similar to "slitting its throat and catch the blood in a bowl." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 29:12

#### General Information:

Yahweh continues speaking to Moses.

#### the horns

These were projections that looked like ox horns attached to the four corners of the altar. See how you translated this in [Exodus 27:2](../27/01.md).

#### the rest of the blood

"the remaining blood"

#### covers the inner parts

"covers the organs"

#### liver ... kidneys

These are organs in the body.

#### But as for the bull's flesh, as well as its skin and dung

"But as for the remaining parts of the bull"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md)]]

### Exodus 29:15

#### You must kill the ram

For these consecration sacrifices for the priests, it was Moses, not Aaron or his sons, who had to kill the animals.

#### on the altar

Unlike the bull offering that was burned outside of the tent, the ram was to be burned on the inner altar.

#### the inner parts

"the organs." See how you translated this in [Exodus 29:13](./12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 29:19

#### General Information:

Yahweh continues speaking to Moses.

#### Then you must kill the ram

The ram was killed by cutting its throat. This can be stated clearly in the translation. AT: "Then kill the ram by slitting its throat" or "Then kill the ram by cutting its throat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Exodus 29:21

#### General Information:

Yahweh continues speaking to Moses.

#### Aaron will then be set apart for me

This can be stated in active form. AT: "By doing this, you will dedicate Aaron to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]

### Exodus 29:22

#### General Information:

Yahweh continues speaking to Moses.

#### inner parts ... liver ... kidney

These refer to organs inside the body. See how you translated this in [Exodus 29:13](./12.md).

#### Take one loaf ... before Yahweh

For 29:23 see how you translated similar words in [Exodus 29:2](./01.md).

#### that is before Yahweh

"that you have placed before Yahweh"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 29:24

#### General Information:

God continues speaking to Moses.

#### You must put these

Here "these" refers to the parts of the sacrifice mentioned in the previous verses.

#### it will be an offering made to me by fire

This can be stated in active form. AT: "burn it as an offering to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]

### Exodus 29:26

#### General Information:

Yahweh continues speaking to Moses.

#### ram of dedication

"ram that you dedicated" or "ram that you killed"

#### Aaron's ram of dedication

"the ram that you used to dedicate Aaron"

#### a perpetual ordinance

"a permanent law"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Exodus 29:29

#### General Information:

Yahweh continues speaking to Moses.

#### The holy garments of Aaron must also be reserved for his sons after him

These garments belong to the priesthood and are not just Aaron's personal clothing. AT: "Aaron must reserve the holy garments for his sons after him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They are to be anointed in them and ordained to me in them

This can be stated in active form. AT: "They must wear the holy garments when you anoint his sons and ordain them to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### tent of meeting

This is another name for the tabernacle. See how you translated this in [Exodus 27:21](../27/20.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ordain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]

### Exodus 29:31

#### General Information:

Yahweh continues speaking to Moses.

#### the ram for the installation of the priests

"the ram you killed when you installed the priests"

#### in a holy place

This is not the same as the holy place outside of the most holy place. This refers to a place within the courtyard. AT: "at the entrance to the tent of meeting" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### tent of meeting

This is another name for the tabernacle. See how you translated this in [Exodus 27:21](../27/20.md).

#### that were given

This can be stated in active form. AT: "that you sacrificed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### It must not be eaten

This can be stated in active form. AT: "No one must eat it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### because it has been set apart to me

This can be stated in active form. AT: "because you have set it apart to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 29:35

#### General Information:

Yahweh continues speaking to Moses.

#### In this way, by following all that I have commanded you to do, you must treat Aaron and his sons

"I have commanded you to treat Aaron and his sons this way"

#### Then the altar will be completely set apart to me

"Then the altar will be most holy"

#### will be set apart to Yahweh

"will also be very holy"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]

### Exodus 29:38

#### General Information:

Yahweh continues speaking to Moses.

#### You must regularly offer on the altar every day

"You must daily offer on the altar"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]

### Exodus 29:40

#### General Information:

Yahweh continues speaking to Moses.

#### a tenth ... the fourth part

"1/10 ... 1/4" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### ephah

An ephah is 22 liters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### hin

A hin is 3.7 liters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md)]]

### Exodus 29:41

#### General Information:

Yahweh continues speaking to Moses.

#### it will be an offering made to me by fire

This can be stated in active form. AT: "it will be a burnt offering to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### throughout your generations

"through all the generations of your descendants." See how you translated this in [Exodus 12:14](../12/12.md).

#### tent of meeting

This is another name for the tabernacle. See how you translated this in [Exodus 27:21](../27/20.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 29:43

#### General Information:

Yahweh continues speaking to Moses.

#### the tent will be set apart for me by my glory

This can be stated in active form. AT: "My awesome presence will dedicate the tent to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Exodus 29:45

#### General Information:

Yahweh continues speaking to Moses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 29:intro

#### Exodus 29 General Notes ####

####### Special concepts in this chapter #######

######## Consecrating priests ########
This chapter records the process of consecrating priests. The priests were to be set apart from the rest of Israel because Yahweh is holy. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

####### Other possible translation difficulties in this chapter #######

######## "I will live among the Israelites" ########
As God, Yahweh is everywhere and cannot be limited to a single space. This phrase indicates that he permanently remains within Israel in a special way while they have the ark. 

##### Links: #####

* __[Exodus 29:01 Notes](./01.md)__

__[<<](../28/intro.md) | [>>](../30/intro.md)__


## Exodus 30

### Exodus 30:01

#### General Information:

Yahweh tells Moses how to build the worship equipment.

#### You must make

Here "you" refers to Moses and the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### Its horns must be made

These were projections that looked like ox horns attached to the four corners of the altar. See how you translated "horns" in [Exodus 27:2](../27/01.md). AT: "You must make its horns" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]

### Exodus 30:03

#### General Information:

Yahweh continues telling Moses what the people must do.

#### the incense altar

"an altar to burn incense"

#### to be attached to it

This can be stated in active form. AT: "which you will attach to the altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 30:05

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### ark of the testimony

The ark is the chest that contains the commandments. This can be stated clearly in the translation. See how you translated this in [Exodus 26:33](../26/31.md). AT: "the chest containing the commandments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made. See how you translated this in [Exodus 25:17](../25/15.md).

#### where I will meet with you

Here "you" refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]

### Exodus 30:07

#### General Information:

Yahweh continues telling Moses what the people must do.

#### throughout your generations

"through all the generations of your descendants." See how you translated this in [Exodus 12:14](../12/12.md).

#### But you must offer

Though the word "you" is addressed to Moses, the instruction is given specifically to Aaron and his descendants as to when and what they are to offer on the altar of incense.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md)]]

### Exodus 30:10

#### General Information:

Yahweh continues speaking to Moses.

#### horns

These were projections that looked like ox horns attached to the four corners of the altar. See how you translated this in [Exodus 27:2](../27/01.md).

#### throughout your generations

"through all the generations of your descendants." See how you translated this in [Exodus 12:14](../12/12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 30:11

#### When you take

Possible meanings are 1) "you" refers to just Moses or 2) "you" refers to Moses and the leaders of Israel in future generations when they take a census. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### a census of the Israelites

The leaders only counted the Israelite men.

#### Everyone who is counted

This can be stated in active form. They counted only the men. AT: "Everyone you count" or "Every man you count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### half a shekel of silver

"1/2 a shekel of silver." Translators may use a unit of measure that people understand and a round number: "5.5 grams of silver" or "six grams of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### according to the weight of the shekel of the sanctuary

There were evidently shekels of more than one weight at the time. This specified which one was to be used.

#### twenty gerahs

"20 gerahs." A gerah is a unit that people used for measuring how much something very small weighed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### from twenty years old and up

Larger numbers are spoken of as being up or above smaller numbers. AT: "from twenty years old and more" or "who is twenty years old or older" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/census.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/census.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ransom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 30:15

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### the people

Only the men made this offering.

#### the half shekel

Translators may use a unit of measure that people understand and a round number: "the 5.5 grams of silver" or "the 6 grams of silver." See how you translated this in [Exodus 3:13](./11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### It must be a reminder to the Israelites before me, to make atonement for your lives

Possible meanings are 1) "It will remind the Israelites to make atonement for their lives" or 2) "It will remind the Israelites that they have made atonement for their lives."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]

### Exodus 30:17

#### You must also make

Here "you" refers to Moses and the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### basin

"bowl" or "tub"

#### a bronze stand

This is what the basin would be put on.

#### a basin for washing

This phrase explains what the priests were to use the large bronze basin for.

#### the altar

the altar of sacrifice

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Exodus 30:19

#### General Information:

Yahweh continues telling Moses what the people must do.

#### water in it

"water in the basin"

#### for Aaron and his descendants throughout their people's generations

"for Aaron and all the generations of his descendants." See how you translated a similar phrase in [Exodus 12:14](../12/12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Exodus 30:22

#### General Information:

Yahweh continues telling Moses what the people must do.

#### spices

dried plants that people grind into a powder and put in oil or food to give it a nice smell or flavor. See how you translated this in [Exodus 25:6](../25/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### five hundred shekels ... 250 shekels

"500 shekels ... two hundred and fifty shekels." A shekel is about 11 grams. Translators may use units that people know and round numbers: "5.7 kilograms ... 11.4 kilograms" or "six kilograms ... three kilograms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### cinnamon ... cane ... cassia

These are sweet spices. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### the weight of the shekel of the sanctuary

There were evidently shekels of more than one weight at the time. This specified which one was to be used. See how you translated this in [Exodus 30:13](./11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### one hin

Translators may use units that people know and round numbers: "3.7 liters" or "four liters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### with these ingredients

"with these items"

#### the work of a perfumer

Possible meanings are 1) Moses was to have a perfumer do the work or 2) Moses was to do the work himself the way a perfumer would do it.

#### a perfumer

a person who is skilled in mixing spices and oils

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]

### Exodus 30:26

#### General Information:

Yahweh continues speaking to Moses.

#### You must anoint

Here "you" refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### ark of the testimony

The ark is the chest that contains the commandments. This can be stated clearly in the translation. See how you translated this in [Exodus 26:33](../26/31.md). AT: "the chest containing the commandments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the altar for burnt offerings

"the altar on which offering were burnt"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ark.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ark.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]

### Exodus 30:29

#### General Information:

Yahweh continues speaking to Moses.

#### set them apart

This refers to the items listed in [Exodus 30:26-28](./26.md).

#### throughout your people's generations

"all the generations of your descendants." See how you translated this in [Exodus 12:14](../12/12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Exodus 30:32

#### General Information:

Yahweh continues telling Moses what Moses must tell the people.

#### It must not be applied to people's skin

This can be stated in active form. AT: "You must not put the anointing oil that is dedicated to Yahweh on a person's skin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### with the same formula

"with the same ingredients" or "with the same items"

#### that person must be cut off from his people

The metaphor "cut off" has at least three possible meanings. They can be expressed in active form: 1) "I will no longer consider him to be one of the people of Israel" 2) "the people of Israel must send him away" or 3) "the people of Israel must kill him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 30:34

#### General Information:

Yahweh continues to tell Moses what to do. Yahweh gives the commands only to Moses: all instances of "you" are singular. However, the words "blended by a perfumer" might mean that Moses could have the perfumer take the spices, blend them, grind them, and give them to Moses so Moses could put part of the mixture in front of the ark, as in UDB.

#### stacte, onycha, and galbanum

These are spices. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### Make it into the form of incense, blended by a perfumer

The phrase with "blended" can be translated in active form. AT: "Make it into the form of incense that a perfumer has blended" or "A perfumer must blend it into a kind of incense" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### blended by a perfumer

Possible meanings are 1) Moses was to have a perfumer do the work or 2) Moses was to do the work himself the way a perfumer would do it. See how you translated these words in [Exodus 30:25](./22.md).

#### You will grind it

"You will crush it." Here "you" refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### You will regard

Here "you" is plural and refers to Moses and all the people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ark.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ark.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]

### Exodus 30:37

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### you must not make any

The word "you" here refers to the people of Israel.

#### with the same formula

"with the same ingredients" or "with the same items." See how you translated this in [Exodus 30:32](./32.md).

#### It must be most holy to you

"You must consider it to be most holy"

#### perfume

This is a pleasant smelling liquid a person puts on his or her body.

#### must be cut off from his people

The metaphor "cut off" has at least three possible meanings. They can be expressed in active form: 1) "I will no longer consider him to be one of the people of Israel" 2) "the people of Israel must send him away" or 3) "the people of Israel must kill him." See how you translated this in [Exodus 30:33](./32.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 30:intro

#### Exodus 30 General Notes ####

####### Special concepts in this chapter #######

######## Atonement ########
The atonement offered by the priests was very important in the religious life of Israel. In order to offer sacrifices, the priests had to maintain ritual cleanliness by washing themselves. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]])

##### Links: #####

* __[Exodus 30:01 Notes](./01.md)__

__[<<](../29/intro.md) | [>>](../31/intro.md)__


## Exodus 31

### Exodus 31:01

#### I have called by name

God speaks of choosing specific people as calling them by name. AT: "I have chosen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Bezalel ... Uri ... Hur

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Exodus 31:03

#### General Information:

Yahweh continues speaking to Moses.

#### I have filled Bezalel with my Spirit

Yahweh speaks of giving Bezalel his Spirit as if Bezalel were a container and God's Spirit were a liquid. AT: "I have given my Spirit to Bezalel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for all kinds of craftsmanship

The abstract noun "craftsmanship" can be translated as "making crafts" or "making things." AT: "for making all kinds of crafts" or "so that he can make all kinds of things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/filled.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/filled.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 31:06

#### General Information:

Yahweh continues speaking to Moses.

#### Oholiab ... Ahisamak

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I have put skill into the hearts of all who are wise

God speaks of making people able to make things as if he were putting the ability into their hearts. AT: "I have given skill to all who are wise" or "I have made all who are wise able to make things well"

#### tent of meeting

This is another name for the tabernacle. See how you translated this in [Exodus 27:21](../27/20.md).

#### ark of the testimony

The ark is the chest that contains the commandments. This can be stated clearly in the translation. See how you translated this in [Exodus 26:33](../26/31.md). AT: "the chest containing the commandments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made. See how you translated this in [Exodus 25:17](../25/15.md).

#### incense altar

"altar to burn incense." See how you translated this in [Exodus 30:03](../30/03.md).

#### altar for burnt offerings

"altar on which offering were burnt." See how you translated this in [Exodus 30:28](../30/26.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]

### Exodus 31:10

#### General Information:

Yahweh continues speaking to Moses.

#### finely-woven garments

These were clothing made from narrow linen threads that someone twisted together to make a stronger thread. See how you translated a similar phrase in [Exodus 28:8](../28/06.md).

#### These craftsmen

"These people who are skilled in making beautiful things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 31:12

#### You must certainly keep Yahweh's Sabbath days

God speaks of obeying his instructions about the Sabbath as keeping the Sabbath. AT: "You must certainly obey Yahweh's instructions about the Sabbath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### throughout your people's generations

"through all the generations of your descendants." See how you translated this in [Exodus 12:14](../12/12.md).

#### who sets you apart for himself

God speaks of choosing people to be his as setting them apart for himself. AT: "who has chosen you to be his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for it must be treated by you as holy

This can be stated in active form. AT: "for you must treat it as holy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Everyone who defiles it

God speaks of treating the Sabbath with disrespect as defiling it. AT: "Everyone who treats the Sabbath with disrespect" or "Everyone who does not obey the laws about the Sabbath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### must surely be put to death

"must surely be killed." This can be stated in active form. AT: "you must surely kill" or "you must surely execute" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### must surely be cut off from his people

The metaphor "cut off" has at least three possible meanings. They can be expressed in active form: 1) "Yahweh will no longer consider him to be one of his people" 2) "you must surely send him away" or 3) "you must surely kill him." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### but the seventh day

"but day 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]

### Exodus 31:16

#### General Information:

Yahweh continues telling Moses what he must tell the people of Israel.

#### must keep the Sabbath

God speaks of obeying his instructions about the Sabbath as keeping the Sabbath. AT: "must obey Yahweh's instructions about the Sabbath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They must observe it throughout their people's generations

"They and all the generations of their descendants must observe it." See how you translated "throughout their people's generations" in [Exodus 12:42](../12/12.md).

#### permanent law

"a law the will not end." See how you translated this in [Exodus 28:43](../28/42.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]

### Exodus 31:18

#### written on by his own hand

This can be translated with an active verb. AT: "which Yahweh wrote on with his own hand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Exodus 31:intro

#### Exodus 31 General Notes ####

####### Structure and formatting #######

This chapter is the end of Exodus' recording of the law of Moses. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]) 

####### Special concepts in this chapter #######

######## Sabbath ########
As described in this chapter, the Sabbath is more than just a day of worship or celebration. Its significance extends beyond a way to help people rest. It is a major part of the identity of the Hebrew people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]])

##### Links: #####

* __[Exodus 31:01 Notes](./01.md)__

__[<<](../30/intro.md) | [>>](../32/intro.md)__


## Exodus 32

### Exodus 32:01

#### the people saw

Here understanding something is spoken of as if it were being seen. AT: "the people realized" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Come, make us an idol

The word "come" strengthens the force of the command following it. The people were demanding that Aaron make an idol for them.

#### go before us

"lead us" or "be our leader"

#### bring them to me

The word "them" refers to the golden rings.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 32:03

#### All the people

This refers to all the people who rejected Moses as their leader and Moses' God as their God.

#### fashioned it in a mold, and made it into a molded calf

Aaron melted the gold and poured it into a mold that had the shape of a calf. When the gold became hard, he removed the mold, and the hardened gold had the shape of a calf.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 32:05

#### When Aaron saw this

You may need to make explicit what he saw. "When Aaron saw what the people did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### to carouse in wild celebration

"to have a wild party." The people likely behaved in sexually immoral ways at the party.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fellowshipoffering.md)]]

### Exodus 32:07

#### left the way that I commanded them

Here God speaks of the people disobeying what he commanded them as if he had told them to walk on a certain road and they left that road. AT: "stopped doing what I commanded them to do" or "have stopped obeying what I commanded them to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They have molded for themselves a calf

"They have made a gold statue for themselves shaped like a calf"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Exodus 32:09

#### I have seen this people

Here Yahweh compares knowing the people to seeing them. AT: "I know this people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a stiff-necked people

Yahweh speaks of the people being stubborn as if they had stiff necks. AT: "a stubborn people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Now then

The word "now" is used here to mark a break in what Yahweh was telling Moses. Here Yahweh tells what he will do to the people.

#### My anger will burn hot against them

Yahweh speaks of his anger as if it were a fire that could burn hot. AT: "My anger towards them will be terrible" or "I am extremely angry with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from you

The word "you" refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### why does your anger burn against your people ... a mighty hand?

Moses used this question to to try to persuade Yahweh not to be so angry with his people. This rhetorical question can be translated as a statement. AT: "Do not let your anger burn against your people ... a mighty hand." or "Do not be so angry with your people ... a mighty hand." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### great power ... mighty hand

These two phrases share similar meanings and are combined for emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### a mighty hand

Here the word "hand" refers to the things Yahweh did. AT: "and the powerful things you did" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]

### Exodus 32:12

#### General Information:

Moses continues to reason with God not to destroy Israel.

#### Why should the Egyptians say, 'He led them out ... to destroy them from the face of the earth?'

Moses used this question to try to persuade God not to destroy his people. This rhetorical question can be translated with a statement. AT: If you destroy your people, the Egyptians might say, 'He led them out ... to destroy them from the face of the earth.' (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### face of the earth

"from the surface of the earth" or "from the earth"

#### Turn from your burning anger

"Stop your burning anger" or "Stop being so angry"

#### your burning anger

Moses speaks of God's anger as if it were a fire that was burning. AT: "your terrible anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Call to mind Abraham

"Remember Abraham" or "Think about Abraham"

#### swore

"made an oath" or "solemnly promised"

#### They will inherit it forever

God speaks about them possessing the land as if they would inherit it. AT: "They will possess it forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Exodus 32:15

#### tablets of the covenant decrees

These are the two stone slabs on which God had engraved his commandments.

#### The tablets were God's own work, and the writing was God's own writing

These two phrases share similar meanings. The second explains how the tablets were "God's own work." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]

### Exodus 32:17

#### he said to Moses

It is assumed that Joshua met Moses while Moses was going back to the camp. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 32:19

#### the tablets

"the two stone slabs that Yahweh had written on"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]

### Exodus 32:21

#### Then Moses said to Aaron, "What did this people ... a great sin on them?"

This can be stated as an indirect quote. AT: "Then Moses asked Aaron what the people do to him, that he have brought such a great sin on them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### you have brought such a great sin on them

Moses spoke of causing people to sin as if sin were an object and Aaron put it on them. AT: "you have caused them to sin so terribly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Do not let your anger burn hot

Aaron spoke of Moses' anger as if it were a fire that could burn. "Do not be so angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they are set on doing evil

Being determined to do evil is spoken of as being set on evil. AT: "they are determined to do what is evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this Moses

People showed disrespect by putting the word "this" before his name, as if Moses were someone they did not know and could not trust.

#### So I said to them, 'Whoever has any gold, let him take it off.'

This can be stated as an indirect quote. AT: "So I told them that whoever had any gold should take it off" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### I threw it into the fire, and out came this calf

Instead of taking ownership for making the calf, Aaron claims the calf came out of the fire supernaturally.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]

### Exodus 32:25

#### were running wild

"were behaving wildly" or "were not controlling themselves"

#### Then Moses stood at the entrance ... "Whoever is on Yahweh's side, come to me."

This can be stated as an indirect quote. AT: "Then Moses stood at the entrance to the camp and said that whoever was on Yahweh's side should come to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### Whoever is on Yahweh's side

Moses speaks of being loyal to Yahweh as being on Yahweh's side. AT: "Whoever is loyal to Yahweh" or "Whoever serves Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### go back and forth from entrance to entrance

"go from side of the camp to the other, starting at one entrance to the camp and going to the entrance on the other side of the camp"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]

### Exodus 32:28

#### three thousand of the people

"3000 of the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### You have been placed into Yahweh's service

This probably means "You have been chosen to serve Yahweh" or "You have become Yahweh's servants."

#### for each of you has taken action against his son and his brother

The fact that they did this in obedience to God can be stated clearly. AT: "for you have obeyed Yahweh and killed your sons and your brothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Exodus 32:30

#### You have committed a very great sin

They worshiped an idol.

#### Perhaps I can make atonement for your sin

Moses spoke of persuading God to forgive the people as if he could make atonement for their sin. AT: "Perhaps I can persuade Yahweh to forgive you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### blot me out of the book

The word "me" here refers to the name of Moses. AT: "erase my name from the book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the book that you have written

What God had written in the book can be stated clearly. AT: "the book in which you have written the names of your people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blotout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blotout.md)]]

### Exodus 32:33

#### that person I will blot out of my book

The phrase "that person" represents "that person's name." AT: "I will erase that person's name from my book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### my book

This refers to the book of Yahweh that Moses spoke of in [Exodus 32:32](./30.md).

#### But on the day that I punish them, I will punish them

On the day that God decides to punish them, it will be clear that it is God who is judging them.

#### Yahweh sent a plague on the people

This plague may have been a serious illness. AT: "Yahweh made the people very sick"

#### they had made the calf, the one that Aaron made

Even though Aaron made the calf, the people were also guilty because they told Aaron to do it. AT: "they told Aaron to make the calf"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blotout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/blotout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]

### Exodus 32:intro

#### Exodus 32 General Notes ####

####### Structure and formatting #######

The events of this chapter occur while Moses spoke with God and therefore happen at the same time as the events in chapters 20-31.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 32:18.

####### Special concepts in this chapter #######

######## Idolatry ########
The making of the golden calf was considered a form of idolatry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Exodus 32:01 Notes](./01.md)__

__[<<](../31/intro.md) | [>>](../33/intro.md)__


## Exodus 33

### Exodus 33:01

#### General Information:

Yahweh continues to tell Moses of his anger.

#### that land, which is flowing with milk and honey

The land was good for raising livestock and growing crops. See how you translated this in [Exodus 3:8](../03/07.md). AT: "a land that is excellent for raising livestock and growing crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### flowing with

"full of" or "with an abundance of"

#### milk

Since milk comes from cows and goats, this represents food produced by livestock. AT: "food from livestock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### honey

Since honey is produced from flowers, this represents food from crops. AT: "food from crops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a stubborn people

"people who refuse to change"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/isaac.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jacob.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md)]]

### Exodus 33:04

#### jewelry

beautiful clothing as well as chains and rings with jewels in them

#### a stubborn people

"people who refuse to change." See how you translated this in [Exodus 33:3](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/horeb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/horeb.md)]]

### Exodus 33:07

#### the pillar of cloud

The cloud had the shape of a pillar. See how you translated this in [Exodus 13:22](../13/19.md). AT: "the cloud shaped like a pillar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### would come down

Where it came down from can be stated clearly. AT: "would come down from the sky" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]

### Exodus 33:10

#### Yahweh would speak to Moses face to face

Speaking directly rather than through dreams and visions, is spoken of as if Moses and God saw each other's faces while they spoke. AT: "Yahweh would speak directly to Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### young man

old enough to be a soldier ([Exodus 17:9-10](../17/08.md)), but much younger than Moses

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]

### Exodus 33:12

#### See

"Look!" or "Listen!" or "Pay attention to what I am about to tell you"

#### I know you by name

To know someone by name is to know them well. AT: "I know you well" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you have also found favor in my eyes

Here "found favor" is an idiom that means be approved of or that God is pleased with Moses. Here "eyes" are a metonym for sight, and sight is a metaphor representing God's evaluation. AT: "I have evaluated you and approve" or "I am pleased with you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Now if I have found favor in your eyes

Here "found favor" is an idiom that means be approved of or that God is pleased with Moses. Here "eyes" are a metonym for sight, and sight is a metaphor representing God's evaluation. AT: "Now If you are pleased with me" or "Now if you approve of me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### show me your ways

Possible meanings: 1) "show me what you are going to do in the future" or 2) "show me how people can do what pleases you."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Exodus 33:14

#### My own presence will go

God's presence represents himself. AT: "I will go" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### go with you ... give you

The word "you" here refers to Moses. It is singular. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### I will give you rest

"I will let you rest"

#### For otherwise

"For if your presence does not go with us"

#### how will it be known

This can be expressed with an active form. AT: how will people know" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### how will it be known ... people?

Moses used this question in order to emphasize that if God does not go with them, no one will know that Moses had found favor in God's sight. AT: "no one will know ... people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will it not only be if

"Will it not only be known if"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Exodus 33:17

#### General Information:

When Yahweh uses the word "you" in this verse, it is singular and refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### you have found favor in my eyes

Here "found favor" is an idiom that means that God is pleased with Moses. Here "eyes" are a metonym for sight, and  sight is a metaphor representing his evaluation. See how you translated this in [Exodus 33:12](./12.md). AT: "I am pleased with you" or "I approve of you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I know you by name

To know someone by name is to know them well. See how you translated this in [Exodus 33:12](./12.md). AT: "I know you well" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Exodus 33:19

#### I will make all my goodness pass before you

God speaks of walking past Moses so that Moses can see his goodness as if only his goodness would go past Moses. AT: "I will move past you so that you may see my goodness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Exodus 33:21

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you."

#### you will see my back

This is because Yahweh will be walking away from Moses.

#### but my face will not be seen

This can be expressed in active form. AT: "but you will not see my face" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Exodus 33:intro

#### Exodus 33 General Notes ####

####### Special concepts in this chapter #######

######## Covenant ########
While the covenants Yahweh made may not be conditioned upon the obedience of Israel, it is clear that their conquering of the Promised Land was conditioned on their obedience to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

##### Links: #####

* __[Exodus 33:01 Notes](./01.md)__

__[<<](../32/intro.md) | [>>](../34/intro.md)__


## Exodus 34

### Exodus 34:01

#### tablets

"flat slabs of stone." See how you translated this in [Exodus 31:18](../31/18.md)

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]

### Exodus 34:03

#### General Information:

Yahweh continues speaking to Moses.

#### Do not let anyone else be seen anywhere on the mountain

Being seen doing something represents doing that. AT: "Do not let anyone else be anywhere on the mountain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### No flocks or herds are even to graze in front of the mountain

"Even flocks or herds are not allowed to come near the mountain to eat."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Exodus 34:05

#### stood with Moses there

"stood with Moses on the mountain"

#### he pronounced the name "Yahweh."

Possible meanings are 1) "he spoke the name 'Yahweh.'" or 2) "he proclaimed who Yahweh is." For the second meaning, "name" would represent who God is. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Yahweh, Yahweh, God is merciful and gracious

God is speaking about himself. AT: "I, Yahweh, am God, and I am merciful and gracious" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### abounding in covenant faithfulness and trustworthiness

"always showing covenant faithfulness and trustworthiness"

#### abounding in covenant faithfulness and trustworthiness

The abstract nouns "faithfulness" and "trustworthiness" can be stated as "faithful" and "trustworthy." AT: "always being faithful to my covenant and always being trustworthy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### keeping covenant faithfulness for thousands of generations

The abstract noun "faithfulness" can be stated as "faithfully" or "faithful." See how you translated a similar phrase in [Exodus 20:6](../20/04.md). AT: "faithfully loving thousands of generations" or "faithful to his covenant with thousands of generation" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### But he will

Yahweh is speaking about himself. AT: "But I will" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### he will by no means clear the guilty

Yahweh is speaking about himself. AT: "I will by no means clear the guilty" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### will by no means clear the guilty

"will certainly not clear the guilty" or "will certainly not say that the guilty are innocent" or "will certainly not free guilty people"

#### He will bring the punishment for the fathers' sin on their children

Punishing people is spoken of as if punishment were an object that someone could bring on people. AT: "He will punish the children for their fathers' sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their children

The word "children" represents descendants. AT: "their descendants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/transgression.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/guilt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]

### Exodus 34:08

#### If now I have found favor in your eyes

Here "found favor" is an idiom that means be approved of or that God is pleased with Moses. Here "eyes" are a metonym for sight, and  sight is a metaphor representing his evaluation. See how you translated this in [Exodus 33:12](../33/12.md). AT: "Now If you are pleased with me" or "Now if you approve of me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### our iniquity and our sin

The words "iniquity" and "sin" mean basically the same thing and are combined for emphasis. AT: "all our sins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### take us as your inheritance

Something that someone possesses forever is spoken of as if it were something that they had inherited. AT: "take us as the people that you possess forever" or "accept us as the people who belong to you forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]

### Exodus 34:10

#### your people

Here "your" refers to Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### it is a fearful thing that I am doing with you

A fearful thing is a thing that causes people to be afraid. In this case, people will fear God when they see what he does. AT: "what I do for you will cause people to fear me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I am doing with you

Here "you" refers to Moses and the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]

### Exodus 34:12

#### General Information:

Yahweh continues speaking to Moses. Here he tells him what Moses and the people must do.

#### they will become a trap among you

People who tempt others to sin are spoken of as if they were a trap. AT: "they will tempt you to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh, whose name is Jealous

The word "Jealous" here means that God is concerned to keep his honor. If his people worship other gods, he loses honor, because when his people do not honor him, other people also will not honor him. AT: "I, Yahweh, always guard my honor" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### whose name is Jealous,

The word "name" here represents God's character. AT: "I, Yahweh, who am always jealous" or "I, Yahweh, am always jealous" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Exodus 34:15

#### Connecting Statement:

Yahweh continues to tell Moses how his people are to behave towards outsiders.

#### for they prostitute themselves to their gods

God speaks of people worshiping other gods as if they were prostitutes going to other men. AT: "for they worship other gods" or "because they worship other gods like prostitutes who go to other men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you will eat some of his sacrifice

The consequence of eating food that is sacrificed to another god can be stated clearly. AT: "you will eat some of his sacrifice and become guilty of worshiping his gods" or "and you will prostitute yourself to his god by eating some of his sacrifice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 34:18

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### seven days

"7 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### in the month of Aviv

This is the name of the first month of the Hebrew calendar. Aviv is during the last part of March and the first part of April on Western calendars. See how you translated "Aviv" in [Exodus 13:4](../13/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]

### Exodus 34:19

#### General Information:

Yahweh continues telling Moses what the people must do.

#### buy back

Firstborn sons and firstborn donkeys belonged to Yahweh, but Yahweh did not want them sacrificed to Him. Instead, the Israelites were to sacrifice a lamb in their place. This allowed the Israelites to buy the donkeys and sons back from Yahweh.

#### No one may appear before me empty-handed

God speaks of the offering as if the person was to carry it in his hands. AT: "No one may come to me without an offering" or "Everyone who comes to me must bring me an offering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]

### Exodus 34:21

#### General Information:

Yahweh continues telling Moses what the people must do.

#### Even at plowing time and in harvest

"Even when you are preparing the soil or gathering the crops"

#### Festival of Ingathering

This festival was also known as the Festival of Shelters or the Festival of Booths. The idea came from the practice of the farmers living in temporary booths, or huts, out in the fields to guard the crop as it ripened. The word "Ingathering" means when they harvest their crop.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pentecost.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pentecost.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]

### Exodus 34:23

#### General Information:

Yahweh continues telling Moses what the people must do.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Exodus 34:25

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### the blood of my sacrifice

The fact that the blood is from an animal can be stated clearly. AT: "the blood of an animal that you sacrifice to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### with any yeast

The fact that any yeast would be in bread can be stated clearly. AT: "with bread that has yeast in it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/yeast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/passover.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]

### Exodus 34:27

#### Moses was there

"Moses was on the mountain"

#### forty days

"40 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### for forty days and nights

"for forty days, both day and night"

#### He wrote

"Moses wrote"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tencommandments.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tencommandments.md)]]

### Exodus 34:29

#### had become radiant

"had started to shine"

#### came up to him

"approached him" or "went to him." They did not go up the mountain.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]

### Exodus 34:32

#### all the commands that Yahweh had given him

Telling commands is spoken of as if the commands were objects that could be given. AT: "all the commands that Yahweh had told him" or "everything that Yahweh had commanded them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md)]]

### Exodus 34:34

#### he would remove

"Moses would remove"

#### what he was commanded

This can be stated in active form. AT: "what Yahweh had commanded him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/veil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Exodus 34:intro

#### Exodus 34 General Notes ####

####### Other possible translation difficulties in this chapter #######

######## "He will bring the punishment for the fathers' sin on their children" ########
This phrase does not mean that a child is necessarily punished for the sins of their parents. Many scholars believe that this passage indicates that a parent's sins will have consequences that will affect their children and grandchildren. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Exodus 34:01 Notes](./01.md)__

__[<<](../33/intro.md) | [>>](../35/intro.md)__


## Exodus 35

### Exodus 35:01

#### the seventh day

"day number seven" or "Saturday" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Whoever does any work on that day must be put to death

This can be stated in active form. AT: "You must kill anyone who does work on that day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Exodus 35:04

#### General Information:

Moses tells the Israelites to make the things Yahweh commanded him in [Exodus 25:3-7](../25/03.md).

#### Take an offering for Yahweh

"Take up a collection for Yahweh"

#### all of you who have a willing heart

Here "heart" refers to the person bringing the offering. AT: "everyone who is willing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]

### Exodus 35:10

#### General Information:

Moses continues telling the people what God commanded them to do.

#### Every skilled man

"Every man with a skill"

#### clasps

The clasps fit into the loops to hold the curtains together. See how you translated these in [Exodus 26:4-6](../26/04.md).

#### bases

These are heavy objects that rest on the ground and keep the object attached to them from moving. See how you translated this in [Exodus 25:31](../25/31.md).

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made. See how you translated this in [Exodus 25:17](../25/15.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]

### Exodus 35:13

#### They brought

"The people of Israel brought"

#### bread of the presence

This bread represented the presence of God. See how you translated this in [Exodus 25:30](../25/28.md).

#### bronze grate

This is a frame of crossed bronze bars for holding wood when burning. See how you translated "grate" in [Exodus 27:4](../27/03.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 35:17

#### hangings

These were large curtains made of cloth. See how you translated this in [Exodus 26:36](../26/36.md).

#### posts

These were strong pieces of wood set upright and used as supports. See how you translated these in [Exodus 27:10](../27/09.md).

#### bases

These were blocks that had a slot in them to keep the board in place. See how you translated this in [Exodus 26:19](../26/19.md).

#### tent pegs

sharp pieces of wood or metal used to secure the corners of a tent to the ground. See how you translated this in [Exodus 27:19](../27/17.md).

#### finely-woven garments

This was clothing made from narrow linen threads that someone twisted together to make a stronger thread. See how you translated this in [Exodus 28:8](../28/06.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Exodus 35:20

#### all the tribes of Israel

This refers to the people in the tribes. AT: "the people from all the tribes of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### whose heart stirred him up

Here "heart" refers to the person. The heart that responded to God is spoken of as if it were water stirred up by a storm. AT: "who responded to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### whom his spirit made willing

Here "spirit" refers to the person. AT: "who was willing" or "who wanted to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### all who had a willing heart

Here "heart" refers to the person. AT: "everyone who was willing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### brooches, earrings, rings, and ornaments

These are different kinds of jewelry.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 35:23

#### Everyone who had ... brought them

For 35:23 see how you translated many of these words in [Exodus 25:4-5](../25/03.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]

### Exodus 35:25

#### blue, purple, or scarlet wool

Possible meanings are 1) "material that is dyed blue, purple, and scarlet," probably wool yarn, or 2) "blue, purple and scarlet dye" to dye the linen. See how you translated a similar phrase in [Exodus 25:4](../25/03.md).

#### whose hearts stirred them up

Here "hearts" refers to the women. The hearts of the women who responded to God are spoken of as if they were water stirred up by a storm. AT: "who responded to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Exodus 35:27

#### The leaders brought ... Moses to be made

For 35:27-29 see how you translated many of these words in [Exodus 25:1-2](../25/01.md) and [Exodus 25:3-7](../25/03.md).

#### whose heart was willing

Here "heart" refers to the people. AT: "who was willing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 35:30

#### He has filled Bezalel with his Spirit

God's Spirit who gave Bezalel the ability to work is spoken of here as if he was something that filled up Bezalel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### design and craftsmanship

For 35:30-33 see how you translated these words in [Exodus 31:1-2](../31/01.md) and [Exodus 31:3-5](../31/03.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/filled.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/filled.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 35:34

#### General Information:

Moses continues speaking to the people.

#### He has put it in his heart to teach

Here "heart" refers to Bezalel. The ability to teach is spoken of as if it something that could be placed in a heart. AT: "He gave Bezalel the ability to teach" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### filled them with skill

Skill to create beautiful objects is spoken of as if it was something that could fill up a person. AT: "made them very skillful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Oholiab son of Ahisamak, from the tribe of Dan

"Oholiab" and "Ahisamak" are names of men. See how you translated these names in [Exodus 31:6](../31/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### engravers

a person who cuts designs into a hard material such as wood, stone, or metal

#### embroiderers

people who sew designs into cloth

#### craftsmen

people who are skilled in making beautiful objects by hand

#### weavers

a person who creates cloth using thread

#### artistic designers

a person who creates beauty with materials

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]

### Exodus 35:intro

#### Exodus 35 General Notes ####

####### Special concepts in this chapter #######

######## Sacrifice ########
All of the people offered sacrifices to Yahweh. This was a form of worship and a sign of repentance from making the golden calf idol. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]])

##### Links: #####

* __[Exodus 35:01 Notes](./01.md)__

__[<<](../34/intro.md) | [>>](../36/intro.md)__


## Exodus 36

### Exodus 36:01

#### General Information:

Moses continues speaking to the people.

#### Bezalel

This is the name of a man. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Oholiab

This is the name of a man. See how you translated this in [Exodus 31:6](../31/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### to whom Yahweh has given skill and ability

Here skill and ability are spoken of as if they are something that Yahweh can place inside a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### according to all that Yahweh has commanded

"just as Yahweh has commanded"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]

### Exodus 36:02

#### Bezalel

This is the name of a man. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Oholiab

This is the name of a man. See how you translated this in [Exodus 31:6](../31/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in whose mind Yahweh had given skill

Here "mind" refers to the person who was made skillful by Yahweh. AT: "to whom Yahweh had given skill" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### whose heart stirred within him

Here "heart" refers to the person. The heart that responded to God is spoken of as if it were water stirred up by a storm. AT: "who responded to God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/freewilloffering.md)]]

### Exodus 36:05

#### The craftsmen told Moses ... commanded us to do."

The can be stated as an indirect quote. AT: "The craftsmen told Moses that the people were bringing much more than enough for doing the work that Yahweh has commanded them to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### The craftsmen told Moses

"The men working on the sanctuary told Moses"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]

### Exodus 36:08

#### So all the craftsmen ... joined to each other

For 38:8-10 see how you translated many of these words in [Exodus 26:1-3](../26/01.md).

#### ten curtains made from fine linen

These curtains are sheets of cloth woven and sewed together so that they can hang to form a wall or tent.

#### Bezalel

This is the name of a man. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]

### Exodus 36:11

#### He made loops ... became united

For 36:11-13 see how you translated many of these words in [Exodus 26:4-6](../26/04.md).

#### loops of blue

loops of blue cloth

#### curtain

These were large, heavy sections of woven cloth that were used to form the covering and dividing walls of the tabernacle. See how you translated this in [Exodus 26:01](../26/01.md).

#### He made

Here "he" refers to Bezalel, but it includes all the men working on the sanctuary.

#### fifty gold clasps

"50 gold clasps" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 36:14

#### Bezalel made curtains ... the second set

For 36:14-17 see how you translated many of these words in [Exodus 26:7-9](../26/07.md) and [Exodus 26:10](../26/10.md).

#### made eleven

"made 11" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### thirty cubits

"30 cubits" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### fifty loops

"50 loops" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 36:18

#### Bezalel made ... to go above that

For 36:18-19 see how you translated many of these words in [Exodus 26:11](../26/10.md) and [Exodus 26:14](../26/12.md).

#### fifty bronze clasps

"50 bronze clasps" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Exodus 36:20

#### Bezalel made ... for the south side

For 36:20-23 see how you translated many of these words in [Exodus 26:15-18](../26/15.md).

#### ten cubits ... one and a half cubits

"10 cubits ... 1.5 cubits" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### two wooden pegs for joining

A wooden peg is a small piece of wood sticking out beyond the end of the board so it can be secured.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 36:24

#### Bezalel made ... and so on

For 36:24-26 see how you translated many of these words in [Exodus 26:19-21](../26/19.md).

#### forty silver bases

"40 silver bases" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### twenty frames

"20 frames" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### and so on

There will be two bases under each and every frame.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 36:27

#### For the back ... of the tabernacle

For 36:27-28 see how you translated many of these words in [Exodus 26:22-23](../26/22.md).

#### on the west

on the side that is on the west

#### for the back corners

for the corners at the rear of the tabernacle

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 36:29

#### These frames ... and so on

For 36:29-30 see how you translated many of these words in [Exodus 26:24-25](../26/22.md).

#### sixteen bases in all

"16 bases in all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### and so on

There will be two bases under each and every frame.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Exodus 36:31

#### Bezalel made ... with gold

For 36:31-34 see how you translated many of these words in [Exodus 26:26-28](../26/26.md) and [Exodus 26:29](../26/29.md).

#### to the west

on the west side

#### from end to end

from one side of the tabernacle to the other side

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 36:35

#### Bezalel made ... silver bases

For 36:35-36 see how you translated many of these words in [Exodus 26:31-32](../26/31.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Exodus 36:37

#### He made ... made of bronze

For 36:37-38 see how you translated many of these words in [Exodus 26:36-37](../26/36.md).

#### He made

Here "he" refers to Bezalel and those working for him. "Bezalel and his men made"

#### a hanging

a curtain

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 36:intro

#### Exodus 36 General Notes ####

####### Special concepts in this chapter #######

######## Tent of meeting ########
The tent of meeting, or tabernacle, mentioned in previous chapters is constructed in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]])

##### Links: #####

* __[Exodus 36:01 Notes](./01.md)__

__[<<](../35/intro.md) | [>>](../37/intro.md)__


## Exodus 37

### Exodus 37:01

#### Bezalel

This is the name of a man. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### two and a half cubits ... one cubit and a half

A cubit is 46 centimeters. AT: "2.5 cubits ... 1.5 cubits" or "115 centimeters ... 69 centimeters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### its four feet

These four pieces of wood that supported the ark are spoken of as if they were human or animal feet. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 37:04

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### He made ... and a half cubits

For 37:4-6 see how you translated many of these words in [Exodus 25:13-14](../25/12.md) and [Exodus 25:17](../25/15.md).

#### He made

Though "he" refers to Bezalel, "he" may include all of the workers who assisted him.

#### two and a half cubits ... one and a half cubits

A cubit is 46 centimeters. AT: "2.5 cubits ... 1.5 cubits" or "115 centimeters ... 69 centimeters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]

### Exodus 37:07

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### Bezalel made ... the center of the atonement lid

For 37:7-9 see how you translated many of these words in [Exodus 25:18](../25/15.md) and [Exodus 25:19-20](../25/19.md).

#### They were made as one piece

This can be stated in active form. AT: "He made them as one piece" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The cherubim spread out their wings upward and overshadowed

Bezalel placed the statues of the cherubim as if they were real cherubim which were spreading their wings and overshadowing the atonement lid. AT: "They placed the winged creatures so that their wings touched each other and spread out over" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The cherubim faced one another and looked toward

"The faces of the cherubim were towards each other, and they looked toward"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cherubim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]

### Exodus 37:10

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### Bezalel made ... four feet were

For 37:10-13 see how you translated many of these words in [Exodus 25:23-24](../25/23.md) and [Exodus 25:25-26](../25/25.md).

#### two cubits ... one cubit ... one and a half cubits

A cubit is 46 centimeters. AT: "2 cubits ... 1 cubit ... 1.5 cubits" or "92 centimeters ... 46 centimeters ... 69 centimeters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### handbreadth

This was the width of a man's hand with fingers spread out. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### the four feet

These four pieces of wood that supported the ark are spoken of as if they were human or animal feet. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 37:14

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture

#### The rings ... out of pure gold

For 37:14-16 see how you translated many of these words in [Exodus 25:27](../25/25.md) and [Exodus 25:28-29](../25/28.md).

#### The rings were attached

This can be stated in active form. AT: "Bezalel attached the rings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### dishes, spoons, the bowls, and pitchers to be used to pour out the offerings

It is only the bowls and pitchers that are used to pour out the offerings. AT: "plates and cups, and also the jars and bowls which the priests will use for pouring out the offerings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]

### Exodus 37:17

#### Connecting Statement:

Bezalel's work crew continues to build the tabernacle and furniture.

#### General Information:

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### He made ... from the lampstand

For 37:17-19 see how you translated many of these words in [Exodus 25:31-32](../25/31.md) and [Exodus 25:33](../25/33.md).

#### Its cups, its leafy bases, and its flowers were all made of one piece with it

This can be stated in active form. AT: "He made the cups, its leafy bases, and its flowers as one piece with the lampstand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### three cups made like almond blossoms

This can be stated in active form. AT: "he made the 3 cups look like almond blossoms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### almond blossoms

An almond blossom is a white or pink flower with five petals that grows on an almond tree.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 37:20

#### On the lampstand ... of pure gold

For 37:20-22 see how you translated many of these words in [Exodus 25:34](../25/33.md) and [Exodus 25:35-36](../25/35.md).

#### there were four cups made like almond blossoms

This can be stated in active form. AT: "there were 4 cups which Bezalel made to look like almond blossoms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### made as one piece with it

This can be stated in active form. AT: "which he made as one piece with the lampstand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 37:23

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### Bezalel made ... talent of pure gold

For 37:23-24 see how you translated many of these words in [Exodus 25:37-39](../25/37.md).

#### tongs

This is a tool made from two sticks of wood or metal connected at one end and used for picking up objects.

#### one talent

"33 kilograms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 37:25

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### Bezalel made ... gold for it

For 37:25-26 see how you translated many of these words in [Exodus 30:1-2](../30/01.md) and [Exodus 30:3](../30/03.md).

#### cubit

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### Its horns were made as one piece with it

This can be stated in active form. AT: "He made the horns as one piece with the altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 37:27

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### He made two golden rings ... with gold

For 37:27-28 see how you translated many of these words in [Exodus 30:4](../30/03.md) and [Exodus 30:5](../30/05.md)

#### to be attached to it

This can be stated in active form. AT: "which they attached to the altar" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the work of a perfumer

A perfumer is skilled in mixing spices and oils. See how you translated this in [Exodus 30:25](../30/22.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 37:intro

#### Exodus 37 General Notes ####

####### Special concepts in this chapter #######

######## The ark of the covenant ########
The ark, mentioned in previous chapters, is constructed in this chapter. There are other furnishings of the tabernacle that are also produced in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]])

##### Links: #####

* __[Exodus 37:01 Notes](./01.md)__

__[<<](../36/intro.md) | [>>](../38/intro.md)__


## Exodus 38

### Exodus 38:01

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### Bezalel made ... equipment with bronze

For 38:1-3 see how you translated many of these words in [Exodus 27:1-2](../27/01.md) and [Exodus 27:3](../27/03.md).

#### cubits

One cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### The horns were made of one piece

This can be stated in active form. AT: "He made the horns as one piece" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 38:04

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### He made ... for the poles

For 38:4-5 see how you translated many of these words in [Exodus 27:4](../27/03.md) and [Exodus 27:5](../27/05.md).

#### to be placed under the ledge

This can be stated in active form. AT: "which they placed under the ledge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 38:06

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### Bezalel made ... out of planks

A plank is a long, flat piece of wood that is thicker than a board. See how you translated many of these words in [Exodus 27:7-8](../27/07.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/acacia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Exodus 38:08

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### large bronze basin with a bronze stand

The stand supported the bronze basin. See how you translated this in [Exodus 30:18](../30/17.md).

#### He made the basin out of mirrors

The bronze came from the mirrors. This can be stated clearly in the translation. AT: "The bronze for the basin came from the mirrors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### mirrors

A mirror is a piece of polished metal or glass that reflects an image.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]

### Exodus 38:09

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### He also made ... as well as silver rods

For 38:9-10 see how you translated many of these words in [Exodus 27:9-10](../27/09.md).

#### one hundred ... twenty

"100 ... 20" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### cubits

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Exodus 38:11

#### Likewise along the north side ... posts were silver

For 38:11-12 see how you translated many of these words in [Exodus 27:11-12](../27/11.md).

#### one hundred ... twenty ... fifty ... ten

"100 ... 20 ... 50 ... 10" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### cubits

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Exodus 38:13

#### the courtyard

For 38:13-16 see how you translated many of these words in [Exodus 27:13](../27/11.md) and [Exodus 27:14-16](../27/14.md).

#### fifty ... fifteen ... three

"50 ... 15 ... 3" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### cubits

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### All the hangings around the courtyard were made of fine linen

This can be stated in active form. AT: "Bezalel and the workers made all the hangings around the courtyard with fine linen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]

### Exodus 38:17

#### The bases ... courtyard were made of bronze

For 38:17-20, see how you translated many of these words in [Exodus 27:16](../27/14.md) and [Exodus 27:17-19](../27/17.md).

#### The bases for the posts were made of bronze

This can be stated in active form. AT: "Bezalel and the workers made the bases for the posts out of bronze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The hooks and rods for the posts were made of silver, and the covering for the tops of the posts was also made of silver

This can be stated in active form. AT: "They made the hooks, the rods for the posts, and the covering for the tops of the posts out of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### All the courtyard posts were covered with silver

This can be stated in active form. AT: "They covered the courtyard posts with silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### twenty ... five ... four

"20 ... 5 ... 4" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### cubits

A cubit is 46 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### The curtain was made of

This can be stated in active form. "They made the curtain out of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The covering for their tops and its rods were made of silver

This can be stated in active form. AT: "They made the covering for the tops of the posts and their rods out of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### All the tent pegs for the tabernacle and courtyard were made of bronze

This can be stated in active form. AT: "They made all of the tent pegs for the tabernacle and courtyard out of bronze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 38:21

#### Connecting Statement:

Bezalel's work crew continues to build the tabernacle and furniture.

#### General Information:

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### as it was taken

This can be stated in active form. AT: "which Moses instructed the Levites to write down" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Ithamar

This is the name of a man. See how you translated this name in [Exodus 6:23](../06/23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bezalel son of Uri son of Hur

"Bezalel" and "uri" are the name of men. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Yahweh had commanded Moses

"everything that Yahweh told Moses to do"

#### Oholiab son of Ahisamak

"Oholiab" and "Ahisamak" are names of men. See how you translated this in [Exodus 31:6](../31/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### an engraver, as a skillful workman, and as an embroiderer

"as a skilled engraver and embroiderer"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]

### Exodus 38:24

#### All the gold that was used for the project

This can be stated in active form. AT: "All the gold that the people used for the project" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### twenty-nine talents ... one hundred talents

"29 talents ... 100 talents." A talent is about 33 kilograms. AT: "29 talents ... 100 talents" or "about 960 kilograms ... about 330 kilograms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### 730 shekels ... 1,775 shekels

"Seven hundred and thirty shekels ... one thousand seven hundred and seventy-five shekels." A shekel is 11 grams. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### measured by the standard of the sanctuary shekel

There were evidently shekels of more than one weight at the time. This specified which one was to be used. See how you translated this in [Exodus 30:13](../30/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### The silver given by the community

This can be stated in active form. AT: "The silver which the community gave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### one beka

A beka is 1/2 a shekel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### half a shekel

A shekel is 11 grams. AT: "1/2 a shekel" or "five and a half grams" or "5 1/2 grams" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### This figure was reached on the basis of every person who was counted in the census

Every man who was 20 years old or older was included in the census and was required to give half a shekel.

#### twenty years old

"20 years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/census.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/census.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Exodus 38:27

#### One hundred talents of silver were cast

A talent is about 33 kilograms. AT: "The workers cast 100 talents of silver" or "The workers cast 3,300 kilograms of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### One hundred talents

"100 talents" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### 1,775 shekels

"one thousand seven hundred and seventy-five shekels" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### shekels

A shekel is a unit of weight equal to about 11 grams. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### Bezalel

This is the name of a man. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### seventy talents and 2,400 shekels

"70 talents and two thousand four hundred shekels." This would be about 2,300 kilograms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Exodus 38:30

#### General Information:

Bezalel's work crew continues to build the tabernacle and furniture.

#### grate

This is a frame of crossed bars for holding wood when burning. See how you translated this in [Exodus 27:04](../27/03.md).

#### tent pegs

These are sharp bronze stakes that were used to secure the corners of a tent to the ground. See how you translated this in [Exodus 27:19](../27/17.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]

### Exodus 38:intro

#### Exodus 38 General Notes ####

####### Special concepts in this chapter #######

######## The altar ########
The altar is constructed in this chapter. There are other furnishings of the tabernacle that are also produced in this chapter. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]])

######## Materials ########
The list of materials being used is intended to give the reader an understanding of the scale of the tabernacle. It should fill the reader with awe concerning the power of Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Exodus 38:01 Notes](./01.md)__

__[<<](../37/intro.md) | [>>](../39/intro.md)__


## Exodus 39

### Exodus 39:01

#### General Information:

Bezalel's work crew shifts to making the priestly garments.

#### they made

The word "they" refers to Bezalel, Oholiab, and the other workmen.

#### as Yahweh had commanded Moses

"just as Yahweh told Moses to do"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 39:02

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### Bezalel

This is the name of a man. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 39:04

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### it was made of one piece with the ephod, made of fine twined linen

This can be stated in active form. AT: "they made it as one piece with the ephod with fine twisted linen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as Yahweh had commanded Moses

"just as Yahweh told Moses to do." See how you translated this phrase in [Exodus 39:01](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 39:06

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### signet

This was an engraved stone that was used to stamp a design in a wax seal. See how you translated this in [Exodus 28:11](../28/10.md).

#### twelve sons

"12 sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### as Yahweh had commanded Moses

"just as Yahweh told Moses to do." See how you translated this phrase in [Exodus 39:01](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 39:08

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### He made

"Bezalel made" or "Bezalel and the workers made"

#### span

A span is 23 centimeters. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 39:10

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### They set in it

"The workers set in the breastpiece"

#### ruby ... jasper

Some languages may not have words for each of these stones. The important fact is that they were valuable and different from one another. See how you translated these in [Exodus 28:17-20](../28/17.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### The stones were mounted in gold settings

This can be stated in active form. AT: "They mounted the stones in gold settings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 39:14

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### The stones were arranged

This can be stated in active form. AT: "The workers arranged the stones" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Exodus 39:17

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### two braided chains

"chains that are made of pure gold and are braided like cords." See how you translated this in [Exodus 28:14](../28/13.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]

### Exodus 39:19

#### General Information:

Bezalel's work crew continues to make the priestly garments that were commanded in [Exodus 28:26](../28/25.md) and [Exodus 28:27](../28/27.md).

#### finely-woven waistband

This was a cloth belt made from narrow linen threads that someone twisted together to make a stronger thread. See how you translated this in [Exodus 28:8](../28/06.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]

### Exodus 39:21

#### General Information:

Bezalel's work crew continues to make the priestly garments as commanded in [Exodus 28:28](../28/27.md).

#### so that it might be attached

This can be stated in active form. AT: "so they could attach it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the breastpiece might not become unattached from the ephod

The double negative can be translated as a positive. AT: "the breastpiece would stay attached to the ephod" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 39:22

#### General Information:

Bezalel's work crew continues to make the priestly garments as commanded in [Exodus 28:31-32](../28/31.md) and [Exodus 28:33](../28/33.md).

#### Bezalel

This is the name of a man. See how you translated this in [Exodus 31:1-2](../31/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]

### Exodus 39:25

#### General Information:

Bezalel's work crew continues to make the priestly garments as commanded in [Exodus 28:34-35](../28/33.md).

#### bells of pure gold

These were tiny bells.

#### a bell and a pomegranate, a bell and a pomegranate

This is how the pattern is supposed to repeat all along the bottom edge of the robe.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 39:27

#### General Information:

Bezalel's work crew continues to make the priestly garments.

#### They made ... commanded Moses

For 39:27-29 see how you translated many of these words in [Exodus 28:39](../28/39.md) and [Exodus 28:40](../28/40.md) and [Exodus 28:42](../28/42.md).

#### turban

This is a head covering worn by men made of a long strip of cloth wound around the head.

#### undergarments

This is clothing worn under the outer clothes, next to the skin. AT: "underwear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### sash

This is a long piece of cloth worn over the shoulder or around the waist.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 39:30

#### General Information:

Bezalel's work crew continues to make the priestly garments as commanded in [Exodus 28:36-37](../28/36.md).

#### holy crown

This was an engraved crown made of pure gold. See how you translated this in [Exodus 29:6](../29/05.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 39:32

#### General Information:

The Israelites finish making the things Yahweh commanded in [Exodus 35:4-9](../35/04.md) and [Exodus 35:10-12](../35/10.md).

#### So the work on the tabernacle, the tent of meeting, was finished. The people of Israel did everything

The "tabernacle" and "tent of meeting" are the same thing. This can be stated in active form. AT: "So the people of Israel finished all of the work on the tabernacle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### clasps

The clasps fit into the loops to hold the curtains together. See how you translated these in [Exodus 26:4-6](../26/04.md).

#### bases

These are heavy objects that rest on the ground and keep the object attached to them from moving. See how you translated this in [Exodus 25:31](../25/31.md).

#### atonement lid

This is the lid that sits on top of the ark where the atonement offering was made. See how you translated this in [Exodus 25:17](../25/15.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]

### Exodus 39:36

#### General Information:

Bezalel's work crew continues to present all that they made to Moses.

#### bread of the presence

This bread represented the presence of God. See how you translated this in [Exodus 25:30](../25/28.md).

#### grate

This is a frame of crossed bars that held wood while burning. See how you translated this in [Exodus 27:4](../27/03.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 39:40

#### General Information:

Bezalel's work crew continues to present all that they made to Moses.

#### They brought

"The people of Israel brought"

#### the tabernacle, the tent of meeting

These refer to the same place.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyplace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Exodus 39:42

#### Thus the people

"And so the people"

#### behold

The word "behold" here draws attention to the information that follows.

#### As Yahweh had commanded, in that way they did it

"They did it in the way that Yahweh had commanded them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Exodus 39:intro

#### Exodus 39 General Notes ####

####### Special concepts in this chapter #######

######## The holy clothing ########
The special, holy clothing mentioned in previous chapters is produced in this chapter to the correct specifications. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]])

##### Links: #####

* __[Exodus 39:01 Notes](./01.md)__

__[<<](../38/intro.md) | [>>](../40/intro.md)__


## Exodus 40

### Exodus 40:01

#### the first day of the first month of the new year

The new year marks the time when God rescued his people from Egypt. This happens around the middle of March on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]

### Exodus 40:03

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### place the ark of the testimony in it

"place the ark of the covenant decrees in the sacred chest"

#### shield the ark with the curtain

"put the ark behind the curtain"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]

### Exodus 40:05

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### ark of the testimony

This refers to the "sacred chest."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]

### Exodus 40:08

#### General Information:

Yahweh continues to tell Moses what the people must do.

#### all its furnishings

"all the things that are a part of it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]

### Exodus 40:12

#### General Information:

Yahweh continues speaking to Moses.

#### You are to bring

Moses will do these things himself.

#### that are set apart to me

This can be stated in active form. AT: "that you have set apart to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Exodus 40:14

#### General Information:

Yahweh continues speaking to Moses.

#### throughout their people's generations

"through all the generations of their descendants." See how you translated a similar phrase in [Exodus 12:14](../12/12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 40:17

#### So the tabernacle was set up

This can be stated in active form. AT: "So the people set up the tabernacle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the first day of the first month

This refers to exactly one year after God rescued his people from Egypt. This happens around the middle of March on Western calendars. See how you translated this in [Exodus 40:2](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### in the second year

This is the second year after Yahweh brought his people out of Egypt. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Moses set up

Moses was the leader. The people helped him set up the tabernacle. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### posts

a strong piece of wood set upright and used as a support

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonementlid.md)]]

### Exodus 40:21

#### He brought

Moses was the leader. He had workers helping him.

#### for it to shield

"in front of"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Exodus 40:24

#### He put the lampstand into the tent of meeting

Moses instructed his workers to move the lampstand. This can be stated clearly in the translation. AT: "Moses' workmen set the lampstand inside the sacred tent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 40:26

#### in front of the curtain

This curtain separated the holy place from the very holy place. This can be stated clearly in the translation. AT: "in front of the curtain that separated the holy place from the very holy place" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/altarofincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 40:28

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Exodus 40:31

#### washed their hands and their feet from the basin

They washed with water from the basin. This can be stated clearly in the translation. AT: "washed their hands and their feet with water from the basin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### In this way

"And so"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Exodus 40:34

#### Yahweh's glory filled

"Yahweh's awesome presence filled"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Exodus 40:36

#### was taken up from over

This can be stated in active form. AT: "rose up from" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that it was lifted up

This can be stated in active form. AT: "when it rose up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Exodus 40:intro

#### Exodus 40 General Notes ####

####### Structure and formatting #######

This chapter is repetitive and should read as a series of instructions. It is repeated as well to show that Moses was obedient to every detail of Yahweh's command. 

####### Other possible translation difficulties in this chapter #######

######## "Yahweh's glory filled the tabernacle" ########
This phrase indicates that Yahweh began to dwell within the tabernacle, among Israel, in a special way. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]])

##### Links: #####

* __[Exodus 40:01 Notes](./01.md)__

__[<<](../39/intro.md) | __


## Exodus front

### Exodus front:intro

#### Introduction to Exodus ####

##### Part 1: General Introduction #####

####### Outline of Exodus #######

1. Israel in Egypt; preparing to depart from slavery (1–12)
      - First genealogy (1:1–6)
      - Israel as slaves in Egypt (1:7–22)
      - Moses' history to the time of the Exodus (2:1–4:26)
      - Israel suffers in Egypt (4:27–6:13)
      - Sedond genealogy (6:14–27)
      - Moses and Aaron go to Pharaoh (6:28–7:25)
      - The plagues (8:1–11:10)
1. Instructions for celebrating the Passover (12:1–30)
1. From Egypt to Mount Sinai (12:31–18:27)
      - The Passover; preparing to leave Egypt; leaving Egypt (12:31–50, 13:1–22)
      - Journey from Egypt to Mount Sinai (14:1–18:27)
1. Mount Sinai and the Law (19-40)
      - Preparing for the covenant (19:1–25)
      - The Ten Commandments (20:1–17)
      - The covenant described (20:18–23:33)
      - The people agree to the covenant; Moses returns to Mount Sinai (24:1–18)
      - Design of the tabernacle and its furnishings; what was required of those who serve in it; tabernacle functions (25:1–31:18)
      - The golden calf; Moses prays for the people (32:1–33:22)
      - The covenant described again (34:1–35)
      - Making of the ark and its furnishings (35:1–38:31) and priestly garments (39:1–43, 40:1–33)
      - The cloud (40:34–38)

####### What is the Book of Exodus about? #######
 
Exodus continues the story of the previous book, Genesis. The first half of Exodus is about how Yahweh made Abraham's descendants into a nation. This nation, which would be called "Israel," was meant to belong to Yahweh and worship him. The second half of Exodus describes how God gave the Israelites his law through Moses. The law of Moses told the Israelites how to obey and worship Yahweh properly.

The Book of Exodus tells how the Israelites were to build the tabernacle. The tabernacle was a tent where Yahweh would be among his people. The Israelites worshiped and sacrificed animals to Yahweh at the tabernacle. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/tabernacle.md)]])

####### How should the title of this book be translated? #######

"Exodus" means "exit" or "departure." Translators may translate this title in a way that can communicate its subject clearly, for example, "About the Israelites Leaving Egypt" or "How the Israelites Left the Land of Egypt." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### Who wrote the Book of Exodus? #######

The writers of both the Old and New Testaments present Moses as being very involved with writing the book of Exodus. Since ancient times, both Jews and Christians have thought that Moses wrote Genesis, Exodus, Leviticus, Numbers, and Deuteronomy.

####### Why did Moses write so much about God delivering or rescuing the people of Israel? #######

Moses wrote much about God rescuing his people from the Egyptians to show that Yahweh is very powerful. Egypt was the most powerful nation at that time. And Yahweh was still able to free the Israelites from the Egyptians. Also, by rescuing the Israelites, Yahweh showed that he had chosen them as his people and they should worship him.

####### How does the Book of Exodus show the fulfillment of the promises given to Abraham? #######
 
The Book of Exodus shows God beginning to fulfill his promise to Abraham. In Genesis, God promised Abraham that he would have many descendants and that they would become a large nation. When God rescued the Israelites from the Egyptians, he took them to Mount Sinai. There he made a covenant with them, and they became the nation that belonged to Yahweh.

##### Part 2: Important Religious and Cultural Concepts #####

####### What was the Jewish Passover? #######

The Jewish Passover was a religious festival. Yahweh commanded the Israelites to celebrate it every year. Passover was a time to remember how God rescued them from the Egyptians. The first Passover meal was eaten in the evening just before they left Egypt.

####### What was the law of Moses to the people of Israel? #######

The law of Moses instructed the people of Israel what Yahweh required them to do as his people. In the law, God told the people how they should live so that they honor him. He also instructed them about their need to offer animal sacrifices. God required these sacrifices so that he could forgive their sins and continue living among them. The law also described the duties of the priests and told how to build the tabernacle.
 
####### What did it mean that Israel was to be a "kingdom of priests and a holy nation" (19:6 ULB)? #######

Israel was a holy nation because Yahweh separated them from all other nations to belong to him. They were to honor and worship him only. This made them different than all the other nations of the world. These other nations worshiped many false gods.

##### Part 3: Important Translation Issues #####

####### Why are the details of the construction of the tabernacle in Exodus 25–32 repeated in Exodus 35–40? #######

In Exodus 25-32, God describes exactly how the tabernacle was to be built. The details were repeated in Exodus 35-40. This showed that the people were to be careful to do exactly as God commanded.

####### Are the events in the order that they actually happened? #######

Most but not all of the events in the Book of Exodus are told in the order that they actually happened. Translators may need to make it clear when the events are in an unusual order. 

####### What does it mean that God "lived" among his people? #######

The Book of Exodus presents God as living in the tabernacle among the nation of Israel. God is everywhere, but he lived among the Israelites in a special way. God dwelled with Israelites because they belonged to him. He promised to lead them and bless them. In return, the people were to worship him and honor him.



---

