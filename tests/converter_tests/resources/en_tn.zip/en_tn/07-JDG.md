# <a id="jdg"/>Judges

## Judges 01

### Judges 01:01

#### Connecting Statement:

The book of Judges continues the story about Joshua and is also the beginning of a new part of the story.

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### will attack the Canaanites for us

The word "us" refers to the people of Israel, but not to Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### Judah will attack

Here "Judah" represents the men of the tribe of Judah. Yahweh is commanding these men to attack first. AT: "The men of Judah must attack first" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### See

"Look" or "Listen" or "Pay attention to what I am about to tell you"

#### this land

This refers to the land where the Canaanites lived. AT: "the land of the Canaanites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### their brothers

"their fellow Israelites" or "their relatives"

#### Come up with us

The people of the tribes of Judah and Simeon were camped with the rest of the Israelite people in the valley of the Jordan River. The land given to Judah was in the hills above the valley. Some languages do not usually indicate whether people were going up or down. AT: "Come with us" or "Go with us"

#### that was assigned to us ... that was assigned to you

This can be stated in active form. AT: "that Yahweh assigned to us ... that Yahweh assigned to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### We will likewise go with you

"We will also go with you" or "In the same way, we will go with you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]

### Judges 01:04

#### The men of Judah attacked

It is implied that the men of Simeon attacked with the men of Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They killed ten thousand

"They killed about 10,000" or "They killed a large number" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### of them

"soldiers of the Canaanites and Perizzites" or "enemies"

#### Bezek

This is an area in the mountains of Canaan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Adoni-Bezek

This man was the leader of the army of the Canaanites and the Perizzites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### they fought against him

Here "him" actually refers to Adoni-Bezek and his army. AT: "they fought against him and his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]

### Judges 01:06

#### pursued him

"chased him"

#### Seventy kings

"70 kings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### who had their thumbs and their big toes cut off

This can be stated in active form. AT: "whose thumbs and big toes I told my men to cut off" or "whose thumbs and big toes we cut off" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### gathered their food from under my table

Forcing these kings to eat scraps of food represents all the ways that Adoni-Bezek humiliated these kings. Here "gathering" food represents eating it. AT: "ate scraps of food from under my table" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Judges 01:08

#### the city of Jerusalem and took it

Here "city" represents the people. AT: "the people who lived in Jerusalem and defeated them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They attacked it

Here "it" refers to the city which represents the people of the city. AT: "They attacked the people of the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with the edge of the sword

"with the point of the sword." Here "sword" represents the swords and other weapons that the soldiers used in battle. AT: "with their swords" or "with their weapons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the men of Judah went down to fight

It was common to use the word "down" when it refers to traveling from Jerusalem. AT: "the men of Judah went to fight"

#### in the Negev

"in the southern Judean wilderness"

#### foothills

hills at the base of a mountain or mountain range

#### the name of Hebron was previously Kiriath Arba

This is background information. Some people who first read this book had probably heard of Kiriath Arba but did not know that it was the same as the city that they called Hebron. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Sheshai, Ahiman, and Talmai

These are the names of three Canaanite leaders of Hebron. Each leader represents his army. AT: "Sheshai, Ahiman, Talmai, and their armies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]

### Judges 01:11

#### the name of Debir was previously Kiriath Sepher

The author probably wrote this because his readers knew the city as Debir. But at the time Israel attacked it, it was called Kiriath Sepher. AT: "which used to be called Kiriath Sepher" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### previously

"in times past" or "at an earlier time"

#### Whoever attacks Kiriath Sepher and takes it

Here "Kiriath Sepher" represents the people. AT: "Whoever attacks and defeats the people of Kiriath Sepher and takes their city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Aksah

This is the name of Caleb's daughter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Othniel, son of Kenaz

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]

### Judges 01:14

#### she urged him

"Aksah urged Othniel"

#### give her a field ... Since you have given me the land

This implies that Caleb did give her the field when she asked him for it in verse 14. In verse 15, she is now asking for springs of water in addition to that field. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Give me a blessing

"Do a favor for me" or "Do this for me"

#### Since you have given me the land of the Negev

Caleb gave Aksah in marriage to Othniel, so she lived with Othniel in the city that he had captured in the Negev. The full meaning of this statement can be made explicit. AT: "Since you have given me in marriage to live in the Negev" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]

### Judges 01:16

#### of Moses' father-in-law

"of the father of Moses' wife"

#### father-in-law the Kenite went up

"father-in-law, who was one of the Ken people, went up"

#### went up from the City of Palms ... into the wilderness

"left the City of Palms ... and went into the wilderness"

#### City of Palms

This is another name for the city of Jericho. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Arad

This is the name of a city in Canaan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the men of Simeon their brothers

Here "brothers" means relatives who were in another tribe of Israel.

#### Zephath

This is the name of a city in Canaan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The name of the city was called Hormah

After the Israelites destroyed Zephath, they changed its name to "Hormah." The name "Hormah" means "complete destruction." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/negev.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Judges 01:18

#### Yahweh was with the people of Judah

Here "was with" means that Yahweh helped the people of Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### plains

a very large area of level, treeless ground

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ekron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]

### Judges 01:20

#### Hebron was given to Caleb (like Moses had said)

This can be stated in active form. AT: "Moses had given Hebron to Caleb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### three sons of Anak

The leaders of the people groups are used to refer to the entire group. AT: "three sons of Anak and their people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Anak

This is the name of a man. Anak and his descendants were famous for being very tall. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### to this day

"until now." This refers to the time the book of Judges was written.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Judges 01:22

#### The house of Joseph

Here "house" represents descendants. Manasseh and Ephraim were sons of Joseph, and the "house of Joseph" can refer to the descendants of Manasseh and Ephraim. AT: "The descendants of Manasseh and Ephraim" or "The men of the tribes of Manasseh and Ephraim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to attack Bethel

Here "Bethel" represents the people who live in Bethel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### spy

to get information secretly

#### the city that was formerly called Luz

This is background information. Some people who first read this book had probably heard of Luz but did not know that it was the same as the city that they called Bethel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### spies

people who get information secretly

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]

### Judges 01:25

#### they attacked the city

Here "city" represents the people. AT: "they attacked the people of the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with the edge of the sword

"with the point of the sword." Here "sword" represents the swords and other weapons that the soldiers used in battle. AT: "with their swords" or "with their weapons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### get away

This is an idiom. AT: "escape" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Luz

This new town started in the land of the Hittites was named after the town of Luz, near Bethel, that the man had left.

#### which is its name to this day

"which is still its name." Here "to this day" refers to the time when the book of Judges was written.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Judges 01:27

#### Beth Shan ... Taanach ... Dor ... Ibleam ... Megiddo

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### because the Canaanites were determined to live in that land

To "determine" is to firmly decide something. AT: "because the Canaanites firmly decided not to leave that land"

#### When Israel became strong

Here "Israel" represents the people. AT: "When the people of Israel became stronger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they forced the Canaanites to serve them with hard labor

"they forced the Canaanites to do hard work for them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Judges 01:29

#### Ephraim did not

Here "Ephraim" the men or the soldiers of the tribe of Ephraim. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Gezer

The name of one of the cities in the Ephraim area. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Judges 01:30

#### Zebulun did not drive out

Here "Zebulun" represents the men or the soldiers of the tribe of Zebulun. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Kitron ... Nahalol

These are names of cities in the land of Canaan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### but Zebulun forced

Here "Zebulun" represents the people of the tribe of Zebulun. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hard labor

"difficult labor"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Judges 01:31

#### Asher did not drive

Here "Asher" represents the men or the soldiers of the tribe of Asher. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Akko ... Sidon ... Ahlab, Akzib, Helbah, Aphek ... Rehob

These are names of cities in the land of Canaan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]

### Judges 01:33

#### Beth Shemesh ... Beth Anath

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the inhabitants of Beth Shemesh and Beth Anath were forced into hard labor for Naphthali

This can be stated in active form. AT: "the people of Naphtali forced the people of Beth Shemesh and Beth Anath to work for them as slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethshemesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Judges 01:34

#### not allowing them to come down

"stopping them from coming down"

#### plain

a very large area of flat land without trees

#### Mount Heres

This is the name of a large hill on which the city of Aijalon was built. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Aijalon ... Shaalbim

These are names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the military might of the house of Joseph conquered them

"the tribes of people who descended from Joseph were able to conquer them because of their powerful army"

#### house of Joseph

Here "house" represents descendants. Manasseh and Ephraim were sons of Joseph, and the "house of Joseph" can refer to the descendants of Manasseh and Ephraim. AT: "the descendants of Manasseh and Ephraim" or "the men of the tribes of Manasseh and Ephraim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the hill of Akrabbim

This was a pass southwest of the Dead Sea. It is also called the "Scorpion Pass." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Sela

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]

### Judges 01:intro

#### Judges 01 General Notes ####

####### Structure and formatting #######
######## "After the death of Joshua" ########
This statement creates a seamless transition from the book of Joshua.

####### Special concepts in this chapter #######

######## Finishing the conquest of the Promised Land ########

Israel fought to clear the land of the Canaanites, but they also made treaties with other peoples and made some of them do hard labor. This was against God's instruction to completely remove the Canaanite people from the land.   

##### Links: #####

* __[Judges 01:01 Notes](./01.md)__
* __[Judges intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Judges 02

### Judges 02:01

#### angel of Yahweh

Possible meaning are 1) "angel who represents Yahweh" or 2) "messenger who serves Yahweh" or 3) it may refer to Yahweh himself, who looked like an angel as he talked to a person. Either one of these meanings would explain the angel's use of "I" as if Yahweh himself were talking.

#### went up from Gilgal to Bokim

"left Gilgal and went to Bokim"

#### Bokim

This is what the Israelites named this place in 2:5 after the angel rebukes the people. "Bokim" means "crying." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### and said

It is understood that the angel of Yahweh is speaking to the people of Israel. AT: "and said to the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### brought you up from Egypt

"led you from Egypt"

#### your fathers

"your ancestors" or "your forefathers"

#### break my covenant with you

This is an idiom. AT: "fail to do what I said I would do for you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you have not listened to my voice

Here "voice" represents what Yahweh said. AT: "you have not obeyed my commands" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### What is this that you have done?

This question is asked to cause the people of Israel to realize they have disobeyed Yahweh and will suffer because of it. AT: "You have done a terrible thing." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Judges 02:03

#### General Information:

The angel of Yahweh continues to speak to the people of Israel.

#### So now I say, 'I will not ... trap for you.'

This has a quotation within a quotation. This direct quotation can be stated as an indirect quotation. AT: "So now I tell you that I will not ... trap for you.'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### become thorns in your sides

The Canaanites troubling the Israelites is spoken of as if the Canaanites would be thorns in the side of the Israelites. AT: "cause you trouble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### thorns

sharp pieces of wood up to 7 centimeters long that stick out from some plants

#### their gods will become a trap for you

The Israelites worshiping the Canaanite gods is spoken of as if the false gods were a hunter's trap that catches an animal and causes it harm. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### shouted and wept

"cried many tears"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]

### Judges 02:06

#### Now when Joshua

Here "Now" is used here to mark a break in the main story line. Here the narrator begins a summary that explains how the generations of Israelites after Joshua sinned and worshiped false gods so that Yahweh punished them, but then he would send judges to rescue them. This summary ends in 2:23.

#### when Joshua ... died at the age of 110 years old

The events of 1:1-2:5 happened after Joshua died. This is recounting events that happened at the end of the book of Joshua.

#### to the place assigned

This statement can be made clearer. AT: "to the place Yahweh gave them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### during the lifetime

This means the time that someone lived. AT: "during the life"

#### the elders

Here this means the men who helped lead Israel, participating in matters of social justice and in religious matters such as maintaining the law of Moses.

#### outlived him

This means to live longer than someone else. AT: "lived longer than he did"

#### Nun

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 110 years old

"one hundred and ten years old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 02:09

#### he was assigned

This can be stated in active form. AT: "that God gave him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Timnath Heres

This is the name of an area of land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mount Gaash

This is the name of a mountain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### All that generation was also gathered to their fathers

The phrase "was also gathered to their fathers" means that as the people of that generation died, their souls went to the same place as their ancestors who died before them. It is a polite way of saying they died. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### fathers

Here this means the ancestors of a certain person or people group.

#### grew up

"grew older" or "became older"

#### who did not know Yahweh

Here "did not know" means they had not experienced Yahweh or his power the way the previous generation had.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 02:11

#### what was evil in the sight of Yahweh

The sight of Yahweh represents Yahweh's judgment or evaluation. AT: "what was evil in Yahweh's judgment" or "what Yahweh considered to be evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Baals

This is the plural of Baal. While "Baal" was generally the name of one false god, the word was also used for various other gods that were often worshiped along with Baal. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They broke away from Yahweh

The Israelites no longer obeying Yahweh is spoken of as if they physically broke away from him and left him. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their fathers

"their ancestors" or "their forefathers"

#### They went after other gods

The Israelites starting to worship false gods is spoken of as if the Israelites walked and went after the false gods. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bowed down to them

This is an act of worship and giving honor to someone. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### They provoked Yahweh to anger

"They caused Yahweh to become angry"

#### Ashtoreths

This is the plural of Ashtoroth, who was worshiped as a goddess in many different forms. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Judges 02:14

#### The anger of Yahweh burned against Israel

The anger of Yahweh is described as burning like a fire. AT: "Yahweh became very angry with the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he gave them to the raiders who stole their possessions from them

"he let raiders steal their possessions"

#### He sold them as slaves who were held by the strength of their enemies around them, so they could no longer defend themselves against their enemies

Yahweh allowing the enemies to take the Israelites as slaves is spoken of as if he sold them into slavery. The phrase "who were held by" can be stated in active form. AT: "He allowed their enemies to conquer them and take them as slaves, and they could no longer resist their powerful enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Yahweh's hand was against them to defeat them

Here "hand" represents Yahweh's power. AT: "Yahweh helped their enemies defeat them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they were in terrible distress

"they were suffering terribly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Judges 02:16

#### Then Yahweh raised up judges

Yahweh appointing persons to be judges is spoken of as if he were raising or lifting the persons up. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### out of the hand of those

Here "hand" refers to power. AT: "from the power of the enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they would not listen to their judges

"they would not obey their judges"

#### gave themselves like prostitutes to other gods and worshiped them

The people betraying Yahweh and worshiping other gods is spoken of as if the people were prostitutes. AT: "betrayed him by worshiping false gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### They soon turned aside from the way their fathers had lived

The people not acting like their ancestors who worshiped Yahweh is spoken of as if the people turned and went in a different direction than their ancestors. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their fathers

"their ancestors" or "their forefathers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Judges 02:18

#### When Yahweh raised up judges

Yahweh appointing persons to be judges is spoken of as if he raised or lifted up the persons. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### judges for them ... rescued them

The word "them" refers to the Israelites.

#### the hand of their enemies

Here "hand" refers to power of the enemies to hurt Israel. AT: "the power of their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### all the days the judge lived

"as long as the judge lived"

#### pity

to have compassion for someone or something

#### as they groaned

The sound made by a person who suffers is used to describe the pain of the Israelites as they suffer. AT: "as they suffered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they would turn away

The people no longer obeying Yahweh is spoken of as if they would physically turn away from Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their fathers

"their ancestors" or "their forefathers"

#### They would go after other gods to serve them and worship them

The Israelites worshiping other gods is spoken of as if they were walking and going after other gods. AT: "They would serve and worship other gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They refused to give up any of their evil practices or their stubborn ways

"They refused to stop doing evil things and being stubborn." This can be stated in positive form. AT: "They continued doing evil things and being stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stiffnecked.md)]]

### Judges 02:20

#### The anger of Yahweh burned against Israel

The anger of Yahweh is described as burning like a fire. See how you translated this phrase in [Judges 2:14](./14.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### this nation has broken

Here "nation" represents the people. AT: "these people have broken" or "the Israelites have broken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### fathers

Here this refers to the ancestors of a certain person or people group.

#### they have not listened to my voice

Here "voice" represents what Yahweh said. AT: "they have not obeyed what I commanded them" or "they have not obeyed me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### any of the nations

Here "nations" represents the people groups that lived in Canaan before the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they will keep the way of Yahweh and walk in it

How Yahweh wants people to live or behave is spoken of as if it were a way or road. A person obeying Yahweh is spoken of as if they were walking in his way. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### did not drive them out quickly and give them into the hand of Joshua

These two phrases mean the same thing and can be combined. AT: "he did not let Joshua quickly conquer them and drive them out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### into the hand of Joshua

Here "hand" is a metonym for power, and "Joshua" represents himself and his army. AT: "into the power of Joshua and his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]

### Judges 02:intro

#### Judges 02 General Notes ####

####### Special concepts in this chapter #######

######## Yahweh tests Israel ########

Yahweh said, "Because this nation has broken the terms of my covenant." Completely removing the Canaanites from the land was a test from Yahweh. While Yahweh displayed covenant faithfulness, Israel did not. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenantfaith.md)]])

##### Links: #####

* __[Judges 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Judges 03

### Judges 03:01

#### Now Yahweh

Here "Now" begins a new section of the story.

#### these nations

This refers to the people groups that the narrator will list in 3:3.

#### who had not experienced any of the wars fought in Canaan

This can be stated in active form. AT: "who had not fought in any of the wars in Canaan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He did this to teach warfare to the new generation of the Israelites who had not known it before

This breaks from the main story line. The narrator gives background information about why Yahweh left some of the people groups in Canaan. AT: "Yahweh left nations among the Israelites to teach the young men who had not fought in battle before how to fight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### the five kings

These five kings represent themselves and their people. AT: "the five kings and their people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Mount Baal Hermon

This is the highest mountain in Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hamath Pass

This is the name of an area at the northern boundary of Canaan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]

### Judges 03:04

#### These nations were left

This can be stated in active form. AT: "Yahweh left these nations in Canaan" or "Yahweh allowed these nations to continue to live in Canaan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as a means

"as a way"

#### whether they would ... gave their ancestors

The words "they" and "their" refer to the people of Israel.

#### the commands he gave

"the commands Yahweh gave"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hivite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]

### Judges 03:07

#### what was evil in the sight of Yahweh

The sight of Yahweh represents Yahweh's judgment or evaluation. See how you translated this in [Judges 2:11](../02/11.md). AT: "what was evil in Yahweh's judgment" or "what Yahweh considered to be evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### forgot Yahweh their God

Here "forgot" is an idiom that means "they stopped obeying." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the anger of Yahweh was set on fire

Yahweh becoming very angry is spoken of as if his anger were something that could be set on fire. AT: "Yahweh became very angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sold them into the hand of Cushan-Rishathaim

Allowing the people of Israel to be conquered is spoken of as if Yahweh sold them to Cushan-Rishathaim. AT: "allowed Cushan-Rishathaim and his army to defeat them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### into the hand of Cushan-Rishathaim

Here "hand" is a metonym that represents power or control. Also, "Cushan-Rishathaim" is a synechdoche that represents himself and his army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Cushan-Rishathaim

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Aram Naharaim

This is the name of a country. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mesopotamia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mesopotamia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Judges 03:09

#### Yahweh raised up someone

Yahweh appointing someone to do a special work for him is spoken of as if Yahweh raised or lifted up the person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Othniel ... Kenaz

See how you translated these men's names in [Judges 1:13](../01/11.md).

#### empowered him

This phrase means that Yahweh helped Othniel to have and develop the qualities he needed to be a great leader.

#### he judged Israel

Here "judged" means he led the people of Israel.

#### he went out to war

Here "he" refers to Othniel who represents himself and the army of Israel. AT: "Othniel and the Israelite soldiers went to fight against the army of Cushan-Rishathaim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Yahweh gave him victory over Cushan-Rishathaim king of Aram

Here "Cushan-Rishathaim" represents his army. AT: "Yahweh helped the Israelite army defeat the army of Cushan-Rishathaim king of Aram" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### The hand of Othniel

Here "hand" is a metonym for army. AT: "The army of Othniel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The land had peace

"The land" is used to refer to the people who lived in the land. AT: "The people lived peacefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### forty years

"40 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/caleb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Judges 03:12

#### what was evil in the sight of Yahweh

The sight of Yahweh represents Yahweh's judgment or evaluation. See how you translated this in [Judges 2:11](../02/11.md). AT: "what was evil in Yahweh's judgment" or "what Yahweh considered to be evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh gave strength to Eglon king of Moab

The abstract noun "strength" can be stated as an adjective. AT: "Yahweh made Eglon king of Moab strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### to Eglon king of Moab to overpower the Israelites

Here "Eglon king of Moab" represents himself and his army. AT: "to Eglon king of Moab and his soldiers as they attacked the Israelite army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Eglon

This is the name of a king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the City of Palms

This is another name for the city of Jericho. See how you translated this in [Judges 1:16](../01/16.md).

#### eighteen years

"18 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]

### Judges 03:15

#### called out to Yahweh

Here this means to shout or speak loudly to someone far away. It can also mean to ask someone for help, especially God.

#### raised up someone

Yahweh appointing someone to do a special service for him is spoken of as if he raised or lifted up the person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Ehud ... Gera

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### left-handed

Ehud was better able to hold a sword with his left hand.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]

### Judges 03:16

#### one cubit

If it is necessary to use a modern measurement of length, here are two ways of doing it. AT: "46 centimeters" or "about one half meter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### he strapped it on under his clothing on his right thigh

"he tied it to his right thigh under his clothing"

#### thigh

"upper leg"

#### Now Eglon was a very fat man

Here "Now" is used here to mark a break in the main story line. Here the narrator tells background information about Eglon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]

### Judges 03:19

#### when he reached the place where the carved images were made near Gilgal

This can be stated in active form. AT: "when he arrived at the place near Gilgal where people made carved images" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in the coolness of the upper room

This is a room above the lower level that was used for rest and to remain cool during the hot part of the day.

#### The king got up out of his seat

Standing up was a sign of honoring God will listening to his message. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilgal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Judges 03:21

#### The tip of the sword came out of his back

"The sharp end of the sword came out of his back"

#### porch

an outside room with low walls and a roof covering

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Judges 03:24

#### Surely he is relieving himself

This is a polite way to speak about a person having a bowel movement (defecating) or urinating. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### until they felt they were neglecting their duty

They waited until they became worried that something was wrong and it was their duty to open the doors to their king's private room.

#### took the key and opened them

"took the key and opened the doors"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 03:26

#### While the servants were waiting ... Ehud escaped

This tells what happened before the servants opened the doors to the upper room and found the king dead. AT: "Meanwhile, as the servants were still waiting outside of the upper room ... Ehud escaped" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])

#### Seirah

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### When he arrived

This could be made clearer. AT: "When he arrived in Seirah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 03:28

#### General Information:

Ehud speaks to the people of Israel in Ephraim.

#### for Yahweh is about to defeat your enemies

Yahweh helping the Israelites to defeat their enemies is spoken of as if Yahweh were a warrior who would fight and defeat their enemies. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### captured the fords

"gained control of the fords"

#### fords

the areas of a river where it is shallow and easy to walk across to the other side

#### did not allow anyone to cross

"did not let anyone cross"

#### ten thousand men

"10,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### capable men

"able men" or "men able to fight well"

#### Moab was subdued by the strength of Israel

This can be stated in active form. AT: "the Israelite army defeated the Moabites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the strength of Israel

Here "strength" represents the Israelite army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the land had rest

Here "land" represents the people. AT: "the Israelites lived peacefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### eighty years

"80 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 03:31

#### judge

God appointed judges to lead the people of Israel in times of trouble after they entered the Promised Land and before they had kings. Often judges rescued the Israelites from their enemies.

#### Shamgar

The name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Anath

The name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 600 men

"six hundred men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### goad

"move" or "direct"

#### He also delivered Israel from danger

The word "danger" refers to enemies that tried to harm the people of Israel. AT: "He also delivered the people of Israel from their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]

### Judges 03:intro

#### Judges 03 General Notes ####

####### Special concepts in this chapter #######

######## The people worship false gods ########

Israel worshiped idols and false gods. Because of this, Yahweh allowed Aram and Moab to rule over them. In the period of Judges, when Israel sinned, they were often placed under the rule of a foreign power. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]) 

####### Other possible translation difficulties in this chapter #######

######## "Blew a trumpet" ########

When Ehud "blew a trumpet," he was calling all of the men to come help him fight. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]]) 

##### Links: #####

* __[Judges 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Judges 04

### Judges 04:01

#### Ehud

See how you translated this man's name in [Judges 3:15](../03/15.md).

#### what was evil in the sight of Yahweh

The sight of Yahweh represents Yahweh's judgment or evaluation. See how you translated this in [Judges 2:11](../02/11.md). AT: "what was evil in Yahweh's judgment" or "what Yahweh considered to be evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh sold them into the hand of Jabin king of Canaan

Here "hand" refers to Jabin's power over Israel. Yahweh's decision to give Jabin power over them is spoken of as if Yahweh had sold them to Jabin. AT: "Yahweh allowed them to be defeated by the power of Jabin king of Canaan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Jabin ... Sisera

These are the names of men (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hazor ... Harosheth Haggoyim

These are the names of cities or places (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### nine hundred iron chariots

"900 iron chariots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### twenty years

"20 years"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Judges 04:04

#### Now

This word is used here to mark a break in the main story line. Here the narrator tells background information about Deborah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Deborah

This is the name of a woman (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Lappidoth

This is the name of a man (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### judge

God appointed judges to lead the Israelites in times of trouble. Often the judges rescued them from their enemies.

#### palm of Deborah

This tree was named after Deborah.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]

### Judges 04:06

#### General Information:

The writer of Judges refers to men, a city, a mountain, and a river by their names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Barak ... Abinoam

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mount Tabor

This is the name of a mountain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### ten thousand men

"10,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### I will draw out

Here "I" refers to God.

#### draw out Sisera

Here "Sisera" represents himself and his army. AT: "draw out Sisera and his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### draw out

to cause people to come away from a safe location

#### Sisera ... Jabin

See how you translated these men's names in [Judges 4:2](./01.md).

#### Kishon

This is the name of a river. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]

### Judges 04:08

#### General Information:

Barak has a discussion with Deborah.

#### Barak

See how you translated this man's name in [Judges 4:6](./06.md).

#### the road on which you are going will not lead to your honor

The choice Barak makes is spoken of as if Barak were choosing a road on which to travel. And, "honor" is spoken of as if it were a destination to which one travels. AT: "no one will honor you for what you do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for Yahweh will sell Sisera into the hand of a woman

Here "hand" refers to her power to kill him. AT: "for Yahweh will cause a woman to defeat Sisera" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Sisera

See how you translated this man's name in [Judges 4:2](./01.md).

#### Deborah

See how you translated this woman's name in [Judges 4:4](./04.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]

### Judges 04:10

#### Ten thousand men

"10,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]

### Judges 04:11

#### Now

This word is used here to mark a break in the main story line. Here the narrator tells background information about Heber the Kenite. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Heber ... Hobab

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Kenite

See how you translated this in [Judges 1:16](../01/16.md)

#### Moses' father-in-law

"the father of Moses' wife"

#### Zaanannim

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kedesh.md)]]

### Judges 04:12

#### When they told Sisera

Here "they" does not identify anyone specifically. AT: "When someone told Sisera"

#### Sisera

See how you translated this man's name in [Judges 4:2](./01.md).

#### Barak ... Abinoam ... Mount Tabor

See how you translated these names in [Judges 4:6](./06.md).

#### Sisera called out all his chariots

Here "chariots" represents the soldiers who drove the chariots. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### nine hundred iron chariots

"900 iron chariots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Harosheth Haggoyim

See how you translated the name of this city in [Judges 4:2](./01.md).

#### Kishon River

See how you translated this in [Judges 4:7](./06.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]

### Judges 04:14

#### Yahweh has given you victory

Because Deborah is certain of victory, she speaks as if Barak had already won the battle. AT: "Yahweh will give you victory" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### Is not Yahweh leading you?

Deborah asks this question to remind Barak that they fight on the side of Yahweh. AT: "Remember, Yahweh is leading you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### with ten thousand

"with 10,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 04:15

#### Yahweh confused Sisera and all his chariots and all his army

"Yahweh made Sisera and all his chariots and all his army unable to think clearly" or "Yahweh made Sisera and all his chariots and all his army panic"

#### all his chariots

Here the word "chariots" is a metonym for the soldiers driving the chariots. AT: "all the men driving chariots" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Barak pursued

Here "Barak" represents himself and his army. AT: "Barak and his soldiers chased" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Harosheth

Translate this the same way you did in [Judges 4:2](./01.md).

#### the whole army of Sisera was killed by the edge of the sword

Here "sword" represents the swords and other weapons that the soldiers used in battle. This can be stated in active form. AT: "Barak and his soldiers killed Sisera's whole army with their swords" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Judges 04:17

#### Sisera ... Jabin ... Hazor

See how you translated these names in [Judges 4:2](./01.md).

#### ran away on foot

This is an idiom that means he was walking rather than riding a horse or in a chariot. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Jael

This is the name of a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Heber

See how you translated this man's name in [Judges 4:11](./11.md).

#### Kenite

See how you translated this in [Judges 1:16](../01/16.md).

#### Turn aside

This means to change course during a journey in order to rest. AT: "Come here" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### blanket

a large covering for the body to sleep under for warmth, made of wool or animal skins

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Judges 04:19

#### He said to her

"Sisera said to Jael"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]

### Judges 04:21

#### tent peg

a pointed piece of wood or metal, like a large nail, that is hammered into the ground to hold down a corner of a tent

#### hammer

a heavy tool made of wood used to hit a tent peg into the ground

#### a deep sleep

Like a person in a deep hole cannot easily climb out, a person in a deep sleep cannot easily wake up. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### it pierced

"it made a hole"

#### Barak was pursuing

"Barak was chasing" or "Barak was following after"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sleep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 04:23

#### God defeated Jabin, the king of Canaan, before the people of Israel

God causing the Israelites to defeat Jabin and his army is spoken of as is God himself defeated Jabin as the people of Israel watched. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The might

"The military power"

#### they destroyed him

Here "him" refers to Jabin who represents himself and his army. AT: "they destroyed Jabin and his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]

### Judges 04:intro

#### Judges 04 General Notes ####

####### Structure and formatting #######
Chapters 4 and 5 form one section about Barak and Deborah.

####### Special concepts in this chapter #######

######## Barak's leadership ########

At this time, it was very unusual for a woman to be a leader, especially a military leader. Barak lacked the strength to go into battle without Deborah. This indicates that Barak was a poor leader. If a woman won the battle for him, it would have brought Barak shame. It also indicates that Deborah was very well respected. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Judges 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Judges 05

### Judges 05:01

#### On that day

The full meaning of this statement can be made explicit. AT: "On the day the Israelites defeated the army of King Jabin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Deborah

See how you translated this name in [Judges 4:4](../04/04.md).

#### Barak ... Abinoam

See how you translated these names in [Judges 4:6](../04/06.md).

#### when the people gladly volunteer for war

"when the men agree to fight in battle"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 05:03

#### General Information:

Deborah and Barak's song continues using poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]])

#### Listen, you kings! Pay attention, you leaders

Deborah and Barak speak to the kings and leaders as if they were there listening to the song. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### you kings ... you leaders

This refers to kings and leaders in general, not to specific kings or leaders.

#### when you went out from Seir, when you marched from Edom

This refers to the time when the Israelites left Edom to start conquering the people in Canaan. Yahweh empowering his people to defeat the people of Canaan is spoken of as if he were a warrior leading the Israelite army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Seir

Seir is a mountain on the border of the land of Israel and Edom. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the earth shook, and the skies also trembled; also the clouds poured down water

Possible meanings are 1) this is poetic language that emphasizes Yahweh's power by describing it as causing earthquakes and storms or 2) the people of Canaan being terrified as the Israelites were about to attack them is spoken of as if the earth and sky were shaking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Judges 05:05

#### General Information:

Deborah and Barak's song continues using poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]])

#### The mountains quaked

This probably refers to earthquakes and gives the impression that the mountains quaked because they were very afraid of Yahweh. AT: "The mountains trembled in fear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### before the face of Yahweh

Here "face" refers Yahweh's presence. AT: "in the presence of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### even Mount Sinai quaked

When Moses and Israel were at Mount Sinai, it quaked. AT: "long ago, even Mount Sinai quaked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### In the days of

"During the lifetime of"

#### Shamgar ... Anath ... Jael

These are the names of people. See how you translated Shamgar and Anath in [Judges 3:31](../03/31.md) and Jael in [Judges 4:18](../04/17.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### son of Anath

Shamgar's father is mentioned to help identify Shamgar and when he lived. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### the main roads were abandoned

This can be stated in active form and you can make explicit why the roads were abandoned AT: "people stopped using the main roads; because they were afraid of Israel's enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the winding paths

This refers to smaller roads that fewer people traveled on.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]

### Judges 05:07

#### I, Deborah, arose, arose as a mother in Israel

This speaks of Deborah's leadership as if she were the mother of the Israelites. AT: "I took care of the Israelites like a mother takes care of her children" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### they chose new gods

The full meaning of this statement can be made explicit. AT: "the people of Israel worshiped new gods" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### there was fighting at the city gates

Here "gates" represents the entire city. The full meaning of this statement can be made explicit. AT: "enemies attacked the people within the Israelite cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### there were no shields or spears seen among forty thousand in Israel

This statement is probably an exaggeration about how few weapons the Israelites had. AT: "few weapons for battle remained in Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### forty thousand in Israel

"40,000 in Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]

### Judges 05:09

#### My heart goes out to the commanders of Israel

The word "heart" represents a person's emotions. The phrase "My heart goes out to" is a way of saying that Deborah feels gratitude or appreciation. AT: "I appreciate the commanders of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you who ride on white donkeys ... you who walk along the road

This contrast probably refers to rich people and poor people. AT: "you rich people who ride on white donkeys ... you poor people who walk along the road" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### sitting on rugs for saddles

These rugs were probably used as saddles on the donkey's back to make the rider more comfortable.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Judges 05:11

#### General Information:

The song of Deborah and Barak continues.

#### Hear the voices of those

Here "voices" represents the people singing. AT: "Listen to those" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### went down to the city gates

Here "gates" represents the whole city. AT: "returned to their cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Judges 05:12

#### General Information:

Deborah and Barak's song continues using poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]])

#### Awake, awake

Possible speakers are 1) the people of Israel or 2) Deborah who is speaking to herself or 3) the poet who wrote the song.

#### Deborah

See how you translated this name in [Judges 4:4](../04/04.md).

#### Barak ... Abinoam

See how you translated these names in [Judges 4:6](../04/06.md).

#### to me with the warriors

The word "me" refers to Deborah.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 05:14

#### from Ephraim, whose root is in Amalek

The people of Ephraim living in the land where the descendants of Amalek originally lived is spoken of as if the people of Ephraim were planted and their roots grew into the land. AT: "from Ephraim, that land where the descendants of Amalek once lived" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### followed you

Here "you" refers to the people of Ephraim. It can be stated in third person. AT: "followed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Machir

This is the place where the descendants of Machir live. Machir was the son of Manasseh and the grandson of Joseph. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### from Zebulun those who carry an officer's staff

Military leaders are described by the staff, a symbol of their authority. AT: "military leaders from Zebulun" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]

### Judges 05:15

#### My princes in Issachar were with Deborah

Here "My" refers to Deborah. This whole statement can be translated in first person. AT: "My princes in Issachar were with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Deborah

See how you translated this name in [Judges 4:4](../04/04.md).

#### Issachar was with Barak

Here "Issachar" refers to the tribe of Issachar. AT: "the tribe of Issachar was with Barak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Barak

See how you translated this name in [Judges 4:6](../04/06.md).

#### rushing after him into the valley under his command

"obeying his command and rushing after him into the valley"

#### rushing after

"following after" or "hurrying after"

#### there were great searchings of heart

Here "heart" represents thoughts. The people discussing with each other but being unable to decide what they should do is spoken of as if they were searching their heart. AT: "there was a lot of discussing about what they should do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Judges 05:16

#### Why did you sit between the fireplaces, listening to the shepherds playing their pipes for their flocks?

This question is asked to criticize the people of Reuben because they did not decide to come fight in the battle. This can be translated as a statement. AT: "You should have helped us fight, instead of staying at home and listening to the shepherds playing their pipes for their flocks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the fireplaces

Some versions of the Bible have the translation "the sheepfolds" or "the sheep pens."

#### there were great searchings of heart

Here "heart" represents thoughts. The people discussing with each other but being unable to decide what they should do is spoken of as if they were searching their heart. See how you translated this in [Judges 5:15](./15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Judges 05:17

#### Gilead stayed

Here "Gilead" the men from Gilead who should have gone to fight in battle. AT: "The men of Gilead stayed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the other side of the Jordan

This refers to the east side of the Jordan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Dan, why did he wander about on ships?

This question is asked to express anger because the people of the tribe of Dan would not fight for Israel. AT: "the men of Dan should not have remained on their ships!" or "the people of the tribe of Dan did not help us in the battle. Instead they were wandering around on the sea in ships!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Dan, why did he

Here "Dan" represents the men from Dan who should have gone to fight in battle. AT: "the men of Dan, why did they" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### wander about on ships

The tribe of Dan was located near the Mediterranean sea. They sailed on the sea to make money through trade and fishing. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Asher remained on the coast and lived close to his harbors

The full meaning of this statement can be made explicit. AT: "The people of the tribe of Asher also failed to help us, they just remained on the coast near their harbors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Asher remained

Here "Asher" represents the men who should have gone to fight in battle. AT: "The men of Asher remained" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### harbors

places at the seacoast with deeper water where ships were kept

#### Naphtali, also

You can make clear the understood information. AT: "Naphtali was a tribe who would also risk their lives to the point of death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]

### Judges 05:19

#### The kings came, they fought ... the kings of Canaan fought

The king of a people group is used to refer to himself and the army he commands. AT: "The kings and their armies came and fought ... the kings of Canaan and their armies fought" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they fought ... fought

The word "us" is understood. AT: "they fought us ... fought us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Taanach ... Megiddo

Translate the names of these places as you did in [Judges 1:27](../01/27.md).

#### no silver as plunder

Here "silver" represents any treasure in general. AT: "no silver or other treasures as plunder" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### plunder

things taken by force, usually in battle or by thieves

#### From heaven the stars fought, from their paths across the heavens they fought against Sisera

Yahweh helping the Israelite to defeat Sisera and his army is spoken of as if the stars themselves fought against Sisera and his army. This may refer to Yahweh using natural elements, specifically rain storms, to defeat Sisera. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### against Sisera

Here "Sisera" represents himself and his whole army. AT: "Sisera and his army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Sisera

See how you translated this name in [Judges 4:2](../04/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Judges 05:21

#### The Kishon River swept them away

Because of the heavy rain the river flooded quickly causing the chariots to be stuck in the mud and drowning many soldiers. AT: "The Kishon River flooded and swept away Sisera's soldiers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Kishon

See how you translated this in [Judges 4:6](../04/06.md).

#### March on my soul, be strong

Here "soul" refers to the whole person. The word "my" refers to Deborah. AT: "I tell myself to march on and to be strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Then the sound of horses' hooves—galloping, the galloping of his mighty ones

This describes the sound of many horses running away from the battle. AT: "Then I heard the sound of horses running away. Sisera's mighty horses were running away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### galloping

to run quickly

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sweep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sweep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hooves.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hooves.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]

### Judges 05:23

#### Curse Meroz

Here "Meroz" represents the people who lived there. AT: "Curse the people of Meroz" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Meroz

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### inhabitants

the people who live in a place

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md)]]

### Judges 05:24

#### Jael

See how you translated this name in [Judges 4:18](../04/17.md).

#### Heber

See how you translated this name in [Judges 4:11](../04/11.md).

#### Kenite

Translate the name of this people group as you did in [Judges 1:16](../01/16.md).

#### brought him butter

Here "butter" refers to curdled milk. This was the best milk and a favorite drink among Jael's people. AT: "brought him yogurt" or "brought him curds"

#### a dish fit for princes

This phrase means the dish was of the best quality because princes were given the best things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]

### Judges 05:26

#### She put her hand to the tent peg

"Jael grabbed the tent peg with her left hand"

#### tent peg

This is a pointed piece of wood or metal, like a large nail, that is hammered into the ground to hold down a corner of a tent. See how you translated this in [Judges 4:21](../04/21.md).

#### her right hand to the workman's hammer

This can be stated as a complete sentence. AT: "she grabbed a hammer with her right hand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### hammer

This is a heavy tool made of wood used to hit a tent peg into the ground. See how you translated this in [Judges 4:21](../04/21.md).

#### Sisera

See how you translated this man's name in [Judges 4:2](../04/01.md).

#### limp

without strength or movement

#### he was violently killed

This can be stated in active form. AT: "she killed him" or "he died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/skull.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/skull.md)]]

### Judges 05:28

#### the lattice

This is a frame in the window made of crossed wood.

#### Why has it taken his chariot so long to come? Why have the hoofbeats of the horses that pull his chariots been delayed?

Both of these questions mean the same thing. These two statements can be combined. AT: "Why is it taking Sisera so long to arrive home" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### taken his chariot ... Why have the hoofbeats of the horses that pull his chariots

Both of these represent Sisera. AT: "taken Sisera ... Why has he" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hooves.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hooves.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Judges 05:29

#### wisest princesses

A "princess" is the daughter of a king, but a "princess" can also mean female advisers to the king's family. AT: "wisest ladies"

#### she gave herself the same answer

"she said to herself the same thing"

#### Have they not found and divided up the plunder?

The women use a question to emphasize that they believe this is what certainly happened. AT: "They must have so much plunder that it is taking a long time to divide it." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### A womb, two wombs for every man ... of those who plunder?

The women use a question to emphasize that they believe this is what certainly happened. AT: "There must be a womb, two wombs for every man ... of those who plunder." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### A womb, two wombs for every man

Here "womb" represents a woman. Sisera's mother believes Sisera's men have captured many women. AT: "Each soldier will receive a woman or two" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### dyed fabric

"colored cloth" or "colored clothes"

#### embroidered

"nicely stitched"

#### for the necks of those who plunder

Here "necks" represents Sisera's soldiers. AT: "for the soldiers who plunder to wear" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]

### Judges 05:31

#### like the sun when it rises in its might

The people of Israel wish to be like the sun that rises because no nation's army is powerful enough to stop the sunrise. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the land had peace

Here "the land" represents the people of Israel. AT: "and the people of Israel lived peacefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### for forty years

"for 40 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]

### Judges 05:intro

#### Judges 05 General Notes ####

####### Structure and formatting #######

The account of Deborah and Barak continues in this chapter.

Some translations prefer to set apart quotations, prayers or songs. The ULB and many other English translations indent the lines of Chapter 5, which is a song.

####### Other possible translation difficulties in this chapter #######

######## The flood ########

God caused rain and flooding to bog down Jaban's chariots making 
them vulnerable to soldiers on foot, even though it is not said. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Judges 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Judges 06

### Judges 06:01

#### what was evil in the sight of Yahweh

The sight of Yahweh represents Yahweh's judgment or evaluation. See how you translated this in [Judges 2:11](../02/11.md). AT: "what was evil in Yahweh's judgment" or "what Yahweh considered to be evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the hand of Midian

Here "Midian" represents the people of Midian. Also, "hand" represents control. AT: "the control of the people of Midian" or "the control of the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The power of Midian oppressed Israel

Here "the power of Midian" refers to the people of Midian. AT: "The people of Midian were more powerful than the people of Israel and they oppressed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### dens

places in the rocky cliffs that would provide shelter

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]

### Judges 06:03

#### They would set up their army

"The army would encamp" or "The army would set up their tents"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Judges 06:05

#### Whenever they and their livestock and tents came up

The land of Midian was south of the land of Israel, near the Red Sea. It was common to use the phrase "came up" when speaking of traveling from Midian to Israel. AT: "Whenever the Midianites brought their livestock and tents to the land of Israel"

#### they would come as a swarm of locusts

The Midianites are compared to a swarm of locusts because they came in with a great number of people and their livestock ate everything that grew. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### it was impossible to count

This is an exaggeration, a hyperbole, showing the number is very great. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Midian weakened

Here "Midian" represents the people of Midian. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### called out to Yahweh

This is an idiom. AT: "prayed to Yahweh for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 06:07

#### called out to Yahweh

This is an idiom. AT: "prayed to Yahweh for help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### because of Midian

Here "Midian" represents the people of Midian. AT: "because of the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I brought you up from Egypt

"I led you out of Egypt"

#### the house of slavery

Moses speaks of Egypt as if it were a house where people keep slaves. AT: "the place where you were slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Judges 06:09

#### from the hand

In this phrase "hand" represents power or control. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### obeyed my voice

- Here "my voice" represents what Yahweh commanded. AT: "obeyed my command" or "obeyed me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Judges 06:11

#### Now

This word is used here to mark a break in the story line. Here the narrator starts to tell a new part of the story.

#### Ophrah

This is the name of a town. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Abiezrite

This is a people group named after their ancestor Abiezer. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### was separating out the wheat by beating it on the floor

This is a process called "threshing." Gideon was beating the wheat against the floor to separate the wheat grain from the rest of the wheat plant.

#### appeared to him

"went to him"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md)]]

### Judges 06:13

#### my master

Gideon uses the word "master" as a polite way to greet a stranger. He does not realize he is speaking to Yahweh in the form of an angel or a man.

#### Where are all his wonderful deeds that our fathers told us about, when they said, 'Did not Yahweh bring us up from Egypt?'

Gideon uses a question to challenge the stranger's statement that Yahweh was with him. Also, the direct quotation can be stated as an indirect quotation. AT: "We have not seen any wonderful deeds like the ones our fathers told us about when Yahweh brought them up from Egypt." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### gave us into the hand of Midian

The phrase "gave us into" means Yahweh allowed the Israelites to be defeated. AT: "allowed the Midianites to defeat us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### gave us into the hand

Here "hand" represents power or control. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### of Midian

Here "Midian" represents the people of Midian. AT: "of the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]

### Judges 06:14

#### Yahweh looked at him

"Yahweh looked at Gideon"

#### from the hand

Here "hand" represents power or control. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### of Midian

Here "Midian" represents the people of Midian. AT: "of the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Have I not sent you?

Yahweh uses a question to ensure Gideon that he is sending him. Here "sent" means Yahweh has appointed Gideon with a specific task. AT: "I, Yahweh, am sending you!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Please, Lord

Gideon now calls the person "Lord" instead of "my master" as in [Judges 6:13](./13.md). Here it seems Gideon either knows or suspects that he is speaking with Yahweh.

#### how can I deliver Israel?

Gideon uses a question to emphasize that he does not think he can rescue the Israelites. AT: "I cannot possibly rescue the Israelites!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### See, my family

"Look at my family and me and you will see that it"

#### in Manasseh

"in the tribe of Manasseh"

#### in my father's house

Here "house" represents a family. AT: "in my father's family" or "in my family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Judges 06:16

#### I will be with you

Here "be with you" is an idiom that means Yahweh will help and bless Gideon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### as one man

You can state the full meaning explicitly. AT: "as easily as if you were fighting only one man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### set it before you

"place it in front of you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]

### Judges 06:19

#### from an ephah of flour

If it is necessary to use a modern measurement; here is one way of doing it. AT: "with 22 liters of flour" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### broth

water that has had food, such as meat, cooked in it

#### them to him

"them to the angel of God"

#### angel of God

This is the same as the angel of Yahweh. AT: "God, who was in the form of an angel" or "God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/basket.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Judges 06:21

#### angel of Yahweh

In 6:11-24 Yahweh appears to Gideon in the form of an angel. See how you translated this in [Judges 6:11](./11.md).

#### went away

"disappeared"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/staff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/unleavenedbread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/consume.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]

### Judges 06:22

#### angel of Yahweh

In 6:11-24 Yahweh appears to Gideon in the form of an angel. See how you translated this in [Judges 6:11](./11.md).

#### Ah, Lord Yahweh!

The word "Ah" here shows that Gideon was very frightened. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclamations.md)]])

#### seen the angel of Yahweh face to face

This phrase refers to two people being close to each other. AT: "really seen the angel of Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh said to him

Apparently Yahweh spoke to Gideon from heaven. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### To this day

This means to the time when the book of Judges was written.

#### Ophrah

Translate the name of this town as you did in [Judges 6:11](./11.md).

#### the clan of Abiezer

Translate the name of this people group as you did in [Judges 6:11](./11.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Judges 06:25

#### a second bull

The word "second" is the ordinal number for "two." AT: "another bull" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### that is beside it

"that is beside the altar of Baal"

#### on the top of this place of refuge

The city of Ophrah was on top of a hill. Israelites fled there for refuge from the Midianites.

#### construct it the correct way

"place the stones in an orderly manner" or "and build it properly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]

### Judges 06:27

#### did as Yahweh had told him

This refers to Yahweh's command in [Judges 6:25-26](./25.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]

### Judges 06:28

#### got up

"got up out of bed" or "woke up"

#### the altar of Baal was broken down, and the Asherah that was beside it was cut down, and the second bull had been offered on the altar that had been built

This can be stated in active form. AT: "they noticed that someone had broken down the altar of Baal, cut down the Asherah that was beside it, and built an altar and sacrificed the second bull on it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]

### Judges 06:30

#### he may be put to death

This can be stated in active form. AT: "we may kill him as punishment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asherim.md)]]

### Judges 06:31

#### Will you plead the case for Baal?

Joash uses a question to emphasize that a human should not have to defend a god. AT: "You should not have to defend Baal." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### plead the case

"make a defense" or "give an excuse"

#### Will you save him?

Joash uses a question to emphasize that a human should not have to rescue a god. AT: "You should not have to save Baal." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Jerub Baal

This is another name for Gideon. It means "let Baal defend himself." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### because he said

"because Joash said"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]

### Judges 06:33

#### Now

This word is used here to mark a break in the story line. Here the narrator starts to tell a new part of the story.

#### gathered together

The full meaning of this statement can be made explicit. AT: "gathered together as an army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezreel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezreel.md)]]

### Judges 06:34

#### came over Gideon

This is an idiom. AT: "took control of Gideon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### clan of Abiezer

Translate the name of this people group as you did in [Judges 6:11](./11.md).

#### so they might follow him

The words "to battle" are understood. AT: "so they might follow him to battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### and they too, were called out to follow him

This can be stated in active form. AT: "calling them out to follow him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to Asher, Zebulun, and Naphtali

These all represent the people of each tribe. AT: "to the tribes of Asher, Zebulun, and Naphtali" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]

### Judges 06:36

#### woolen fleece

the woolly coat of a sheep

#### dew

water that forms on plants during the night

#### then I will know that you will

The full meaning of this statement can be made explicit. AT: "this will be a sign from you, and then I will know that you will" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]

### Judges 06:38

#### Gideon rose

"Gideon got out of bed"

#### wrung

twist and squeeze something to remove water

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Judges 06:39

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]

### Judges 06:intro

#### Judges 06 General Notes ####

####### Structure and formatting #######

This chapter begins a section about Gideon. (Chapters 6-8)

######## Special concepts in this chapter ########

######## Israel's punishment ########
In Judges, Israel's actions are connected to their obedience to Yahweh. When Israel does evil, they are oppressed. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]])

##### Links: #####

* __[Judges 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Judges 07

### Judges 07:01

#### Jerub Baal

This is another name for Gideon. See how you translated his name in [Judges 6:32](../06/31.md).

#### they encamped

"they set up their camp"

#### spring of Harod ... hill of Moreh

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The camp of Midian was to their north

Here "Midian" represents the Midianite army. AT: "The Midianite army set up their camp to the north of the Israelite army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]

### Judges 07:02

#### for me to give you victory over the Midianites

The word "victory" is an abstract noun that can be translated as a verb or an adjective. AT: "for me to allow you to defeat the Midianites" or "for me to cause you to be victorious over the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Our own power has saved us

Here "power" represents the people themselves. AT: "We have saved ourselves without God's help" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### proclaim in the ears of the people

Here "the ears" refers to the whole person. AT: "proclaim to the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Whoever is afraid, whoever trembles

Both of these phrases have the same meaning. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### trembles

This word describes fear that causes a person to uncontrollably shake. AT: "shakes with fear"

#### let him return

You can make explicit where he will go. AT: "let him return to his home" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Mount Gilead

This is the name of a mountain in the region of Gilead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### twenty-two thousand

"22,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### ten thousand remained

The word "people" or "men" is understood. AT: "10,000 people remained" or "10,000 men remained" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### ten thousand

"10,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/boast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Judges 07:04

#### I will make their number smaller for you there

Here "number" represents the army. The full meaning of this statement can be made explicit. AT: "there, I will show you who to send home so the army will have less men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Judges 07:05

#### Gideon brought

The word "brought" can be translated as "took" or "led." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md)]])

#### laps

to drink by licking with the tongue

#### Three hundred men

"300 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 07:07

#### three hundred men

"300 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### I will rescue you and give you victory

Here "you" is plural and refers to Gideon and the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### So those who were chosen

This can be stated in active form. AT: "So those whom Yahweh chose" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### took their supplies and their trumpets

Here "their" refers to the Israelite soldiers who were leaving the army.

#### Now

This word is used here to mark a break in the story line. Here the narrator starts to tell a new part of the story.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]

### Judges 07:09

#### Attack the camp, for I am going to give you victory over it

Here "camp" refers to the whole Midianite army. The word "victory" is an abstract noun that can be translated as a verb or an adjective. AT: "Attack the Midianites at their camp, for I am going to help you defeat them" or "Attack the Midianites at their camp, for I am going to cause you to be victorious over them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### afraid to go down

You can make clear the understood information. AT: "afraid to go down to attack" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Purah

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### your courage will be strengthened

This can be stated in active form. AT: "what you hear will be encourage you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### guard posts

places around the edge of an area where soldiers stand to watch for an enemy army

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]

### Judges 07:12

#### as thick as a cloud of locusts

Here "cloud" means a swarm. The author speaks of the army as if it were a swarm of locusts to emphasize how many soldiers there were. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Their camels were more ... in number than the grains of the sand on the seashore

The author uses a hyperbole, an exaggeration, to emphasize that there were very many camels. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Their camels were more than could be counted

This can be stated in active form. AT: "Their camels were more than anyone could count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/locust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]

### Judges 07:13

#### This is nothing other than the sword of Gideon

Here "the sword of Gideon" refers to Gideon's army attacking. AT: "The loaf of barley bread in your dream must be the army of Gideon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### God has given him victory over Midian

This future event is spoken of as if it were a past event. This emphasizes that it will certainly happen. AT: "God will certainly help the Israelites defeat the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pastforfuture.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Judges 07:15

#### three hundred men

"300 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/interpret.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Judges 07:17

#### For Yahweh and for Gideon!

The words "we fight" are implied. AT: "We fight for Yahweh and for Gideon!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]

### Judges 07:19

#### hundred men

"100 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### right at the beginning of the middle watch

The beginning of the middle watch would be around 10 o'clock at night.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimewatch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimewatch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Judges 07:20

#### The sword of Yahweh and of Gideon

Here "sword" refers to their fighting. AT: "We fight for Yahweh and for Gideon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/run.md)]]

### Judges 07:22

#### three hundred trumpets

"300 trumpets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Yahweh set every Midianite man's sword against his comrades

Here "sword" refers to their attack with the use of the sword. AT: "Yahweh caused every Midianite man to fight against his fellow soldiers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Beth Shittah ... Zererah ... Abel Meholah ... Tabbath

These are the names of towns and cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The men of Israel from Naphtali, Asher, and all Manasseh were called out

This can be stated in active form. AT: "Gideon called out the Israelites from the tribes of Naphtali, Asher, and all Mannasseh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]

### Judges 07:24

#### Beth Barah

This is the name of a town. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### took control of the waters, as far as Beth Barah and the Jordan River

"took control of the area of the Jordan River as far south as Beth Barah"

#### at the rock of Oreb ... at the winepress of Zeeb

The places were given these names after the Israelites killed Oreb and Zeeb there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Oreb ... Zeeb

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]

### Judges 07:intro

#### Judges 07 General Notes ####

####### Structure and formatting #######

The account of Gideon continues in this chapter. 

####### Special concepts in this chapter #######

######## God gets all of the credit ########

God said, "There are too many soldiers for me to give you victory over the Midianites. Make sure that Israel will not boast against me, saying, 'Our own power has saved us.'" By lowering the number of fighting soldiers, it emphasizes that the victory is achieved through God's power. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]])

##### Links: #####

* __[Judges 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Judges 08

### Judges 08:01

#### What is this you have done to us?

The people of the tribe of Ephraim were rebuking Gideon with this rhetorical question for not including them in his army. This can be expressed as a statement. AT: "You have not treated us fairly." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### against Midian

Here "Midian" represents the Midianite army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they had a violent argument with him

they argued angrily with him" or "they rebuked him severely"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]

### Judges 08:02

#### General Information:

Gideon replies to the men from Ephraim.

#### What have I done now compared to you?

Gideon uses this question to honor the people of Ephraim. AT: "I have done very little compared with what you have done!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Are not the gleanings of Ephraim's grapes better than the full grape harvest of Abiezer?

Gideon was calming the people of Ephraim with this rhetorical question. AT: "Certainly the grapes you people of Ephraim gleaned are better than what we the descendants of Abiezer gathered from the whole harvest!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Are not the gleanings of Ephraim's grapes better than the full grape harvest of Abiezer?

Gideon and his army defeating the Medianites is spoken of as if it were a grape harvest. The people of Ephraim killing Oreb and Zeeb at the end of the battle is spoken of as if they were gleaning grapes at the end of the harvest. AT: "What you people of Ephraim did at the end of the battle is more important than what we descendants of Abiezer did at the beginning." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Abiezer

This is the name of one of Gideon's ancestors. Gideon used his name to refer to Abiezer's descendants and their land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Oreb and Zeeb

See how you translated these names in [Judges 7:25](../07/24.md).

#### What have I accomplished compared to you?

Gideon uses this question to honor the people of Ephraim. This can be expressed as a statement. AT: "What you have done is more important than what I have done." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### died down

"became less"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/glean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Judges 08:04

#### the three hundred men

"the 300 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### kept up the pursuit

The word "pursuit," an abstract noun, can be expressed as a verb. AT: "continued to chase their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Zebah and Zalmunna

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]

### Judges 08:06

#### Are the hands of Zebah and Zalmunna now in your hand?

The leaders use a question to emphasize that the Israelites have not yet captured Zebah and Zalumnna. AT: "You have not captured Zebah and Zalmunna yet." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Are the hands of Zebah and Zalmunna

Here "hands" refer to the whole body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### now in your hand

Here "hand" represents power or control. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Why should we give bread to your army?

The leaders use a question to emphasize that they have no reason to give bread to the Israelites. AT: "We see no reason to give bread to your army." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will tear your skin with the desert thorns and briers

The full meaning of this statement can be made explicit. AT: "I will make whips out of desert thorns and briers and use them to beat you and cut you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### thorns and briers

sharp, pointed pieces on vines or tree limbs that stick out and can cut people and animals

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]

### Judges 08:08

#### He went up from there

Here "He" refers to Gideon. Gideon represents himself and the soldiers following him. AT: "They left there" or "Gideon and his 300 men left there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Peniel

The name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### spoke to the people there in the same way

You can make clear the understood information. AT: "asked for food there in the same way" or "he also asked them for food" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### When I come again in peace

This is a polite way of referring to the defeat of his enemies. AT: "After I have completely defeated the Midian army" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### I will pull down this tower

Here "I" refers to Gideon and represents himself and his men. AT: "My men and I will pull down this tower" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]

### Judges 08:10

#### Now

This word is used here to mark a break in the story line. Here the narrator starts to tell a new part of the story.

#### Zebah and Zalmunna

See how you translated these names in [Judges 8:5](./04.md).

#### Karkor

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### fifteen thousand men

"15,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### had fallen

This is a polite way of referring to people who died in battle. AT: "had been killed" or "had died in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### 120,000 men

"one hundred thousand men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### men who drew the sword

Here drawing the sword represents using the sword in battle. Possible meanings are 1) this phrase refers to soldiers who use swords in battle. AT: "swordsmen" or "men who fought with swords" or 2) this phrase refers to any soldiers. AT: "soldiers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Judges 08:11

#### Gideon went up

Here "Gideon" represents himself and all of his soldiers. AT: "Gideon and his soldiers went up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### He defeated

Here "He" refers to Gideon and represents himself and all of his soldiers. AT: "Gideon and his soldiers defeated" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Nobah and Jogbehah

These are names of towns. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zebah and Zalmunna

See how you translated these names in [Judges 8:5](./04.md).

#### panic

extreme fear or worry that makes someone unable to think or act normally

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]

### Judges 08:13

#### the pass of Heres

This is the name of a road that passes between two mountains. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He ran into a young man

This is an idiom. AT: "He met a young man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### sought advice from him

It can be stated explicitly what Gideon asked the young man. AT: "he asked him to identify all the names of the leaders in the town" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### seventy-seven men

"77 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Judges 08:15

#### Zebah and Zalmunna

See how you translated these names in [Judges 8:5](./04.md).

#### Have you already conquered Zebah and Zalmunna?

Gideon quotes the people of Succoth as using a question to mock him. AT: "You have not yet conquered Zebah and Zalmunna." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Gideon took ... he punished ... he pulled

Here "Gideon" represents himself and his soldiers. AT: "Gideon and his soldiers took ... they punished ... they pulled" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### thorns and briers

These are sharp, pointed pieces on vines or tree limbs that stick out and can cut people and animals. See how you translated this in [Judges 8:7](./06.md).

#### Peniel

Translate the name of this city as you did in [Judges 8:8](./08.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/succoth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]

### Judges 08:18

#### Zebah and Zalmunna

See how you translated these names in [Judges 8:5](./04.md).

#### Tabor

Translate the name of this city as you did in [Judges 4:6](../04/06.md).

#### As you are, so were they

"They were just like you"

#### As Yahweh lives

This idiom is a religious oath used for emphasis that what he is about to say is true. AT: "I promise you that" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]

### Judges 08:20

#### Jether

This is the name of Gideon's son. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### For as the man is, so is his strength

This is an idiom. AT: "It is a job for a man to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### crescent

This is a curved shape with two points. This shape occurs when the moon is mostly covered in shadow.

#### ornaments

"decorations"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]

### Judges 08:22

#### you, your son, and your grandson

This implies that they want Gideon's descendants to rule over them after he dies. AT: "you and your descendants after you die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### out of the hand of Midian

Here "hand" represents the power of Midian over Israel. AT: "from the power of Midian" or "from Midian" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### of Midian

Here "Midian" represents the people of Midian. AT: "of the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 08:24

#### Gideon said to them

"Gideon said to the men of Israel"

#### earrings

jewelry worn on the ear

#### plunder

things stolen by force or taken off of people killed in war

#### The Midianites had golden earrings because they were Ishmaelites

Here the narrator tells background information about the Midianites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### cloak

clothing made from a large piece of fabric and worn over the shoulders as a coat

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ishmael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ishmael.md)]]

### Judges 08:26

#### 1,700 shekels of gold

"one thousand seven hundred shekels of gold." If it is necessary to use modern weight units, here are two ways of doing it. AT: "18.7 kilograms of gold" or "about 20 kilograms of gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### crescent ornaments

See how you translated this in [Judges 8:21](./20.md).

#### pendants

pieces of jewelry that hang at the end of the chains or cords of necklaces

#### that was worn by the kings of Midian

This can be stated in active form. AT: "that the kings of Midian wore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]

### Judges 08:27

#### Gideon made an ephod out of the earrings

"Gideon used the gold from the earrings to make an ephod"

#### Ophrah

Translate the name of this city as you did in [Judges 6:11](../06/11.md).

#### all Israel prostituted themselves by worshiping it there

This speaks of worshiping a false god as if it were prostitution. AT: "the Israelites sinned against Yahweh by worshiping the ephod there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### all Israel

Here "all" is an exaggeration to emphasize that very many worshiped the garment. AT: "very many people in Israel worshiped the garment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### It became a trap for Gideon and for those in his house

This speaks of Gideon and his family being tempted to worship the ephod as if the ephod were a hunter's snare that would trap them. AT: "It became a temptation for Gideon and his family" or "Gideon and his family sinned by worshiping it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for those in his house

Here "his house" represents Gideon's family. AT: "for his family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### So Midian was subdued before the people of Israel

This can be stated in active form. AT: "So Yahweh subdued the Midianites before the people of Israel" or "So Yahweh helped the Israelites defeat the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they did not raise their heads up again

This is an idiom. AT: "they did not attack Israel again" (See:[[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### So the land had peace

Here "land" represents the people of Israel. AT: "So the Israelites lived peacefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### forty years

"40 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### in the days of Gideon

"during the life of Gideon"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Judges 08:29

#### Jerub Baal

This is another name for Gideon. See how you translated his name in [Judges 6:32](../06/31.md).

#### seventy sons

"70 sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]

### Judges 08:32

#### a good old age

This is an idiom. AT: "when he was very old" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### was buried

This can be stated in active form. AT: "they buried him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Ophrah

Translate the name of this city as you did in [Judges 6:11](../06/11.md).

#### the clan of Abiezer

Translate the name of this people group as you did in [Judges 6:11](../06/11.md).

#### It came about

This phrase is used here to mark the beginning of a new part of the story. If your language has a way for doing this, you could consider using it here.

#### turned again

The people rejecting Yahweh is spoken of as if they physically turned away from him. AT: "they stopped worshiping Yahwheh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### prostituted themselves by worshiping the Baals

This speaks of worshiping false gods as if it were prostitution. AT: "they sinned against Yahweh by worshiping the Baals" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Baal-Berith

This is the name of a false god. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joash.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Judges 08:34

#### from the hand of all their enemies

Here "hand" represents power or control. AT: "from the power of all their enemies" or "from all their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### on every side

"who surrounded them"

#### the house of Jerub Baal

Here "the house of" represents a person's family. AT: "the family of Jerub Baal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Jerub Baal

This is another name for Gideon. See how you translated this in [Judges 6:32](../06/31.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gideon.md)]]

### Judges 08:intro

#### Judges 08 General Notes ####

####### Structure and formatting #######

The account of Gideon concludes in this chapter. 

####### Special concepts in this chapter #######

######## Succoth's refusal to help Gideon ########
The men of Succoth feared the Midianites more than Gideon. This is why they refused to help Gideon. By allying themselves with the Midianites, they aligned themselves against Yahweh. Because of this, Gideon treated them like he treated the Midianites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Gideon refuses to be king ########

Gideon said to them, "I will not rule over you, neither will my son rule over you. Yahweh will rule over you." Although the book of Deuteronomy anticipates a king in Israel, it was sinful for Israel to desire to have a king. He did though take a share of everyone's plunder as a king would have done through taxes. This may serve as a warning to Israel about their desire to have a king. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Judges 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Judges 09

### Judges 09:01

#### Jerub Baal

This is another name for Gideon. See how you translated this in [Judges 6:32](../06/31.md).

#### Please say this, so that all the leaders in Shechem may hear, 'Which is better for you, that all seventy sons of Jerub Baal rule over you, or that just one rule over you?'

This has a quotation within a quotation. A direct quotation can be stated as an indirect quotation. AT: "Please ask the leaders of Shechem if they would rather have all seventy sons of Jerub Baal rule over them, or if they would rather have just one of his sons rule over them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotesinquotes.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### I am your bone and your flesh

Here "your bone and your flesh" represents being someone's relative. AT: "I am a member of your family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Judges 09:03

#### His mother's relatives spoke for him to the leaders

This means that the relatives of the mother of Abimelech spoke to the leaders, suggesting that they make Abimelech their king.

#### they agreed to follow Abimelech

"they agreed to let Abimelech be their leader"

#### the house

Here "house" represents a temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### seventy pieces of silver

This means seventy shekels of silver. A shekel weighs 11 grams. If it is necessary to translate this with modern measurements, you can translate it like this. AT: "almost one kilo of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Baal-Berith

This is the name of a false god. See how you translated it in [Judges 8:33](../08/32.md).

#### lawless and reckless

"violent and foolish"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]

### Judges 09:05

#### Ophrah

Translate the name of this city as you did in [Judges 6:11](../06/11.md).

#### one stone

"1 stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Jerub Baal

This is another name for Gideon. See how you translated this in [Judges 6:32](../06/31.md).

#### Beth Millo

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]

### Judges 09:07

#### General Information:

Jotham begins telling a parable where trees represent various people groups. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]])

#### When Jotham was told about this

This can be stated in active form. AT: "When Jotham heard that Abimelech had murdered his brothers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Mount Gerizim

This is a mountain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The trees once went out to anoint a king over them. For they said to the olive tree, 'Reign over us.'

In this parable Jotham describes the trees doing things that humans do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### to anoint a king over them

Here, to anoint with oil is a symbolic action that represents appointing a person to be king. AT: "to appoint a king to rule over all of them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### Reign over us

"Be our king"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]

### Judges 09:09

#### General Information:

Jotham continues telling his parable, where trees represent various people groups.

#### the olive tree said to them ... fig tree said to them

In this parable, Jotham describes the trees as doing things that humans do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Should I give up my oil ... over the other trees?

The olive tree is asking this question to refuse to be king. This question can be expressed as a statement. AT: "I will not give up my oil ... over the other trees." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### sway over

To "sway over" means to move back and forth in the wind. Here the tree uses this phrase to means to "rule over."

#### Should I give up my sweetness ... over the other trees?

The fig tree is asking this question to refuse to be king. This question can be expressed as a statement. AT: "I will not give up my sweetness ... over the other trees." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### my sweetness and my good fruit

The word "sweetness" is an abstract noun. It can be stated as an adjective that describes the fruit that grows on the tree. AT: "my good sweet fruit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]

### Judges 09:12

#### General Information:

Jotham continues telling his parable, where trees represent various people groups.

#### The trees said to the vine

In this parable, Jotham describes the trees and the vine as doing things that humans do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Should I give up my new wine ... over the other trees?

The vine is asking this question to refuse to be king. This question can be expressed as a statement. AT: "I will not give up my new wine ... over the other trees." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### thornbush

Thorns are sharp spikes or spurs that hurt. This bush has many sharp spikes along its branches.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thorn.md)]]

### Judges 09:15

#### General Information:

Jotham continues telling his parable, where trees represent various people groups, and makes the application.

#### The thornbush said to the trees

In this parable, Jotham describes the thornbush and the trees as doing things that humans do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parables.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### to anoint me as king over you

To anoint someone with oil is a symbolic action that appoints a person to be king. AT: "to appoint me as your king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### find safety

The word "safety" is an abstract noun that can be expressed as an adjective. AT: "be safe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### fire come out of the thornbush and let it burn up the cedars of Lebanon

This means to let the thornbush burn so that it will burn the cedars.

#### then let fire come out of the thornbush

The thornbush refers to itself as "the thornbush." AT: "then may fire come out from me, the thornbush" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### if you have done well concerning Jerub Baal and his house, and if you have punished him as he deserves

Jotham offered the possibility that what they did was good, but Jotham does not actually believe what they did was good. AT: "if you have done what is right and Jerub Baal deserved for you to kill all of his sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### Jerub Baal

This is another name for Gideon. See how you translated this in [Judges 6:32](../06/31.md).

#### his house

Here "house" represents Gideon's family. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cedar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/lebanon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Judges 09:17

#### General Information:

Jotham makes the application to the situation at that time and place.

#### to think that my father fought for you ... out of the hand of Midian

Here Jotham is expressing that he cannot believe how badly the people of Shechem have treated Gideon and his family even after Gideon fought to save the people of Shechem.

#### out of the hand of Midian

Here "hand" represents power or control. AT: "from the power of the Midianites" or "from the Midianites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you have risen up against

This is an idiom. AT: "you have opposed" or "you have rebelled against" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### my father's house

Here "house" represents family. AT: "my father's family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### one stone

"1 stone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### his female servant

Here "his" refers to Gideon.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/midian.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]

### Judges 09:19

#### If you acted with honesty and integrity with Jerub Baal and his house

Jotham offered the possibility that what they did was good, but Jotham does not actually believe what they did was good. AT: "If you treated Jerub Baal and his family as they deserved to be treated" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### Jerub Baal

This is another name for Gideon. It means "let Baal defend himself." See how you translated this in [Judges 6:32](../06/31.md).

#### his house

Here "house" refers to family. AT: "his family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### But if not

Jotham offered the opposite possibility that what they did was evil and applied a curse. Jotham does believe what they did was evil. AT: "But if you treated Jerub Baal and his family as they did not deserve to be treated" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hypo.md)]])

#### let fire come out from Abimelech and burn up the men of Shechem

Jotham is speaking a curse. He speaks of Abimelech destroying the people of Shechem as if he would burn them with fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let fire come out from the men of Shechem and Beth Millo, to burn up Abimelech

Jotham is speaking a curse. He speaks of the people of Shechem and Beth Millo destroying Abimelech as if they would burn him with fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Beth Millo

This is the name of a place. See how you translated this in [Judges 9:6](./05.md).

#### Beer

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/integrity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md)]]

### Judges 09:22

#### three

"3" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### God sent an evil spirit between Abimelech and the leaders of Shechem

This means that God applied the curse Jotham made by sending an evil spirit to cause trouble and animosity between Abimelech and the leaders of Shechem.

#### God did this so the violence done ... helped him murder his brothers

The passive phrases can be stated in active form. AT: "God did this to avenge the seventy sons whom Abimelech their brother murdered and the men of Shechem helped murder" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Jerub Baal

This is another name for Gideon. See how you translated this in [Judges 6:32](../06/31.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/betray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]

### Judges 09:25

#### positioned men to lie in wait on the hilltops that they might ambush him

"sent men to hide on the hilltops and wait to attack Abimelech"

#### This was reported to Abimelech

This can be stated in active form. AT: "Someone told Abimelech about the men waiting to attack him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]

### Judges 09:26

#### Gaal ... Ebed

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### had confidence in him

The word "confidence" is an abstract noun that can be stated with the verb "trust." AT: "trusted him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### They went out into the field

Here "They" refers to Gaal and his relatives and the men of Shechem.

#### they trampled on them

They did this to squeeze out the grape juice to make wine with it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### trampled

"crushed" or "stomped"

#### in the house

Here "house" represents a temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/confidence.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]

### Judges 09:28

#### Gaal ... Ebed

See how you translated these names in [Judges 9:26](./26.md).

#### Who is Abimelech, and who is Shechem, that we should serve him?

Gaal uses a question to emphasize that the people of Shechem should not serve Abimelech. AT: "We should not serve Abimelech!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Who is Abimelech, and who is Shechem, that we should serve him?

Both of these questions means the same thing. Gaal refers to Abimelech as "Shechem" because Abimelech's mother was from Shechem. AT: "We should not serve Abimelech, that is, Shechem!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Is he not the son of Jerub Baal? Is Zebul not his officer?

Gaal uses a question to emphasize that the people of Shechem should not serve Abimelech. AT: "He is just the son of Jerub Baal, and Zebul is just his officer." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Jerub Baal

This is another name for Gideon. See how you translated this in [Judges 6:32](../06/31.md).

#### Zebul

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Serve the men of Hamor, Shechem's father

Gaal means the people of Shechem should serve those who descended from Hamor, that is, those who are truly Canaanites, and not serve someone whose father was an Israelite.

#### Why should we serve Abimelech?

Gaal uses a question to emphasize that the people of Shechem should not serve Abimelech. AT: "We should not serve Abimelech!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I wish that this people were under my command

"I wish that I ruled the people of Shechem"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hamor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Judges 09:30

#### Zebul

See how you translated this name in [Judges 9:28](./28.md).

#### heard the words of Gaal son of Ebed

"heard what Gaal son of Ebed said"

#### Gaal ... Ebed

See how you translated these names in [Judges 9:26](./26.md).

#### his anger was kindled

Becoming angry is spoken of as if a fire were starting. AT: "he became very angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in order to deceive

Zebul is deceiving Gaal and the people of Shechem. AT: "secretly"

#### they are stirring up the city against you

This speaks of the people of the city becoming upset as if they were liquid in a pot moving around. AT: "they are persuading the people of the city to rebel against you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the city

Here "city" represents the people of the city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]

### Judges 09:32

#### General Information:

Zebul's messengers continue talking to Abimelech.

#### Now

This does not mean "at this moment," but is used to draw attention to the important point that follows.

#### an ambush

"to hide and attack them suddenly"

#### do whatever you can to them

This means that they can do what they want to destroy the followers of Gaal.

### Judges 09:34

#### all the men who were with him

"all the men accompanying Abimelech" or "all the men fighting for Abimelech"

#### they set an ambush against Shechem

Here "Shechem" represents the people of Shechem. AT: "they hid in order to attack the people of Shechem by surprise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### dividing into four units

"separating into 4 groups" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Gaal ... Ebed

See how you translated these names in [Judges 9:26](./26.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Judges 09:36

#### Gaal

This is the name of a man. See how you translated this in [Judges 9:26](./26.md).

#### Zebul

This is the name of a man. See how you translated this in [Judges 9:28](./28.md).

#### You are seeing the shadows on the hills like they are men

Zebul is trying to confuse Gaal and keep him from preparing for battle. AT: "That is not people, it is only shadows on the hills"

#### one unit

"1 group" or "1 troop" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oak.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/divination.md)]]

### Judges 09:38

#### Zebul

See how you translated this name in [Judges 9:28](./28.md).

#### Where are your proud words now, you

Zebul is scolding Gaal with this rhetorical question. AT: "You are not speaking proudly now, you" or "You are not proud now, you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### you who said, 'Who is Abimelech that we should serve him?'

Zebul is quoting Gaal's boast back to Gaal. This can be translated as a statement and as an indirect quote. AT: "you who said that we should not serve Abimelech." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-quotations.md)]])

#### Are these not the men you despised?

Zebul is challenging Gaal with this rhetorical question. This question can be translated as a statement. AT: "Here are the men that you despised." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### despised

strongly disliked or hated

#### Gaal

See how you translated this name in [Judges 9:26](./26.md).

#### Many fell with deadly wounds

This is an idiom. AT: "And many men died of wounds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Judges 09:41

#### Arumah

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zebul

This is the name of a man. See how you translated this in [Judges 9:28](./28.md).

#### Gaal

This is the name of a man. See how you translated this in [Judges 9:26](./26.md).

#### this was reported to Abimelech

This can be stated in active form. AT: "someone reported this to Abimelech" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### divided them into three units

"separated them into 3 groups" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### they set an ambush in the fields

"they hid in the fields to attack the people by surprise"

#### he attacked

Here "he" refers to Abimelech who represents himself and all of his soldiers. AT: "they attacked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]

### Judges 09:44

#### the units

"the groups of soldiers"

#### other two

"other 2" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Abimelech fought ... He tore down

Here "Abimelech" represents himself and his soldiers. AT: "Abimelech and his soldiers fought ... They tore down" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### against the city

Here "city" represents the people. AT: "against the people of Shechem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### tore down

"demolished"

#### spread salt over it

"spread salt over the land." Spreading salt over land keeps anything from growing there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Judges 09:46

#### the house

Here this represents a temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### El-Berith

The word "El" means "god." This is the same false god as "Baal-Berith" in [Judges 8:33](../08/32.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Abimelech was told

This can be stated in active form. AT: "Someone told Abimelech" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stronghold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]

### Judges 09:48

#### Mount Zalmon

This is the name of a mountain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### piled

This means to stack the branches into a large heap.

#### about a thousand men

"about 1,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ax.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]

### Judges 09:50

#### Thebez

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### encamped against Thebez

"camped outside the city of Thebez"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]

### Judges 09:52

#### fought against it

"attacked it"

#### upper millstone

Two large, flat, round stones were used to grind grain in a mill. An upper millstone was the top one that was rolled on the lower one to crush the grain in between them.

#### armor-bearer

This is the man who carried the weapons of Abimelech.

#### pierced him through

This means the young man put the sword right through the body of Abimelech.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 09:55

#### seventy

"70" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### made all the evil of the men of Shechem turn back on their own heads

"Evil turn back on their heads" here is an idiom. AT: "punished the men of Shechem for all the evil they had done" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### on them came the curse of Jotham son of Jerub Baal

This is an idiom. AT: "the curse of Jotham son of Jerub Baal happened to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Jerub Baal

This is another name for Gideon. See how you translated this name in [Judges 6:32](../06/31.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jotham.md)]]

### Judges 09:intro

#### Judges 09 General Notes ####

####### Special concepts in this chapter #######

######## Jotham's curse ########

Gideon's son, Abimelech, killed all of his brothers except Jotham in order to become king of Shechem. Jotham cursed Abimelech for having murdered Gideon's other sons. "Let fire come out from Abimelech and burn up the men of Shechem and the house of Millo. Let fire come out from the men of Shechem and Beth Millo, to burn up Abimelech." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]])

=##### Important figures of speech in this chapter #####

######## Tree metaphor ########
This chapter contains an extended metaphor about trees. This metaphor functions as a parable instructing Israel about their sinful desire to have a king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

##### Links: #####

* __[Judges 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Judges 10

### Judges 10:01

#### Tola ... Puah ... Dodo

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shamir

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### arose to deliver Israel

"came to deliver Israel" or "became the leader to deliver Israel"

#### deliver Israel

Here "Israel" represents the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He judged Israel

Here "judged" means he led the people of Israel.

#### twenty-three years

"23 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### was buried

This can be stated in active form. AT: "they buried him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abimelech.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 10:03

#### He was followed by Jair the Gileadite

This can be stated in active form. AT: "Jair the Gileadite was leader after Tola" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Jair

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Gileadite

Jair was from the tribe of Gilead.

#### He judged Israel

Here "judged" means he led the people of Israel.

#### Israel

Here "Israel" represents the people of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### twenty-two years

"22 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### thirty sons

"30 sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Havvoth Jair

This is the name of a region, which is named after a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### to this day

This means to the time when the book of Judges was being written.

#### was buried

This can be stated in active form. AT: "they buried him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Kamon

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Judges 10:06

#### added to the evil they had done in the sight of Yahweh

This speaks of evil as if it were an object that a person could add to and make bigger. AT: "continued doing what Yahweh said was evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the sight of Yahweh

The sight of Yahweh represents Yahweh's judgment or evaluation. AT: "according to Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Ashtoreths

This is the plural of Ashtoroth, who was worshiped as a goddess in many different forms. See how you translated this in [Judges 2:13](../02/11.md).

#### They abandoned Yahweh and no longer worshiped him

The author basically said the same thing twice for emphasis. These can be combined. AT: "They completely stopped worshiping Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### They abandoned Yahweh

No longer obeying and worshiping Yahweh is spoken of as if the people left Yahweh and went somewhere else. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Yahweh burned with anger toward Israel

Yahweh becoming angry is spoken of as if anger were a burning fire. AT: "Yahweh was very angry at Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he sold them into the hand of the Philistines and into the hand of the Ammonites

Yahweh allowing the Philistines and the Ammonites to defeat the Israelites is spoken of as if he sold the Israelites to them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### into the hand

Here "hand" represents power or control. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aram.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Judges 10:08

#### crushed and oppressed

These two words basically mean the same and emphasize how much the Israelites suffered. AT: "terribly oppressed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### eighteen years

"18 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### who were beyond the Jordan

This means on the east side of the Jordan River.

#### which is in Gilead

"this region is also called Gilead"

#### Judah ... Benjamin

"Judah" and "Benjamin" refer to the people belonging to those tribes. AT: "the people of the tribe of Judah ... the people of the tribe of Benjamin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### house of Ephraim

The "house" refers to the people of the tribe of Ephraim. AT: "the people of the tribe of Ephraim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### so that Israel was greatly distressed

"Israel" refers to the people of Israel. AT: "so that the people of Israel suffered much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]

### Judges 10:10

#### the people of Israel called out to Yahweh

This means the people of Israel desperately asked Yahweh for help.

#### because we abandoned our God

The people no longer obeying and worshiping Yahweh is spoken of as if they left Yahweh and went somewhere else. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### abandoned our God

The people are speaking to Yahweh and refer to him as "our God." This can be stated in second person. AT: "abandoned you, our God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### Did I not deliver you ... Sidonians?

God was rebuking the people of Israel for their worship of other gods. This rhetorical question can be translated as a statement. AT: "I was the one who delivered you ... Sidonians." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Maonites

These are the people from the clan or family of Maon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### from their power

Here "power" represents the Amalekites and the Maonites. AT: "from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/baal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Judges 10:13

#### you abandoned me again

The people no longer obeying and worshiping Yahweh is spoken of as if they left Yahweh and went somewhere else. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will not keep adding to the times I deliver you

The phrase "keep adding to the times" is an idiom that means to continue to do something. You can make explicit the implicit meaning of Yahweh's saying. AT: "I will not keep on delivering you again and again" or "You can be sure that I will stop delivering you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]

### Judges 10:15

#### foreign gods among them

You can make explicit the implicit meaning of this statement. AT: "foreign gods whose images they possessed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Yahweh could bear Israel's misery no longer

Here Israel refers to the people of Israel. AT: "And Yahweh did not want the people of Israel to suffer any longer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Judges 10:17

#### Who is the man who will begin to fight the Ammonites?

"Who will lead our army to fight against the Ammonites?"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]

### Judges 10:intro

#### Judges 10 General Notes ####

####### Structure and formatting #######

This chapter begins the account of Jephthah. (See: [Judges 10-12](./01.md))

####### Special concepts in this chapter #######

######## Israel's punishment ########
In Judges, Israel's actions are connected to their obedience to Yahweh. When Israel does evil, they are oppressed. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]) 

##### Links: #####

* __[Judges 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Judges 11

### Judges 11:01

#### Gileadite

This is someone who is from the region of Gilead. It is a coincidence that his father's name is also Gilead. See how you translated this in [Judges 10:3](../10/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### When his wife's sons grew up

"When the sons of Gilead's wife became adults"

#### the land of Tob

Tob is the name of a region. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### they came and went with him

"they followed him" or "they went everywhere together"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/warrior.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lawful.md)]]

### Judges 11:04

#### Some days later

"Some time later"

#### made war against Israel

The phrase "made war" is an idiom which means that they attacked Israel and were at war with them. Here "Israel" refers to the people of Israel. AT: "attacked the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### that we may fight with

"so that we can fight against"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]

### Judges 11:07

#### my father's house

Here "house" refers to people living in the house. AT: "my family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### That is why we are turning to you now

The word "that" refers to what Jephthah said about about them being in trouble. The full meaning of this statement can be made clear. AT: "We are turning to you now because we are in trouble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### fight with the people of Ammon

"fight against the people of Ammon"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]

### Judges 11:09

#### leader and commander

These two words basically have the same meaning repeated to emphasize how important Jephthah had became. You can combine the two words. AT: "commander" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### When he was before Yahweh in Mizpah, Jephthah repeated all the promises he made

This is an idiom. Here the phrase "before Yahwheh" means that he repeated his promises as a vow before Yahweh. AT: "When Jephthah was in Mizpah he repeated all of these promises as a vow before Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### all the promises he made

This refers to the promises he made to the leaders of Gilead about becoming their leader.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Judges 11:12

#### What is this conflict between us

"Why is there conflict between us?" Jephthah is asking the king why they are angry with Israel.

#### Why have you come with force to take our land

The word "you" refers to the King of Ammon and represents himself and his soldiers. AT: "Why have your soldiers come to seize our land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### come with force to take

"come to forcefully take"

#### Arnon ... Jabbok

These are the names of two rivers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### over to the Jordan

"on the other side of the Jordan River"

#### in peace

"peacefully" or "and do not try to defend them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]

### Judges 11:14

#### he said

Here the word "he" refers to the messenger who was speaking to the king. This may be written with the word "they" as in the UDB, referring to the group of messengers. AT: "Jephthah told the messengers to say" or "they said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they came up from Egypt

Whenever people traveled to the promised land it is referred to as going "up" to the promised land. When the Israelites left Egypt they were on their way to the promised land. AT: "they left Egypt" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md)]]

### Judges 11:17

#### General Information:

Jephthah's messengers continue to speak.

#### When Israel sent messengers

The messengers were sent by the leaders of Israel. AT: "When the leaders of Israel sent messengers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### pass through

"go through" or "cross"

#### would not listen

This phrase is an idiom that means to "refuse." AT: "refused" or "denied their request" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### They also sent messengers to the king of Moab

The reason that Israel sent messengers to the king of Moab can be made explicit. AT: "They also send messengers to the king of Moab with the same request" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but he refused

The king of Moab refused Israel's request to pass through Moab. The full meaning of this statement can be made clear. AT: "but he also refused and would not let them pass through the land of Moab" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Arnon

This is the name of a river. See how you translated this in [Judges 11:13](./12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kadesh.md)]]

### Judges 11:19

#### General Information:

Jephthah's messengers continue to speak.

#### Israel sent messengers to Sihon

The messengers were sent by the leaders of Israel. AT: "When the leaders of Israel sent messengers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Sihon

This is the name of a person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Heshbon ... Jahaz

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### But Sihon did not trust Israel to pass through his territory

Sihon did not trust the people of Israel to pass through his land peacefully. The full meaning of this statement can be made explicit. AT: "But Sihon did not trust the people of Israel to pass through his territory peacefully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### there he fought

The word "he" refers to Sihon and represents himself and his army. AT: "there they fought" or "there his army fought" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]

### Judges 11:21

#### General Information:

Jephthah's messengers continue to speak.

#### Sihon

See how you translated this man's name in [Judges 11:19](./19.md).

#### gave Sihon and all his people into the hand of Israel

Here "hand" refers to power to defeat in battle. AT: "gave Israel power over Sihon and all his people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Arnon ... Jabbok

See how you translated the names of these rivers in [Judges 11:13](./12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]

### Judges 11:23

#### General Information:

Jephthah's messengers continue to speak.

#### should you now take possession of their land?

Jephthah is rebuking the king of the Ammonites with this rhetorical question. The word "their" refers to the Israel. This question can be translated as a statement. AT: "therefore, you should not take possession of their land." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will you not take over the land that Chemosh, your god, gives you?

Jephthah is rebuking the king of the Ammonites with a rhetorical question. This question can be translated as a statement. AT: "You should only take over the land that Chemosh, your god, gives you." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### take over

This is an idiom which means to take control of something. AT: "take control of" or "take possession of" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Chemosh

This is the name of a false god. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Now are you really better than Balak son of Zippor, king of Moab?

Jephthah is rebuking the king of the Ammonites with a rhetorical question. This question can be translated as a statement. AT: "You are not better than Balak son of Zippor, who was king of Moab." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Balak ... Zippor

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Did he dare to have an argument with Israel?

Jephthah is rebuking the king of the Ammonites with a rhetorical question. This question can be translated with a statement. AT: "Yet he did not dare to have an argument with Israel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Did he ever wage war against them?

Jephthah is rebuking the king of the Ammonites with a rhetorical question. This question can be translated with a statement. AT: "Nor did he ever wage war against them." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]

### Judges 11:26

#### General Information:

Jephthah's messengers continue to speak.

#### three hundred years

"300 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Heshbon

Translate the name of this city the same way that you did in [Judges 11:19](./19.md).

#### Aroer

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Arnon

Translate the name of this city the same way that you did in [Judges 11:13](./12.md).

#### why then did you not take them back during that time?

Jephthah is rebuking the king of the Ammonites with a rhetorical question. This question can be translated as a statement. AT: "you should have taken them back during that time." or "now it is too late; you should have taken them back long ago." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I have not done you wrong, but you are doing me wrong by attacking me

Jephthah is speaking to the Sihon. Here Jephthah speaks about the Israelites as though they were himself and of the Ammonites as if they were Sihon their king. AT: "The Israelites have not done wrong to your people, but your people are doing us wrong by attacking us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### done you wrong ... doing me wrong

This is an idiom. To do someone wrong means to do something wrong to them. AT: "treated you wrongly ... treating me wrongly" or "treated you unfairly ... treating me unfairly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wrong.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]

### Judges 11:29

#### the Spirit of Yahweh came on Jephthah

This is an idiom which means that the Spirit influenced Jephthah's decisions. AT: "the Spirit of Yahweh took control of Jephthah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he passed through Gilead and Manasseh ... from Mizpah of Gilead

Jephthah passed through these places enlisting men for his army to go to war with the people of Ammon. The full meaning of this can be made clear. AT: "he gathered men for his army as he passed through Gilead and Manasseh ... from Mizpah of Gilead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will offer it up

This is an idiom which means to give something as an offering. AT: "I will offer it to you" or "I will sacrifice it to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]

### Judges 11:32

#### So Jephthah passed through ... Yahweh gave him victory ... He attacked

Since Jephthah was the leader of his army, he and his army are often spoken of as Jephthah himself. AT: "So Jephthah and his army passed through ... Yahweh gave them victory ... they attacked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Aroer

Translate the name of this city the same way you did in [Judges 11:26](./26.md).

#### Minnith ... Abel Keramim

These are the names of cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### twenty cities

"including 20 cities" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]

### Judges 11:34

#### tambourines

musical instruments with heads like drums that can be hit and with pieces of metal around their sides that sound when the instruments are shaken (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### he tore his clothes

This is an act that shows mourning or great sadness. AT: "he tore his clothes from grief" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### You have crushed me with sorrow ... you have become one who causes me pain

Jephthah said basically the same thing twice to emphasize that he was very sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### You have crushed me with sorrow

Here Jephthah speaks of his great sorrow as something that crushes him. AT: "You have caused me great sorrow" or "You have filled me with sorrow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### you have become one who causes me pain

Here Jephthah talks about his great distress and trouble as if it were pain. AT: "you have become someone who troubles me" or "you cause me great distress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I cannot turn back on my promise

This is an idiom. To turn back on a promise means to not do what you have promised to do. AT: "I must do what I have promised" or "I cannot break my promise" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Judges 11:36

#### has taken vengeance for you against your enemies, the Ammonites

Yahweh has taken vengence for him by defeating his enemies. The meaning of this can be made explicit. AT: "has taken vengeance for you against your enemies, the Ammonites, by defeating them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Let this promise be kept for me

This can be stated in an active form. AT: "Keep this promise for me" or "Keep this promise concerning me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### grieve over my virginity

"weep because I am a virgin" or "cry because I will never be married"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/companion.md)]]

### Judges 11:38

#### the Gileadite

This refers to someone from Gilead. See how you translated this in [Judges 10:3](../10/03.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]

### Judges 11:intro

#### Judges 11 General Notes ####

####### Structure and formatting #######

The account of Jephthah continues in this chapter. 

####### Special concepts in this chapter #######

######## Jephthah the leader ########
Jephthah was half Israelite and half Canaanite by birth. While all of the judges were called by Yahweh, it is the leaders who called Jephthah to help them, but Yahweh still used Jephthah to help them.

##### Links: #####

* __[Judges 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Judges 12

### Judges 12:01

#### A call went out to the men of Ephraim

Here the abstract noun "call" can be expressed as a verb. AT: "The men of Ephraim were called together" or "The men ... of Ephraim called together their soldiers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Zaphon

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### passed through ... pass through

or "traveled through ... travel" or "journeyed through ... journey"

#### We will burn your house down over you

This idiom means to burn down a house with people inside it. AT: "We will burn your house down with you still in it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### When I called you, you

Here the word "you" is plural and refers to the people of Ephraim. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### did not rescue me

Jephthah uses the word "me" to refer to himself and all the people of Gilead. AT: "do not rescue us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]

### Judges 12:03

#### you did not rescue me

The word "you" is plural and refers to the men of Ephraim. Jephthah is referring to the people of Gilead, including himself, when he says "me." AT: "you did not rescue us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### I put my life in my own strength

This is an idiom which means to risk one's life and to rely only on one's own strength. Jephthah continues to refer to the people of Gilead as himself. AT: "We risked our lives, relying on our own strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Yahweh gave me victory

Jephthah is referring to Yahweh giving the men of Gilead victory over the Ammonites. The full meaning of this statement can be made clear. AT: "Yahweh gave us victory over them" or "Yahweh allowed us to defeat them in battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he fought against Ephraim

The word "he" refers to Jephthah and all the fighting men of Gilead. AT: "they fought against Ephraim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Why have you come to fight against me

The word "you" is plural and refers to the men of Ephraim. Jephthah is referring to the people of Gilead, including himself, when he says "me." AT: "Why have you come to fight against us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### You Gileadites are fugitives

You can make the meaning of this insult explicit. AT: "You Gileadites do not really belong here. You are just people who came here to live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### passed through against the people of Ammon

This means that they fought against the Ammonites as they passed through Ammon. The full meaning of this statement can be made clear. AT: "fought against the people of Ammon as we passed through their region" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Gileadites

people from Gilead

#### in Ephraim—in Ephraim and Manasseh

"in the regions of Ephraim and Manasseh" or "in the land of Ephraim and Manasseh." Here "Ephraim" and "Manasseh" refer to regions and are named after the tribes which live there.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]

### Judges 12:05

#### to Ephraim

"to the land of Ephraim"

#### The Gileadites captured

"The Gileadites controlled" or "The Gileadites occupied"

#### fords

These are places where you can cross the river on foot because the water is shallow.

#### Ephraimite

person from the tribe of Ephraim

#### Shibboleth ... Sibboleth

These words have no meaning. Copy these words into your language, and make sure that the beginning of the words, that is the letters "Sh" and "S" are translated differently. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### pronounce

"say"

#### Forty-two thousand

"42,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Forty-two thousand Ephraimites were killed

This can be stated in active form. AT: "They killed forty-two thousand Ephraimites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jordanriver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]

### Judges 12:07

#### Jephthah the Gileadite died and was buried

This can be stated in active form. AT: "Jephthah the Gileadite died and they buried him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jephthah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 12:08

#### Ibzan of Bethlehem

This is the name of a man from Bethlehem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He gave away thirty daughters in marriage

Here "give away ... in marriage" is an idiom which means that he allowed his daughters to get married. AT: "He had thirty daughters and arranged a marriage for each of them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he brought in thirty daughters of other men for his sons, from the outside

The idiom "bring them in from the outside" means that he had women from other clans marry his sons. AT: "he arranged for thirty daughters of other men from outside of his clan to marry his sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 12:10

#### was buried at Bethlehem

This can be stated in active form. AT: "they buried him in Bethlehem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Elon

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zebulunite

someone from the tribe of Zebulun

#### Aijalon

Translate the name of this place the same way you did in [Judges 1:35](../01/34.md).

#### was buried in Aijalon

This can be stated in active form. AT: "they buried him in Aijalon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 12:13

#### Abdon ... Hillel

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Pirathonite ... Pirathon

Pirathon is the name of a place, someone who is from that place is called a Pirathonite. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They rode on seventy donkeys

These men owned seventy donkeys, which they did ride. Here the word "rode" is used instead of "owned." AT: "They owned seventy donkeys" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### forty sons ... thirty grandsons ... seventy donkeys

"40 sons ... 30 grandsons ... 70 donkeys (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amalekite.md)]]

### Judges 12:intro

#### Judges 12 General Notes ####

####### Structure and formatting #######

The account of Jephthah concludes in this chapter. 

######## Other possible translation difficulties in this chapter ########

######## Shibboleth ########
This is a word in Hebrew. Its importance in this chapter is because of its sounds, not its meaning. The translator should not translate the meaning of this word, but should transliterate or transfer it into the target language by substituting letters that have the same sounds. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

##### Links: #####

* __[Judges 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Judges 13

### Judges 13:01

#### what was evil in the sight of Yahweh

The sight of Yahweh represents Yahweh's judgment or evaluation. See how you translated this in [Judges 2:11](../02/11.md). AT: "what was evil in Yahweh's judgment" or "what Yahweh considered to be evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he gave them into the hand of the Philistines

Here "hand" refers to power to gain victory in battle. AT: "he allowed the Philistines to defeat them" or "he allowed them to be oppressed by the Philistines" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### forty years

"40 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Zorah

This was the name of a town in Israel. It was in the region of Judah near the border of Dan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Danites

people from the tribe of Dan

#### Manoah

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]

### Judges 13:03

#### give birth to a son

This refers to childbirth. AT: "bear a son" or "have a baby boy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### anything unclean

Something that Yahweh has stated is unfit to eat is spoken of as if it were physically unclean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Look

"Pay attention" or "Listen"

#### No razor will be used upon his head

Here the word "head" refers to his hair. This can be stated in active form. AT: "No one should ever cut his hair" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### razor

a sharp knife used to cut hair close to the skin

#### a Nazirite to God

This means that he will be devoted to God as a Nazirite. AT: "a Nazirite devoted to God" or "devoted to God as a Nazirite" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from the womb

Here the word "womb" refers to the time before the child is born. AT: "from before he is born" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the hand of the Philistines

Here the word "hand" means control. AT: "the control of the Philistines" or "being under the Philistine's control" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deliverer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Judges 13:06

#### A man of God

This means that the man was sent by God. This can be made explicit. AT: "A man that God sent" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### his appearance was like that of an angel of God, very terrible

Here "terrible" means "frightening." AT: "I was very afraid of him because he looked like an angel of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Look

"Pay attention" or "Listen"

#### give birth to a son

This refers to childbirth. AT: "bear a son" or "have a baby boy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### any food that the law declares to be unclean

Something that Yahweh has stated is unfit to eat is spoken of as if it were physically unclean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a Nazirite to God

This means that he will be devoted to God as a Nazirite. See how you translated this in [Judges 3:5](./03.md). AT: "a Nazirite devoted to God" or "devoted to God as a Nazirite" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from the time he is in your womb until the day of his death

This emphasizes that it would be for his entire life. AT: "all his life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 13:08

#### Manoah

See how you translated this man's name in [Judges 13:2](./01.md).

#### came to the woman

You can make explicit the implicit meaning of the author's words. AT: "came to Manoah's wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Judges 13:10

#### Look

"Listen" or "Pay attention to what I am about to tell you"

#### The man

This refers to the angel of God in [Judges 13:3](./03.md). This can be made explicit. AT: "the man of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

### Judges 13:12

#### your words

"what you have said"

#### anything that comes from the vines

Here the angel refers to any food that grow on a vine as "coming" from the vine. AT: "anything that grows on a vine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### unclean

Something that Yahweh has stated is unfit to eat is spoken of as if it were physically unclean. See how you translated this phrase in [Judges 13:7](./06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strongdrink.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/declare.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Judges 13:15

#### prepare a young goat for you

You can make explicit the implicit meaning of Manoah's statement. AT: "cook a young goat for you to eat" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]

### Judges 13:17

#### your words come true

"what you have said comes true"

#### Why do you ask my name?

The angel asks this question as a rebuke. This question can be written as a statement. AT: "You should not ask me what my name is." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### It is wonderful

It may be helpful to explain more explicitly why they should not ask his name. AT: "It is too wonderful for you to understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Judges 13:19

#### with the grain offering

This law requires a grain offering to be offered when a burnt offering is made. AT: "with the grain offering required with it" or "with the grain offering to accompany it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### on the rock

"on the altar." The altar Manoah sacrificed the offering on was a rock.

#### He did something

"The angel did something"

#### the angel of Yahweh went up in the flame of the altar

"the angel of Yahweh went back up into heaven through the flames on the altar"

#### lay facedown on the ground

"lay with their faces to the ground." This is a sign of respect and honor, but it also shows their fear of Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Judges 13:21

#### that he was the angel of Yahweh

The word "he" refers to the man who Manoah and his wife had seen.

#### We are sure to die, because we have seen God

It is implied that they think God will cause them to die. This can be made clear. AT: "God will cause us to die because we have seen him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Judges 13:23

#### He would not have shown us all these things, nor at this time would he have let us hear such things

Manoah's wife said basically the same thing twice for emphasis. These two statements can be combined. AT: "He would not have told us what he wanted us to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]

### Judges 13:24

#### the woman

"Manoah's wife"

#### gave birth to a son

This refers to childbirth. AT: "bore a son" or "had a baby boy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### grew up

"became an adult" or "matured"

#### Yahweh's Spirit began to stir him

Here the way Yahweh's Spirit influences Samson is compared to the way a spoon stirs food in a pot. AT: "Yahweh's Spirit began to influence Samson" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Mahaneh Dan ... Eshtaol

Mahaneh Dan is the name of a temporary camp that the tribe of Dan lived in while they looked for a permanent home. Eshtaol is the name of a town. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zorah

Translate the name of this town the same way you did in [Judges 13:2](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Judges 13:intro

#### Judges 13 General Notes ####

####### Structure and formatting #######

This chapter begins the account of Samson. (See: [Judges 13-16](./01.md))

####### Special concepts in this chapter #######

######## Warning not to cut his hair ########

The angel of the Lord prophesied about Samson and gave instructions to Samson's mother. Samson's mother was to offer up her son under a Nazarite vow. This was a special type of vow, dedicating Samson to Yahweh. Part of this vow prohibited the cutting of the person's hair. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]])

##### Links: #####

* __[Judges 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Judges 14

### Judges 14:01

#### Samson went down to Timnah

The phrase "went down" is used here because Timnah is lower in elevation than where his father's house was. Timah is the name of a city in the Sorek Valley. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### one of the daughters of the Philistines

The word "daughter" is a polite way to refer to a young, unmarried woman. AT: "one of the unmarried women among the Philistine people" or "a Philistine girl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### Now get her for me to be my wife

This is an idiom. Samson was demanding his parents to speak to the Philistine woman's parents about marriage. AT: "Now arrange for her to become my wife" or "Make the arrangements for me to marry her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Judges 14:03

#### Is there not a woman among the daughters of your relatives, or among all our people?

They ask this question to suggest that they could find Samson a wife among their own people. This question can be written as a statement. AT: "Surely there are women among your people whom you could marry." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the daughters of your relatives

The word "daughter" is a polite way to refer to a young, unmarried woman. AT: "one of the unmarried women among your relatives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### Are you going to take a wife from the uncircumcised Philistines?

This question is asked to rebuke Samson. This question can be written as a statement. You can make explicit the reason his parents do not want him to marry a Philistine. AT: "You really should not marry a Philistine woman because the Philistine people do not worship Yahweh." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Get her for me

This is an idiom. Samson was demanding his parents to speak to the Philistine woman's parents about marriage. AT: "Now arrange for her to be my wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### she pleases me

This means that Samson thinks she is beautiful. "I am pleased by how beautiful she is" or "she is beautiful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### this matter

This refers to Samson's request to marry the Philistine woman.

#### for he desired to create a conflict

The word "he" refers to Yahweh.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 14:05

#### Samson went down to Timnah

The phrase "went down" is used here because Timnah is lower in elevation than where his father's house was. Timnah was a city in the Sorek Valley. Translate the name of this city the same way you did in [Judges 14:1](./01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### And, look, there one of the young lions came up

Here the word "look" is used to draw the readers attention to a surprising event that happens in the story. The phrase "came up" means that the lion came near him. AT: "Suddenly, a young lion came near him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### was roaring at him

"threatened him." This is the kind of noise that a lion makes when it threatens to attack something.

#### Yahweh's Spirit suddenly came on him

The phrase "came on" means that Yahweh's Spirit influenced Samson. In this case, he made him very strong. AT: "Yahweh's Spirit made him very strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### tore ... apart

tore into two pieces

#### had nothing in his hand

Here it states that he had nothing in his hand to emphasize that he was not holding a weapon. AT: "did not have a weapon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]

### Judges 14:07

#### she pleased Samson

This means that he thought she was very beautiful. AT: "he was pleased by how beautiful she was" or "he thought she was very beautiful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### he turned aside

This means that he left his path to do something. AT: "he left the path" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### carcass

"dead body"

#### And, look, there was a swarm of bees

Here the word "look" is used to draw the reader's attention to something surprising that happens in the story. AT: "He found a swarm of bees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### swarm

large group of insects

#### scraped up

"gathered up"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/body.md)]]

### Judges 14:10

#### Samson's father went down to where the woman was

The phrase "went down" is used to describe Timnah which is lower in elevation than where Samson's father lives. AT: "Samson's father went to where the woman lived" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the custom of the young men

It may be helpful to state that this was a marriage custom. AT: "the custom of young men who were getting married" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### thirty of their friends

"30 of their friends" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]

### Judges 14:12

#### riddle

a game in which the players must discover the answer to a difficult question

#### can find it out

This means to figure out the meaning of the riddle. AT: "can figure out its meaning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### thirty linen robes and thirty sets of clothes

"30 linen robes and 30 sets of clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### But if you cannot tell me

Here the word "you" is plural and refers to the guests at the feast. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### linen

a type of cloth

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]

### Judges 14:14

#### General Information:

Samson tells his riddle. Since it is supposed to be hard to understand, do not translate it in a way that people will immediately know what it means.

#### Out of the eater was something to eat

"Out of the eater came something to eat" or "Something to eat came out of something that eats"

#### the eater

The noun "eater" can be expressed as a verb phrase. AT: "the thing that eats"

#### out of the strong was something sweet

"out of the strong came something sweet" or "Something that is sweet came out of something that is strong"

#### the strong

This refers to something that is strong. AT: "the strong thing" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### his guests

"the men at his feast"

#### could not find the answer

Here figuring out the answer to the riddle is spoke of as if it were something hidden that the guest had to search for and find. AT: "could not figure out the answer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

### Judges 14:15

#### the fourth day

"day 4" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Trick

mislead or fool someone into doing something they would not want to do

#### your father's house

Possible meanings are 1) this refers to the actual house. AT: "the house your father and his family live in" or 2) "house" refers to the people who live in it. AT: "your family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will burn up

The phrase "burn up" means to burn something completely. If a person is "burnt up," it means that person is burned to death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Did you invite us here in order to make us poor?

They ask her this question to accuse her of doing evil. This question can be written as a statement. AT: "You have brought us here to make us poor!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### to make us poor

They would become poor if they had to buy him new clothes if they could not solve the riddle. AT: "to make us poor by forcing us to buy him new clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Judges 14:16

#### All you do is hate me! You do not love me

Samson's wife basically said the same thing twice for emphasis. AT: "You do not really love me at all" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### riddle

a game in which the players must discover the answer to a difficult question

#### Look here

This is used to get someones attention. Here "look" means to "listen." AT: "Listen to me" or "Pay attention to what I am about to say"

#### if I have not told my father or my mother, should I tell you?

Samson was rebuking her for demanding that he tell her the answer. This question can be written as a statement. AT: "I have not even told my father or mother. I will not tell you." or "you should not demand that I tell you, since I have not even told my parents, and they are closer to me than you are." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### during the seven days that their feast lasted

Possible meanings are 1) "during the seven days of their feast" or 2) "during the rest of the seven days of their feast."

#### the seventh day

"day 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### she pressured him very much

Here the word "pressured" means "urged." AT: "she kept urging him to tell her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]

### Judges 14:18

#### the men of the city

This refers to Samson's wife's relatives. This can be stated clearly. AT: "the young men" or "her relatives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the seventh day

"day 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### What is sweeter than honey? What is stronger than a lion?

This is the answer to the riddle. It may be written as a statement instead of as questions. If necessary it could be made clear how this relates to the riddle by adding more information. AT: "Honey is sweet and a lion is strong." or "Honey is sweet and it came out of a lion." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If you had not plowed with my heifer

Samson compares their using his wife to get the answer to someone using another person's heifer to plow his field. AT: "If you had not used my wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### plowed

To plow is to use an animal to pull a blade through soil to prepare the soil for seeds.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//heifer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//heifer.md)]]

### Judges 14:19

#### came on Samson with power

The phrase "came on" means that Yahweh's Spirit influenced Samson. In this case, he made him very strong. AT: "made Samson very strong" or "made Samson very powerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### killed thirty of their men

"killed 30 of their men" - (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### their men

"the men who lived there"

#### plunder

things taken by force, usually after a fight or battle

#### their clothes

These were from the plunder he had taken from Ashkelon. AT: "the sets of clothing that he had taken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Burning with anger

"Very angry"

#### went up to his father's house

The phrase "went up" is used here because Samson was at Timnah which is lower in elevation than where his father's house is located.

#### Samson's wife was given to his best friend

This can be stated in active form. AT: "his wife's father gave her to his best friend" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### best friend

"closest friend"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashkelon.md)]]

### Judges 14:intro

#### Judges 14 General Notes ####

####### Structure and formatting #######

The account of Samson continues in this chapter.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 14:14, 18.

######## Special concepts in this chapter ########

######## Intermarriage ########
It was considered sinful for an Israel to marry a Canaanite or anyone from a different people group. This is why Samson's parents did not want him to marry a Philistine woman. They use rhetorical questions to convince him that he is sinning. This woman caused Samson many problems. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

##### Links: #####

* __[Judges 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## Judges 15

### Judges 15:01

#### He said to himself

This refers to thinking. AT: "He thought to himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### I will go to my wife's room

Samson intended to sleep with his wife. This can be stated clearly. AT: "I will go to my wife's room, so we may sleep together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### would not allow him to go in

The phrase "her room" is understood from what Samson said to himself. It can be repeated here. AT: "would not permit him to go into her room" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### so I gave her to your friend

This means that he gave her to be his friend's wife. This can be stated clearly. AT: "so I gave her to be married to your friend" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### is she not?

He asks this question to imply that Samson should agree with him. This question may be written as a statement. AT: "I hope you agree." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Take her instead

He is suggesting that Samson take her as his wife. This can be stated clearly. AT: "Take her to be your wife instead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/goat.md)]]

### Judges 15:03

#### I will be innocent in regard to the Philistines when I hurt them

Samson thinks that he will be innocent if he attacks the Philistines because they wronged him. This can be stated clearly. AT: "I will be innocent if I hurt the Philistines because they have wronged me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### three hundred foxes

"300 foxes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### foxes

Foxes are animals like dogs that have long tails and that eat nesting birds and other small animals.

#### each pair

a pair is two of anything, such as two foxes, or two tails

#### tail to tail

"by their tails"

#### torches

A torch is a stick of wood with something flammable attached to one end; a torch is often used to light other things or to be carried for light.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Judges 15:05

#### standing grain

grain that is still growing on its stalk in the field

#### stacked grain

the stalks of grain collected in piles after it has been harvested

#### orchards

An orchard is a place where fruit trees are grown.

#### the Timnite's son-in-law

The husband of a man's daughter is a "son-in-law."

#### Timnite

This is a person from Timnah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### took Samson's wife and gave her to his friend

Samson's wife's father gave her in marriage to Samson's friend. This can be stated clearly. AT: "took Samson's wife and allowed her to marry Samson's friend" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### burned up

The phrase "burned up" means to burn something completely. If a person is "burned up," it means that person is burned to death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Judges 15:07

#### said to them

"said to the Philistines"

#### If this is what you do

"Because you have done this."

#### he cut them to pieces, hip and thigh

Here "hip and thigh" refers to the whole body. This is a graphic description of how Samson killed the Philistines. AT: "He cut their bodies to pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### he went down

Here the phrase "went down" does not likely mean that he changed elevation, but rather, it is a way to describe someone going to another place. AT: "he went" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### cave

an opening in a hill or mountainside

#### cliff

a high, rocky hill or mountainside

#### Etam

This is the name of the rocky hill country near Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]

### Judges 15:09

#### the Philistines came up ... in Judah

The phrase "came up" is used here because the Philistines went to Judah which is higher in elevation than where they traveled from.

#### prepared for battle

"organized themselves for battle"

#### Lehi

This is the name of a town in Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### do to him as he has done to us

The Philistines are comparing how they want to kill Samson to how he killed many of the Philistines. AT: "kill him like he killed many of our people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]

### Judges 15:11

#### three thousand men of Judah

"3,000 men of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### cave in the cliff of Etam

See how you translated this phrase in [Judges 15:8](./07.md).

#### Do you not know that the Philistines are rulers over us? What is this you have done to us?

The men of Judah ask Samson these questions to rebuke him. This questions may be written as a statements. AT: "You know that the Philistines are rulers over us but you act like they are not. What you have done has caused us great harm." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### They did to me, and so I have done to them

Samson is referring to how they killed his wife and how he killed them in revenge. This can be stated clearly. AT: "They killed my wife, so I killed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Judges 15:12

#### the hands of the Philistines

Here "hands" refers to power. AT: "the Philistine's control" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hand you over to them

This means to cause someone to be under someone else's control. AT: "give you to the Philistines" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### up from the rock

This refers to the cave in the cliff of Etam where Samson had gone in [Judges 15:8](./07.md). Here the words "up from" mean that they had brought him away from the cave. AT: "away from the cave in the large rock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Judges 15:14

#### When he came

Samson was not travelling alone, he was being led by the men who had tied him with ropes. AT: "When they came" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Lehi

This is the name of a town in Judah. See how you translated this in [Judges 15:9](./09.md).

#### came on him with power

The phrase "came on" means that Yahweh's Spirit influenced Samson. In this case, he made him very strong. AT: "made Samson very strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### The ropes on his arms became like burnt flax

Samson easily broken the ropes that bound his hands. The author describes how easily he broke the ropes by saying it was as if they had become burnt flax. AT: "He snapped the ropes on his arms as easily as if they had been stalks of burned flax" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### flax

fibers from the flax plant used for making threads and cloth

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Judges 15:15

#### a fresh jawbone

This means that the donkey had died very recently and its bones had not yet begun to decay. A jawbone is the bone in which the lower rows of teeth are set.

#### a thousand men

"1,000 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the jawbone of a donkey

"a donkey's jawbone"

#### heaps upon heaps

This phrase describes how many people Samson killed. There were enough bodies to make large piles of bodies. AT: "I have made heaps of dead bodies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Judges 15:17

#### Ramath Lehi

This is the name of a place. It's name means "Jawbone Hill" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### was very thirsty

"needed water to drink"

#### But now will I die of thirst and fall into ... uncircumcised?

Possible meanings are 1) Samson is so thirsty he could literally die. AT: "But now I will die of thirst and my body will fall into ... uncircumcised." or 2) Samson exaggerates how thirsty he is by asking if he will die of thirst. AT: "But now will you allow me to become so weak from my thirst that I fall into ... uncircumcised?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### die of thirst

This means to die because you have not drank enough and therefore, you do not have enough water in your body. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### fall into the hands of those who are uncircumcised

The phrase "fall into the hands" means to be captured. "Those who are uncircumcised" refers to the Philistines and with the word "uncircumcised" emphasizing that they do not worship Yahweh. AT: "be captured by those godless Philistines" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/circumcise.md)]]

### Judges 15:19

#### split open the hollow place

"opened a hole in the ground" or "opened the low place." This refers to a low area of ground where Yahweh caused a spring of water to appear.

#### Lehi

See how you translated this in [Judges 15:9](./09.md)

#### his strength returned and he revived

These two phrase mean basically the same thing and emphasize that Samson became strong again. These two statements can be combined. AT: "he became strong again" or "he was revived" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### En Hakkore

This is the name of a spring of water. The name means "spring of him who prayed." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### it is at Lehi to this day

This means that the spring did not dry up but that it remained. The phrase "to this day" refers to the "present" time. AT: "the spring can still be found at Lehi, even today" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### in the days of the Philistines

This refers to the time period that the Philistines controlled the land of Israel. AT: "during the time the Philistines controlled Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### for twenty years

"for 20 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Judges 15:intro

#### Judges 15 General Notes ####

####### Structure and formatting #######

The account of Samson continues in this chapter. 

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 15:16.

####### Special concepts in this chapter #######

######## Samson's strength ########

The Spirit of Yahweh rushed upon Samson. This meant God gave Samson extraordinary strength. Samson's power is the power of Yahweh himself and he enacted the judgment of God on the Philistines. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]])

##### Links: #####

* __[Judges 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## Judges 16

### Judges 16:01

#### he went to bed with her

The phrase "went to bed with" is a polite way of referring to having sex. AT: "he had sex with her" or "he slept with her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### The Gazites were told

The word "Gazites" refers to people from Gaza. This can be stated in active form. AT: "Someone told the people of Gaza" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The Gazites surrounded the place ... they waited for him all night at the city gate

This implies that some Gazites surrounded the place where Samson was staying and others waited at the city gate so that he could not leave.

#### They kept silent all night

Possible meanings are 1) "They did not make any noise all night" or 2) "They made no attempt to attack him all night."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Judges 16:03

#### midnight

"the middle of the night"

#### its two posts

These are supports for the city gate. These posts were probably made from tree trunks and were buried deep into the ground. The doors of the city gate were attached to these posts.

#### bar and all

The bar was probably a heavy rod of iron that connected the gate to the posts. The doors of the city gate were probably made of heavy wooden beams or iron bars.

#### shoulders

the part of the human body where the arms and the neck attach to the body

#### Hebron

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hebron.md)]]

### Judges 16:04

#### Valley of Sorek

This is the name of a valley near Samson's home. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Trick

to mislead or fool someone into doing something they would not want to do

#### to see

This is an idiom that means to learn something. AT: "to understand" or "to learn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### where his great strength lies

This is an idiom that refers to where his strength comes from. AT: "what causes him to be very strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### by what means we may overpower him

"how we might overpower him"""

#### 1,100 pieces of silver

"one thousand one hundred pieces of silver." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Judges 16:06

#### bind you, so you might be controlled

This can be stated in active form. AT: "bind you to control you" or "bind you to restrain you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### fresh bowstrings

Bowstrings were often made from parts of an animal, often from the tendons. The words "fresh bowstrings" refer to those that come from a freshly slaughtered animal that have not yet dried.

#### that have not been dried

This can be stated in active form. AT: "that have not yet dried" or "that are not dry yet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]

### Judges 16:08

#### that had not been dried

This can be stated in active form. AT: "that had not yet dried" or "that were not dry yet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### she tied Samson up with them

"Delilah tied Samson up with the fresh bowstrings"

#### Now

This word is used here to mark a break in the main story line. Here the author tells background information about Philistine men that Delilah had waiting to capture Samson. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### The Philistines are upon you

The phrase "upon you" means that they are ready to capture him. AT: "The Philistines are here to capture you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he broke the bowstrings like a thread of yarn when it touches the fire

The author describes how easily he broke the bowstrings by comparing them to how yarn breaks when it is burned. AT: "he broke the bowstrings as easily as if he were breaking burned yarn" or "he broke the bowstrings as easily as if they were made of thin yarn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Judges 16:10

#### This is how you have deceived me and told me lies.

Deceiving and lying mean the same thing and are stated to emphasize how angry Delilah felt. AT: "You have greatly deceived me!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### you can be overpowered

This can be stated in active form. AT: "people can overpower you"

#### The Philistines are upon you

The phrase "upon you" means that they are there to capture him. AT: "The Philistines are here to capture you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### lying in wait

This means that they were hiding and waiting for the right moment to attack. AT: "waiting to attack him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### like they were a piece of thread

The author describes how easily Samson broke the ropes by comparing it to him breaking a piece of thread. AT: "as easily as if they were only a piece of thread" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Judges 16:13

#### you have deceived me and told me lies

Deceiving and lying mean the same thing and are stated to emphasize how angry Delilah felt. AT: "you have greatly deceived me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### you may be overpowered

This can be stated in active form. AT: "people can overpower you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### weave

crossing pieces of material together so they hold each other in place

#### locks of my hair

small bunches of hair

#### fabric

cloth made from weaving material together

#### loom

a machine used for combining many threads of material into a cloth (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### then nail that to the loom

"then nail the fabric to the loom"

#### nail

to hammer a nail in order to hold something in one place

#### I will be like any other man

The full meaning of this statement can be made explicit. AT: "I will be as weak as any other man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The Philistines are upon you

The phrase "upon you" means that they are there to capture him. AT: "The Philistines are here to capture you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### he pulled out the fabric and the pin from the loom

Samson pulled out the fabric from the loom when he pulled his hair away from the loom. This can be stated clearly. AT: "pulled away his hair, taking with it the pin of the loom and the fabric in the loom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the pin

This is the wooden nail or peg used to fasten the fabric to the loom.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Judges 16:15

#### How can you say, 'I love you,' when you do not share your secrets with me?

Delilah asks this question to say that if Samson really loved her he would tell her his secrets. This question can be written as a statement. AT: "When you say 'I love you,' you are lying because you do not share your secrets with me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### pressed him hard ... pressured him

Here the author speaks of how Delilah tries to persuade Samson as if she were putting pressure on him to convince him to tell her what she wants to know. AT: "tried hard to persuade him ... kept trying to persuade him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### with her words

"by what she said to him"

#### that he wished he would die

The author used a hyperbole, an exaggeration, to emphasize how miserable Sampson felt. AT: "that he was completely miserable" or "that he was very unhappy" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 16:17

#### told her everything

everything about the source of his strength. This can be stated clearly. AT: "told her the source of his strength" or "told her the truth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### razor

a sharp blade used to cut hair close to a person's skin

#### a Nazirite for God

This means that he is devoted to God as a Nazirite. See how you translated a similar phrase in [Judges 13:5](../13/03.md). AT: "a Nazirite devoted to God" or "devoted to God as a Nazirite" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from my mother's womb

Here "from my mother's womb" refers to to when he was born. This means that he has been a Nazirite since he was born. AT: "my entire life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### If my head is shaved

This can be stated in active form. AT: "If someone shaves my head" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### shaved

to have had the hair cut close to the skin with a razor

#### my strength will leave me

Samson speaks about his strength as if it were a person who could leave him. AT: "I will not be strong any more" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/nazirite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/womb.md)]]

### Judges 16:18

#### Delilah saw

Here the word "saw" is a idiom that means to realize something. AT: "Delilah realized" or "Delilah learned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the truth about everything

Here the word "everything" refers to everything about why Samson was strong. AT: "the truth about why he is strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Come up again

Delilah is telling the rulers to come again to where she lives. Her home is likely at a higher elevation than where the rulers would be travelling from.

#### bringing the silver in their hands

This means that they brought to her the silver that they had promised to give her if she helped them capture Samson. AT: "bringing the silver that they had promised to give her" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### She had him fall asleep

"She caused him to fall asleep"

#### in her lap

This means that he slept with his head on her lap. This can be stated clearly. AT: "with his head on her lap" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### lap

The lap is the level area of the upper legs when a person is sitting down.

#### the seven locks of his head

Samson had seven locks of hair on his head. Locks are small bunches of hair. Here his locks of hair are described as "belonging" to his head. AT: "the seven locks of hair on his head" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md)]])

#### subdue him

"control him"

#### his strength had left him

Here Samson's strength is described as if it were a person who could leave him. AT: "his strength was gone" or "he was no longer strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/delilah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]

### Judges 16:20

#### The Philistines are upon you

The phrase "upon you" means that they are ready to capture him. AT: "The Philistines are here to capture you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### woke up

"awakened"

#### get out

"escape"

#### But he did not know that Yahweh had left him

It is implied that if Yahweh left Samson, he would no longer be strong. AT: "But he did not know that Yahweh had left him and that he would not be strong enough to defeat the Philistines" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### put out his eyes

This means that they removed his eyes from his head. AT: "removed his eyes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### down to Gaza

The phrase "down to" is used here because they brought Samson to Gaza which is lower in elevation than his home where they captured him.

#### bound him with bronze shackles

"chained him with bronze shackles" or "tied him up using bronze shackles"

#### shackles

locks on the end of chains that hold a prisoner at his feet or hands, or both

#### turned the millstone

"pulled the millstone around in a circle"

#### millstone

This is a very large, heavy, circular stone. Normally, a large animal pulls the millstone around in a circle to crush grain. Here the Philistines humiliate Samson by making him pull it.

#### after it had been shaved

This can be stated in active form. AT: "after the Philistines had shaved it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gaza.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]

### Judges 16:23

#### Dagon

a major false god of the Philistines (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### conquered

"defeated"

#### put him in our grasp

Here the author speak of Samson being under the rulers' control as if he were something grasped tightly by their hands. AT: "put him under our control" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the destroyer of our country

This refers to Samson. The word "destroyer" can be expressed with the verb "destroy." AT: "the man who has destroyed our country"

#### who killed many of us

Here the word "us" refers to the Philistine people. Those who are talking are not counting themselves among the people whom Samson killed. AT: "who killed many of our people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destroyer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/destroyer.md)]]

### Judges 16:25

#### Call for Samson ... They called for Samson

Since Samson was a prisoner, he would not be called directly, but rather the people were asking for the men in charge of the prison to bring him to them. AT: "Call for them to bring out Samson ... They brought Samson" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the boy

"the young man" This was not a young child, but rather a youth.

#### Permit me to touch the pillars on which the building rests

"Allow me to touch the pillars which hold up the building"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]

### Judges 16:27

#### Now

This word is used here to mark a break in the main story while the writer tells background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### three thousand men and women

"3,000 men and women" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### looking on

"watching"

#### while Samson was entertaining them

It is unclear what Samson did to entertain them. It seems the Philistines were making him do things that would humiliate him so that they could make fun of him.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]

### Judges 16:28

#### called to Yahweh

"prayed to Yahweh"

#### call me to mind

This means to remember him and his situation. AT: "remember me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### only this once

"one more time"

#### in one blow on the Philistines

This idiom means that he wants to have one more powerful act against the Philistines to get full revenge for what they did to him. AT: "with one strike against the Philistine" or "in one powerful act against the Philistines" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### on which the building rested

"which held up the building"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]

### Judges 16:30

#### He stretched out with his strength

When Samson stretched out his arms he pushed down the pillars of the building. AT: "He used his strength to push down the pillars" or "He used his strength to push over the pillars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the dead

This refers to people who are dead. AT: "the dead people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-nominaladj.md)]])

#### were more

"were a greater amount"

#### all the house of his father

Here the word "house" refers to his family. AT: "all of his father's family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### came down

The phrase "came down" is used here because the place that Samson's family traveled form was higher in elevation than Gaza.

#### Zorah ... Eshtaol

See how you translated the names of these places in [Judges 13:2](../13/01.md) and [Judges 13:25](../13/24.md).

#### in the burial place of Manoah, his father

"where his father, Manoah, is buried"

#### Manoah

See how you translated this man's name in [Judges 13:2](../13/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Samson had judged Israel for twenty years

This same sentence is also in [Judges 15:20](../15/19.md). It is repeated here to remind readers of how long he judged Israel. AT: "Samson had judged Israel for twenty years before he died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### twenty years

"20 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samson.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistines.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bury.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 16:intro

#### Judges 16 General Notes ####

####### Structure and formatting #######

The account of Samson concludes in this chapter. 

####### Special concepts in this chapter #######

######## Samson's mistake ########

Samson mistakenly thought that he was the source of his strength. He did not realize that Yahweh had left him and without Yahweh, he had no strength. This was not Samson's only mistake. His foreign wife created most of his problems. 

##### Links: #####

* __[Judges 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | [>>](../17/intro.md)__


## Judges 17

### Judges 17:01

#### There was a man

This is a way to introduce a new person to the story line. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### Micah

This is the name of a man. It is not the same man who wrote the book of Micah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 1,100 pieces

"one thousand one hundred pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### that were taken from you

This can be stated in active form. AT: "which someone stole from you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I stole it

"I was the one who took it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Judges 17:03

#### 1,100 pieces

"one thousand one hundred" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### set apart

This means to dedicate something to a specific purpose. AT: "dedicate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### cast metal

metal that has been melted and poured into a mold to form a special shape

#### I restore it to you

"I give it back to you"

#### two hundred pieces of silver

"200 pieces of silver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### they were placed in the house of Micah

The word "they" refers to the metal figures. This may be stated in active form. AT: "Micah placed them in his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Judges 17:05

#### a house of idols

This refers to a house used specifically for worshiping idols. This can be stated clearly. AT: "a house for worshiping idols" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### everyone did what was right in his own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "each person did what he decided was right" or "each person did what he judged to be right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 17:07

#### of Bethlehem

"from Bethlehem"

#### of the clan of Judah

This means that he was living among the family of Judah, that is, the tribe of Judah. AT: "who was living among the tribe of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He stayed there to fulfill his duties

"He lived and worked there"

#### find a place to live

"find a different place to live"

#### where I might live

It is implied that he is looking for a place to live and work. AT: "where I might live and have a job" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]

### Judges 17:10

#### a father and a priest

The word "father" is here used in the sense of an advisor, and not to a literal father. AT: "an advisor and a priest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will give you ten pieces of silver a year

"I will give you ten pieces of silver each year"

#### a suit of clothes

"a set of clothes"

#### So the Levite went into his house

It is implied that the Levite accepted Micah's offer, and therefore, entered Micah's house. AT: "So the Levite accepted his offer and went into his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the young man became to Micah like one of his sons

The relationship between the Levite and Micah became like the close relationship between a father and son. AT: "the young man became close to Micah and was like one of his sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Judges 17:12

#### Micah set apart the Levite

Here "set apart" means that Micah "dedicated" or "ordained" him. AT: "Micah dedicated the Levite" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### was in Micah's house

Here living in Micah's house is spoken of as "being" in his house. AT: "lived in Micah's house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/setapart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 17:intro

#### Judges 17 General Notes ####

####### Structure and formatting #######

This chapter begins a section explaining how Israel came to have a king. 

####### Special concepts in this chapter #######

######## Idols and figures ########

According to the law of Moses, the Israelites were prohibited from making wooden figures or cast metal idols. This was a form of idolatry. This practice was common in Canaan and it shows the influence the Israelites allowed these people to have on them. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

##### Links: #####

* __[Judges 17:01 Notes](./01.md)__

__[<<](../16/intro.md) | [>>](../18/intro.md)__


## Judges 18

### Judges 18:01

#### In those days

This phrase introduces the beginning of another event in the story line. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### In those days ... from among the tribes of Israel

This is background information about Israel and the people of the tribe of Dan. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### not received any inheritance from

This refers specifically to land inherited where they would live. AT: "not received a land inheritance from" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### from the whole number of their tribe

The phrase "the whole number" refers to all of the men in the tribe. AT: "from among all of the men in their tribe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### experienced warriors

"experienced fighters"

#### Zorah

See how you translated the name of this town in [Judges 13:2](../13/01.md).

#### Eshtaol

See how you translated the name of this town in [Judges 13:25](../13/24.md).

#### to scout the land on foot

The phrase "on foot" means to walk. AT: "to scout the land by walking through it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Micah

See how you translated this man's name in [Judges 17:1](../17/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]

### Judges 18:03

#### they recognized the speech of the young Levite

They recognized the man by the sound of his voice. Here "speech" refers to his "voice." AT: "they heard the young Levite talking, and they recognized his voice" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Judges 18:05

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 18:07

#### Laish

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### There was no one who conquered

"There were no enemies living in their land who had conquered them"

#### had no dealings with anyone

"had no contact with any outsiders." This means they lived far enough away from any other city that they lived secluded from other people.

#### Zorah

Translate the name of this city the same as you did in [Judges 13:2](../13/01.md).

#### Eshtaol

Translate the name of this city the same as you did in [Judges 13:25](../13/24.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]

### Judges 18:09

#### Are you doing nothing?

This rhetorical question is asked sarcastically and means that they should be doing the opposite. This question can be written as a statement. AT: "You should be acting now!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### Do not be slow to attack

These two negative words "not" and "slow" together emphasize the positive idea to attack quickly. AT: "Hurry! Attack" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### the land is wide

"the land is large." This is a description of the size of the land.

#### that does not lack anything in the land

The men use a hyperbole, an exaggeration, to emphasize that it is a very desirable place to live. AT: "where we will have everything there that we need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### that does not lack anything

The two negative words together emphasize a positive idea. AT: "has everything" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Judges 18:11

#### Six hundred men

"600 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Kiriath Jearim

This is the name of a town. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mahaneh Dan

Translate the name of this place the same as you did in [Judges 13:25](../13/24.md).

#### to this day

This means that something remains the same. It refers to the "present" time. AT: "and that is still its name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Judges 18:13

#### Laish

Translate the name of this town the same as you did in [Judges 18:7](./07.md).

#### in these houses there are an ephod, ... metal figure? Decide ... will do

The five men asked this question to suggest and encourage the men that they should steal the idols. This can be written as a statement, and the implied information may be given in a parenthetical phrase. AT: "these houses contain an ephod, ... metal figure. (They were suggesting that the men steal these things.) Decide ... will do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### in these houses there are

"in one of these house there is" or "among these houses is"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Judges 18:15

#### they turned in there

"they turned"

#### they greeted him

The word "him" refers to the Levite.

#### six hundred Danites

"600 Danites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Judges 18:17

#### six hundred men

"600 men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Judges 18:19

#### Is it better for you to be priest for the house of one man ... a clan in Israel?

They ask this as a rhetorical question to imply that it is true. This question can be written as a statement. AT: "It is better for you to be priest for a tribe and a clan in Israel than for just the house of one man." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### The priest's heart was glad

Here the priest is referred to by his "heart" to emphasize his emotions. AT: "The priest was glad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ephod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]

### Judges 18:21

#### They put the small children in front of themselves

They traveled this way to protect the children. If Micah and his people attacked them the would reach the warriors first and not the children. AT: "They put the small children in front of themselves to protect them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a good distance

"some distance." This refers a short distance but one that is long enough to be considered as measurable progress. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the men who were in the houses near Micah's house were called together

This can be stated in active form. AT: "he called together the men who were in the houses near his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they caught up with the Danites

This implies that they ran after them. This can be stated clearly. AT: "running after the Danites, they caught up with them"

#### they turned

"the Danites turned around"

#### Why have you been called together?

This question is a rebuke. It can be translated as a statement. AT: "You should not have called your men together to chase us." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### been called together

This can be stated in active form. AT: "called these men together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]

### Judges 18:24

#### the gods that I made

Micah did not make his gods, rather the craftsman made them. AT: "the gods which I had made for me" or "the gods which a craftsman made for me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### What else do I have left?

Micah asks this question to emphasize that he no longer has the things that are important to him. AT: "I have nothing left." or "You have taken everything that is important to me." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### How can you ask me, 'What is bothering you?'

Micah asks this question to emphasize that the Danites definitely know what is bothering him. AT: "You know that I am greatly distressed!'" or "You know how much I am bothered by what you have done to me!'" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### let us hear you say anything

The phrase "us hear you say" refers to the Danites hearing Micah speaking about what had happened, but it also includes if they are told by others that Micah had spoken about what had happened. AT: "let us find out that you have said anything" or "say anything about this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### hear you say anything

The word "anything" refers to any information about the Danites coming to Micah's house and stealing his idols. This can be stated clearly. AT: "hear you say anything about this matter" or "hear you say anything about what has happened" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### you and your family will be killed

This can be stated in active form. AT: "kill you and your family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### went their way

This means that they continued on their journey. AT: "continued on their journey" or "continued travelling" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they were too strong for him

This refers to the Danites being too strong for Micah and his men to fight against. AT: "they were too strong for him and his men to fight" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]

### Judges 18:27

#### what Micah had made

Micah did not make his gods, rather a craftsman made them for him. Also, this can be stated in active form. AT: "the things that had been made for Micah" or "Micah's things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Laish

See how you translated this in [Judges 18:7](./07.md).

#### with the edge of the sword

"with their swords." Here "the sword" represents the swords and other weapons that the soldiers used in battle. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they had no dealings with anyone

this means they lived far enough away from any other city, that they lived secluded from other people. See how you translated this phrase in [Judges 18:7](./07.md).

#### Beth Rehob

This is a name of a town. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 18:30

#### Jonathan son of Gershom, son of Moses

This is the name of the young Levite who used to serve as priest for Micah. This can be made explicit. AT: "The young Levite's name was Jonathan the son of Gershom, son of Moses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### until the day of the land's captivity

This refers to a time later on when the people of Dan would be captured by their enemies. Here the land being conquered is spoken of as if it were a prisoner taken captive by an enemy. AT: "until the day that their enemies conquered their land" or "until the day that their enemies took them captive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### that he made

Micah did not make his gods, rather the craftsman made them for him. AT: "that had been made for him" or "that his craftsman made for him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonathan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jonathan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]

### Judges 18:intro

#### Judges 18 General Notes ####

####### Special concepts in this chapter #######

######## The tribe of Dan ########

The tribe of Dan lacked faith in Yahweh and had yet to conquer its inheritance. In this chapter, they begin to conquer their land, but they also started to worship an idol. Their conquering of the land is much different than the other tribes' victories. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]])

##### Links: #####

* __[Judges 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__


## Judges 19

### Judges 19:01

#### In those days

This phrase introduces the beginning of another event in the story line. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-newevent.md)]])

#### remote

far from where most people live

#### was unfaithful to him

This means that she was unfaithful in their relationship and that she began to sleep with other men. This can be stated explicitly if necessary. AT: "began to sleep with other men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Judges 19:03

#### His servant was with him, and a pair of donkeys

"He took with him his servant and two donkeys"

#### His father-in-law, the girl's father, persuaded

"His father-in-law, that is, the girl's father, persuaded" or "The girl's father persuaded"

#### persuaded him to stay

"spoke to him so he decided to stay"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Judges 19:05

#### he prepared

the Levite prepared

#### Strengthen yourself with a bit of bread

Here "bread" refers to "food." AT: "Eat some food so you will be strong enough to travel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Please be willing to spend the night

"Please stay another night"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]

### Judges 19:07

#### Strengthen yourself, and wait until the afternoon

The father-in-law is suggesting that he strengthen himself by eating. He is also asking him to wait until the afternoon to leave. This can be stated clearly. AT: "Eat some food so you will be strong enough to travel, and wait until afternoon to leave" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Judges 19:09

#### now the day is advancing toward evening

"the day is almost over" or "it is almost evening"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Judges 19:10

#### that is Jerusalem

"which was later called Jerusalem"

#### He had a pair of saddled donkeys

This can be stated in active form. AT: "He put saddles on his two donkeys" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Come, let us

This is an idiom used to make a suggestion. AT: "I suggest that we" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### turn aside to

This means to take a break from their journey and stop somewhere along the route. AT: "stop at" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Judges 19:12

#### turn aside into

This means to take a break from their journey and stop at a place along the route. See how you translated a similar phrase in [Judges 19:11](./10.md). AT: "stop at" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Come, let us

This is an idiom used to make a suggestion. AT: "I suggest that we" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ramah.md)]]

### Judges 19:14

#### turned aside

This means to take a break from their journey and stop at a place along the route. See how you translated a similar phrase in [Judges 19:11](./10.md). AT: "stopped" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the city square

the marketplace where people gathered during the day

#### took them into his house

This phrase means for someone to invite them to spend the night in their home. AT: "invited them to stay in their house for that night" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Judges 19:16

#### Benjamites

A Benjamite was a descendant of Benjamin. See how you translated the name of this people group in [Judges 3:15](../03/15.md).

#### He raised his eyes

Here the man looked up and paid attention to what was around him. AT: "He looked up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the city square

the marketplace where people gathered during the day. See how you translated this in [Judges 19:14](./14.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Judges 19:18

#### who will take me into his house

This phrase refers to someone inviting other people into his house to spend the night there. AT: "who has invited me to stay in his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### will take me

Here the Levite says "me," but he is actually referring to himself along with his servant and his concubine. AT: "will take us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### there is bread and wine

Change to active voice. AT: "we have plenty of bread and wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### me and your female servant here, and for this young man with your servants

The Levite speaks of himself and the others as servants and in the third person to show respect. AT: "me, my concubine, and my servant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### We lack nothing

This can be written as a positive statement. AT: "We have everything we need" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Judges 19:20

#### Only do not

"Do not." The word "only" is used here to emphasize what he did not want the Levite to do.

#### square

This refers to the city square. See how you translated this [Judges 19:17](./16.md).

#### brought the Levite into his house

This means that he invited the Levite to spend the night in his house. Also, by inviting the Levite he was inviting the man's concubine and servant as well. AT: "invited the Levite and his servants to stay in his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Judges 19:22

#### they were making their hearts glad

The phrase "making their hearts glad" is an idiom that means to have a good time with someone else. AT: "they were have a good time together" or "they were enjoying themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### some men of ... surrounded the house

Some men stood on all sides of the house.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Judges 19:24

#### See

This word is used to get the peoples' attention. AT: "Listen"

#### the men would not listen to him

Here the author speaks of "agreeing" as if it were "listening." AT: "the men would not accept his offer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the man seized his concubine

there could be confusion as to the identity of the man. AT: "the Levite seized his concubine"

#### at dawn

"when the sun was coming up" or "at first light" This refers to when the sun begins to rise.

#### it was light

This refers to morning when it is bright outside. AT: "the sun was fully risen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Judges 19:27

#### But there was no answer

The woman did not answer because she was dead. This can be stated clearly. AT: "But she did not answer because she was dead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/threshold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/threshold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]

### Judges 19:29

#### limb by limb

"section by section." The author uses this graphic description of how the Levite cut up her body into specific pieces to emphasize what he did. "Limbs" refers to a person's arms and legs. If there is not a similar phrase in your language, this description may be left out of the translation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### twelve pieces

"12 pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### sent the pieces everywhere throughout Israel

This means that he sent sent the different pieces to twelve different areas of Israel. AT: "sent each piece to a different place throughout Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/counselor.md)]]

### Judges 19:intro

#### Judges 19 General Notes ####

####### Special concepts in this chapter #######

######## The sin of Benjamin  ########
People from a village of the tribe of Benjamin raped a visitor's wife to death. This was very evil, especially in the ancient Near East. The people of Israel considered mistreatment of a guest one of the worst crimes. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]])

##### Links: #####

* __[Judges 19:01 Notes](./01.md)__

__[<<](../18/intro.md) | [>>](../20/intro.md)__


## Judges 20

### Judges 20:01

#### as one man

This simile speaks of the group as acting as a single person. It refers to a group of who people do everything together in the same way. AT: "as if they were a single man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### from Dan to Beersheba

This refers to the land as a whole. AT: "from all the eleven tribes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### God—400,000 men on foot

"God and also 400,000 regular soldiers came"

#### ready to fight

"capable of going to war." They were not going to fight each other.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/dan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Judges 20:03

#### Now

This word is used here to mark a break in the main story line. Here the author of the book tells background information about what the people of Benjamin knew.

#### had gone up to Mizpah

Mizpah was located high in the mountains.

#### to spend the night

"for the night" or "to stay for a night"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]

### Judges 20:05

#### wickedness and outrage

The word "outrage" describes the "wickedness." AT: "outrageous wickedness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md)]])

#### Now

This word is used to introduce the conclusion of the speech of the Levite.

#### give your advice and counsel here

The words "advice" and "counsel" refer to the same thing and are repeated for emphasis. They can be combined. AT: "decide what we need to do about this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seize.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/concubine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Judges 20:08

#### as one

This simile speaks of the group as acting as a single person. They all acted together in exactly the same way. AT: "as if they were a single man" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### None of us will go to his tent ... none of us will return to his house

These two clauses say basically the same thing twice for emphasis. They can be combined. The words "none ... go" and "none ... return" emphasizes how the people will continue to stay there. They can be stated in positive form. AT: "We will all stay here" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### But now

These words introduce the main portion of what the people say after the initial exclamation.

#### as the lot directs

This involved tossing or rolling small marked stones to determine what God wants.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]

### Judges 20:10

#### ten men of a hundred ... one hundred of a thousand ... one thousand of ten thousand

"10 men out of 100 ... 100 out of 1,000 ... 1,000 out of 10,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### provisions

"food" or "supplies"

#### assembled against the city

"came together to attack the city"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Judges 20:12

#### put them to death

This is an idiom. AT: "kill them" or "execute them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the voice of their brothers

Here "voice" refers to the message that they spoke. AT: "what their brother said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Judges 20:15

#### twenty-six thousand

"26,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### seven hundred

"700" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### left-handed

A left-handed person is someone who is more skilled with their left hand than with their right hand.

#### could sling a stone at a hair and not miss

This show how amazingly well they could aim and hit their target. It can be stated in positive form. AT: "could throw a stone at even a hair and hit it" or "could throw a stone at something as small as a hair and hit it"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]

### Judges 20:17

#### not counting

"not including"

#### 400,000

"four hundred thousand men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### asked for advice from God

"asked God what to do" or "asked God how to continue"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]

### Judges 20:19

#### moved their camp near Gibeah

There is some question about the meaning of the Hebrew text. Instead of meaning that they set up their camp near Gibeah, it could mean that the army went out and stood across from Gibeah ready to fight.

#### twenty-two thousand

"22,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]

### Judges 20:22

#### strengthened themselves

Here "strengthened" is an idiom that means they encouraged each other. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they formed the battle line

This probably means that the Israelites prepared their battle lines for the next day's fighting. AT: "they got ready to fight the next day"

#### they sought direction from Yahweh

The method they used is not stated. The priest may have cast lots to determine God's will.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Judges 20:24

#### eighteen thousand

"18,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Judges 20:26

#### before Yahweh

"in Yahweh's presence" or "to Yahweh"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md)]]

### Judges 20:27

#### for the ark of the covenant of God ... was serving before the ark in those days

This is background information that the author inserted to help the reader understand how the people asked Yahweh for an answer. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### was there in those days

"was at Bethel in those days"

#### was serving before the ark

The full meaning of this statement can be made explicit. AT: "was serving as priest before the ark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Attack

The full meaning of this statement can be made explicit. AT: "Attack the army of Benjamin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/phinehas.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/eleazar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/eleazar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Judges 20:29

#### Israel set men

Here "Israel" refers to the people of Israel. AT: "the Israelites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### secret places

"in ambush"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Judges 20:31

#### fought against the people

The full meaning of this statement can be made explicit. AT: "fought against the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### they were drawn away from the city

This can be stated in active form. AT: "the people of Israel drew them away from the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They began to kill some of the people

The full meaning of this statement can be made explicit. AT: "The people of Benjamin began to kill some of the men of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]

### Judges 20:32

#### just as at first

"just as before" or "just like the first two times"

#### Baal Tamar

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Maareh Gibeah

This is the name of a place. Other translations may read "fields of Gibeah" or "west of Gibeah" or "Maareh Geba." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Judges 20:34

#### ten thousand

"10,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### chosen men

This is an idiom that means these were particularly good soldiers. AT: "well-trained soldier" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### disaster was close to them

Here immanent disaster is spoken of as if it was standing very close by them. AT: "they would soon be completely defeated" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### 25,100 men

"twenty-five thousand one hundred men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Judges 20:36

#### The men of Israel had given ground to Benjamin, because they were counting on the men ... outside Gibeah

From this sentence until the end of verse 41 is background information that the writer inserted to explain to the readers how the ambush defeated the Benjamites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### had given ground to Benjamin

This is an idiom that means they intentionally retreated. AT: "had allowed Benjamin to move forward" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### they were counting on the men

This is an idiom that means they trusted their men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

### Judges 20:39

#### General Information:

This verse continues to give background information that the writer inserted to explain to the readers how the ambush defeated the Benjamites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### would turn from the battle

"would retreat from the fight"

#### they are defeated before us

This can be stated in active form. AT: "we have defeated them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Judges 20:40

#### General Information:

This verse continues to give background information that the writer inserted to explain to the readers how the ambush defeated the Benjamites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### disaster

"great harm" or "trouble" or "misery"

#### come on them

This idiom means it happened to them. AT: "happened to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]

### Judges 20:42

#### But the fighting overtook them

This speaks about fighting as if it were a person who could overtake someone. AT: "But the soldiers of Israel caught up to them" or "But they were not able to escape the fighting" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Judges 20:43

#### Nohah

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### trampled them down

The completed destruction of the Benjamites is spoken of as if the Israelites stomped on their bodies. AT: "they completely destroyed them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### eighteen thousand

"18,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### were distinguished in battle

"had fought bravely in the battle"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Judges 20:45

#### They turned and fled

"The remaining Benjamites turned and fled"

#### five thousand ... two thousand

"5,000 ... 2,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Gidom

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### twenty-five thousand

"25,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rimmon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rimmon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Judges 20:47

#### six hundred

"600" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### turned back against the people of Benjamin

These people of Benjamin are not the soldiers who fled to the rock of Rimmon, but the ones who were still in the city.

#### the city

Here "the city" refers to the people in that city. AT: "everyone who was in the city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in their path

This idiom refers to everything that they found as they went toward the city. AT: "they came to" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Judges 20:intro

#### Judges 20 General Notes ####

####### Special concepts in this chapter #######

######## Benjamin destroyed ########

The army of Israel destroys all the tribe of Benjamin except 600 men. After this point in time, the tribe of Benjamin becomes mostly insignificant. 

##### Links: #####

* __[Judges 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__


## Judges 21

### Judges 21:01

#### Now the men of Israel had made a promise ... marry a Benjamite."

This background information tells the reader about the promise that the Israelites made before the battle with the Benjamites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Benjamite

This is the name of the descendants of Benjamin. See how you translated this in [Judges 3:15](../03/15.md).

#### Why, Yahweh, God of Israel, has this happened to Israel, that one of our tribes should be missing today?

The people of Israel used this rhetorical question to express their deep sadness. This question can be translated as a statement. AT: "Oh Yahweh, we are so sad that one of the tribes of Israel has been completely destroyed." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]

### Judges 21:04

#### The people of Israel said, "Which of all the tribes of Israel did not come up in the assembly to Yahweh?"

The people are referring back to the assembly of the Israelites at Mizpah before they attacked the Benjamites.

#### For they had made an important promise concerning anyone who did not come up to Yahweh at Mizpah. They said, "He would certainly be put to death."

This is background information to explain to the reader the promise that the Israelites had made at Mizpah before they attacked the Benjamites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### He would certainly be put to death

Here "He" refers to anyone who did not go to Mizpah. This can be stated in active form. AT: "We will certainly kill that person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peaceoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Judges 21:06

#### their brother Benjamin

This speaks of the tribe of Benjamin as if it were Israel's brother to show their closeness to the tribe. AT: "the surviving Benjamites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### one tribe has been cut off from Israel

The destruction of the tribe of Benjamin is spoken of as if it had been cut off from Israel by a knife. This was an exaggeration because 600 men were still left. However, the women of Benjamin had been killed, so the future of the tribe was in question. AT: "one tribe has been removed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Who will provide wives for those who are left, since we have made a promise to Yahweh that we will not let any of them marry our daughters?

The Israelites wanted to provide wives for the few surviving Benjamites, but their promise at Mizpah prevented them from doing that.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cutoff.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Judges 21:08

#### Jabesh Gilead

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### people were set out in an orderly manner

"people that were assembled at Mizpah were accounted for"

#### none of the inhabitants of Jabesh Gilead were there

This refers back to the earlier assembly at Mizpah. The full meaning of this statement can be made clear. AT: "none of the inhabitants of Jabesh Gilead had been present at Mizpah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### twelve thousand

"12,000" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### strike the inhabitants of Jabesh Gilead with the edge of the sword, including the women and children

The next verse will add an exception to this general instruction.

#### strike ... with the edge of the sword

"kill ... with their swords"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/mizpah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Judges 21:11

#### Jabesh Gilead

This is the name of a city. See how you translated this in [Judges 21:8](./08.md).

#### slept with a man

This is a euphemism for sexual relations. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-euphemism.md)]])

#### four hundred young women

"400 young women" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sex.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]

### Judges 21:13

#### they were offering them peace

The abstract noun "peace" can be translated with a verb phrase. AT: "they wanted to stop fighting with them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Jabesh Gilead

This is the name of a city. See how you translated this in [Judges 21:8](./08.md).

#### there were not enough women for all of them

There were six hundred Benjamite men, and only four hundred women from Jabesh Gilead.

#### made a division between the tribes of Israel

"had caused the tribes of Israel not to be unified"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rimmon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/rimmon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 21:16

#### Benjamites

This refers to the descendants of Benjamin. See how you translated this in [Judges 3:15](../03/15.md).

#### the women of Benjamin have been killed

This can be stated in active form. AT: "we killed all the Benjamite women" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### There must be an inheritance ... is not destroyed from Israel

The Israelites are exaggerating. They had already given wives to four hundred of the Benjamites, so the tribe would not be completely destroyed. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 21:18

#### a wife to Benjamin

Here Benjamin refers to the male descendants of Benjamin. AT: "a wife to the men of Benjamin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### which is north of Bethel, east of the road that goes up from Bethel to Shechem, and south of Lebonah

This is background information to explain to the reader where the city of Shiloh is located. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### Lebonah

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shechem.md)]]

### Judges 21:20

#### each one of you should grab a wife ... go back to the land of Benjamin

It it understood that the Benjamites would take these women back to their own land with them. The full meaning of this statement can be made explicit. AT: "each one of you should seize one of the girls of Shiloh, and then take her back with you to the land of Benjamin to become your wife" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/shiloh.md)]]

### Judges 21:22

#### Show us favor

The abstract noun "favor" can be stated as an action. AT: "Act kindly toward us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### because we did not get wives for each man during the war

The full meaning of this statement can be made explicit. AT: "because we did not get wives for each of them during the war with Jabesh Gilead" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### You are innocent ... not give your daughters to them

This refers to the men of Shiloh. They did not voluntarily give their daughters to the Benjamites, and therefore did not break their promise not to do that.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/favor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]

### Judges 21:23

#### the number of wives that they needed

This refers to one wife for each of the two hundred Benjamite men who did not receive wives from Jabesh Gilead (See: [Judges 21:14](./13.md)).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clan.md)]]

### Judges 21:25

#### there was no king in Israel

"Israel did not yet have a king"

#### what was right in his own eyes

The eyes represent seeing, and seeing represents thoughts or judgment. AT: "what he judged to be right" or "what he considered to be right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Judges 21:intro

#### Judges 21 General Notes ####

####### Structure and formatting #######

This chapter concludes the account of the previous chapter.

####### Special concepts in this chapter #######

######## Sin and immorality ########

At the end of Judges, there is much sin and immorality. The people are doing wrong and fixing their wrongs by doing more evil things. This period of Judges is typified by this final account and summarized by the statement, "everyone did what was right in his own eyes." (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

##### Links: #####

* __[Judges 21:01 Notes](./01.md)__

__[<<](../20/intro.md) | __


## Judges front

### Judges front:intro

#### Introduction to Judges ####

##### Part 1: General Introduction #####

####### Outline of Judges #######

   - The time from Joshua, and conquests of Canaan (1:1–2:5)
1. History of the Judges of Israel (2:6–16:31)
      - Cushan Rishathaim in conflict with Othniel (3:7–11)
      - Eglon in conflict with Ehud; Philistines against Shamgar (3:12–31)
      - Sisera and Jabin in conflict with Deborah and Barak (4:1–5:31)
      - Gideon's wars (6:1–8:32)
      - Abimelech, Tola, and Jair (8:33–10:5)
      - Ammonites and Philistines in conflict with Jepthah; Ibzan, Elon, and Abdon (10:6–12:15)
      - Samson (13:1–16:31)
1. The account of Micah and his idols (17:1–18:31)
1. The account of what happened in the city of Gibeah and how the other Israelites took revenge (19:1–21:25)

####### What is the book of Judges about? #######

The book of Judges tells of some events that occurred after the Israelites settled in the Promised Land. The events in these book happened over a period of about 150 years.

This book describes how the Israelites repeatedly sinned against Yahweh. They worshiped false gods and did the same wicked things as the peoples who lived around them. Therefore, God would allow enemies to defeat and oppress the Israelites. Eventually, the Israelites would call to Yahweh for help. Yahweh would then cause someone to help the Israelites defeat their enemies. This person was called a "judge." The Israelites would live in peace until the judge died.

After that judge died, the Israelites would start sinning again. So this pattern of events would repeat.

####### How should the title of this book be translated? #######

This book traditionally has the title "Judges" because it gives accounts of some of the main leaders or judges in Israel before there were any kings over the people. Unless there are good reasons for following the title in other Bible versions, the translator should probably use a title such as, "The Book about the Leaders in Israel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### What kind of leaders were the judges? #######

These were men and women whom God chose to help the Israelites defeat their enemies. After defeating their enemies, these leaders usually continued to help the people by deciding disputes among them. They also helped them make important decisions. Many of these leaders served the entire people of Israel, but some of these leaders seem to have served only certain tribes.

####### What kind of society was Israel during the time of the judges? #######

During this time, the twelve tribes of Israel were independent of one another. They were not a unified nation with one king ruling them all. The tribes would sometimes help each other when enemies were threatening them.

These tribes were descended from the same ancestors: Abraham, Isaac, and Jacob. They shared in the same covenant with Yahweh.

####### What spiritual struggles did Israel experience during the time of the judges? #######

Israel struggled during this time to remain faithful to Yahweh. The best judges encouraged Israel to be faithful to him, but some of the judges failed to do so. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]])

##### Part 3: Important Translation Issues #####

####### What is the meaning of the phrase "in those days there was no king in Israel, and everyone did what was right in his own eyes?" #######

This phrase occurs twice in the book of Judges. Shorter versions of the phrase occur two other times. These phrases imply that the writer or editor of this book was alive at a later time when there was a king in Israel. They also seem to imply that the writer thought that things were not good in Israel before there was a king. 

The translation of these phrases should imply to the reader that the book's writer is looking back a long time into the past.

####### What is the meaning of the phrase "to this day"? #######

The narrator used this phrase to refer to the time when he was writing. The translator should be aware that "to this day" refers to a time which has already passed. The translator must avoid giving the impression that the present day of the translation's readers is meant. The translator might decide to say, "to this day, at the time when this is being written," or, "to this day, at the time of writing." This Hebrew phrase occurs in Judges 1:21, 26; 6:24; 10:4; 15:19; 18:12.



---

