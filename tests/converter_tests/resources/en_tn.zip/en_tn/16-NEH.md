# <a id="neh"/>Nehemiah

## Nehemiah 01

### Nehemiah 01:01

#### Nehemiah ... Hakaliah ... Hanani

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in the month of Kislev

"Kislev" is the ninth month of the Hebrew calendar. It is during the last part of November and the first part of December on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### in the twentieth year

Nehemiah is referring to the number of years that Artaxerxes had been reigning as king. AT: "in the twentieth year of the reign of Artaxerxes, King of Persia" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### fortress of Susa

This was one of the royal cities of Persian kings, located in the country of Elam. It was a large, fortified city with high walls surrounding it.

#### one of my brothers, Hanani

Hanani was Nehemiah's biological brother.

#### Hanani, came with some people from Judah

"Hanani came from Judah with some other people"

#### the Jews who had escaped, the remnant of the Jews who were there

These two phrases refer to the same group of people. Possible meanings are 1) the few Jews who were taken as exiles to Babylon but escaped and returned to live in Jerusalem or 2) the few Jews who had escaped from those who were trying to take them into exile in Babylon and so remained in Jerusalem. Since it is unclear from where they escaped, it may be best not to specify in the translation. AT: "the Jews who had escaped the exile and who remained in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/remnant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Nehemiah 01:03

#### They said to me

Here "They" refers to Hanani and the other people who had come from Judah.

#### the province

Here "province" refers to Judah as an administrative district under the Persian Empire. AT: "the province of Judah" or "Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the wall of Jerusalem has been broken open, and its gates have been set on fire

This can be stated in active form. AT: "armies have broken open the wall of Jerusalem and have set its gates on fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Nehemiah 01:04

#### Then I said

Nehemiah tells what he prayed. AT: "Then I said to Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### who love him and keep his commandments

Since Nehemiah is speaking to Yahweh, the pronouns "him" and "his" can be translated as "you" and "your." AT: "who love you and keep your commandments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Nehemiah 01:06

#### open your eyes

"look at me." Here "open your eyes" is a metaphor that represents paying attention to someone. AT: "pay attention to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### so you may hear the prayer of your servant

"so that you may hear the prayer that I, your servant, am praying." The word "servant" refers to Nehemiah. This is how a person would address his superior in order to show humility and respect.

#### day and night

By saying that he prays both during the day and during the night, Nehemiah emphasizes the frequency of his prayers. AT: "all the time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### Both I and my father's house

Here the word "house" represents family. AT: "Both I and my family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]

### Nehemiah 01:08

#### Connecting Statement:

Nehemiah continues praying to God.

#### Please call to mind

To "call to mind" is an idiom that means to remember. AT: "Please remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the word you commanded your servant Moses

The pronouns "you" and "your" refer to God.

#### If you act unfaithfully ... scatter you ... if you return ... your people

The pronouns "you" and "your" are plural and refer to the Israelite people.

#### I will scatter you among the nations

Yahweh speaks of causing the Israelite people to live in other nations as if he scattered them like one would scatter seeds. AT: "I will cause you to live among the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### though your people were scattered

This can be stated in active form. AT: "though I scattered your people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### under the farthest skies

Yahweh speaks of places on the earth that are very far away as being "under the farthest skies." AT: "to places very far away" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### to that place where I have chosen ... remain

This phrase refers to Jerusalem, where the temple was located. AT: "to Jerusalem, where I have chosen ... remain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### where I have chosen to make my name remain

Here the word "name" represents Yahweh himself. AT: "where I have chosen to dwell" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Nehemiah 01:10

#### General Information:

Nehemiah continues his prayer.

#### Now

This word is used here to mark a break in Nehemiah's prayer. Here he begins to make his request based on Yahweh's promise.

#### they are your servants

The word "they" refers to the Israelite people.

#### by your great power and by your strong hand

Here "hand" represents strength or power. Together, these two phrases form a doublet that emphasizes the intensity of Yahweh's power. AT: "by your great power and by your mighty strength" or "by your very powerful strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the prayer of your servant

Here "servant" refers to Nehemiah. This is how a person would address his superior in order to show humility and respect. See how you translated this in [Nehemiah 1:6](./06.md).

#### the prayer of your servants

Here "servants" refers to the rest of the Israelite people who would have been praying for Yahweh to act on behalf of his people and on behalf of Jerusalem.

#### who delight to honor your name

Here "name" represents Yahweh himself. AT: "who delight to honor you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### grant him mercy in the sight of this man

Here "him" refers to Nehemiah, who refers to himself in the third person to express his humility before God, and "this man" refers to Artaxerxes, the king of Persia.

#### in the sight of this man

Nehemiah speaks of the king's attitude or disposition as if it were how the king viewed something. AT: "grant that the king will have mercy on me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I served as cupbearer to the king

This is background information about Nehemiah's role in the king's court. Your language may have a special way to mark background information. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beg.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cupbearer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cupbearer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Nehemiah 01:intro

#### Nehemiah 01 General Notes ####

####### Structure and formatting #######

######## "The words of Nehemiah son of Hacaliah:" ########
This phrase serves as an introduction to this entire book.

####### Special concepts in this chapter #######

######## Repentance ########
This chapter is a single long record of Nehemiah's repentance on behalf of the people. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]])

####### Other possible translation difficulties in this chapter #######

######## I ########
While the author of this book is probably Ezra, the word "I" always refers to Nehemiah.

######## Israel ########
It is uncertain to whom "Israel" refers. It probably does not refer to the northern kingdom of Israel. Neither does it likely refer to the twelve tribes of Israel. Instead, it is probably a reference to Israel in the sense of the surviving people group. At Nehemiah's time, this people group exclusively comprised the tribe of Judah because the other tribes had already been scattered throughout the entire Near East, where they lost their identity, for the most part. 

##### Links: #####

* __[Nehemiah 01:01 Notes](./01.md)__
* __[Nehemiah intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Nehemiah 02

### Nehemiah 02:01

#### In the month of Nisan

"Nisan" is the name of the first month of the Hebrew calendar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### in the twentieth year of Artaxerxes the king

"in the 20th year that Artaxerxes was king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### Now

This word is used here to mark a break in the main story line. Here Nehemiah tells background information about his demeanor before the king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### But the king

"So the king"

#### Why is your face so sad

Here Nehemiah is referred to by his face because the face shows one's emotions. AT: "Why are you so sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### This must be sadness of heart

This speaks of Nehemiah being sad as if his heart were sad, since the heart is often considered the center of emotions. AT: "You must be very sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Then I became very much afraid

As Nehemiah prepares to answer, he is afraid because he does not know how the king will respond.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeyear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]

### Nehemiah 02:03

#### May the king live forever

Nehemiah is showing honor to King Artaxerxes. Here "forever" is an exaggeration that refers to a long life. AT: "Long live the king" or "May the king have a long life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Why should not my face be sad?

Here Nehemiah uses this rhetorical question to tell the king that he has a reason to be sad. This can be written as a statement. AT: "I have very good reasons to be sad." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the place of my fathers' tombs

"the place where my ancestors are buried"

#### its gates have been destroyed by fire

This can be stated in active form. AT: "fire has destroyed its gates" or "our enemy has burned its gates" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Nehemiah 02:04

#### I replied to the king

"Then I replied to the king"

#### your servant

Nehemiah refers to himself this way to show his submission to the king.

#### in your sight

Here sight represents judgment or evaluation. AT: "in your judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the city of my fathers' tombs

"the city where my ancestors are buried"

#### that I may rebuild it

Nehemiah does not plan to do all of the building himself, but he will be the leader of the work. AT: "that I and my people may rebuild it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]

### Nehemiah 02:07

#### may letters be given to me

This may be stated in active form. AT: "may you give letters to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa.

#### Asaph

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the good hand of God was on me

God's "good hand" represents his "favor." AT: "God's favor was upon me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 02:09

#### Sanballat the Horonite

Sanballat is the name of a man, and the Horonites were a people group. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Tobiah the Ammonite servant

This man was likely a freed slave now serving as an officer in Ammon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### heard this

"heard that I had arrived"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horsemen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Nehemiah 02:11

#### had put into my heart

Here Nehemiah's "heart" refers to his thoughts and will. AT: "had inspired me" or "had led me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### There was no animal with me

"There were no animals with me"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]

### Nehemiah 02:13

#### General Information:

A few men accompanied Nehemiah on this inspection, but he speaks in the first person because he was the primary person. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### I went out by night by the Valley Gate

"At night, I went out through the Valley Gate"

#### Jackal

a wild dog

#### Dung Gate

Presumably, refuse was removed from the city through this gate.

#### which had been broken open, and the wooden gates were destroyed by fire

This can be stated in active form. AT: "which Israel's enemies had broken open, and the wooden gates which their enemies had destroyed with fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/well.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Nehemiah 02:15

#### So I went up ... and I turned back

The other men with Nehemiah also followed him. AT: "So we went up ... and we turned back" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### by the Valley Gate

"through the Valley Gate"

#### the rest who did the work

This refers to the men who would later rebuild the walls. AT: "the others who would later do the work of rebuilding the walls" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/noble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 02:17

#### You see the trouble

Here "you" is plural, referring to all the people mentioned in [Nehemiah 02:16](./15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### its gates have been destroyed by fire

This can be stated in active form. AT: "how our enemies destroyed its gates by fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### so we will no longer be in disgrace

"so we will no longer be ashamed"

#### the good hand of my God was on me

God's "good hand" represents his "favor." AT: "my God's favor was upon me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### rise up and build

This is an idiom. AT: "begin building" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### So they strengthened their hands for the good work

The phrase "strengthened their hands" means to prepare to do something. AT: "So they prepared do this good work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trouble.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 02:19

#### Sanballat ... Tobiah

These are the names of men. See how you translated this in [Nehemiah 02:9-10](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Geshem

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### What are you doing? Are you rebelling against the king?

These rhetorical questions are used to mock Nehemiah. These can be written as statements. AT: "You are acting foolishly! You should not be rebelling against the king!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### the king

This refers to Artaxerses, the king of Persia.

#### will arise and build

This is an idiom. AT: "will begin rebuilding" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### But you have no share, no right, and no historic claim in Jerusalem

"But you have no share, legal right, or religious claim to Jerusalem"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Nehemiah 02:intro

#### Nehemiah 02 General Notes ####

####### Structure and formatting #######

This chapter begins the account of the construction of the wall. Many scholars believe these chapters teach valuable lessons on leadership. (See: [Nehemiah 2-6](./01.md))

######## Special concepts in this chapter ########

######## Nehemiah's character ########
Apparently, Nehemiah's character made an impression on the king. It was very unusual for a king to be so concerned with one of his servants. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Cultural Customs ########
In ancient Persia, they thought it was important for their conquered peoples to practice their own cultural customs. It was thought that this independence promoted peace in their vast kingdom. The rebuilding of Jerusalem may have been seen as a way to allow for the Jewish cultural practices. 

######## Yahweh's control ########
Yahweh is seen as very powerful. He is able to provide for his people, even through a foreign king. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]])

##### Links: #####

* __[Nehemiah 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Nehemiah 03

### Nehemiah 03:01

#### Then Eliashib the high priest rose up with his brother priests

"Then Eliashib the high priest came forward with his brothers, the priests"

#### Eliashib ... Zaccur son of Imri

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Tower of the Hundred

"Tower of the 100" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Tower of Hananel

This is the name of a tower. It is likely named after a man named "Hananel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### men of Jericho

This means that the men were from Jericho. AT: "men from Jericho" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/consecrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Nehemiah 03:03

#### Hassenaah ... Meremoth ... Uriah ... Hakkoz ... Meshullam ... Berechiah ... Meshezabel ... Zadok ... Baana

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### set its doors

"installed its doors" or "put its doors in place"

#### its bolts, and its bars

"its locks and bars." These locked the gates securely.

#### Meremoth repaired the next section ... Meshullam repaired ... Zadok repaired ... Tekoites repaired

These phrases refer to repairing the wall. AT: "Meremoth repaired the next section of the wall ... Meshullam repaired the wall ... Zadok repaired the wall ... Tekoites repaired the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the Tekoites

These are people from the town of Tekoa. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### ordered by their supervisors

This can be stated in active form. AT: "that their supervisors had ordered them to do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uriah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/uriah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 03:06

#### Joiada ... Paseah and Meshullam ... Besodeiah ... Melatiah ... Jadon

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### set its doors

"installed its doors" or "put its doors in place"

#### its bolts, and its bars

"its locks and bars." These locked the gates securely.

#### Gibeonite ... Meronothite

Gibeonites and Meronothites are people groups. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Gibeon and Mizpah

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Province Beyond the River

This is the name of the province that was west of the Euphrates River. It was across the river from the city of Susa. See how you translated this in [Nehemiah 2:7](../02/07.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Nehemiah 03:08

#### Uzziel ... Harhaiah ... Hananiah ... Rephaiah ... Hur ... Jedaiah ... Harumaph ... Hattush ... Hashabneiah

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### goldsmiths

A goldsmith is a person who makes gold jewelry and other gold objects.

#### goldsmiths, repaired ... Hur repaired ... Harumaph repaired ... Hashabneiah repaired

These phrases refer to repairing the wall. AT: "goldsmiths, repaired the wall ... Hur repaired the wall ... Harumaph repaired the wall ... Hashabneiah repaired the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### next to him was Hananiah, a maker of perfumes

Hananiah repaired the wall as well. AT: "next to him Hananiah, a maker of perfumes, repaired the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### perfumes

liquid substances that people put on their body in small amounts to smell pleasant

#### ruler

leader or chief administrator

#### half the district

"Half" means one part out of two equal parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Nehemiah 03:11

#### Malchijah ... Harim ... Hasshub ... Pahath-Moab ... Shallum ... Hallohesh

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### repaired another section ... repaired, along with his daughters

These phrase refer to repairing the wall. AT: "repaired another section of the wall ... repaired the wall, along with his daughters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Shallum son of Hallohesh, the ruler

Shallum was the ruler, not Hallohesh.

#### ruler

leader or chief administrator. See how you translated this in [Nehemiah 3:9](../08.md).

#### half the district

"Half" means one part out of two equal parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Nehemiah 03:13

#### Hanun

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the inhabitants of Zanoah

"the people from Zanoah"

#### Zanoah

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Valley Gate

"the Gate of the Valley" or "the Gate that Leads to the Valley." Try to translate this expression as a name, not just as a description.

#### set its doors

"installed its doors" or "put its doors in place"

#### its bolts, and its bars

"its locks and bars." These locked the gates securely.

#### They repaired a thousand cubits as far as the Dung Gate

They repaired the portion of the wall between the Valley Gate and the Dung Gate. AT: "They repaired a thousand cubits of the wall, from the Valley Gate to the Dung Gate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They repaired a thousand cubits

It is understood that they were repaing the wall of Jerusalem. AT: "They repaired a thousand cubits of the wall" or "They repaired another thousand cubits of the wall beyond the Valley Gate" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### a thousand cubits

"1,000 cubits." This may be written in modern measurements. AT: "460 meters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the Dung Gate

Presumably, refuse was removed from the city through this gate. Try to translate this expression as a name, not just as a description.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md)]]

### Nehemiah 03:14

#### Malchijah ... Recab ... Shallun ... Kol-Hozeh

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Malchijah son of Recab, the ruler

Malchijah was the ruler, not Recab.

#### ruler

leader or chief administrator. See how you translated this in [Nehemiah 3:9](../08.md).

#### Beth Hakkerem

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### He ... set its doors

"He installed its doors" or "He put its doors in place"

#### its bolts, and its bars

"its locks, and its bars." These locked the gates securely.

#### Shallun son of Kol-Hozeh, the ruler

Shallun was the ruler, not Kol-Hozeh.

#### the wall of the Pool of Siloam

This means that the wall was beside the Pool of Siloam. AT: "the wall that surrounded the Pool of Siloam" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-possession.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cityofdavid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cityofdavid.md)]]

### Nehemiah 03:16

#### Nehemiah ... Azbuk ... Rehum ... Bani ... Hashabiah

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Nehemiah son of Azbuk, the ruler

Nehemiah was the ruler, not Azbuk.

#### Nehemiah

This is a different man named Nehemiah from the person who authored this book.

#### ruler

leader or chief administrator. See how you translated this in [Nehemiah 3:9](../08.md).

#### half the district

"Half" means one part out of two equal parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### Beth Zur ... Keilah

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### repaired to the place ... Levites repaired

These phrases refer to repairing the wall. AT: "repaired the wall up to the place ... Levites repaired the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### mighty men

"warriors"

#### for his district

"representing his district" or "on behalf of his district"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Nehemiah 03:18

#### After him their countrymen repaired ... repaired another section

These phrases refer to repairing the wall. AT: "Next to him their countrymen repaired the wall ... repaired another section of the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### After him

"Next to him"

#### Binnui ... Henadad ... Ezer ... Jeshua

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Binnui son of Henadad, the ruler

Binnui was the ruler, not Henadad.

#### Keilah ... Mizpah

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ezer son of Jeshua, the ruler

Ezer was the ruler, not Jeshua.

#### that faced the ascent to the armory

"in front of the steps that went up to the armory"

#### armory

the place where weapons are kept

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]

### Nehemiah 03:20

#### After him

"Next to him"

#### Baruch ... Zabbai ... Eliashib ... Meremoth ... Uriah ... Hakkoz

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### repaired another section

This refers to repairing the wall. AT: "repaired another section of the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]

### Nehemiah 03:22

#### around Jerusalem, repaired ... Benjamin and Hasshub repaired ... Azariah ... repaired ... Binnui ... repaired

These phrases refer to repairing the wall. AT: "around Jerusalem, repaired the wall ... Benjamin and Hasshub repaired the wall ... Azariah ... repaired the wall ... Binnui ... repaired the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Benjamin ... Hasshub ... Azariah ... Maaseiah ... Ananiah ... Binnui ... Henadad

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### After them ... After him

"Next to them ... Next to him"

#### opposite their own house

"in front of their own house"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Nehemiah 03:25

#### Palal ... repaired ... Parosh repaired ... servants ... repaired ... repaired another section

These phrases refer to repairing the wall. AT: "Palal ... repaired the wall ... Parosh repaired the wall ... servants ... repaired the wall ... repaired another section of the wall"

#### Palal ... Uzai ... Pedaiah ... Parosh

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the tower that extends upward

"the tower that rises up"

#### upper house of the king

"higher palace of the leader of Israel"

#### the courtyard of the guard

This is the place where the guards stayed.

#### After him

"Next to him"

#### Ophel

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### opposite the Water Gate

"in front of the Water Gate"

#### the projecting tower ... the great projecting tower

"the tall tower ... the tall tower." The phrase "the projecting tower" means a tall tower that juts out from the wall. It is likely that both of these phrases refer to the same tower.

#### the Tekoites

These are people from the town of Tekoa. See how you translated this in [Nehemiah 3:5](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Nehemiah 03:28

#### priests repaired ... repaired the section ... east gate, repaired ... repaired another section ... repaired opposite

These phrases refer to repairing the wall. AT: "priests repaired the wall ... repaired the section of the wall ... east gate, repaired the wall ... repaired another section of the wall ... repaired the wall opposite" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### above the Horse Gate

The word "above" is used here because the priests' houses were likely located at a higher elevation than the Horse Gate.

#### opposite his own house

"in front of his own house"

#### After them ... After him

"Next to them ... Next to him"

#### Zadok ... Immer ... Shemaiah ... Shecaniah ... Hananiah ... Shelemiah ... Hanun ... Zalaph ... Meshullam ... Berechiah

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shemaiah son of Shecaniah, the keeper of the east gate

Shemaiah was the keeper of the east gate, not Shecaniah.

#### the keeper of the east gate

"the person who looked after the east gate" or "the person who opened and closed the east gate"

#### the sixth son

"son 6" or "son number 6" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### opposite his living chambers

"in front of the rooms where he stayed." The word "his" refers to Meshullam.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Nehemiah 03:31

#### After him

"Next to him"

#### Malchijah

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### goldsmiths

A goldsmith is a person who makes gold jewelry and other gold objects.

#### repaired to the house ... merchants repaired

These phrases refer to repairing the wall. AT: "repaired the wall to the house ... merchants repaired the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### merchants

"sellers" or "traders"

#### upper living chambers

the higher-level rooms where people stayed

#### Sheep Gate

This is the name of an entranceway in the wall.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Nehemiah 03:intro

#### Nehemiah 03 General Notes ####

####### Special concepts in this chapter #######

######## Priests ########
The priests worked on rebuilding the city. Normally, the priests were exempt from this type of work. Because they helped, it emphasizes that this is a holy work and something done for Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Cooperation ########
Everyone worked on this project. Many names are mentioned to emphasize the cooperation between the different families. Each was given a section of the wall to rebuild.

##### Links: #####

* __[Nehemiah 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Nehemiah 04

### Nehemiah 04:01

#### Now when Sanballat

Here Nehemiah uses the word "now" to signal a new part of the story.

#### Sanballat ... Tobiah

These are the names of a men. See how you translated this in [Nehemiah 2:10](../02/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### it burned within him, and he was furiously angry

Here "it" refers to Sanballat's realization that the Jews are rebuilding the walls. This speaks of Sanballat becoming very angry as if his anger were a burning fire. AT: "he became furiously angry" or "he became very angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### In the presence of his brothers

"In the presence of his kinsmen" or "In the presence of his clan"

#### What are these feeble ... Will they restore ... Will they offer ... Will they finish the work in a day?

Sanballat poses these questions to mock the Jews. These can be written as statements. AT: "These feeble Jews can accomplish nothing. They will never restore the city for themselves. They will not offer sacrifices. They will not finish the work in a day." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### feeble Jews

"weak Jews"

#### in a day

This speaks of not finishing something quickly by saying that it cannot be accomplished in a day. AT: "quickly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Will they bring to life the stones from the piles of rubble after they were burned?

Sanballat also poses this question to mock the Jews. This can be written as a statement. AT: "They will not bring to life again the stones from piles of rubble that were burned." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### bring to life the stones from the piles of rubble after they were burned

This speaks of the people rebuilding the city as if they were bring it back to life. AT: "restore the city and rebuild its walls from the useless stones that were burned and turned into rubble" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from the piles of rubble after they were burned

This can be stated in active form. AT: "from piles of rubble that someone had burned" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### If only a fox went up on what they are building, it would break down their stone wall

Sanaballat mocks the wall and exaggerates how weak it is by saying that a fox could knock it down. AT: "That wall they are building is so weak that even if a little fox climbed up on it, their stone wall would fall to the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/samaria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]

### Nehemiah 04:04

#### Hear, our God, ... for they have provoked the builders to anger. So

Here Nehemiah is praying to God. This can be stated clearly and written with quotation marks. AT: "Then I prayed, 'Hear, our God, ... for they have provoked the builders to anger.' So" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Hear, our God, for we are despised

Here the word "we" refers to the Jews. This can be stated in active form. AT: "Hear, our God, for our enemies despise us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### give them up to be plundered

This can be stated in active form. AT: "let their enemies rob them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Turn back their taunts on their own heads

The phrase "their taunts" refers to Sanballat's and Tobiah's insults. Here the word "heads" refers to the whole people. AT: "Turn their taunts onto themselves" or "Cause their insulting words to mock themselves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Do not cover over

This speaks of a forgiving a person's sins as if they were a object that could be physically hidden. AT: "Do not forgive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### do not erase their sin from before you

This speaks of forgetting a person's sins as if they were something written that could be erased. AT: "do not forget their sins

#### they have provoked the builders to anger

"they have angered the builders"

#### So we built the wall

"So we rebuilt the wall"

#### all the wall was joined together to half its height

This can be stated in active form. AT: "we joined the wall together and it was half its total height" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### half its height

"Half" means one part out of two equal parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/iniquity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 04:07

#### a great anger burned within them

This speaks of the people being very angry as if their anger were something that burned inside them. AT: "they became very angry" or "they became enraged" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### against Jerusalem

Here "Jerusalem" refers to the people who live there. AT: "against the people of Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### set a guard as protection

"put men around the wall to guard the city"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 04:10

#### There is too much rubble

Rubble is "burned stone" or "broken rock" or "unusable stone."

#### They will not know or see until we come among them

"They will not see us coming until we are beside them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 04:12

#### from all directions

This represents many directions. The word "all" is an exaggeration for represents "many." AT: "from many directions" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### spoke to us ten times

Here the number 10 is used to represent "many." AT: "spoke to us many times" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the exposed areas

"in the vulnerable areas"

#### I positioned each family

This refers to several people from each family, this likely does not include the women and children. AT: "I positioned people from each family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Call to mind the Lord

the phrase "call to mind" means to remember. AT: "Remember the Lord" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md)]]

### Nehemiah 04:15

#### It came about

"It happened that"

#### their plans were known to us

This can be stated in active form. AT: "we knew about their plans" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### my servants worked

"my young men worked"

#### half of my servants ... half of them

"Half" means one part out of two equal parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### the leaders stood behind all the people

"the leaders positioned themselves behind all the people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shield.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/armor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]

### Nehemiah 04:17

#### Everyone worked with one hand, and with the other hand he held his weapon

This is an exaggeration. They did not always work with only one hand, but they always had their weapon with them so that they were prepared to protect themselves and those around them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Nehemiah 04:19

#### I said

Here "I" refers to Nehemiah.

#### the nobles ... the officials

These are the leaders referred to in [Nehemiah 4:16](./15.md).

#### The work is great

Here the word "great" means "large-scale" or "huge."

#### the trumpet sound

This refers to someone blowing a trumpet. AT: "someone blowing a trumpet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 04:21

#### Half of them

Here "Half" means one part out of two equal parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### from the rising of the dawn until the coming out of the stars

This refers to the whole day, while it is light outside. AT: "from the first light of day until the very beginning of the night"

#### the rising of the dawn

It is the point in time that the sun rises that is "dawn." Here the sun rising is spoken of as if the "dawn" rose. AT: "the rising of the sun" or "dawn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### in the middle of Jerusalem

"within Jerusalem"

#### changed our clothes

"took off our clothes"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Nehemiah 04:intro

#### Nehemiah 04 General Notes ####

####### Special concepts in this chapter #######

######## Dedication ########
The people were so dedicated to rebuilding the walls that they worked with their weapons ready for battle right next to them. Even when they were threatened with an attack, they continued to trust in Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]])

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########

Sanballat uses a series of rhetorical questions. These are intended to show his intense anger against the Israelites. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

##### Links: #####

* __[Nehemiah 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Nehemiah 05

### Nehemiah 05:01

#### Then the men and their wives raised a great outcry against their fellow Jews

Since they were working on the wall, the workers did not have enough time to work to buy and grow food for their families. The full meaning of this statement can be made clear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the men and their wives

This refers to the men who were working on building the wall.

#### raised a great outcry

The word "outcry" can be expressed as a verb. AT: "cried out loudly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### We are mortgaging our fields

"We are having to pledge" or "We are having to give in pledge"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md)]]

### Nehemiah 05:04

#### Yet now our flesh and blood is the same as our brothers, and our children are the same as their children

Here the Jews are implying that they are of the same Jewish descent as the other Jews and that they of the same importance as the others. The meaning of this can be made clear. AT: "Yet our families are Jews just like the other Jew's families, and our children are just as important to us as their children are to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### our flesh and blood

This is an idiom which refers to their family members. AT: "our family" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Some of our daughters have already been enslaved

This can be stated in active form. AT: "We have already sold some of our daughters into slavery" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### But it is not in our power to help it because other men now own our fields and our vineyards

Since the mens' fields and vineyards are not in their possession, they are unable to produce the money they need to support their families. The full meaning of this can be made clear. AT: "But we are unable to change this situation because other men now own our fields and our vineyards which we need to support our lives" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### it is not in our power

This is an idiom which means that they do not have the resources to do something. AT: "we are unable" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tax.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Nehemiah 05:06

#### when I heard their outcry

The word "outcry" can be expressed as a verb. AT: "when I heard them cry out" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### You are exacting interest, each from his own brother

Every Jew would have known that it is wrong under the Law to charge interest to another Jew. The full meaning of this can be made clear. AT: "Each of you is charging interest to your own brother, and that is wrong under the Law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I held a great assembly against them

This means that he brought together a large group of people and brought these charges against them. The meaning of statement this can be made clear. AT: "I held a great assembly and brought these charges against them" or "I held them on trial in front of the assembly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### but you even sell your brothers and sisters that they may be sold back to us

This means that they are selling their family members as slaves to their fellow Jews. The full meaning of this statement can be made clear. AT: "Now you are selling your own people to be slaves of your fellow Jews, so that they might later sell them back to us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who had been sold to the nations

This can be stated in active form. AT: "who people had sold as slaves to the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sister.md)]]

### Nehemiah 05:09

#### Also I said

The pronoun "I" refers to Nehemiah.

#### What you are doing

"You" here refers to the Jewish nobles.

#### Should you not walk in the fear of our God to prevent the taunts of the nations that are our enemies?

This is a rhetorical question that Nehemiah is using to scold the nobles. It can be translated as a statement. AT: "You should walk in the fear of our God to prevent the taunts of the nations that are our enemies." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### walk in the fear of our God

This is and idiom. Here "walk" refers to a person's behavior and the way he lives. AT: "live your life in a way that honors God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the taunts of the nations that are our enemies

The word "taunt" means "slander" or "mockery" and it can be expressed as a verb. AT: "the nations who are our enemies from taunting us" or "the enemy nations from mocking us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### lending

borrowing or giving something to someone expecting repayment

#### loans

This is any money, food, or property that one person could let another person borrow in order to repay debts. The borrower would then be indebted to the lender.

#### percentage

A part of the value of the loan that the borrower was charged in interest.

#### you exacted from them

"you charged them" or "you made them pay"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]

### Nehemiah 05:12

#### Then they said

Here "they" refers to the Jewish leaders.

#### We will return what we took from them

The Jewish leaders are saying they will return the money which the poorer Jews paid in interest charges.

#### made them swear

Here the word "them" refers to the Jewish leaders.

#### Then I called

"I" refers to Nehemiah.

#### I shook out the fold of my robe

"I shook out the pockets of my robe." Many times in the Old Testament, oaths were physically demonstrated as a witness to what was promised. Nehemiah is demonstrating to the Jewish leaders what will happen if they break the promise they had made. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### So may God shake out of his house ... So may he be shaken out and emptied

Here Nehemiah speaks of God taking away all of a man's possessions as if God were shaking him out of his home and possessions like Nehemiah shook out his robe. AT: "So may God take away from every man who does not keep his promise all of his possessions and his home like I have taken everything out of the fold of my robe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Nehemiah 05:14

#### from the time I was appointed

Here "I" refers to Nehemiah.

#### from the twentieth year until the thirty-second year

"from the 20th year until the 32 year" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### of Artaxerxes the king

"that Artaxerxes was king"

#### twelve years

"12 years" or "during those 12 years." Nehemiah is restating the number of years to emphasize that he did this continually for the full time he was governor. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the food provided for the governor

This can be stated in active form. AT: "ate the food that the people provided for the governor"

#### for their daily

"every day for their"

#### former governors

"previous governors" or "governors from the past." Nehemiah was not the first governor of Judah.

#### forty shekels

"40 shekels" or "40 silver coins" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### But I did not do so because of the fear of God

"But because my fear of God I did not take the food" or "But I did not take the food because I feared God"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 05:16

#### I also continued

"I" refers to Nehemiah.

#### we bought

The word "we" refers to Nehemiah and his servants.

#### all my servants were gathered

This can be stated in active form. AT: "I gathered all of my servants there" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for the work

"to work on the wall"

#### 150 men

"one hundred and fifty men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### At my table were the Jews ... from among the nations who were around us

Nehemiah was responsible for providing food for all of these people. This can be stated clearly. AT: "Also, every day I was responsible to feed at our table the Jews and the officials, 150 people; and we also fed the visitors who came from other countries around us (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### my table

This refers to the governor's table. It was a communal table for the community and for discussion of issues.

#### officials

"government leaders"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Nehemiah 05:18

#### Now what was prepared each day was

This can be stated in active form. AT: "Each day I told my servants to prepare" or "Each day I told my servants to serve us the meat from" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### six choice ... ten days

"6 choice ... 10 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### wine in abundance

"enough wine for everyone"

#### yet for all this I did not demand the food allowance of the governor

"yet I never asked for the governor's food allowance"

#### Call me to mind

This is an idiom. It is a request for God to think about him and remember him. AT: "Remember me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### for good

This idiom is a request for God to reward him with good things because of the good that he has done for the people. AT: "and reward me" or "cause good to happen to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible//ox.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Nehemiah 05:intro

#### Nehemiah 05 General Notes ####

####### Special concepts in this chapter #######

######## Equality ########

The rich made money from the poor. The rich oppressed the poor by charging interest on loans. Because Nehemiah wanted to treat everyone fairly, he did not collect any taxes from them. This chapter also emphasizes that it was wrong to enslave a fellow Jew. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oppress.md)]]) 

######## Governor ########
Nehemiah was a governmental leader in Jerusalem, but he was not a king. Jerusalem had a great deal of independence, but it  was under the authority of the Persian king. The term "governor" reflects this idea, but a different term may be used in translation.

##### Links: #####

* __[Nehemiah 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Nehemiah 06

### Nehemiah 06:01

#### Sanballat, Tobiah, and Geshem

These are the names of men. See how you translated this in [Nehemiah 2:9-10](../02/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I had rebuilt the wall ... I had not yet

Nehemiah supervised the rebuilding of the wall and did not build it by himself. AT: "we had rebuilt the wall ... we had not yet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### any sections

This refers to sections of the wall. AT: "any sections of the wall" or "any gaps in the city wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### sent to me

This means that they sent a messenger with a message. AT: "sent a messenger to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Ono

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/arabia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Nehemiah 06:03

#### I am doing a great work

Nehemiah supervised the rebuilding of the wall. He did not build it by himself. AT: "We are doing a great work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Why should the work stop while I leave it and come down to you?

This rhetorical question is used to challenge Sanballat's request. This can be written as a statement. AT: "I cannot let the work stop and come down to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### down to you

The word "down" is used here because the plain of Ono where they were requesting Nehemiah to come is at a lower elevation than Jerusalem.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/messenger.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 06:05

#### Sanballat sent his servant to me in the same way the fifth time

Identifying this message separately means it is distinct in some way from the previous four messages and, therefore, should be noted. AT: " Sanballat sent his servant to me in the same way yet again" or "Sanballat sent his servant to me to deliver a fifth message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### an open letter

The letter was an unsealed diplomatic communication. This was an insult to the recipient because the courier was free to read it and spread its contents among the people of the region.

#### in his hand

This means he had the letter in his possession, but he did not necessarily carry it in his hand at all times. AT: "in his possession" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### It is reported among the nations

This can be stated in active form. AT: "The rumor in the region is" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### are planning to rebel

This means that they are planning to rebel against Artaxerxes, the Persian king, who was currently ruling the Jews. AT: "are planning to rebel against Artaxerxes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Nehemiah 06:07

#### the king will hear

"King Artaxerxes will hear"

#### Therefore come

"Therefore come meet with us"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]

### Nehemiah 06:08

#### Then I sent word to him

Here "I" refers to Nehemiah and "him" to Sanballat.

#### No such things have occurred as you say

"None of the things you have written have occurred"

#### for within your heart you invented them

Here the "heart" refers to the "mind," that is, to one's desires and thoughts. AT: "for within your mind you invented them" or "for you have made this up in your own imagination" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### For they all wanted to make us afraid

Here "they" refers to Nehemiah's enemies, Sanballat, Tobiah, Geshem, and their followers. The word "us" refers to the Jews.

#### They will drop their hands from doing the work

This is a descriptive phrase that means that they are stopping their work on the wall. AT: "The workers on the wall will stop doing the work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### strengthen my hands

Here Nehemiah requests for God to strengthen him by asking him to strengthen his "hands." AT: "strengthen me" or "give me courage" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 06:10

#### Shemaiah ... Delaiah ... Mehetabel

These are men's names. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### who was confined in his home

The writer does not give the reason for him being confined, so it is best to say that he was staying at home using the most general words possible. AT: "who could not leave his house" or "whom the authorities had ordered to stay in his house" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Would a man like me run away? Would a man like me go into the temple just so he could save his own life?

Nehemiah uses these rhetorical questions to emphasize that he will not do what Shemaiah has suggested. These questions may be written as statements. AT: "A man like me would not run away. A man like me would not go into the temple just to hide to stay alive." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Nehemiah 06:12

#### but that he had prophesied against me

"but that he had prophesied in order to oppose me"

#### and sin

Using the temple as a place to hide was sinful. It may be helpful to make this explicit. AT: "and sin by misusing the temple"

#### a bad name

This is an idiom. AT: "so that they could give me a bad reputation" or "so that they could give a bad report about me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Call to mind

This is an idiom. AT: "Remember"

#### Noadiah

This is the name of a woman. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]

### Nehemiah 06:15

#### So the wall was finished

This can be stated in active form. AT: "We finished the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the twenty-fifth day of the month of Elul

"day 25 of the month of Elul." Elul is the sixth month of the Hebrew calendar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### fifty-two days

"52 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### they fell greatly in their own eyes

"they thought much less of themselves" or "they lost confidence in themselves"

#### the work was done with the help of our God

This can be stated in active form. AT: "it was our God who helped us complete this work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 06:17

#### sent many letters

The nobles sent messengers to bring these letters to Tobiah. AT: "sent many messengers with letters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Tobiah's letters came

Here Tobiah's letters are personified as coming by themselves, when they were actually brought by messengers. AT: "Tobiah sent letters" or "Tobiah sent many messengers with letters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Tobiah

See how you translated this man's name in [Nehemiah 2:10](../02/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### who were bound by an oath to him

This speaks of people being loyal to Tobiah because they had pledged an oath to him as if their oath were a rope that bound their bodies. AT: "who had sworn an oath to him" or "who had made an oath and were loyal to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he was the son-in-law of Shecaniah

This means that Tobiah was married to the daughter of Shecaniah. See how you translated "Shecaniah" in [Nehemiah 3:29](../03/28.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Arah ... Jehohanan

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Meshullam ... Berechiah

These are the names of men. See how you translated this in [Nehemiah 3:4](../03/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They also spoke to me about his good deeds and reported my words back to him

"The Jewish nobles told me about Tobiah's good deeds and then told him about my responses"

#### Letters were sent to me from Tobiah

This can be stated in active form. Tobiah sent messengers to bring the letters to Nehemiah. AT: "Tobiah sent letters to me" or "Tobiah sent messengers to bring letters to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/letter.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/report.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Nehemiah 06:intro

#### Nehemiah 06 General Notes ####

####### Structure and formatting #######

The building of the wall is completed in this chapter. 

The ULB indents the lines in 6:6-7 because they are part of a long quotation.

####### Special concepts in this chapter #######

######## Miracle ########

Completing this city wall in only fifty-two days was considered proof that God had helped the Jews, especially given the opposition that they had experienced from the people in surrounding areas. 

##### Links: #####

* __[Nehemiah 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Nehemiah 07

### Nehemiah 07:01

#### When the wall was finished

This can be stated in active form. AT: "When we had finished the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I had set up the doors in place

This was done with help. AT: "I and others hung the doors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the gatekeepers and singers and Levites had been appointed

This can be stated in active form. Possible meanings are: 1) Nehemiah appointed them. AT: "I assigned the gatekeepers and singers and Levites to their tasks" or 2) Someone else appointed them. AT: "they assigned the gatekeepers and singers and Levites to their tasks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### gatekeepers

people assigned to each gate, responsible to control access to the city or temple, as well as to open and close the gates at times and for reasons set by the administrator

#### singers

vocal musicians who led in worship, in processions, and ceremonies, producing music and chants that emphasized and enhanced the occasion

#### Hanani ... Hananiah

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I gave my brother Hanani charge

"I gave the order for my brother Hanani to be the manager"

#### who had oversight of the fortress

"who was in charge of the fortress"

#### feared God more than many

"feared God more than many other people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 07:03

#### I said to them

The word "them" refers to Hanani and Hananiah.

#### Do not open the gates of Jerusalem until the sun is hot. While the gatekeepers are on guard, you may shut the doors and bar them

Possible meanings are 1) these actions were done by Hanani and Hananiah or 2) these actions were done by Hanani and Hananiah with the help of the gatekeepers or 3) the gatekeepers did these actions under the direction of Hanani and Hananiah.

#### the sun is hot

"the sun is high in the sky"

#### While the gatekeepers are on guard, you may shut the doors and bar them

"Shut the doors and bar them while the gatekeepers are still on guard"

#### gatekeepers

See how you translated this in [Nehemiah 7:1](./01.md)

#### shut the doors and bar them

"close the gates and lock them"

#### Appoint guards from those who live in Jerusalem

"Assign guards from those people who live in Jerusalem"

#### guard station

"guard post" or "guard duty place"

#### no houses had yet been rebuilt

This can be stated in active form. AT: "the people had not yet rebuilt the houses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Nehemiah 07:05

#### put into my heart

Here Nehemiah's "heart" refers to his thoughts and will. See how you translated this in [Nehemiah 2:12](../02/11.md). AT: "inspired me" or "led me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to enroll them

"to list and register them"

#### the book of the genealogy

This was a book that no longer exists.

#### found the following written in it

This can be expressed in active form. AT: "found that someone had written the following in it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]

### Nehemiah 07:06

#### These are the people of the province

"These are the descendants of this region"

#### went up out of

"returned from" or "came back from"

#### went up

This is an idiom that refers to traveling toward Jerusalem, which was on higher ground than the surrounding area. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### whom Nebuchadnezzar the king of Babylon took into exile

"whom Nebuchadnezzar, ruler of Babylon, took away from their home country." The army of Babylon did this under the command of Nebuchadnezzar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Zerubbabel ... Jeshua ... Nehemiah ... Azariah ... Raamiah ... Nahamani ... Mordecai ... Bilshan ... Mispereth ... Bigvai ... Nehum ... Baanah

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The number of the men

A census had been taken when the Israelites first returned to Jerusalem after the exile. The numbers represent how many men belonged to each family group. This sentence introduces the information in the following verses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nebuchadnezzar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md)]]

### Nehemiah 07:08

#### Connecting Statement:

Nehemiah is recounting the number of people who returned from exile. The people were grouped by families according to the name of their patriarchs. The number represents the number of men in each family. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Parosh ... Shephatiah ... Arah

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Nehemiah 07:11

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### through the descendants of Jeshua and Joab

"that is, the descendants of Jeshua and Joab"

#### Pahath-Moab ... Jeshua ... Joab ... Elam ... Zattu ... Zakkai

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joab.md)]]

### Nehemiah 07:15

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Binnui ... Bebai ... Azgad ... Adonikam

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Nehemiah 07:19

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Bigvai ... Adin ... Ater ... Hashum

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The descendants of Ater, of Hezekiah

The writer has shortened this sentence. AT: "the descendants of Ater, who is a descendant of Hezekiah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hezekiah.md)]]

### Nehemiah 07:23

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Bezai ... Hariph ... Gibeon

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bethlehem and Netophah

These are the names of places in Judah. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gibeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethlehem.md)]]

### Nehemiah 07:27

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Anathoth ... Beth Azmaveth ... Kiriath Jearim, Kephirah, and Beeroth ... Ramah and Geba

These are all names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Nehemiah 07:31

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Michmas ... Bethel and Ai ... Nebo ... Elam

These are all names of places. (See [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/elam.md)]]

### Nehemiah 07:35

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Harim ... Jericho ... Lod, Hadid, and Ono ... Senaah

These are all names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jericho.md)]]

### Nehemiah 07:39

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Jedaiah ... Jeshua ... Immer ... Pashhur ... Harim

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### of the house of Jeshua

The word "house" is a metonym for family. AT: "from the family of Jeshua" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]

### Nehemiah 07:43

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Jeshua ... Kadmiel ... Binnui ... Hodevah ... Asaph ... Shallum ... Ater ... Talmon ... Akkub ... Hatita ... Shobai

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### singers

See how you translated this in [Nehemiah 7:1](./01.md).

#### gatekeepers

See how you translated this in [Nehemiah 7:1](./01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Nehemiah 07:46

#### General Information:

These verses continue the names of people whose descendants returned from the exile.

#### Ziha ... Hasupha ... Tabbaoth ... Keros ... Sia ... Padon ... Lebana, ... Hagaba ... Shalmai ... Hanan ... Giddel ... Gahar

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Sia

This is the same man known by the name Siaha in Ezra 2:44.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Nehemiah 07:50

#### General Information:

These verses continue the names of people whose descendants returned from the exile.

#### Reaiah ... Rezin ... Nekoda ... Gazzam ... Uzza ... Paseah ... Besai ... Meunim ... Nephushesim

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Nehemiah 07:53

#### General Information:

These verses continue the names of people whose descendants returned from the exile.

#### Bakbuk ... Hakupha ... Harhur ... Bazluth ... Mehida ... Harsha ... Barkos ... Sisera ... Temah ... Neziah ... Hatipha

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]

### Nehemiah 07:57

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Sotai ... Sophereth ... Perida ... Jaala ... Darkon ... Giddel ... Shephatiah ... Hattil ... Pochereth Hazzebaim ... Amon

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Sophereth

This is the name of a man who is called Hassophereth in Ezra 2:55.

#### Perida

This is the name of a man who is also called Peruda in Ezra 2:55.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Nehemiah 07:61

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### went up

This is an idiom that refers to traveling toward Jerusalem, which was on higher ground than the surrounding area. AT: "returned" or "came back" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Tel Melah ... Tel Harsha ... Kerub ... Addon ... Immer

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Delaiah ... Tobiah ... Nekoda ... Habaiah ... Hakkoz ... Barzillai

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gilead.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Nehemiah 07:64

#### These sought their records among those enrolled by their genealogy

"They sought their written genealogical records" or "They searched their written genealogical records"

#### These sought

"These" refers to the descendants of Hobaiah, Hakkoz and Barzillai. (See: [Nehemiah 7:63](./61.md))

#### but they could not be found

This can be expressed in active form. AT: "but they could not find their records" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they were excluded from the priesthood as unclean

This can be translated in active form. The abstract noun "priesthood" can be translated as the verb "work as priests." AT: "the governor treated them as if they were unclean and did not allow them to work as priests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### until there rose up a priest with Urim and Thummim

This can be stated in active form. AT: "until a priest with Urim and Thummim approved" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Urim and Thummim

These were sacred stones that the high priest carried on his breastplate and used at times to determine God's will. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/raise.md)]]

### Nehemiah 07:66

#### Connecting Statement:

Nehemiah is continuing to recount the number of people who returned from exile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### The whole assembly together

"The whole group together"

#### was 42,360

"was 42,360 people"

#### singing men and women

"male singers and female singers"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Nehemiah 07:68

#### 736 ... 245 ... 435 ... 6,720

"seven hundred and thirty-six ... two hundred and forty-five ... four hundred and thirty-five ... six thousand seven hundred and twenty." These are numbers of animals brought back. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/camel.md)]]

### Nehemiah 07:70

#### the heads of ancestors' families

"the chief patriarchs" or "the leaders of the clans"

#### gave to the treasury

"put into the treasury"

#### one thousand darics

"1,000 darics" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### darics of gold

A daric was a small gold coin that people in the Persian Empire used. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### 50 basins

"fifty basins." These are large bowls. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### 530 priestly garments

"five hundred thirty priestly garments." These are items of clothing worn by the priests. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### twenty thousand darics

"20,000 darics" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### 2,200 minas of silver

"two thousand two hundred minas of silver." A mina is about one half of a kilogram in weight. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### silver

a shiny, gray precious metal used to make coins, jewelry, containers, and ornaments

#### two thousand minas

"2,000 minas" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### sixty-seven priestly garments

"67 priestly garments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Nehemiah 07:73

#### gatekeepers

See how you translated this in [Nehemiah 7:1](./01.md).

#### singers

See how you translated this in [Nehemiah 7:1](./01.md).

#### some of the people

The implied information is that this refers to some of the Israelites who were not priests or other temple workers. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all Israel

Possible meanings are: 1) all the groups of Israelites that are listed in this verse or 2) the rest of the Israelites who did not work in the temple.

#### the seventh month

"month 7." This is the seventh month of the Hebrew calendar. It is during the last part of September and the first part of October on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### were settled in their cities

"lived in their own cities"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Nehemiah 07:intro

#### Nehemiah 07 General Notes ####

####### Special concepts in this chapter #######

######## Genealogy ########

The people who returned from Persia were counted according to their families. Nehemiah ensured that those who lived in Jerusalem had a completely Jewish ancestry.

######## Different lists ########
This list is paralleled in [Esra Ezra 2](../../ezr/02/01.md). The lists do contain some differences in numbers. This is probably due to the timing of their counting. They were likely counted at different times.

##### Links: #####

* __[Nehemiah 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Nehemiah 08

### Nehemiah 08:01

#### All the people gathered as one man

The word "all" is a generalization that indicates the people as a whole came together. AT: "The people gathered all together" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Water Gate

This was the name of a large opening or doorway in the wall.

#### the Book of the Law of Moses

This would have been all or part of the first five books of the Old Testament.

#### On the first day of the seventh month

This is the seventh month of the Hebrew calendar. The first day of the seventh month is near the middle of September on Western calendars. AT: "On day 1 of month 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### brought the law

"brought The Book of the Law"

#### all who could hear and understand

This would include children who were old enough to understand what was being read.

#### He faced the open area

"He turned towards the open area"

#### he read from it

Here "it" refers to the Book of the Law of Moses.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]

### Nehemiah 08:04

#### Mattithiah, Shema, Anaiah, Uriah, Hilkiah, and Maaseiah ... Pedaiah, Mishael, Malchijah, Hashum, Hashbaddanah, Zechariah, and Meshullam

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ezra opened the book in the sight of all the people

The abstract noun "sight" can be expressed with the verb "see." AT: "Everyone saw Ezra open the book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the book

"The Book of the Law"

#### he was standing above the people

"he was standing higher than the people"

#### when he opened it all the people stood up

The people stood up out of respect for God's word. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]

### Nehemiah 08:06

#### Ezra gave thanks to Yahweh

The abstract noun "thanks" can be translated as a verb. AT: "Ezra thanked Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Jeshua, Bani, Sherebiah, Jamin, Akkub, Shabbethai, Hodiah, Maaseiah, Kelita, Azariah, Jozabad, Hanan, Pelaiah

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They read in the book

The word "They" here refers to the Levites.

#### making it clear with interpretation and giving the meaning

The abstract nouns "interpretation" and "meaning" can be translated as verbs. AT: "clearly interpreting and explaining it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the reading

"what was read"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]

### Nehemiah 08:09

#### For all the people wept

This is a generalization that indicates there was great weeping among the people. AT: "For the people wept greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### eat the fat and have something sweet to drink

The implied information is that the people were told to feast on rich food and sweet drinks. AT: "eat rich food and drink something sweet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Do not be grieved

This can be stated in active form. AT: "Do not grieve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for the joy of Yahweh is your strength

The abstract nouns "joy" and "strength" can be expressed as verbs or adjectives. AT: "rejoicing in Yahweh will protect you" or "being joyful in Yahweh will be your strong refuge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Nehemiah 08:11

#### Hush!

"Be quiet!" or "Be silent!"

#### Do not be grieved

This can be stated in active form. AT: "Do not grieve" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### celebrate with great joy

The abstract noun "joy" can be expressed as a verb. AT: "rejoice greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the words that were made known to them

This can be stated in active form. AT: "the words that he declared to them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Nehemiah 08:13

#### On the second day

"On day 2" or "On the next day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### to gain insight from

The abstract noun "insight" can be expressed as a verb. AT: "to understand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### should live in shelters

These were temporary shelters that people made out of branches and leaves.

#### the seventh month

"month 7." This is the seventh month of the Hebrew calendar. It is during the last part of September and the first part of October on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]])

#### They should make a proclamation

"They should announce"

#### myrtle

a kind of small tree with colorful flowers (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### shade trees

"leafy trees"

#### as it is written

This can be translated in active form. AT: "as Moses wrote about it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]

### Nehemiah 08:16

#### made themselves shelters

"each built their own shelters"

#### Water Gate ... Gate of Ephraim

These are names of large openings or doorways in the wall.

#### in the square at the Gate of Ephraim

"in the open place by the Gate of Ephraim"

#### For since the days of Joshua

"From the days of Joshua"

#### son of Nun

"Nun" here is a man's name. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### their joy was very great

The abstract noun "joy" can be expressed as an adjective. AT: "the people were very joyful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/refuge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/house.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joshua.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Nehemiah 08:18

#### day by day

This idiom means "each day." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### from the first day to the last

The implied information is that it was during the entire week of the festival. AT: "from the first day to the last day of the week" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### They kept the festival

"They made a feast" or "They celebrated the festival"

#### on the eighth day

"on day 8" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### solemn assembly

This was a special religious gathering.

#### in obedience to the decree

The implied information is that "the decree" was the command of Yahweh about how the Festival of Shelters was to end. AT: "as God had commanded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]

### Nehemiah 08:intro

#### Nehemiah 08 General Notes ####

####### Special concepts in this chapter #######

######## Reading of the Law ########

During the exile, the Hebrew language was no longer spoken. Only the priests and Levites still understood it. Ezra read the book of the law to the people in Hebrew and the Levites walked among the crowd translating it into Aramaic for the people to understand. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

######## Festival of Shelters ########

After they heard Ezra read the Law of Moses, the people obeyed it by making temporary shelters for themselves with tree branches. They did this to remember that their ancestors slept in shelters when they came out of slavery in Egypt. 

##### Links: #####

* __[Nehemiah 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Nehemiah 09

### Nehemiah 09:01

#### the twenty-fourth day of the same month

"the twenty-fourth day of the seventh month" This is near the middle of October on Western calendars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-hebrewmonths.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the people of Israel were assembled

"the people of Israel came together"

#### they were wearing sackcloth, and they put dust on their heads

This was in order to show how sorry they were for the wrong things they and their ancestors had done. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### The descendants of Israel

"The Israelites"

#### separated themselves from all the foreigners

"no longer had anything to do with those who were not Israelites"

#### They stood and confessed their own sins and the evil actions of their ancestors

"They admitted the wrong things that they had done and also the wrong things their forefathers had done"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/biblicaltimeday.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Nehemiah 09:03

#### They stood up

All the Israelites stood up

#### they were confessing

"they were admitting the wrong things they had done"

#### bowing down before

"worshiping" or "praising"

#### The Levites, Jeshua, Bani ... stood on the stairs

Some versions translate, "Jeshua, Bani ... stood on the stairs built for the Levites"

#### Jeshua, Bani, Kadmiel, Shebaniah, Bunni, Sherebiah, Bani, and Kenani

men's names (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]

### Nehemiah 09:05

#### Then the Levites ... said, "Stand up ... ever."

Here the Levites are speaking to the people of Israel.

#### give praise to Yahweh

"bless Yahweh"

#### Jeshua ... Kadmiel ... Bani ... Sherebiah ... Shebaniah

men's names. See how you translated this in [Nehemiah 9:3-4](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hashabneiah ... Hodiah ... Pethahiah

men's names (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### May they bless your glorious name

the Levites are speaking to Yahweh. "May the people of Judah bless your glorious name, Yahweh"

#### the highest heavens, with all their host ... the host of heaven worship you

A host is an army. The "host of heaven" speaks in a metaphor of the many stars as if they were an army. The stars in turn are a metaphor for the many angels. The stars worshiping Yahweh is a metaphor for the angels worshiping Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/exalt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Nehemiah 09:07

#### Connecting Statement:

The Levites continue their prayer before all the people.

#### Ur of the Chaldees

"Ur, where the Chaldean people group lived"

#### You found his heart was faithful before you

The heart, the inner being of the person, represents the person. AT: "You saw that he was completely faithful to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Canaanites ... Hittites ... Amorites ... Perizzites ... Jebusites ... Girgashites

people group names (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/abraham.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/chaldeans.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/chaldeans.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/hittite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/amorite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/perizzite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jebusites.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]

### Nehemiah 09:09

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### You saw

Yahweh saw

#### you heard their cry

The implied information is that God was moved to action because of the Israelites' cries for help. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### signs and wonders against Pharaoh

The plagues tested Pharaoh's heart, and they became a witness against his hardness of heart. AT: "signs and wonders that testified against Pharaoh" or "signs and wonders that condemned Pharaoh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### all the people of his land

"all the Egyptians"

#### acted with arrogance against them

"were arrogant toward the Israelites" or "mistreated God's chosen people"

#### you made a name for yourself which stands to this day

Here "name" represents a reputation. AT: "you made yourself famous and even now people still remember" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/afflict.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/redsea.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/pharaoh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Nehemiah 09:11

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### you divided the sea

God divided

#### you ... threw those who pursued them into the depths, as a stone into deep waters

In this simile, the writer describes God throwing the Egyptians into the sea as easily as a person would throw a stone into water, and the stone would disappear under the water completely. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/stone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Nehemiah 09:12

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### You led them

Yahweh led the Israelites.

#### you came down

When God talks with his people, he is often described as "coming down" or "coming down from heaven." This is a descriptive way of saying that God appeared to that person. AT: "you appeared" or "you came down from heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### righteous decrees and true laws, good statutes and commandments

Both of these double phrases describe the same thing, the law of Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sinai.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Nehemiah 09:14

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### commandments ... statutes ... law

Each of these three words refers to the law of Moses. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]

### Nehemiah 09:16

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### they and our ancestors

the Israelites at the time of Moses and the people of Israel after the time of Moses

#### they were stubborn ... became stubborn

The literal statement is "they hardened their necks." If your language has a different idiom for being stubborn, you may want to use it here. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the wonders that you had done among them

"the miracles that you had done among them"

#### they appointed a leader to return to their slavery

The Israelites would know that this referred to their ancestors wanting to return to Egypt. AT: "they appointed a leader to take them back to Egypt where they had been slaves" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### who is full of forgiveness

The desire to forgive is spoken of as if it were a liquid that could fill a container. AT: "who is ready to forgive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### abounding in steadfast love

Love is spoken of as if it were a food crop that Yahweh could share with people. AT: "loves his people very much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forgive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Nehemiah 09:18

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### you ... did not abandon them

Yahweh did not abandon the Israelites.

#### cast a calf out of molten metal

melted metal and molded it in the shape of a calf

#### The pillar of cloud ... the pillar of fire

See how you translated this in [Nehemiah 09:12](./12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Nehemiah 09:20

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### Your good Spirit ... your manna ... water

The writer changes the usual word order to emphasize the good things Yahweh gave his people. Your language may have another way of emphasizing these items.

#### instruct

"teach"

#### your manna you did not withhold from their mouths

This litotes can be expressed positively. AT: "you generously gave them manna" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-litotes.md)]])

#### from their mouths

The mouth is a synecdoche for the whole person. AT: "from them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Nehemiah 09:22

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### You gave them kingdoms

Yahweh gave the Israelites kingdoms.

#### gave them kingdoms and peoples

"enabled them to conquer kingdoms and peoples"

#### assigning to them every corner of the land

"enabling them to possess every part of the land"

#### Sihon ... Og

These are the names of kings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Heshbon ... Bashan

These are names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bashan.md)]]

### Nehemiah 09:23

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### You made their children

Yahweh made the descendants of the Israelites at the time of Moses

#### gave them into their hands

The Canaanites are spoken of as if they were small objects that a person could place in the hand of another person. To give something into a person's hand is to give that person complete control over that thing. AT: "enabled the Israelites to have complete control over them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/possess.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/canaan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Nehemiah 09:25

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### They captured

The Israelites at the time of Moses captured

#### a productive land

"a fertile land"

#### cisterns

holes in the ground where people store water

#### grew fat

This might be a metaphor for "stopped thinking about Yahweh" or "became complacent." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]

### Nehemiah 09:26

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### They threw your law behind their backs

The law is spoken of as if it were a worthless item that a person could throw away. AT: "They considered your law worthless and paid no attention to it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They threw your law

The Israelites threw Yahweh's law.

#### you gave them into the hand of their enemies, who made them suffer

Here "hand" represents power or control. AT: "you allowed their enemies to defeat them and cause them to suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you sent them rescuers who rescued them out of the hand of their enemies

Here "hand" represents power or control. AT: "you sent people to stop their enemies from harming them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/disobey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]

### Nehemiah 09:28

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### they had rest, they did evil again before you

Here "they" refers to the Israelites and "you" to Yahweh.

#### you abandoned them to the hand of their enemies

Here "hand" represents power or control. AT: "you abandoned them and allow their enemies to defeat them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### did not listen to your commands

If your language has a word for "listen" that also means "obey," use it here.

#### your decrees which give life to anyone who obeys them

Yahweh himself is spoken of as if he were the decrees themselves. AT: "you even though you give life to everyone who obeys your decrees" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They gave the stubborn shoulder-blade and stiffened their neck

These are images of an ox refusing to allow its owner to put a yoke on its shoulders. Here they are a metaphor that represents the people being stubborn. AT: "They became stubborn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### Nehemiah 09:30

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### you gave them into the hand of the neighboring peoples

Here "hand" represents power or control. See how you translated these words in [Nehemiah 9:27](./26.md). AT: "you allowed the neighboring peoples to defeat them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you gave

Yahweh gave

#### you did not make a complete end of them

"you did not destroy them"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/forsaken.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Nehemiah 09:32

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### do not let all this hardship seem little to you that has come on us ... until today

It is possible to divide this into two sentences. "Do not let all this hardship seem little to you. The hardship has come upon us ... until today"

#### hardship ... has come on us ... everything that has come on us

The phrase "come on us" speaks of bad things that happen as if they are people who cause harm. AT: "harm ... we have suffered ... everything we have suffered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/awe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/assyria.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Nehemiah 09:35

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### while they enjoyed your great goodness to them

"while they enjoyed the good things you gave them"

#### they did not serve you

"they were not obedient to your law or teaching"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Nehemiah 09:36

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### its good gifts

"all the good things in it" or "all the good things we can get from it"

#### The rich yield from our land goes to the kings

"We pay tribute to kings for working our own land"

#### They rule

The kings rule.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/livestock.md)]]

### Nehemiah 09:38

#### Connecting Statement:

In these verses, the Levites continue to praise Yahweh in the presence of the people of Israel.

#### Because of all this

because the people had disobeyed and Yahweh had punished them

#### On the sealed document are the names

The reader should understand that the men wrote their names on the document before it was sealed.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Nehemiah 09:intro

#### Nehemiah 09 General Notes ####

####### Structure and formatting #######

This chapter and the next one form a single section.

####### Special concepts in this chapter #######

######## Prayer to God ########

The people prayed and thanked God for his care for them and the blessings he gave to them. They also confessed their sin of disobeying him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/confess.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]])

######## Learning from their ancestor's mistakes ########
This chapter teaches that the Jews learned from the mistakes of their ancestors. They became determined to worship Yahweh alone, to not intermarry with other peoples, and to worship Yahweh as the law of Moses instructed them. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]])

######## Recalling the great power of God ########
It was common to recall the great things God did for Israel. This is a reminder to Israel of God's power. It is intended to bring the people to repentance and proper worship of Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]])

##### Links: #####

* __[Nehemiah 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Nehemiah 10

### Nehemiah 10:01

#### On the sealed documents were Nehemiah ... Malchijah

The names of these people were written on the documents. This can be stated clearly. AT: "On the sealed documents were the names of Nehemiah ... Malchijah" or "On the sealed documents were the names of the following people: Nehemiah ... Malchijah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### sealed documents

The documents were sealed after the names had been signed on the documents.

#### Nehemiah

Some people believe that Nehemiah wrote this book and is speaking of himself as if he were someone else because this is an official list. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-pronouns.md)]])

#### Hakaliah

This is a man's name. See how you translated this in [Nehemiah 1:1](../01/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zedekiah, Seraiah ... Jeremiah, Pashhur, Amariah

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Azariah

This is a man's name. See how you translated this in [Nehemiah 3:23](../03/22.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Malchijah

This is a man's name. See how you translated this in [Nehemiah 3:11](../03/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zedekiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zedekiah.md)]]

### Nehemiah 10:04

#### General Information:

In these verses, Nehemiah lists the names of the priests who signed the sealed document. (See: [Nehemiah 10:1](./01.md))

#### Hattush

This is a man's name. See how you translated this in [Nehemiah 3:10](../03/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shebaniah ... Meshullam

These are the names of men. See how you translated this in [Nehemiah 9:4](../09/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Malluk ... Obadiah, Daniel, Ginnethon ... Abijah, Mijamin, Maaziah, Bilgai

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Harim

This is a man's name. See how you translated this in [Nehemiah 3:11](../03/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Meremoth

This is a man's name. See how you translated this in [Nehemiah 3:4](../03/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Baruch

This is a man's name. See how you translated this in [Nehemiah 3:20](../03/20.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shemaiah

This is a man's name. See how you translated this in [Nehemiah 3:29](../03/28.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### These were the priests

This refers to the previous list of men who signed the document. AT: "These were the names of the priests who signed the document" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Nehemiah 10:09

#### General Information:

In these verses, Nehemiah continues to list the names of the people who signed the sealed document.

#### The Levites were

This refers to those who put their names on the sealed documents. AT: "The Levites who put their names on the sealed documents were" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Jeshua ... Henadad

These are the names of men. See how you translated this in [Nehemiah 3:18-19](../03/18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Azaniah ... Rehob ... Beninu

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Binnui

This is a man's name. See how you translated this in [Nehemiah 3:24](../03/22.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Kadmiel

This is a man's name. See how you translated this in [Nehemiah 7:43](../07/43.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shebaniah

This is a man's name. See how you translated this in [Nehemiah 9:4](../09/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hodiah ... Kelita ... Pelaiah ... Sherebiah

These are the names of men. See how you translated this in [Nehemiah 8:7](../08/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hanan

This is a man's name. See how you translated this in [Nehemiah 7:49](../07/46.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Mika

This is a man's name. See how you translated this in [Nehemiah 10:11](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hashabiah ... Bani

These are the names of men. See how you translated this in [Nehemiah 3:17](../03/16.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Zaccur

This is a man's name. See how you translated this in [Nehemiah 3:2](../03/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The leaders of the people were

This refers to those who put their names on the sealed documents. AT: "The leaders of the people who put their names on the sealed documents were" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### Parosh

This is a man's name. See how you translated this in [Nehemiah 3:25](../03/25.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Pahath-Moab

This is a man's name. See how you translated this in [Nehemiah 3:11](../03/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Elam ... Zattu

These are the names of men. See how you translated this in [Nehemiah 7:12](../07/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]

### Nehemiah 10:15

#### General Information:

In these verses, Nehemiah continues to list the names of the people who signed the sealed document.

#### Bunni

This is a man's name. See how you translated this in [Nehemiah 9:4](../09/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Azgad, Bebai

These are the names of men. See how you translated this in [Nehemiah 7:16-17](../07/15.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Adonijah ... Azzur ... Nebai, Magpiash ... Hezir ... Jaddua

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bigvai

This is a man's name. See how you translated this in [Nehemiah 7:7](../07/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Adin, Ater, Hezekiah ... Hashum

These are the names of men. See how you translated this in [Nehemiah 7:20](../07/19.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hodiah

This is a man's name. See how you translated this in [Nehemiah 8:7](../08/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Bezai, Hariph

These are the names of men. See how you translated this in [Nehemiah 7:23](../07/23.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Anathoth

This is a man's name. See how you translated this in [Nehemiah 7:27](../07/27.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Meshullam ... Meshezabel, Zadok

These are the names of men. See how you translated this in [Nehemiah 3:4](../03/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md)]]

### Nehemiah 10:22

#### General Information:

In these verses, Nehemiah continues to list the names of the people who signed the sealed document.

#### Pelatiah ... Hoshea ... Pilha ... Shobek ... Hashabnah ... Ahiah ... Anan ... Harim ... Baanah

These are the name of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hanan

This is a man's name. See how you translated this in [Nehemiah 7:49](../07/46.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Anaiah

This is a man's name. See how you translated this in [Nehemiah 8:4](../08/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Anaiah

This is a man's name. See how you translated this in [Nehemiah 3:8](../03/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Hasshub ... Hallohesh

These are the names of men. See how you translated this in [Nehemiah 3:11](../03/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Rehum

This is a man's name. See how you translated this in [Nehemiah 3:17](../03/16.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Maaseiah

This is a man's name. See how you translated this in [Nehemiah 3:23](../03/22.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Malluk, Harim

These are the names of men. See how you translated this in [Nehemiah 10:4](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Baanah

This is a man's name. See how you translated this in [Nehemiah 7:6](../07/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

### Nehemiah 10:28

#### gatekeepers

This refers to the people assigned to each gate, responsible to control access to the city or temple, as well as to open and close the gates at times and for reasons set by the administrator. See how you translated this in [Nehemiah 7:1](../07/01.md).

#### singers

"temple singers"

#### all who have knowledge and understanding

This phrase can be made explicit. AT: "all who were old enough to understand what promising to obey God meant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### their brothers, their nobles

"their fellow brothers the nobles" or "their brothers the leaders." These phrases refer to the same people.

#### bound themselves with both a curse and an oath

This speaks of the people taking an oath and a curse as if the oath and the curse were a rope that physically bound them. AT: "swore themselves to an oath and a curse" or "they took an oath and called for a curse to come on themselves if they failed to keep it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### to walk in God's law

This is an idiom. AT: "to live by God's law" or "to obey God's law" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### which was given by Moses the servant of God

This can be stated in active form. AT: "which Moses the servant of God had given to Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to observe

"to follow"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/neighbor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pledge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/walk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lordyahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/decree.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/statute.md)]]

### Nehemiah 10:30

#### General Information:

In these verses, the people describe the content of the oath they were making in [Nehemiah 10:29](./28.md).

#### would not give our daughters to the people of the land or take their daughters for our sons

This means that they would not allow their sons and daughters to marry them. AT: "would not give our daughters to marry the people of the land or take their daughters to marry our sons" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the people of the land

This refers to the people who live in their land who do not worship Yahweh. AT: "the people of this land who do not worship Yahweh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### We promised ... we would not give ... we would not buy ... we will let ... we will cancel

The pronoun "we" here includes Nehemiah and the Jewish people, but not the reader of this book. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### seventh year

"year 7" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### we will let our fields rest

This is an idiom. AT: "we will not plow our fields" or "we will not grow anything in our fields" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### we will cancel all debts contracted by other Jews

"we will cancel all debts to other Jews" or "we will forgive all debts owed to us by other Jews"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]

### Nehemiah 10:32

#### General Information:

In these verses, the people continue describing the content of the oath they were making in [Nehemiah 10:29](./28.md).

#### We accepted the commands

"We promised to obey the command"

#### We accepted

The pronoun "we" here includes all the Israelites including Nehemiah except for the priest and Levites, and does not include the reader of this book (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### a third of a shekel

"1/3 of a shekel." "A third" means one part out of three equal parts. This can be written in modern measurements. AT: "5 grams of sliver" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### for the service of

"to pay for the care of"

#### the bread of the presence

This refers to the 12 loaves of bread baked without yeast kept in the temple and used to symbolize God's presence with His people.

#### the new moon festivals

These were celebrations held when the moon was just a small crescent in the sky.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burntoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/festival.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/feast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sinoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/atonement.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 10:34

#### General Information:

In these verses, the people continue describing the content of the oath they were making in [Nehemiah 10:29](./28.md).

#### to be burned

This can be stated in active form. AT: "for the Levites to burn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### as it is written

This can be stated in active form. AT: "as it states" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from our soil

"in our soil" or "on our land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]

### Nehemiah 10:37

#### General Information:

In these verses, the people continue describing the content of the oath they were making in [Nehemiah verse 29](./28.md).

#### We will bring ... We will bring

The pronoun "we" here includes Nehemiah and the Israelites except for the priests and the Levites, and also does not include the reader of this book (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### our dough

Possible meanings are that this refers to 1) dough made from coarse flour, 2) coarse flour, or 3) ground grain.

#### the new wine and the oil

The words "first of" are understood from the begininng of the sentnces. They can be repeated. AT: "the first of the new wine and of the oil" or "the best of the new wine and of the oil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the storerooms of the house of our God

"the places where things are stored in the temple"

#### the tithes from our soil

Here "our soil" refers to everything that is grown in the ground. AT: "the tithes of what we grow in the ground" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they receive the tithes

This can be stated in active form. AT: "the people give them the tithes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a tenth

This means one part out of ten equal parts. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### the storerooms of the treasury

"the storerooms in the temple"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]

### Nehemiah 10:39

#### General Information:

In these verses, the people finish describing the content of the oath they were making in [Nehemiah 10:29](./28.md).

#### the storerooms where the articles of the sanctuary are kept

This can be stated in active form. AT: "the rooms where the priests keep the things that are used in the temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### We will not neglect the house of our God

This can be stated in positive form. AT: "We will care for the temple"

#### We will

The pronoun "we" here includes Nehemiah and all the people of Israel but does not include the reader of this book. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-exclusive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctuary.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Nehemiah 10:intro

#### Nehemiah 10 General Notes ####

####### Structure and formatting #######

This chapter concludes the passage beginning in chapter 9.

####### Special concepts in this chapter #######

######## The vow ########

By signing this document, the people vowed or agreed to obey God, not to buy things on the Sabbath and to pay their temple tax. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/vow.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]])

##### Links: #####

* __[Nehemiah 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Nehemiah 11

### Nehemiah 11:01

#### the people cast lots

"the people threw marked stones"

#### to bring one of ten

"to bring one family out of every ten families"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]

### Nehemiah 11:03

#### on his own land, including some Israelites

"on his own land: Israelites"

#### some of the descendants of Judah and some of the descendants of Benjamin

"some of the people of Judah and some of the people of Benjamin"

#### The people from Judah included:

"From the descendants of Judah:"

#### Judah ... Benjamin ... Athaiah ... Uzziah ... Zechariah ... Amariah ... Shephatiah ... Mahalalel ... Perez

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### a descendant of Perez

"from the descendants of Perez"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]

### Nehemiah 11:05

#### Connecting Statement:

In these verses, Nehemiah continues to list the provincial officers who lived in Jerusalem.

#### Maaseiah ... Baruch ... Kol-Hozeh ... Hazaiah ... Adaiah ... Joiarib ... Zechariah ... Perez

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Shilonite

This refers to a person who comes from the town of Shiloh.

#### All ... were 468

"All ... were four hundred and sixty-eight." Perez had 468 descendants who lived in Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### They were outstanding men

"They were courageous men" or "They were valiant men"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Nehemiah 11:07

#### Connecting Statement:

In these verses, Nehemiah continues to list the provincial officers who lived in Jerusalem.

#### These are the descendants

"These are some of the descendants." Your language may need to specify that this is not a list of every descendant.

#### Benjamin ... Sallu ... Meshullam ... Joed ... Pedaiah ... Kolaiah ... Maaseiah ... Ithiel ... Jeshaiah ... Gabbai ... Sallai ... Joel ... Zichri ... Judah ... Hassenuah

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 928 men

"nine hundred and twenty-eight men." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/overseer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]

### Nehemiah 11:10

#### Jedaiah ... Joiarib ... Jakin ... Seraiah ... Hilkiah ... Meshullam ... Zadok ... Meraioth ... Ahitub ... Adaiah ... Jeroham ... Pelaliah ... Amzi ... Zechariah ... Pashhur ... Malchijah

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### their associates

"their brothers" or "their kinsmen"

#### who did the work for the house

"who worked in the temple." The "house" referred to here is the "house of God" mentioned in the previous verse.

#### 822 men

"eight hundred and twenty-two men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Nehemiah 11:13

#### His brothers

the brothers of Adaiah, the son of Jeroham ([Nehemiah 11:12](./10.md)).

#### brothers

This word is a metaphor for 1) fellow Israelites or 2) people who did the same work. AT: "associates" or "fellow workers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### 242 men

"two hundred and forty-two men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Amashsai ... Azarel ... Ahzai ... Meshillemoth ... Immer ... Zabdiel ... Haggedolim

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 128 courageous fighting men

"one hundred and twenty-eight courageous fighting men." These were "valiant warriors" or "courageous warriors." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Nehemiah 11:15

#### Shemaiah ... Hasshub ... Azrikam ... Hashabiah ... Bunni ... Shabbethai ... Jozabad

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### who were from the leaders of the Levites and were in charge

"from the leaders of the Levites, were in charge"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Nehemiah 11:17

#### Mattaniah ... Mika ... Zabdi ... Asaph ... Bakbukiah ... Abda ... Shammua ... Galal ... Jeduthun

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### who began the thanksgiving in prayer

That is, who directed the singers.

#### Bakbukiah, the second among his brothers

Possible meanings are 1) Bakbukiah was Mattaniah's kinsman and second in authority to Mattaniah or 2) "Bakbukiah, who led a second group of singers."

#### brothers

Another possible meaning is "associates" or "fellow workers."

#### the holy city

This expression refers to the city of Jerusalem.

#### numbered 284

"numbered two hundred and eighty-four." There were 284 Levites in Jerusalem. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Nehemiah 11:19

#### gatekeepers

people assigned to each gate, responsible to control access to the city or temple, as well as to open and close the gates at times and for reasons set by the administrator. See how you translated this in [Nehemiah 7:1](../07/01.md).

#### Akkub ... Talmon ... Ziha ... Gishpa

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### 172 men

"one hundred and seventy-two men" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Ophel

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]

### Nehemiah 11:22

#### The chief officer over

"The overseer of"

#### Uzzi ... Bani ... Hashabiah ... Mattaniah ... Mika ... Asaph ... Pethahiah ... Meshezabel ... Zerah ... Judah

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They were under orders from the king

"The king had told them what to do"

#### firm orders were given for the singers

This can be translated in active form. AT: "the king had told them specifically what to do about the singers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### at the king's side in all matters concerning the people

"at the Persian king's side as an adviser in all matters concerning the Jewish people"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Nehemiah 11:25

#### Kiriath Arba ... Dibon ... Jekabzeel ... Jeshua ... Moladah ... Beth Pelet ... Hazar Shual ... Beersheba

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Nehemiah 11:28

#### Ziklag ... Mekonah ... Enrimmon ... Zorah ... Jarmuth ... Zanoah ... Adullam ... Lachish ... Azekah ... Beersheba ... Valley of Hinnom

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### they lived

Here "they" refers to the people of Judah.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/beersheba.md)]]

### Nehemiah 11:31

#### The people of Benjamin also lived from Geba onward, at Mikmash and Aija

"The people of Benjamin lived in Geba, Mikmash and Aija"

#### Geba ... Mikmash ... Aija ... Bethel ... Anathoth, Nob, Ananiah, Hazor, Ramah, Gittaim, Hadid, Zeboim, Neballat, Lod ... Ono ... Judah

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Aija

This is possibly another name for the town of Ai.

#### the valley of craftsmen

Possible meanings are 1) this is a description of Ono or 2) it is "Craftsmen's Valley" or "the Valley of Craftsmen," another name for Ono, or 3) it is a different place from Ono, "and the Valley of Craftsmen." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Some of the Levites who lived in Judah were assigned to the people of Benjamin

"Some of the Judean divisions of Levites were assigned to live with the people of Benjamin"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/bethel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]

### Nehemiah 11:intro

#### Nehemiah 11 General Notes ####

####### Special concepts in this chapter #######

######## The places where the Jews lived ########

Some people lived in Jerusalem, but most people lived in villages and towns away from Jerusalem. They lived there in order to farm the land and raise their animals. The city with its walls was there to provide all of the people with protection if enemies attacked them. 

##### Links: #####

* __[Nehemiah 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Nehemiah 12

### Nehemiah 12:01

#### who came up

"who arrived from Babylonia"

#### with Zerubbabel

"under the leadership of Zerubbabel"

#### Zerubbabel ... Shealtiel ... Jeshua ... Seraiah ... Jeremiah ... Ezra ... Amariah ... Malluk ... Hattush ... Shecaniah ... Rehum ... Meremoth

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jeshua

The original readers would have understood that Jeshua was the high priest. AT: "Jeshua the high priest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]

### Nehemiah 12:04

#### Connecting Statement:

The list that began in [Nehemiah 12:1](./01.md) continues.

#### There were

These words have been added for this translation. If you continue the list that began in [Nehemiah 12:1](./01.md), you can omit these words.

#### Iddo ... Ginnethon ... Abijah ... Mijamin ... Moadiah ... Bilgah ... Shemaiah ... Joiarib ... Jedaiah ... Sallu ... Amok ... Hilkiah ... Jedaiah ... Jeshua.

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ginnethon

Ginnethoi may be another form of the name "Ginnethon."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]

### Nehemiah 12:08

#### Jeshua ... Binnui ... Kadmiel ... Sherebiah ... Judah ... Mattaniah ... Bakbukiah ... Unni

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### stood opposite them during the service

Possible meanings are 1) this was during a worship service and these were two groups of singers or other worshipers, or 2) these groups guarded the temple at different times, or "took turns guarding the temple."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Nehemiah 12:10

#### Jeshua ... Joiakim ... Eliashib ... Joiada ... Jonathan ... Jaddua

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jeshua was the father of Joiakim

This was the same Jeshua named in [Nehemiah 12:1](./01.md). The original readers would have understood that Jeshua was the high priest. AT: "Jeshua the high priest was the father of Joiakim" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]

### Nehemiah 12:12

#### Joiakim ... Meraiah ... Hananiah ... Meshullam ... Jehohanan ... Jonathan ... Joseph

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Seraiah ... Jeremiah ... Ezra ... Amariah ... Malluk ... Shebaniah

These are names of families named after men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]

### Nehemiah 12:15

#### Connecting Statement:

The list that began in [Nehemiah 12:12](./12.md) continues.

#### Adna ... Helkai ... Zechariah ... Meshullam ... Zichri ... Piltai ... Shammua ... Jehonathan ... Mattenai ... Uzzi ... Kallai ... Eber ... Hashabiah ... Nethanel

These are all names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Harim ... Meremoth ... Iddo ... Ginnethon ... Abijah ... Miniamin ... Moadiah ... Bilgah ... Shemaiah ... Joiarib ... Jedaiah ... Sallu ... Amok ... Hilkiah ... Jedaiah

These are all names of families that are named after men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### was the leader of

"was the leader of the family of" or "was the leader of the descendants of"

#### Meshullam was the leader of Ginnethon

Ginnethon may be another form of the name Ginnethoi.

#### ... of Miniamin

The people who made the copies of Hebrew text mistakenly left out the name of the leader of the family of Miniamin. Translators may supply a footnote explaining this. The ULB uses "..." to show that the name of the leader is missing. AT: "Someone was the leader of Miniamin"

#### Moadiah

Maadiah may be another form of the name Moadiah.

### Nehemiah 12:22

#### Eliashib ... Joiada, Johanan ... Jaddua

names of men (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### during the reign of Darius

Another possible meaning is "until the reign of Darius"

#### recorded in the book of the annals

This may refer to the Book of Chronicles. The scribes wrote the words in the verses above in a book that recorded the events of each day.

#### up to the days of Johanan son of Eliashib

The records in the temple recorded only up until Johanan.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/family.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/darius.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/persia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Nehemiah 12:24

#### Hashabiah, Sherebiah ... Jeshua ... Kadmiel ... David ... Mattaniah, Bakbukiah, Obadiah, Meshullam, Talmon, and Akkub ... Joiakim ... Jeshua ... Jozadak ... Nehemiah ... Ezra

These are names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### who stood opposite them to give praise and to give thanks, responding section by section

This refers to how they sang some of their songs in worship. A leader or one group would sing a phrase, then one or two groups that "stood opposite them" would sing a phrase in response.

#### obedience to the command of David

King David had commanded the Levites how they were to organize and lead worship.

#### in the days of Joiakim ... Jozadak, and in the days of Nehemiah the governor and of Ezra ... scribe

The date was fixed by listing those who were leading the Jews at the time. "when Joiakim ... Jozadak was high priest, and when Nehemiah was governor and Ezra ... was the scribe"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/obadiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/governor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]

### Nehemiah 12:27

#### At the dedication of the wall of Jerusalem

Possible meanings are 1) "At the time when they dedicated the wall of Jerusalem" or 2) "So that the dedication of Jerusalem's wall could take place."

#### cymbals

two thin, round metal plates that are hit together to make a loud sound (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dedicate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lute.md)]]

### Nehemiah 12:29

#### Beth Gilgal ... Geba and Azmaveth

These are the names of places. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Nehemiah 12:31

#### the leaders of Judah

the leaders of the people who lived in the region of Judah

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dung.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Nehemiah 12:32

#### Hoshaiah ... Azariah, Ezra, Meshullam, Judah, Benjamin, Shemaiah, Jeremiah ... Zechariah ... Jonathan ... Shemaiah ... Mattaniah ... Micaiah ... Zaccur ... Asaph

These are the names of males. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### after them went

"behind them followed"

#### some of the priests' sons with trumpets, and Zechariah

Some versions read, "from among the priests with trumpets, Zechariah"

#### Zechariah son of Jonathan son of Shemaiah son of Mattaniah son of Micaiah son of Zaccur son of Asaph

All of the names after "Zechariah" are the ancestors of Zechariah. This list connects Zechariah with the famous singer Asaph. "Zechariah who was the son of Jonathan, who was the son of Shemaiah, who was the son of Mattaniah, who was the son of Micaiah, who was the son of Zaccur son of Asaph"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md)]]

### Nehemiah 12:36

#### There also were

"Along with them were"

#### Zechariah ... Shemaiah, Azarel, Milalai, Gilalai, Maai, Nethanel, Judah, Hanani ... David ... Ezra

These are the names of males. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ezra the scribe was in front of them

"Ezra the scribe was leading them"

#### Fountain Gate ... Water Gate

These are the names of openings in the wall.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zechariahot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ezra.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cityofdavid.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/cityofdavid.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]

### Nehemiah 12:38

#### choir

"group of singers"

#### I followed them

Nehemiah followed them.

#### Tower of Ovens ... Tower of Hananel ... Tower of the Hundred

These are the names of tall structures where people kept watch for danger. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Broad Wall

This is a name for part of the wall.

#### Gate of Ephraim ... Old Gate ... Fish Gate ... Sheep Gate ... Gate of the Guard

These are the names of openings in the wall.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watchtower.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephraim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]

### Nehemiah 12:40

#### I also took my place

Nehemiah is speaking here. AT: "I, Nehemiah, also took my place"

#### Eliakim ... Maaseiah ... Miniamin ... Micaiah ... Elioenai ... Zechariah ... Hananiah ... Maaseiah ... Shemaiah ... Eleazar ... Uzzi ... Jehohanan ... Malchijah ... Elam ... Ezer

These are the names of males who were the priests at that time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Jezrahiah

This is the name of a male who was the leader of the singers.

#### with the trumpets

Possible meanings are 1) only the first seven priests listed from Eliakim to Hananiah carried trumpets or 2) all 15 priests listed from Eliakim to Ezer carried trumpets.

#### made themselves heard

"sang loudly"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Nehemiah 12:43

#### rejoice with great joy

"rejoice greatly"

#### So the joy of Jerusalem could be heard far away

"The joy of Jerusalem" here is a metonym for "the sound that the people of Jerusalem made." This can be translated in active form. AT: "people far away from Jerusalem could hear the sound that the people of Jerusalem made as they celebrated" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Nehemiah 12:44

#### men were appointed to be in charge

This can be stated in active form. It is not clear who appointed the men. AT: "they appointed men to be in charge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the contributions

things the people gave to the priests

#### For Judah rejoiced over the priests and the Levites

It seems that the people appointed the men because the people of Judah were grateful for the priests and Levites who were serving.

#### who were standing before them

The Levites and priests were not just standing, they were serving in their roles. The meaning can be made explicit. AT: "who were standing before them serving God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### gatekeepers

These were people assigned to each gate, responsible to control access to the city or temple, as well as to open and close the gates at times and for reasons set by the administrator. See how you translated this in [Nehemiah 7:1](../07/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]

### Nehemiah 12:46

#### there were directors of singers

This sentence tells why the people did what they did in [Nehemiah 12:45](./44.md) and gives us more information about the time when David told people how to worship at the temple.

#### In the days of Zerubbabel

Zerubbabel was a descendant of King David and one of the governors in the region of Judah.

#### They set aside the portion

"All Israel set aside the portion"

#### the descendants of Aaron

the priests in Israel, who descended from Aaron, the brother of Moses

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asaph.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/nehemiah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/aaron.md)]]

### Nehemiah 12:intro

#### Nehemiah 12 General Notes ####

####### Special concepts in this chapter #######

######## Dedication of the wall ########

In the ancient Near East, it was common to dedicate an important structure to a god. When it was completed, the wall was dedicated to Yahweh. Long lists of people are present, indicating that "everyone" was present for this and praised Yahweh. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

##### Links: #####

* __[Nehemiah 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Nehemiah 13

### Nehemiah 13:01

#### in the hearing of the people

"so that the people could hear it"

#### should come into the assembly of God, forever

"should ever come into the assembly of God"

#### This was because

"They could not come into the assembly because"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bread.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/law.md)]]

### Nehemiah 13:04

#### Eliashib the priest was appointed

This can be translated in active form. AT: "they appointed Eliashib the priest" or "the leaders appointed Eliashib the priest" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He was related to Tobiah

"Eliashib and Tobiah worked closely together"

#### Eliashib ... Tobiah

These are the names of men.

#### Eliashib prepared for Tobiah a large storeroom

"Eliashib prepared a large storeroom for Tobiah to use"

#### gatekeepers

people assigned to each gate, responsible to control access to the city or temple, as well as to open and close the gates at times and for reasons set by the administrator. See how you translated this in [Nehemiah 7:1](../07/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Nehemiah 13:06

#### But in all this time I was not in Jerusalem

"During the time all this was happening, I was away from Jerusalem"

#### I was not

Here "I" refers to Nehemiah.

#### a storeroom in the courts of the house of God

This was a room which had previously been purified to store offering supplies ([Nehemiah 13:5](./04.md)).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/artaxerxes.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Nehemiah 13:08

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/household.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grainoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]

### Nehemiah 13:10

#### the Levites' portions had not been given to them

The full meaning of this statement can be made clear. This can also be translated in active form. AT: "the people had not been bringing into the storerooms their tithes and offerings of food for the temple priests" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they had run away, each to his own field, the Levites and the singers who did the work

"the Levites and the singers who did the work had left the temple, each one going to his own field"

#### Why is the house of God neglected?

Nehemiah uses a rhetorical question to challenge or even ridicule the officials who had not done their work. This question can be translated as a statement. AT: "You have neglected the house of God!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Nehemiah 13:12

#### all Judah

The name of the land is a metonym for the people of the land. This is probably a generalization. AT: "all the people who lived in Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Shelemiah ... Zadok ... Pedaiah ... Hanan ... Zaccur ... Mattaniah

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### they were counted as trustworthy

This can be translated in active form. The abstract noun "trustworthy" can be translated as a verb. AT: "I knew that I could trust them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Call me to mind, my God, concerning this

"My God, remember me concerning this"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tenth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zadok.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/scribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Nehemiah 13:15

#### treading winepresses

The word "winepresses" is a metonym for the grapes that were in the winepresses. The people were walking on grapes to get the juice out of them to make wine. AT: "walking on grapes in winepresses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### treading

walking on something to crush or press it

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/donkey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Nehemiah 13:16

#### Tyre

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### What is this evil thing you are doing, profaning the Sabbath day?

Nehemiah is using a rhetorical question to scold the leaders of Judah. This can be translated as a statement. AT: "You are doing an evil thing by profaning the Sabbath day." or "God will punish you for doing this evil thing, for profaning the Sabbath day." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Did not your fathers do this? Did not our God bring all this evil on us and on this city?

Nehemiah is using these rhetorical questions to scold the leaders of Judah. These questions can be combined and translated as a statement. AT: "You know that your fathers did this, and that is why God brought all this evil on us and on this city." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/profane.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/father.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Nehemiah 13:19

#### As soon as it became dark ... before the Sabbath

"When the sun went down ... and it was time for the Sabbath to begin"

#### that the doors be shut and that they should not be opened until

This can be translated in active form. AT: "that the guards shut the doors and not open them until" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### no load could be brought in

This can be translated in active form. AT: "no one could bring in things they wanted to sell" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### sellers of all kinds of wares

"people who had brought many different things they wanted to sell"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Nehemiah 13:21

#### Why do you camp outside the wall?

Nehemiah uses a rhetorical question to rebuke merchants and to emphasize his command. This question can be translated as a statement. The full meaning of this statement can also be made explicit. AT: "You are camping outside the wall against what I commanded." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will lay hands on you!

The word "hands" is a metonym for forceful action. AT: "I will send you away by force!" or "I will remove you by force!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Call me to mind for this also, my God

"My God, remember me concerning this also." See how you translated a similar phrase in [Nehemiah 13:14](./12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sanctify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]

### Nehemiah 13:23

#### Connecting Statement:

These verses introduce the action that follows.

#### Jews that had married women of Ashdod, Ammon, and Moab

"Jews that had married foreign women." God had forbidden intermarriage. The full meaning of this statement can be made clear. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Ashdod

This is the name of a city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Ammon ... Moab

These are the names of nations. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Half of their children

"As a result, half of their children"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ashdod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ammon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moab.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]

### Nehemiah 13:25

#### I confronted them

"I spoke directly to them about what they had done"

#### I hit some of them

Nehemiah hit some of them with his hands.

#### I made them swear by God

"I made them say a promise before God"

#### Did not Solomon king of Israel sin on account of these women?

Nehemiah uses a rhetorical question to scold the men. This can be translated as a statement. AT: "You know that Solomon king of Israel sinned on account of these women." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Should we then listen to you and do all this great evil, and act treacherously against our God by marrying foreign women?

Nehemiah uses a rhetorical question to scold the men. This can be translated as a statement. AT: "We will not listen to you or do this great evil or act treacherously against our God by marrying foreign women." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/solomon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Nehemiah 13:28

#### Joiada ... Eliashib ... Sanballat

These are the names of men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the Horonite

This refers to a person from the city of Beth Horon. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### I caused him to flee from my presence

"I chased him away" or "I made him leave Jerusalem"

#### Call them to mind

"Think about them" or "Remember what they have done." See how you translated a similar phrase in [Nehemiah 13:14](./12.md).

#### they have defiled the priesthood, and the covenant of the priesthood and the Levites

Causing the priesthood to be dishonored and breaking the covenant is spoken of as if they made the priesthood and covenant physically unclean. AT: "they have dishonored the priesthood and broken the covenant you made with the priests and Levites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/highpriest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/covenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]

### Nehemiah 13:30

#### Thus I cleansed them

"In this way I purified them"

#### established the duties of the priests and the Levites

"told the priests and Levites what they were to do"

#### I provided for the wood offering

"I arranged for a supply of wood for the wood offerings"

#### for the firstfruits

"for the offering of firstfruits at harvest time"

#### Call me to mind, my God, for good

"Think about all I have done, my God, and bless me because of the good things I have done." See how you translated a similar phrase in [Nehemiah 13:14](./12.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foreigner.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/appoint.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/good.md)]]

### Nehemiah 13:intro

#### Nehemiah 13 General Notes ####

####### Special concepts in this chapter #######

######## Nehemiah returns to Jerusalem ########

Nehemiah was eager to make sure that the Jews kept their promise to obey the law. When he returned from Persia, he found many things wrong: one of the store rooms in the temple had been converted into a guest room for Tobiah, the Levites had not received their portions for working in the temple, people were working on the Sabbath, and many had married heathen wives. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promise.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lawofmoses.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sabbath.md)]])

##### Links: #####

* __[Nehemiah 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | __


## Nehemiah front

### Nehemiah front:intro

#### Introduction to Nehemiah ####

##### Part 1: General Introduction #####

####### Outline of Nehemiah #######

1. Nehemiah's return to Jerusalem 
    - How Nehemiah receives permission to return to Jerusalem (1:1–2:8)
    - Nehemiah begins to rebuild the walls of Jerusalem (2:9–2:20)
1. Rebuilding the walls of Jerusalem
    - Beginning at the Sheep Gate and attracting notice of enemies (3:1–32)
    - Sanballat and Tobiah threaten to stop the work on the walls (4:1–12)
    - The work proceeds under Nehemiah's leadership (4:13–23)
1. Nehemiah addresses mistreatment of the poor and provides an example of unselfishness (5:1–19)
1. Samaritans seek to slow the work of rebuilding the walls, but the walls are completed in fifty-two days (6:1–19)
1. A repeat of the counting of the people (7:6–70)
1. The renewal of the covenant with Yahweh (10:1–39)
1. A counting of the Jewish leaders in the region (11:1–36)
1. A counting of the priests and Levites (12:1–26)
1. The dedication of the walls of Jerusalem (12:27–47)
1. Correcting abuses and bringing reforms (13:1–31)

####### What is the Book of Nehemiah about? #######

The book of Nehemiah is about a Jew named Nehemiah. He lived in Persian and worked for the king. Nehemiah received a report about the condition of the wall around Jerusalem. In those times, the city wall was essential to the protection of the city against armies and invaders. Nehemiah returned to Jerusalem to help rebuild the city walls. 

####### How should the title of this book be translated? #######

It is suggested that translators use a self-explanatory title or follow the regional or the national language versions of the Bible. "Nehemiah" is named for the events of the book which focus on the leadership of Nehemiah. One possible title is "The Book about Nehemiah." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### Why were Israelites not allowed to marry people from other nations? #######

Foreigners worshiped many false gods. Yahweh did not allow his people to marry foreigners because he knew this would cause the people of Israel to worship other gods. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

####### Did all of the people of Israel return to their homeland? #######

Many of the Jews remained in Babylon instead of returning to the Promised Land. Many of them had become successful in Babylon and desired to remain there. However, this meant that they were unable to participate in the temple worship as their ancestors had done. . (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/promisedland.md)]])

##### Part 3: Important Translation Issues #####

####### How does the Book of Nehemiah use the term "Israel"? #######

The Book of Nehemiah uses the term "Israel" to refer to the kingdom of Judah, which was composed mostly of the two tribes of Judah and Benjamin. The other ten tribes had ended their loyalty to any kings descended from David. God allowed the Assyrians to conquer the other ten tribes and take them into exile. As a result, they became a part of other ethnic groups and did not return to the land of Israel. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]])

####### Are the events in the Book of Nehemiah told in the order that they actually happened? #######

Some of the events in the Book of Nehemiah are not told in the order they actually happened. Translators should pay attention to notes that signal when events are probably out of order with each other.



---

