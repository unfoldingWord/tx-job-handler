# <a id="rev"/>Revelation

## Revelation 01

### Revelation 01:01

#### General Information:

This is an introduction to the book of Revelation. It explains that it is a revelation from Jesus Christ and it gives a blessing to those who read it.

#### his servants

This refers to people who believe in Christ.

#### what must soon take place

"the events that must happen soon"

#### made it known

"communicated it"

#### to his servant John

John wrote this book and was referring to himself here. AT: "to me, John, his servant" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### the word of God

"Word of God" here is a metonym for the message from God. AT: "God's message" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the one who reads aloud

This does not refer to a specific person. It refers to anyone who reads it aloud. AT: "anyone who reads aloud" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### obey what is written in it

This can be stated in active form. AT: "obey what John has written in it" or "obey what they read in it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the time is near

"the things that must happen will soon happen"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]

### Revelation 01:04

#### General Information:

This is the beginning of John's letter. Here he names himself as the writer and greets the people he is writing to.

#### May grace be to you and peace from the one who is ... and from the seven spirits ... and from Jesus Christ

This is a wish or blessing. John speaks as if these were things that God could give, although they are really ways in which he hopes God will act for his people. AT: "May he who is ... and the seven spirits ... and Jesus Christ treat you kindly and enable you to live peacefully and securely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### from the one who is

"from God, who is"

#### who is to come

Existing in the future is spoken of as coming. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### seven spirits

The number seven is a symbol of completeness and perfection. The "seven spirits" refers either to the Spirit of God or to seven spirits who serve God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the firstborn from the dead

"the first person to be raised from death"

#### from the dead

From among all those who have died. This expression describes all dead people together in the underworld. To come back from among them speaks of becoming alive again.

#### has released us

"has set us free"

#### has made us a kingdom, priests

"has set us apart and begun to rule over us and he has made us priests"

#### his God and Father

This is one person. AT: "God, his Father"

#### Father

This is an important title for God that describes the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### to him be the glory and the power

This is a wish or prayer. Possible meanings are 1) "May people honor his glory and power" or 2) "May he have glory and power." John prays that Jesus Christ will be honored and will be able to rule completely over everyone and everything. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the power

This probably refers to his authority as king.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstborn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Revelation 01:07

#### General Information:

In verse 7, John is quoting from Daniel and Zechariah.

#### every eye

Since people see with the eyes, the word "eye" is used to refer to people. AT: "every person" or "everyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### including those who pierced him

"even those who pierced him will see him"

#### pierced him

Jesus' hands and feet were pierced when he was nailed to the cross. Here it refers to people killing him. AT: "killed him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### pierced

made a hole in

#### the alpha and the omega

These are first and last letters of the Greek alphabet. Possible meanings are 1) "the one who began all things and who ends all things" or 2) "the one who has always lived and who always will live." If unclear to readers you may consider using the first and last letters of your alphabet. AT: "the A and the Z" or "the first and the last" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### who is to come

Existing in the future is spoken of as coming. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### says the Lord God

Some languages would put "The Lord God says" at the beginning or the end of the whole sentence. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-quotations.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-quotations.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]

### Revelation 01:09

#### General Information:

John explains how his vision began and the instructions the Spirit gave him.

#### your ... you

These refer to the believers in the seven churches. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### I, John—your brother and the one who shares with you in the suffering and kingdom and patient endurance that are in Jesus—was

This can be stated as a separate sentence. AT: "I, John, am your brother who who shares with you in God's kingdom and also suffers and patiently endures trials along with you because we belong to Jesus. I was"

#### because of the word of God

"Word of God" here is a metonym for the message from God. AT: "because I spoke to others about the message of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I was in the Spirit

John speaks of being influenced by God's Spirit as if he were in the Spirit. AT: "I was influenced by the Spirit" or "The Spirit influenced me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### the Lord's day

the day of worship for believers in Christ

#### loud voice like a trumpet

The voice was so loud it sounded like a trumpet. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### trumpet

This refers to an instrument for producing music or for calling people to gather together for an announcement or meeting.

#### Smyrna ... Pergamum ... Thyatira ... Sardis ... Philadelphia ... Laodicea

These are names of cities in the region of western Asia that today is modern Turkey. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephesus.md)]]

### Revelation 01:12

#### Connecting Statement:

John begins to explain what he saw in his vision.

#### whose voice

This refers to the person speaking. AT: "who" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### son of man

This expression describes a human figure, someone who looks human. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### a golden sash

a piece of cloth worn around the chest. It may have had golden threads in it.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]

### Revelation 01:14

#### His head and hair were as white as wool—as white as snow

Wool and snow are examples of things that are very white. The repetition of "as white as" emphasizes that they were very white. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### wool

This is the hair of a sheep or goat. It was known to be very white.

#### his eyes were like a flame of fire

His eyes are described as being full of light like a flame of fire. AT: "his eyes were glowing like a flame of fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### His feet were like polished bronze

Bronze is polished to make it shine and reflect light. AT: "His feet were very shiny like polished bronze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### like polished bronze, like bronze that had been refined in a furnace

The bronze would be refined first and then polished. AT: "like bronze that has been purified in a hot furnace and polished" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])

#### furnace

a strong container for holding a very hot fire. People would put metal in it, and the hot fire would burn away any impurities that were in the metal.

#### the sound of many rushing waters

This is very loud, like the sound of a large, fast flowing river, of a large waterfall, or of loud waves in the sea.

#### a sword ... was coming out of his mouth

The sword blade was sticking out of his mouth. The sword itself was not in motion.

#### a sword with two sharp edges

This refers to a double-edged sword, which is sharpened on both sides to cut both directions.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/snow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]

### Revelation 01:17

#### fell at his feet like a dead man

John lay down facing the ground. He was probably very frightened and was showing Jesus great respect. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### He placed his right hand on me

"He touched me with his right hand"

#### I am the first and the last

This refers to the eternal nature of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### I have the keys of death and of Hades

Having the power over something is spoken of as having the keys to it. The implied information is that he can give life to those who have died and let them out of Hades. AT: "I have the power over death and over Hades" or "I have the power to give life to people who have died and to let them out of Hades" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]

### Revelation 01:19

#### Connecting Statement:

The Son of Man continues to speak.

#### stars

These stars are symbols that represent the seven angels of the seven churches. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### lampstands

The lampstands are symbols that represent the seven churches. See how you translated this in [Revelation 1:12](./12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the angels of the seven churches

Possible meanings are 1) heavenly angels who protect the seven churches or 2) human messengers to the seven churches.

#### seven churches

This refers to seven churches that actually existed in Asia Minor at that time. See how you translated this in [Revelation 1:11](./09.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Revelation 01:intro

#### Revelation 01 General Notes ####

####### Structure and formatting #######

This chapter explains how the book is a recording of the vision John received on the island of Patmos. 

Some translations indent quotations from the Old Testament. The ULB does this with the quoted material in 1:7.

####### Special concepts in this chapter #######

######## Seven churches ########
This letter was specifically addressed to seven actual churches located in the modern country of Turkey.

######## White ########
White is a color that often symbolizes holiness or righteousness in scripture. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]])

####### Important figures of speech in this chapter #######

######## "Him who is, and who was, and who is to come" ########
The phrase explains that God has always existed, exists now and will always exist. Not all languages have a way to easily translate the past, present and future aspects of a verb. It is possible this is a play on the name of God, Yahweh, which means "I am." 

######## His blood ########
This is a reference to Jesus' death. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

####### Other possible translation difficulties in this chapter #######

######## "He is coming with the clouds" ########
Many scholars believe Jesus will come back in two stages. Jesus' first return will be subtle, like a "thief in the night." Then, Jesus will come in an undeniable way where everyone will see him. It is this latter coming that the book of Revelation is about. 

######## Jesus ########
The image of the man in heaven is probably Jesus. Overall, the image is a description of Jesus in all of his glory. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## "The angels of the seven churches" ########
The Greek word translated as "angels" can also be translated as "messengers." It is possible this is a reference to the messengers or leaders of these seven churches.

##### Links: #####

* __[Revelation 01:01 Notes](./01.md)__
* __[Revelation intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Revelation 02

### Revelation 02:01

#### General Information:

This is the beginning of the Son of Man's message to the angel of the church in Ephesus.

#### the angel

Possible meanings are 1) a heavenly angel who protects the church or 2) a human messenger to the churches. See how you translated "angel" in [Revelation 1:20](../01/19.md)

#### stars

These stars are symbols. They represent the seven angels of the seven churches. See how you translated this in [Revelation 1:16](../01/14.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### lampstands

The lampstands are symbols that represent the seven churches. See how you translated this in [Revelation 1:12](../01/12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### I know ... your hard labor and your patient endurance

"Labor" and "endurance" are abstract nouns and can be translated with verbs "work" and "endure." AT: "I know ... that you work very hard and that you endure patiently" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### but are not

"but are not apostles"

#### you have found them to be false

"you have recognized that those people are false apostles"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/ephesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]

### Revelation 02:03

#### because of my name

"Name" here is a metonym for the person of Jesus Christ. AT: "because of me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]] )"because you believe in my name" or "because you believe in me"

#### you have not grown weary

Being discouraged is spoken of as being tired. AT: "you have not become discouraged" or "you have not quit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I have against you the fact that

"I disapprove of you because" or "I am angry with you because"

#### you have left behind your first love

To stop doing something is spoken of as leaving it behind. Love is spoken of as if it is an object that can be left behind. AT "you have stopped loving me as you did at the beginning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### from where you have fallen

No longer loving as much as they used to is spoken of as haven fallen. AT: "how much you have changed" or "how much you used to love me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Unless you repent

"If you do not repent"

#### remove your lampstand

The lampstands are symbols that represent the seven churches. See how you translated "lampstand" in [Revelation 1:12](../01/12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]

### Revelation 02:06

#### Nicolaitans

people who followed the teachings of a man named Nicolaus (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Let the one who has an ear listen

Being willing to listen is spoken of as having an ear. AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the one who conquers

This refers anyone who conquers. AT: "anyone who resists evil" or "those who do not agree to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### the paradise of God

"God's garden." This is a symbol for heaven.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 02:08

#### General Information:

This is the beginning of the Son of Man's message to the angel of the church in Smyrna.

#### Smyrna

This is the name of a city in a part of western Asia that today is modern Turkey. See how you translated this in [Revelation 1:11](../01/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the first and the last

This refers to the eternal nature of Jesus. See how you translated this in [Revelation 1:17](../01/17.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### I know your sufferings and your poverty

"Sufferings" and "poverty" can be translated as verbs. AT: "I know how you have suffered and how poor you are" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### I know the slander of those who say they are Jews

"Slander" can be translated as a verb. AT: "I know how people have slandered you—those who say they are Jews" or "I know how people have said terrible things about you—those who say they are Jews" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### but they are not

"but they are not real Jews"

#### a synagogue of Satan

People who gather to obey or honor Satan are spoken of as if they were a synagogue, a place of worship and teaching for the Jews. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]

### Revelation 02:10

#### The devil is about to throw some of you into prison

"The devil will soon cause others to put some of you in prison"

#### Be faithful until death

"Be faithful to me even if they kill you." The use of the word "until" does not mean that you should stop being faithful at death.

#### the crown

"the winner's crown." This was a wreath, originally of olive branches or laurel leaves, that was put on the head of a victorious athlete.

#### the crown of life

Possible meanings are 1) "a crown that shows that I have given you eternal life" or 2) "true life as a prize like a winner's crown" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let the one who has an ear

Being willing to listen is spoken of as having an ear. See how you translated this in [Revelation 2:7](./06.md). AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The one who conquers

This refers anyone who conquers. See how you translated this in [Revelation 2:7](./06.md). AT: "Anyone who resists evil" or "Those who do not agree to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### will not be hurt by the second death

"will not experience the second death" or "will not die a second time"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Revelation 02:12

#### General Information:

This is the beginning of the Son of Man's message to the angel of the church in Pergamum.

#### Pergamum

This is the name of a city in a part of western Asia that today is modern Turkey. See how you translated this in [Revelation 1:11](../01/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the sword with two sharp edges

This refers to a double-edged sword, which is sharpened on both sides to cut both directions. See how you translated this in [Revelation 1:16](../01/14.md)

#### Satan's throne

Possible meanings are 1) Satan's power and evil influence on people, or 2) the place where Satan rules. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you hold on tightly to my name

"Name" here is a metonym for the person. Firmly believing is spoken of as holding on tightly. AT: "you firmly believe in me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### you did not deny your faith in me

"Faith" can be translated with the verb "believe." AT "you continued to tell people that you believe in me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Antipas

This is the name of a man. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Revelation 02:14

#### But I have a few things against you

"I disapprove of you because of a few things you have done" or "I am angry with you because of a few things you did." See how you translated a similar phrase in [Revelation 2:4](./03.md).

#### who hold tightly to the teaching of Balaam, who

Possible meanings are 1) "who teach what Balaam taught; he" or 2) "who do what Balaam taught; he." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Balak

This is the name of a king. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### who taught Balak to throw a stumbling block before the children of Israel

Something that leads people to sin is spoken of as a stone in the road that people stumble on. AT: "who showed Balak how to cause the people of Israel to sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### be sexually immoral

"sin sexually" or "commit sexual sin"

#### Nicolaitans

This was the name for a group of people who followed the teachings of a man named Nicolaus. See how you translated this in [Revelation 2:6](./06.md) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/balaam.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/stumblingblock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]

### Revelation 02:16

#### Repent, therefore

"So repent"

#### If you do not, I

The verb can be supplied from the previous phrase. AT: "If you do not repent, I" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### wage war against them

"fight against them"

#### with the sword in my mouth

This refers to the sword in [Revelation 1:16](../01/14.md). Although symbols in apocalyptic language are not normally to be replaced with the item they represent, translators may choose whether or not to show that this as a symbol represents God's word, as the UDB does. This symbol indicates that Christ will defeat his enemies by giving a simple command. AT: "with the sword in my mouth, which is the word of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### Let the one who has an ear listen

Being willing to listen is spoken of as having an ear. See how you translated this in [Revelation 2:7](./06.md). AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### To the one who conquers

This refers anyone who conquers. See how you translated this in [Revelation 2:7](./06.md). AT: "anyone who resists evil" or "those who do not agree to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/manna.md)]]

### Revelation 02:18

#### General Information:

This is the beginning of the Son of Man's message to the angel of the church in Thyatira.

#### Thyatira

This is the name of a city in a part of western Asia that today is modern Turkey. See how you translated this in [Revelation 1:11](../01/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Son of God

This is an important title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### who has eyes like a flame of fire

His eyes are describes as being full of light like a flame of fire. See how you translated this in [Revelation 1:14](../01/14.md). AT: "whose eyes glow like a flame of fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### feet like polished bronze

Bronze is polished to make it shine and reflect light. See how you translated this in [Revelation 1:15](../01/14.md). AT: "whose feet are very shiny like polished bronze" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### your love and faith and service and your patient endurance

The abstract nouns "love," "faith," "service," and "endurance" can be translated with verbs. AT: "How you have loved, trusted, served, and endured patiently" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### your love and faith and service and your patient endurance

The implied objects of these verbs can be stated clearly. AT: "How you have loved me and others, trusted me, served me and others, and endured troubles patiently" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]

### Revelation 02:20

#### But I have this against you

"But I disapprove of some of the things you are doing" or "But I am angry with you because of something you are doing." See how you translated a similar phrase in [Revelation 2:4](./03.md).

#### the woman Jezebel, who

Jesus spoke of a certain woman in their church as if she were Queen Jezebel, because she did the same kinds of sinful things that Queen Jezebel had done long before that time. AT: "the woman who is just like Jezebel and" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I gave her time to repent

"I gave her opportunity to repent" or "I waited for her to repent"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezebel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jezebel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sacrifice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]

### Revelation 02:22

#### I will throw her onto a sickbed ... into great suffering

Her having to lie in bed would be the result of Jesus making her very sick. AT: "I will make her lie sick in bed ... I will make suffer greatly" or "I will make her very sick ... I will make suffer greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### those who commit adultery with her into great suffering

Jesus speaks of causing people to suffer as throwing them into suffering. AT: "I will make those who commit adultery with her to suffer greatly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### commit adultery

"practice adultery"

#### unless they repent of her deeds

This implies that they have participated with her in her wicked behavior. By repenting of her deeds, they also repent of participating in her behavior. AT: "if they do not repent from doing the evil that she does" or "if they do not repent of participating in her deeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I will strike her children dead

"I will kill her children"

#### her children

Jesus spoke of her followers as if they were her children. AT: 'her followers" or "the people who do what she teaches" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### thoughts and hearts

The term "heart" a metonym that represents feelings and desires. AT: "what people think and want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will give to each one of you

This is an expression about punishment and reward. AT: "I will punish or reward each one of you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/adultery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Revelation 02:24

#### everyone who does not hold this teaching

Believing a teaching is spoken of as holding the teaching. AT: "everyone who does not believe this teaching" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### does not hold this teaching

The noun "teaching" can be translated as a verb. AT: "does not hold to what she teaches" or "does not believe what she teaches"

#### what some call the deep things of Satan

Possible meanings are 1) those who called them the deep things understood that they were from Satan or 2) some people called them the deep things, but Jesus was saying that those things were really from Satan. AT: "the things of Satan, what some call the deep things"

#### the deep things of Satan

"the deep things that Satan teaches"

#### deep things

Secret things are spoken of as if they were deep. AT: "secret things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/burden.md)]]

### Revelation 02:26

#### The one who conquers

This refers anyone who conquers. See how you translated this in [Revelation 2:7](./06.md). AT: "Anyone who resists evil" or "The person who does not agree to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### He will rule ... break them into pieces

This is a prophecy from the Old Testament about a king of Israel, but Jesus applied it here to those to whom he gives authority over the nations.

#### He will rule them with an iron rod

Ruling harshly is spoken of as ruling with an iron rod. AT: "He will rule them harshly as if striking them with an iron stick" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### like clay jars he will break them into pieces

Breaking them to pieces is an image that represents either 1) destroying evildoers or 2) defeating enemies. AT: "He will defeat his enemies completely as if breaking clay jars into pieces" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Just as I have received from my Father

Some languages may need to tell what was received. Possible meanings are 1) "Just as I have received authority from my Father" or 2) "Just as I have received the morning star from my Father." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### my Father

This is an important title for God that describes the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### I will also give him

Here "him" refers to the one who conquers.

#### morning star

This is a bright star that sometimes appears early in the morning just before dawn. It was a symbol of victory. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### Let the one who has an ear listen

Being willing to listen is spoken of as having an ear. See how you translated this in [Revelation 2:7](./06.md). AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]

### Revelation 02:intro

#### Revelation 02 General Notes ####

####### Structure and formatting #######

Chapters 2 and 3 together form a single unit. This section is usually referred to as the "seven letters to the seven churches." The translator may wish to set these letters apart from each other to clearly distinguish them. 

Some translations indent quotations from the Old Testament. The ULB does this with the quoted material in 2:27.

####### Special concepts in this chapter #######

######## Poverty and wealth ########
This chapter has a play on the two possible meanings of being poor and rich. The Ephesians were poor financially because they did not have a lot of money. They were not poor spiritually because of the great "riches" they had in Christ. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]])

######## "The devil is about to" ########
The book of Revelation is about the things that Satan is going to do on earth. Despite this, it is ultimately about what God will do in the end to defeat Satan.

######## Balaam, Balak and Jezebel ########
These teachings of Balaam are difficult to fully understand if the books of Kings have not yet been translated. This is probably a reference to leading the people of Israel into immorality and the worship of false gods. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]])

####### Important figures of speech in this chapter #######

######## Metaphor ########
Some scholars take chapter 2 and 3 as a metaphor. They understand these churches to refer to types of churches or historical periods of the church. It is best to translate this as instructions to ancient churches in each of these cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## "If you have an ear, listen to what the Spirit says to the churches." ########
This is a phrase which acts as a call to repentance for those in the church. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]])

####### Other possible translation difficulties in this chapter #######

######## "The angels of the seven churches" ########

The Greek word translated as "angels" can also be translated as "messengers." It is possible this is a reference to the messengers or leaders of these seven churches.

######## "These are the words of the one" ########
This phrase, used to introduce these letters is probably a reference to Jesus. Each letter then describes an aspect of Jesus which is significant for the rest of the letter. 

##### Links: #####

* __[Revelation 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Revelation 03

### Revelation 03:01

#### General Information:

This is the beginning of the Son of Man's message to the angel of the church in Sardis.

#### Sardis

This is the name of a city in the western part of Asia that today is modern Turkey. See how you translated this in [Revelation 1:11](../01/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### the seven spirits

The number seven is a symbol of completeness and perfection. The "seven spirits" refers either to the Spirit of God or to seven spirits who serve God. See how you translated this in [Revelation 1:4](../01/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the seven stars

These stars are symbols that represent the seven angels of the seven churches. See how you translated this in [Revelation 1:16](../01/14.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### alive ... dead

Obeying and honoring God is spoken of as being alive; disobeying and dishonoring him is spoken of as being dead. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Wake up and strengthen what remains, but is about to die

The good deeds done by the believers in Sardis are spoken of as if they were alive but in danger of dying. AT: "Wake up and complete the work that remains, or what you have done will become worthless" or "Wake up. If you do not finish what you have started to do, your previous work will have been useless" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Wake up

Being alert to danger is spoken of as waking up. AT: "Be alert" or "Be careful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Revelation 03:03

#### what you have received and heard

This refers to God's word, which they believed. AT: "God's word that you heard and the truth that you believed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### if you do not wake up

Being alert to danger is spoken of as waking up. See how you translated "wake up" on [Revelation 3:2](./01.md). AT: "If you are not alert" or "If you are not careful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will come as a thief

Jesus will come at a time when people do not expect him, just as a thief comes when not expected. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a few names of the people

This refers to the people themselves. AT: "a few people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### did not make their clothes dirty

Jesus speaks of sin in a person's life as if it were dirty clothes. AT: "have not made their lives sinful like dirty clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### will walk with me

People commonly spoke of living as "walking." AT: "will live with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### dressed in white

White clothes represent a pure life without sin. AT: "and they will be dressed in white, which shows that they are pure" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thief.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]

### Revelation 03:05

#### The one who conquers

This refers anyone who conquers. See how you translated this in [Revelation 2:7](../02/06.md). AT: "Anyone who resists evil" or "Anyone who does not agree to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### will be clothed in white garments

This can be translated with an active verb. AT: "will wear white garments" or "I will give white clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I will speak his name

He would not simply say the person's name, but announce that the person belongs to him. AT: "I will announce that he belongs to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### before my Father

"in the presence of my Father"

#### my Father

This is an important title for God that describes the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Let the one who has an ear listen

Being willing to listen is spoken of as having an ear. See how you translated this in [Revelation 2:7](../02/06.md). AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Revelation 03:07

#### General Information:

This is the beginning of the Son of Man's message to the angel of the church in Philadelphia.

#### Philadelphia

This is the name of a city in the western part of Asia that today is modern Turkey. See how you translated this in [Revelation 1:11](../01/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### key of David

Jesus speaks of his authority to decide who may go into his kingdom as if it were King David's key. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### he opens and no one shuts

"he opens the door to the kingdom and no one can close it"

#### he shuts and no one can open

"he closes the door and no one can open it"

#### I have put before you an open door

"I have opened a door for you"

#### you have obeyed my word

"word" here is a metonym for message. AT: "you have followed by teachings" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### my name

The word "name" is often used to refer to the person who has that name. AT: "me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/strength.md)]]

### Revelation 03:09

#### synagogue of Satan

People who gather to obey or honor Satan are spoken of as if they were in a synagogue, a place of worship and teaching for the Jews. See how you translated this in [Revelation 2:9](../02/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bow down

This is a sign of submission, not worship. AT: "bow down in submission" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### before your feet

Here the word "feet" represent the person before whom these people bow down. AT: "before you" or "to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### they will come to know

"they will learn" or "they will admit"

#### will also keep you from the hour of testing

"will also prevent the hour of testing from happening to you" or "will protect you so you do not enter the hour of testing"

#### hour of testing

"time of testing." This probably means "the time when people try to make you disobey me."

#### is coming

Existing in the future is spoken of as coming. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I am coming soon

It is understood that he is coming in order to judge. AT: "I am coming to judge soon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Hold to what you have

Continuing to believe firmly in Christ is spoken of as if it were holding something tightly. AT: "Continue to believe firmly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### crown

A crown was a wreath, originally of olive branches or laurel leaves, that was put on the head of a victorious athlete. Here "crown" stands for a reward. See how you translated "crown" in [Revelation 2:10](../02/10.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/synagogue.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/test.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]

### Revelation 03:12

#### The one who conquers, I will make like a pillar in the temple of my God

Here "The one who conquers" refers to anyone who conquers. See how you translated this in [Revelation 2:7](../02/06.md). The "pillar" represents an important and permanent part of God's kingdom. AT: "Anyone who resists evil to be strong like a pillar in the temple of my God" or "Those who do not agree to do evil to be strong like a pillar in the temple of my God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Let the one who has an ear

Being willing to listen is spoken of as having an ear. See how you translated this in [Revelation 2:7](../02/06.md). AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Revelation 03:14

#### General Information:

This is the beginning of the Son of Man's message to the angel of the church in Laodicea.

#### Laodicea

This is the name of a city in the western part of Asia that today is modern Turkey. See how you translated this in [Revelation 1:11](../01/09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### The words of the Amen

Here "the Amen" is a name for Jesus Christ. He guarantees God's promises by saying amen to them.

#### the ruler over God's creation

Possible meanings are 1) "the one who rules over everything that God created" or 2) "the one through whom God created everything."

#### you are neither cold nor hot

"Cold" and hot" represent two extremes of spiritual interest or love for God. To be "cold" is to be completely against God, and to be "hot" is to be zealous to serve him. AT: "you are like water that is neither cold nor hot" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### lukewarm

"slightly warm." This describes someone who has only a small amount of spiritual interest or conviction. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I am about to vomit you out of my mouth

Rejecting them is spoken of as vomiting them out of the mouth. AT: "I will reject you as I would spit out lukewarm water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]

### Revelation 03:17

#### you are most miserable, pitiable, poor, blind, and naked

Jesus speaks of their spiritual condition as if he were speaking about their physical condition. AT: "You are like people who are most miserable, pitiable, poor, blind, and naked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Buy from me gold refined by fire so that you may become rich, and brilliant white garments so you may clothe yourself and not show the shame of your nakedness, and salve to anoint your eyes so you will see

Here to "buy" represents receiving things from Jesus that have true spiritual value. The "gold refined by fire" represents spiritual wealth. The "brilliant white garments" represents rightousness. And the "salve to anoint your eyes" represents the ability to understand spiritual things. AT: "Come to me and receive spiritual wealth, which is more valuable than gold that is refined by fire. Receive from me righteousness, which is like brilliant white garments, so that you will not be ashamed. And receive from me wisdom, which is like salve for the eyes, so that you may understand spiritual things" (See: [https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md))

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/anoint.md)]]

### Revelation 03:19

#### be earnest and repent

"be serious and repent"

#### I am standing at the door and am knocking

Jesus speaks about wanting people to relate to him as if he wanted them to invite him into their home. AT: "I am like one standing at the door and knocking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### am knocking

When people want someone to welcome them into their home, they knock on the door. AT: "I want you to let me come inside" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### hears my voice

The phrase "my voice" refers to Christ speaking. AT: "hears me speak" or "hears me call" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### I will come into his home

Some languages might prefer the verb "go" here. AT: "I will go in to his home" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md)]])

#### and will eat with him

This represents being together as friends. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]

### Revelation 03:21

#### Connecting Statement:

This is the end of the Son of Man's messages to the angels of the seven churches.

#### The one who conquers

This refers anyone who conquers. See how you translated this in [Revelation 2:7](../02/06.md). AT: "Anyone who resists evil" or "Anyone who does not agree to do evil" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-genericnoun.md)]])

#### to sit down with me on my throne

To sit on a throne means to rule. AT: "to rule with me" or "to sit down on my throne and rule with me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### my Father

This is an important title for God that describes the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### Let the one who has an ear listen

Being willing to listen is spoken of as having an ear. See how you translated this in [Revelation 2:7](../02/06.md). AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]

### Revelation 03:intro

#### Revelation 03 General Notes ####

####### Structure and formatting #######

Chapters 2 and 3 form a single unit. This section is usually referred to as the "seven letters to the seven churches." The translator may wish to set these letters apart from each other to clearly distinguish them from each other.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 3:7.

####### Special concepts in this chapter #######

######## Seven spirits of God ########
The exact meaning of this phrase is unclear. It is possibly a reference to the Holy Spirit with the number seven symbolizing "completeness." It may also be a reference to the seven spirits surrounding the throne of God. It should be unnecessary to specifically define it in translation.

######## Seven stars ########
These are probably a reference to the leaders of the churches. (See: [Revelation 1:20](../01/19.md))

####### Important figures of speech in this chapter #######

######## Metaphor ########
Some scholars take chapter 2 and 3 as a metaphor. They understand these churches to refer to types of churches or historical periods of the church. It is best to translate this as instructions to ancient churches in each of these cities. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

The phrase "Look, I stand at the door and knock" is another extended metaphor describing Jesus' readiness and willingness to accept anyone who repents and believes in him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]])

######## "If you have an ear, listen to what the Spirit says to the churches." ########
This is a phrase which acts as a call to repentance for those in the church.

####### Other possible translation difficulties in this chapter #######

######## "The angels of the seven churches" ########

The Greek word translated as "angels" can also be translated as "messengers." This is possibly a reference to the messengers or leaders of these seven churches.

##### Links: #####

* __[Revelation 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | [>>](../04/intro.md)__


## Revelation 04

### Revelation 04:01

#### General Information:

John begins to describe his vision of the throne of God.

#### After these things

"After I had just seen these things" ([Revelation 2:1-3:22](../02/01.md))

#### an open door in heaven

This expression stands for the ability that God gave John to see into heaven, at least by means of a vision. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### speaking to me like a trumpet

How the voice was like a trumpet can be stated clearly. AT: "speaking to me loudly like the sound of a trumpet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### trumpet

This refers to an instrument for producing music or for calling people to gather together for an announcement or meeting. See how you translated this in [Revelation 1:10](../01/09.md).

#### I was in the Spirit

John speaks of being influenced by God's Spirit as if he were in the Spirit. See how you translated this in [Revelation 1:10](../01/09.md). AT: "I was influenced by the Spirit" or "The Spirit influenced me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### jasper and carnelian

valuable stones. Jasper may have been clear like glass or crystal, and carnelian may have been red. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### emerald

a green, valuable stone (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]

### Revelation 04:04

#### twenty-four elders

"24 elders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### golden crowns

These were likenesses of wreaths of olive branches or laurel leaves, hammered out in gold. Such crowns, made of leaves, were given to victorious athletes to wear on their heads.

#### flashes of lightning

Use your language's way of describing what lightning looks like each time it appears.

#### rumblings, and crashes of thunder

These are the loud noises that thunder makes. Use your language's way of describing the sound of thunder.

#### seven spirits of God

The number seven is a symbol of completeness and perfection. The "seven spirits" refers either to the Spirit of God or to seven spirits who serve God. See how you translated this in [Revelation 1:4](../01/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 04:06

#### a sea of glass

How it was like glass or a sea can be stated clearly. Possible meanings are 1) a sea is spoken of as if it were glass. AT: "a sea that was as smooth as glass" or 2) glass if spoken of as if it were a sea. AT: "glass that was spread out like a sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### like crystal

How it was like crystal can be stated clearly. AT: "clear as crystal" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### In the middle of the throne and around the throne

"Immediately around the throne" or "Close to the throne and around it"

#### four living creatures

"four living beings" or "four living things"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]

### Revelation 04:07

#### The first living creature was like a lion, the second living creature was like a calf, the third living creature had a face like a man, and the fourth living creature was like a flying eagle

How the head of each living creature appeared to John is expressed as a comparison with something more familiar. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### living creature

"living being" or "living thing." See how you translated this in [Revelation 4:6](./06.md)

#### full of eyes on top and underneath

The top and bottom of each wing was covered with eyes.

#### who is to come

Existing in the future is spoken of as coming. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/like.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]

### Revelation 04:09

#### the one who was seated on the throne, the one who lives forever and ever

This is one person. The one who was seated on the throne lives forever and ever.

#### forever and ever

These two words mean about the same thing and are repeated for emphasis. AT: "for all eternity" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### twenty-four elders

"24 elders." See how you translated this in [Revelation 4:4](./04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### prostrated themselves

They lay down facing the ground.

#### they threw down their crowns before the throne

These were likenesses of wreaths of olive branches or laurel leaves, hammered out in gold. Examples actually made of leaves were given to victorious athletes to wear on their heads. The elders were showing that they were submitting to God's authority to rule. AT: "they threw down their crowns before the throne to show that they were submitting to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### our Lord and our God

"our Lord and God." This is one person, the one who was sitting on the throne.

#### to receive glory and honor and power

These are things that God always has. Being praised for having them is spoken of as receiving them. AT: "to be praised for your glory, honor, and power" or "for everyone to praise you because you are glorious, honorable, and powerful" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]

### Revelation 04:intro

#### Revelation 04 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 4:8, 11.

This chapter begins the remainder of the book of Revelation and it is markedly different than the first three chapters. It now describes an unfolding image John sees in his vision. 

####### Special concepts in this chapter #######

######## Glory ########
The whole of this chapter is an image describing a scene in heaven where everything constantly gives glory to God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]])

####### Important figures of speech in this chapter #######

######## Simile ########
The description of the person sitting on the throne contains many similes. Many cultures do not have these specific gem stones and it is possible that these have symbolic significance. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]]) 

####### Other possible translation difficulties in this chapter #######

######## Difficult images ########
There are many images that may appear difficult or impossible. For example, bolts of lighting coming from the throne, lamps that are the seven spirits of God or a sea in front of the throne. It is best to allow these difficulties to remain in the translation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

##### Links: #####

* __[Revelation 04:01 Notes](./01.md)__

__[<<](../03/intro.md) | [>>](../05/intro.md)__


## Revelation 05

### Revelation 05:01

#### Connecting Statement:

John continues to describe what he saw in his vision of the throne of God.

#### Then I saw

"After I saw those things, I saw"

#### the one who was seated on the throne

This is the same "one" as in [Revelation 4:2-3](../04/01.md).

#### a scroll written on the front and on the back

"a scroll with writing on the front and the back"

#### sealed with seven seals

"and it had seven seals keeping it closed"

#### Who is worthy to open the scroll and break its seals?

The person would need to break the seals in order to open the scroll. AT: "Who is worthy to break the seals and open the scroll?" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-events.md)]])

#### Who is worthy to open the scroll and break its seals?

This can be translated as a command: "The one who is worthy to do this should come to break the seals and open the scroll!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righthand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]

### Revelation 05:03

#### in heaven or on the earth or under the earth

This means everywhere: the place where God and the angels live, the place where people and animals live, and the place where those who have died are. AT: "anywhere in heaven or on the earth or under the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### Look

"Listen" or "Pay attention to what I am about to tell you"

#### The Lion of the tribe of Judah

This is a title for the man from the tribe of Judah that God had promised would be the great king. AT: "The one who is called the Lion of the tribe of Judah" or "The king who is called the Lion of the tribe of Judah"

#### The Lion

The king is spoken of as if he were a lion because a lion is very strong. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the Root of David

This is a title for the descendant of David that God had promised would be the great king. AT: "the one who is called the Root of David"

#### the Root of David

The descendant is spoken of as if David's family were a tree and he were a root of that tree. AT: "the Descendant of David" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worthy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]

### Revelation 05:06

#### General Information:

The Lamb appears in the throne room. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-participants.md)]])

#### a Lamb

A "lamb" is a young sheep. Here is it used symbolically to refer to Christ. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### seven spirits of God

The number seven is a symbol of completeness and perfection. The "seven spirits" refers either to the Spirit of God or to seven spirits who serve God. See how you translated this in [Revelation 1:4](../01/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### sent out into all the earth

This can be translated with an active verb. AT: "which God sent out over all the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### He went

He approached the throne. Some languages would use the verb "come." AT: "He came" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-go.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 05:08

#### the Lamb

This is a young male sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](./06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### twenty-four elders

"24 elders." See how you translated this in [Revelation 4:4](../04/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### prostrated themselves

"lay down on the ground." Their faces were toward the ground.

#### Each of them

Possible meanings are 1) "each of the elders and living creatures" or 2) "each of the elders."

#### a golden bowl full of incense, which are the prayers of the believers

The incense here is a symbol for the believers' prayers to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Revelation 05:09

#### For you were slaughtered

This can be stated in active form. AT: "For they slaughtered you" or "For people killed you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### slaughtered

If your language has a word for killing an animal for a sacrifice, consider using it here.

#### with your blood

Since blood represents a person's life, losing the blood represents dying. This probably means "by your death" or "by dying." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you purchased people for God

"you bought people so that they could belong to God" or "you paid the price so that people could belong to God"

#### from every tribe, language, people, and nation

This means that people from every ethnic group are included.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]

### Revelation 05:11

#### ten thousands of ten thousands and thousands of thousands

Use an expression in your language that shows that it is a huge number. AT: "millions" or "too many thousands to count" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Worthy is the Lamb who has been slaughtered

"The Lamb who has been slaughtered is worthy"

#### to receive power, wealth, wisdom, strength, honor, glory, and praise

These are all things that the Lamb has. Being praised for having them is spoken of as receiving them. This can be restated to remove the abstract nouns. See how you translated a similar sentence in [Revelation 4:11](../04/09.md). AT: "for everyone to honor, glorify, and praise him because he is powerful, wealthy, wise, and strong" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]

### Revelation 05:13

#### in heaven and on the earth and under the earth

This means everywhere: the place where God and the angels live, the place where people and animals live, and the place where those who have died are. See how you translated this in [Revelation 5:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### To the one who sits on the throne and to the Lamb be

"May he who sits on the throne and the Lamb have"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Revelation 05:intro

#### Revelation 05 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 4:8, 11.

####### Special concepts in this chapter #######

######## Sealed scroll ########
A sealed scroll contains a written message hidden and waiting to be read. The scroll can only be read by the person with the authority to open it.

######## Twenty-four elders ########
This is probably a reference to church leaders, but the identity of the twenty-four elders is uncertain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## Christian prayers ########
The prayers of Christians are connected with incense. Christian prayers have a good smell to God. He is pleased when Christians pray.

######## Seven spirits of God ########

The exact meaning of this phrase is unclear. It is possibly a symbolic reference to the Holy Spirit with the number seven symbolizing "completeness." It may also not be symbolic, and reference  seven spirits surrounding the throne of God.

####### Important figures of speech in this chapter #######

######## Metaphor ########
The "Lion of the tribe of Judah" and the "Root of David" are references to Jesus. They are metaphors and they function as titles for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Revelation 05:01 Notes](./01.md)__

__[<<](../04/intro.md) | [>>](../06/intro.md)__


## Revelation 06

### Revelation 06:01

#### Connecting Statement:

John continues to describe the events that happened before the throne of God. The Lamb begins to open the seals on the scroll.

#### Come!

This is a command to one person, apparently the rider of the white horse who is spoken of in verse 2.

#### he was given a crown

This kind of crown was a likeness of wreaths of olive branches or laurel leaves, probably hammered out in gold. Examples actually made of leaves were given to victorious athletes to wear on their heads. This can be translated with an active verb. AT: "he received a crown" or "God gave him a crown (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a crown

This was a wreath of olive branches or of laurel leaves like the wreaths that winning athletes received in contests at the time of John.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bowweapon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]

### Revelation 06:03

#### the second seal

"the next seal" or "seal number two" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the second living creature

"the next living creature" or "living creature number two" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### came out—fiery red

This can the stated as a second sentence. AT: "came out. It was red like fire" or "came out. It was bright red"

#### To its rider was given permission

This can be stated with an active verb. AT: "God gave permission to its rider" or "Its rider received person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### This rider was given a huge sword

This can be stated with an active verb. AT: "This rider received a huge sword" or "God gave this rider a huge sword" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### huge

"very large" or "great"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Revelation 06:05

#### the third seal

"the next seal" or "seal number three" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the third living creature

"the next living creature" or "living creature number three" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### a pair of scales

a tool used for weighing things

#### A choenix of wheat for one denarius

Some languages might want a verb such as "cost" or "buy" in the sentence. There was very little wheat for all the people, so its price was very high. AT: "A choenix of wheat now costs one denarius" or "Buy a choenix of wheat with one denarius"

#### A choenix of wheat ... three choenices of barley

a "choenix" was a specific measure that was about one liter. The plural of "choenix" is "choenices." AT: "one liter of wheat ... three liters of barley" or "one bowl of wheat ... three bowls of barley" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bvolume.md)]])

#### one denarius

This coin was worth a day's wages. AT: "one silver coin" or "the pay for one day of work" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bmoney.md)]])

#### But do not harm the oil and the wine

If the oil and wine were harmed, there would be less of them for people to buy, and their prices would go up.

#### the oil and the wine

These expressions probably stand for the olive oil harvest and the grape harvest. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/barley.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Revelation 06:07

#### the fourth seal

"the next seal" or "seal number four" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### the fourth living creature

"the next living creature" or "living creature number four" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### pale

"grey." This is the color of a dead body, so its color is a symbol of death.

#### one-fourth of the earth

Here "the earth" represents the people of the earth. AT: "one-fourth of the people on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### the sword

A sword is a weapon, and here it represents war. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### with the wild animals of the earth

This means that Death and Hades would cause the wild animals to attack and kill people.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md)]]

### Revelation 06:09

#### the fifth seal

"the next seal" or "seal number five" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### under the altar

This may have been "at the base of the altar."

#### those who had been killed

This can be translated with an active verb. AT "those whom others had killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### because of the word of God and the testimony which they held

Here "Word of God" is a metonym for the message from God and "held" is a metaphor. Possible meanings are 1) holding the testimony refers to believing God's word and testimony. AT: "because of the teachings of scripture and what they taught about Jesus Christ" or "because they believed the word of God, which is his testimony" or 2) holding the testimony refers to testifying about the word of God. AT: "because they testified about the word of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### avenge our blood

The word blood here represents their deaths. AT: "punish those who killed us" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### until the full number ... were to be killed

This implies that God had decided that a certain number of people should be killed by their enemies.

#### their fellow servants and their brothers and sisters

This is one group of people described in two ways: as servants and as brothers and sisters. AT: "their brothers and sisters who serve God with them" or "their fellow believers who serve God with them"

#### brothers and sisters

Christians are often spoken of as being one another's brothers and sisters. AT: "fellow Christians" or "fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Revelation 06:12

#### the sixth seal

"the next seal" or "seal number six" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### as black as sackcloth

Sometimes sackcloth was made of black hair. People would wear sackcloth when they were mourning. The image of sackcloth is meant to lead people to think of death and mourning. AT: "as black as mourning clothes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### like blood

The image of blood is meant to lead people to think of death. How it was like blood can be stated clearly. AT: "red like blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### just as a fig tree drops its unripe fruit when shaken by a stormy wind

This can be stated in active form. AT: "just as a stormy wind shakes a fig tree and causes it to drop its unripe fruit" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The sky vanished like a scroll that was being rolled up

The sky was normally thought of as being strong like a sheet of metal, but now it was weak like a sheet of paper and easily torn and rolled up. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]

### Revelation 06:15

#### the generals

This word refers to the warriors who command in the battle.

#### caves

large holes in the sides of hills

#### the face of the one

This refers to God. They did not want God to see them and punish them. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### face

Here "face" is used for the idea of "presence." AT: "God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the great day of their wrath has come

The day of their wrath refers to the time when they would punish wicked people. AT: "this is the terrible time when they will punish people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### has come

Existing now is spoken of as having come. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### their wrath

"Their" refers to the one on the throne and the Lamb.

#### Who is able to stand?

Surviving, or staying alive, is spoken of as standing. This question is used to express their great sadness and fear that no one will be able to survive when God punishes them. AT: "No one can survive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Revelation 06:intro

#### Revelation 06 General Notes ####

####### Structure and formatting #######

The image of the wrath of God in this chapter is intended to produce fear in those who hear these words. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]])

####### Special concepts in this chapter #######

######## Seven Seals ########
There is disagreement over how these seals are attached to the scroll. It would be logical if they were all side-by-side but the scroll would only have revealed its contents after the last seal is broken. This is not how this chapter describes the scroll because each seal reveals a judgment. It is also commonly believed that the absent seventh seal uncovers the seven trumpet judgments. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## Price Increases ########
The prices of some things people will suddenly increase. People will not be able to afford the things they need to live. This is usually called "inflation."

####### Important figures of speech in this chapter #######

######## The Lamb ########
This is a reference to Jesus. In this chapter, it also functions as a title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## Similes ########
The author uses many different similes. This is because he is attempting to describe the image he sees in the vision. Therefore, he compares the images in this vision to everyday things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

##### Links: #####

* __[Revelation 06:01 Notes](./01.md)__

__[<<](../05/intro.md) | [>>](../07/intro.md)__


## Revelation 07

### Revelation 07:01

#### General Information:

John begins to describe a vision of 144,000 servants of God who become marked with seals. Their marking takes place after the Lamb opens the sixth seal and before he opens the seventh seal.

#### the four corners of the earth

The earth is spoken of as if it were flat and square like a sheet of paper. The phrase "the four corners" refers to the north, south, east, and west.

#### the seal of the living God

The word "seal" here refers to a tool that is used to press a mark onto a wax seal. In this case the tool would be used to put a mark on God's people. AT: "the marker" or "stamp" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### put a seal on the foreheads

The word "seal" here refers to a mark. This mark shows that the people belong to God and that he will protect them. AT: "put a mark on the foreheads" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### foreheads

The forehead is the top of the face, above the eyes.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Revelation 07:04

#### those who were sealed

This can be stated with an active verb. AT: "those whom God's angel marked" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### 144,000

"one hundred forty-four thousand people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### twelve thousand from the tribe

"12,000 people from the tribe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/reuben.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/gad.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/asher.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/naphtali.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/manasseh.md)]]

### Revelation 07:07

#### Connecting Statement:

This continues the list of the people of Israel who were sealed.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/simeon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/levite.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/issachar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/zebulun.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/josephot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/benjamin.md)]]

### Revelation 07:09

#### General Information:

John begins to describe a second vision about a multitude praising God. This is a different group of people than the 144,000 people who become marked with seals. This vision also takes place after the Lamb opens the sixth seal and before he opens the seventh seal.

#### a huge multitude

"a huge crowd" or "a great number of people"

#### white robes

Here the color "white" represents purity.

#### Salvation belongs to

"Salvation comes from"

#### Salvation belongs ... to the Lamb

They were praising God and the Lamb. The noun "salvation" can be expressed with the verb "save." AT "Our God, who sits on the throne, and the Lamb have saved us!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 07:11

#### the four living creatures

These are the four creatures mentioned in [Revelation 4:6-8](../04/06.md).

#### they fell on their faces

They lay down facing the ground. See how you translated a similar expression in [Revelation 4:10](../04/09.md). AT: "they bowed down"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Praise, glory ... be to our God

"Our God is worthy of all praise, glory, wisdom, thanks, honor, power and strength"

#### Praise, glory ... thanksgiving, honor ... be to our God

The verb "give" can be used to show how praise, glory, and honor, are to be "to" God. AT: "We must give praise, glory, thanks, and honor to our God"

#### forever and ever

These two words mean basically the same thing and emphasize that the praise will never end.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Revelation 07:13

#### clothed with white robes

These white robes showed that they were righteous.

#### have come out of the great tribulation

"have survived the great tribulation" or "have lived through the great tribulation"

#### the great tribulation

"the time of terrible suffering" or "the time when people will suffer terribly"

#### They have washed their robes and made them white in the blood of the Lamb

Being made righteous by the blood of the Lamb is spoken of as washing their robes in his blood. AT: "They have been made righteous by washing their robes white in his blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the blood of the Lamb

The word "blood" is used to refer to the death of Lamb. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribulation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]

### Revelation 07:15

#### Connecting Statement:

The elder continues to speak to John.

#### they ... them ... their

All of these refer to those people who have come through the Great Tribulation.

#### day and night

These two parts of the day are used together to mean "all the time" or "without stopping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### will spread his tent over them

"will put his tent up over them." Protecting them is spoken of as if he were giving them shelter to live under. AT: "will shelter them" or "will protect them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The sun will not beat down

The sun's heat is compared to punishment that causes people to suffer. AT: "The sun will not burn them" or "The sun will not make them weak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the Lamb at the center of the throne

"the Lamb, who is standing in the middle of the area around the throne"

#### For the Lamb ... will be their shepherd

The elder speaks of the Lamb's care for his people as if it were a shepherd's care for his sheep. AT: "For the Lamb ... will be like a shepherd to them" or "For the Lamb ... will care for them as a shepherd cares for his sheep" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he will guide them to springs of living water

The elder speaks of what gives life as if it were springs of fresh water. AT: "he will guide them like a shepherd guiding his sheep to fresh water" or "he will guide them to life like a shepherd guiding his sheep to living water" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### God will wipe away every tear from their eyes

Tears here represent sadness. AT: "God will wipe away their sadness, like wiping away tears" or "God will cause them to not be sad anymore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shepherd.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Revelation 07:intro

#### Revelation 07 General Notes ####

####### Structure and formatting #######

Many scholars believe the first half of this chapter is about a great revival among the Israelites, in which 144,000 people will come to believe in Jesus. The second half of this chapter tells about a great revival among the Gentiles, in which countless Gentiles will come to faith in Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 7:5-8, 15-17.

####### Special concepts in this chapter #######

######## Worship ########
The people in this chapter respond to these events with repentance and worship. This is the proper response to the information contained in this book. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]])

######## The Great Tribulation ########
This is a period when the people of the earth will be greatly punished by God. There is some disagreement about this period but many scholars believe it is a reference to the last half of the seven years of tribulation prophesied in Revelation 4-19 and in the rest of Scripture. 

####### Important figures of speech in this chapter #######

######## The Lamb ########
This is a reference to Jesus. In this chapter, it also functions as a title for Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

##### Links: #####

* __[Revelation 07:01 Notes](./01.md)__

__[<<](../06/intro.md) | [>>](../08/intro.md)__


## Revelation 08

### Revelation 08:01

#### Connecting Statement:

The Lamb opens the seventh seal.

#### the seventh seal

This is the last of the seven seals on the scroll. AT: "the next seal" or "the final seal" or "seal number seven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### seven trumpets were given to them

They were each given one trumpet. This can be stated in active form. Possible meanings are 1) "God gave them seven trumpets" or 2) "the Lamb gave them seven trumpets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Revelation 08:03

#### he would offer it

"he would offer the incense to God by burning it"

#### the angel's hand

This refers to the bowl in the angel's hand. AT: "the bowl in the angel's hand" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### filled it with fire

The word "fire" here probably refers to burning coals. AT: "filled it with burning coals" or "filled it with coals of fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/pray.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]

### Revelation 08:06

#### General Information:

The seven angels sound the seven trumpets, one at a time.

#### It was thrown down onto the earth

This can be stated in active form. AT: "The angel threw the hail and fire mixed with blood down onto the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a third of it was burned up, a third of the trees were burned up, and all the green grass was burned up

This can be stated in active form. AT: "it burned up a third of the earth, a third of the trees, and all the green grass" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]

### Revelation 08:08

#### The second angel

"The next angel" or "Angel number two" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### something like a great mountain burning with fire was thrown

This can be stated in active form. AT: "the angel threw something like a great mountain burning with fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### A third of the sea became blood

The fraction "A third" can be explained in translation. AT: "It was like the sea was divided into three parts, and one of those parts became blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### became blood

Possible meanings are it 1) "became red like blood" or it 2) really became blood. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### the living creatures in the sea

"the things living in the sea" or "the fish and other animals that lived in the sea"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Revelation 08:10

#### a huge star fell from the sky, blazing like a torch

"a huge star that was blazing like a torch fell from the sky." The fire of the huge star looked similar to the fire of a torch. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### torch

a stick with one end lit on fire to provide light

#### The name of the star is Wormwood

Wormwood is a shrub that tastes bitter. People made medicine out of it, but they also believed that it was poisonous. AT: "The name of the star is Bitterness" or "The name of the star is Bitter Medicine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### became wormwood

The bitter taste of the water is spoken of as if it were wormwood. AT: "became bitter like wormwood" or "became bitter" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### died from the waters that became bitter

"died when they drank the bitter water"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]

### Revelation 08:12

#### a third of the sun was struck

Causing something bad to happen to the sun is spoken of as striking, or hitting, it. This can be stated with an active verb. AT: "a third of the sun changed" or "God changed a third of the sun" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a third of them turned dark

Possible meanings are 1) "one third of the time they were dark" or 2) "one third of the sun, one third of the moon, and one third of the stars became dark"

#### a third of the day and a third of the night had no light

"there was no light during one third of the day and one third of the night" or "they did not shine during one third of the day and one third of the night"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]

### Revelation 08:13

#### because of the remaining trumpet ... angels

This can be stated in active form. AT: "because the three angels who have not yet sounded their trumpets are about to sound them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Revelation 08:intro

#### Revelation 08 General Notes ####

####### Special concepts in this chapter #######

######## Seven seals ########
There is disagreement over how these seals are attached to the scroll. It would be logical if they were all side by side, but the scroll would only have revealed its contents after the last seal is broken. This is not how this chapter describes the scroll because each seal reveals a judgment. It is also commonly held that the absent seventh seal uncovers the seven trumpet judgments. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

####### Important figures of speech in this chapter #######

######## Passive voice ########
The passive voice is frequently used in this chapter to hide the identity of the subject performing the action. This will be difficult to convey if the translator's language does not have a passive voice. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

######## Similes ########
The author uses many different similes. This is because he is attempting to describe the image he sees in the vision. Therefore, he compares the images in this vision to everyday things. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]]) 

##### Links: #####

* __[Revelation 08:01 Notes](./01.md)__

__[<<](../07/intro.md) | [>>](../09/intro.md)__


## Revelation 09

### Revelation 09:01

#### Connecting Statement:

The fifth of the seven angels begins to sound his trumpet.

#### I saw a star from heaven that had fallen

John saw the star after it had fallen. He did not watch if fall.

#### the key to the shaft of the bottomless pit

"the key that unlocks the shaft of the bottomless pit"

#### the shaft of the bottomless pit

Possible meanings are 1) "shaft" is another way of referring to the pit and describes it as long and narrow, or 2) "shaft" refers to the opening of the pit.

#### the bottomless pit

This is an extremely deep narrow hole. Possible meanings are 1) the pit has no bottom; it continues to go down further forever or 2) the pit is so deep that it is as if it had no bottom.

#### like smoke from a huge furnace

A huge furnace gives off a great amount of thick, dark smoke. AT: "like the great amount of smoke that comes from a huge furnace" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### The sun and the air turned dark

"Turned dark" here is an idiom for "changed to dark." AT: "The sun and the air changed from light to dark" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/furnace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/furnace.md)]]

### Revelation 09:03

#### locusts

insects that fly together in large groups. People fear them because they can eat up all the leaves in gardens and on trees. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### power like that of scorpions

Scorpions have the ability to sting and poison other animals and people. AT: "the ability to sting people as scorpions do" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### scorpions

small insects with poisonous stingers on their tails. Their sting is extremely painful and the pain lasts a long time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### They were told not to damage the grass on the earth or any green plant or tree

Ordinary locusts were a terrible threat to people because when they swarm, they can eat up all the grass and all the leaves on plants and trees. These locusts were told not to do this.

#### but only the people

The phrase "to damage" or "to harm" is understood. AT: "but only to harm the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### the seal of God

The word "seal" here refers to a tool that is used to press a mark onto a wax seal. In this case the tool would be used to put a mark on God's people. See how you translated "seal" in [Revelation 7:3](../07/01.md). AT: "the marker of God" or "stamp of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### foreheads

The forehead is the top of the face, above the eyes.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 09:05

#### They were not given permission

"They" refers to the locusts. ([Revelation 9:03](./03.md))

#### those people

the people whom the locusts were stinging

#### but only to torture them

Here the words "given permission" are understood. AT: "but only given permission to torture them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### to torture them for five months

The locusts would be allowed to do this for five months.

#### to torture them

"to make them suffer terrible pain"

#### the sting of a scorpion

A scorpion is a small insect with a poisonous stinger at the end of its long tail. The sting can cause severe pain or even death.

#### people will seek death, but will not find it

This can be restated to remove the abstract noun "death." AT: "people will try to find a way to die, but will not find it" or "people will try to kill themselves, but will not find a way to die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### will greatly desire to die

"will want very much to die" or "will wish that they could die"

#### death will flee from them

John speaks of death as if it were a person or animal that could run away. AT: "they will not be able to die" or "they will not die" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Revelation 09:07

#### General Information:

These locusts did not look like ordinary locusts. John describes them by telling how parts of them looked like other things.

#### crowns of gold

These were likenesses of wreaths of olive branches or laurel leaves, hammered out in gold. Examples actually made of leaves were given to victorious athletes to wear on their heads.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]

### Revelation 09:10

#### They had tails

The word "They" refers to the locusts.

#### with stingers like scorpions

A scorpion is a small insect with a poisonous stinger at the end of its long tail. The sting can cause severe pain or even death. See how you translated a similar phrase in [Revelation 9:6](./05.md). AT: "with stingers like scorpion stingers" or "with stingers that could cause terrible pain as scorpion stingers can" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### in their tails they had power to harm people for five months

Possible meanings are 1) they had power for five months to harm people or 2) they could sting people and the people would be in pain for five months.

#### the bottomless pit

This is an extremely deep narrow hole. Possible meanings are 1) the pit has no bottom; it continues to go down further forever or 2) the pit is so deep that it is as if it had no bottom. See how you translated this in [Revelation 9:1](./01.md).

#### Abaddon ... Apollyon

Both names mean "Destroyer." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-transliterate.md)]])

#### there are still two disasters to come

Existing in the future is spoken of as coming. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]

### Revelation 09:13

#### Connecting Statement:

The sixth of the seven angels begins to sound his trumpet.

#### I heard a voice coming

The voice refers to the one who was speaking. John does not say who the speaker was, but it may have been God. AT: "I heard someone speaking" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### horns of the golden altar

These are horn-shaped extensions at each of the four corners of the top of the altar.

#### The voice said

The voice refers to the speaker. AT: "The speaker said" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### The four angels who had been prepared for ... that year, were released

This can be stated with an active form. AT: "The angel released the four angels who had been prepared for ... that year" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The four angels who had been prepared

This can be stated with an active form. AT: "The four angels whom God had prepared" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for that hour, that day, that month, and that year

These words are used to show that there is a specific, chosen time and not just any time. AT: "for that exact time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bond.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md)]]

### Revelation 09:16

#### General Information:

Suddenly, 200,000,000 soldiers on horseback appear in John's vision. John is no longer speaking about the four angels mentioned in the previous verse.

#### 200,000,000

Some ways to express this are: "two hundred million" or "two hundred thousand thousand" or "twenty thousand times ten thousand." If your language does not have a specific number for this, you could also see how you translated a similar large number in [Revelation 5:11](../05/11.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### fiery red

"red like fire" or "bright red." See how you translated this in [Revelation 6:3](../06/03.md).

#### sulfurous yellow

"yellow like sulfur" or "bright yellow like sulfur"

#### out of their mouths came fire, smoke, and sulfur

"fire, smoke, and sulfur came out of their mouths"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breastplate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md)]]

### Revelation 09:18

#### Connecting Statement:

John continues to describe the horses and the plagues brought upon humanity.

#### A third of the people

"One third of the people." See how you translated "A third" in [Revelation 8:7](../08/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### For the power of the horses was in their mouths and in their tails

The abstract noun "power" can be translated with an adjective. AT: "For it was the horses' mouths and tails that were so powerful" or "for it was the horses' mouths and tails that were able to hurt people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]

### Revelation 09:20

#### those who were not killed by these plagues

This can be stated in active form. AT: "those whom the plagues had not killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### things that cannot see, hear, or walk

This phrase reminds us that idols are not alive and do not deserve to be worshiped. But the people did not stop worshiping them. AT: "even though idols cannot see, hear, or walk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]

### Revelation 09:intro

#### Revelation 09 General Notes ####

####### Structure and formatting #######

This chapter continues the seven trumpet judgments. This chapter and the previous one form a single unit.

######## Woe ########
There are several specific "woes" mentioned in the book of Revelation. This chapter contains the first of these woes. It is possible that these have some structural significance or importance to the chronology of the events of Revelation.

####### Special concepts in this chapter #######

######## Animal imagery ########
Animal imagery is common in this book, as well as very common in this chapter. The people of the ancient Near East probably viewed these animals as having some "trait" that typified the animal. For example, a lion is often seen as powerful.  The translator should not try to determine the meaning of each of these images. 

######## Bottomless pit ########
This is a common image in the book of Revelation that portrays hell. It emphasizes that hell is inescapable. It is described as being down, in opposition to heaven which is considered up. This emphasizes that neither is on earth. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]) 

######## Abaddon and Apollyon ########

"Abaddon" here is a Hebrew word, and "Apollyon" is a Greek word. Both words mean "Destroyer." John transliterated the sounds of the Hebrew word by writing them with Greek letters. The translators of the ULB and the UDB transliterated the sounds of both words by writing them with English letters. Translators are encouraged to transliterate these words using the letters of the target language. Since the original Greek readers would have understood the meaning of "Apollyon," translators may also supply the meaning in the text or in a footnote.

######## Repentance ########
This chapter mentions the theme of repentance. Despite these great miracles, the people are said to avoid repentance and remain in their sin. One should not lose sight of this theme when reading the book of Revelation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]) 

####### Important figures of speech in this chapter #######

######## Symbol ########
Satan is often described as a fallen angel. Since stars are symbols for angels in the book of Revelation, the phrase "a star from heaven that had fallen" probably symbolizes Satan. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]], [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## Simile ########
There are many similes in this chapter. Their purpose is to describe the complex images that John sees in his vision. Therefore, they serve more of a practical rather than poetic function. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

####### Other possible translation difficulties in this chapter #######

######## "The people who did not have the seal of God" ########
It is best to leave the meaning of this phrase unclear in translation, if possible. Many scholars believe the seal to be a mark made to distinguish believers from unbelievers in this time of tribulation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believe.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]]) 

##### Links: #####

* __[Revelation 09:01 Notes](./01.md)__

__[<<](../08/intro.md) | [>>](../10/intro.md)__


## Revelation 10

### Revelation 10:01

#### General Information:

John begins to describe a vision of a mighty angel holding a scroll. In John's vision he is viewing what is happening from earth. This takes place between the blowing of the sixth and seventh trumpets.

#### He was robed in a cloud

John speaks of the angel as if he were wearing a cloud as his clothing. This expression may be understood as metaphor. However, because very unusual things were often seen in visions, it might be understood as a literally true statement in its context. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### His face was like the sun

John compares the brightness of his face with the brightness of the sun. AT: "His face was bright like the sun" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### his feet were like pillars of fire

The word "feet" refers to the legs. AT: "his legs were like pillars of fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### He put his right foot on the sea and his left foot on the land

"He stood with his right foot on the sea and his left foot on the land"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]

### Revelation 10:03

#### Then he shouted

"Then the angel shouted"

#### the seven thunders spoke out

The thunder is described as if it were a person who could speak. AT: "the seven thunders made a loud noise" or "the thunder sounded very loudly seven times"

#### seven thunders

Thunder occurring seven times is spoken of as if it were seven different "thunders."

#### but I heard a voice from heaven

The word "voice" refers to words spoken by someone other than the angel. AT: "but I heard someone speaking from heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Revelation 10:05

#### raised his right hand to heaven

He did this to show that he was swearing by God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### He swore by the one who lives forever and ever

"He asked that what he was going to say would be confirmed by the one who lives forever and ever"

#### the one who lives forever and ever

Here "the one" refers to God.

#### There will be no more delay

"There will be no more waiting" or "God will not delay"

#### the mystery of God will be accomplished

This can be stated in active form. AT: "God will accomplish his mystery" or "God will complete his secret plan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mystery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### Revelation 10:08

#### Connecting Statement:

John hears the voice from heaven, which he had heard in [Revelation 10:4](./03.md), speak to him again.

#### The voice I heard from heaven

The word "voice" refers to the speaker. AT: "The one I heard speak from heaven" or "The one who had spoken to me from heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### I

The word "I" here refers to John.

#### He said to me

"The angel said to me"

#### bitter

"sour" or "acid." This refers to a bad taste from the stomach after eating something that is not good.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]

### Revelation 10:10

#### languages

This refers to the people who speak the languages. AT: "many language communities" or "many groups of people who speak their own languages" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/scroll.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/honey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Revelation 10:intro

#### Revelation 10 General Notes ####

####### Special concepts in this chapter #######

######## Seven thunders ########
It is unclear what is meant by the seven thunders. It is perfectly acceptable for the translator to not understand this phrase and translate it as "seven thunders." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## "The mystery of God" ########
It is uncertain what this references. It is not the "mystery" that Paul describes, namely the church. It probably does share the meaning of being something that is currently hidden or unknown, which will be revealed at this time. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]])

####### Important figures of speech in this chapter #######

######## "Coming down from heaven" ########
Heaven is frequently said to be "up." The reason for this is to emphasize that heaven is not located on the earth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

######## Simile ########
There are many different similes used to describe the mighty angel. The similes are used to try to describe what John sees by relating it to everyday things. The rainbow and cloud, however, should be understood as literal, since they are not part of any simile. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

####### Other possible translation difficulties in this chapter #######

######## Scrolls ########
The scroll mentioned in this chapter is different from the scrolls which have been the subject of much of the book of Revelation to this point. It is called the "little scroll" here. The translator should ensure the reader is aware that there is more than one scroll.

##### Links: #####

* __[Revelation 10:01 Notes](./01.md)__

__[<<](../09/intro.md) | [>>](../11/intro.md)__


## Revelation 11

### Revelation 11:01

#### General Information:

John begins to describe a vision about receiving a measuring rod and two witnesses that God appointed. This vision also takes place between the blowing of the sixth and seventh trumpets.

#### A reed was given to me

This can be stated in active form. AT: "Someone gave me a reed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### given to me ... I was told

The words "me" and "I" refer to John.

#### those who worship in it

"count those who worship in the temple"

#### trample

to treat something as worthless by walking on it

#### forty-two months

"42 months" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/courtyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gentile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Revelation 11:03

#### Connecting Statement:

God continues speaking to John.

#### for 1,260 days

"for one thousand two hundred and sixty days" or "for twelve hundred and sixty days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### days, clothed in sackcloth

Why they will wear sackcloth can be made explicit. AT: "days, wearing rough mourning clothes" or "days: they will wear scratchy clothes to show that they are very sad" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### These witnesses are the two olive trees and the two lampstands that have stood before the Lord of the earth

The two olive trees and the two lampstands symbolize these people, but they are not literally the people. AT: "The two olive trees and the two lampstands that have stood before the Lord of the earth represent these witnesses" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the two olive trees and the two lampstands that

John expects his readers to know about them because many years earlier another prophet had written about them. AT: "the two olive trees and the two lampstands, told about in scripture, that" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### fire comes out of their mouth and devours their enemies

Because this is about future events, it can also be stated in the future tense. AT: "fire will come out of their mouth and devour their enemies"

#### fire ... devours their enemies

Fire burning and killing people is spoken of as if it were an animal that could eat them up. AT: "fire ... will destroy their enemies" or "fire ... will completely burn up their enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/olive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lampstand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/adversary.md)]]

### Revelation 11:06

#### to close up the sky so that no rain will fall

John speaks of the sky as if it had a door that can be opened to let rain fall or closed to stop the rain. AT: "to keep rain from falling from the sky" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### power to turn the waters to blood

"power to turn" here is an idiom for "power to change." AT: "power to change the waters to blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### to strike the earth with every kind of plague

John speaks of the plagues as if they were a stick that someone could hit the earth with. AT: "to cause all kinds of trouble to occur on earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bottomless pit

This is an extremely deep narrow hole. Possible meanings are 1) the pit has no bottom; it continues to go down further forever or 2) the pit is so deep that it is as if it had no bottom. See how you translated this in [Revelation 9:1](../09/01.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/turn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]

### Revelation 11:08

#### Their bodies

This refers to the bodies of the two witnesses.

#### in the street of the great city

The city had more than one street. This was a public place where people could see them. AT: "in one of the streets of the great city" or "in the main street of the great city"

#### three and a half days

"3 full days and one half day" or "3.5 days" or "3 1/2 days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### their Lord

They served the Lord, and like him would die in that city.

#### They will not permit them to be placed in a tomb

This will be a sign of disrespect.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sodom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/crucify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tomb.md)]]

### Revelation 11:10

#### will rejoice over them and celebrate

"will rejoice that the two witnesses have died"

#### even send gifts to one another

This action shows how happy the people were. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-symaction.md)]])

#### because these two prophets tormented those who lived on the earth

This is the reason that the people will be so happy that the witnesses have died.

#### three and a half days

"3 full days and one half day" or "3.5 days" or "3 1/2 days." See how you translated this in [Revelation 11:9](./08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### a breath of life from God will enter them

The ability to breathe is spoken of as if it were something that can go into people. AT: "God will cause the two witnesses to breathe again and live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Great fear will fall on those who see them

Fear is spoken of as if it is a object that can fall on people. AT: "Those who see them will be extremely afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Then they will hear

Possible meanings are 1) the two witnesses will hear or 2) the people will hear what is said to the two witnesses.

#### a loud voice from heaven

The word "voice" refers to the one who speaks. AT: "someone speak loudly to them from heaven and" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### say to them

"say to the two witnesses"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/gift.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Revelation 11:13

#### Seven thousand people

"7,000 people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the survivors

"those who do not die" or "those who are still living"

#### give glory to the God of heaven

"say that the God of heaven is glorious"

#### The second woe is past

"The second terrible event is over." See how you translated "The first woe is past" in [Revelation 9:12](../09/10.md).

#### The third woe is coming quickly

Existing in the future is spoken of as coming. AT: "The third woe will happen soon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/terror.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]

### Revelation 11:15

#### Connecting Statement:

The last of the seven angels begins to sound his trumpet.

#### the seventh angel

This is the last of the seven angels. See how you translated "seventh" in [Revelation 8.1](../08/01.md). AT: "the final angel" or "angel number seven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-ordinal.md)]])

#### loud voices spoke in heaven and said

The phrase "loud voices" represents speakers who spoke loudly. AT: "speakers in heaven spoke loudly and said"

#### The kingdom of the world ... the kingdom of our Lord and of his Christ

Here "kingdom" refers to the authority to rule the world. AT: "The authority to rule the world ... the authority that belongs to our Lord and his Christ" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the world

This refers to everyone in the world. AT: "everyone in the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The kingdom of the world has become the kingdom of our Lord and of his Christ

"Our Lord and his Christ are now the rulers of the world"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Revelation 11:16

#### twenty-four elders

"24 elders." See how you translated this in [Revelation 4:4](../04/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### fell upon their faces

They lay down facing the ground. See how you translated a similar expression in [Revelation 4:10](../04/09.md). AT: "they bowed down"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### you, Lord God Almighty, the one who is and who was

These phrases can be stated as sentences. AT: "you, Lord God, the ruler over all. You are the one who is, and you are the one who was" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]])

#### the one who is

"the one who exists" or "the one who lives"

#### who was

"who has always existed" or "who has always lived"

#### you have taken your great power

What God did with his great power can be stated clearly. AT: "you have defeated with your power everyone who has rebelled against you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]

### Revelation 11:18

#### Connecting Statement:

The twenty-four elders continue praising God.

#### General Information:

The words "you" and "your" refer to God.

#### were enraged

"were extremely angry"

#### your wrath has come

Existing in the present is spoken of as having come. AT: "You are ready to show your anger" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The time has come

Existing in the present is spoken of as having come. AT: "The time is right" or "Now is the time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the prophets, those who are believers, and those who feared your name

This list explains what "your servants" means. These were not three completely different groups of people. The prophets also were believers and feared God's name. "Name" here is a metonym for the person of Jesus Christ. AT: "the prophets, those who are believers, and those who fear you" or "the prophets and the others who are believers and fear your name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonomy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]

### Revelation 11:19

#### Then God's temple in heaven was opened

This can be stated in active form. AT: "Then someone opened God's temple in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the ark of his covenant was seen within his temple

This can be stated in active form. AT: "I saw the ark of his covenant in his temple" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### flashes of lightning

Use your language's way of describing what lightning looks like each time it appears. See how you translated this in [Revelation 4:5](../04/04.md).

#### rumblings, crashes of thunder

These are the loud noises that thunder makes. Use your language's way of describing the sound of thunder. See how you translated this in [Revelation 4:5](../04/04.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/arkofthecovenant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md)]]

### Revelation 11:intro

#### Revelation 11 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 11:15, 17-18.

######## Woe ########

There are several specific "woes" mentioned in the book of Revelation. This chapter contains the second and third of these woes. It is possible these have some structural significance or importance to the chronology of the events of Revelation.

####### Special concepts in this chapter #######

######## Gentiles ########
The word "Gentiles" is used in this chapter to refer to ungodly Gentiles and not Gentile Christians. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/ungodly.md)]]) 

######## Two witnesses ########
These two witnesses serve an important function as prophets during the time of Revelation. Scholars have put forth many suggestions about the identity of these two men. It is unknown and unimportant who they are. Instead, it is their indestructible nature and their message that is more significant and undeniable. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]) 

######## Bottomless pit ########
This is a common image in the book of Revelation that portrays hell. It emphasizes hell is inescapable. It is described as being down, in opposition to heaven, which is considered as being up. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]])

####### Other possible translation difficulties in this chapter #######

######## "These two prophets tormented those who lived on the earth" ########
The two prophets are connected with a great deal of destruction, which will cause great harm to the people on the earth. This is not mean-spirited, but it is an effort to bring these people to repentance. But they will not repent. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## "The time has come for the dead to be judged" ########
People will be judged after they die. Those who reject Jesus will suffer eternal punishment, while Christians will be rewarded for the faithfulness with which they lived their lives as Christians. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]])
##### Links: #####

* __[Revelation 11:01 Notes](./01.md)__

__[<<](../10/intro.md) | [>>](../12/intro.md)__


## Revelation 12

### Revelation 12:01

#### General Information:

John begins to describe a woman who appears in his vision.

#### A great sign was seen in heaven

This can be stated in active form. AT: "A great sign appeared in heaven" or "I, John, saw a great sign in heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a woman clothed with the sun, and with the moon under her feet

This can be stated in active form. AT: "A woman who was wearing the sun and had the moon under her feet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### a crown of twelve stars

This was apparently a likeness of a wreath made of laurel leaves or olive branches, but with twelve stars included in it.

#### twelve stars

"12 stars" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/laborpains.md)]]

### Revelation 12:03

#### Connecting Statement:

John describes a dragon that appears in his vision.

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### His tail swept away a third of the stars

"With his tail he swept away a third of the stars"

#### a third

"one third." See how you translated this in [Revelation 8:7](../08/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-fraction.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]

### Revelation 12:05

#### rule all the nations with an iron rod

Ruling harshly is spoken of as ruling with an iron rod. See how you translated a similar phrase in [Revelation 2:27](../02/26.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Her child was snatched away to God

This can be stated in active form. AT: "God quickly took her child to himself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for 1,260 days

"for one thousand two hundred and sixty days" or "for twelve hundred and sixty days" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Revelation 12:07

#### Now

John uses this word to mark a shift in his account to introduce something else happening in his vision.

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. The dragon is also identified in verse 9 as "the devil or Satan." See how you translated this in [Revelation 12:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### So there was no longer any place in heaven for him and his angels

"So the dragon and his angels could no longer stay in heaven"

#### dragon—that old serpent called the devil or Satan, who deceives the whole world—was thrown down to the earth, and his angels were thrown down with him

The information about the serpent can be given in a separate sentence after the statement that it was thrown down to the earth. AT: "dragon was thrown down to earth, and his angels were thrown down with him. He is the old serpent who deceives the world and is called the devil or Satan" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]])

#### The great dragon ... was thrown down to the earth, and his angels were thrown down with him

This can be stated in active form. AT: "God threw the great dragon ... and his angels out of heaven and sent them to the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/michael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Revelation 12:10

#### I

The word "I" refers to John.

#### I heard a loud voice in heaven

The word "voice" refers to someone who speaks. AT: "I heard someone saying loudly from heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Now have come the salvation, the power, the kingdom of our God, and the authority of his Christ

God saving people by his power is spoken of as if his salvation and power were things that have come. God's ruling and Christ's authority are also spoken of as if they have come. AT: "Now God has saved his people by his power, God rules as king, and his Christ has all authority" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### have come

"have begun to really exist" or "have appeared" or "have become real." God is revealing these things because their time to occur has "come." It is not that they did not exist before.

#### the accuser of our brothers has been thrown down

This is the dragon that was thrown down in [Revelation 12:9](./10.md).

#### our brothers

Fellow believers are spoken of as if they were brothers. AT: "our fellow believers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### day and night

These two parts of the day are used together to mean "all the time" or "without stopping" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/accuse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]

### Revelation 12:11

#### Connecting Statement:

The loud voice from heaven continues to speak.

#### They conquered him

"They conquered the accuser"

#### by the blood of the Lamb

The blood refers to his death. AT: "because the lamb had shed his blood and died for them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### by the word of their testimony

The word "testimony" can be expressed with the verb "testify." Also who they testified about can be stated clearly. AT: "by what they said when they testified to others about Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]]) (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### even to death

The believers told the truth about Jesus, even though they knew that their enemies might try to kill them because of it. AT: "but they kept testifying even though they knew that they might die for it"

#### He is filled with terrible anger

The devil is spoken of as if he were a container, and anger is spoken of as if it were a liquid that could be in him. AT: "He is terribly angry" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/know.md)]]

### Revelation 12:13

#### the dragon realized he had been thrown down to the earth

This can be stated in active form. AT: "the dragon realized that God had thrown him out of heaven and sent him to earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he pursued the woman

"he chased after the woman"

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. The dragon is also identified in verse 9 as "the devil or Satan." See how you translated this in [Revelation 12:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### time, times, and half a time

"three and half years"

#### the serpent

This is another way of referring to the dragon.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/eagle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]

### Revelation 12:15

#### serpent

This is the same being as the dragon mentioned earlier in [Revelation 12:9](./07.md).

#### like a river

The water flowed from his mouth like a river flows. AT: "in large volume" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### to sweep her away

"to wash her away"

#### The earth opened its mouth and swallowed the river that the dragon was pouring out of his mouth

The earth is spoken of as if it were a living thing, and a hole in the earth is spoken of as if it were a mouth that could drink up the water. AT: "A hole in the ground opened up and the water went down into the hole" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. The dragon is also identified in verse 9 as "the devil or Satan." See how you translated this in [Revelation 12:3](./03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### hold to the testimony about Jesus

The word "testimony" can be translated as a verb. AT: "continue to testify about Jesus"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Revelation 12:intro

#### Revelation 12 General Notes ####

####### Structure and formatting #######

Many scholars believe the events of this chapter are both future and past. The author may shift between the events without shifting the tense in which he speaks. Despite this, John speaks as if these events are about to happen.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 12:10-12.

####### Special concepts in this chapter #######

######## Serpent ########
The reference to Satan as the serpent is intended to have the reader remember the account of the temptation in the Garden of Eden. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

####### Important figures of speech in this chapter #######

######## Metaphor ########
The woman is described using many different metaphors, but her identity is unclear. The chapter also speaks about the rise of the antichrist. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/antichrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/antichrist.md)]])

####### Other possible translation difficulties in this chapter #######

######## "A great sign was seen in heaven" ########
It is unclear whether this was seen by everybody on earth or whether it was only seen by John in his vision. The translator may have difficulty when the subject is unclear. In English, this is done through the use of the passive voice, but not every language has this construct. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

##### Links: #####

* __[Revelation 12:01 Notes](./01.md)__

__[<<](../11/intro.md) | [>>](../13/intro.md)__


## Revelation 13

### Revelation 13:01

#### General Information:

John begins to describe a beast who appears in his vision. The word "I" here refers to John.

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. The dragon is also identified as "the devil or Satan." See how you translated this in [Revelation 12:3](../12/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### The dragon gave his power to it

The dragon made the beast as powerful as he was. He did not lose his power, however, by giving it to the beast.

#### his power ... his throne, and his great authority to rule

These are three ways of referring to his authority, and together they emphasize that the authority was great.

#### his throne

The word "throne" here refers to the dragon's authority to rule as king. AT: "his royal authority" or "his authority to rule as king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leopard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/leopard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bearanimal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bearanimal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Revelation 13:03

#### but its fatal wound was healed

This can be stated in active form. AT: "but its fatal wound healed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### fatal wound

"deadly wound." This is an injury that is serious enough to cause a person to die.

#### The whole earth

The word "earth" refers to the people on it. AT: "All the people on the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### followed the beast

"obeyed the beast"

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. The dragon is also identified as "the devil or Satan." See how you translated this in [Revelation 12:3](../12/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### he had given his authority to the beast

"he had caused the beast to have as much authority as he had"

#### Who is like the beast?

This question shows how amazed they were about the beast. AT: "No one is as powerful as the beast!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Who can fight against it?

This question shows how much the people feared the power of the beast. AT: "No one could ever fight against the beast and win!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]

### Revelation 13:05

#### The beast was given ... It was permitted

This can be stated in active form. AT: "God gave the beast ... God permitted the beast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The beast was given a mouth that could speak

Being given a mouth refers to being allowed to speak. AT: "The beast was allowed to speak" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### forty-two months

"42 months" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### to speak blasphemies against God

"to say disrespectful things about God"

#### blaspheming his name, the place where he lives, and those who live in heaven

These phrases tell how the beast spoke blasphemies against God.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proud.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Revelation 13:07

#### authority was given to it

This can be stated in active form. AT: "God gave authority to the beast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### every tribe, people, language, and nation

This means that people from every ethnic group are included. See how you translated a similar list in [Revelation 5:9](../05/09.md).

#### will worship it

"will worship the beast"

#### everyone whose name was not written ... in the Book of Life

This phrase clarifies who on the earth will worship the beast. It can be stated in active form. AT: "those whose names the Lamb did not write ... in The Book of Life" or "those whose names were not ... in the Book of Life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### since the creation of the world

"when God created the world"

#### the Lamb

A "lamb" is a young sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](../05/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### who had been slaughtered

This can be stated in active form. AT: "whom the people slaughtered" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/slaughter.md)]]

### Revelation 13:09

#### General Information:

These verses are a break from John's account of his vision. Here he give a warning to the people reading his account.

#### If anyone has an ear

Being willing to listen is spoken of as having an ear. See how you translated a similar phrase in [Revelation 2:7](../02/06.md). AT: "Let the one who is willing to listen, listen" or "If you are willing, listen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### If anyone is to be taken

This expression means that someone has decided who should be taken. If needed, translators may state clearly who decided it. AT: "If God has decided that someone should be taken" or "If it is God's will that someone should be taken" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### If anyone is to be taken into captivity

This can be stated in active form. The noun "captivity" can be stated with the verb "capture." AT: "If it is God's will for the enemy to capture a certain person" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### into captivity he will go

The noun "captivity" can be stated with the verb "capture." AT: "he will be captured" or "the enemy will capture him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### If anyone is to be killed with the sword

This can be stated in active form. AT: "If it is God's will for the enemy to kill a certain person with a sword" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### with the sword

The sword represents war. AT: "in war" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he will be killed

This can be stated in active form. AT: "the enemy will kill him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Here is a call for patient endurance and faith for those who are holy

"Those who are holy must endure patiently and be faithful"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/captive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Revelation 13:11

#### Connecting Statement:

John begins to describe another beast who appears in his vision.

#### it spoke like a dragon

Harsh speech is spoken of as if it were the roar of a dragon. AT: "it spoke harshly like a dragon speaks" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. The dragon is also identified as "the devil or Satan." See how you translated this in [Revelation 12:3](../12/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the earth and those who live on it

"everyone on the earth"

#### the one whose lethal wound had been healed

This can be stated in active form. AT: "the one who had a lethal wound that healed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### lethal wound

"deadly wound." This was an injury that was serious enough that it could have made him die.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]

### Revelation 13:13

#### It performed

"The beast from the earth performed"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]

### Revelation 13:15

#### It was permitted

This can be stated in active form. AT: "God permitted the beast from the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### to give breath to the beast's image

Here the word "breath" represents life. AT: "to give life to the beast's image" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the beast's image

This is the image of the first beast that had been mentioned.

#### cause all who refused to worship the beast to be killed

"put to death anyone who refused to worship the first beast"

#### It also forced everyone

"The beast from the earth also forced everyone"

#### It was impossible for anyone to buy or sell unless he had the mark of the beast

"People could buy or sell things only if they had the mark of the beast." The implicit information that the beast from the earth commanded it can be stated clearly. AT: "He commanded that people could buy or sell things only if they had the mark of the beast" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the mark of the beast

This was an identifying mark that indicated that the person who received it worshiped the beast.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/breath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Revelation 13:18

#### General Information:

This verse is a break from John's account of his vision. Here he gives another warning to the people reading his account.

#### This calls for wisdom

"Wisdom is needed" or "You need to be wise about this"

#### If anyone has insight

The word "insight" can be translated with the verb "understand." AT: "If anyone is able to understand things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### let him calculate the number of the beast

"he should discern what the number of the beast means" or "he should figure out what the number of the beast means"

#### is the number of a human being

Possible meanings are 1) the number represents one person or 2) the number represents all of humanity.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]

### Revelation 13:intro

#### Revelation 13 General Notes ####

####### Structure and formatting #######

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 13:10, which is quoted from the OT.

####### Special concepts in this chapter #######

######## A lethal wound ########
Many scholars believe this is a prophecy about the death of the antichrist. They believe the antichrist will mimic or counterfeit the resurrection of Jesus. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/antichrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/antichrist.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]])
####### Important figures of speech in this chapter #######

######## The beast ########
Many scholar believe this is a metaphorical way to refer to the antichrist. This is very significant for proper understanding of this passage. This is used in contrast to the lamb, which is a reference to Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]], [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## Another beast ########
Many scholars believe this second beast is a prophet or priest of the antichrist. He is capable of performing many wondrous miracles and gets many people to worship the antichrist. 

####### Other possible translation difficulties in this chapter #######

######## Unknown animals ########
This chapter uses a great number of unknown animals. Many of these animals are used in a symbolic way but their meaning is imprecise. This will cause great difficulties for translators. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

##### Links: #####

* __[Revelation 13:01 Notes](./01.md)__

__[<<](../12/intro.md) | [>>](../14/intro.md)__


## Revelation 14

### Revelation 14:01

#### Connecting Statement:

John begins to describe the next part of his vision. There are 144,000 believers standing before the Lamb.

#### General Information:

The word "I" refers to John.

#### Lamb

A "lamb" is a young sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](../05/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### 144,000

"one hundred forty-four thousand." See how you translated this in [Revelation 7:4](../07/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### who had his name and his Father's name written on their foreheads

This can be stated in active form. AT: "on whose foreheads the Lamb and his Father had written their names" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his Father

This is an important title for God that describes the relationship between God and Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/guidelines-sonofgodprinciples.md)]])

#### a voice from heaven

"a sound from heaven"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/godthefather.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]

### Revelation 14:03

#### They sang a new song

"The 144,000 people sang a new song." This explains what the sound was that John heard. AT: "That sound was a new song that they sang"

#### the four living creatures

"living being" or "living thing." See how you translated "living creature" in [Revelation 4:6](../04/06.md)

#### elders

This refers to the twenty-four elders around the throne. See how you translated "elders" in [Revelation 4:4](../04/04.md).

#### 144,000

"one hundred forty-four thousand." See how you translated this in [Revelation 7:4](../07/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### have not defiled themselves with women

Possible meanings are 1) "have never had immoral sexual relations with a woman" or 2) "have never had sexual relations with a woman." Defiling oneself with women may be a symbol of worshiping idols.

#### they have kept themselves sexually pure

Possible meanings are 1) "they did not have sexual relations with a woman who was not their wife" or 2) "they are virgins."

#### follow the Lamb wherever he goes

Doing what the Lamb does is spoken of as following him. AT: "they do whatever the Lamb does" or "they obey the Lamb" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### bought out of mankind as firstfruits

"Firstfruits" here is a metaphor for the first offering to be made to God in celebration of harvest. AT: "purchased out of the midst of the rest of mankind as a special celebration of salvation"  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### No lie was found in their mouth

Their "mouth" refers to what they said." AT: "They never lied when they spoke" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/defile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/firstfruit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blameless.md)]]

### Revelation 14:06

#### Connecting Statement:

John begins to describe the next part of his vision. This is the first of three angels who proclaim judgment on the earth.

#### every nation, tribe, language, and people

This means that people from every ethnic group are included. See how you translated a similar list in [Revelation 5:9](../05/09.md).

#### the hour of his judgment has come

Here "the hour" represents the time that has been chosen for something, and the hour having "come" is a metaphor for now being the chosen time. The idea of "judgment" can be expressed with a verb. AT: "now is the time that God has chosen for judgment" or "it is now the time for God to judge people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/goodnews.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tribe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]

### Revelation 14:08

#### Fallen, fallen is Babylon the great

The angel speaks of Babylon having been destroyed as if it had fallen. AT: "Babylon the great has been destroyed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Babylon the great

"Babylon the large city" or "the important city of Babylon." This was probably a symbol for the city of Rome, which was large, wealthy, and sinful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### who persuaded

Babylon is spoken of as if it were a person, instead of a city filled with people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### to drink the wine of her immoral passion

This is a symbol for participating in her sexually immoral passion. AT: "to be sexually immoral like her" or "to get drunk like her in sexual sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### her immoral passion

Babylon is spoken of as if it were a prostitute who has caused other people to sin along with her. This may well have a double meaning: literal sexual immorality and also the worship of false gods. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Revelation 14:09

#### with a loud voice

"loudly"

#### will also drink some of the wine of God's wrath

Drinking the wine of God's wrath is a symbol for being punished by God. AT: "will also drink some of the wine that represents God's wrath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### that has been poured undiluted

This can be translated in active form. AT: "that God has poured full strength" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### that has been poured undiluted

This means that the wine has no water mixed into it. It is strong, and a person who drinks much of it will get very drunk. As a symbol, it means that God will be extremely angry, not just a little angry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### cup of his anger

This symbolic cup holds the wine that represents God's anger. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]

### Revelation 14:11

#### Connecting Statement:

The third angel continues to speak.

#### The smoke from their torment

The phrase "their torment" refers to the fire that torments them. AT: "The smoke from the fire that torments them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### they have no rest

"they have no relief" or "the torment does not stop"

#### day or night

These two parts of the day are used to refer to all of the time. AT: "ever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### Here is a call for the patient endurance of those who are holy

"Those who are holy must endure patiently and be faithful." See how you translated a similar phrase in [Revelation 13:10](../13/09.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/patient.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/endure.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]

### Revelation 14:13

#### the dead who die

"those who die"

#### who die in the Lord

"who are united to the Lord and die." This may refer to people who are killed by their enemies. AT: "who die because they are united to the Lord"

#### labors

difficulties and sufferings

#### their deeds will follow them

These deeds are spoken of as if they were alive and able to follow those who did them. Possible meanings are 1) "others will know the good deeds these people have done" or 2) "God will reward them for their deeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inchrist.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/labor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]

### Revelation 14:14

#### Connecting Statement:

John begins to describe the next part of his vision. This part is about the Son of Man harvesting the earth. Harvesting the grain is a symbol of God's judging people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### one like a son of man

This expression describes a human figure, someone who looks human. See how you translated this in [Revelation 1:13](../01/12.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### golden crown

This was the likeness of a wreath of olive branches or laurel leaves, hammered out in gold. Examples actually made of leaves were given to victorious athletes to wear on their heads.

#### sickle

a tool with a curved blade used for cutting grass, grain, and vines (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### came out of the temple

"came out of the heavenly temple"

#### the time to reap has come

Existing in the present is spoken of as having come. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the earth was harvested

This can be stated in active form. AT: "he harvested the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sonofman.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reap.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/time.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]

### Revelation 14:17

#### Connecting Statement:

John continues describing his vision about the earth being harvested.

#### who had authority over the fire

Here "authority over" refers to responsibility to tend the fire.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]

### Revelation 14:19

#### great wine vat ... winepress

These refer to the same container.

#### the great wine vat of God's wrath

"the large wine vat where God will show his wrath"

#### up to the height of a horse's bridle

"as high as the bridle in a horse's mouth"

#### bridle

a device made of leather straps that goes around a horse's head and is used for directing the horse

#### 1,600 stadia

"one thousand six hundred stadia" or "sixteen hundred stadia." A "stadium" is 185 meters. In modern measures this would be about "300 kilometers" or "200 miles." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]

### Revelation 14:intro

#### Revelation 14 General Notes ####

####### Special concepts in this chapter #######

######## "Victorious over the beast" ########
This is victory in the spiritual battles occurring during this time. While most spiritual battles cannot be seen, the book of Revelation pictures a time of great spiritual battles openly occurring. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## Mark of the beast ########
John has spent some time discussing the mark given by the beast. Many scholars believe this chapter teaches that those who receive this mark will face eternal punishment in hell. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]])

####### Important figures of speech in this chapter #######

######## Harvest ########
This is a common image used in scripture. The harvest illustrates a time when good things come to fruition. It is commonly used to refer to people coming to faith in Jesus, but this is not how John uses it here. It is used to describe the culmination of God's plans. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

##### Links: #####

* __[Revelation 14:01 Notes](./01.md)__

__[<<](../13/intro.md) | [>>](../15/intro.md)__


## Revelation 15

### Revelation 15:01

#### General Information:

This verse is a summary of what will happen in 15:6-16:21.

#### great and marvelous

These words have similar meanings and are used for emphasis. AT: "something that greatly amazed me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### seven angels with seven plagues

"seven angels who had authority to send seven plagues on the earth"

#### which are the final plagues

"and after them, there will not be any more plagues"

#### for with them the wrath of God will be completed

This can be stated in active form. AT: "for these plagues will complete the wrath of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for with them the wrath of God will be completed

Possible meanings are 1) these plagues will show all of God's anger or 2) after these plagues, God will no longer be angry.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 15:02

#### General Information:

Here John begins to describe his vision of the people who had been victorious over the beast and who are praising God.

#### sea of glass

How it was like glass or a sea can be stated clearly. Possible meanings are 1) a sea is spoken of as if it were glass. AT: "a sea that was as smooth as glass" or 2) glass if spoken of as if it were a sea. See how you translated this in [Revelation 4:6](../04/06.md). AT: "glass that was spread out like a sea" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who had been victorious over the beast and his image

How they were victorious can be stated clearly. AT: "who had been victorious over the beast and his image by not worshiping them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### over the number representing his name

How they were victorious over the number can be stated clearly. AT: "over the number representing his name by not being marked with that number" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the number representing his name

This refers to the number described in [Revelation 13:18](../13/18.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 15:03

#### They were singing

"Those who had been victorious over the beast were singing"

#### Who will not fear you, Lord, and glorify your name?

This question is used to show their amazement at how great and glorious the Lord is. It can be expressed as an exclamation. AT: "Lord, everyone will fear you and glorify your name!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### glorify your name

The phrase "your name" refers to God. AT: "glorify you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your righteous deeds have been revealed

This can be stated in active form. AT: "you have made everyone know about your righteous deeds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/moses.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/reveal.md)]]

### Revelation 15:05

#### Connecting Statement:

The seven angels with the seven plagues come out of the most holy place. They were spoken of previously in [Revelation 15:1](./01.md).

#### After these things

"After the people finished singing"

#### the seven angels holding the seven plagues

These angels were seen as holding seven plagues because in [Revelation 17:7](./07.md) they are given seven bowls full of the wrath of God.

#### linen

a fine, expensive cloth made from flax

#### sashes

A sash is a decorative piece of cloth worn on the upper body.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/tentofmeeting.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/clothed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Revelation 15:07

#### the four living creatures

"living being" or "living thing." See how you translated "living creatures" in [Revelation 4:6](../04/06.md)

#### seven golden bowls full of the wrath of God

The image of the wine in the bowls can be stated clearly. The word "wrath" here refers to punishment. The wine is a symbol for punishment. AT: "seven gold bowls full of the wine that represents the wrath of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### until the seven plagues of the seven angels were completed

"until the seven angels finished sending the seven plagues to the earth"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]

### Revelation 15:intro

#### Revelation 15 General Notes ####

####### Structure and formatting #######

The events and pictures described in this chapter occur in heaven.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 15:3-4.

####### Special concepts in this chapter #######

######## "The most holy place, in which was the tent of witness, was open in heaven" ########
This statement has led some scholars to believe that the Jewish temple reflected a scene in heaven. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]]) 

######## Songs ########

Heaven is often described as a place where people sing. These are songs of worship to God. This illustrates that heaven is a place where God is continually worshiped. 

##### Links: #####

* __[Revelation 15:01 Notes](./01.md)__

__[<<](../14/intro.md) | [>>](../16/intro.md)__


## Revelation 16

### Revelation 16:01

#### Connecting Statement:

John continues to describe the part of the vision about the seven angels with the seven plagues. The seven plagues are the seven bowls of God's wrath.

#### I heard

The word "I" refers to John.

#### bowls of God's wrath

The image of the wine in the bowls can be stated clearly. The word "wrath" here refers to punishment. The wine is a symbol for punishment. See how you translated a similar phrase in [Revelation 15:7](../15/07.md). AT: "bowls full of the wine that represents God's wrath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Revelation 16:02

#### poured out his bowl

The word "bowl" refers to what is in it. AT: "poured out the wine from his bowl" or "poured out God's wrath from his bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### painful sores

"painful wounds." These could be infections from diseases or injuries that have not healed.

#### mark of the beast

This was an identifying mark that indicated that the person who received it worshiped the beast. See how you translated this in [Revelation 13:17](../13/15.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]

### Revelation 16:03

#### poured out his bowl

The word "bowl" refers to what is in it. See how you translated this in [Revelation 16:2](./02.md). AT: "poured out the wine from his bowl" or "poured out God's wrath from his bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the sea

This refers to all the salt water lakes and oceans. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Revelation 16:04

#### poured out his bowl

The word "bowl" refers to what is in it. See how you translated this in [Revelation 16:2](./02.md). AT: "poured out the wine from his bowl" or "poured out God's wrath from his bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### rivers and the springs of water

This refers to all bodies of fresh water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### the angel of the waters

Possible meanings are 1) this refers to the third angel who was in charge of pouring out God's wrath on the rivers and springs of water or 2) this was another angel who was in charge of all the waters.

#### You are righteous

"You" refers to God. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the one who is and who was

"God who is and who was." See how you translated a similar phrase in [Revelation 1:4](../01/04.md).

#### they poured out the blood of the believers and prophets

Here "poured out the blood" means killed. AT: "evil people murdered the believers and prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### you have given them blood to drink

God will make the evil people drink the waters that he turned to blood.

#### I heard the altar reply

The word "altar" here refers perhaps to someone at the altar. "I heard someone at the altar reply" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fountain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyone.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]

### Revelation 16:08

#### poured out his bowl

The word "bowl" refers to what is in it. See how you translated this in [Revelation 16:2](./02.md). AT: "poured out the wine from his bowl" or "poured out God's wrath from his bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### it was given permission to scorch the people

John speaks about the sun as if it were a person. This can be stated in active form. AT: "and caused the sun to severely burn the people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They were scorched by the terrible heat

This can be stated in active form. AT: "The extreme heat burned them badly" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### they blasphemed the name of God

Here the name of God represents God. AT: "they blasphemed God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### God, who has the power over these plagues

This phrase reminds readers of something they already know about God. It helps to explain why the people were blaspheming God. AT: "God because he has the power over these plagues" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]])

#### the power over these plagues

This refers to the power to inflict these plagues on people, and the power to stop the plagues. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]

### Revelation 16:10

#### poured out his bowl

The word "bowl" refers to what is in it. See how you translated this in [Revelation 16:2](./02.md). AT: "poured out the wine from his bowl" or "poured out God's wrath from his bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the throne of the beast

This is where the beast reigns from. It may refer to the capital city of his kingdom. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### darkness covered its kingdom

"Darkness" here is a metaphor, in which ungodliness is like a blanket, obstructing everything from God's influence. AT: "ungodliness was over all its kingdom" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### They chewed ... They blasphemed

This refers to the people in the beast's kingdom.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/repent.md)]]

### Revelation 16:12

#### poured out his bowl

The word "bowl" refers to what is in it. See how you translated this in [Revelation 16:2](./02.md). AT: "poured out the wine from his bowl" or "poured out God's wrath from his bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Euphrates. Its water was dried up

This can be stated in active form. AT: "the Euphrates. Its water dried up" or "the Euphrates, and caused its water to dry up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### looked like frogs

A frog is a small animal that lives near water. Jews considered them unclean animals.

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. The dragon is also identified in verse 9 as "the devil or Satan." See how you translated this in [Revelation 12:3](../12/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/euphrates.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/world.md)]]

### Revelation 16:15

#### General Information:

Verse 15 is a break from the main story line of John's vision. These are words spoken by Jesus. The story line continues in verse 16.

#### Look! I am coming ... his shameful condition

This is in parentheses to show that it is not part of the story line in the vision. Rather, this is something that the Lord Jesus said. It can be stated clearly that the Lord Jesus said this, as in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### I am coming as a thief

Jesus will come at a time when people do not expect him, just as a thief comes when not expected. See how you translated a similar phrase in [Revelation 3:3](../03/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### keeping his garments on

Living the right way is spoken of as keeping one's clothes on. AT: "doing what is right, like keeping his clothes on" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### keeping his garments on

Some versions translate, "keeping his garments with him."

#### they see his shameful condition

Here the word "they" refers to other people.

#### They brought them together

"The spirits of the demons brought the kings and their armies together"

#### the place that is called

This can be stated in active form. AT: "the place that people call" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Armageddon

This is the name of a place. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/watch.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hebrew.md)]]

### Revelation 16:17

#### Connecting Statement:

The seventh angel pours out the seventh bowl of God's wrath.

#### poured out his bowl

The word "bowl" refers to what is in it. See how you translated this in [Revelation 16:2](./02.md). AT: "poured out the wine from his bowl" or "poured out God's wrath from his bowl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Then a loud voice came out of the temple and from the throne

This means someone sitting on the throne or someone standing near the throne spoke loudly. It is unclear who is speaking. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### flashes of lightning

Use your language's way of describing what lightning looks like each time it appears. See how you translated this in [Revelation 4:5](../04/04.md).

#### rumbles, crashes of thunder

These are the loud noises that thunder makes. Use your language's way of describing the sound of thunder. See how you translated this in [Revelation 4:5](../04/04.md).

#### The great city was split

This can be stated in active form. AT: "The earthquake split the great city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Then God called to mind

"Then God remembered" or "Then God thought of" or "Then God started to pay attention to." This does not mean that God remembered something he had forgotten.

#### he gave that city the cup filled with the wine made from his furious wrath

The wine is a symbol of his wrath. Making people drink it is a symbol of punishing them. AT: "he made the people of that city drink the wine that represents his wrath" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]

### Revelation 16:20

#### Connecting Statement:

This is part of the seventh bowl of God's wrath.

#### the mountains were no longer found

The inability to see any mountains is metonymy expressing the idea that no mountains existed any longer. AT: "there were no longer any mountains" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### a talent

You may convert this to a modern measure. AT: "33 kilograms" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bweight.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hail.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]

### Revelation 16:intro

#### Revelation 16 General Notes ####

####### Structure and formatting #######

This chapter forms the conclusion of a major section of the book of Revelation, ending the period of wrath or great judgment by God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]])

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 16:5-7.

####### Special concepts in this chapter #######

######## "The most holy place" ########

This statement has led some scholars to believe that the Jewish temple reflected a scene in heaven. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## Seven bowl judgments ########
This chapter reveals judgments called the seven bowl judgments. The judgments are pictured as being poured out, emphasizing their quickness and totality. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

The tone of this chapter is meant to shock the reader. This should not be minimized in translation. 

######## Armageddon ########

This is a word in Hebrew, and it is used as the name of a place. John transliterates the sounds of this word by writing them with Greek letters. Translators are encouraged to transliterate it using the letters of the target language. 

##### Links: #####

* __[Revelation 16:01 Notes](./01.md)__

__[<<](../15/intro.md) | [>>](../17/intro.md)__


## Revelation 17

### Revelation 17:01

#### General Information:

John begins to describe the part of his vision about the great prostitute.

#### the condemnation of the great prostitute

The noun "condemnation" can be expressed with the verb "condemn." AT: "how God will condemn the great prostitute" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### the great prostitute

"the prostitute that everyone knows about." She represents a certain sinful city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### on many waters

If you need to, you can use a more specific word for the kind of water. AT: "on many rivers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### It is with the wine of her sexual immorality that the earth's inhabitants became drunk

The wine represents sexual immorality. AT: "The people of the earth became drunk by drinking her wine, that is, they were sexually immoral" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-distinguish.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### her sexual immorality

This may well have a double meaning: sexual immorality among people and also the worship of false gods. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/condemn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]

### Revelation 17:03

#### carried me away in the Spirit to a wilderness

The setting changes from John being in heaven to being in a wilderness. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### pearls

beautiful and valuable white beads. They are formed inside the shell of a certain kind of small animal that lives in the ocean. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### On her forehead was written a name

This can be stated in active form. AT: "Someone had written on her forehead a name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Babylon the great

If it needs to be made clear that the name refers to the woman, it can be put in a sentence. AT: "I am Babylon, the powerful one" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blasphemy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/detestable.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/detestable.md)]]

### Revelation 17:06

#### General Information:

The angel begins to explain to John the meaning of the prostitute and the red beast. The angel explains these things through verse 18.

#### was drunk with the blood ... and with the blood

"was drunk because she had drunk the blood ... and had drunk the blood"

#### the martyrs for Jesus

"the believers who have died because they told others about Jesus"

#### astonished

"amazed" or "surprised"

#### Why are you astonished?

The angel used this question to gently scold John. AT: "You should not be astonished!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/amazed.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horn.md)]]

### Revelation 17:08

#### the bottomless pit

This is an extremely deep narrow hole. Possible meanings are 1) the pit has no bottom; it continues to go down further forever or 2) the pit is so deep that it is as if it had no bottom. See how you translated this in [Revelation 9:1](../09/01.md).

#### Then it will go on to destruction

The noun "destruction" can be translated with a verb. AT: "Then he will be destroyed" or "Then God will destroy him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### it will go on to destruction

The certainty of what will happen in the future is spoken of as if the beast were going to it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### those whose names have not been written

This can be stated in active form. AT: "those whose names God did not write" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### since the foundation of the world

The angel speaks of God creating the world as if he laid the world's foundation, like one would lay the foundation of a building. AT: "before God created the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]

### Revelation 17:09

#### Connecting Statement:

The angel continues speaking. Here he explains the meaning of the seven heads of the beast that the woman is riding.

#### This calls for a mind that has wisdom

The abstract nouns "mind" and "wisdom" can be expressed with "think" and "wise" or "wisely." Why a wise mind is needed can be stated clearly. AT: "A wise mind is needed in order to understand this" or "You need to think wisely in order to understand this" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### This calls for

"This makes it necessary to have"

#### The seven heads are seven hills

Here "are" means "stand for" or "represent."

#### Five kings have fallen

The angel speaks of dying as falling. AT: "Five kings have died" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### one exists

"one is king now" or "one king is alive now"

#### the other has not yet come; when he comes

Not having existed yet is spoken of as not yet having come. AT: "the other has not yet become king; when he becomes king" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### he can remain only for a little while

The angel speaks of someone continuing to be king as if he were remaining in a place. AT: "he can be king only for a little while" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Revelation 17:11

#### it is one of those seven kings

Possible meanings are 1) the beast rules twice: first as one of the seven kings, and then as the eighth king or 2) the beast belongs to that group of seven kings because he is like them.

#### it is going to destruction

The certainty of what will happen in the future is spoken of as if the beast were going to it. AT: "it will certainly be destroyed" or "God will surely destroy it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Revelation 17:12

#### Connecting Statement:

The angel continues speaking to John. Here he explains the meaning of the ten horns of the beast.

#### for one hour

If your language does not divide the day into 24 hours, you may need to use a more general expression. AT: "for a very short time" or "for a very small part of a day" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### These are of one mind

"These all think the same thing" or "These all agree to do the same thing"

#### the Lamb

A "lamb" is a young sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](../05/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the called ones, the chosen ones, and the faithful ones

This refers to one group of people. The words "called" and "chosen" can be expressed in active form. AT: "the called, chosen, and faithful ones" or "the ones whom God has called and chosen, who are faithful to him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/kingdom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mind.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/elect.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]

### Revelation 17:15

#### The waters you saw, where the prostitute is seated, are peoples, multitudes, nations, and languages

Here "are" stands for "represent." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The waters

If you need to, you can use a more specific word for the kind of water. See how you translated "many waters" in [Revelation 17:1](./01.md). AT: "The rivers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### multitudes

"large groups of people" or "great numbers of people"

#### languages

This refers to people who speak the languages. See how you translated this in [Revelation 10:11](../10/10.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Revelation 17:16

#### make her desolate and naked

"steal everything that she has and leave her with nothing"

#### they will devour her flesh

Destroying her completely is spoken of as eating all her flesh. "They will destroy her completely" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### For God has put it into their hearts to carry out his purpose by agreeing to give ... until God's words are fulfilled

They would agree to give their power to the beast, but it would not be that they want to obey God. AT: "For God has put it into their hearts to agree to give ... until God's words are fulfilled, and by doing this, they would carry out God's purpose"

#### God has put it into their hearts

The heart represents desires. Making them want to do something is spoken of as putting it in their hearts to do it. AT: "God has made them want" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### power to rule

"authority" or "kingly authority"

#### until God's words are fulfilled

This can be stated in active form. AT: "until God fulfills what he said will happen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desolate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fulfill.md)]]

### Revelation 17:18

#### Connecting Statement:

The angel finishes speaking to John about the prostitute and the beast.

#### is

Here "is" stands for "represents." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the great city that rules

When it says that the city rules, it means that the leader of the city rules. AT: "the great city whose leader rules" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruler.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]

### Revelation 17:intro

#### Revelation 17 General Notes ####

####### Structure and formatting #######

This chapter is a continuation of the previous chapter. 

####### Special concepts in this chapter #######

######## Prostitute ########
The Jews were often pictured as adulterous people and occasionally as prostitutes. This is not necessarily the reference here. The context may favor identifying the prostitute as Satan, but the translator should allow this illustration to be vague. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

######## Seven hills ########
This is possibly a reference to the city of Rome, which was said to sit atop seven hills. However, the translator should not attempt to identify the seven hills in the translation.

=##### Important figures of speech in this chapter #####

==Metaphors ==
John uses many different metaphors in this chapter. He gives some explanation of their meaning, but allows them to remain relatively unclear. The translator should attempt to do the same. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## "The beast you saw existed, does not exist now, but is about to come up " ########
This phrase is intended to contrast the statement that Jesus "was and is and is to come" used elsewhere in Scripture. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

######## The use of paradox ########

A paradox is a seemingly absurd statement, which appears to contradict itself, but it is not absurd. This sentences in 17:11 is a paradox: "the beast ... is itself also an eighth king; but it is one of those seven kings." The translator should not attempt to resolve this paradox, and it should remain a mystery. ([Revelation 17:11](./20.md))

##### Links: #####

* __[Revelation 17:01 Notes](./01.md)__

__[<<](../16/intro.md) | [>>](../18/intro.md)__


## Revelation 18

### Revelation 18:01

#### Connecting Statement:

Another angel comes down from heaven and speaks. This is a different angel than the one in the previous chapter, who spoke about the prostitute and the beast.

#### General Information:

The pronouns "she" and "her" refer to the city of Babylon, which is spoken of as if it were a prostitute. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Fallen, fallen is Babylon the great

The angel speaks of Babylon having been destroyed as if it had fallen. See how you translated this in [Revelation 14:8](../14/08.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### detestable bird

"disgusting bird" or "repulsive bird"

#### all the nations

The nations is a metonym for the people of those nations. AT: "the people of all the nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### have drunk the wine of her immoral passion

This is a symbol for participating in her sexually immoral passion. AT: "have become sexually immoral like her" or "have become drunk like her in sexual sin" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### her immoral passion

Babylon is spoken of as if it were a prostitute who has caused other people to sin along with her. This may well have a double meaning: literal sexual immorality and also the worship of false gods. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### merchants

A merchant is a person who sells things.

#### from the power of her sensual way of living

"because she spent so much money on sexual immorality"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/demon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Revelation 18:04

#### Connecting Statement:

Another voice from heaven begins to speak.

#### General Information:

The pronouns "she" and "her" refer to the city of Babylon, which is spoken of as if it were a prostitute. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### another voice

The word "voice" refers to the speaker, which is probably either Jesus or the Father. AT: "someone else" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Her sins have piled up as high as heaven

The voice speaks of Babylon's sins as if they were objects that could form a pile. AT: "Her sins are so many they are like a pile that reaches heaven" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### remembered

"thought of" or "started to pay attention to." This does not mean that God remembered something he had forgotten. See how you translated "called to mind" in [Revelation 16:19](../16/17.md).

#### Pay her back as she has paid others back

The voice speaks of punishment as if it were payment. AT: "Punish her as she has punished others" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### repay her double

The voice speaks of punishment as if it were payment. AT: "punish her twice as much" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### in the cup she mixed, mix double the amount for her

The voice speaks of causing others to suffer as preparing strong wine for them to drink. AT: "prepare for her the wine of suffering that is twice as strong as what she made for others" or "make her suffer twice as much as she made others suffer" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### mix double the amount

Possible meanings are 1) "prepare twice the amount" or 2) "make it twice as strong"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Revelation 18:07

#### Connecting Statement:

The same voice from heaven continues speaking about Babylon as if it were a woman.

#### she glorified herself

"the people of Babylon glorified themselves"

#### For she says in her heart,

"Says in her heart" here is a synecdoche for her entire way of thinking. AT: "For she says to herself" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### I am seated as a queen

She claims to be a ruler, having her own authority. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### I am not a widow

She implies that she will not be dependent on other people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I will never see mourning

Experiencing mourning is spoken of as seeing mourning. AT: "I will never mourn" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### her plagues will come

Existing in the future is spoken of a coming. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She will be consumed by fire

Being burned up by fires is spoken of as being eaten up by fire. This can be stated in active form. AT: "Fire will completely burn her up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/queen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/famine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]

### Revelation 18:09

#### Connecting Statement:

John tells what people say about Babylon.

#### General Information:

In these verses the word "her" refers to the city of Babylon.

#### committed sexual immorality and went out of control with her

"sinned sexually and did whatever they wanted just as the people of Babylon did"

#### afraid of her torment

The abstract noun "torment" can be translated as a verb. AT: "afraid that they will be tormented as Babylon is" or "afraid that God will torment them as he torments Babylon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### Woe, woe

This is repeated for emphasis.

#### your punishment has come

Existing in the present is spoken of as having come. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/torment.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Revelation 18:11

#### mourn for her

"mourn for the people of Babylon"

#### precious stone, pearls

"many kinds of expensive stones." See how you translated these in [Revelation 17:4](../17/03.md).

#### fine linen

expensive cloth made from flax. See how you translated "linen" in [Revelation 15:6](../15/05.md).

#### purple

"purple cloth"

#### silk

This is soft, strong cloth made from the fine string that silkworms make when they make their cocoons. AT: "expensive cloth" or "fine cloth" or "beautiful cloth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### scarlet

"red cloth"

#### every vessel of ivory

"all kinds of containers made of ivory"

#### ivory

a beautiful hard, white material that people get from the tusks or teeth of very large animals such as elephants or walruses. AT: "tusks" or "valuable animal teeth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### marble

a precious stone used for building (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### cinnamon

a spice that smells nice and comes from the bark of a certain kind of tree

#### spice

a substance used to add flavor to food or a good smell to oil

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bronze.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/incense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/myrrh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/frankincense.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/cow.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]

### Revelation 18:14

#### The fruit

"Fruit" here is a metaphor for "result" or "outcome." AT: "The result" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### longed for with all your might

"wanted very much"

#### vanished, never to be found again

Not to be found stands for not existing. This figure of speech can be stated in active form. AT: "vanished; you will never have them again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]

### Revelation 18:15

#### General Information:

In these verses, the word "her" refers to the city of Babylon.

#### because of the fear of her torment

This can be restated to remove the abstract nouns "fear" and "torment." AT: "because they will be afraid of God tormenting them they way he torments her" or "because they will be afraid of suffering the way she is suffering" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### weeping and mourning loudly

This is what the merchants will be doing. AT: "and they will weep and mourn loudly"

#### the great city that was dressed in fine linen

Throughout this chapter, Babylon is spoken of as if it were a woman. The merchants speak of Babylon as being dressed in fine linen because its people were dressed in fine linen. AT: "the great city, which was like a woman dressed in fine linen" or "the great city, whose women were dressed in fine linen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### that was dressed in fine linen

This can be stated in active form. AT: "that wore fine linen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### was adorned with gold

This can be stated in active form. AT: "adorned herself with gold" or "adorned themselves with gold" or "wore gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### precious jewels

"valuable gems" or "treasured gems"

#### pearls

beautiful and valuable white beads. They are formed inside the shell of a certain kind of small animal that lives in the ocean. See how you translated this in [Revelation 17:4](../17/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### whose living is made from the sea

The phrase "from the sea" refers to what they do on the sea. AT: "who travel on the sea to make their living" or "who sail on the sea to different places in order to trade things" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/waste.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/waste.md)]]

### Revelation 18:18

#### General Information:

In these verses the word "they" refers to the sailors and seafarers, and the word "her" refers to the city of Babylon.

#### What city is like the great city?

This question shows the people the importance of the city of Babylon. AT: "No other city is like the great city, Babylon!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### God has brought your judgment on her

The noun "judgment" can be expressed with the verb "judge." AT: "God has judged her for you" or "God has judged her because of the bad things she did to you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mourn.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/woe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Revelation 18:21

#### Connecting Statement:

Another angel begins to speak about Babylon. This is a different angel than the ones who have spoken previously.

#### millstone

a large round stone used to crush grain

#### Babylon, the great city, will be thrown down with violence and will not be seen anymore

God will completely destroy the city. This can be stated in active form. AT: "God will violently throw down Babylon, the great city, and it will no longer exist" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will not be seen anymore

"no one will see it anymore." Not being seen here means that it will not exist. AT: "it will not exist anymore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The sound made by harpists, musicians, flute players, and trumpeters will not be heard anymore in you

This can be stated in active form. AT: "No one in your city will ever again hear the sound that harpists, musicians, flute players, and trumpeters make" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### in you

The angel speaks as if Babylon were there listening to him. AT: "in Babylon" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### will not be heard anymore in you

"no one will hear them anymore in you." Not being heard here means that they will not be there. AT: "they will not be in your city anymore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### No craftsman ... will be found in you

Not being found there means that they will not be there. AT: "No craftsman of any kind will be in your city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### No sound of a mill will be heard anymore in you

The sound of something not being heard means that no one will make that sound. AT: "No one will use a mill in your city" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/babylon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]

### Revelation 18:23

#### Connecting Statement:

The angel who threw the millstone finishes talking.

#### General Information:

The words "you," "your," and "her" refer to Babylon.

#### The voices of the bridegroom and the bride will not be heard in you anymore

This can be stated in active form. AT: "No one will ever again hear in Babylon the happy voices of a bridegroom and a bride" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### will not be heard in you anymore

Not being heard here means that they will not be there. AT: "will not be in your city anymore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### your merchants were the princes of the earth

The angel speaks of important and powerful people as if they were princes. AT: "your merchants were like princes of the earth" or "your merchants were the most important men in the world" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the nations were deceived by your sorcery

This can be stated in active form. AT: "you deceived the people of the nations with your magic spells" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### In her the blood of prophets and believers was found, and the blood of all who have been killed on the earth

Blood being found there means that the people there were guilty of killing people. AT: "Babylon is guilty of killing the prophets and believers and all the other people in the world who were killed" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prince.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]

### Revelation 18:intro

#### Revelation 18 General Notes ####

####### Structure and formatting #######

Chapter 19 will continue the material contained in this chapter and both should be seen as a single unit.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 19:1-8.

####### Special concepts in this chapter #######

######## Prophecy ########
The angel gives a prophecy about the fall of Babylon. It is spoken of as having already happened even though it had not yet happened. This was common in prophecy and emphasizes the inevitability of the coming judgment. It is also prophesied that the people will lament over the fall of Babylon. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

####### Important figures of speech in this chapter #######

######## Metaphors ########
Metaphors are frequently used in prophecy. This chapter forms a slight break in the apocalyptic style of the book of Revelation overall. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Revelation 18:01 Notes](./01.md)__

__[<<](../17/intro.md) | [>>](../19/intro.md)__


## Revelation 19

### Revelation 19:01

#### General Information:

This is the next part of John's vision. Here he describes the rejoicing in heaven over the fall of the great prostitute, who is the city of Babylon.

#### I heard

Here "I" refers to John.

#### Hallelujah

This word means "Praise God" or "Let us praise God."

#### the great prostitute

Here John refers to the city of Babylon whose wicked people rule over all the people of the earth and lead them to worship false gods. He speaks of the wicked people of Babylon as if they were a great prostitute. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### who corrupted the earth

Here "the earth" is a metonym for its inhabitants. AT: "who corrupted the people of the earth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the blood of his servants

Here "the blood" is a metonym that represents murder. AT: "murdering his servants" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### she herself

This refers to Babylon. The reflexive pronoun "herself" is used to add emphasis. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/corrupt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Revelation 19:03

#### They spoke

Here "They" refers to the crowd of people in heaven.

#### Hallelujah

This word means "Praise God" or "Let us praise God." See how you translated this in [Revelation 19:1](./01.md).

#### smoke rises from her

The word "her" refers to the city of Babylon, which is spoken of as if it were a prostitute. The smoke is from the fire that destroys the city. AT: "smoke rises from that city" 

#### twenty-four elders

"24 elders." See how you translated this in [Revelation 4:4](../04/04.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### the four living creatures

"the four living beings" or "the four living things." See how you translated this in [Revelation 4:6](../04/06.md)

#### who was seated on the throne

This can be stated in active form. AT: "who sat on the throne" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/creature.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostrate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostrate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]

### Revelation 19:05

#### a voice came out from the throne

Here John speaks of the "voice" as if it were a person. AT: "someone spoke from the throne" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### Praise our God

Here "our" refers to the speaker and all God's servants. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-inclusive.md)]])

#### you who fear him

Here "fear" does not mean to be afraid of God, but to honor him. AT: "all you who honor him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### both the unimportant and the powerful

The speaker uses these words together to mean all of God's people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Revelation 19:06

#### Then I heard what sounded like the voice of a great number of people, like the roar of many waters, and like loud crashes of thunder

John speaks of what he is hearing as if it were like the sound made by a very large crowd of people, a large body of rushing water, and very loud thunder. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Hallelujah

This word means "Praise God" or "Let us praise God." See how you translated this in [Revelation 19:1](./01.md).

#### For the Lord

"Because the Lord"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Revelation 19:07

#### Connecting Statement:

The voice of the crowd from the previous verse continues speaking.

#### Let us rejoice

Here "us" refers to all of God's servants.

#### give him the glory

"give God the glory" or "honor God"

#### wedding celebration of the Lamb ... his bride has made herself ready

Here John speaks of the joining of Jesus and his people together forever as if it were a wedding celebration. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Lamb

This is a young sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](../05/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### has come

Existing in the present is spoken of as having come. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### his bride has made herself ready

John speaks of God's people as if they were a bride who has gotten ready for her wedding. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### She was permitted to be dressed in bright and clean fine linen

Here "she" refers to the people of God. John speaks of the righteous acts of God's people as if they were a bright and clean dress that a bride wears on her wedding day. You can state this in active form. AT: "God allowed her to wear a dress of bright and clean fine linen" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/works.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]

### Revelation 19:09

#### General Information:

An angel begins to speak to John. This is likely the same angel who began to speak to John in [Revelation 17:1](../17/01.md).

#### those who are invited

You can state this in active form. AT: "the people whom God invites" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the wedding feast of the Lamb

Here the angel speaks of the joining of Jesus and his people forever as if it were a wedding feast. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### I prostrated myself

To prostrate oneself is to lie on the ground, face down, to show respect and willingness to serve. See note in [Revelation 19:3](./03.md).

#### your brothers

The word "brothers" here refers to all believers, male and female.

#### who hold the testimony about Jesus

Here holding stands for believing in or announcing. AT: "who speak the truth about Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### for the testimony about Jesus is the spirit of prophecy

Here "spirit of prophecy" refers to God's Holy Spirit. AT: "for it is the Spirit of God who gives people the power to speak the truth about Jesus" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]

### Revelation 19:11

#### General Information:

This is the beginning of a new vision. John begins to describe a rider on a white horse.

#### Then I saw heaven open

This imagery is used to signify the beginning of a new vision. See how you translated this idea in [Revelation 4:1](../04/01.md) and [Revelation 11:19](../11/19.md) and [Revelation 15:5](../15/05.md).

#### The one riding it

The rider is Jesus.

#### It is with justice that he judges and wages war

Here "justice" refers to what is right. AT: "He judges all people and wages war according to what is right" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### His eyes are like a fiery flame

John speaks of the rider's eyes as if they shone like a flame of fire. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### He has a name written on him

You can state this in active form. AT: "Someone has written a name on him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on him that no one knows but himself

"on him, and only he knows the meaning of that name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rpronouns.md)]])

#### He wears a robe that was dipped in blood

You can state this in an active form. AT: "Blood had covered his robe" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### his name is called the Word of God

You can state this in active form. "Word of God" here is a metonym for Jesus Christ. AT: "his name is called the Message of God" or "his name is also the Word of God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithful.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/justice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/judgeposition.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/crown.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]

### Revelation 19:14

#### Out of his mouth goes a sharp sword

The sword blade was sticking out of his mouth. The sword itself was not in motion. See how you translated a similar phrase in [Revelation 1:16](../01/14.md).

#### strikes down the nations

"destroys the nations" or "brings the nations under his control"

#### rule them with an iron rod

John speaks of the rider's power as if he were ruling with an iron rod. See how you translated this in [Revelation 12:5](../12/05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### He tramples in the winepress of the fury of the wrath of God Almighty

John speaks of the rider's destroying his enemies as if they were grapes that a person tramples in a winepress. Here "wrath" refers to God's punishment of evil persons. AT: "He crushes his enemies according to the judgment of God Almighty, just as a person crushes grapes in a winepress" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### He has a name written on his robe and on his thigh:

This can be stated in active form. AT: "Someone has written a name on his robe and thigh:" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wrath.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]

### Revelation 19:17

#### I saw an angel standing in the sun

Here "the sun" is a metonym for the light of the sun. AT: "Then I saw an angel standing in the light of the sun" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### both free and slave, the unimportant and the powerful

The angel uses these two sets of opposite-meaning words together to mean all people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/commander.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]

### Revelation 19:19

#### The beast was captured and with him the false prophet

This can be stated in active form. AT: "The rider on the white horse captured the beast and the false prophet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the mark of the beast

This was an identifying mark that indicated that the person who received it worshiped the beast. See how you translated this in [Revelation 13:17](../13/15.md).

#### The two of them were thrown alive

This can be stated in active form. AT: "God threw the beast and the false prophet alive" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the fiery lake of burning sulfur

"the lake of fire that burns with sulfur" or "place full of fire that burns with sulfur"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]

### Revelation 19:21

#### The rest of them were killed by the sword that came out of the mouth of the one who rode on the horse

This can be stated in active form. AT: "The rider of the horse killed the remainder of the beast's armies with the sword that extended from his mouth" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the sword that came out of the mouth

The sword blade was sticking out of his mouth. The sword itself was not in motion. See how you translated a similar phrase in [Revelation 1:16](../01/14.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/horse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]

### Revelation 19:intro

#### Revelation 19 General Notes ####

####### Structure and formatting #######

Chapter 19 continues the material contained in chapter 18 and both should be seen as a single unit.

Some translations indent each line of poetry to make it easier to read. The ULB does this with the poetry in 19:1-8.

####### Special concepts in this chapter #######

######## Songs ########

Heaven is often described as a place where people sing. These are songs of worship to God. This illustrates that heaven is a place where God is continually worshiped. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]])

######## Wedding celebration ########

The wedding celebration or feast is a very important image used in Scripture. In Jewish culture, paradise, or life with God after death, was often pictured as a feast. Here, Jesus pictures it as a wedding feast that a king prepares for his son, who has just gotten married. In addition, Jesus emphasizes that not all people whom God invites will properly prepare themselves to participate. These people will be thrown out from the feast.

##### Links: #####

* __[Revelation 19:01 Notes](./01.md)__

__[<<](../18/intro.md) | [>>](../20/intro.md)__


## Revelation 20

### Revelation 20:01

#### General Information:

John begins to describe a vision of an angel throwing the devil into the bottomless pit.

#### Then I saw

Here "I" refers to John.

#### bottomless pit

This is an extremely deep narrow hole. Possible meanings are 1) the pit has no bottom; it continues to go down further forever or 2) the pit is so deep that it is as if it had no bottom. See how you translated this in [Revelation 9:1](../09/01.md).

#### dragon

This was a large, fierce reptile, like a lizard. For Jewish people, it was a symbol of evil and chaos. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### sealed it over him

The angel sealed the pit to keep anyone from opening it. AT: "sealed it to prevent anyone from opening it" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### deceive the nations

Here "nations" is a metonym for the people of the earth. AT: "deceive the people-groups" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the thousand years

"1,000 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### he must be set free

This can be stated in active form. AT: "God will command the angel to free him" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serpent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Revelation 20:04

#### General Information:

This is the next part of John's vision. He describes suddenly seeing thrones and the souls of believers.

#### who had been given authority to judge

This can be stated in active form. AT: "whom God had given authority to judge" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### who had been beheaded

This can be stated in active form. AT: "whose heads others had cut off" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### for the testimony about Jesus and for the word of God

"because they had spoken the truth about Jesus and about the word of God"

#### for the word of God

These words are a metonym for the message from God. AT: "for what they taught about the scriptures" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### They came to life

"They came back to life" or "They became alive again"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/authority.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/image.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/receive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]

### Revelation 20:05

#### The rest of the dead

"All of the other dead people"

#### the thousand years were ended

"the end of the 1,000 years" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### Over these the second death has no power

Here John describes "death" as a person with power. AT: "These people will not experience the second death" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the second death

"dying a second time." This is described as eternal punishment in the lake of fire in [Revelation 20:14](./13.md) and [Revelation 21:08](../21/07.md). See how you translated this in [Revelation 2:11](../02/10.md). AT: "the final death in the lake of fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/resurrection.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/power.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/christ.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]

### Revelation 20:07

#### Satan will be released from his prison

This can be stated in active form. AT: "God will release Satan from his prison" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### at the four corners of the earth

This is an idiom that means "all over the earth." See how you translated this in [Revelation 7:1](../07/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Gog and Magog

These are the names that the prophet Ezekiel used to represent faraway countries. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### They will be as many as the sand of the sea

This emphasizes the extremely large number of soldiers in Satan's army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prison.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Revelation 20:09

#### They went

"Satan's army went"

#### the beloved city

This refers to Jerusalem.

#### fire came down from heaven and devoured them

Here John speaks of fire as if it were alive. AT: "God sent fire from heaven to burn them up" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### The devil, who deceived them, was thrown into

This can be stated in active form. AT: "God threw the devil, who had deceived them, into" or "God's angel threw the devil, who had deceived them, into" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### lake of burning sulfur

"the lake of fire that burns with sulfur" or "place full of fire that burns with sulfur." See how you translated this in [Revelation 19:20](../19/19.md).

#### where the beast and the false prophet had been thrown

This can be stated in active form. AT: "where he had also thrown the beast and the false prophet" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### They will be tormented

This can be stated in active form. AT: "God will torment them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/believer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/beloved.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/satan.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/beast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/falseprophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Revelation 20:11

#### General Information:

This is the next part of John's vision. He describes suddenly seeing a great white throne and the dead being judged.

#### The earth and the heaven fled away from his presence, but there was no place for them to go

John describes heaven and earth as if they were people who were trying to escape God's judgment. This means that God completely destroyed the old heaven and earth. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the mighty and the unimportant

John combines these opposite-meaning words to mean all of the dead people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the books were opened

This can be stated in active form. AT: "someone opened the books" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### The dead were judged

This can be stated in active form. AT: "God judged the people who had died and now lived again" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### by what was recorded

This can be stated in active form. AT: "by what he had recorded" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]

### Revelation 20:13

#### The sea gave up the dead ... Death and Hades gave up the dead

Here John speaks of the sea, death, and Hades as if they were living persons. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]])

#### the dead were judged

This can be stated in active form. AT: "God judged the dead people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Death and Hades were thrown

This can be stated in active form. AT: "God threw Death and Hades" or "God's angel threw Death and Hades" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Hades

Here "Hades" is a metonym that represents the place where unbelievers go when they die, to wait for God's judgment. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the second death

"dying a second time." This is described as eternal punishment in the lake of fire in [Revelation 20:14](./13.md) and [Revelation 21:08](../21/07.md). See how you translated this in [Revelation 2:11](../02/10.md). AT: "the final death in the lake of fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### If anyone's name was not found written

This can be stated in active form. AT: "If God's angel did not find a person's name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### he was thrown into the lake of fire

This can be stated in active form. AT: "the angel threw him into the lake of fire" or "the angel threw him into the place where fire burns forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hades.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/written.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md)]]

### Revelation 20:intro

#### Revelation 20 General Notes ####

####### Structure and formatting #######

This chapter is about a period of time often referred to as the "millennial kingdom" because it is a kingdom of a thousand years. This chapter is very significant for understanding the events of the last days and the book of Revelation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lastday.md)]])

####### Special concepts in this chapter #######

######## The thousand-year reign of Christ ########
Jesus is said to reign for a thousand years. and all the prophecies in Scripture about worldwide peace will be fulfilled. Scholars are divided over whether this is an actual period of time or if it is an allegory for Christ beginning to reign in people's hearts. It is best to translate this as if Christ is physically reigning on earth for a thousand years and not attempt to input potential symbolism into the text. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

######## Final rebellion ########
This chapter describes the period of time after Jesus' reign known as the final rebellion. During this time, Satan and many people will attempt to rebel against Jesus. This will result in God's ultimate and final victory over sin and evil before eternity begins. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/sin.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]])

######## Great white throne ########
This is an important judgment in heaven after the final rebellion. During this judgment, people who have faith in God are separated from those who reject him. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faith.md)]])

####### Important figures of speech in this chapter #######

######## Book of life ########
The is a metaphor for eternal life. Those possessing eternal life are said to have their names written in this book of life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## Hades and the lake of fire ########
These appear to be two distinct places. The translator may wish to do further research to determine how to differentiate these two places, but they should not be equated with each other in translation. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]])

##### Links: #####

* __[Revelation 20:01 Notes](./01.md)__

__[<<](../19/intro.md) | [>>](../21/intro.md)__


## Revelation 21

### Revelation 21:01

#### General Information:

John begins to describe his vision of the new Jerusalem.

#### I saw

Here "I" refers to John.

#### like a bride adorned for her husband

This compares the new Jerusalem to a bride who has made herself beautiful for her bridegroom. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/holycity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/holycity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]

### Revelation 21:03

#### a great voice from the throne saying

The word "voice" refers to the one who speaks. AT: "someone speak loudly from the throne saying" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Look!

The word "Look" here alerts us to pay attention to the surprising information that follows.

#### The dwelling place of God is with human beings, and he will live with them

These two phrases mean the same thing and emphasize that God will, indeed, live among men. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### He will wipe away every tear from their eyes

Tears here represent sadness. See how you translated this in [Revelation 7:17](../07/15.md). AT: "God will wipe away their sadness, like wiping away tears" or "God will cause them to not be sad anymore" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/voice.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Revelation 21:05

#### these words are trustworthy and true

Here "words" refers to the message that they formed. AT: "this message is trustworthy and true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the alpha and the omega, the beginning and the end

These two phrases mean basically the same thing and emphasize God's eternal nature. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the alpha and the omega

These are first and last letters of the Greek alphabet. Possible meanings are 1) "the one who began all things and who ends all things" or 2) "the one who has always lived and who always will live." If these are unclear to readers, you may consider using the first and last letters of your alphabet. See how you translated this in [Revelation 1:8](../01/07.md). AT: "the A and the Z" or "the first and the last" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the beginning and the end

Possible meanings are 1) "the one who began all things and the one who will cause all things to end" or 2) "the one who existed before all things and who will exist after all things."

#### To the one who thirsts ... water of life

God speaks of a person's desire for eternal life as if it were thirst and of that person receiving eternal life as if he were drinking life-giving water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/trust.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Revelation 21:07

#### Connecting Statement:

The one seated on the throne continues to speak to John.

#### the cowards

"those who are too afraid to do what is right"

#### the detestable

"those who do terrible things"

#### the fiery lake of burning sulfur

"the lake of fire that burns with sulfur" or "place full of fire that burns with sulfur." See how you translated this in [Revelation 19:20](../19/19.md).

#### the second death

"dying a second time." This is described as eternal punishment in the lake of fire in [Revelation 20:14](../20/13.md) and [Revelation 21:08](./07.md). See how you translated this in [Revelation 2:11](../02/10.md). AT: "the final death in the lake of fire" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/son.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/faithless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/hell.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sulfur.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]]

### Revelation 21:09

#### the bride, the wife of the Lamb

The angel speaks of Jerusalem as if it were a woman who is about to marry her groom, the Lamb. Jerusalem is metonymy for those who believers who will inhabit it. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the Lamb

This is a young sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](../05/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### carried me away in the Spirit

The setting changes as John is taken to a high mountain where he can see the city of Jerusalem. See how you translated this phrase in [Revelation 17:3](../17/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-background.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/holycity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/holycity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]

### Revelation 21:11

#### Jerusalem

This refers to the "Jerusalem, coming down out of heaven" that he described in the previous verse and not to the physical Jerusalem.

#### like a very precious jewel, like a stone of crystal-clear jasper

These two phrases mean basically the same thing. The second emphasizes the brilliance of Jerusalem by naming a specific jewel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### crystal-clear

"extremely clear"

#### jasper

This is a valuable stone. Jasper may have been clear like glass or crystal. See how you translated this in [Revelation 4:3](../04/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### twelve gates

"12 gates" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]])

#### were written

This can be stated in active form. AT: "someone had written" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/12tribesofisrael.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/children.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Revelation 21:14

#### Lamb

This refers to Jesus. See how you translated this in [Revelation 5:6](../05/06.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/apostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]

### Revelation 21:16

#### twelve thousand stadia

"12,000 stadia." You may convert this to modern measures. AT: "2,200 kilometers" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### 144 cubits

"one hundred forty-four cubits." You may convert this to modern measures. AT: "66 meters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-numbers.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-bdistance.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/rod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]

### Revelation 21:18

#### The wall was built of jasper and the city of pure gold

This can be stated in active form. AT: "Someone had built the wall with jasper and the city with pure gold" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### pure gold, like clear glass

The gold was so clear that it is spoken of as if it were glass. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### The foundations of the wall were adorned

This can be stated in active form. AT: "Someone adorned the foundations of the wall" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### jasper ... emerald ... carnelian

These are valuable stones. Jasper may have been clear like glass or crystal, and carnelian may have been red. Emeralds are green. See how you translated these in [Revelation 4:3](../04/01.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### sapphire ... agate ... onyx ... chrysolite ... beryl ... topaz ... chrysoprase ... jacinth ... amethyst

These are all precious gems. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/foundation.md)]]

### Revelation 21:21

#### pearls

beautiful and valuable white beads. They are formed inside the shell of a certain kind of small animal that lives in the ocean. See how you translated this in [Revelation 17:4](../17/03.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### each of the gates was made from a single pearl

This can be stated in active form. AT: "someone had made each of the gates from a single pearl" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### pure gold, like transparent glass

The gold was so clear that it is spoken of as if it was glass. See how you translated a similar phrase in [Revelation 21:18](./18.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### Lord God ... and the Lamb are its temple

The temple represented God's presence. This means the new Jerusalem does not need a temple because God and the Lamb will live there. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/purify.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]

### Revelation 21:23

#### its lamp is the Lamb

Here the glory of Jesus, the Lamb, is spoken of as if it were a lamp that gives light to the city. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The nations will walk

"Walk" here is an idiom for "live." AT: "The people from all the different nations will live" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Its gates will not be shut

This can be stated in active form. AT: "No one will shut the gates" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/glory.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/light.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/king.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]

### Revelation 21:26

#### They will bring

"The kings of the earth will bring"

#### nothing unclean will ever enter into it, nor anyone

This can be stated in positive form. AT: "only what is clean will ever enter, and never anyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublenegatives.md)]])

#### but only those whose names are written in the Lamb's Book of Life

This can be stated in active form. AT: "but only those whose names the Lamb wrote in his Book of Life" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### the Lamb

This is a young sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](../05/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/splendor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/honor.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/clean.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/deceive.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bookoflife.md)]]

### Revelation 21:intro

#### Revelation 21 General Notes ####

####### Structure and formatting #######

This chapter gives a detailed description of the new Jerusalem.

####### Special concepts in this chapter #######

######## Second death ########
Death is a type of separation. The first death is a physical death, the separation of the soul from the body. The second death is the eternal separation from God. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/death.md)]], [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/soul.md)]] and [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]])

####### Important figures of speech in this chapter #######

######## Book of life ########
The is a metaphor for eternal life. Those possessing eternal life are said to have their names written in this book of life. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

####### Other possible translation difficulties in this chapter #######

######## New heaven and new earth ########
It is unclear whether this is an entirely new heaven and earth or if it is remade out of the present heaven and earth. The same is also true of the new Jerusalem. It is possible this will affect translation in some languages. 

##### Links: #####

* __[Revelation 21:01 Notes](./01.md)__

__[<<](../20/intro.md) | [>>](../22/intro.md)__


## Revelation 22

### Revelation 22:01

#### Connecting Statement:

John continues to describe the new Jerusalem as the angel shows it to him.

#### showed me

Here "me" refers to John.

#### the river of the water of life

"the river flowing with life-giving water"

#### the water of life

Eternal life is spoken of as if it were provided by life-giving water. See how you translated this in [Revelation 21:6](../21/05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the Lamb

This is a young sheep. Here is it used symbolically to refer to Christ. See how you translated this in [Revelation 5:6](../05/06.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-symlanguage.md)]])

#### the nations

Here "nations" refers to the people who live in every nation. AT: "the people of all nations" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/heal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Revelation 22:03

#### There will no longer be any curse

Possible meanings are 1) "There will never be anyone there that God will curse" or 2) "There will not be anyone there who is under God's curse"

#### his servants will serve him

Possible meanings of "his" and "him" are 1) both words refer to God the Father, or 2) both words refer to both God and the Lamb, who rule together as one.

####  They will see his face,

This is an idiom, meaning to be in God's presence. AT: "They will be in God's presence."  (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/curse.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/throne.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lamb.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/serve.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/face.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lamp.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reign.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]

### Revelation 22:06

#### General Information:

This is the beginning of the end of John's vision. In verse 6 the angel is speaking to John. In verse 7, Jesus is speaking. This can be shown clearly as is is in the UDB. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### These words are trustworthy and true

Here "words" refers to the message that they formed. See how you translated this in [Revelation 21:5](../21/05.md). AT: "This message is trustworthy and true" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the God of the spirits of the prophets

Possible meanings are 1) the word "spirits" refers to the inward disposition of the prophets and indicates that God inspires them. AT: "God who inspires the prophets" or 2) the word "spirits" refers to the Holy Spirit who inspires the prophets. AT: "God who gives his Spirit to the prophets" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Look!

Here Jesus begins to speak. The word "Look" adds emphasis to what follows.

#### I am coming soon!

It is understood that he is coming in order to judge. See how you translated this in [Revelation 3:11](../03/09.md). AT: "I am coming to judge soon!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/true.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/spirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/send.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]

### Revelation 22:08

#### General Information:

John tells his readers about how he responded to the angel.

#### I prostrated myself

This means that John lay on the ground and stretch himself out in reverence or submission. This action was an important part of worship, to show respect and willingness to serve.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/johntheapostle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/worship.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/brother.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/obey.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]

### Revelation 22:10

#### Connecting Statement:

The angel finishes speaking to John.

#### Do not seal up ... this book

To seal a book was to keep it closed with something that makes it impossible for anyone to read what was inside without breaking the seal. The angel is telling John not to keep the message a secret. AT: "Do not keep secret ... this book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### the words of the prophecy of this book

Here "words" refers to the message that they formed. See how you translated this in [Revelation 22:7](./06.md). AT: "This prophetic message of this book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/seal.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/righteous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Revelation 22:12

#### General Information:

As the book of Revelation is ending, Jesus gives a closing greeting. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-endofstory.md)]])

#### the alpha and the omega, the first and the last, the beginning and the end

These three phrases share similar meanings and emphasize that Jesus has and will exist for all time. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the alpha and the omega

These are first and last letters of the Greek alphabet. Possible meanings are 1) "the one who began all things and who ends all things" or 2) "the one who has always lived and who always will live." If unclear to readers you may consider using the first and last letters of your alphabet. See how you translated this in [Revelation 1:8](../01/07.md). AT: "the A and the Z" or "the first and the last" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the first and the last

This refers to the eternal nature of Jesus. See how you translated this in [Revelation 1:17](../01/17.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-merism.md)]])

#### the beginning and the end

Possible meanings are 1) "the one who began all things and the one who will cause all things to end" or 2) "the one who existed before all things and who will exist after all things." See how you translated this in [Revelation 21:6](../21/05.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/reward.md)]]

### Revelation 22:14

#### Connecting Statement:

Jesus continues giving his closing greeting.

#### those who wash their robes

Becoming righteous is spoken of as if it were washing one's clothing. See how you translated as similar phrase in [Revelation 7:14](../07/13.md). AT: "those who have become righteous, as if they have washed their robes" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Outside

This means they are outside the city and not allowed to enter.

#### are the dogs

In that culture the dog was an unclean, despised animal. Here the word "dogs" is derogatory and refers to people who are wicked. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/robe.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gate.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sorcery.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fornication.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/falsegod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]

### Revelation 22:16

#### to testify to you

Here the word "you" is plural. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-you.md)]])

#### the root and the descendant of David

The words "root" and "descendant" mean basically the same thing. Jesus speaks of being a "descendant" as if he were a "root" that grew out of David. Together the words emphasize that Jesus belongs to the family of David. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### the bright morning star

Jesus speaks of himself as if he were the bright star that sometimes appears early in the morning and indicates that a new day is about to begin. See how you translated "morning star" in [Revelation 2:28](../02/26.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/angel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/church.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/descendant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/david.md)]]

### Revelation 22:17

#### Connecting Statement:

This verse is a response to what Jesus said.

#### the Bride

Believers are spoken of as if they were a bride about to be married to her groom, Jesus. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Come!

Possible meanings are 1) that this is an invitation for people to come and drink the water of life. AT: "Come and drink!" or 2) that this is a polite request for Jesus to return. AT: "Please come!" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Whoever is thirsty ... the water of life

A person's desire for eternal life is spoken of as if it were thirst and of that person receiving eternal life as if he were drinking life-giving water. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### the water of life

Eternal life is spoken of as if it were provided by life-giving water. See how you translated this in [Revelation 21:6](../21/05.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/free.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/water.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/life.md)]]

### Revelation 22:18

#### General Information:

John gives his final remarks about the book of Revelation.

#### I testify

Here "I" refers to John.

#### the words of the prophecy of this book

Here "words" refers to the message that they formed. See how you translated this in [Revelation 22:7](./06.md). AT: "This prophetic message of this book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### If anyone adds to them ... If anyone takes away

This is a strong warning to not change anything about this prophecy.

#### that are written about in this book

This can be stated in active form. AT: "which I have written about in this book" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/word.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/plague.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/holycity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/holycity.md)]]

### Revelation 22:20

#### General Information:

In these verses John gives his and Jesus' closing greetings.

#### The one who testifies

"Jesus, who testifies"

#### everyone

"every one of you"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/testimony.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/amen.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/lord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/jesus.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]

### Revelation 22:intro

#### Revelation 22 General Notes ####

####### Structure and formatting #######

This chapter emphasizes that the prophecies of the book of Revelation are going to take place soon. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

####### Special concepts in this chapter #######

######## Tree of life ########
There is probably an intended connection between the tree of life in the Garden of Eden and the tree of life mentioned here. The curse that began in Eden will end at this time. 

####### Other possible translation difficulties in this chapter #######

######## Alpha and omega ########

These are the names of the first and last letters in the Greek alphabet. The ULB spells out their names in English. This strategy can serve as a model for other translators.  Some translators, however, may decide to use the first and last letters in their own alphabet, for example, "A and Z" in English. 
##### Links: #####

* __[Revelation 22:01 Notes](./01.md)__

__[<<](../21/intro.md) | __


## Revelation front

### Revelation front:intro

#### Introduction to Revelation ####

##### Part 1: General Introduction #####

####### Outline of the Book of Revelation #######

1. Opening (1:1-20)
1. Letters to the seven churches (2:1-3:22)
1. Vision of God in heaven, and a vision of the Lamb (4:1-11)
1. The seven seals (6:1-8:1)
1. The seven trumpets (8:2-13:18)
1. Worshipers of the Lamb, the martyrs, and the harvest of wrath (14:1-20)
1. The seven bowls (15:1-18:24)
1. Worship in heaven (19:1-10)
1. The Lamb's judgment, the destruction of the beast, the thousand years, the destruction of Satan, and the final judgment (20:11-15)
1. The new creation and the new Jerusalem (21:1-22:5)
1. Jesus' promise to return, the witness from the angels, John's closing words, Christ's message to his church, the invitation and the warning (22:6-21)

####### Who wrote the Book of Revelation? #######

The author identified himself as John. This was probably the Apostle John. He wrote the Book of Revelation while on the island of Patmos. The Romans exiled John there for teaching people about Jesus.

####### What is the Book of Revelation about? #######

John wrote the Book of Revelation to encourage believers to remain faithful even when they are suffering. John described visions he had of Satan and his followers fighting against and killing believers. In the visions God causes many terrible things to happen on the earth to punish wicked people. In the end, Jesus defeats Satan and his followers. Then Jesus comforts those who were faithful. And the believers will live forever with God in the new heavens and earth.

####### How should the title of this book be translated? #######

Translators may choose to call this book by one of its traditional titles, "Revelation," "The Revelation of Jesus Christ," "The Revelation to Saint John," or "The Apocalypse of John." Or they may choose a possibly clearer title, such as "The Things that Jesus Christ Showed to John." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

####### What type of writing is the Book of Revelation? #######

John used a special style of writing to describe his visions. John described what he saw by using many symbols. This style of writing is called symbolic prophecy or apocalyptic literature. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

##### Part 2: Important Religious and Cultural Concepts #####

####### Are the events of Revelation past or future? #######

Since early Christian times, scholars have interpreted Revelation differently. Some scholars think John described events that happened during his time. Some scholars think John described events happening from his time until the return of Jesus. Other scholars think John described events that will happen in a short period of time just before Christ returns.

Translators will not need to decide how to interpret the book before they translate it. Translators should leave the prophecies in the tenses that are used in the ULB.

####### Are there any other books in the Bible like Revelation? #######

No other book of the Bible is like the Book of Revelation. But, passages in Ezekiel, Zechariah, and especially Daniel are similar in content and style to Revelation. It may be beneficial to translate Revelation at the same time as Daniel since they have some imagery and style in common.

##### Part 3: Important Translation Issues #####

####### Does one need to understand the Book of Revelation to translate it? #######

One does not need to understand all of the symbols in the Book of Revelation to translate it properly. Translators should not give possible meanings for the symbols or numbers in their translation. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-apocalypticwriting.md)]])

####### How are the ideas of "holy" and "sanctify" represented in Revelation in the ULB? #######

The scriptures use these words to indicate any one of various ideas. For this reason, it is often difficult for translators to represent them well in their versions. In translating REvelation into English, the ULB uses the following principles:
* The meaning in two passages indicates moral holiness. Here, the ULB uses "holy." (See: 14:12; 22:11)
* Usually the meaning in Revelation indicates a simple reference to Christians without implying any particular role filled by them. In these cases, the ULB uses "believer" or "believers." (See: 5:8; 8:3, 4; 11:18; 13:7; 16:6; 17:6; 18:20, 24; 19:8; 20:9)
* Sometimes the meaning implies the idea of someone or something set apart for God alone. In these cases, the ULB uses "sanctify," "set apart," "dedicated to," or "reserved for." 

The UDB will often be helpful as translators think about how to represent these ideas in their own versions.

####### Periods of time #######

John referred to various periods of time in Revelation. For example, there are many references to forty-two months, seven years, and three and a half days. Some scholars think these time periods are symbolic. Other scholars think these are actual time periods. The translator should treat these time periods as referencing actual periods of time. It is then up to the interpreter to determine their significance or what they may represent.

####### What are the major issues in the text of the Book of Revelation? #######

The following are the most significant textual issues in the Book of Revelation:

* "'I am the alpha and the omega,' says the Lord God, 'the one who is, and who was, and who is to come, the Almighty'" (1:8). The ULB, UDB, and most modern versions read this way. Some versions add the phrase "the Beginning and the End."
* "the elders prostrated themselves and worshiped" (5:14). The ULB, UDB, and most modern versions read this way. Some older versions read, "the twenty-four elders prostrated themselves and worshiped the one who lives forever and ever."
* "so that a third of it [the earth] was burned up" (8:7). The ULB, UDB, and most modern versions read this way. Some older versions do not include this phrase.
* Some manuscripts add the phrase "and who is to come" (11:17). But the ULB, UDB, and most modern versions do not.
* Some manuscripts add the phrase "before the throne of God" (14:5). But the ULB, UDB, and most modern versions do not.
* "the one who is and who was, the Holy One" (16:5). The ULB, UDB, and most modern versions read this way. Some older manuscripts read, "O Lord, the One who is and who was and who is to be."
* "The nations will walk by the light of that city" (21:24). The ULB, UDB, and most modern versions read this way. Some older manuscripts read, "The nations that are saved will walk by the light of that city."
* "Blessed are those who wash their robes" (22:14). The ULB, UDB, and most modern versions read this way. Some older manuscripts read "Blessed are those who do his commandments."
* "God will take away his share in the tree of life and in the holy city" (22:19). The ULB, UDB, and most modern versions read this way. Some older manuscripts read, "God will take away his share in the book of life and in the holy city." 

(See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-textvariants.md)]])



---

