# <a id="jol"/>Joel

## Joel 01

### Joel 01:01

#### General Information:

God speaks through Joel to the people of Israel using poetry. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### the word of Yahweh that came to Joel

This idiom is used to announce that God gave messages to Joel. AT: "the message Yahweh gave to Joel" or "the message Yahweh spoke to Joel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### Yahweh

This is the name of God that he revealed to his people in the Old Testament. See the translationWord page about Yahweh concerning how to translate this.

#### Pethuel

Joel's father (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Has anything like this happened in your days or in the days of your ancestors?

Joel is preparing the elders to listen to what he has to say. This can be translated as a statement. AT: "Nothing like this has ever happened before either to you or to your ancestors" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### their children the next generation

You may need to fill in the words that have been left out. AT: "let their children tell the generation after them" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/wordofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/joel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Joel 01:04

#### the swarming locust

large groups of insects like grasshoppers that fly together and eat large areas of food crops (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### swarming locust ... great locust ... grasshopper ... caterpillar

These are, respectively, an adult locust that can fly, a locust too large to fly easily, a locust with wings too young to fly, and a newborn locust that has not yet developed wings. Use names that would be understood in your language.

### Joel 01:05

#### General Information:

God warns the people of Israel about the coming locust army.

#### you drunkards, and weep! Wail, all you drinkers of wine

If your language has only one word for "weep" and "wail," you can combine the lines: "you people who love wine should cry out in sorrow" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### a nation

The locust swarm is like an invading army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### His teeth ... he has the teeth ... He has made ... He has stripped

The locusts are like a nation which is like one person. You can refer to the nation as "it," or to the locusts as "they," or to the invader as one person.

#### His teeth are the teeth of a lion, and he has the teeth of a lioness.

These two lines share similar meanings. The reference to the locusts' teeth being as sharp as lions' teeth emphasize how fierce they are as they eat all of the crops of the land. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### my land ... my vineyard ... my fig tree

Yahweh's land, vineyard, and fig tree

#### terrifying

Those who see the land are very afraid because the invading nation has completely destroyed it.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drunk.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vineyard.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]

### Joel 01:08

#### General Information:

God continues speaking to the people of Israel.

#### the ground is mourning

Here the land is spoken of as if it were a person. These words could also be seen as a metonym for the people who are mourning or even as hyperbole, that the famine is so bad that even things that are not alive are mourning. AT: "the farmers are mourning" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the grain has been destroyed

This can be translated in active form. AT: "the locusts have destroyed all of the grain" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/virgin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grain.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]

### Joel 01:11

#### General Information:

God continues speaking to the people of Israel.

#### barley

a type of grass, like wheat, whose seeds can be used to make bread (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### withered

dried up and died

#### fig ... pomegranate ... apple

different types of fruit (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/perish.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/palm.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]

### Joel 01:13

#### General Information:

God speaks to the priests in Israel

#### the grain offering and the drink offering

regular offerings in the temple

#### the house of Yahweh your God

the temple in Jerusalem

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sackcloth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]

### Joel 01:15

#### General Information:

This is what God is telling the priests to say.

#### With it will come destruction from the Almighty

The abstract noun "destruction" can be translated using the verb "destroy." You may need to make explicit what it is the Almighty will destroy. AT: "On that day the Almighty will destroy his enemies" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Has not food been cut off from before our eyes, and joy and gladness from the house of our God?

It is certain that destruction will come from the Almighty because these things have already happened. This can be translated in active form. AT: "We know this is true because we have already seen the Almighty cut off our supply of food, and he has cut off joy and gladness from the house of our God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### from before our eyes

"from us." This refers to all of the nation of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### joy and gladness from the house of our God

You may need to fill in the ellipsis. AT: "joy and gladness have been cut off from the house of our God" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### joy and gladness

These two words mean basically the same thing. Together they emphasize that there is no kind of joyful activity happening at the temple. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### clods

lumps of dirt

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/almighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/houseofgod.md)]]

### Joel 01:18

#### General Information:

God continues to tell the priests how they should pray for Israel.

#### groan

make a deep sound because of pain

#### brooks

small streams

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/suffer.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/flock.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sheep.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Joel 01:intro

#### Joel 01 General Notes ####

####### Structure and formatting #######

Joel is written in poetic form and with striking imagery. The ULB is written in poetic form, but the UDB has been transferred to a prose form. If possible, use the poetic form to communicate the meaning of this book in order to stay closer to the original meaning of the text. 

####### Special concepts in this chapter #######

######## Locusts ########
This book starts very dramatically with the imagery of the locusts and the devastation they produce. There are five different kinds of locusts that appear to come and they progressively destroy the vegetation including the crops, vineyards and even the trees of the whole land of Israel.

It was common for farmers in the ancient Near East to experience large locust swarms that would come and eat all crops in their fields. Joel might be describing such attacks in this first chapter. Because Joel uses military terms and images to describe these locust attacks, his descriptions might represent enemy invaders who would come and destroy the land and its people. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

Translators should translate simply, presenting the scenes of locusts as Joel describes them, and not worry about the various possible meanings. 

####### Important figures of speech in this chapter #######

######## Rhetorical Questions ########
The author also uses rhetorical questions that communicate surprise and alarm. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

##### Links: #####

* __[Joel 01:01 Notes](./01.md)__
* __[Joel intro](../front/intro.md)__

__| [>>](../02/intro.md)__


## Joel 02

### Joel 02:01

#### General Information:

Joel continues poetry that began in the previous chapter. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Blow the trumpet ... sound an alarm

Joel is emphasizing the importance of calling Israel together in preparation for the destruction that is coming.

#### day of darkness and gloom

The words "darkness" and "gloom" share similar meanings and emphasize that the darkness will be very dark. Both words refer to a time of disaster or divine judgment. AT: "day that is full of darkness" or "day of terrible judgment" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### gloom

total or partial darkness

#### day of clouds and thick darkness

This phrase means the same thing as, and intensifies the idea of the previous phrase. Like that phrase, both "clouds" and "thick darkness" refer to divine judgment. AT: "day full of dark storm clouds" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Like the dawn that spreads on the mountains, a large and mighty army is approaching

When direct sunlight shines on a mountain at dawn, it begins at the top and spreads to the bottom. When an army comes over a mountain range, it comes over the top and spreads out as it comes down. AT: "A large, mighty army comes over the mountains into the land. They spread over the land like the light from the rising sun" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### a large and mighty army

The words "large" and "mighty" share similar meanings here and emphasize that the army will be very strong. The word "army" could possibly be 1) a metaphor for a swarm of locusts or 2) referring to a human army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]

### Joel 02:03

#### General Information:

Joel's description of the coming army continues.

#### A fire is consuming everything in front of it

A fire destroys everything as it moves, and the "army" ([Joel 2:2](./01.md)), whether of humans or of locusts, destroys everything as it moves. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### behind it a flame is burning

After a wall of flame goes through dry land and burns the dryest and smallest fuel, there will still be flames as the larger and less dry fuel burns, (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### land is like the garden of Eden

The garden of Eden was a beautiful place, and the land was beautiful. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/eden.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/eden.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/ruin.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]

### Joel 02:04

#### General Information:

The description continues with the noises of an army of horses.

#### The army's appearance is like horses

The head of a locust looks like a small horse head. The army is fast, and horses are fast. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### horses

A large, strong, fast animal with four legs. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-unknown.md)]])

#### they run like horsemen

Men riding horses move quickly, and the army moves quickly. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### jump

A horse jumps or leaps as it runs quickly.

#### a noise like that of chariots ... like the noise of fiery flames ... like a mighty army ready for battle

These sounds would have been very frightening to Joel's readers. If your readers will not understand what these sound like, you might be able to use a more general phrase: "a noise that frightens everyone" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/chariot.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/devour.md)]]

### Joel 02:06

#### General Information:

Joel continues to describe the locust army of Yahweh.

#### They run like mighty warriors ... climb the walls like soldiers

The army of locusts acts as real soldiers do. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

#### walls

walls around the cities

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]

### Joel 02:08

#### General Information:

The description of the locust army of Yahweh continues.

#### they break through the defenses

they overcome the soldiers defending the city.

### Joel 02:10

#### The earth shakes in front of them, the heavens tremble

Joel speaks of the earth and heavens as if they were people who are shaking with fear. This can be translated as either a hyperbole, that the army is so frightening that even things that are not alive are afraid, or as metonymy, that the earth and the heavens are metonyms for the beings who live there. AT: "Everyone on earth and in the heavens is very afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-personification.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the sun and the moon are darkened, and the stars stop shining

This exaggeration claims that there are so many locusts that people cannot see the sun, moon, or stars. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### Yahweh raises his voice

"Yahweh speaks loudly" to give commands.

#### great and very terrible

In this phrase both descriptions mean basically the same thing. AT: "greatly terrible" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hendiadys.md)]])

#### Who can survive it?

This can be translated as a statement. AT: "No one will be strong enough to survive Yahweh's judgment." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/command.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]

### Joel 02:12

#### Return to me with all your heart

The heart is a metonym for what the person thinks and loves. AT: "Turn away from your sins and be totally devoted to me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### Tear your heart and not only your garments

The heart is a metonym for what the person thinks and loves. Tearing one's clothes is an outward act of shame or repentance. AT: "Change your way of thinking; do not just tear your garments" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### abundant in covenant faithfulness

The abstract noun "faithfulness" can be stated as "faithful" or "faithfully." AT: "always faithful to his covenant" or "always loves faithfully" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### turn from

stop

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heart.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/grace.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/mercy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/angry.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/love.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/punish.md)]]

### Joel 02:14

#### Will he perhaps turn ... God?

This can be translated as a statement. AT: "Perhaps Yahweh will turn from his anger ... God." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### leave a blessing behind him, a grain offering and a drink offering

"leave behind him a blessing—that is, a grain offering and a drink offering." The blessing is that plenty of grain and grapes will ripen, and so the people will be able to offer grain and drink offerings.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/compassion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/bless.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mealoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mealoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/drinkoffering.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joel 02:15

#### bridal chambers

rooms, usually in the parents' houses, where brides would wait for their wedding ceremonies

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/trumpet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fast.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/assembly.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/elder.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bridegroom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/bride.md)]]

### Joel 02:17

#### do not make your inheritance into an object of scorn

"do not allow your inheritance to become people whom the other nations regard as worthless"

#### your inheritance

Here the people of Israel are spoken of as God's inheritance. AT: "your special people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Why should they say among the nations, 'Where is their God?'

This can be translated as a statement. AT: "Other nations should not be able to say, 'Their God does not help them.'" or "Other nations should not be able to say that the God of Israel has abandoned his people." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/priest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/altar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joel 02:18

#### his land

"the nation of Israel"

#### his people

"the people of Israel"

#### Look

"Pay attention to what I am about to say"

#### You will be satisfied with them

"You will have all you need of them"

#### a disgrace

"unworthy of respect"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zealous.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]

### Joel 02:20

#### General Information:

God continues his promise to Israel.

#### northern ... eastern ... western

These directions are from the perspective of people living in the land of Israel.

#### the eastern sea

the Dead Sea

#### the western sea

the Mediterranean Sea

#### he has done great things

That is, Yahweh has done great things. Another possible meaning is that the writer speaks of the invading army, "it has done very bad things."

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/castout.md)]]

### Joel 02:21

#### Do not fear, land

Joel speaks to the people of the land as if he were speaking to the land itself. AT: "Do not be afraid, you people of the land" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### Do not fear, beasts of the field

Joel speaks to people who own livestock as if he were speaking to the animals themselves. AT: "Do not be afraid, you people who own livestock" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-apostrophe.md)]])

#### the pastures of the wilderness will sprout

The pastures are a metonym for the plants that grow in the pastures. AT: "plants good for food will sprout in the pastures in the wilderness" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### he will ... bring down showers for you

"he will ... cause much rain to fall so that you will live well"

#### autumn rain and the spring rain

the first rains of the rainy season in early December and the last rains in April and May

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/fear.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/joy.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fig.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]

### Joel 02:24

#### Connecting Statement:

Yahweh begins a long speech to the Israelites.

#### vats

large containers for liquids

#### the years of crops that the swarming locust has eaten

"the crops that you took care of for years and that the swarming locusts have eaten"

#### swarming locust ... the great locust, the devouring locust, and the destroying locust

These are, respectively, an adult locust that can fly, a locust too large to fly easily, a locust with wings too young to fly, and a newborn locust that has not yet developed wings. Use names that would be understood in your language. See how you translated this in [Joel 1:4](../01/04.md).

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/thresh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wheat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/oil.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/restore.md)]]

### Joel 02:26

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](./24.md), promising good things for the people of Israel.

#### praise the name of Yahweh

The name is a metonym for the person, specifically his reputation. AT: "praise Yahweh" or "praise Yahweh because everyone knows he is good" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### the name of Yahweh ... who has done wonders

Yahweh speaks of himself by name to show that he will certainly do as he has said. AT: "my name ... because I have done wonders" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-123person.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/praise.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/shame.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/peoplegroup.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]

### Joel 02:28

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](./24.md), promising good things for the people of Israel.

#### It will come about afterward that I

"This is what I will do after that: I"

#### I will pour out my Spirit on all flesh

Yahweh speaks of the Spirit as if he were speaking of water. AT" "I will give my Spirit generously to all flesh" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### all flesh

Here "flesh" represents people. AT: "all people" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/flesh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/dream.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/vision.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/servant.md)]]

### Joel 02:30

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](./24.md), promising good things for the people of Israel.

#### blood, fire, and pillars of smoke

"blood" is symbolizing the death of people. AT: "death, fire and pillars of smoke" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### The sun will turn into darkness

"The sun will no longer give light"

#### the moon into blood

Here the word "blood" refers to the color red. You can supply the verb for this phrase. AT: "the moon will turn red like blood" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/miracle.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/earth.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/fire.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/pillar.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/darkness.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]

### Joel 02:32

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](./24.md), promising good things for the people of Israel.

#### It will be that everyone

"This is what will happen: everyone"

#### everyone who calls on the name of Yahweh will be saved

The name is a metonym for the person. This can be translated in active form. AT: "Yahweh will save everyone who calls on his name" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### on Mount Zion and in Jerusalem

These refer to the same place. AT: "on Mount Zion in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### among the survivors, those whom Yahweh calls

The phrase "there will be" is understood from earlier in the sentence. It can be repeated here. AT: "among the survivors there will be those whom Yahweh calls" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-ellipsis.md)]])

#### survivors

people who live through a terrible event like a war or a disaster

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/call.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/name.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/save.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]

### Joel 02:intro

#### Joel 02 General Notes ####

####### Structure and formatting #######

This chapter continues in the poetic form with striking imagery of armies and soldiers. 

####### Special concepts in this chapter #######

######## Locusts ########

This book starts very dramatically with the imagery of the locusts and the devastation they produce. There are five different kinds of locusts that appear to come and progressively destroy the vegetation including the crops, vineyards and even the trees of Israel.

####### Important figures of speech in this chapter #######

This chapter uses simile to a great extent as Joel tries to describe this army. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-simile.md)]])

######## Metaphor ########
The drought, or severe lack of rain, Joel describes is probably a real drought. It might also be a picture of either enemy invaders or of Yahweh himself coming to punish his people and the other nations. Translators should translate simply, presenting the scenes of locusts and drought as Joel describes them, and not worry about the various possible meanings. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

##### Links: #####

* __[Joel 02:01 Notes](./01.md)__

__[<<](../01/intro.md) | [>>](../03/intro.md)__


## Joel 03

### Joel 03:01

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](../02/24.md), promising good things for the people of Israel.

#### Behold

"Listen" or "Pay attention"

#### in those days and at that time

The phrase "at that time" means the same thing as and intensifies the phrase "in those days." AT: "in those very days" or "at that very time" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### when I return the exiles of Judah and Jerusalem

"When I send the exiles back to Judah and Jerusalem"

#### Valley of Jehoshaphat

Jehoshaphat, whose name means "Yahweh judges," was king of Judah before Joel lived. There is no known place with this name. It would be best to translate this as the name of a valley that people named after the man Jehoshaphat.

#### my people and my inheritance Israel

These two phrases emphasize how Yahweh views Israel as his own precious people. AT: "the people of Israel, who are my inheritance" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-doublet.md)]])

#### traded a boy for a prostitute, and sold a girl for wine so they could drink

These are examples of the kinds of things they did and do not indicate what they did to two particular children. AT: "and did things like trading a boy for a prostitute and selling a girl for wine, so they could drink" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/exile.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoshaphat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoshaphat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/inherit.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/lots.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/prostitute.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]

### Joel 03:04

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](../02/24.md), promising good things for the people of Israel.

#### why are you angry at me ... Philistia?

Yahweh is encouraging the people of Judah, who can hear him, by scolding the people of Tyre, Sidon, and Philistia, who cannot hear him, as if they can. The names of the towns are metonyms for the people who live in the towns. These words can be translated as a statement. AT: "you have no right to be angry at me ... Philistia." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### Will you repay me?

"Will you get revenge on me?" God uses this question to make the people think about what they are doing. AT: "You think you can get revenge on me, but you cannot." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-rquestion.md)]])

#### I will immediately return your retribution on your own head

Here the word "head" refers to the person. Yahweh will make them suffer the pain they wanted him to suffer. AT: "I will cause you to suffer the retribution that you tried to put on me" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-idiom.md)]])

#### retribution

"revenge" or "payback"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/tyre.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/sidon.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistia.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/philistia.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/head.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/silver.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/gold.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/temple.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/kingdomofjudah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/greek.md)]]

### Joel 03:07

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](../02/24.md), promising good things for the people of Israel.

#### Look

"Pay attention" or "Listen"

#### out of the place where you sold them

The people of Israel will leave the places where they were slaves and come back to the land of Israel. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### return payment

"give back what you deserve"

#### I will sell your sons and your daughters, by the hand of the people of Judah

The hand can be a metonym for the power the hand exercises or a synecdoche for the person. AT: "I will have the people of Judah sell your sons and your daughters" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-synecdoche.md)]])

#### Sabeans

the people of the land of Sabea (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/hand.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joel 03:09

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](../02/24.md), promising good things for the people of Israel. Here he begins an ironic call to the nations to prepare for a war in which Yahweh will completely destroy the nations. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### rouse the mighty men

"make the mighty men ready for action"

#### Beat your plowshares into swords and your pruning knives into spears

These two phrases share similar meanings. Both of them instruct the people to turn their farming tools into weapons. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### plowshares

tools that are used to break up the soil in order to plant crops

#### pruning knives

knives that are used to cut off small branches

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/proclaim.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/sword.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/spear.md)]]

### Joel 03:11

#### General Information:

Yahweh continues the speech he began in [Joel 2:25](../02/24.md), promising good things for the people of Israel.

#### Hurry and come ... together there

These words continue the ironic call to battle that begins in [Joel 3:9](./09.md). (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-irony.md)]])

#### gather yourselves together

The purpose of the gathering is for battle. This can be stated explicitly. AT: "gather yourselves together for battle" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-explicit.md)]])

#### Yahweh, bring down your mighty warriors

Possible meanings are 1) Joel is telling the people of Judah that this is what they are to "proclaim among the nations" ([Joel 3:9](./09.md)) or 2) Joel interrupts the words of Yahweh and prays a short prayer.

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/mighty.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]

### Joel 03:12

#### General Information:

Yahweh finishes the speech he began in [Joel 2:25](../02/24.md), promising good things for the people of Israel.

#### Let the nations wake themselves ... all the surrounding nations

The words "the nations" and "the surrounding nations" refer to the same nations, those that surround Judah. Yahweh will judge them in the Valley of Jehoshaphat for what they have done to Jerusalem.

#### Valley of Jehoshaphat

Jehoshaphat, whose name means "Yahweh judges," was king of Judah before Joel lived. There is no known place with this name. It would be best to translate this as the name of a valley that people named after the man Jehoshaphat. See how you translated this in [Joel 3:2](./01.md).

#### Put in the sickle ... the winepress is full

Possible meanings are that Yahweh speaks of completely destroying the nations as if 1) he were harvesting all the grapes and all the grain or 2) he were harvesting quickly, while the grain and grapes are ripe. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Put in the sickle, for the harvest is ripe

Yahweh speaks of making war against the nations as if he were using a sharp tool to harvest a field of ripe crops. If your readers will not understand the word "sickle," you may use the word for any sharp tool that your people use for harvesting. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### Put in the sickle

"Swing the sickle to cut the grain." This is a metaphor for a soldier using a sword to kill people, but it is best to use the word for a sharp tool used in harvesting. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### sickle

a long curved knife that people use for cutting grain

#### the harvest is ripe

"the grain is ready to be harvested"

#### Come, crush the grapes, for the winepress is full

Yahweh speaks of the nations as if they were many grapes in a winepress, ready for people to crush them by stepping on them. AT: "Come, completely destroy the nations, for they are many, and they are helpless to resist you" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The vats overflow, for their wickedness is enormous

Yahweh speaks of the nations' wickedness as if it were the juice that flows from the winepress into storage containers, and more juice flows into the vats than they can contain. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/nation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoshaphat.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jehoshaphat.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/harvest.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/grape.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/winepress.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/evil.md)]]

### Joel 03:14

#### a tumult, a tumult

A tumult is noise caused by a large crowd. This is repeated to show that it will be very noisy from all the people.

#### Valley of Judgment ... Valley of Judgment

This phrase is repeated to show that the judgment will certainly happen.

#### Valley of Judgment

There is no known place with this name. The abstract noun "judgment" can be translated using the verb "judge." AT: "Valley Where Yahweh Judges" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-abstractnouns.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/judge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/dayofthelord.md)]]

### Joel 03:16

#### General Information:

Yahweh begins speaking in verse 17.

#### Yahweh will roar from Zion, and raise his voice from Jerusalem

Both phrases mean Yahweh will shout with a loud, clear and powerful voice from Jerusalem. If your language only has one word for speaking very loudly, this can be used as one phrase. AT: "Yahweh will shout from Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### Yahweh will roar

Possible meanings are 1) "Yahweh will roar like a lion" or 2) "Yahweh will roar like thunder." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### The heavens and earth will shake

Joel speaks of the heavens and earth as if they were people who are shaking with fear. This can be translated as either a hyperbole, that Yahweh's roar is so frightening that even things that are not alive are afraid, or as metonymy, that the heavens and earth are metonyms for the beings who live there. AT: "Everyone in the heavens and on the earth is very afraid" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### will shake

This word is the past form of the word translated "tremble" in [Joel 2:10](../02/10.md).

#### Yahweh will be a shelter for his people, and a fortress for the people of Israel

Both of these phrases mean Yahweh will protect his people. A fortress is a strong shelter used to protect people during war. AT: "Yahweh will be a strong fortress for his people, the people of Israel" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])

#### So you will know

"When I do these things, you will know"

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/jerusalem.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/heaven.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/peopleofgod.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/israel.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/god.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holy.md)]]

### Joel 03:18

#### General Information:

God continues to speak about the day of the Lord.

#### It will come about on that day that the mountains

"This is what will happen on that day: the mountains" Translate "It will come about" as in [Joel 2:28](../02/28.md).

#### the mountains will drip with sweet wine

"sweet wine will drip from the mountains." This is an exaggeration to show that the land is very fertile. AT: "On the mountains there will be vineyards that produce plenty of sweet wine" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-hyperbole.md)]])

#### the hills will flow with milk

"milk will flow from the hills." The land being very fertile is spoken of as if the hills would flow with milk. AT: "on the hills your cattle and goats will produce plenty of milk" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metaphor.md)]])

#### all the brooks of Judah will flow with water

"water will flow through all the brooks of Judah"

#### water the Valley of Shittim

"will send water to the Valley of Shittim"

#### Shittim

the name of a place on the east side of the Jordan River. It means "Acacia Trees." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]])

#### Egypt will become an abandoned devastation

"Everyone will leave Egypt and no one will live there"

#### Edom will become an abandoned wilderness

"Everyone will leave Edom and it will look like no people have ever lived there"

#### because of the violence done to the people of Judah

"because of the violent things Egypt and Edom did to the people of Judah"

#### because they shed innocent blood in their land

The word "they" refers to "Edom" and "Egypt" and is a metonym for the people of Egypt and Edom. The words "innocent blood" are a metonym for innocent people whom they have killed. AT: "because the people of Egypt and the people of Edom killed innocent people in the land of the people of Judah" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/wine.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/judah.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/egypt.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/names/edom.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/desert.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/innocent.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]

### Joel 03:20

#### General Information:

Yahweh continues to speak about the day of the Lord.

#### Judah will be inhabited forever

This can be stated in active form. AT: "people will live in Judah forever" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### Jerusalem will be inhabited from generation to generation

This can be stated in active form. AT: "generation after generation, people will live in Jerusalem" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-activepassive.md)]])

#### I will avenge their blood that I have not yet avenged

Blood is a metonym for death. AT: "I will punish the enemies who killed the people of Israel and still have not been punished" (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-metonymy.md)]])

#### translationWords

* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/eternity.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/generation.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/other/avenge.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/blood.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/yahweh.md)]]
* [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/zion.md)]]

### Joel 03:intro

#### Joel 03 General Notes ####

####### Structure and formatting #######

There is a change in focus in this chapter from the people of Israel to her enemies. The events of this chapters also contain many prophecies about the events of the end of this world. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/prophet.md)]])

####### Other possible translation difficulties in this chapter #######

######## Israel ########
The mention of Israel in this chapter is probably a reference to the people of Judah and not the northern kingdom of Israel. It is also possible this is a reference to the people of Israel as a whole.

##### Links: #####

* __[Joel 03:01 Notes](./01.md)__

__[<<](../02/intro.md) | __


## Joel front

### Joel front:intro

#### Introduction to Joel ####

##### Part 1: General Introduction #####

####### Outline of the Book of Joel #######

1. Judgment and the day of Yahweh (1:1–2:11)
    - An army like locusts, like the coming Judgment (1:1–20)
    - The day of Yahweh (2:1–11)
1. Restoration and the mercy of Yahweh 
    - The people should turn to Yahweh, for he will pity them (2:12–27)
    - The Spirit of Yahweh, wonders, and salvation (2:28–32)
1. Yahweh will judge the nations
    - Yahweh judges the nations (3:1–16)
    - Yahweh dwells in Zion (3:17–21)

####### What is the Book of Joel about? #######

In this book, Joel speaks a lot about the "day of Yahweh." This expression is found five times in Joel (1:15; 2:1; 11, 21; and 3:14). This phrase is also found in thirteen places in Isaiah, Jeremiah, Ezekiel, Amos, Obadiah, Zephaniah, and Malachi. This "day" is the time when Yahweh will judge and punish his people and also the other nations. At this time, Yahweh will stop those who rebel and sin against him.

####### How should the title of this book be translated? #######

"The Book of Joel" may also be called the "The Book about Joel" or "The Sayings of Joel." (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/translate-names.md)]]) 

####### Who wrote the Book of Joel? #######

Very little is known about the prophet Joel, son of Pethuel. According to tradition, Joel lived in the time of the northern and southern kingdoms. He may have lived during the reign of King Joash of Judah sometime between 650-600 B.C. However, most scholars today think that Joel probably lived after the Jews had returned to Judah from Babylonia.

##### Part 2: Important Religious and Cultural Concepts #####

####### What is the meaning of the locust attacks in Joel 1 and 2, and of the drought in Joel 2? #######

It was common for farmers in the Ancient Near East to experience massive locust attacks. Millions of these insects would come and eat all crops in their fields. Joel may have been describing such attacks in the first two chapters. But because Joel used military terms to describe these locust attacks, he may have been describing enemy invaders who would come and destroy the land and its people. 

In the same manner, the drought that Joel described might have been a real lack of rain. Or it might have been a description of either enemy invaders or of Yahweh himself coming to punish his people and the other nations.

Translators should translate simply as Joel described them and not worry about the various possible meanings.

####### What did Joel prophesy about the future for God's people? #######

Joel prophesied that God will defeat Israel's enemies, rebuild the city of Jerusalem, and rule as victorious king over the whole world. At the same time, God will give his Spirit to all his people, and they will receive messages from him in dreams and visions. (See: [[[https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md](https://git.door43.org/dummy_repo/en_tw/src/master/bible/kt/holyspirit.md)]])

##### Part 3: Important Translation Issues #####

####### How should one translate the poetry of the Book of Joel? #######

All of the text in the Book of Joel is poetry, as is represented in the ULB. The UDB, however, presents the text as prose, because many translators will choose to use prose in their versions. Translators who wish to translate the book as poetry should read about poetry and parallelism. (See: [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/writing-poetry.md)]] and [[[https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md](https://git.door43.org/dummy_repo/en_ta/src/master/translate/figs-parallelism.md)]])



---

